export const environment = {
  production: true,
  apiUrl : 'http://10.20.79.116:1994'
  };



