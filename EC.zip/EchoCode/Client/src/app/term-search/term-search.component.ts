import { Component, OnInit, HostListener } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Service } from '../Services/apicall';
import { HCPCSApiCall } from '../Services/HCPCSApiCall';
import { FlatTreeControl } from '@angular/cdk/tree';
import { MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material/tree';

@Component({
  selector: 'app-term-search',
  templateUrl: './term-search.component.html',
  styleUrls: ['./term-search.component.css']
})
export class TermSearchComponent implements OnInit {
  TermText: any;
  CPTTreeData: any = [];
  HCPCSTreeData: any = [];
  CMTreeData: any = [];
  PCSTreeData: any = [];
  splitdata: any;
  notFound: boolean;
  dataNotFound: string;
  hcpcsNotFound:boolean;
  icdPcsNotFound:boolean;
  icdCmNotFound:boolean;
  private _transformer = (node: any, level: number) => {
    if (node.code.includes("-")) {
      this.splitdata = node.code.split("-");
      return {
        expandable: !!node.node && node.node.length > 0,
        name: node.desc,
        code1: this.splitdata[0],
        code2: this.splitdata[1],
        level: level,
      };
    }
    else {
      return {
        expandable: !!node.node && node.node.length > 0,
        name: node.desc,
        code: node.code,
        level: level,
      };
    }
  }

  treeControl = new FlatTreeControl<any>(
    node => node.level, node => node.expandable);

  treeFlattener = new MatTreeFlattener(
    this._transformer, node => node.level, node => node.expandable, node => node.node);

  CPTdataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
  CMdataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
  HCPCSdataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
  PCSdataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);

  hasChild = (_: number, node: any) => node.expandable;
  constructor(private route: ActivatedRoute, private service: Service, private Hcpcscallservice: HCPCSApiCall, private router: Router) { }
  ExpandCPTTree: any;
  @HostListener('window:load', ['$event']) onload($event) {
    this.router.navigate(['/TermSearch'])
  }
  ngOnInit() {
    this.notFound = false;
    this.dataNotFound = "No data found";
    this.CPTdataSource.data = [];
    this.route.queryParams.subscribe(params => {
      if (Object.keys(params).length != 0) {
        this.TermText = params.Term;
        this.Hcpcscallservice.GetMethod('/Apihit/GetApiTreeData?Term=' + this.TermText + '&CodeType=cpt').subscribe(
          (res: any) => {
            this.CPTTreeData = JSON.parse(res);
            if (this.CPTTreeData.termSearchGroup==undefined) {
              this.CPTdataSource.data = [];
              this.notFound = true;
              this.ExpandCPTTree = true;
            }
            else if(this.CPTTreeData.termSearchGroup.length==0){
              this.CPTdataSource.data = [];
              this.notFound = true;
              this.ExpandCPTTree = true;
            }
            else {
              this.CPTdataSource.data = this.CPTTreeData.termSearchGroup;
              console.log(this.CPTdataSource.data);
              this.ExpandCPTTree = true;
              this.notFound = false;
            }
          },
          error => { }
        )
      }
    });
  }
  CodeClick(data, CodeType) {
    this.router.navigate(["/codeinfo"], { queryParams: { Code: data, CodeType: CodeType } });
  }
  HCPCSOpened() {
    this.HCPCSdataSource.data = [];
    this.hcpcsNotFound = false;
    this.Hcpcscallservice.GetMethod('/Apihit/GetApiTreeData?Term=' + this.TermText + '&CodeType=hcpcs').subscribe(
      (res: any) => {
        this.HCPCSTreeData = JSON.parse(res);
        if (this.HCPCSTreeData.termSearchGroup==undefined) {
          this.HCPCSdataSource.data = [];
          this.hcpcsNotFound = true;
        }
        else if(this.HCPCSTreeData.termSearchGroup.length==0){
          this.HCPCSdataSource.data = [];
          this.hcpcsNotFound = true;
        }
        else {
          this.HCPCSdataSource.data = this.HCPCSTreeData.termSearchGroup;
          this.hcpcsNotFound = false;
        }
      },
      error => { }
    )
  }

  ICD10PCSOpened() {
    this.PCSdataSource.data = [];
    this.icdPcsNotFound = false;
    this.Hcpcscallservice.GetMethod('/Apihit/GetApiTreeData?Term=' + this.TermText + '&CodeType=icd10pcs').subscribe(
      (res: any) => {
        this.PCSTreeData = JSON.parse(res);
        if (this.PCSTreeData.termSearchGroup==undefined) {
          this.PCSdataSource.data = [];
          this.icdPcsNotFound = true;
        }
        else if(this.PCSTreeData.termSearchGroup.length==0){
          this.PCSdataSource.data = [];
          this.icdPcsNotFound = true;
        }
        else {
          this.PCSdataSource.data = this.PCSTreeData.termSearchGroup;
          this.icdPcsNotFound = false;
        }
      },
      error => { }
    )
  }

  ICD10CMOpened() {
    this.CMdataSource.data = [];
    this.icdCmNotFound = false;
    this.Hcpcscallservice.GetMethod('/Apihit/GetApiTreeData?Term=' + this.TermText + '&CodeType=icd10cm').subscribe(
      (res: any) => {
        this.CMTreeData = JSON.parse(res);
        if (this.CMTreeData.termSearchGroup==undefined) {
          this.CMTreeData.data = [];
          this.icdCmNotFound = true;
        }
        else if(this.CMTreeData.termSearchGroup.length==0) {
          this.CMTreeData.data = [];
          this.icdCmNotFound = true;
        }
        else {
          this.CMdataSource.data = this.CMTreeData.termSearchGroup;
          this.icdCmNotFound = false;
        }
      },
      error => { }
    )
  }

  TermSearch(data: any) {
    if (data[0].STATUS == 'D') {
      this.service.GetDeletedCode(data[0].CODE).subscribe(
        res => {
          this.router.navigate(["/DeletedCodes"], { queryParams: { Code: data[0].CODE } })
        },
        error => { }
      )
    } else {
      this.router.navigate(["/codeinfo"], { queryParams: { Code: data[0].CODE } });
    }
  }
}
