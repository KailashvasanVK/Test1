import { Component, OnInit } from '@angular/core';
import {FlatTreeControl} from '@angular/cdk/tree';
import {MatTreeFlatDataSource, MatTreeFlattener} from '@angular/material/tree';

interface FoodNode {
  name: string;
  code:number;
  children?: FoodNode[];
}
interface ExampleFlatNode {
  expandable: boolean;
  name: string;
  level: number;
}


const TREE_DATA: FoodNode[] = [
  {
    name: 'Acetabulum',
    code:50342,
    children: [
      {name: 'Excision,Tumour',code:27076},
      {name: 'Fracture Treatment',code:0},
      {name: 'Reconstruction',code:27120},
    ]
  }, {
    name: 'Archilles Tendon',
    code:50220,
    children: [
      {
        name: 'Green',
        code:0,
        children: [
          {name: 'Broccoli',code:0},
          {name: 'Brussels sprouts',code:0},
        ]
      },
    ]
  },
];
@Component({
  selector: 'app-index-search',
  templateUrl: './index-search.component.html',
  styleUrls: ['./index-search.component.css']
})
export class IndexSearchComponent implements OnInit {
  private _transformer = (node: FoodNode, level: number) => {
    return {
      expandable: !!node.children && node.children.length > 0,
      name: node.name,
      level: level,
    };
  }

  treeControl = new FlatTreeControl<ExampleFlatNode>(
      node => node.level, node => node.expandable);

  treeFlattener = new MatTreeFlattener(
      this._transformer, node => node.level, node => node.expandable, node => node.children);

  dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);

  hasChild = (_: number, node: ExampleFlatNode) => node.expandable;
  constructor() {this.dataSource.data = TREE_DATA; }
  alphabets:string[] = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
  subAlpha:string;
  ngOnInit() {
    
  }
  getSubIndex(alpha)
  {
    this.subAlpha = alpha
  }
}
