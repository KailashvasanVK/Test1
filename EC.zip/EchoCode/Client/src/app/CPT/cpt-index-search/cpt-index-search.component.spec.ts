import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CptIndexSearchComponent } from './cpt-index-search.component';

describe('CptIndexSearchComponent', () => {
  let component: CptIndexSearchComponent;
  let fixture: ComponentFixture<CptIndexSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CptIndexSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CptIndexSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
