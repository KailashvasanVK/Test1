import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CptNewCodesComponent } from './cpt-new-codes.component';

describe('CptNewCodesComponent', () => {
  let component: CptNewCodesComponent;
  let fixture: ComponentFixture<CptNewCodesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CptNewCodesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CptNewCodesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
