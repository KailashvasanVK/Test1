import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CptRevisedCodesComponent } from './cpt-revised-codes.component';

describe('CptRevisedCodesComponent', () => {
  let component: CptRevisedCodesComponent;
  let fixture: ComponentFixture<CptRevisedCodesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CptRevisedCodesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CptRevisedCodesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
