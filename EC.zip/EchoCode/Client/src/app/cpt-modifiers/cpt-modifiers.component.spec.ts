import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CPTModifiersComponent } from './cpt-modifiers.component';

describe('CPTModifiersComponent', () => {
  let component: CPTModifiersComponent;
  let fixture: ComponentFixture<CPTModifiersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CPTModifiersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CPTModifiersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
