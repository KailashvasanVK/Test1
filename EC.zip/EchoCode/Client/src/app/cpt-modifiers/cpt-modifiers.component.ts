import { Component, OnInit } from '@angular/core';
import{Service} from '../Services/apicall';
import {MatSnackBar} from '@angular/material/snack-bar';
import {ActivatedRoute,Router} from '@angular/router';



@Component({
  selector: 'app-cpt-modifiers',
  templateUrl: './cpt-modifiers.component.html',
  styleUrls: ['./cpt-modifiers.component.css']
})
export class CPTModifiersComponent implements OnInit {
  ModifierCodevisible=true;
  Modifiervisible=false;
  CPTModifierHeading='CPT Modifiers';
  ModifierCodelink:any;
  ModifierCode:any;
  hideBack=true;

  constructor(private service:Service,private snackBar:MatSnackBar,private router:Router) { }

  ngOnInit() {
    this.service.GetAllModifierCodeLink('CPT').subscribe(
      res =>{        
         this.ModifierCodelink=res;
      },
      error => { }  
    )
  }
  CPTModifierBack(){
    this.CPTModifierHeading='CPT Modifiers';
    this.Modifiervisible=false;
    this.ModifierCodevisible=true;
    this.hideBack=true;
  }
  redirectCodeinfo(data){
    this.service.getdatabycode(data).subscribe(
      res =>{
        
        if (res.length == 1){        
          this.router.navigate(["/codeinfo"],{ queryParams: { Code:res[0].CODE} });
        }else if(res.length >1){
          let codedata;
          for(let i=0;i<=res.length-1;i++)
            {
              if(res[i].BASE_CODE_TYPE == 'CPT'){
                codedata =res[i];
              }
            }
            this.router.navigate(["/codeinfo"],{ queryParams: { Code:codedata.CODE,CodeType:codedata.BASE_CODE_TYPE} });
        }
      },
      error => { }  
    )

  }
  
  ModifierCodeeve(data:any){
    if(data[0].STATUS == 'D'){
      this.service.GetDeletedCode(data[0].CODE).subscribe(
        res =>{
          let RedirectValue;
          if(data[0].BASE_CODE_TYPE == 'CPT')
            {
              RedirectValue="/DeletedCodes";
            }else if(data[0].BASE_CODE_TYPE == 'HCPCS')
            {
              RedirectValue="/HcpcsDeletedCode";
            }else if(data[0].BASE_CODE_TYPE == 'ICD-CM')
            {
              RedirectValue="/Icd10CmDeletedCodes";
            }else if(data[0].BASE_CODE_TYPE == 'ICD-PCS')
            {
              RedirectValue="/Icd10PcsDeletedCodes";
            }
          this.router.navigate([RedirectValue],{queryParams: { Code: data[0].CODE}})
        },
        error => { }  
      )
    }else{
      this.router.navigate(["/codeinfo"],{ queryParams: { Code:data[0].CODE} });
    }
  }
  GetModifierCode(data){
    this.CPTModifierHeading='Modifier Code for '+data;
    this.service.GetModifierCode(data,'CPT').subscribe(
      res =>{
        if(res.length > 0){
          this.Modifiervisible=true;
          this.ModifierCodevisible=false;
         this.ModifierCode=res;
         this.hideBack=false;
         
        }else{
          this.ModifierCode=[];
          this.Modifiervisible=false;          
          this.ModifierCodevisible=true;
          this.hideBack=true;
          
          this.snackBar.open('No Data found!!','OK',{
            duration:3000,
            verticalPosition: 'top'            
          }); 
        }
      },
      error => { }  
    )
  }

}
