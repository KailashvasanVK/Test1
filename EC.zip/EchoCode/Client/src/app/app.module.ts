import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { MDBBootstrapModule } from 'angular-bootstrap-md';
import { SideNavComponent } from './side-nav/side-nav.component';
import { HomeComponent } from './home/home.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatRadioModule} from '@angular/material/radio';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatSelectModule} from '@angular/material/select';
import {MatButtonModule} from '@angular/material/button';
import {MatTableModule} from '@angular/material/table';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatDialogModule} from '@angular/material/dialog';
import {MatMenuModule} from '@angular/material/menu';
import {MatSortModule} from '@angular/material/sort';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatDividerModule} from '@angular/material/divider';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatListModule} from '@angular/material/list';
import {MatIconModule} from '@angular/material/icon';
import {MatCardModule} from '@angular/material/card';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatNativeDateModule} from '@angular/material/core'
import { IndexSearchComponent } from './index-search/index-search.component';
import { MatTreeModule } from '@angular/material/tree';
import { CodeInfoComponent } from './code-info/code-info.component';
import { CodeResultsComponent } from './code-results/code-results.component';
import { SearchbarComponent } from './searchbar/searchbar.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {Service} from './Services/apicall';
import{HCPCSApiCall} from './Services/HCPCSApiCall';

import{LoaderServiceService} from './Services/loaderService.service';
import { NgxLoadingModule } from 'ngx-loading';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import {
  DxTextBoxModule,
  DxNumberBoxModule,
  DxDateBoxModule,
  DxSelectBoxComponent,
  DxSelectBoxModule,
  DxTextAreaModule,
  DxDataGridModule,
  DxButtonModule,
  DxAutocompleteModule,
  DxTemplateModule
} from 'devextreme-angular'; 
import { LatestUpdatesComponent } from './latest-updates/latest-updates.component';
import { DeletedCodesComponent } from './deleted-codes/deleted-codes.component';
import { HCPCSDeletedCodesComponent } from './hcpcs-deleted-codes/hcpcs-deleted-codes.component';
import { ClientmappingPipe } from './clientmapping.pipe';
import { ColorCodesKeyPipe } from './colorCodesKey.pipe';
import { CPTModifiersComponent } from './cpt-modifiers/cpt-modifiers.component';
import { HCPCSModifiersComponent } from './hcpcs-modifiers/hcpcs-modifiers.component';
import { DRGDialogComponent } from './code-info/drg-dialog/drg-dialog.component';
import { CPTCMComponent } from './Cross_Reference/cpt-cm/cpt-cm.component';
import { CPTPCSComponent } from './Cross_Reference/cpt-pcs/cpt-pcs.component';
import { CPTHCPCSComponent } from './Cross_Reference/cpt-hcpcs/cpt-hcpcs.component';
import { HCPCSCMComponent } from './Cross_Reference/hcpcs-cm/hcpcs-cm.component';
import { AppLoaderComponent } from './app-loader/app-loader.component';
import { Interceptor } from "src/app/Services/Interceptor/interceptor";
import { AlertComponent } from './alert/alert.component';
import { CciEditCheckerComponent } from './cci-edit-checker/cci-edit-checker.component';
import { AutopopulatetextboxComponent } from './autopopulatetextbox/autopopulatetextbox.component';
import { GlobalSurgeryDaysCalculatorComponent } from './global-surgery-days-calculator/global-surgery-days-calculator.component';
import { TermSearchComponent } from './term-search/term-search.component';
import { AutoTextboxComponent } from './global-surgery-days-calculator/auto-textbox/auto-textbox.component';
import { Icd10cmDrugComponent } from './icd-10-cm/icd10cm-drug/icd10cm-drug.component';
import { CptNewCodesComponent } from './CPT/cpt-new-codes/cpt-new-codes.component';
import { HcpcsNewCodesComponent } from './HCPCS/hcpcs-new-codes/hcpcs-new-codes.component';
import { IcdCmNewCodesComponent } from './ICD-CM/icd-cm-new-codes/icd-cm-new-codes.component';
import { IcdPcsNewCodesComponent } from './ICD-PCS/icd-pcs-new-codes/icd-pcs-new-codes.component';
import { CptRevisedCodesComponent } from './CPT/cpt-revised-codes/cpt-revised-codes.component';
import { HcpcsRevisedCodesComponent } from './HCPCS/hcpcs-revised-codes/hcpcs-revised-codes.component';
import { IcdCmRevisedCodesComponent } from './ICD-CM/icd-cm-revised-codes/icd-cm-revised-codes.component';
import { IcdPcsRevisedCodesComponent } from './ICD-PCS/icd-pcs-revised-codes/icd-pcs-revised-codes.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { IcdCmDeletedCodesComponent } from './ICD-CM/icd-cm-deleted-codes/icd-cm-deleted-codes.component';
import { IcdPcsDeletedCodesComponent } from './ICD-PCS/icd-pcs-deleted-codes/icd-pcs-deleted-codes.component';
import { DrgCodesComponent } from './drg-codes/drg-codes.component';
import { RxhccComponent } from './HCC/rxhcc/rxhcc.component';
import { HccEsrdComponent } from './HCC/hcc-esrd/hcc-esrd.component';
import { MedAdvV22Component } from './HCC/med-adv-v22/med-adv-v22.component';
import { MedAdvV24Component } from './HCC/med-adv-v24/med-adv-v24.component';
import { NeoplasmTableComponent } from './ICD-CM/neoplasm-table/neoplasm-table.component';
import { CptHcpcsRevenueComponent } from './Cross_Reference/cpt-hcpcs-revenue/cpt-hcpcs-revenue.component';
import { ExternalCausesComponent } from './ICD-CM/external-causes/external-causes.component';
import { HccTypeViewComponent } from './HCC/hcc-type-view/hcc-type-view.component';
import { MultipleCodeinfoComponent } from './code-info/multiple-codeinfo/multiple-codeinfo.component';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { PdfViewerComponent } from './code-info/pdf-viewer/pdf-viewer.component';
import { NgKnifeModule } from 'ng-knife';
import { CptIndexSearchComponent } from './CPT/cpt-index-search/cpt-index-search.component';
import { Icd10cmIndexSearchComponent } from './ICD-CM/icd10cm-index-search/icd10cm-index-search.component';
import { HcpcsIndexsearchComponent } from './HCPCS/hcpcs-indexsearch/hcpcs-indexsearch.component';
import { AllModifierComponent } from './all-modifier/all-modifier.component';
import { CptSpecialtyNavigationComponent } from './CPT/cpt-specialty-navigation/cpt-specialty-navigation.component';
import { HcpcsSpecialtyNavigationComponent } from './HCPCS/hcpcs-specialty-navigation/hcpcs-specialty-navigation.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    SideNavComponent,
    HomeComponent,
    IndexSearchComponent,
    CodeResultsComponent,
    CodeInfoComponent,
    SearchbarComponent,
    LatestUpdatesComponent,
    DeletedCodesComponent,
    HCPCSDeletedCodesComponent,
    ClientmappingPipe,
    ColorCodesKeyPipe,
    CPTModifiersComponent,
    HCPCSModifiersComponent,
    DRGDialogComponent,
    CPTCMComponent,
    CPTPCSComponent,
    CPTHCPCSComponent,
    HCPCSCMComponent,
    AppLoaderComponent,
    AlertComponent,
    CciEditCheckerComponent,
    AutopopulatetextboxComponent,
    GlobalSurgeryDaysCalculatorComponent,
    TermSearchComponent,
    AutoTextboxComponent,
    Icd10cmDrugComponent,
    CptNewCodesComponent,
    HcpcsNewCodesComponent,
    IcdCmNewCodesComponent,
    IcdPcsNewCodesComponent,
    CptRevisedCodesComponent,
    HcpcsRevisedCodesComponent,
    IcdCmRevisedCodesComponent,
    IcdPcsRevisedCodesComponent,
    IcdCmDeletedCodesComponent,
    IcdPcsDeletedCodesComponent,
    RxhccComponent,
    HccEsrdComponent,
    MedAdvV22Component,
    MedAdvV24Component,    
    DrgCodesComponent, NeoplasmTableComponent, CptHcpcsRevenueComponent, 
    ExternalCausesComponent, HccTypeViewComponent, MultipleCodeinfoComponent, PdfViewerComponent, CptIndexSearchComponent, Icd10cmIndexSearchComponent, HcpcsIndexsearchComponent, AllModifierComponent, CptSpecialtyNavigationComponent, HcpcsSpecialtyNavigationComponent
  ],
  imports: [
    PdfViewerModule,
    HttpClientModule,
    BrowserModule,
    MatSnackBarModule,
    ReactiveFormsModule,
    AppRoutingModule,
    DxAutocompleteModule,
    DxTemplateModule,
    MatToolbarModule,
    MatListModule,
    NgxLoadingModule.forRoot({}),
    MatNativeDateModule,
    MatMenuModule,
    MatCardModule,
    FormsModule,
    MatInputModule,
    MatIconModule,
    MatSelectModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatRadioModule,
    MatExpansionModule,
    MatDatepickerModule,
    MatDividerModule,
    MatTableModule,
    MatPaginatorModule,
    MatSidenavModule,
    MDBBootstrapModule.forRoot(),
    BrowserAnimationsModule,
    MatSortModule,
    MatTreeModule,DxTextBoxModule,
    DxNumberBoxModule,
    DxDateBoxModule,DxSelectBoxModule,DxTextAreaModule,DxDataGridModule,DxButtonModule,
    NgMultiSelectDropDownModule.forRoot(),
    NgKnifeModule
  ],
  providers: [
    Service,HCPCSApiCall,LoaderServiceService,{provide:HTTP_INTERCEPTORS,useClass:Interceptor,multi:true}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

