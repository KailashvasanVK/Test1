import { Pipe, PipeTransform } from '@angular/core';
import { HCPCSApiCall } from './Services/HCPCSApiCall';
@Pipe({
  name: 'colorCodesKey'
})

export class ColorCodesKeyPipe implements PipeTransform {
  data: any;
  constructor(private service: HCPCSApiCall) {
}

  transform(value: any, codeType:string): string {
    if(codeType=='CPT' || codeType=='HCPCS') {

      if(value=='newCode'){
        return 'New Code';
      }
      else if(value=='revisedCode'){
        return 'Revised Code';
      }
      else if(value=='modifier51Exempt'){
        return 'Modifier 51 Exempt';
      }
      else if(value=='maleProcedure'){
        return 'Male Procedure';
      }
      else if(value=='femaleProcedure'){
        return 'Female Procedure';
      }
      else if(value=='unlistedCode'){
        return 'Unlisted Code';
      }
      else if(value=='ascPaymentIndicator'){
        return 'ASC Payment Indicator';
      }
      else if(value=='moderateSedation'){
        return 'Moderate Sedation';
      }
      else if(value=='medicalUnlikelyEdits'){ // for HCPCS
        return 'Medical Unlikely Edits';
      }
      else if(value=='reviseNoteNotBook'){ // for CPT
        return 'Medical Unlikely Edits';
      }
      else if(value=='ageRestrictions'){
        return 'Age Restrictions';
      }
      else if(value=='maternity'){
        return 'Maternity';
      }
      else if(value=='modifier63Exempt'){
        return 'Modifier 63 Exempt';
      }
      else if(value=='addOn'){
        return 'Add On';
      }
      else if(value=='serviceNotCoveredByMedicare'){
        return 'Service Not Covered By Medicare';
      }
      else if(value=='opsiCode'){
        return 'OPSI Code';
      }
      else if(value=='coSurgeryAllowed'){
        return 'Co-Surgery Allowed';
      }
      else if(value=='assistAtSurgeryAllowedWithDocumentation'){
        return 'Assist At Surgery Allowed With Documentation';
      }
      else if(value=='assistAtSurgeryAllowed'){
        return 'Assist At Surgery Allowed';
      }
      else if(value=='cliaWavedTest'){
        return 'CLIA Waved Test';
      }
      else if(value=='carrierPriced'){
        return 'Carrier Priced';
      }
      else if(value=='teamSurgeryAllowed'){
        return 'Team Surgery Allowed';
      }
      else if(value=='mulitplePxReductionGuidelinesApply'){
        return 'Mulitple Px Reduction Guidelines Apply';
      }
      else if(value=='endoscopicMulitplePxGuidelinesApply'){
        return 'Endoscopic Multiple Px Guidelines Apply';
      }
      else if(value=='bilateralSurgeryAllowed'){
        return 'Bilateral Surgery Allowed';
      }
      else if(value=='stvxPackaged'){
        return 'STVX Packaged';
      }
      else if(value=='bloodAndBloodProducts'){
        return 'Blood and Blood Products';
      }
      else if(value=='tpackaged'){
        return 'T Packaged';
      }
      else if(value=='brachytherapySources'){
        return 'Brachytherapy Sources';
      }
      else if(value=='mayBePaidThroughCompositeApc'){
        return 'May Be Paid Through Composite APC';
      }
      else if(value=='contractorDiscretion'){
        return 'Contractor Discretion';
      }
      else if(value=='notCoveredOrValidForMedicare'){
        return 'Not Covered Or Valid For Medicare';
      }
      else if(value=='quantityAlert'){
        return 'Quantity Alert';
      }
      else if(value=='specialCoverageInstructions'){
        return 'Special Coverage Instructions';
      }
      else if(value=='digitRequired4th'){
        return 'Digit Required 4th';
      }
      else if(value=='digitRequired5th'){
        return 'Digit Required 5th';
      }
      else if(value=='maleDiagnosis'){
        return 'Male Diagnosis';
      }
      else if(value=='femaleDiagnosis'){
        return 'Female Diagnosis';
      }
      else if(value=='unspecifiedDiagnosisCode'){
        return 'Unspecified Diagnosis Code';
      }
      else if(value=='otherSpecifiedDiagnosisCode'){
        return 'Other Specified Diagnosis Code';
      }
      else if(value=='adultDiagnosis'){
        return 'Adult Diagnosis';
      }
      else if(value=='maternityDiagnosis'){
        return 'Maternity Diagnosis';
      }
      else if(value=='newbornDiagnosis'){
        return 'Newborn Diagnosis';
      }
      else if(value=='pediatricDiagnosis'){
        return 'Pediatric Diagnosis';
      }
      else if(value=='hivRelated'){
        return 'HIV Related';
      }
      else if(value=='duplicatePrimaryDx'){
        return 'Duplicate Primary Dx';
      }
      else if(value=='vCodeAsPrimaryDx'){
        return 'V Code As Primary Dx';
      }
      else if(value=='unacceptablePrincipalDx'){
        return 'Unacceptable Principal Dx';
      }
      else if(value=='manifestationCodeNotAPrimaryDx'){
        return 'Manifestation Code Not A Primary Dx';
      }
      else if(value=='comorbidityOrComplication'){
        return 'Comorbidity Or Complication';
      }
      else if(value=='majorComplication'){
        return 'Major Complication';
      }
      else if(value=='revisedcodeNoteNotAmaBook'){
        return 'Revised code Note Not AMA Book';
      }
      else if(value=='newcptcodeNotAmaBook'){
        return 'New CPT code Not AMA Book';
      }
      else if(value=='modifier95'){
        return 'Modifier 95';
      }
      else{
        return '';
      }
    }
    if(codeType=='ICD-CM'){
      if(value=='newCode'){
        return 'New Code';
      }
      else if(value=='revisedCode'){
        return 'Revised Code';
      }
      else if(value=='characterRequired4Th'){
        return 'Character Required 4th';
      }
      else if(value=='characterRequired5Th'){
        return 'Character Required 5th';
      }
      else if(value=='characterRequired6Th'){
        return 'Character Required 6th';
      }
      else if(value=='characterRequired7Th'){
        return 'Character Required 7th';
      }
      else if(value=='characterRequiredX7Th'){
        return 'Character Required X7th';
      }
      else if(value=='maleDiagnosis'){
        return 'Male Diagnosis';
      }
      else if(value=='femaleDiagnosis'){
        return 'Female Diagnosis';
      }
      else if(value=='unspecifiedDiagnosisCode'){
        return 'Unspecified Diagnosis Code';
      }
      else if(value=='otherSpecifiedDiagnosisCode'){
        return 'Other Specified Diagnosis Code';
      }
      else if(value=='adultDiagnosis'){
        return 'Adult Diagnosis';
      }
      else if(value=='maternityDiagnosis'){
        return 'Maternity Diagnosis';
      }
      else if(value=='newbornDiagnosis'){
        return 'Newborn Diagnosis';
      }
      else if(value=='pediatricDiagnosis'){
        return 'Pediatric Diagnosis';
      }
      else if(value=='hivRelated'){
        return 'HIV Related';
      }
      else if(value=='unacceptablePrincipalDx'){
        return 'Unacceptable Principal Dx';
      }
      else if(value=='manifestationCodeNotAPrimaryDx'){
        return 'Manifestation Code Not A Primary Dx';
      }
      else if(value=='comorbidityOrComplication'){
        return 'Comorbidity Or Complication';
      }
      else if(value=='majorComplication'){
        return 'Major Complication';
      }
      else if(value=='zCodeIndicator'){
        return 'Z Code Indicator';
      }
      else if(value=='questionablePdx'){
        return 'Questionable Pdx';
      }
      else if(value=='hospitalAcquiredCondition'){
        return 'Hospital Acquired Condition';
      }
      else if(value=='conditionalHospitalAcquiredCondition'){
        return 'Conditional Hospital Acquired Condition';
      }
      else{
        return '';
      }
    }
  }

} 
