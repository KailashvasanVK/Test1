import { ClientmappingPipe } from './clientmapping.pipe';

describe('ClientmappingPipe', () => {
  it('create an instance', () => {
    const pipe = new ClientmappingPipe();
    expect(pipe).toBeTruthy();
  });
});
