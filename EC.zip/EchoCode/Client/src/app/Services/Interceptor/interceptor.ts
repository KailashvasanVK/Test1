import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, observable, Subscription } from 'rxjs';
import { LoaderServiceService } from '../loaderService.service';

@Injectable({
  providedIn: 'root'
})
export class Interceptor implements HttpInterceptor {
  private requests: HttpRequest<any>[] = [];

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    this.requests.push(req);
    if(req.url.includes("Codes/Getallcodes?Code"))
      {
      this.loaderService.setLoading(false);
      }else{
        this.loaderService.setLoading(true);
      }
    return Observable.create(x => {
      const subscription = next.handle(req)
      .subscribe( event => {
        if (event instanceof HttpResponse) {
          this.removeRequest(req);
          x.next(event);
        }
      }, err => {
        this.removeRequest(req);
        x.error(err);
      },
       () => {
        this.removeRequest(req);
        x.complete();
       });

      return () => {
        this.removeRequest(req);
        subscription.unsubscribe();
    };
    });
  }

  removeRequest(req: HttpRequest<any>) {
    const i = this.requests.indexOf(req);
    if (i >= 0) {
        this.requests.splice(i, 1);
    }
    this.loaderService.setLoading(this.requests.length > 0);
  }
  constructor(private loaderService: LoaderServiceService) { }
}
