
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable,Subject } from 'rxjs';
import * as types from '../models/CodeSearch';
import {environment} from 'src/environments/environment';


@Injectable()
export class Service {
    // private httpOptions = {
    //     headers: new HttpHeaders({  
    //         "Content-Type": "application/json;"
    //     }),withCredentials: true
    //   };

    private subject = new Subject<any>();
    
        sendMessage(data) {
            this.subject.next(data);
        }
        getMessage(): Observable<any> {
            return this.subject.asObservable();
        }
    apiUrl = environment.apiUrl;
    constructor(private http: HttpClient) { }
    getAllCodes(Code): Observable<any[]> {
         return this.http.get<any[]>(this.apiUrl + '/Codes/Getallcodes?Code=' + Code, { withCredentials: true })
    }
    getUserName(): Observable<any[]> {
        return this.http.get<any[]>(this.apiUrl + '/Codes/GetUserName', { withCredentials: true })
    }
    getdatabycode(Code): Observable<any[]> {
        return this.http.get<any[]>(this.apiUrl + '/Codes/GetDataByCode?Code=' + Code, { withCredentials: true })
    }
    GetDeletedCode(Code): Observable<any[]> {
        return this.http.get<any[]>(this.apiUrl + '/CPT/GetCptDeletedCodes?Code=' + Code, { withCredentials: true })
    }
    GetAllDeletedCode(): Observable<any[]> {
        return this.http.get<any[]>(this.apiUrl + '/CPT/GetAllCPTDeletedCode', { withCredentials: true })
    }    
    GetAllModifierCodeLink(CodeType): Observable<any[]> {
        return this.http.get<any[]>(this.apiUrl + '/CPT/GetAllCPTModifierCodeLink?CodeType='+CodeType, { withCredentials: true })
    }
    GetAllowModifier_p(Code,CodeType): Observable<any[]> {    
        return this.http.get<any[]>(this.apiUrl + '/CPT/GetAllowModifierdataP?Code='+Code+'&CodeType='+CodeType, { withCredentials: true })
    }
    GetCrossWalkData(Code,CodeType,alpha): Observable<any[]> {        
        return this.http.get<any[]>(this.apiUrl + '/CPT/GetCrossWalkData?Code='+Code+'&CodeType='+CodeType+'&Alpha='+alpha, { withCredentials: true })
    }
    GetAllowModifier_ASP(Code,CodeType): Observable<any[]> {        
            return this.http.get<any[]>(this.apiUrl + '/CPT/GetAllowModifierdataASP?Code='+Code+'&CodeType='+CodeType, { withCredentials: true })
        }
    GetModifierCode(Code,CodeType): Observable<any[]> {
        return this.http.get<any[]>(this.apiUrl + '/CPT/GetAllCPTModifierCode?Code=' + Code+'&CodeType='+CodeType, { withCredentials: true })
    }
    GetAllDeletedHCPCSCode(): Observable<any[]> {
        return this.http.get<any[]>(this.apiUrl + '/HCPCS/GetAllHCPCSDeletedCode', { withCredentials: true })
    }
    DeleteFavCode(Code): Observable<any[]> {
        return this.http.get<any[]>(this.apiUrl + '/Codes/DeleteFavCode?Code=' + Code, { withCredentials: true })
    }
    getFavoritedata(): Observable<any[]> {
        return this.http.get<any[]>(this.apiUrl + '/Codes/GetFavoriteData', { withCredentials: true })
    }
    addFavoritCode(FavoriteCode: types.FavoriteCode): Observable<any[]> {
        let  headers  =  new  HttpHeaders();
        headers  =  headers.set('Content-Type',  'text/plain');
        return this.http.post<any[]>(this.apiUrl + '/Codes/SaveFavoriteCode',JSON.stringify(FavoriteCode), {withCredentials:true })
    }
    SaveNotes(Notes: types.Notes): Observable<any[]> {
        let  headers  =  new  HttpHeaders();
        headers  =  headers.set('Content-Type',  'text/plain');
        return this.http.post<any[]>(this.apiUrl + '/Codes/SaveNotes',JSON.stringify(Notes), {withCredentials:true })
    }
}