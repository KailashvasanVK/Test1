import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoaderServiceService {
  loading = new BehaviorSubject<boolean>(false);
  loadingtemp = this.loading.asObservable();
  constructor() { }

  setLoading(value: boolean) {
    this.loading.next(value);
  }
}