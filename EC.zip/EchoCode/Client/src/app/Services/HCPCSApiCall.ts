import { Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as Model from '../models/HCPCS_Code';
import {environment} from 'src/environments/environment';
import { BehaviorSubject } from 'rxjs'; 
import { DomSanitizer } from '@angular/platform-browser';
import { map, filter, switchMap } from 'rxjs/operators';

const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type':  'application/json',
      'Authorization': 'Basic ' + btoa('Access_Heatlh_1:1$ZSElNGJj')
    })
  };
  
@Injectable()
export class HCPCSApiCall {
    private index = new BehaviorSubject<any[]>([]);
    public todos = this.index.asObservable();

    private indexFromGlob = new BehaviorSubject<any[]>([]);
    public missingIndexFromGlob = this.indexFromGlob.asObservable();

    private missValule = new BehaviorSubject<string>('');
    public missingValue = this.missValule.asObservable();

    apiUrl = environment.apiUrl;
    
    constructor(private http: HttpClient, private sanitizer: DomSanitizer) { }

    getAllClientInfo(): Observable<any[]> {
      return this.http.get<any[]>(this.apiUrl + '/HCPCS/GetAllClientInfo', { withCredentials: true })
    }
    GetAllLatestUpdateData(): Observable<any[]> {
      return this.http.get<any[]>(this.apiUrl + '/HCPCS/GetLatestUpdateData', { withCredentials: true })
    }
    GetDRGData(Code,CodeType): Observable<any[]> {
      return this.http.get<any[]>(this.apiUrl + '/HCPCS/GetDRGCodeData?Code='+Code+'&CodeType='+CodeType, { withCredentials: true })
    }
    GetMethod(URL){
      return this.http.get<any[]>(this.apiUrl + URL, { withCredentials: true })
    } 
    GetMethod1(URL){
      const httpOptions1 = {
          'responseType'  : 'arraybuffer' as 'json',
          withCredentials: true
            //'responseType'  : 'blob' as 'json'        //This also worked
        };
      return this.http.get<any[]>(this.apiUrl + URL,httpOptions1)
    }
    AddLatestUpdate(LatestUpdate: Model.SaveLatestUpdate): Observable<any[]> {
        let  headers  =  new  HttpHeaders();  
        headers  =  headers.set('Content-Type',  'text/plain');
        return this.http.post<any[]>(this.apiUrl + '/HCPCS/AddLatestUpdate',JSON.stringify(LatestUpdate), {withCredentials:true })
    }

    setMissingIndex(missingIndex: any[]) {
        this.index.next(missingIndex);
    }

    getMissingIndex() {
      return this.todos;
    }

    setMissingIndexForGlob(indexFromGlob:any[]){
      this.indexFromGlob.next(indexFromGlob);
    }

    getMissingIndexFromGlob() {
      return this.missingIndexFromGlob;
    }

    setMissingString(missingString: string) {
      this.missValule.next(missingString);
    }
    getMissingString() {
      return this.missingValue;
    }
}