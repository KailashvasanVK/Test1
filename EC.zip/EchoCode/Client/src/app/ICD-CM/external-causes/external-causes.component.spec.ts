import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExternalCausesComponent } from './external-causes.component';

describe('ExternalCausesComponent', () => {
  let component: ExternalCausesComponent;
  let fixture: ComponentFixture<ExternalCausesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExternalCausesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExternalCausesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
