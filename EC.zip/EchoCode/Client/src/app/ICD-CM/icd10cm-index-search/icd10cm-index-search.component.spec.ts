import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Icd10cmIndexSearchComponent } from './icd10cm-index-search.component';

describe('Icd10cmIndexSearchComponent', () => {
  let component: Icd10cmIndexSearchComponent;
  let fixture: ComponentFixture<Icd10cmIndexSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Icd10cmIndexSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Icd10cmIndexSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
