import { Component, OnInit } from '@angular/core';
import{Service} from '../../Services/apicall';
import{HCPCSApiCall} from '../../Services/HCPCSApiCall';
import {MatSnackBar} from '@angular/material/snack-bar';
import {ActivatedRoute,Router} from '@angular/router';
import {FlatTreeControl} from '@angular/cdk/tree';
import {MatTreeFlatDataSource, MatTreeFlattener} from '@angular/material/tree';


@Component({
  selector: 'app-icd10cm-index-search',
  templateUrl: './icd10cm-index-search.component.html',
  styleUrls: ['./icd10cm-index-search.component.css']
})
export class Icd10cmIndexSearchComponent implements OnInit {
  apidata:any=[];
  seedata:any;
  cpitreedata:any=[]; 
  data=true; 
  alphabets = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
  private _transformer = (node: any, level: number) => {
    
    return {
      expandable: !!node.node && node.node.length > 0,
      name:node.term,
      code:node.code,
      seedata:node.seedata,
      level: level,
    };
  
  }
  
  treeControl = new FlatTreeControl<any>(
      node => node.level, node => node.expandable);
  
  treeFlattener = new MatTreeFlattener(
      this._transformer, node => node.level, node => node.expandable, node => node.node);
  
  CPTdataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
  
  hasChild = (_: number, node: any) => node.expandable;
  
  constructor( private route: ActivatedRoute,private Hcpcscallservice:HCPCSApiCall,private service:Service,private snackBar:MatSnackBar,private router:Router) { }

  ngOnInit() {    
    this.route.queryParams.subscribe(params => {
      if (params != undefined) {
      }
    });
  }
  alphabetsclick(data)
  {
    
    this.cpitreedata=[];
    this.CPTdataSource.data=[];
    
    this.Hcpcscallservice.GetMethod('/HCC/GetIndexSearchData?Code=' + data + '&CodeType=icd10cm').subscribe(
      (res: any) => {        
        this.apidata=JSON.parse(res)["indexSearchResult"];
        for(let i=0;i<=this.apidata.length-1;i++){          
          this.apidata[i].node=[];
          
          if(this.apidata[i].level != 1)
            {      
              if(this.apidata[i].level > this.apidata[i-1].level && this.apidata[i].level -1 == this.apidata[i-1].level){
                   this.apidata[i-1].node.push(this.apidata[i]);                      
               }else{
                 this.dataarrange(i,i-1);
               }               
             }
        }     
        for(let i=0;i<=this.apidata.length-1;i++){          
          this.apidata[i].term=this.replaceAll(this.apidata[i].term.trim(),'<i>','');
          this.apidata[i].term=this.replaceAll(this.apidata[i].term.trim(),'</i>','');
          
           if(this.apidata[i].term.includes("See")){ 
            this.apidata[i].seedata=[]; 
            this.seedata=this.replaceAll(this.apidata[i].term.trim(),'See','');
            if(this.seedata.includes(","))
              {
                this.seedata=this.seedata.split(",")
                for(let f=0;f<this.seedata.length;f++){
                  if(f==this.seedata.length-1)
                    {
                      this.apidata[i].seedata.push(this.seedata[f]);
                    }else{

                      this.apidata[i].seedata.push(this.seedata[f]+',');
                    }
                }
              }else{
                this.apidata[i].seedata.push(this.seedata);
              }
          }
          if(this.apidata[i].level ==1)
            {
              this.apidata[i].term=this.replaceAll(this.apidata[i].term.trim(),'<b>','');
              this.apidata[i].term=this.replaceAll(this.apidata[i].term.trim(),'</b>','');              
              this.cpitreedata.push(this.apidata[i])
            }
        }   
        this.data=false;             
        this.Codelink();        
      },
      error => { }
    )
  }
  seedataclick(data){
    data=data.replace(',','');
    this.alphabetsclick(data.trim());
  }
  Codeclick(ret){
    ret=ret.replace('-','').trim();
    ret=ret.replace('[','').trim();
    ret=ret.replace(']','').trim();
    ret=ret.replace(',','').trim();
    this.router.navigate(["/codeinfo"],{ queryParams: { Code:ret,CodeType:'cpt'} });
  }
  Codelink(){      
    let data;
    let count;
    let clonecpitreedata=[];
    let length;
    clonecpitreedata=JSON.parse(JSON.stringify(this.cpitreedata))
    for(let i=0;i<this.cpitreedata.length;i++){
      if(this.cpitreedata[i].codes != undefined){
        this.cpitreedata[i].code=[];
        this.cpitreedata[i].codes=this.replaceAll(this.cpitreedata[i].codes.trim(),'-',',');
        if(this.cpitreedata[i].codes.includes(','))
          {
            data=this.cpitreedata[i].codes.split(',')
            count=data.length-1;
            for(let j=0;j<data.length;j++){
              if(data.length <= 1)
                {                 
                  this.cpitreedata[i].code.push(data[j].trim());
                }else{  
                  clonecpitreedata[i].codes=this.replaceAll(clonecpitreedata[i].codes," ","");
                  if(clonecpitreedata[i].codes.lastIndexOf(data[j]) != 0){
                    if(clonecpitreedata[i].codes[clonecpitreedata[i].codes.lastIndexOf(data[j])-1] == '-'){
                      if(data[j-1] != undefined)                    
                      this.cpitreedata[i].code.push(data[j-1].trim()+"-");                      
                    }
                    else{  
                      if(data[j-1] != undefined)                   
                      this.cpitreedata[i].code.push(data[j-1].trim()+",");                      
                    }  
                    if(j==data.length-1){  
                      if(data[j] != undefined)                  
                      this.cpitreedata[i].code.push(data[j].trim());
                    }                  
                  }                     
                }
            }            
          }else
          {
           this.cpitreedata[i].code.push(this.cpitreedata[i].codes);
          }
      }
    }    
    
    this.CPTdataSource.data=this.cpitreedata; 
  }
  replaceAll(string, search, replace) {
    return string.split(search).join(replace);
  }
  dataarrange(i,j){    
    if(this.apidata[i].level > this.apidata[j-1].level && this.apidata[i].level - 1 == this.apidata[j-1].level){
      this.apidata[j-1].node.push(this.apidata[i]);                      
  }else{
    this.dataarrange(i,j-1);
  }
}
icdcmIndexSearch(data:any){
    if(data[0].STATUS == 'D'){
      this.service.GetDeletedCode(data[0].CODE).subscribe(
        res =>{
          let RedirectValue;
          if(data[0].BASE_CODE_TYPE == 'CPT')
            {
              RedirectValue="/DeletedCodes";
            }
            else if(data[0].BASE_CODE_TYPE == 'HCPCS')
            {
              RedirectValue="/HcpcsDeletedCode";
            }
            else if(data[0].BASE_CODE_TYPE == 'ICD-CM')
            {
              RedirectValue="/Icd10CmDeletedCodes";
            }
            else if(data[0].BASE_CODE_TYPE == 'ICD-PCS')
            {
              RedirectValue="/Icd10PcsDeletedCodes";
            }
          this.router.navigate([RedirectValue],{queryParams: { Code: data[0].CODE}})
        },
        error => { 
        }  
      )
    }
    else{
      this.router.navigate(["/codeinfo"],{ queryParams: { Code:data[0].CODE} });
    }
  }
}
