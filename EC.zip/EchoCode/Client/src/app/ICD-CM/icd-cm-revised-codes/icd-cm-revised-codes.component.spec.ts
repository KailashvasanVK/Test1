import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IcdCmRevisedCodesComponent } from './icd-cm-revised-codes.component';

describe('IcdCmRevisedCodesComponent', () => {
  let component: IcdCmRevisedCodesComponent;
  let fixture: ComponentFixture<IcdCmRevisedCodesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IcdCmRevisedCodesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IcdCmRevisedCodesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
