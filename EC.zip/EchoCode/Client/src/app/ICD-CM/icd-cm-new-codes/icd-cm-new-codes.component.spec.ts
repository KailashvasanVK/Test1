import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IcdCmNewCodesComponent } from './icd-cm-new-codes.component';

describe('IcdCmNewCodesComponent', () => {
  let component: IcdCmNewCodesComponent;
  let fixture: ComponentFixture<IcdCmNewCodesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IcdCmNewCodesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IcdCmNewCodesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
