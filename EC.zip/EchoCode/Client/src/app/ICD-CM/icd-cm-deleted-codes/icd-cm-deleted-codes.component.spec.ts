import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IcdCmDeletedCodesComponent } from './icd-cm-deleted-codes.component';

describe('IcdCmDeletedCodesComponent', () => {
  let component: IcdCmDeletedCodesComponent;
  let fixture: ComponentFixture<IcdCmDeletedCodesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IcdCmDeletedCodesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IcdCmDeletedCodesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
