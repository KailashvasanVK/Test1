import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Service } from '../../Services/apicall';
import { Router, ActivatedRoute } from '@angular/router';
import { HCPCSApiCall } from '../../Services/HCPCSApiCall';

@Component({
  selector: 'app-icd-cm-deleted-codes',
  templateUrl: './icd-cm-deleted-codes.component.html',
  styleUrls: ['./icd-cm-deleted-codes.component.css']
})
export class IcdCmDeletedCodesComponent implements OnInit {

  constructor(private service: Service, private HCPCSService: HCPCSApiCall, private router: Router, private route: ActivatedRoute) { }
  
  IcdCmDeletedCodesData:any;
  codeType:string;
  focusedRowKey:any;
  autoNavigateToFocusedRow = true;

  ngOnInit() {
    this.GetDeletedIcdCmCodes();
    this.codeType="ICD-10-CM";
    this.route.queryParams.subscribe(params => {
      if (params != undefined) {
        this.focusedRowKey = params.Code;
      };
    });
  }

  icd10CmDeletedCodes(data: any) {
    if (data[0].STATUS == 'D') {
      if(data[0].BASE_CODE_TYPE == 'CPT')
        {
          this.router.navigate(["/DeletedCodes"],{queryParams: { Code: data[0].CODE}});
        }else if(data[0].BASE_CODE_TYPE == 'HCPCS')
        {
          this.router.navigate(["/HcpcsDeletedCode"],{queryParams: { Code: data[0].CODE}});
        }else if(data[0].BASE_CODE_TYPE == 'ICD-CM')
        {
          this.focusedRowKey=data[0].CODE;
        }else if(data[0].BASE_CODE_TYPE == 'ICD-PCS')
        {
          this.router.navigate(["/Icd10PcsDeletedCodes"],{queryParams: { Code: data[0].CODE}})
        }
    } else {
      this.router.navigate(["/codeinfo"], { queryParams: { Code: data[0].CODE } });
    }
  }
  GetDeletedIcdCmCodes() {
    this.HCPCSService.GetMethod('/RevisedCodes/GetAllIcdCmDeletedCode').subscribe(
      (res: any) => {
        this.IcdCmDeletedCodesData = res;
      },
      error => { }
    )
  }

}
