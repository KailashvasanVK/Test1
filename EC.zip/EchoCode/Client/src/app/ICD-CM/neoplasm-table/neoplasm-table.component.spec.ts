import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NeoplasmTableComponent } from './neoplasm-table.component';

describe('NeoplasmTableComponent', () => {
  let component: NeoplasmTableComponent;
  let fixture: ComponentFixture<NeoplasmTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NeoplasmTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NeoplasmTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
