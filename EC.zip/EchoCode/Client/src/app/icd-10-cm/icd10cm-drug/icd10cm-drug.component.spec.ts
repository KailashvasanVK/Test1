import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Icd10cmDrugComponent } from './icd10cm-drug.component';

describe('Icd10cmDrugComponent', () => {
  let component: Icd10cmDrugComponent;
  let fixture: ComponentFixture<Icd10cmDrugComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Icd10cmDrugComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Icd10cmDrugComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
