import { Component, OnInit } from '@angular/core';
import { Service } from '../../Services/apicall';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import xml2js from 'xml2js';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-icd10cm-drug',
  templateUrl: './icd10cm-drug.component.html',
  styleUrls: ['./icd10cm-drug.component.css']
})
export class Icd10cmDrugComponent implements OnInit {
  alphabets = [];
  xmlItems: any;
  griddataheading: any = [];
  griddatacell: any = [];
  griddatarightcell: any = [];
  clonegrid = [];
  linecount = 1;
  line: any = '';
  txtDrug: any;
  alpha: any;
  noDatafound:boolean;
  dataNotFound:string;
  constructor(private _http: HttpClient, private service: Service, private snackBar: MatSnackBar, private router: Router) { }

  ngOnInit() {
    this.alphabets = [];
    this.XMLRead();
    this.noDatafound=false;
    this.dataNotFound="No Data found";
  }
  icd10cmdrug(data: any) {
    if (data[0].STATUS == 'D') {
      let RedirectValue;
      if (data[0].BASE_CODE_TYPE == 'CPT') {
        RedirectValue = "/DeletedCodes";
      } else if (data[0].BASE_CODE_TYPE == 'HCPCS') {
        RedirectValue = "/HcpcsDeletedCode";
      } else if (data[0].BASE_CODE_TYPE == 'ICD-CM') {
        RedirectValue = "/Icd10CmDeletedCodes";
      } else if (data[0].BASE_CODE_TYPE == 'ICD-PCS') {
        RedirectValue = "/Icd10PcsDeletedCodes";
      }
      this.router.navigate([RedirectValue], { queryParams: { Code: data[0].CODE } })
    } else {
      this.router.navigate(["/codeinfo"], { queryParams: { Code: data[0].CODE } });
    }
  }
  XMLRead() {
    this._http.get('/assets/users.xml',
      {
        headers: new HttpHeaders()
          .set('Content-Type', 'text/xml')
          .append('Access-Control-Allow-Methods', 'GET')
          .append('Access-Control-Allow-Origin', '*')
          .append('Access-Control-Allow-Headers', "Access-Control-Allow-Headers, Access-Control-Allow-Origin, Access-Control-Request-Method"),
        responseType: 'text'
      })
      .subscribe((data) => {
        this.parseXML(data)
          .then((data) => {
            this.xmlItems = data;
          });
      });
  }
  parseXML(data) {
    var d = this;
    return new Promise(resolve => {
      var k: string | number,

        arr = [],
        parser = new xml2js.Parser(
          {
            trim: true,
            explicitArray: true
          });

      parser.parseString(data, function (err, result) {
        let count = result["ICD10CM.index"].letter.length;
        d.alphabets = [];
        for (let i = 0; i <= count - 1; i++) {
          d.alphabets.push(result["ICD10CM.index"].letter[i].title.toString());
        }
        resolve(result["ICD10CM.index"]);
      });
    });
  }
  loadTable(element) {
    this.line = '';
    for (let k = 0; k < this.linecount - 1; k++) {
      this.line = this.line + ' -- ';
    }
    this.griddatacell = [];
    if (element.title[0].nemod != undefined) {
      if (element.see != undefined) {
        this.griddatacell.push(this.line + element.title[0]._ + element.title[0].nemod + '( see - ' + element.see + ')')
      }
      else if (element.seeAlso != undefined) {
        this.griddatacell.push(this.line + element.title[0]._ + element.title[0].nemod + '( seeAlso - ' + element.seeAlso + ')')
      }
      else {
        this.griddatacell.push(this.line + element.title[0]._ + element.title[0].nemod);
      }

    }
    else {
      if (element.see != undefined) {
        this.griddatacell.push(this.line + element.title[0] + '( see - ' + element.see + ')')
      }
      else if (element.seeAlso != undefined) {
        this.griddatacell.push(this.line + element.title[0] + '( seeAlso - ' + element.seeAlso + ')')
      }
      else {
        this.griddatacell.push(this.line + element.title[0]);
      }
    }
    if (element.cell != undefined) {
      element.cell.forEach(element1 => {
        this.griddatacell.push(element1._)
      });
      if (this.griddatacell.length != 7) {
        for (let r = this.griddatacell.length; r <= 6; r++) {
          this.griddatacell.push('')
        }
      }
      this.griddatarightcell.push(this.griddatacell);
    } else {
      for (let j = 0; j <= 5; j++) {
        this.griddatacell.push('');
      }
      this.griddatarightcell.push(this.griddatacell);
    }
  }

  alldataread() {
    let headercount = this.xmlItems.indexHeading[0].head.length;
    for (let i = 0; i <= headercount - 1; i++) {
      this.griddataheading.push(this.xmlItems.indexHeading[0].head[i]._);
    }
    for (let i = 0; i <= this.xmlItems.letter.length - 1; i++) {
      let b = this.xmlItems.letter[i];
      b.mainTerm.forEach((element) => {
        this.griddatacell = [];
        if (element.cell != undefined) {
          this.linecount = 0;
          this.loadTable(element)
        } else if (element.title[0].nemod != undefined) {
          if (element.see != undefined) {
            this.griddatacell.push(this.line + element.title[0]._ + element.title[0].nemod + '( see - ' + element.see + ')')
          }
          else if (element.seeAlso != undefined) {
            this.griddatacell.push(this.line + element.title[0]._ + element.title[0].nemod + '( seeAlso - ' + element.seeAlso + ')')
          }
          else {
            this.griddatacell.push(this.line + element.title[0]._ + element.title[0].nemod);
          }

          for (let j = 0; j <= 5; j++) {
            this.griddatacell.push('');
          }
          this.griddatarightcell.push(this.griddatacell);
        }
        else {
          if (element.see != undefined) {
            this.griddatacell.push(this.line + element.title[0] + '( see - ' + element.see + ')')
          }
          else if (element.seeAlso != undefined) {
            this.griddatacell.push(this.line + element.title[0] + '( seeAlso - ' + element.seeAlso + ')')
          }
          else {
            this.griddatacell.push(this.line + element.title[0]);
          }

          for (let j = 0; j <= 5; j++) {
            this.griddatacell.push('');
          }
          this.griddatarightcell.push(this.griddatacell);
        }

        if (element.term != undefined) {
          element.term.forEach((element2) => {
            this.linecount = 2;
            this.loadTable(element2);
            this.checkterm(element2);
          });
        }
      });
    }
    let currentvalue;
    let beforevalue;
    for (let k = 0; k <= this.griddatarightcell.length - 1; k++) {
      if (this.griddatarightcell[k][0].includes("--")) {
        currentvalue = this.griddatarightcell[k][0].split("--").length - 1;
        for (let g = k; g >= 0; g--) {
          beforevalue = this.griddatarightcell[g - 1][0].split("--").length - 1;
          if (currentvalue > beforevalue) {
            this.griddatarightcell[k].push(g - 1);
            break;
          }
        }
      } else {
        this.griddatarightcell[k].push(k);
      }
    }
    this.clonegrid = JSON.parse(JSON.stringify(this.griddatarightcell))
  }
  alphabetsclick(res) {

    this.alpha = res;
    this.griddataheading = [];
    this.griddatacell = [];
    this.griddatarightcell = [];
    let headercount = this.xmlItems.indexHeading[0].head.length;
    for (let i = 0; i <= headercount - 1; i++) {
      this.griddataheading.push(this.xmlItems.indexHeading[0].head[i]._);
    }
    let b = this.xmlItems.letter.find(t => t.title == res)
    b.mainTerm.forEach(element => {
      this.griddatacell = [];
      if (element.cell != undefined) {
        this.linecount = 0;
        this.loadTable(element)
      } else if (element.title[0].nemod != undefined) {

        if (element.see != undefined) {
          this.griddatacell.push(this.line + element.title[0]._ + element.title[0].nemod + '( see - ' + element.see + ')')
        }
        else if (element.seeAlso != undefined) {
          this.griddatacell.push(this.line + element.title[0]._ + element.title[0].nemod + '( seeAlso - ' + element.seeAlso + ')')
        }
        else {
          this.griddatacell.push(this.line + element.title[0]._ + element.title[0].nemod);
        }

        for (let j = 0; j <= 5; j++) {
          this.griddatacell.push('');
        }
        this.griddatarightcell.push(this.griddatacell);
      }
      else {
        if (element.see != undefined) {
          this.griddatacell.push(this.line + element.title[0] + '( see - ' + element.see + ')')
        }
        else if (element.seeAlso != undefined) {
          this.griddatacell.push(this.line + element.title[0] + '( seeAlso - ' + element.seeAlso + ')')
        }
        else {
          this.griddatacell.push(this.line + element.title[0]);
        }
        for (let j = 0; j <= 5; j++) {
          this.griddatacell.push('');
        }
        this.griddatarightcell.push(this.griddatacell);
      }

      if (element.term != undefined) {
        element.term.forEach(element2 => {
          this.linecount = 2;
          this.loadTable(element2);
          this.checkterm(element2);
        });
      }
    });

  }

  checkterm(data) {
    if (data.term != undefined) {
      this.linecount++;
      let termcount = data.term.length;
      for (let i = 0; i <= termcount - 1; i++) {
        this.loadTable(data.term[i]);
        if (data.term[i].term != undefined) {
          this.checkterm(data.term[i])
        }
      }

      this.linecount--;
    }
  }
  Cellclick(res) {
    this.service.getdatabycode(res).subscribe(
      data => {
        if (data.length > 0) {
          if (data[0].STATUS == 'D') {
            let RedirectValue;
            if (data[0].BASE_CODE_TYPE == 'CPT') {
              RedirectValue = "/DeletedCodes";
            } else if (data[0].BASE_CODE_TYPE == 'HCPCS') {
              RedirectValue = "/HcpcsDeletedCode";
            } else if (data[0].BASE_CODE_TYPE == 'ICD-CM') {
              RedirectValue = "/Icd10CmDeletedCodes";
            } else if (data[0].BASE_CODE_TYPE == 'ICD-PCS') {
              RedirectValue = "/Icd10PcsDeletedCodes";
            }
            this.router.navigate([RedirectValue], { queryParams: { Code: data[0].CODE } })
          } else {
            this.router.navigate(["/codeinfo"], { queryParams: { Code: data[0].CODE } });
          }
        }
      },
      error => { }
    )


  }

  Searchclick() {

    if (this.txtDrug != undefined && this.txtDrug != '') {

      this.griddataheading = [];
      this.griddatarightcell = [];
      this.clonegrid = [];
      this.alldataread();


      for (let b = 0; b <= this.clonegrid.length - 1; b++) {
        this.clonegrid[b][0] = this.replaceAll(this.clonegrid[b][0].trim(), "--", '').trim();
      }

      let indexvalue = [];
      let dataresult = [];
      dataresult = this.clonegrid.filter(t => t[0].toLowerCase().startsWith(this.txtDrug.toLowerCase()));
      for (let m = 0; m <= dataresult.length - 1; m++) {
        if (this.griddatarightcell[dataresult[m][7]] == dataresult[m][7]) {
          if (!indexvalue.includes(dataresult[m][7]))
            indexvalue.push(dataresult[m][7]);
        } else {
          if (!this.griddatarightcell[dataresult[m][7]][0].trim().startsWith('-')) {
            if (!indexvalue.includes(this.griddatarightcell[dataresult[m][7]][7]))
              indexvalue.push(this.griddatarightcell[dataresult[m][7]][7]);
          }
        }
      }
      dataresult = [];
      for (let n = 0; n <= indexvalue.length - 1; n++) {
        dataresult.push(this.griddatarightcell[indexvalue[n]]);
      }

      let datatable = JSON.parse(JSON.stringify(this.griddatarightcell));
      this.griddatarightcell = [];
      for (let i = 0; i <= dataresult.length - 1; i++) {
        this.griddatarightcell.push(dataresult[i]);
        for (let j = 0; j <= datatable.length - 1; j++) {
          if (datatable[j][0].toString().startsWith(dataresult[i][0])) {
            for (let k = j + 1; k <= datatable.length - 1; k++) {
              if (datatable[k][0].trim().startsWith('-')) {

                this.griddatarightcell.push(datatable[k]);

              } else {
                break;
              }
            }
          }
        }
      }

      for (let k = 0; k <= this.griddatarightcell.length - 1; k++) {
        this.griddatarightcell[k].pop();
      }
      if(this.griddatarightcell.length==0){
        this.noDatafound=true;
      }
    }
  }
  replaceAll(string, search, replace) {
    return string.split(search).join(replace);
  }

}
