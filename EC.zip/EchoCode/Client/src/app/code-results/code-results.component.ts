import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-code-results',
  templateUrl: './code-results.component.html',
  styleUrls: ['./code-results.component.css']
})
export class CodeResultsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
