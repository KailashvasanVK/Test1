export interface PeriodicElement {
    name: string;
    position: number;
    weight: number;
    symbol: string;
  }
  export interface topping {
    value: string;
    viewValue: string;
  } 
export class FavoriteCode{
  Code:string;
  Code_Type:string;
  Login_Id:string;
}
export class Notes{
  Code:string;
  CodeNotes:string;
  Login_Id:string;
}
export class CodeInfo{  
CODE :string;
BASE_CODE_TYPE:string;
SHORT_DESCRIPTION:string;
LONG_DESCRIPTION:string;
FULL_DESCRIPTION:string;
PREVIOUS_VALUE:string;
NEXT_VALUE:string;
NOTES:string;
STATUS:string;
X_CODE_TYPE1_COUNT:number;
X_CODE_TYPE2_COUNT:number;
X_CODE_TYPE3_COUNT:number;
X_CODE_TYPE1:string;
X_CODE_TYPE2:string;
X_CODE_TYPE3:string;
MIPS:string;
}
export class DeletedCodes{
  CODE :string;
  BASE_CODE_TYPE:string;
  FULL_DESCRIPTION:string;
  DELETE_DATE:string;
  STATUS:string;
}

export enum ApiCodeTypes {
  CPT = "cpt",
  HCPCS = "hcpcs",
  ICD10CM = "icd10cm",
  ICD10PCS = "icd10pcs"
}