export class HCPCS_DeletedCodes{
    HCPCS_CODE :string;
    FULL_DESCRIPTION:string;
    DELETED_DATE:string;
    SUBSTITUTION_CODE:string;
    }

    export class Client_Info{
        CLIENT_ID:number;
        CLIENT_NAME:string;
    }
    export class SaveLatestUpdate{
        NewsID:number;
        Client_Id:number;
        News:string;
        UserName:string;
        Status:string;
    }
    export class LatestUpdateInfo{
        ClientName :string;
        News:string;
    }