import { Component, OnInit ,EventEmitter,HostListener,Output, Input} from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import {ActivatedRoute,Router} from '@angular/router';
import{ HCPCSApiCall } from '../Services/HCPCSApiCall';

@Component({
  selector: 'app-autopopulatetextbox',
  templateUrl: './autopopulatetextbox.component.html',
  styleUrls: ['./autopopulatetextbox.component.css']
})

export class AutopopulatetextboxComponent implements OnInit {

  dynamicForm: FormGroup;
  codes:any;
  NoOfCodes:any;
  DataCodes=[];
  NF:any="1";
  nocodes:any=10;
  invalidCodesIndex=[];
  invalidCodes:string;
  submitted=false;
  minLength:boolean=false;
  filteredArray=new Array<number>(1000);
  notNullArray:any;

  @Output() Codesdata: EventEmitter<any> = new EventEmitter();

  constructor(private formBuilder: FormBuilder,private route:ActivatedRoute,private router :Router,private Hcpcscallservice:HCPCSApiCall) { 
    this.invalidCodesIndex=[];
    this.Hcpcscallservice.getMissingIndex().subscribe(data => {
      this.invalidCodesIndex=data;
    })
    this.Hcpcscallservice.getMissingString().subscribe(data => {
      this.invalidCodes=data;
    })
  }

  @HostListener('window:load', ['$event']) onload($event){
    this.router.navigate(['/CCIEDITCHECK'])
  }

  ngOnInit() {  
    this.codes='';
    this.submitted=false; 
    this.invalidCodes='';
    this.invalidCodesIndex=[];
    this.minLength=false;
    this.notNullArray='';
    this.route.queryParams.subscribe(params => {
      if(Object.keys(params).length != 0) { 
        this.DataCodes=params.CodesDetails;
        this.NF=params.RadioCheck;               
      }
    })
    this.NoOfCodes=[10,11,12,13,14,15,16]
      this.dynamicForm = this.formBuilder.group({          
          tickets: new FormArray([])
      });
      const numberOfTickets = 10 || 0;
      if (this.t.length < numberOfTickets) {
          for (let i = this.t.length; i < numberOfTickets; i++) {
              this.t.push(this.formBuilder.group({
                  name: [this.DataCodes[i]],                  
              }));
          }
      } else {
          for (let i = this.t.length; i >= numberOfTickets; i--) {
              this.t.removeAt(i);
          }
      }
      if(this.DataCodes){
      this.onSubmit();
      }
  } 
  
  // convenience getters for easy access to form fields
  get f() { return this.dynamicForm.controls; }
  get t() { return this.f.tickets as FormArray; }

  onChangeTickets(e) {
    const numberOfTickets = e.target.value || 0;
      if (this.t.length < numberOfTickets) {
          for (let i = this.t.length; i < numberOfTickets; i++) {
              this.t.push(this.formBuilder.group({
                  name: ['', Validators.required],                  
              }));
          }
      } else {
          for (let i = this.t.length; i >= numberOfTickets; i--) {
              this.t.removeAt(i);
          }
      }
  }
  ClearClick(){  
    this.submitted=false;
    this.dynamicForm.reset();
    this.invalidCodes='';
    this.invalidCodesIndex=[];
    this.minLength=false;
    this.notNullArray='';
    this.codes=''; 
  }
  onSubmit() {    
    this.invalidCodesIndex=[];
    let array1=[];
    let OutputCodes:any;
    this.submitted = true;
    this.notNullArray='';
    var formLength = this.dynamicForm.value.tickets.length;
    for(var i=0;i<formLength;i++){
      if(this.dynamicForm.value.tickets[i].name==""){
        this.dynamicForm.value.tickets[i].name="null";
      }
      else if(this.dynamicForm.value.tickets[i].name){
        this.dynamicForm.value.tickets[i].name = this.dynamicForm.value.tickets[i].name.toUpperCase();
      }
    }
    let data = JSON.parse(JSON.stringify(this.dynamicForm.value, null, 4)).tickets;
    this.codes='';    
    for(let i=0;i<this.t.length;i++)
      {  
        this.codes=this.codes+data[i].name + ','; 
        if(data[i].name!=undefined){
           this.notNullArray = this.notNullArray+data[i].name.toUpperCase() + ',';  
        }
      }
      if(this.notNullArray){
        array1=this.notNullArray.split(',');
        this.filteredArray = array1.filter(notEmpty);
      }
      function notEmpty(value) {
        return value !== "null" && value !== "";
      }
    if(this.filteredArray.length<2){
      this.minLength=true;
    }
    else{
      this.Codesdata.emit(this.codes +";"+this.NF);
    }
  }   
}
