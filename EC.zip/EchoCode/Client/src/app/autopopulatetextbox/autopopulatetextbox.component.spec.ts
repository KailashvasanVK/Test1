import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AutopopulatetextboxComponent } from './autopopulatetextbox.component';

describe('AutopopulatetextboxComponent', () => {
  let component: AutopopulatetextboxComponent;
  let fixture: ComponentFixture<AutopopulatetextboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AutopopulatetextboxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AutopopulatetextboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
