import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { IndexSearchComponent } from './index-search/index-search.component';
import { CodeResultsComponent } from './code-results/code-results.component';
import { CodeInfoComponent } from './code-info/code-info.component';
import { LatestUpdatesComponent } from './latest-updates/latest-updates.component';
import { DeletedCodesComponent } from './deleted-codes/deleted-codes.component';
import { HCPCSDeletedCodesComponent } from './hcpcs-deleted-codes/hcpcs-deleted-codes.component';
import { CPTModifiersComponent } from './cpt-modifiers/cpt-modifiers.component';
import { HCPCSModifiersComponent } from './hcpcs-modifiers/hcpcs-modifiers.component';
import { DRGDialogComponent } from './code-info/drg-dialog/drg-dialog.component';
import { CPTCMComponent } from './Cross_Reference/cpt-cm/cpt-cm.component';
import { CPTHCPCSComponent } from './Cross_Reference/cpt-hcpcs/cpt-hcpcs.component';
import { CPTPCSComponent } from './Cross_Reference/cpt-pcs/cpt-pcs.component';
import { HCPCSCMComponent } from './Cross_Reference/hcpcs-cm/hcpcs-cm.component';
import { AlertComponent } from './alert/alert.component';
import { CciEditCheckerComponent } from './cci-edit-checker/cci-edit-checker.component';
import { TermSearchComponent } from './term-search/term-search.component';
import { GlobalSurgeryDaysCalculatorComponent } from './global-surgery-days-calculator/global-surgery-days-calculator.component';
import { Icd10cmDrugComponent } from './icd-10-cm/icd10cm-drug/icd10cm-drug.component';
import { CptNewCodesComponent } from './CPT/cpt-new-codes/cpt-new-codes.component'
import { CptRevisedCodesComponent} from './CPT/cpt-revised-codes/cpt-revised-codes.component'
import { HcpcsNewCodesComponent } from './HCPCS/hcpcs-new-codes/hcpcs-new-codes.component'
import { HcpcsRevisedCodesComponent} from './HCPCS/hcpcs-revised-codes/hcpcs-revised-codes.component'
import { IcdCmNewCodesComponent } from './ICD-CM/icd-cm-new-codes/icd-cm-new-codes.component'
import { IcdCmRevisedCodesComponent } from './ICD-CM/icd-cm-revised-codes/icd-cm-revised-codes.component'
import { IcdPcsNewCodesComponent } from './ICD-PCS/icd-pcs-new-codes/icd-pcs-new-codes.component'
import { IcdPcsRevisedCodesComponent } from './ICD-PCS/icd-pcs-revised-codes/icd-pcs-revised-codes.component'
import { IcdCmDeletedCodesComponent } from './ICD-CM/icd-cm-deleted-codes/icd-cm-deleted-codes.component';
import { IcdPcsDeletedCodesComponent } from './ICD-PCS/icd-pcs-deleted-codes/icd-pcs-deleted-codes.component';
import { RxhccComponent } from './HCC/rxhcc/rxhcc.component';
import { HccEsrdComponent } from './HCC/hcc-esrd/hcc-esrd.component';
import { MedAdvV22Component } from './HCC/med-adv-v22/med-adv-v22.component';
import { MedAdvV24Component } from './HCC/med-adv-v24/med-adv-v24.component';
import{DrgCodesComponent} from './drg-codes/drg-codes.component';
import{NeoplasmTableComponent} from './ICD-CM/neoplasm-table/neoplasm-table.component';
import { CptHcpcsRevenueComponent } from './Cross_Reference/cpt-hcpcs-revenue/cpt-hcpcs-revenue.component';
import{ExternalCausesComponent} from './ICD-CM/external-causes/external-causes.component';
import{HccTypeViewComponent}from './HCC/hcc-type-view/hcc-type-view.component';
import{MultipleCodeinfoComponent}from './code-info/multiple-codeinfo/multiple-codeinfo.component';
import{PdfViewerComponent}from './code-info/pdf-viewer/pdf-viewer.component';
import{CptIndexSearchComponent} from './CPT/cpt-index-search/cpt-index-search.component';
import{Icd10cmIndexSearchComponent} from './ICD-CM/icd10cm-index-search/icd10cm-index-search.component';
import{HcpcsIndexsearchComponent}from './HCPCS/hcpcs-indexsearch/hcpcs-indexsearch.component';
import{AllModifierComponent} from './all-modifier/all-modifier.component';
import{CptSpecialtyNavigationComponent} from './CPT/cpt-specialty-navigation/cpt-specialty-navigation.component';
import{HcpcsSpecialtyNavigationComponent} from './HCPCS/hcpcs-specialty-navigation/hcpcs-specialty-navigation.component';



const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'indexsearch', component: IndexSearchComponent },
  { path: 'home', component: HomeComponent }, 
  { path:'cptspecnav',component:CptSpecialtyNavigationComponent},
  {path:'hcpcsspecnav',component:HcpcsSpecialtyNavigationComponent},
  { path: 'codeinfo', component: CodeInfoComponent },
  { path: 'coderesults', component: CodeResultsComponent },
  { path: 'latestupdate', component: LatestUpdatesComponent },
  { path: 'DeletedCodes', component: DeletedCodesComponent },
  { path: 'HcpcsDeletedCode', component: HCPCSDeletedCodesComponent },
  { path: 'CptModifiers', component: CPTModifiersComponent },
  { path: 'HCPCSModifiers', component: HCPCSModifiersComponent },
  { path: 'DRGDialog', component: DRGDialogComponent },
  { path: 'AlertDialog', component: AlertComponent },
  { path: 'CPTCM', component: CPTCMComponent },
  { path: 'HCPCSCM', component: HCPCSCMComponent },
  { path: 'CPTPCS', component: CPTPCSComponent },
  { path: 'CPTHCPCS', component: CPTHCPCSComponent },
  { path: 'CCIEDITCHECK', component: CciEditCheckerComponent },
  { path: 'TermSearch', component: TermSearchComponent },
  { path: 'GlobalCalc', component: GlobalSurgeryDaysCalculatorComponent },
  { path: 'Icd10CmDrug', component: Icd10cmDrugComponent },
  { path: 'CptNewCodes', component: CptNewCodesComponent },
  { path: 'CptRevisedCodes', component: CptRevisedCodesComponent},
  { path: 'HcpcsNewCodes', component: HcpcsNewCodesComponent },
  { path: 'HcpcsRevisedCodes', component: HcpcsRevisedCodesComponent },
  { path: 'IcdCmNewCodes', component: IcdCmNewCodesComponent },
  { path: 'IcdCmRevisedCodes', component: IcdCmRevisedCodesComponent }, 
  { path: 'Icd10CmDeletedCodes', component: IcdCmDeletedCodesComponent },
  { path: 'IcdPcsNewCodes', component: IcdPcsNewCodesComponent },
  { path: 'IcdPcsRevisedCodes', component: IcdPcsRevisedCodesComponent },
  { path: 'Icd10PcsDeletedCodes', component: IcdPcsDeletedCodesComponent},
  { path: 'HccRxhcc', component: RxhccComponent},
  { path: 'HccEsrd', component: HccEsrdComponent},
  { path: 'HccMedicareV22', component: MedAdvV22Component},
  { path: 'HccMedicareV24', component: MedAdvV24Component},
  {path: 'Icd10PcsDeletedCodes', component: IcdPcsDeletedCodesComponent},
  {path:'DrgCodes',component:DrgCodesComponent},
  {path:'Neoplasmtable',component:NeoplasmTableComponent},
  {path:'ExternalCauses',component:ExternalCausesComponent},
  {path:'CPTHCPCSRevenue', component: CptHcpcsRevenueComponent},
  {path:'HccTypeView',component:HccTypeViewComponent},
  {path:'MultipleCode',component:MultipleCodeinfoComponent},
  {path:'pdfview',component:PdfViewerComponent},
  {path:'CptIndexSearch',component:CptIndexSearchComponent},
  {path:'icdcmindexsearch',component:Icd10cmIndexSearchComponent},
  {path:'hcpcsindexsearch',component:HcpcsIndexsearchComponent},
  {path:'allmodifier',component:AllModifierComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
