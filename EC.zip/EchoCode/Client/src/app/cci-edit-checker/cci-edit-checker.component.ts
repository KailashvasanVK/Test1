import { Component, OnInit } from '@angular/core';
import{Service} from '../Services/apicall';
import {ActivatedRoute,Router} from '@angular/router';
import{HCPCSApiCall} from '../Services/HCPCSApiCall';


@Component({
  selector: 'app-cci-edit-checker',
  templateUrl: './cci-edit-checker.component.html',
  styleUrls: ['./cci-edit-checker.component.css']
})
export class CciEditCheckerComponent implements OnInit {
  NoOfCodes:any;
  CodesCount=[];
  CCIEditCheckDtl:any;
  Modifier_p:any;
  Modifier_ASP:any;
  DefaultText=false;
  indexList=[];
  missingString:string;
  constructor(private service:Service,private router:Router,private Hcpcscallservice:HCPCSApiCall) { }

  ngOnInit() {
    
  }
  EditCheckData(data:any){
    if(data[0].STATUS == 'D'){
      this.service.GetDeletedCode(data[0].CODE).subscribe(
        res =>{
          let RedirectValue;
          if(data[0].BASE_CODE_TYPE == 'CPT')
            {
              RedirectValue="/DeletedCodes";
            }else if(data[0].BASE_CODE_TYPE == 'HCPCS')
            {
              RedirectValue="/HcpcsDeletedCode";
            }else if(data[0].BASE_CODE_TYPE == 'ICD-CM')
            {
              RedirectValue="/Icd10CmDeletedCodes";
            }else if(data[0].BASE_CODE_TYPE == 'ICD-PCS')
            {
              RedirectValue="/Icd10PcsDeletedCodes";
            }
          this.router.navigate([RedirectValue],{queryParams: { Code: data[0].CODE}})
        },
        error => { }  
      )
    }else{
      this.router.navigate(["/codeinfo"],{ queryParams: { Code:data[0].CODE} });
    }
  }
  // CodeChanged(CodeCount){
  //   this.DefaultText=true;
  //   this.CodesCount=[];
  //   let i=1;
  //   while(i <= CodeCount.value){
  //     this.CodesCount.push(i);
  //     i++;
  //   }       
  // }
  redirectCodeinfo(data){
    this.service.getdatabycode(data).subscribe(
      res =>{
        if (res.length == 1){        
          this.router.navigate(["/codeinfo"],{ queryParams: { Code:res[0].CODE} });
        }else if(res.length >1){
          this.router.navigate(["/MultipleCode"],{queryParams:{code:data}})
        }
      },
      error => { }  
    )

  }
  arraylist:any=[];
  duplicatedata:any=[];
  CCICheckClick(OutputCodes:any){
    let value='';
    let array1=[];
    let resList=[];
    this.indexList=[];
    let filteredArray=[];
    let resultValue:any='';
    let missingIndex:any='';
    let datavalue:any=[];
    let link:any='';
    let missing=[];
    value=OutputCodes.split(";")[1];
    OutputCodes=OutputCodes.split(";")[0];
    array1 = OutputCodes.split(',');
    
    
    filteredArray = array1.filter(notEmpty);
    function notEmpty(value) {
      return value !== "";
    }

    if(value == "2")
      {
        link='/HCPCS/GetFaclityEditCheck?Code='+OutputCodes;
      }else if(value == "1"){
        link='/HCPCS/GetNonFaclityEditCheck?Code='+OutputCodes
      }

     this.Hcpcscallservice.GetMethod(link).subscribe(
      (res:any) =>{    
        let numOfTrue;       
        this.CCIEditCheckDtl=res;
        this.duplicatedata=JSON.parse(JSON.stringify(this.CCIEditCheckDtl));
        for(let r=0;r<this.duplicatedata.length;r++){         
         if(r!=0){
           if(this.arraylist.includes(this.duplicatedata[r].COLUMN_2)){  
             datavalue.push(this.duplicatedata.splice(r,1));               
           }
         }
         this.arraylist.push(this.CCIEditCheckDtl[r].COLUMN_2)
        }
        let source:any=[];
        for(let j=0;j<datavalue.length;j++){
          for(let k=0;k<this.duplicatedata.length;k++){
          if(datavalue[j][0].COLUMN_2 == this.duplicatedata[k].COLUMN_2){
            this.duplicatedata[k].data=[];
            source.MODIFIER=datavalue[j][0].MODIFIER;
            source.PTP_EDIT_RATIONALE=datavalue[j][0].PTP_EDIT_RATIONALE;  
            source.DESCRIPTION=datavalue[j][0].DESCRIPTION;
            this.duplicatedata[k].data.push(source);
          }         
        }
        }
        

        console.log(this.duplicatedata);
        let resultValue;
        let resList=[];
        
        
        if(Object.keys(this.CCIEditCheckDtl).length>0){
          this.CCIEditCheckDtl.map((obj, i) => {
            resultValue = obj.COLUMN_2;
            resList.push(resultValue);
        });
        }
      for(let i=0; i<filteredArray.length; i++){
        if(filteredArray[i]!="null"){
          if(!resList.includes(filteredArray[i])){
             this.indexList.push(i);
          }
        }
      }
      this.missingString = missing.toString();

      if(this.indexList.length>0){
        this.Hcpcscallservice.setMissingIndex(this.indexList);
      }
      
      if(this.missingString.length>0){
        this.Hcpcscallservice.setMissingString(this.missingString);
      }
      },
      error => { }  
    )
  }
  LoadModifier_P(Code,CodeType){  
    
      this.service.GetAllowModifier_p(Code,CodeType).subscribe(
        res =>{
          this.Modifier_p=res;
        },
        error => { }  
      )
    
  }
  LoadModifier_ASP(Code,CodeType){  
    
      this.service.GetAllowModifier_ASP(Code,CodeType).subscribe(
        res =>{
          this.Modifier_ASP=res;
        },
        error => { }  
      )
    
  }
}
