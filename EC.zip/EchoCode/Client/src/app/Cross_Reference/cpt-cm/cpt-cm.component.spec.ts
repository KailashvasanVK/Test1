import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CPTCMComponent } from './cpt-cm.component';

describe('CPTCMComponent', () => {
  let component: CPTCMComponent;
  let fixture: ComponentFixture<CPTCMComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CPTCMComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CPTCMComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
