import { Component, OnInit } from '@angular/core';
import{Service} from '../../Services/apicall';
import{HCPCSApiCall}from '../../Services/HCPCSApiCall';
import {MatSnackBar,MatDialog} from '@angular/material';
import {ActivatedRoute,Router} from '@angular/router';
import{DRGDialogComponent} from '../../code-info/drg-dialog/drg-dialog.component';

@Component({
  selector: 'app-cpt-cm',
  templateUrl: './cpt-cm.component.html',
  styleUrls: ['./cpt-cm.component.css']
})
export class CPTCMComponent implements OnInit {

  constructor(private service:Service,public dialog: MatDialog,private service1:HCPCSApiCall ,private snackBar:MatSnackBar,private router:Router) { }
  CPTCodevisible=true;
  ICDCMCodevisible=true;
  allCPTCodes:any;
  allICDCMCodes:any;
  ICDCMCodes:any;
  CPTCodes:any;
  CPTCodeList:any;
  CPTcode:any;
  ICDCMCode:any;
  ICDCMCodeList:any;
  ngOnInit() {
    this.service1.GetMethod('/HCPCS/GetCPTCodeList').subscribe(
      res =>{
        this.allCPTCodes=res;
      },
      error => { }  
    )
    this.service1.GetMethod('/HCPCS/GetICDCMCodeList').subscribe(
      res =>{
        this.allICDCMCodes=res;
      },
      error => { }  
    )
  }
  DRGClick(Code){
    this.dialog.open(DRGDialogComponent,{
  width:'50%',
  data:Code +'-'+'ICDCM'
});
 }
  CPTCMCross(data:any){
    if(data[0].STATUS == 'D'){
      this.service.GetDeletedCode(data[0].CODE).subscribe(
        res =>{
          let RedirectValue;
          if(data[0].BASE_CODE_TYPE == 'CPT')
            {
              RedirectValue="/DeletedCodes";
            }else if(data[0].BASE_CODE_TYPE == 'HCPCS')
            {
              RedirectValue="/HcpcsDeletedCode";
            }else if(data[0].BASE_CODE_TYPE == 'ICD-CM')
            {
              RedirectValue="/Icd10CmDeletedCodes";
            }else if(data[0].BASE_CODE_TYPE == 'ICD-PCS')
            {
              RedirectValue="/Icd10PcsDeletedCodes";
            }
          this.router.navigate([RedirectValue],{queryParams: { Code: data[0].CODE}})
        },
        error => { }  
      )
    }else{
      this.router.navigate(["/codeinfo"],{ queryParams: { Code:data[0].CODE} });
    }
  }
  redirectCodeinfo(data,CodeType){
    this.service.getdatabycode(data).subscribe(
      res =>{
        
        if (res.length == 1){        
          this.router.navigate(["/codeinfo"],{ queryParams: { Code:res[0].CODE} });
        }else if(res.length >1){
          let codedata;
          for(let i=0;i<=res.length-1;i++)
            {
              if(res[i].BASE_CODE_TYPE == CodeType){
                codedata =res[i];
              }
            }
            this.router.navigate(["/codeinfo"],{ queryParams: { Code:codedata.CODE,CodeType:codedata.BASE_CODE_TYPE} });
        }
      },
      error => { }  
    )

  }
  alphadata:any=[];
  CPTCodeChanged(alpha){
    if(alpha == undefined){
      alpha='NO';
    }
    this.ICDCMCode=null;
    if(this.allCPTCodes.find(X =>X.CODE===this.CPTcode) != undefined){
    this.service.GetCrossWalkData(this.CPTcode,'ICDCM',alpha).subscribe(
      res =>{
        this.CPTCodevisible=false;
        this.ICDCMCodevisible=true;
        this.CPTCodeList=res;
        if(this.alphadata.length ==0)
          {
        let data= this.CPTCodeList[0].STARTINDEXES.split(',');
       for(let i=0;i<data.length;i++){
         this.alphadata.push(data[i]);
       }
      }
      },
      error => { }  
    )
  }else{
    this.snackBar.open('Code Not in List!!!!','OK',{
      duration:3000,
      verticalPosition: 'top'                   
    }); 
    this.CPTCodevisible=true;
    this.ICDCMCodevisible=true;
  }
  }
  ICDCMCodeChanged(){
    this.CPTcode=null;
    if(this.allICDCMCodes.find(X =>X.CODE===this.ICDCMCode) != undefined){
    this.service.GetCrossWalkData(this.ICDCMCode,'CPT','NO').subscribe(
      res =>{
        this.CPTCodevisible=true;
        this.ICDCMCodevisible=false;
        this.ICDCMCodeList=res;
      },
      error => { }  
    )
  }else{
    this.snackBar.open('Code Not in List!!!!','OK',{
      duration:3000,
      verticalPosition: 'top'            
    });  
    this.CPTCodevisible=true;
    this.ICDCMCodevisible=true;
  }
  }
  CPTCodevalueChanged(data){ 
    
    if(data.value != null) {
      if(this.allCPTCodes != undefined)
        this.CPTCodes= this.allCPTCodes.filter(t => t.CODE.toLowerCase().includes(data.value.toLowerCase()))
    } 
  }
  ICDCMCodevalueChanged(data){ 
    
    if(data.value != null) {
      if(this.allICDCMCodes != undefined)
        this.ICDCMCodes= this.allICDCMCodes.filter(t => t.CODE.toLowerCase().includes(data.value.toLowerCase()))
    } 
  }
}
