import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CptHcpcsRevenueComponent } from './cpt-hcpcs-revenue.component';

describe('CptHcpcsRevenueComponent', () => {
  let component: CptHcpcsRevenueComponent;
  let fixture: ComponentFixture<CptHcpcsRevenueComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CptHcpcsRevenueComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CptHcpcsRevenueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
