import { Component, OnInit } from '@angular/core';
import{Service} from '../../Services/apicall';
import{HCPCSApiCall}from '../../Services/HCPCSApiCall';
import {MatSnackBar,MatDialog} from '@angular/material';
import {ActivatedRoute,Router} from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-cpt-hcpcs-revenue',
  templateUrl: './cpt-hcpcs-revenue.component.html',
  styleUrls: ['./cpt-hcpcs-revenue.component.css']
})
export class CptHcpcsRevenueComponent implements OnInit {
  codeValues: any;
  RevenueDataSrc:any;
  output:any;
  enteredCode:any;
  drpDwnValue:string;
  selectedRadio:string="CptHcpcs";
  cptHcpcsDataSrc:any;
  distinctCptHcpcs:any;
  userForm = new FormGroup({
    searchBy: new FormControl(),
    enteredCode: new FormControl()
 }); 

  constructor(private service:Service, public dialog: MatDialog,
              private Hcpcscallservice: HCPCSApiCall, private snackBar:MatSnackBar, 
              private router:Router) { }

  ngOnInit() {
    this.codeValues = [
      { codeId: 'cpt', code: "CPT" },
      { codeId: 'hcpcs', code: "HCPCS" },
  ];
  this.drpDwnValue = this.codeValues[0].codeId;
  }
  CPTHCPCSToRevenueCross(data:any){
    if(data[0].STATUS == 'D'){
      let RedirectValue;
      if(data[0].BASE_CODE_TYPE == 'CPT')
        {
          RedirectValue="/DeletedCodes";
        }else if(data[0].BASE_CODE_TYPE == 'HCPCS')
        {
          RedirectValue="/HcpcsDeletedCode";
        }else if(data[0].BASE_CODE_TYPE == 'ICD-CM')
        {
          RedirectValue="/Icd10CmDeletedCodes";
        }else if(data[0].BASE_CODE_TYPE == 'ICD-PCS')
        {
          RedirectValue="/Icd10PcsDeletedCodes";
        }
      this.router.navigate([RedirectValue],{queryParams: { Code: data[0].CODE}})
    }else{
      this.router.navigate(["/codeinfo"],{ queryParams: { Code:data[0].CODE} });
    }
  }
  onFormSubmit(){
    this.RevenueDataSrc='';
    this.output='';
    this.cptHcpcsDataSrc='';
    this.distinctCptHcpcs='';

   if(this.selectedRadio == 'CptHcpcs') {
     this.Hcpcscallservice.GetMethod('/HCPCS/GetCrossRevCode?Code=' + this.enteredCode + '&CodeType=' + this.drpDwnValue).subscribe(
      (res: any) => {
        this.RevenueDataSrc = JSON.parse(res);
        var resArr = [];
        this.RevenueDataSrc.item.forEach(function(item){
          var i = resArr.findIndex(x => x.revCode == item.revCode);
          if(i <= -1){
            resArr.push({revCode: item.revCode, revCodeDesc: item.revCodeDesc, 
                         tobFacilityCode: item.tobFacilityCode, tobFacilityCodeDesc: item.tobFacilityCodeDesc, 
                         note:item.note});
          }
        });
      this.output = resArr;
      },
      error => { }
    )
   }
   else {
     this.Hcpcscallservice.GetMethod('/HCPCS/GetCrossCptHcpcsCode?Code=' + this.enteredCode + '&CodeType=' + this.drpDwnValue).subscribe(
      (res: any) => {
        
        this.cptHcpcsDataSrc = JSON.parse(res);
        var cptArr = [];
        this.cptHcpcsDataSrc.item.forEach(function(item){
          var i = cptArr.findIndex(x => x.code == item.code);
          if(i <= -1){
            cptArr.push({code: item.code, desc: item.desc, 
                         tobFacilityCode: item.tobFacilityCode, tobFacilityCodeDesc: item.tobFacilityCodeDesc, 
                         note:item.note});
          }
          
        });
        this.distinctCptHcpcs = cptArr;
      },
      error => { }
    )
   }
  }
  redirectCodeinfo(data){          
      this.router.navigate(["/codeinfo"],{ queryParams: { Code:data} });
    }
  clearForm(){
    this.drpDwnValue = this.codeValues[0].codeId;
    this.selectedRadio="CptHcpcs";
    this.enteredCode='';
  }

}
