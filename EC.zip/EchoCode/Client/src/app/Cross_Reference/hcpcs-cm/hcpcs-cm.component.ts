import { Component, OnInit } from '@angular/core';
import{Service} from '../../Services/apicall';
import{HCPCSApiCall}from '../../Services/HCPCSApiCall';
import {MatSnackBar,MatDialog} from '@angular/material';
import {ActivatedRoute,Router} from '@angular/router';
import{DRGDialogComponent} from '../../code-info/drg-dialog/drg-dialog.component';

@Component({
  selector: 'app-hcpcs-cm',
  templateUrl: './hcpcs-cm.component.html',
  styleUrls: ['./hcpcs-cm.component.css']
})
export class HCPCSCMComponent implements OnInit {

  constructor(private service:Service,public dialog: MatDialog,private service1:HCPCSApiCall ,private snackBar:MatSnackBar,private router:Router) { }
  HCPCSCodevisible=true;
  ICDCMCodevisible=true;
  allHCPCSCodes:any;
  allICDCMCodes:any;
  ICDCMCodes:any;
  HCPCSCodes:any;
  HCPCSCodeList:any;
  HCPCScode:any;
  ICDCMcode:any;
  ICDCMCodeList:any;
  ngOnInit() {
    this.service1.GetMethod('/HCPCS/GetHCPCSCodeList').subscribe(
      res =>{
        this.allHCPCSCodes=res;
      },
      error => { }  
    )
    this.service1.GetMethod('/HCPCS/GetICDCMCodeList').subscribe(
      res =>{
        this.allICDCMCodes=res;
      },
      error => { }  
    )
  }
  DRGClick(Code){
    this.dialog.open(DRGDialogComponent,{
  width:'50%',
  data:Code +'-'+'ICDCM'
});
 }
 redirectCodeinfo(data,CodeType){
  this.service.getdatabycode(data).subscribe(
    res =>{
      
      if (res.length == 1){        
        this.router.navigate(["/codeinfo"],{ queryParams: { Code:res[0].CODE} });
      }else if(res.length >1){
        let codedata;
        for(let i=0;i<=res.length-1;i++)
          {
            if(res[i].BASE_CODE_TYPE == CodeType){
              codedata =res[i];
            }
          }
          this.router.navigate(["/codeinfo"],{ queryParams: { Code:codedata.CODE,CodeType:codedata.BASE_CODE_TYPE} });
      }
    },
    error => { }  
  )

}
  HCPCSCMCross(data:any){
    if(data[0].STATUS == 'D'){
      let RedirectValue;
      if(data[0].BASE_CODE_TYPE == 'CPT')
        {
          RedirectValue="/DeletedCodes";
        }else if(data[0].BASE_CODE_TYPE == 'HCPCS')
        {
          RedirectValue="/HcpcsDeletedCode";
        }else if(data[0].BASE_CODE_TYPE == 'ICD-CM')
        {
          RedirectValue="/Icd10CmDeletedCodes";
        }else if(data[0].BASE_CODE_TYPE == 'ICD-PCS')
        {
          RedirectValue="/Icd10PcsDeletedCodes";
        }
      this.router.navigate([RedirectValue],{queryParams: { Code: data[0].CODE}})
    }else{
      this.router.navigate(["/codeinfo"],{ queryParams: { Code:data[0].CODE} });
    }
  }
  alphadata:any=[];
  HCPCSCodeChanged(alpha){
    if(alpha == undefined){
      alpha='NO';
    }
    this.ICDCMcode=null;
    if(this.allHCPCSCodes.find(X =>X.CODE.toLowerCase()===this.HCPCScode.toLowerCase()) != undefined){ 
    this.service.GetCrossWalkData(this.HCPCScode,'ICDCM',alpha).subscribe(
      res =>{
        this.HCPCSCodevisible=false;
        this.ICDCMCodevisible=true;
        this.HCPCSCodeList=res;
        if(this.alphadata.length ==0)
          {
        let data= this.HCPCSCodeList[0].STARTINDEXES.split(',');
       for(let i=0;i<data.length;i++){
         this.alphadata.push(data[i]);
       }
      }
      },
      error => { }  
    )
  }else{
    this.snackBar.open('Code Not in List!!!!','OK',{
      duration:3000,
      verticalPosition: 'top'            
    });  
    this.HCPCSCodevisible=true;
    this.ICDCMCodevisible=true;
  }
  }
  ICDCMCodeChanged(){
    this.HCPCScode=null;
    if(this.allICDCMCodes.find(X =>X.CODE.toLowerCase()===this.ICDCMcode.toLowerCase()) != undefined){ 
    this.service.GetCrossWalkData(this.ICDCMcode,'HCPCS','NO').subscribe(
      res =>{
        this.HCPCSCodevisible=true;
        this.ICDCMCodevisible=false;
        this.ICDCMCodeList=res;
      },
      error => { }  
    )
  }else{
    this.snackBar.open('Code Not in List!!!!','OK',{
      duration:3000,
      verticalPosition: 'top'            
    });  
    this.HCPCSCodevisible=true;
    this.ICDCMCodevisible=true;
  }
  }
  HCPCSCodevalueChanged(data){ 
    
    if(data.value != null) {
      if(this.allHCPCSCodes != undefined)
        this.HCPCSCodes= this.allHCPCSCodes.filter(t => t.CODE.toLowerCase().includes(data.value.toLowerCase()))
    } 
  }
  ICDCMCodevalueChanged(data){ 
    
    if(data.value != null) {
      if(this.allICDCMCodes != undefined)
        this.ICDCMCodes= this.allICDCMCodes.filter(t => t.CODE.toLowerCase().includes(data.value.toLowerCase()))
    } 
  }
}

