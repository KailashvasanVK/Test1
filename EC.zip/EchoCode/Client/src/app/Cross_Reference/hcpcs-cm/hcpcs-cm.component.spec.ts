import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HCPCSCMComponent } from './hcpcs-cm.component';

describe('HCPCSCMComponent', () => {
  let component: HCPCSCMComponent;
  let fixture: ComponentFixture<HCPCSCMComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HCPCSCMComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HCPCSCMComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
