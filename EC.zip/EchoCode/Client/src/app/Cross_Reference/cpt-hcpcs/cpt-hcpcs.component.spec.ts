import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CPTHCPCSComponent } from './cpt-hcpcs.component';

describe('CPTHCPCSComponent', () => {
  let component: CPTHCPCSComponent;
  let fixture: ComponentFixture<CPTHCPCSComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CPTHCPCSComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CPTHCPCSComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
