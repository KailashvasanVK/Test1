import { Component, OnInit } from '@angular/core';
import{Service} from '../../Services/apicall';
import{HCPCSApiCall}from '../../Services/HCPCSApiCall';
import {MatSnackBar,MatDialog} from '@angular/material';
import {ActivatedRoute,Router} from '@angular/router';
import{DRGDialogComponent} from '../../code-info/drg-dialog/drg-dialog.component';

@Component({
  selector: 'app-cpt-hcpcs',
  templateUrl: './cpt-hcpcs.component.html',
  styleUrls: ['./cpt-hcpcs.component.css']
})
export class CPTHCPCSComponent implements OnInit {

  constructor(private service:Service,public dialog: MatDialog,private service1:HCPCSApiCall ,private snackBar:MatSnackBar,private router:Router) { }
  CPTCodevisible=true;
  HCPCSCodevisible=true;
  allCPTCodes:any;
  allHCPCSCodes:any;
  HCPCSCodes:any;
  CPTCodes:any;
  CPTCodeList:any;
  CPTcode:any;
  HCPCSCode:any;
  HCPCSCodeList:any;
  ngOnInit() {
    this.service1.GetMethod('/HCPCS/GetCPTCodeList').subscribe(
      res =>{
        this.allCPTCodes=res;
      },
      error => { }  
    )
    this.service1.GetMethod('/HCPCS/GetHCPCSCodeList').subscribe(
      res =>{
        this.allHCPCSCodes=res;
      },
      error => { }  
    )
  }
  DRGClick(Code){
    this.dialog.open(DRGDialogComponent,{
  width:'50%',
  data:Code +'-'+'ICDCM'
});
 }
 CPTHCPCSCross(data:any){
    if(data[0].STATUS == 'D'){
      let RedirectValue;
      if(data[0].BASE_CODE_TYPE == 'CPT')
        {
          RedirectValue="/DeletedCodes";
        }else if(data[0].BASE_CODE_TYPE == 'HCPCS')
        {
          RedirectValue="/HcpcsDeletedCode";
        }else if(data[0].BASE_CODE_TYPE == 'ICD-CM')
        {
          RedirectValue="/Icd10CmDeletedCodes";
        }else if(data[0].BASE_CODE_TYPE == 'ICD-PCS')
        {
          RedirectValue="/Icd10PcsDeletedCodes";
        }
      this.router.navigate([RedirectValue],{queryParams: { Code: data[0].CODE}})
    }else{
      this.router.navigate(["/codeinfo"],{ queryParams: { Code:data[0].CODE} });
    }
  }
  CPTCodeChanged(){
    this.HCPCSCode=null; 
    if(this.allCPTCodes.find(X =>X.CODE===this.CPTcode) != undefined){
    this.service.GetCrossWalkData(this.CPTcode,'HCPCS','NO').subscribe(
      res =>{
        this.CPTCodevisible=false;
        this.HCPCSCodevisible=true;
        this.CPTCodeList=res;
      },
      error => { }  
    )
  }else{
    this.snackBar.open('Code Not in List!!!!','OK',{
      duration:3000,
      verticalPosition: 'top'            
    });  
    this.CPTCodevisible=true;
    this.HCPCSCodevisible=true;
  }
  }
  HCPCSCodeChanged(){
    this.CPTcode=null;
    if(this.allHCPCSCodes.find(X =>X.CODE===this.HCPCSCode) != undefined){
    this.service.GetCrossWalkData(this.HCPCSCode,'CPT','NO').subscribe(
      res =>{
        this.CPTCodevisible=true;
        this.HCPCSCodevisible=false;
        this.HCPCSCodeList=res;
      },
      error => { }  
    )
  }else{
    this.snackBar.open('Code Not in List!!!!','OK',{
      duration:3000,
      verticalPosition: 'top'            
    });  
    this.CPTCodevisible=true;
    this.HCPCSCodevisible=true;
  }
  }
  redirectCodeinfo(data,CodeType){
    this.service.getdatabycode(data).subscribe(
      res =>{
        
        if (res.length == 1){        
          this.router.navigate(["/codeinfo"],{ queryParams: { Code:res[0].CODE} });
        }else if(res.length >1){
          let codedata;
          for(let i=0;i<=res.length-1;i++)
            {
              if(res[i].BASE_CODE_TYPE == CodeType){
                codedata =res[i];
              }
            }
            this.router.navigate(["/codeinfo"],{ queryParams: { Code:codedata.CODE,CodeType:codedata.BASE_CODE_TYPE} });
        }
      },
      error => { }  
    )

  }
  CPTCodevalueChanged(data){ 
       
    if(data.value != null) {
      if(this.allCPTCodes != undefined)
        this.CPTCodes= this.allCPTCodes.filter(t => t.CODE.toLowerCase().includes(data.value.toLowerCase()))
    } 
  }
  HCPCSCodevalueChanged(data){   
      
    if(data.value != null) {
      if(this.allHCPCSCodes != undefined)
        this.HCPCSCodes= this.allHCPCSCodes.filter(t => t.CODE.toLowerCase().includes(data.value.toLowerCase()))
    } 
  }

}
