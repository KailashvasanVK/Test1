import { Component, OnInit } from '@angular/core';
import{Service} from '../../Services/apicall';
import{HCPCSApiCall}from '../../Services/HCPCSApiCall';
import {MatSnackBar,MatDialog} from '@angular/material';
import {ActivatedRoute,Router} from '@angular/router';
import{DRGDialogComponent} from '../../code-info/drg-dialog/drg-dialog.component';

@Component({
  selector: 'app-cpt-pcs',
  templateUrl: './cpt-pcs.component.html',
  styleUrls: ['./cpt-pcs.component.css']
})
export class CPTPCSComponent implements OnInit {

  constructor(private service:Service,public dialog: MatDialog,private service1:HCPCSApiCall ,private snackBar:MatSnackBar,private router:Router) { }
  CPTCodevisible=true;
  PCSCodevisible=true;
  allCPTCodes:any;
  allPCSCodes:any;
  PCSCodes:any;
  CPTCodes:any;
  CPTCodeList:any;
  CPTcode:any;
  PCScode:any;
  PCSCodeList:any;
  ngOnInit() {
    this.service1.GetMethod('/HCPCS/GetCPTCodeList').subscribe(
      res =>{
        this.allCPTCodes=res;
      },
      error => { }  
    )
    this.service1.GetMethod('/HCPCS/GetPCDCodeList').subscribe(
      res =>{
        this.allPCSCodes=res;
      },
      error => { }  
    )
  }
  
 CPTPCSCross(data:any){
    if(data[0].STATUS == 'D'){
      let RedirectValue;
      if(data[0].BASE_CODE_TYPE == 'CPT')
        {
          RedirectValue="/DeletedCodes";
        }else if(data[0].BASE_CODE_TYPE == 'HCPCS')
        {
          RedirectValue="/HcpcsDeletedCode";
        }else if(data[0].BASE_CODE_TYPE == 'ICD-CM')
        {
          RedirectValue="/Icd10CmDeletedCodes";
        }else if(data[0].BASE_CODE_TYPE == 'ICD-PCS')
        {
          RedirectValue="/Icd10PcsDeletedCodes";
        }
      this.router.navigate([RedirectValue],{queryParams: { Code: data[0].CODE}})
    }else{
      this.router.navigate(["/codeinfo"],{ queryParams: { Code:data[0].CODE} });
    }
  }
  redirectCodeinfo(data,CodeType){
    this.service.getdatabycode(data).subscribe(
      res =>{
        
        if (res.length == 1){        
          this.router.navigate(["/codeinfo"],{ queryParams: { Code:res[0].CODE} });
        }else if(res.length >1){
          let codedata;
          for(let i=0;i<=res.length-1;i++)
            {
              if(res[i].BASE_CODE_TYPE == CodeType){
                codedata =res[i];
              }
            }
            this.router.navigate(["/codeinfo"],{ queryParams: { Code:codedata.CODE,CodeType:codedata.BASE_CODE_TYPE} });
        }
      },
      error => { }  
    )

  }
  CPTCodeChanged(){
    this.PCScode=null;
    if(this.allCPTCodes.find(X =>X.CODE===this.CPTcode) != undefined){  
    this.service.GetCrossWalkData(this.CPTcode,'ICDPCS','NO').subscribe(
      res =>{
        this.CPTCodevisible=false;
        this.PCSCodevisible=true;
        this.CPTCodeList=res;
      },
      error => { }  
    )
  }else{
    this.snackBar.open('Code Not in List!!!!','OK',{
      duration:3000,
      verticalPosition: 'top'            
    });  
    this.CPTCodevisible=true;
    this.PCSCodevisible=true;
  }
  }
  PCSCodeChanged(){
    this.CPTcode=null;
    if(this.allPCSCodes.find(X =>X.CODE===this.PCScode) != undefined){ 
    this.service.GetCrossWalkData(this.PCScode,'CPT','NO').subscribe(
      res =>{ 
        this.CPTCodevisible=true;
        this.PCSCodevisible=false;
        this.PCSCodeList=res;
      },
      error => { }  
    )
  }else{
    this.snackBar.open('Code Not in List!!!!','OK',{
      duration:3000,
      verticalPosition: 'top'            
    });  
    this.CPTCodevisible=true;
    this.PCSCodevisible=true;
  }
  }
  CPTCodevalueChanged(data){   
    
    if(data.value != null) {
      if(this.allCPTCodes != undefined)
        this.CPTCodes= this.allCPTCodes.filter(t => t.CODE.toLowerCase().includes(data.value.toLowerCase()))
    } 
  }
  PCSCodevalueChanged(data){  
       
    if(data.value != null) {
      if(this.allPCSCodes != undefined)
        this.PCSCodes= this.allPCSCodes.filter(t => t.CODE.toLowerCase().includes(data.value.toLowerCase()))
    } 
  }


}
