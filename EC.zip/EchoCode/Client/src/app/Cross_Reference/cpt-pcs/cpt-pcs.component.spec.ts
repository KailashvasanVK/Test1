import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CPTPCSComponent } from './cpt-pcs.component';

describe('CPTPCSComponent', () => {
  let component: CPTPCSComponent;
  let fixture: ComponentFixture<CPTPCSComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CPTPCSComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CPTPCSComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
