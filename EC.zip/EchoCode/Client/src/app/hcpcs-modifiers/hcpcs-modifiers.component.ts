import { Component, OnInit } from '@angular/core';
import{Service} from '../Services/apicall';
import{HCPCSApiCall} from '../Services/HCPCSApiCall';
import {MatSnackBar} from '@angular/material/snack-bar';
import {ActivatedRoute,Router} from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';  



@Component({
  selector: 'app-hcpcs-modifiers',
  templateUrl: './hcpcs-modifiers.component.html',
  styleUrls: ['./hcpcs-modifiers.component.css']
})
export class HCPCSModifiersComponent implements OnInit {

  ModifierCodevisible=true;
  Modifiervisible=false;
  ModifierCodelink:any;
  ModifierCode:any;
  HCPCSModifierHeading='HCPCS Modifiers';
  apidata:any;
  hidehcpcsback=true;  
  constructor(private _http:HttpClient,private service:Service,private service1:HCPCSApiCall,private snackBar:MatSnackBar,private router:Router) { }
  
  ngOnInit() {
    this.service.GetAllModifierCodeLink('HCPCS').subscribe(
      res =>{        
         this.ModifierCodelink=res;
      },
      error => { }  
    )   
    
  }
   HCPCSModifierBack(){
  this.HCPCSModifierHeading='HCPCS Modifiers';  
    this.Modifiervisible=false;
    this.ModifierCodevisible=true;
    this.hidehcpcsback=true;
     
  }
  ModifierCodeeve(data:any){
    if(data[0].STATUS == 'D'){
      let RedirectValue;
      if(data[0].BASE_CODE_TYPE == 'CPT')
        {
          RedirectValue="/DeletedCodes";
        }else if(data[0].BASE_CODE_TYPE == 'HCPCS')
        {
          RedirectValue="/HcpcsDeletedCode";
        }else if(data[0].BASE_CODE_TYPE == 'ICD-CM')
        {
          RedirectValue="/Icd10CmDeletedCodes";
        }else if(data[0].BASE_CODE_TYPE == 'ICD-PCS')
        {
          RedirectValue="/Icd10PcsDeletedCodes";
        }
      this.router.navigate([RedirectValue],{queryParams: { Code: data[0].CODE}})
    }else{
      this.router.navigate(["/codeinfo"], { queryParams: { Code: data[0].CODE} });
    }
  }
  redirectCodeinfo(data){
    this.service.getdatabycode(data).subscribe(
      res =>{
        
        if (res.length == 1){        
          this.router.navigate(["/codeinfo"],{ queryParams: { Code:res[0].CODE} });
        }else if(res.length >1){
          let codedata;
          for(let i=0;i<=res.length-1;i++)
            {
              if(res[i].BASE_CODE_TYPE == 'HCPCS'){
                codedata =res[i];
              }
            }
            this.router.navigate(["/codeinfo"],{ queryParams: { Code:codedata.CODE,CodeType:codedata.BASE_CODE_TYPE} });
        }
      },
      error => { }  
    )

  }
  
  GetModifierCode(data){
    this.HCPCSModifierHeading='Modifier Code for '+data;    
    this.service.GetModifierCode(data,'HCPCS').subscribe(
      res =>{
        if(res.length > 0){
          this.Modifiervisible=true;
          this.ModifierCodevisible=false;
         this.ModifierCode=res;
         this.hidehcpcsback=false;
         
        }else{
          this.ModifierCode=[];
          this.Modifiervisible=false;          
          this.ModifierCodevisible=true;
          this.hidehcpcsback=true;
          
          this.snackBar.open('No Data found!!','OK',{
            duration:3000,
            verticalPosition: 'top'            
          }); 
        }
      },
      error => { }  
    )
  }


}
