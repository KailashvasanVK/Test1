import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HCPCSModifiersComponent } from './hcpcs-modifiers.component';

describe('HCPCSModifiersComponent', () => {
  let component: HCPCSModifiersComponent;
  let fixture: ComponentFixture<HCPCSModifiersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HCPCSModifiersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HCPCSModifiersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
