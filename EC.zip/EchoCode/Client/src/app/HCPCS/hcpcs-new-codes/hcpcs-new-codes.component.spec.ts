import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HcpcsNewCodesComponent } from './hcpcs-new-codes.component';

describe('HcpcsNewCodesComponent', () => {
  let component: HcpcsNewCodesComponent;
  let fixture: ComponentFixture<HcpcsNewCodesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HcpcsNewCodesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HcpcsNewCodesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
