import { Component, OnInit } from '@angular/core';

import { Service } from '../../Services/apicall';
import { ActivatedRoute, Router } from '@angular/router';
import { SearchbarComponent } from "src/app/searchbar/searchbar.component";
import { HCPCSApiCall } from '../../Services/HCPCSApiCall';

@Component({
  selector: 'app-hcpcs-revised-codes',
  templateUrl: './hcpcs-revised-codes.component.html',
  styleUrls: ['./hcpcs-revised-codes.component.css']
})
export class HcpcsRevisedCodesComponent implements OnInit {

  constructor(private service: Service,private HCPCSService:HCPCSApiCall, private router: Router, private route: ActivatedRoute) { }
  HCPCSRevisedCodesData:any;
  ngOnInit() {
    this.getRevisedHcpcsCodes();
   }
   HcpcsRevisedCodes(data: any) {
    if (data[0].STATUS == 'D') {
      let RedirectValue;
      if(data[0].BASE_CODE_TYPE == 'CPT')
        {
          RedirectValue="/DeletedCodes";
        }else if(data[0].BASE_CODE_TYPE == 'HCPCS')
        {
          RedirectValue="/HcpcsDeletedCode";
        }else if(data[0].BASE_CODE_TYPE == 'ICD-CM')
        {
          RedirectValue="/Icd10CmDeletedCodes";
        }else if(data[0].BASE_CODE_TYPE == 'ICD-PCS')
        {
          RedirectValue="/Icd10PcsDeletedCodes";
        }
      this.router.navigate([RedirectValue],{queryParams: { Code: data[0].CODE}})
    } else {
      this.router.navigate(["/codeinfo"], { queryParams: { Code: data[0].CODE} });
    }
  }
  redirectCodeinfo(data){
    this.service.getdatabycode(data).subscribe(
      res =>{
        
        if (res.length == 1){        
          this.router.navigate(["/codeinfo"],{ queryParams: { Code:res[0].CODE} });
        }else if(res.length >1){
          let codedata;
          for(let i=0;i<=res.length-1;i++)
            {
              if(res[i].BASE_CODE_TYPE == 'HCPCS'){
                codedata =res[i];
              }
            }
            this.router.navigate(["/codeinfo"],{ queryParams: { Code:codedata.CODE,CodeType:codedata.BASE_CODE_TYPE} });
        }
      },
      error => { }  
    )

  }
  getRevisedHcpcsCodes(){
    this.HCPCSService.GetMethod('/RevisedCodes/GetRevisedCodes?CodeType=HCPCS').subscribe(
      (res:any) =>{      
         this.HCPCSRevisedCodesData=res;
      },
      error => { }  
    )
  }
}
