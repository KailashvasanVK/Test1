import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HcpcsRevisedCodesComponent } from './hcpcs-revised-codes.component';

describe('HcpcsRevisedCodesComponent', () => {
  let component: HcpcsRevisedCodesComponent;
  let fixture: ComponentFixture<HcpcsRevisedCodesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HcpcsRevisedCodesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HcpcsRevisedCodesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
