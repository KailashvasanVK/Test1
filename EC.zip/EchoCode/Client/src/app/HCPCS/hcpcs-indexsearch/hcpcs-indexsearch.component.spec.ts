import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HcpcsIndexsearchComponent } from './hcpcs-indexsearch.component';

describe('HcpcsIndexsearchComponent', () => {
  let component: HcpcsIndexsearchComponent;
  let fixture: ComponentFixture<HcpcsIndexsearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HcpcsIndexsearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HcpcsIndexsearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
