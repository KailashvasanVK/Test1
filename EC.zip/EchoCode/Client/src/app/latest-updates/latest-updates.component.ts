import { Component, OnInit } from '@angular/core';
import * as model from '../models/HCPCS_Code';
import {HCPCSApiCall} from '../Services/HCPCSApiCall';
import {MatSnackBar,MatDialog} from '@angular/material';
import{AlertComponent} from '../alert/alert.component';

@Component({
  selector: 'app-latest-updates',
  templateUrl: './latest-updates.component.html',
  styleUrls: ['./latest-updates.component.css']
})
export class LatestUpdatesComponent implements OnInit {
  customers:any;
  maxLength:any;
  ClientInfo: model.Client_Info[];
  LatestUpdate={} as model.SaveLatestUpdate;
  CLIENT_ID:any;
  News:any;
  LatestUpdateInfo={} as model.LatestUpdateInfo[];
  constructor(private service:HCPCSApiCall,public AlertMessage: MatDialog,private snackBar: MatSnackBar) {    
  
   }

  ngOnInit() {
    this.getClientInfo();
    this.service.GetAllLatestUpdateData().subscribe(
      res =>{
        this.LatestUpdateInfo=res;
              },
      error => { }  
    )
    }
  getClientInfo(){
    this.service.getAllClientInfo().subscribe(
      res =>{
        this.ClientInfo=res;
        },
      error => { }  
    )
  }
  btnSaveClick(){    
this.LatestUpdate.Client_Id=this.CLIENT_ID;
this.LatestUpdate.News=this.News;
this.LatestUpdate.Status='Save';
this.service.AddLatestUpdate(this.LatestUpdate).subscribe(
  res =>{
    if(res){    
      this.AlertMessage.open(AlertComponent,{
        width:'25%',
        data:'News Added Successfully!!!!'          
      });   
    }else{
      this.AlertMessage.open(AlertComponent,{
        width:'25%',
        data:'Something Went Worng!!!!'          
      });            
    }         
  },
  error => { }  
)
  }
  btnClearClick(){
    this.CLIENT_ID='';
    this.ClientInfo=[];    
    this.News='';
    this.getClientInfo();
  }

}
