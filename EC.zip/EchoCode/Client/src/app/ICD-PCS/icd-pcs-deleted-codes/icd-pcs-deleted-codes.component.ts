import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Service } from '../../Services/apicall';
import { Router, ActivatedRoute } from '@angular/router';
import { HCPCSApiCall } from '../../Services/HCPCSApiCall';

@Component({
  selector: 'app-icd-pcs-deleted-codes',
  templateUrl: './icd-pcs-deleted-codes.component.html',
  styleUrls: ['./icd-pcs-deleted-codes.component.css']
})
export class IcdPcsDeletedCodesComponent implements OnInit {

  constructor(private service: Service, private HCPCSService: HCPCSApiCall, private router: Router, private route: ActivatedRoute) { }
  
  IcdPcsDeletedCodesData:any;
  codeType:string;

 focusedRowKey:any;
 autoNavigateToFocusedRow = true;

  ngOnInit() {
    this.GetDeletedIcdPcsCodes();
    this.codeType="ICD-10-PCS";
    this.route.queryParams.subscribe(params => {
      if (params != undefined) {
        this.focusedRowKey = params.Code;
      };
    });
  }

  icd10PcsDeletedCodes(data: any) {
    if (data[0].STATUS == 'D') {
      if(data[0].BASE_CODE_TYPE == 'CPT')
        {
          this.router.navigate(["/DeletedCodes"],{queryParams: { Code: data[0].CODE}});
        }else if(data[0].BASE_CODE_TYPE == 'HCPCS')
        {
          this.router.navigate(["/HcpcsDeletedCode"],{queryParams: { Code: data[0].CODE}});
        }else if(data[0].BASE_CODE_TYPE == 'ICD-CM')
        {
          this.router.navigate(["/Icd10CmDeletedCodes"],{queryParams: { Code: data[0].CODE}})
        }else if(data[0].BASE_CODE_TYPE == 'ICD-PCS')
        {
          this.focusedRowKey=data[0].CODE;
        }
    } else {
      this.router.navigate(["/codeinfo"], { queryParams: { Code: data[0].CODE } });
    }
  }
  GetDeletedIcdPcsCodes() {
    this.HCPCSService.GetMethod('/RevisedCodes/GetAllIcdPcsDeletedCode').subscribe(
      (res: any) => {
        this.IcdPcsDeletedCodesData = res;
      },
      error => { }
    )
  }

}
