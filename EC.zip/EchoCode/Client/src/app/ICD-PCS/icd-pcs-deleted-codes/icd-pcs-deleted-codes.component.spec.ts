import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IcdPcsDeletedCodesComponent } from './icd-pcs-deleted-codes.component';

describe('IcdPcsDeletedCodesComponent', () => {
  let component: IcdPcsDeletedCodesComponent;
  let fixture: ComponentFixture<IcdPcsDeletedCodesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IcdPcsDeletedCodesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IcdPcsDeletedCodesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
