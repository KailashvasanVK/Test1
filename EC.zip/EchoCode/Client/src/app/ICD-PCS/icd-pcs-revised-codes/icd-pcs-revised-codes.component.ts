import { Component, OnInit } from '@angular/core';


import { Service } from 'src/app/Services/apicall';
import { HCPCSApiCall } from 'src/app/Services/HCPCSApiCall';
import { SearchbarComponent } from "src/app/searchbar/searchbar.component";
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-icd-pcs-revised-codes',
  templateUrl: './icd-pcs-revised-codes.component.html',
  styleUrls: ['./icd-pcs-revised-codes.component.css']
})
export class IcdPcsRevisedCodesComponent implements OnInit {

  constructor(private service: Service, private HCPCSService: HCPCSApiCall, private router: Router, private route: ActivatedRoute) { }
  
  IcdPcsRevisedCodesData:any;

  ngOnInit() {
    this.getRevisedIcdCmCodes();
  }

IcdPcsRevisedCodes(data: any) {
  if (data[0].STATUS == 'D') {
    let RedirectValue;
    if(data[0].BASE_CODE_TYPE == 'CPT')
      {
        RedirectValue="/DeletedCodes";
      }else if(data[0].BASE_CODE_TYPE == 'HCPCS')
      {
        RedirectValue="/HcpcsDeletedCode";
      }else if(data[0].BASE_CODE_TYPE == 'ICD-CM')
      {
        RedirectValue="/Icd10CmDeletedCodes";
      }else if(data[0].BASE_CODE_TYPE == 'ICD-PCS')
      {
        RedirectValue="/Icd10PcsDeletedCodes";
      }
    this.router.navigate([RedirectValue],{queryParams: { Code: data[0].CODE}})
  } else {
    this.router.navigate(["/codeinfo"], { queryParams: { Code: data[0].CODE } });
  }
}

getRevisedIcdCmCodes() {
  this.HCPCSService.GetMethod('/RevisedCodes/GetRevisedCodes?CodeType=ICDPCS').subscribe(
    (res: any) => {
      this.IcdPcsRevisedCodesData = res;
    },
    error => { }
  )
}

}
