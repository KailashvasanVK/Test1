import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IcdPcsRevisedCodesComponent } from './icd-pcs-revised-codes.component';

describe('IcdPcsRevisedCodesComponent', () => {
  let component: IcdPcsRevisedCodesComponent;
  let fixture: ComponentFixture<IcdPcsRevisedCodesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IcdPcsRevisedCodesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IcdPcsRevisedCodesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
