import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IcdPcsNewCodesComponent } from './icd-pcs-new-codes.component';

describe('IcdPcsNewCodesComponent', () => {
  let component: IcdPcsNewCodesComponent;
  let fixture: ComponentFixture<IcdPcsNewCodesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IcdPcsNewCodesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IcdPcsNewCodesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
