import { Component, OnInit } from '@angular/core';

import { Service } from 'src/app/Services/apicall';
import { HCPCSApiCall } from 'src/app/Services/HCPCSApiCall';
import { SearchbarComponent } from "src/app/searchbar/searchbar.component";
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-icd-pcs-new-codes',
  templateUrl: './icd-pcs-new-codes.component.html',
  styleUrls: ['./icd-pcs-new-codes.component.css']
})
export class IcdPcsNewCodesComponent implements OnInit {

  constructor(private service: Service, private HCPCSService: HCPCSApiCall, private router: Router, private route: ActivatedRoute) { }

  IcdPcsNewCodesData:any;

  ngOnInit() {
  }
  IcdPcsNewCodes(data: any) {
    if (data[0].STATUS == 'D') {
      let RedirectValue;
      if(data[0].BASE_CODE_TYPE == 'CPT')
        {
          RedirectValue="/DeletedCodes";
        }else if(data[0].BASE_CODE_TYPE == 'HCPCS')
        {
          RedirectValue="/HcpcsDeletedCode";
        }else if(data[0].BASE_CODE_TYPE == 'ICD-CM')
        {
          RedirectValue="/Icd10CmDeletedCodes";
        }else if(data[0].BASE_CODE_TYPE == 'ICD-PCS')
        {
          RedirectValue="/Icd10PcsDeletedCodes";
        }
      this.router.navigate([RedirectValue],{queryParams: { Code: data[0].CODE}})
    } else {
      this.router.navigate(["/codeinfo"], { queryParams: { Code: data[0].CODE } });
    }
  }
  redirectCodeinfo(data){
    this.service.getdatabycode(data).subscribe(
      res =>{
        
        if (res.length == 1){        
          this.router.navigate(["/codeinfo"],{ queryParams: { Code:res[0].CODE} });
        }else if(res.length >1){
          let codedata;
          for(let i=0;i<=res.length-1;i++)
            {
              if(res[i].BASE_CODE_TYPE == 'ICD-PCS'){
                codedata =res[i];
              }
            }
            this.router.navigate(["/codeinfo"],{ queryParams: { Code:codedata.CODE,CodeType:codedata.BASE_CODE_TYPE} });
        }
      },
      error => { }  
    )

  }
  GetNewIcdCmCodes() {
    this.HCPCSService.GetMethod('/RevisedCodes/GetNewCodes?CodeType=ICDPCS').subscribe(
      (res: any) => {
        this.IcdPcsNewCodesData = res;
      },
      error => { }
    )
  }

}
