/*
 * Public API Surface of ngx-loading
 */

export * from './lib/ngx-loading.service';
export * from './lib/ngx-loading.component';
export * from './lib/ngx-loading.module';
export * from './lib/ngx-loading-config';
