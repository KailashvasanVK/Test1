import { Component, OnInit } from '@angular/core';
import {ngxLoadingAnimationTypes} from './ngx-loading/src/public_api';
import {LoaderServiceService} from '../Services/loaderService.service'




@Component({
  selector: 'app-app-loader',
  templateUrl: './app-loader.component.html',
  styleUrls: ['./app-loader.component.css']
})
export class AppLoaderComponent implements OnInit {
  loading = false;
  PrimaryWhite = '#ffffff';
  SecondaryGrey = '#ccc';
  PrimaryRed = '#dd0031';
  SecondaryBlue = '#006ddd';
  template: any;
  loadingmode = [ ngxLoadingAnimationTypes.circle];
  constructor(private loaderService:LoaderServiceService) { }

  ngOnInit() {
    this.loaderService.loading.subscribe((v) => {
      this.loading = v;
    });
    const rnum = Math.floor(Math.random() * this.loadingmode.length);
    this.template = {animationType: this.loadingmode[0],
       primaryColour: this.PrimaryRed,
       secondaryColour: this.SecondaryBlue,
       backdropBorderRadius: '9px',
       fullScreenBackdrop:true
       };
  }
}
