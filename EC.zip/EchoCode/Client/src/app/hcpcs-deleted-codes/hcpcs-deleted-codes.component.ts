import { Component, OnInit,ViewChild } from '@angular/core';
import{Service} from '../Services/apicall';
import * as types from '../models/HCPCS_Code';
import{SearchbarComponent} from '../searchbar/searchbar.component'
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-hcpcs-deleted-codes',
  templateUrl: './hcpcs-deleted-codes.component.html',
  styleUrls: ['./hcpcs-deleted-codes.component.css']
})
export class HCPCSDeletedCodesComponent implements OnInit {

  @ViewChild('SearchCode',{static:false}) SearchCode:SearchbarComponent;
  constructor(private service:Service,private route: ActivatedRoute,private router:Router) { }
 HcpcsDeletedCode ={} as types.HCPCS_DeletedCodes[];
 CodeType:string;
 focusedRowKey:any;
 autoNavigateToFocusedRow = true;
  ngOnInit() {
    this.service.GetAllDeletedHCPCSCode().subscribe(
      res =>{
         this.HcpcsDeletedCode=res;
         this.CodeType='HCPCS';
      },
      error => { }  
    )
    this.route.queryParams.subscribe(params => {
      if (params != undefined) {
        this.focusedRowKey = params.Code;
      };
    });
    
  }
  DeletedCodeshcpc(data){
    if (data[0].STATUS == 'D') {
      if(data[0].BASE_CODE_TYPE == 'CPT')
        {
          this.router.navigate(["/DeletedCodes"],{queryParams: { Code: data[0].CODE}});
        }else if(data[0].BASE_CODE_TYPE == 'HCPCS')
        {
          this.focusedRowKey=data[0].CODE;
        }else if(data[0].BASE_CODE_TYPE == 'ICD-CM')
        {
          this.router.navigate(["/Icd10CmDeletedCodes"],{queryParams: { Code: data[0].CODE}})
        }else if(data[0].BASE_CODE_TYPE == 'ICD-PCS')
        {
          this.router.navigate(["/Icd10PcsDeletedCodes"],{queryParams: { Code: data[0].CODE}})
        }
      
    } else {
      this.router.navigate(["/codeinfo"], { queryParams: { Code: data[0].CODE} });
    }
  }
  // onRowPrepared(d){  
  //   if(this.SearchCode.code != undefined && d.data!=undefined){ 
  //   if(d.data.CODE.toLowerCase() == this.SearchCode.code.toLowerCase()){
  //     this.CodeType=d.data.BASE_CODE_TYPE;
  //   d.rowElement.style.backgroundColor = '#a7a9ac'; 
  //   }
  //  }
  // }
}
