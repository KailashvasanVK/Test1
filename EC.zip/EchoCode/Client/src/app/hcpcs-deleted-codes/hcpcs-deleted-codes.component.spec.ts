import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HCPCSDeletedCodesComponent } from './hcpcs-deleted-codes.component';

describe('HCPCSDeletedCodesComponent', () => {
  let component: HCPCSDeletedCodesComponent;
  let fixture: ComponentFixture<HCPCSDeletedCodesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HCPCSDeletedCodesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HCPCSDeletedCodesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
