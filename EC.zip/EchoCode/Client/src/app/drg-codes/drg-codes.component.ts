import { Component, OnInit } from '@angular/core';
import{HCPCSApiCall} from '../Services/HCPCSApiCall';
import{Service} from '../Services/apicall';
import {MatSnackBar} from '@angular/material/snack-bar';
import {ActivatedRoute,Router} from '@angular/router';
@Component({
  selector: 'app-drg-codes',
  templateUrl: './drg-codes.component.html',
  styleUrls: ['./drg-codes.component.css']
})
export class DrgCodesComponent implements OnInit {
DrgCodeGrp:any;
DrgCodeGrpDtl:any;
DrgCode=false;
DrgCodeDtl=true;
Code:any;
PreviousValue:any;
NextValue:any;
PreviousValuedhide=true;
NextValuedhide=true;
hideBack=true;
  constructor(private Hcpcscallservice:HCPCSApiCall,private service:Service,private snackBar:MatSnackBar,private router:Router) { }

  ngOnInit() {
    this.Hcpcscallservice.GetMethod('/HCPCS/GetDrgCodeGrp').subscribe(
      (res: any) => {
        this.DrgCodeGrp = res;
      },
      error => { }
    )
  }
  DrgCodeEvent(data:any){
    if(data[0].STATUS == 'D'){
      let RedirectValue;
      if(data[0].BASE_CODE_TYPE == 'CPT')
        {
          RedirectValue="/DeletedCodes";
        }else if(data[0].BASE_CODE_TYPE == 'HCPCS')
        {
          RedirectValue="/HcpcsDeletedCode";
        }else if(data[0].BASE_CODE_TYPE == 'ICD-CM')
        {
          RedirectValue="/Icd10CmDeletedCodes";
        }else if(data[0].BASE_CODE_TYPE == 'ICD-PCS')
        {
          RedirectValue="/Icd10PcsDeletedCodes";
        }
      this.router.navigate([RedirectValue],{queryParams: { Code: data[0].CODE}})
    }else{
      this.router.navigate(["/codeinfo"],{ queryParams: { Code:data[0].CODE} });
    }
  }
  DrgCodeClick(data){
    this.DrgCode=true;
    this.DrgCodeDtl=false;
    this.Code=data;
    this.Hcpcscallservice.GetMethod('/HCPCS/GetDrgCodeGrpDtl?Code='+data).subscribe(
      (res: any) => {
        this.DrgCodeGrpDtl = res;
        this.hideBack=false;
        if(this.DrgCodeGrpDtl.find(t =>t.CODE_RANGE==this.Code).PREVIOUS_VALUE == null)
          {
             this.PreviousValuedhide=false;
          }else{
            {
              this.PreviousValuedhide=true;
           }
          }
          if(this.DrgCodeGrpDtl.find(t =>t.CODE_RANGE==this.Code).NEXT_VALUE == null)
            {
               this.NextValuedhide=false;
            }else{
              this.NextValuedhide=true;
           }
          
      },
      error => { }
    )
  }
  DrgBackClick(){
    this.DrgCode=false;
    this.DrgCodeDtl=true;
    this.hideBack=true;
  }
  arrowleft(){
    this.Code=this.DrgCodeGrpDtl.find(t =>t.CODE_RANGE==this.Code).PREVIOUS_VALUE;
    this.Hcpcscallservice.GetMethod('/HCPCS/GetDrgCodeGrpDtl?Code='+this.Code).subscribe(
      (res: any) => {
        this.DrgCodeGrpDtl = res;
        if(this.DrgCodeGrpDtl.find(t =>t.CODE_RANGE==this.Code).PREVIOUS_VALUE == null)
          {
             this.PreviousValuedhide=false;
          }else{
            {
              this.PreviousValuedhide=true;
           }
          }
          if(this.DrgCodeGrpDtl.find(t =>t.CODE_RANGE==this.Code).NEXT_VALUE == null)
            {
               this.NextValuedhide=false;
            }else{
              this.NextValuedhide=true;
           }
      },
      error => { }
    )
  }
  arrowright(){
    this.Code=this.DrgCodeGrpDtl.find(t =>t.CODE_RANGE==this.Code).NEXT_VALUE;
    this.Hcpcscallservice.GetMethod('/HCPCS/GetDrgCodeGrpDtl?Code='+this.Code).subscribe(
      (res: any) => {
        this.DrgCodeGrpDtl = res;
        if(this.DrgCodeGrpDtl.find(t =>t.CODE_RANGE==this.Code).PREVIOUS_VALUE == null)
          {
             this.PreviousValuedhide=false;
          }else{
            {
              this.PreviousValuedhide=true;
           }
          }
          if(this.DrgCodeGrpDtl.find(t =>t.CODE_RANGE==this.Code).NEXT_VALUE == null)
            {
               this.NextValuedhide=false;
            }else{
              this.NextValuedhide=true;
           }
      },
      error => { }
    )
  }

}
