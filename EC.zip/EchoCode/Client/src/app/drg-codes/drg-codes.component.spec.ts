import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DrgCodesComponent } from './drg-codes.component';

describe('DrgCodesComponent', () => {
  let component: DrgCodesComponent;
  let fixture: ComponentFixture<DrgCodesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DrgCodesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DrgCodesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
