import { Component, OnInit,Output,EventEmitter } from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import{Service} from '../Services/apicall'


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
  })
export class HeaderComponent implements OnInit {
  // Clock = Date.now();

  // public ngOnInit() {
  //   setInterval(() => {
  //     this.Clock = Date.now();
  //   }, 1000);
  // }
  @Output() public sidenavToggle = new EventEmitter(true);
  todaydate:number;
  UserFullName:string;
  constructor(private service:Service) { }
  ngOnInit() {
  //  setInterval(()=>{
  //  this.todaydate=Date.now();
  //  },1000)
  this.todaydate=Date.now();
   this.service.getUserName().subscribe(
     res => {      
        this.UserFullName=res.toString().toUpperCase( );
     }
   )
  }
  public onToggleSidenav = () => {
    this.sidenavToggle.emit();
  }
}
