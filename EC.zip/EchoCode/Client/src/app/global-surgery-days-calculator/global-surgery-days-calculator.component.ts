import { Component, OnInit } from '@angular/core';
import { Service } from '../Services/apicall';
import { ActivatedRoute, Router } from '@angular/router';
import { HCPCSApiCall } from '../Services/HCPCSApiCall';

@Component({
  selector: 'app-global-surgery-days-calculator',
  templateUrl: './global-surgery-days-calculator.component.html',
  styleUrls: ['./global-surgery-days-calculator.component.css']
})
export class GlobalSurgeryDaysCalculatorComponent implements OnInit {
  CalcData: any;
  GlobalSurgData: any;
  GlobSurgData: any;
  indexList: any = [];
  constructor(private service: Service, private router: Router, private Hcpcscallservice: HCPCSApiCall) { }

  ngOnInit() {
    this.Hcpcscallservice.GetMethod('/Apihit/GetGlobalSurgData').subscribe(
      (res: any) => {
        this.GlobSurgData = res;
      },
      error => { }
    )
  }
  GlobalCalcData(data: any) {
    if (data[0].STATUS == 'D') {
      let RedirectValue;
      if (data[0].BASE_CODE_TYPE == 'CPT') {
        RedirectValue = "/DeletedCodes";
      } else if (data[0].BASE_CODE_TYPE == 'HCPCS') {
        RedirectValue = "/HcpcsDeletedCode";
      } else if (data[0].BASE_CODE_TYPE == 'ICD-CM') {
        RedirectValue = "/Icd10CmDeletedCodes";
      } else if (data[0].BASE_CODE_TYPE == 'ICD-PCS') {
        RedirectValue = "/Icd10PcsDeletedCodes";
      }
      this.router.navigate([RedirectValue], { queryParams: { Code: data[0].CODE } })
    } else {
      this.router.navigate(["/codeinfo"], { queryParams: { Code: data[0].CODE } });
    }
  }
  GlobalDataClick(data) {
    this.GlobalSurgData = data;

  }
  SearchClick(OutputCodes: any) {
    let array1 = [];
    let resList = [];
    this.indexList = [];
    let filteredArray = [];
    let value = OutputCodes.split(";")[1];
    value = new Date(value);

    OutputCodes = OutputCodes.split(";")[0];
    array1 = OutputCodes.split(',');
    
    filteredArray = array1.filter(notEmpty);
    function notEmpty(value) {
      
      return value !== "";
    }
    this.Hcpcscallservice.GetMethod('/Apihit/GetGlobalCalcData?Date=' + value.toDateString() + '&Codes=' + OutputCodes).subscribe(
      (res: any) => {
        
        this.CalcData = res;

        let resultValue;
        let resList = [];

        if (Object.keys(this.CalcData).length > 0) {
          this.CalcData.map((obj, i) => {
            
            resultValue = obj.CODE;
            resList.push(resultValue);
          });
        }
        for (let i = 0; i < filteredArray.length; i++) {
          if(filteredArray[i]!="null"){
          if (!resList.includes(filteredArray[i])) {
            this.indexList.push(i);
          }
        }
        }

        if (this.indexList.length > 0) {
          this.Hcpcscallservice.setMissingIndexForGlob(this.indexList);
        }

      },
      error => { }
    )
  }
  redirectCodeinfo(data) {
    this.service.getdatabycode(data).subscribe(
      res => {

        if (res.length == 1) {
          this.router.navigate(["/codeinfo"], { queryParams: { Code: res[0].CODE } });
        } else if (res.length > 1) {
          this.router.navigate(["/MultipleCode"], { queryParams: { Code: res[0].CODE } });
        }
      },
      error => { }
    )

  }
}
