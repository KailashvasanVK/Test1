import { Component, OnInit ,EventEmitter,HostListener,Output} from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators,FormControl } from '@angular/forms';
import {ActivatedRoute,Router} from '@angular/router';
import {HCPCSApiCall} from '../../Services/HCPCSApiCall'

@Component({
  selector: 'app-auto-textbox',
  templateUrl: './auto-textbox.component.html',
  styleUrls: ['./auto-textbox.component.css']
})
export class AutoTextboxComponent implements OnInit {

  dynamicForm: FormGroup;
  codes:any;
  NoOfCodes:any;
  date = new FormControl(new Date());
  DataCodes=[];
  missingIndex:any[]=[];
  
  @Output() Calcdata: EventEmitter<any> = new EventEmitter();
  constructor(private formBuilder: FormBuilder,private route:ActivatedRoute,private router :Router, private Hcpcscallservice:HCPCSApiCall) { 
    this.Hcpcscallservice.getMissingIndexFromGlob().subscribe(data => {
      this.missingIndex=data;
    })
  }
  @HostListener('window:load', ['$event']) onload($event){
    this.router.navigate(['/GlobalCalc'])
  }

  ngOnInit() {
    this.codes='';
    this.missingIndex=[];
    this.NoOfCodes=[10,11,12,13,14,15,16]
    this.dynamicForm = this.formBuilder.group({          
        tickets: new FormArray([])
    });
    const numberOfTickets = 10 || 0;
    if (this.t.length < numberOfTickets) {
        for (let i = this.t.length; i < numberOfTickets; i++) {
            this.t.push(this.formBuilder.group({
                name: [this.DataCodes[i], Validators.required],                  
            }));
        }
    } else {
        for (let i = this.t.length; i >= numberOfTickets; i--) {
            this.t.removeAt(i);
        }
    }
  }
  get f() { return this.dynamicForm.controls; }
  get t() { return this.f.tickets as FormArray; }

  onChangeTickets(e) {
    const numberOfTickets = e.target.value || 0;
      if (this.t.length < numberOfTickets) {
          for (let i = this.t.length; i < numberOfTickets; i++) {
              this.t.push(this.formBuilder.group({
                  name: ['', Validators.required],                  
              }));
          }
      } else {
          for (let i = this.t.length; i >= numberOfTickets; i--) {
              this.t.removeAt(i);
          }
      }
  }
  clearclick(){    
    this.date = new FormControl(new Date());
    this.dynamicForm.reset();
    this.missingIndex=[];
    this.codes='';
  }
  onSubmit() {
    this.missingIndex=[];
    var formLength = this.dynamicForm.value.tickets.length;
    for(var i=0;i<formLength;i++){
      if(this.dynamicForm.value.tickets[i].name==""){
        this.dynamicForm.value.tickets[i].name=null;
      }
      else if(this.dynamicForm.value.tickets[i].name){
        this.dynamicForm.value.tickets[i].name = this.dynamicForm.value.tickets[i].name.toUpperCase();
      }
    }
    let data = JSON.parse(JSON.stringify(this.dynamicForm.value, null, 4)).tickets;
    this.codes='';    
    for(let i=0;i<this.t.length;i++)
      {        
        this.codes=this.codes+data[i].name + ','; 
      }     
      this.Calcdata.emit(this.codes +";"+this.date.value);
  }

}
