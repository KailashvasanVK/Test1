import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AutoTextboxComponent } from './auto-textbox.component';

describe('AutoTextboxComponent', () => {
  let component: AutoTextboxComponent;
  let fixture: ComponentFixture<AutoTextboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AutoTextboxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoTextboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
