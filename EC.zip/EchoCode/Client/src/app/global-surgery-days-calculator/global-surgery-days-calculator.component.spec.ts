import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GlobalSurgeryDaysCalculatorComponent } from './global-surgery-days-calculator.component';

describe('GlobalSurgeryDaysCalculatorComponent', () => {
  let component: GlobalSurgeryDaysCalculatorComponent;
  let fixture: ComponentFixture<GlobalSurgeryDaysCalculatorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GlobalSurgeryDaysCalculatorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GlobalSurgeryDaysCalculatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
