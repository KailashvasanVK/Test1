import { Component, OnInit, ViewChild, HostListener } from '@angular/core';
import * as types from '../models/CodeSearch';
import { Service } from '../Services/apicall';
import { ActivatedRoute, Router } from '@angular/router';
import { SearchbarComponent } from "src/app/searchbar/searchbar.component";
@Component({
  selector: 'app-deleted-codes',
  templateUrl: './deleted-codes.component.html',
  styleUrls: ['./deleted-codes.component.css']
})
export class DeletedCodesComponent implements OnInit {

  constructor(private service: Service, private router: Router, private route: ActivatedRoute) {

  }
  @HostListener('window:load', ['$event']) onload($event) {
    this.router.navigate(['/DeletedCodes'])
  }
  Deletecode = {} as types.DeletedCodes[];
  code: any;
  focusedRowKey:any;
  autoNavigateToFocusedRow = true;
  CodeType: any;
  @ViewChild("SearchCode", { static: false }) SearchCode: SearchbarComponent;
  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      if (params != undefined) {
        this.focusedRowKey = this.code = params.Code;
      };
    });
    if (this.code != undefined) {
      this.service.GetDeletedCode(this.code).subscribe(
        res => {
          this.Deletecode = res;
        },
        error => { }
      )
    } else {
      this.service.GetAllDeletedCode().subscribe(
        res => {
          this.Deletecode = res;
          this.CodeType = 'CPT';
        },
        error => { }
      )
    }
  }
  DeletedCodes(data: any) {
    if (data[0].STATUS == 'D') {
      this.service.GetDeletedCode(data[0].CODE).subscribe(
        res => {
          this.Deletecode = res;
          this.focusedRowKey = data[0].CODE;
        },
        error => { }
      )
    } else {
      this.router.navigate(["/codeinfo"], { queryParams: { Code: data[0].CODE } });
    }
  }
  
  // onRowPrepared(d) {
  //   if (this.SearchCode.code != undefined && d.data != undefined) {
  //     if (d.data.CODE.toLowerCase() == this.SearchCode.code.toLowerCase()) {
  //       this.CodeType = d.data.BASE_CODE_TYPE;
  //       d.rowElement.style.backgroundColor = '#a7a9ac';
  //       this.focusedRowKey = d.data.CODE;
  //     }
  //   }
  // }
}
