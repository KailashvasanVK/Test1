import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeletedCodesComponent } from './deleted-codes.component';

describe('DeletedCodesComponent', () => {
  let component: DeletedCodesComponent;
  let fixture: ComponentFixture<DeletedCodesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeletedCodesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeletedCodesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
