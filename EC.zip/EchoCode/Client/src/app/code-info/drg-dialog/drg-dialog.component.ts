import { Component, OnInit,Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import{HCPCSApiCall} from '../../Services/HCPCSApiCall';



@Component({
  selector: 'app-drg-dialog',
  templateUrl: './drg-dialog.component.html',
  styleUrls: ['./drg-dialog.component.css']
})
export class DRGDialogComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<DRGDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public Code: any,private service:HCPCSApiCall) { }
    DRGDatasrc:any;
  ngOnInit() {
    let data=this.Code.split('-'); 
    this.service.GetDRGData(data[0],data[1]).subscribe(
      res =>{
        this.DRGDatasrc=res;
      },
      error => { }  
    )   
  }
  CloseDialog(){
    this.dialogRef.close();
  }
  

}
