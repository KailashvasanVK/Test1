import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DRGDialogComponent } from './drg-dialog.component';

describe('DRGDialogComponent', () => {
  let component: DRGDialogComponent;
  let fixture: ComponentFixture<DRGDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DRGDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DRGDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
