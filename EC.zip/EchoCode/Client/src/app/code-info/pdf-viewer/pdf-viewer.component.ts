import { Component, OnInit } from '@angular/core';
import{Service} from '../../Services/apicall';
import{HCPCSApiCall} from '../../Services/HCPCSApiCall';
import {MatSnackBar} from '@angular/material/snack-bar';
import {ActivatedRoute,Router} from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';  


@Component({
  selector: 'app-pdf-viewer',
  templateUrl: './pdf-viewer.component.html',
  styleUrls: ['./pdf-viewer.component.css']
})
export class PdfViewerComponent implements OnInit {

  constructor(private _http:HttpClient,private service:Service, private route: ActivatedRoute,private service1:HCPCSApiCall,private snackBar:MatSnackBar,private router:Router) { }
  pdfSrc:any;
  Code:any;
  codedata:any;
  CodeType:any;
  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      if (params != undefined) {
        this.Code=params.Code;
        this.CodeType=params.CodeType;
        this.downloadFile(params.url)
      };
    });
  }
  downloadFile(pdfurl){
    this.service1.GetMethod('/HCC/getpdfAuth?url='+pdfurl).subscribe(
      (res: any) => {       
        this.pdfSrc='data:application/pdf;base64,'+res;       
      },
      error => { }
    )
  }
  downloadFile1() {
    let link = document.createElement("a");
    link.download = "Medical code PDF";
    link.href =  this.pdfSrc;
    link.click();
  }
  pdfviewer(data:any){
    
    if(data[0].STATUS == 'D'){
      let RedirectValue;
      if(data[0].BASE_CODE_TYPE == 'CPT')
        {
          RedirectValue="/DeletedCodes";
        }else if(data[0].BASE_CODE_TYPE == 'HCPCS')
        {
          RedirectValue="/HcpcsDeletedCode";
        }else if(data[0].BASE_CODE_TYPE == 'ICD-CM')
        {
          RedirectValue="/Icd10CmDeletedCodes";
        }else if(data[0].BASE_CODE_TYPE == 'ICD-PCS')
        {
          RedirectValue="/Icd10PcsDeletedCodes";
        }
      this.router.navigate([RedirectValue],{queryParams: { Code: data[0].CODE}})
    }else{
      this.router.navigate(["/codeinfo"],{ queryParams: { Code:data[0].CODE} });
    }
  }
backclick()
{
  
  let data:any;
  this.service.getdatabycode(this.Code).subscribe(
    res =>{
      this.codedata=res;
      if(this.codedata.length > 1)
        {
       for(let i=0;i<=this.codedata.length-1;i++)
        {
          if(this.codedata[i].BASE_CODE_TYPE == this.CodeType){
            data =this.codedata[i];
          }
        }
        this.router.navigate(["/codeinfo"],{ queryParams: { Code:data.CODE,CodeType:data.BASE_CODE_TYPE} });
      }else{
        this.router.navigate(["/codeinfo"],{ queryParams: { Code:this.Code} });
      }
    },
    error => { }  
  )
  
}
}
