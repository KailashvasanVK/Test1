import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultipleCodeinfoComponent } from './multiple-codeinfo.component';

describe('MultipleCodeinfoComponent', () => {
  let component: MultipleCodeinfoComponent;
  let fixture: ComponentFixture<MultipleCodeinfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultipleCodeinfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultipleCodeinfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
