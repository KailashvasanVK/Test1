import { Component, OnInit, ViewChild, HostListener } from '@angular/core';
import { Service } from '../../Services/apicall';
import { ActivatedRoute, Router } from '@angular/router';
import { SearchbarComponent } from "src/app/searchbar/searchbar.component";
@Component({
  selector: 'app-multiple-codeinfo',
  templateUrl: './multiple-codeinfo.component.html',
  styleUrls: ['./multiple-codeinfo.component.css']
})
export class MultipleCodeinfoComponent implements OnInit {

  constructor(private service: Service, private router: Router, private route: ActivatedRoute) { }
  @HostListener('window:load', ['$event']) onload($event) {
    this.router.navigate(['/MultipleCode'])
  }
 multipledata:any;
  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      if (params != undefined) {
        this.service.getdatabycode(params.code).subscribe(
          res =>{
            this.multipledata=res;
          },
          error => { }  
        )
      };
    });
  }
  codeClick(codeType){
    let data:any;
    
     for(let i=0;i<=this.multipledata.length-1;i++)
      {
        if(this.multipledata[i].BASE_CODE_TYPE == codeType){
          data =this.multipledata[i];
        }
      }
      if(data.STATUS == 'D'){
        let RedirectValue;
        if(data.BASE_CODE_TYPE == 'CPT')
          {
            RedirectValue="/DeletedCodes";
          }else if(data.BASE_CODE_TYPE == 'HCPCS')
          {
            RedirectValue="/HcpcsDeletedCode";
          }else if(data.BASE_CODE_TYPE == 'ICD-CM')
          {
            RedirectValue="/Icd10CmDeletedCodes";
          }else if(data.BASE_CODE_TYPE == 'ICD-PCS')
          {
            RedirectValue="/Icd10PcsDeletedCodes";
          }
        this.router.navigate([RedirectValue],{queryParams: { Code: data.CODE}})
      }else{
        this.router.navigate(["/codeinfo"],{ queryParams: { Code:data.CODE,CodeType:data.BASE_CODE_TYPE} });
        
      }
  }

}
