import { Component, OnInit, HostListener, SecurityContext, ChangeDetectorRef } from '@angular/core';
import * as types from '../models/CodeSearch';
import { Service } from '../Services/apicall';
import { HCPCSApiCall } from '../Services/HCPCSApiCall';
import { ActivatedRoute, Router } from '@angular/router';
import { MatSnackBar, MatDialog } from '@angular/material';
import { DRGDialogComponent } from '../code-info/drg-dialog/drg-dialog.component';
import { AlertComponent } from '../alert/alert.component';
import { DomSanitizer } from '@angular/platform-browser';
import { getActiveOffset } from '@angular/material/datepicker/typings/multi-year-view';
import { ColorCodesKeyPipe } from '../colorCodesKey.pipe'
import { Observable } from 'rxjs';
import { subscribeOn } from 'rxjs/operators';
import { debug } from 'util';

@Component({
  selector: 'app-code-info',
  templateUrl: './code-info.component.html',
  styleUrls: ['./code-info.component.css']
})
export class CodeInfoComponent implements OnInit {

  codeInformation = {} as types.CodeInfo;
  bool: boolean = false;
  FavoriteCode = {} as types.FavoriteCode;
  Modifier_p: any;
  Modifier_ASP: any;
  Note: any;
  CM = true;
  PCS = true;
  IncludesExcludesdata: any;
  HCPCS = true;
  CodeDesc = false;
  ExpandColorCodes = false;
  exmodifierASC = false;
  exmodifier = false;
  MueEditsOpen = false;
  MaiDescriptionVisible = false;
  apidata: any;
  instructionsData: any;
  illustrationImages: any;
  colorCodesData: any;
  CMDatasrc: any;
  PCSDatasrc: any;
  MedicareCciSrc: any;
  HCPCSDatasrc: any;
  // $RevenueDataSrc: Observable<any>;
  RevenueDataSrc: any;
  HCCDataSrc: any;
  Notes = {} as types.Notes;
  UnlikelyEdits: any;
  FeeSchedules: any;
  MaiDescriptiondata: any;
  LayTermsData: any;
  ExpandLayTerms = false;
  ExpandHistorical = false;
  ExpandPdf = false;
  ExpandMedicare = false;
  ExpandFeeSchedule = false;
  ExpandFeeLab = false;
  ExpandFeeAnesthesia = false;
  ExpandCrossWalk = false;
  ExpandFeePEN = false;
  ExpandFeePOS = false;
  ExpandFeeAmbulance = false;

  ExpandIllustration = false;
  Type1 = false;
  Type2 = false;
  Type3 = false;
  ExpandMips = false;
  expandRevenue = false;
  expandHCC = false;
  HistoricalData: any;
  CodeStatusData: any;
  GolbalPerioddata: any;
  Radiologydata: any;
  SPEC_VALUE: any;
  PCTCdata: any;
  MULTPROCdata: any;
  BILATSURGdata: any;
  ASSTSURGdata: any;
  COSURGdata: any;
  TEAMSURGdata: any;
  PHYSNdata: any;
  twodata: any;
  fivedata: any;
  tcdata: any;
  Mips = true;
  FeeSchedulehide = true;
  InstructionalNotes: any;
  InstructionalNoteshide = true;
  MedicareCarrier: any;
  medicareCarrierForAnesthesia: any;
  physicalUnits: any;
  physicalUnitsData: any;
  selectedPhysicalUnit: number;
  selectedQualifyUnit: number;
  qualifyUnits: any = [];
  qualifyUnitsData: any = [];
  totalUnits: number;
  FeeLabData: any;
  AsaCrossWalkData: any;
  FeeAnesthesiaData: any;
  GuideLineshide = false;
  instructionsHide = false;
  IncludeExcludeNoteshide = true;
  Medicaredata: any;
  medicareDataForAnesthesia: any;
  Specialtydata: any;
  Specialtygriddata: any;
  Feestates: any;
  Feestatesdata: any;
  FeePenGridData: any;
  FeestatesPOSdata: any;
  FeePosGridData: any;
  FeePosGridDataCount: any;
  AmbulanceMedicarier: any;
  AmbulanceMedidata: any;
  AmbulanceGridData: any;
  enteredUnit: number = 0;
  anesthesiaData: any;
  anesBaseUnit: number;
  anesConversionFactor: number;
  calculatedFeeValue: number;
  dropdownSettings: any = {};
  ApiCodeType: string;
  imgHref: string;
  imageItself: any;
  output = [];
  alternateImg: any;
  notFound: boolean;
  dataNotFound: string;
  chapterNotes: any;
  codeRangeNotes: any;
  imgPath: any;
  noDup: any = [];

  noLayTerms: boolean;
  noGuideLines: boolean;
  noInstructions: boolean;
  noHistoricalData: boolean;
  noDocument: boolean;
  noInstructionalNotes: boolean;
  noIncludesExcludes: boolean;
  noMedicare: boolean;
  noModifierASP: boolean;
  noModifierP: boolean;
  noRevenueData: boolean;
  noASACross: boolean;
  noHCCCross: boolean;
  noMPFS: boolean;
  noDMEPen: boolean;
  noDMEPos: boolean;
  noAmbulanceFee: boolean;
  guideLinesData: any = [];
  cloneApiData: any = [];
  codesInGuide: any = [];
  commonIndex: number;
  htmlToAdd: any;
  finalApiData: any = [];
  finalInstructionsData: any = [];
  finalCodeRangeNotes: any = [];
  finalBlockNotes: any[];
  finalChapterNotes: any = [];
  finalExcludedata1: any = [];
  finalExcludedata2: any = [];
  finalIncludedata1: any = [];
  anchorParamCode: any;
  constructor(private service: Service, public AlertMessage: MatDialog, public dialog: MatDialog,
    private Hcpcscallservice: HCPCSApiCall, private route: ActivatedRoute, private router: Router,
    private snackBar: MatSnackBar, private sanitizer: DomSanitizer, private cd: ChangeDetectorRef) { }

  @HostListener('window:load', ['$event']) onload($event) {
    this.router.navigate(['/codeinfo'])
  }
  redirectCodeinfo(data, Codetype) {

    this.router.navigate(["/codeinfo"], { queryParams: { Code: data, CodeType: Codetype } });

  }
  redirectCodeinfo1(data) {

    this.router.navigate(["/codeinfo"], { queryParams: { Code: data } });

  }
  ngOnInit() {
    this.anchorParamCode = '';
    this.imgPath = '../assets/images/'
    this.notFound = false;
    this.enteredUnit = 0;
    this.anesBaseUnit = 0;
    this.anesConversionFactor = 0;
    this.calculatedFeeValue = 0;
    this.instructionsHide = true;
    this.colorCodesData = [];
    this.imageItself = '';
    this.alternateImg = '';
    this.dataNotFound = "No data found";
    this.commonIndex = 0;
    this.htmlToAdd = '';
    this.guideLinesData = [];
    this.route.queryParams.subscribe(params => {
      if (params != undefined) {
        this.service.getdatabycode(params.Code).subscribe(
          res => {
            if (res.length > 1) {
              if (params.CodeType != undefined) {
                let codedata;
                for (let i = 0; i <= res.length - 1; i++) {
                  if (res[i].BASE_CODE_TYPE == params.CodeType) {
                    codedata = res[i];
                  }
                }
                this.codeInformation = {
                  CODE: codedata.CODE,
                  BASE_CODE_TYPE: codedata.BASE_CODE_TYPE,
                  FULL_DESCRIPTION: codedata.FULL_DESCRIPTION,
                  SHORT_DESCRIPTION: codedata.SHORT_DESCRIPTION,
                  LONG_DESCRIPTION: '',
                  NEXT_VALUE: codedata.NEXT_VALUE,
                  PREVIOUS_VALUE: codedata.PREVIOUS_VALUE,
                  NOTES: codedata.NOTES,
                  STATUS: codedata.STATUS,
                  X_CODE_TYPE1_COUNT: codedata.X_CODE_TYPE1_COUNT,
                  X_CODE_TYPE2_COUNT: codedata.X_CODE_TYPE2_COUNT,
                  X_CODE_TYPE3_COUNT: codedata.X_CODE_TYPE3_COUNT,
                  X_CODE_TYPE1: codedata.X_CODE_TYPE1,
                  X_CODE_TYPE2: codedata.X_CODE_TYPE2,
                  X_CODE_TYPE3: codedata.X_CODE_TYPE3,
                  MIPS: codedata.MIPS
                };
              }
            } else {
              this.codeInformation = {
                CODE: res[0].CODE,
                BASE_CODE_TYPE: res[0].BASE_CODE_TYPE,
                FULL_DESCRIPTION: res[0].FULL_DESCRIPTION,
                SHORT_DESCRIPTION: res[0].SHORT_DESCRIPTION,
                LONG_DESCRIPTION: '',
                NEXT_VALUE: res[0].NEXT_VALUE,
                PREVIOUS_VALUE: res[0].PREVIOUS_VALUE,
                NOTES: res[0].NOTES,
                STATUS: res[0].STATUS,
                X_CODE_TYPE1_COUNT: res[0].X_CODE_TYPE1_COUNT,
                X_CODE_TYPE2_COUNT: res[0].X_CODE_TYPE2_COUNT,
                X_CODE_TYPE3_COUNT: res[0].X_CODE_TYPE3_COUNT,
                X_CODE_TYPE1: res[0].X_CODE_TYPE1,
                X_CODE_TYPE2: res[0].X_CODE_TYPE2,
                X_CODE_TYPE3: res[0].X_CODE_TYPE3,
                MIPS: res[0].MIPS
              };
            }
            this.checkCrossRef();
            this.LoadColorCodesData();
            this.exmodifier = false;
            this.exmodifierASC = false;
            this.MueEditsOpen = false;
            this.ExpandLayTerms = false;
            this.ExpandHistorical = false;
            this.ExpandPdf = false;
            this.ExpandMedicare = false;
            this.ExpandFeeSchedule = false;
            this.ExpandFeeLab = false;
            this.ExpandFeeAnesthesia = false;
            this.ExpandCrossWalk = false;
            this.ExpandFeePEN = false;
            this.ExpandFeePOS = false;
            this.ExpandFeeAmbulance = false;
            this.Type1 = false;
            this.Type2 = false;
            this.Type3 = false;
            this.ExpandMips = false;
            this.expandRevenue = false;
            this.expandHCC = false;
            if (this.codeInformation.CODE != undefined) {
              this.ExpandColorCodes = true;
            }
            else {
              this.ExpandColorCodes = false;
            }
            if (this.codeInformation.FULL_DESCRIPTION != undefined) {
              if (this.CodeDesc)
                this.CodeDesc = false;
              this.CodeDesc = true;
            } else {
              this.CodeDesc = false;
            }
          },
          error => { }
        )


      }
    });
  }
  MipsOpen() {
    this.SPEC_VALUE = null;
    this.Specialtydata = [];
    this.Specialtygriddata = [];
    this.Hcpcscallservice.GetMethod('/Apihit/GetSpecialtyData').subscribe(
      (res: any) => {
        this.Specialtydata = res;
      },
      error => { }
    )
  }
  CalculateAmbulanceClick() {
    this.AmbulanceGridData = '';
    this.noAmbulanceFee = false;
    if (this.codeInformation.CODE != undefined) {
      this.Hcpcscallservice.GetMethod('/Apihit/GetFeeAmbulancedata?Code=' + this.codeInformation.CODE + '&State=' + this.AmbulanceMedidata).subscribe(
        (res: any) => {
          if (res.length > 0) {
            this.AmbulanceGridData = res[0];
          }
          else {
            this.noAmbulanceFee = true;
            this.AmbulanceGridData = '';
          }
        },
        error => { }
      )
    }
  }
  FeeAmbulanceClick() {
    this.Hcpcscallservice.GetMethod('/HCPCS/GetMedicareCarrierdata').subscribe(
      (res: any) => {
        this.AmbulanceMedicarier = res;
        this.AmbulanceMedidata = this.AmbulanceMedicarier[0].LOCALITY_VALUE;
        this.CalculateAmbulanceClick();
      },
      error => { }
    )
  }
  CalculatePENClick() {
    this.noDMEPen = false;
    this.FeePenGridData = [];
    if (this.codeInformation.CODE != undefined) {
      this.Hcpcscallservice.GetMethod('/Apihit/GetFeeDmePen?Code=' + this.codeInformation.CODE + '&State=' + this.Feestatesdata).subscribe(
        (res: any) => {
          if (res.length > 0) {
            this.FeePenGridData = res;
          }
          else {
            this.noDMEPen = true;
            this.FeePenGridData = [];
          }
        },
        error => { }
      )
    }
  }
  FeeDMEPENClick() {
    this.Hcpcscallservice.GetMethod('/Apihit/GetFeeStates').subscribe(
      (res: any) => {
        this.Feestates = res;
        this.Feestatesdata = this.Feestates[0].STATE_VALUE;
        this.CalculatePENClick();
      },
      error => { }
    )
  }
  CalculatePOSClick() {
    this.FeePosGridData = [];
    this.noDMEPos = false;
    if (this.codeInformation.CODE != undefined) {
      this.Hcpcscallservice.GetMethod('/Apihit/GetFeeDmePos?Code=' + this.codeInformation.CODE + '&State=' + this.FeestatesPOSdata).subscribe(
        (res: any) => {
          if (res.length > 0) {
            this.FeePosGridData = res;
            this.FeePosGridDataCount = this.FeePosGridData.length;
          }
          else {
            this.FeePosGridData = [];
            this.noDMEPos = true;
          }
        },
        error => { }
      )
    }
  }
  FeeDMEPOSClick() {
    this.Hcpcscallservice.GetMethod('/Apihit/GetFeeStates').subscribe(
      (res: any) => {
        this.Feestates = res;
        this.FeestatesPOSdata = this.Feestates[0].STATE_VALUE;
        this.CalculatePOSClick();
      },
      error => { }
    )
  }
  SpecialtydataChanged(data) {
    this.Hcpcscallservice.GetMethod('/Apihit/GetSpecialtyGridData?Code=' + this.codeInformation.CODE + '&Speciality=' + data.value).subscribe(
      (res: any) => {
        this.Specialtygriddata = res;
      },
      error => { }
    )
  }
  FeeLabClick() {
    this.Hcpcscallservice.GetMethod('/Apihit/GetFeeLabData?Code=' + this.codeInformation.CODE).subscribe(
      (res: any) => {
        this.FeeLabData = res;
      },
      error => { }
    )
  }
  crossWalkClick() {
    this.AsaCrossWalkData = '';
    this.noASACross = false;
    this.Hcpcscallservice.GetMethod('/Apihit/GetAsaCrossWalkData?Code=' + this.codeInformation.CODE).subscribe(
      (res: any) => {
        if (res.length > 0) {
          this.AsaCrossWalkData = res;
        }
        else {
          this.AsaCrossWalkData = '';
          this.noASACross = true;
        }
      },
      error => { }
    )
  }

  feeAnesthesiaClick() {
    this.Hcpcscallservice.GetMethod('/HCPCS/GetMedicareCarrierdata').subscribe(
      (async res => {
        this.medicareCarrierForAnesthesia = res;
        this.medicareDataForAnesthesia = this.medicareCarrierForAnesthesia[0].LOCALITY_VALUE;
        this.getPhysicalUnits();
        this.getQualifyUnits();
        if (this.codeInformation.CODE != undefined && this.medicareDataForAnesthesia != undefined) {
          this.getBaseUnitConvFactor();
        }
      }),
      error => { }
    )
  }

  onStateChanged(e) {
    const stateChanged = e.value;
    this.medicareDataForAnesthesia = stateChanged;
    if (this.codeInformation.CODE != undefined && this.medicareDataForAnesthesia != undefined) {
      this.getBaseUnitConvFactor();
    }
  }

  getBaseUnitConvFactor() {
    var localityValue = this.medicareDataForAnesthesia;
    this.Hcpcscallservice.GetMethod('/HCPCS/GetFeeAnesthesiaData?Code=' + this.codeInformation.CODE + '&LocalityValue=' + localityValue).subscribe(res => {
      this.anesthesiaData = res;
      this.anesBaseUnit = this.anesthesiaData[0].BASE_UNIT ? this.anesthesiaData[0].BASE_UNIT : 0;
      this.anesConversionFactor = this.anesthesiaData[0].CONVERSION_FACTOR ? this.anesthesiaData[0].CONVERSION_FACTOR : 0;
      this.calculateTotalUnits();
    });
  }

  getPhysicalUnits() {
    this.Hcpcscallservice.GetMethod('/HCPCS/GetPhysicalUnitsdata').subscribe(
      (res: any) => {
        this.physicalUnits = res;
        // this.physicalUnitsData = this.physicalUnits[0].PHYSICAL_STS;
        // var bu = this.physicalUnits.find(e => e.PHYSICAL_STS == this.physicalUnitsData);
        this.selectedPhysicalUnit = 0;
        this.calculateTotalUnits();
      },
      error => { }
    )
  }

  onPValueChanged(e) {
    const newValue = e.value;
    var bu = this.physicalUnits.find(e => e.PHYSICAL_STS == newValue);
    this.selectedPhysicalUnit = bu.BASE_UNIT;
    this.calculateTotalUnits();
  }

  getQualifyUnits() {
    this.Hcpcscallservice.GetMethod('/HCPCS/GetQualifyUnitsdata').subscribe(
      (res: any) => {
        this.qualifyUnits = res;
        this.dropdownSettings = {
          singleSelection: false,
          idField: 'QUALIFY_CIRCUM',
          textField: 'QUALIFY_CIRCUM',
          selectAllText: 'Select All',
          unSelectAllText: 'UnSelect All',
          itemsShowLimit: 1,
          allowSearchFilter: true
        }
        // const defSelectedBU = this.qualifyUnits[0].BASE_UNITS;
        // const defSelectedQC = this.qualifyUnits[0].QUALIFY_CIRCUM;
        // this.qualifyUnitsData = [
        //   { BASE_UNITS: defSelectedBU, QUALIFY_CIRCUM: defSelectedQC },
        // ];
        this.selectedQualifyUnit = 0;
        this.calculateTotalUnits();
      },
      error => { }
    )
  }

  onQValueChanged(e: any): void {
    const newValue = e;
    var bu = this.qualifyUnits.find(e => e.QUALIFY_CIRCUM == newValue);
    this.selectedQualifyUnit += bu.BASE_UNITS;
    this.calculateTotalUnits();
  }

  onSelectAll(items: any): void {
    this.selectedQualifyUnit = 0;
    for (var val of items) {
      var bu = this.qualifyUnits.find(e => e.QUALIFY_CIRCUM == val);
      this.selectedQualifyUnit += bu.BASE_UNITS;
    }
    this.calculateTotalUnits();
  }

  onDeSelect(item: any) {
    var bu = this.qualifyUnits.find(e => e.QUALIFY_CIRCUM == item);
    this.selectedQualifyUnit -= bu.BASE_UNITS;
    this.calculateTotalUnits();
  }

  onDeSelectAll(deSelectedList: Array<string>): void {
    this.selectedQualifyUnit = 0;
    this.calculateTotalUnits();
  }

  calculateTotalUnits(): void {
    this.totalUnits = this.selectedPhysicalUnit! + this.selectedQualifyUnit! + this.enteredUnit! + this.anesBaseUnit!;
  }

  calculateFeeAnesthesia(): void {
    this.calculatedFeeValue = this.totalUnits! * this.anesConversionFactor!;
  }
  maidescdata: any;
  MaiDescClick(Maidata) {
    this.MaiDescriptiondata = Maidata;

  }
  CodeStatusClick(data) {
    this.CodeStatusData = data;
  }
  GlobalPeriod(data) {
    this.GolbalPerioddata = data;
  }
  Radiologyclick(data) {
    this.Radiologydata = data;
  }
  PCTCclick(data) {
    this.PCTCdata = data;
  }
  MULTPROCclick(data) {
    this.MULTPROCdata = data;
  }
  BILATSURGclick(data) {
    this.BILATSURGdata = data;
  }
  ASSTSURGclick(data) {
    this.ASSTSURGdata = data;
  }
  COSURGclick(data) {
    this.COSURGdata = data;
  }
  TEAMSURGclick(data) {
    this.TEAMSURGdata = data;
  }
  PHYSNclick(data) {
    this.PHYSNdata = data;
  }
  MueEdits() {
    this.UnlikelyEdits = '';
    this.notFound = false;
    if (this.codeInformation.CODE != undefined) {
      this.Hcpcscallservice.GetMethod('/HCPCS/GetMueData?Code=' + this.codeInformation.CODE).subscribe(
        (res: any) => {
          this.UnlikelyEdits = res;
        },
        error => { }
      )
      this.Hcpcscallservice.GetMethod('/HCC/getmaidata').subscribe(
        (res: any) => {
          this.maidescdata = res;
        },
        error => { }
      )
    }
  }
  FeeScheduleClick() {
    this.FeeSchedules = [];
    this.MedicareCarrier = null;
    this.FeeSchedulehide = true;
    this.Hcpcscallservice.GetMethod('/HCPCS/GetMedicareCarrierdata').subscribe(
      (res: any) => {
        this.MedicareCarrier = res;
        this.Medicaredata = this.MedicareCarrier[0].LOCALITY_VALUE;
        this.CalculateClick();
      },
      error => { }
    )
  }
  CalculateClick() {
    this.Hcpcscallservice.GetMethod('/HCPCS/GetFeeScheduleData?Code=' + this.codeInformation.CODE + '&Medicare=' + this.Medicaredata).subscribe(
      (res: any) => {
        this.noMPFS = false;
        if (res.length > 0) {
          this.FeeSchedules = [];
          this.twodata = [];
          this.fivedata = [];
          this.tcdata = [];
          let count = res.length;
          if (count > 0) {
            this.FeeSchedules = res[0];
            this.FeeSchedulehide = false;
          } else {
            this.FeeSchedulehide = true;
          }
          if (count > 1) {
            if (res[1].MOD == 'TC') {
              this.tcdata = res[1];
            } else if (res[1].MOD == '26') {
              this.twodata = res[1];
            } else if (res[1].MOD == '53') {
              this.fivedata = res[1];
            }
          }
          if (count > 2) {
            if (res[2].MOD == 'TC') {
              this.tcdata = res[2];
            } else if (res[2].MOD == '26') {
              this.twodata = res[2];
            } else if (res[2].MOD == '53') {
              this.fivedata = res[2];
            }
          }
          if (count > 3) {
            if (res[3].MOD == '26') {
              this.tcdata = res[3];
            } else if (res[3].MOD == '26') {
              this.twodata = res[3];
            } else if (res[3].MOD == '53') {
              this.fivedata = res[3];
            }
          }
        }
        else {
          this.noMPFS = true;
        }
      },
      error => { }
    )
  }
  InstructionalNotesClick() {
    this.noInstructionalNotes = false;
    if (this.codeInformation.CODE != undefined) {
      this.Hcpcscallservice.GetMethod('/HCPCS/GetInstructionalNotes?Code=' + this.codeInformation.CODE).subscribe(
        (res: any) => {
          if (res.length > 0) {
            this.InstructionalNotes = JSON.parse(res);
            let CNInclude: any = [];
            let CRInclude: any = [];
            let BNInclude: any = [];

            let CNExclude1: any = [];
            let CNExclude2: any = [];

            let CRExclude1: any = [];
            let CRExclude2: any = [];

            let BNExclude1: any = [];
            let BNExclude2: any = [];

            let CNOthers: any = [];
            let CROthers: any = [];
            let BNOthers: any = [];

            let cloneInstructionalCRData: any = [];
            let cloneInstructionalCNData: any = [];
            let cloneInstructionalBNData: any = [];

            this.finalChapterNotes = [];
            this.finalCodeRangeNotes = [];
            this.finalBlockNotes = [];

            if (this.InstructionalNotes.chapterNotes.subSection.length > 0) {
              for (let i = 0; i < this.InstructionalNotes.chapterNotes.subSection[0].note.length; i++) {

                if (this.InstructionalNotes.chapterNotes.subSection[0].note[i].startsWith('Includes')) {
                  CNInclude.push(this.InstructionalNotes.chapterNotes.subSection[0].note[i]);
                }
                else if (this.InstructionalNotes.chapterNotes.subSection[0].note[i].startsWith('Excludes 1')) {
                  CNExclude1.push(this.InstructionalNotes.chapterNotes.subSection[0].note[i]);
                }
                else if (this.InstructionalNotes.chapterNotes.subSection[0].note[i].startsWith('Excludes 2')) {
                  CNExclude2.push(this.InstructionalNotes.chapterNotes.subSection[0].note[i]);
                }
                else {
                  CNOthers.push(this.InstructionalNotes.chapterNotes.subSection[0].note[i]);
                }
              }
            }
            if (CNInclude.length > 0 || CNExclude1.length > 0 || CNExclude2.length > 0 || CNOthers.length > 0) {
              for (let i = 0; i < CNInclude.length; i++) {
                if (CNInclude[i].match('Includes header:')) {
                  CNInclude[i] = CNInclude[i].replace('Includes header:', '');
                  CNInclude[i] = CNInclude[i].charAt(0).toUpperCase() + CNInclude[i].slice(1);
                  CNInclude[i] = CNInclude[i].bold();
                }
                else if (CNInclude[i].match('Includes:')) {
                  CNInclude[i] = CNInclude[i].replace('Includes:', '');
                  CNInclude[i] = CNInclude[i].charAt(0).toUpperCase() + CNInclude[i].slice(1);
                  // CNInclude[i] = '\xa0\xa0\xa0\xa0\xa0\xa0\xa0'.concat(CNInclude[i]);
                }
              }
              for (let i = 0; i < CNExclude1.length; i++) {
                if (CNExclude1[i].match('Excludes 1 header:')) {
                  CNExclude1[i] = CNExclude1[i].replace('Excludes 1 header:', '');
                  CNExclude1[i] = CNExclude1[i].charAt(0).toUpperCase() + CNExclude1[i].slice(1);
                  CNExclude1[i] = CNExclude1[i].bold();
                }
                else if (CNExclude1[i].match('Excludes 1:')) {
                  CNExclude1[i] = CNExclude1[i].replace('Excludes 1:', '');
                  CNExclude1[i] = CNExclude1[i].charAt(0).toUpperCase() + CNExclude1[i].slice(1);
                  // CNExclude1[i] = '\xa0\xa0\xa0\xa0\xa0\xa0\xa0'.concat(CNExclude1[i]);
                }
              }
              for (let i = 0; i < CNExclude2.length; i++) {
                if (CNExclude2[i].match('Excludes 2 header:')) {
                  CNExclude2[i] = CNExclude2[i].replace('Excludes 2 header:', '');
                  CNExclude2[i] = CNExclude2[i].charAt(0).toUpperCase() + CNExclude2[i].slice(1);
                  CNExclude2[i] = CNExclude2[i].bold();
                }
                else if (CNExclude2[i].match('Excludes 2:')) {
                  CNExclude2[i] = CNExclude2[i].replace('Excludes 2:', '');
                  CNExclude2[i] = CNExclude2[i].charAt(0).toUpperCase() + CNExclude2[i].slice(1);
                  // CNExclude2[i] = '\xa0\xa0\xa0\xa0\xa0\xa0\xa0'.concat(CNExclude2[i]);
                }
              }
              this.InstructionalNotes.chapterNotes.subSection[0].note = [];
              if (CNInclude.length > 0) {
                this.InstructionalNotes.chapterNotes.subSection[0].note = this.InstructionalNotes.chapterNotes.subSection[0].note.concat("INCLUDES :");
                this.InstructionalNotes.chapterNotes.subSection[0].note = this.InstructionalNotes.chapterNotes.subSection[0].note.concat(CNInclude);
              }

              if (CNExclude1.length > 0) {
                this.InstructionalNotes.chapterNotes.subSection[0].note = this.InstructionalNotes.chapterNotes.subSection[0].note.concat("EXCLUDES 1:");
                this.InstructionalNotes.chapterNotes.subSection[0].note = this.InstructionalNotes.chapterNotes.subSection[0].note.concat(CNExclude1);
              }
              if (CNExclude2.length > 0) {
                this.InstructionalNotes.chapterNotes.subSection[0].note = this.InstructionalNotes.chapterNotes.subSection[0].note.concat("EXCLUDES 2:");
                this.InstructionalNotes.chapterNotes.subSection[0].note = this.InstructionalNotes.chapterNotes.subSection[0].note.concat(CNExclude2);
              }
              this.InstructionalNotes.chapterNotes.subSection[0].note = this.InstructionalNotes.chapterNotes.subSection[0].note.concat(CNOthers);
            }

            if(this.InstructionalNotes.chapterNotes.subSection.length>0){
              cloneInstructionalCNData = this.InstructionalNotes.chapterNotes.subSection[0].note.concat();
            }

            
            if (cloneInstructionalCNData.length > 0) {
              let replacedSymbols: any = [];
              let codesInParanthesis: any = [];
              let codesInPipe: any = [];
              for (let i = 0; i < cloneInstructionalCNData.length; i++) {

                if (cloneInstructionalCNData[i].includes('|')) {
                  codesInPipe = cloneInstructionalCNData[i].split("|")[0];
                  codesInPipe = codesInPipe.replace(/-/g, ',');
                  replacedSymbols.push(codesInPipe);
                }
                if (cloneInstructionalCNData[i].includes('(')) {
                  cloneInstructionalCNData[i] = cloneInstructionalCNData[i].replace(/-/g, ',');
                  replacedSymbols.push(cloneInstructionalCNData[i]);
                }
              }
              for (let i = 0; i < replacedSymbols.length; i++) {
                if (replacedSymbols[i].includes('(')) {
                  let codesInBetweenParanthesis = replacedSymbols[i].indexOf("(") + 1;
                  var sep = replacedSymbols[i].slice(codesInBetweenParanthesis, replacedSymbols[i].indexOf(")"));
                  if (sep.length >= 3) {
                    codesInParanthesis.push(sep);
                  }
                }
                else {
                  let pipeCodes1 = replacedSymbols[i].split(",")[0];
                  let pipeCodes2 = replacedSymbols[i].split(",")[1];
                  codesInParanthesis.push(pipeCodes1);
                  codesInParanthesis.push(pipeCodes2);
                }
              }
              if (codesInParanthesis.length > 0) {
                codesInParanthesis = codesInParanthesis.toString().replace(/"/g, "").replace(/'/g, "").replace(/\(|\)/g, "");
                let codesInGuideString = codesInParanthesis.toString().split(" ");
                let noDuplicate: any = [];
                noDuplicate = Array.from(new Set(codesInGuideString.toString().split(',')));
                noDuplicate = noDuplicate.filter(this.notEmpty);
                // function notEmpty(value) {
                //   return value !== "";
                // }
                noDuplicate = noDuplicate.sort();
                noDuplicate = noDuplicate.reverse();
                this.htmlToAdd = '';
                this.finalChapterNotes = [];
                let indexForCN: any = [];
                for (let i = 0; i < this.InstructionalNotes.chapterNotes.subSection[0].note.length; i++) {
                  for (let j = 0; j < noDuplicate.length; j++) {
                    if (this.InstructionalNotes.chapterNotes.subSection[0].note[i].includes(noDuplicate[j])) {
                      var index = (this.InstructionalNotes.chapterNotes.subSection[0].note[i].indexOf(noDuplicate[j]));
                      let decimal = /^[0-9]+([,.][0-9]+)?$/g.test(noDuplicate[j]);
                      let alphaDecimal = /^[0-9A-Z]+([,.][0-9A-Z]+)?$/g.test(noDuplicate[j]);
                      let alphabets = /^[a-zA-Z]+$/.test(noDuplicate[j]);
                      indexForCN = this.findAllIndexOfCode(this.InstructionalNotes.chapterNotes.subSection[0].note[i], noDuplicate[j]);
                      for (let k = 0; k < indexForCN.length; k++) {
                        if (~indexForCN[k] && (decimal || alphaDecimal)) {
                          if (!alphabets) {
                            var anchorCloseTag = this.InstructionalNotes.chapterNotes.subSection[0].note[i].substr(indexForCN[k] - 1, 1);
                            var equalSign = this.InstructionalNotes.chapterNotes.subSection[0].note[i].substr(indexForCN[k] - 8, 1);
                            var questionSign = this.InstructionalNotes.chapterNotes.subSection[0].note[i].substr(indexForCN[k] - 5, 1);
                            if (anchorCloseTag != '>' && anchorCloseTag != '=' && equalSign != '=' && questionSign != '?') {
                              let codeLength = indexForCN[k] + noDuplicate[j].length;
                              var output = [this.InstructionalNotes.chapterNotes.subSection[0].note[i].slice(0, indexForCN[k]), this.InstructionalNotes.chapterNotes.subSection[0].note[i].slice(indexForCN[k], codeLength), "</a>", this.InstructionalNotes.chapterNotes.subSection[0].note[i].slice(codeLength)].join('');
                              var finalFormat = [output.slice(0, indexForCN[k]), '<a href=#/codeinfo?Code=' + noDuplicate[j] + '&CodeType=' + 'ICD-CM' + '>', output.slice(indexForCN[k])].join('');
                              this.InstructionalNotes.chapterNotes.subSection[0].note[i] = '';
                              this.InstructionalNotes.chapterNotes.subSection[0].note[i] = finalFormat;
                              this.finalChapterNotes[i] = this.InstructionalNotes.chapterNotes.subSection[0].note[i];

                              if(this.InstructionalNotes.chapterNotes.subSection[0].header && this.finalChapterNotes){
                                
                                for(let i=0;i<this.finalChapterNotes.length;i++){
                                  let subPortion = this.InstructionalNotes.chapterNotes.subSection[0].header.split('(')[0];
                                  if(this.finalChapterNotes[i].includes(subPortion)){
                                    
                                    this.InstructionalNotes.chapterNotes.subSection[0].header = '';
                                    
                                    this.InstructionalNotes.chapterNotes.subSection[0].header = this.finalChapterNotes[i].concat();
                                  }
                                }
                              }
                            }
                          }
                        }
                        if (~indexForCN[k] && (!decimal && !alphaDecimal)) {
                          let alphabetsAndDot = /^[a-zA-Z\.]+$/.test(noDuplicate[j]);
                          let alphabets = /^[a-zA-Z]+$/.test(noDuplicate[j]);
                          if (!alphabets && !alphabetsAndDot) {
                            let numberValue = '';
                            let DecimalValue = '';
                            numberValue = noDuplicate[j].toString().split(".")[0];
                            DecimalValue = noDuplicate[j].toString().split(".")[1];
                            if (numberValue != undefined || numberValue != "" && (DecimalValue == "" || DecimalValue == '' || DecimalValue == null)) {
                              noDuplicate[j] = '';
                              noDuplicate[j] = numberValue;
                            }
                            var anchorCloseTag = this.InstructionalNotes.chapterNotes.subSection[0].note[i].substr(indexForCN[k] - 1, 1);
                            var equalSign = this.InstructionalNotes.chapterNotes.subSection[0].note[i].substr(indexForCN[k] - 8, 1);
                            var questionSign = this.InstructionalNotes.chapterNotes.subSection[0].note[i].substr(indexForCN[k] - 5, 1);
                            if (anchorCloseTag != '>' && anchorCloseTag != '=' && equalSign != '=' && questionSign != '?') {
                              let codeLength = indexForCN[k] + noDuplicate[j].length;
                              var output = [this.InstructionalNotes.chapterNotes.subSection[0].note[i].slice(0, indexForCN[k]), this.InstructionalNotes.chapterNotes.subSection[0].note[i].slice(indexForCN[k], codeLength), "</a>", this.InstructionalNotes.chapterNotes.subSection[0].note[i].slice(codeLength)].join('');
                              var finalFormat = [output.slice(0, indexForCN[k]), '<a href=#/codeinfo?Code=' + noDuplicate[j] + '&CodeType=' + 'ICD-CM' + '>', output.slice(indexForCN[k])].join('');
                              this.InstructionalNotes.chapterNotes.subSection[0].note[i] = '';
                              this.InstructionalNotes.chapterNotes.subSection[0].note[i] = finalFormat;
                              this.finalChapterNotes[i] = this.InstructionalNotes.chapterNotes.subSection[0].note[i];

                              if(this.InstructionalNotes.chapterNotes.subSection[0].header && this.finalChapterNotes){
                                
                                for(let i=0;i<this.finalChapterNotes.length;i++){
                                  let subPortion = this.InstructionalNotes.chapterNotes.subSection[0].header.split('(')[0];
                                  if(this.finalChapterNotes[i].includes(subPortion)){
                                    
                                    this.InstructionalNotes.chapterNotes.subSection[0].header = '';
                                    
                                    this.InstructionalNotes.chapterNotes.subSection[0].header = this.finalChapterNotes[i].concat();
                                  }
                                }
                              }

                            }
                          }
                        }
                      }
                     
                    }
                    else {
                      this.finalChapterNotes[i] = this.InstructionalNotes.chapterNotes.subSection[0].note[i];
                    }
                  }
                }
              }
              else {
                this.finalChapterNotes = this.InstructionalNotes.chapterNotes.subSection[0].note;
              }
            }

            // FOR CODE RANGE NOTES :

            if (this.InstructionalNotes.codeRangeNotes.subSection.length > 0) {
              for (let i = 0; i < this.InstructionalNotes.codeRangeNotes.subSection[0].note.length; i++) {
                if (this.InstructionalNotes.codeRangeNotes.subSection[0].note[i].startsWith('Includes')) {
                  CRInclude.push(this.InstructionalNotes.codeRangeNotes.subSection[0].note[i]);
                }
                else if (this.InstructionalNotes.codeRangeNotes.subSection[0].note[i].startsWith('Excludes 1')) {
                  CRExclude1.push(this.InstructionalNotes.codeRangeNotes.subSection[0].note[i]);
                }
                else if (this.InstructionalNotes.codeRangeNotes.subSection[0].note[i].startsWith('Excludes 2')) {

                  CRExclude2.push(this.InstructionalNotes.codeRangeNotes.subSection[0].note[i]);
                }
                else {
                  CROthers.push(this.InstructionalNotes.codeRangeNotes.subSection[0].note[i]);
                }
              }
            }

            if (CRInclude.length > 0 || CRExclude1.length > 0 || CRExclude2.length > 0 || CROthers.length > 0) {

              for (let i = 0; i < CRInclude.length; i++) {
                if (CRInclude[i].match('Includes header:')) {
                  CRInclude[i] = CRInclude[i].replace('Includes header:', '');
                  CRInclude[i] = CRInclude[i].charAt(0).toUpperCase() + CRInclude[i].slice(1);
                  CRInclude[i] = CRInclude[i].bold();
                }
                else if (CRInclude[i].match('Includes:')) {
                  CRInclude[i] = CRInclude[i].replace('Includes:', '');
                  CRInclude[i] = CRInclude[i].charAt(0).toUpperCase() + CRInclude[i].slice(1);
                  // CRInclude[i] = '\xa0\xa0\xa0\xa0\xa0\xa0\xa0'.concat(CRInclude[i]);
                }
              }
              for (let i = 0; i < CRExclude1.length; i++) {
                if (CRExclude1[i].match('Excludes 1 header:')) {

                  CRExclude1[i] = CRExclude1[i].replace('Excludes 1 header:', '');
                  CRExclude1[i] = CRExclude1[i].charAt(0).toUpperCase() + CRExclude1[i].slice(1);
                  CRExclude1[i] = CRExclude1[i].bold();
                }
                else if (CRExclude1[i].match('Excludes 1:')) {

                  CRExclude1[i] = CRExclude1[i].replace('Excludes 1:', '');
                  CRExclude1[i] = CRExclude1[i].charAt(0).toUpperCase() + CRExclude1[i].slice(1);
                  // CRExclude1[i] = '\xa0\xa0\xa0\xa0\xa0\xa0\xa0'.concat(CRExclude1[i]);
                }
              }
              for (let i = 0; i < CRExclude2.length; i++) {
                if (CRExclude2[i].match('Excludes 2 header:')) {

                  CRExclude2[i] = CRExclude2[i].replace('Excludes 2 header:', '');
                  CRExclude2[i] = CRExclude2[i].charAt(0).toUpperCase() + CRExclude2[i].slice(1);
                  CRExclude2[i] = CRExclude2[i].bold();
                }
                else if (CRExclude2[i].match('Excludes 2:')) {

                  CRExclude2[i] = CRExclude2[i].replace('Excludes 2:', '');
                  CRExclude2[i] = CRExclude2[i].charAt(0).toUpperCase() + CRExclude2[i].slice(1);
                  // CRExclude2[i] = '\xa0\xa0\xa0\xa0\xa0\xa0\xa0'.concat(CRExclude2[i]);
                }
              }
              this.InstructionalNotes.codeRangeNotes.subSection[0].note = [];
              if (CRInclude.length > 0) {

                this.InstructionalNotes.codeRangeNotes.subSection[0].note = this.InstructionalNotes.codeRangeNotes.subSection[0].note.concat("INCLUDES :");
                this.InstructionalNotes.codeRangeNotes.subSection[0].note = this.InstructionalNotes.codeRangeNotes.subSection[0].note.concat(CRInclude);
              }
              if (CRExclude1.length > 0) {
                this.InstructionalNotes.codeRangeNotes.subSection[0].note = this.InstructionalNotes.codeRangeNotes.subSection[0].note.concat("EXCLUDES 1:");
                this.InstructionalNotes.codeRangeNotes.subSection[0].note = this.InstructionalNotes.codeRangeNotes.subSection[0].note.concat(CRExclude1);
              }
              if (CRExclude2.length > 0) {
                this.InstructionalNotes.codeRangeNotes.subSection[0].note = this.InstructionalNotes.codeRangeNotes.subSection[0].note.concat("EXCLUDES 2:");
                this.InstructionalNotes.codeRangeNotes.subSection[0].note = this.InstructionalNotes.codeRangeNotes.subSection[0].note.concat(CRExclude2);
              }
              this.InstructionalNotes.codeRangeNotes.subSection[0].note = this.InstructionalNotes.codeRangeNotes.subSection[0].note.concat(CROthers);
            }

            if(this.InstructionalNotes.codeRangeNotes.subSection.length>0){
              cloneInstructionalCRData = this.InstructionalNotes.codeRangeNotes.subSection[0].note.concat();
            }
            
            if (cloneInstructionalCRData.length > 0) {
              let replacedSymbols: any = [];
              let codesInParanthesis: any = [];
              for (let i = 0; i < cloneInstructionalCRData.length; i++) {
                // cloneInstructionalCRData[i] = cloneInstructionalCRData[i].replace(/[\[\]']+/g, '');
                cloneInstructionalCRData[i] = cloneInstructionalCRData[i].replace(/-/g, ',');
                cloneInstructionalCRData[i] = cloneInstructionalCRData[i].replace(/\s*,\s*/g, ",");
                replacedSymbols.push(cloneInstructionalCRData[i]);
              }
              for (let i = 0; i < replacedSymbols.length; i++) {
                if (replacedSymbols[i].includes('(')) {
                  var reBrackets = /\((.*?)\)/g;
                  var listOfText = [];
                  var found;
                  while (found = reBrackets.exec(replacedSymbols[i])) {
                    listOfText.push(found[1]);
                  };
                  if (listOfText.length > 0) {
                    for (let i = 0; i < listOfText.length; i++) {
                      if (listOfText[i].length >= 3) {
                        codesInParanthesis.push(listOfText[i]);
                      }
                    }
                  }
                }
              }
              if (codesInParanthesis.length > 0) {
                let codesInGuideString = codesInParanthesis.toString().replace(/"/g, "").replace(/'/g, "").replace(/\(|\)/g, "");
                // let codesInGuideString = codesInParanthesis.toString().split(" ");
                let noDuplicate: any = [];
                noDuplicate = Array.from(new Set(codesInGuideString.toString().split(',')));
                noDuplicate = noDuplicate.filter(this.notEmpty);
                // function notEmpty(value) {
                //   return value !== "";
                // }
                noDuplicate = noDuplicate.sort();
                noDuplicate = noDuplicate.reverse();
                this.htmlToAdd = '';
                this.finalCodeRangeNotes = [];
                let indexForCR :any =[];
                for (let i = 0; i < this.InstructionalNotes.codeRangeNotes.subSection[0].note.length; i++) {
                  for (let j = 0; j < noDuplicate.length; j++) {
                    if (this.InstructionalNotes.codeRangeNotes.subSection[0].note[i].includes(noDuplicate[j])) {
                      var index = (this.InstructionalNotes.codeRangeNotes.subSection[0].note[i].indexOf(noDuplicate[j]));
                      // var alphaNumeric = /^[0-9a-zA-Z]+$/.test(noDuplicate[j]);
                      //  alphadecimal previous working fine    /^[0-9A-Z]+([,.][0-9A-Z]+)?$/g.test(noDuplicate[j])
                      let decimal = /^[0-9]+([,.][0-9]+)?$/g.test(noDuplicate[j]);
                      let alphaDecimal = /^[0-9A-Z]+([,.][0-9A-Z]+)?$/g.test(noDuplicate[j]);
                      let alphabets = /^[a-zA-Z]+$/.test(noDuplicate[j]);
                      indexForCR = this.findAllIndexOfCode(this.InstructionalNotes.codeRangeNotes.subSection[0].note[i], noDuplicate[j]);
                      for (let k = 0; k < indexForCR.length; k++) {
                        if (~indexForCR[k] && (decimal || alphaDecimal)) {
                          if (!alphabets) {
                            var anchorCloseTag = this.InstructionalNotes.codeRangeNotes.subSection[0].note[i].substr(indexForCR[k] - 1, 1);
                            var equalSign = this.InstructionalNotes.codeRangeNotes.subSection[0].note[i].substr(indexForCR[k] - 8, 1);
                            var questionSign = this.InstructionalNotes.codeRangeNotes.subSection[0].note[i].substr(indexForCR[k] - 5, 1);
                            
                            if (anchorCloseTag != '>' && anchorCloseTag != '=' && equalSign != '=' && questionSign != '?') {
                              
                              let codeLength = indexForCR[k] + noDuplicate[j].length;
                              var output = [this.InstructionalNotes.codeRangeNotes.subSection[0].note[i].slice(0, indexForCR[k]), this.InstructionalNotes.codeRangeNotes.subSection[0].note[i].slice(indexForCR[k], codeLength), "</a>", this.InstructionalNotes.codeRangeNotes.subSection[0].note[i].slice(codeLength)].join('');
                              var finalFormat = [output.slice(0, indexForCR[k]), '<a href=#/codeinfo?Code=' + noDuplicate[j] + '&CodeType=' + 'ICD-CM' + '>', output.slice(indexForCR[k])].join('');
                              this.InstructionalNotes.codeRangeNotes.subSection[0].note[i] = '';
                              this.InstructionalNotes.codeRangeNotes.subSection[0].note[i] = finalFormat;
                              this.finalCodeRangeNotes[i] = this.InstructionalNotes.codeRangeNotes.subSection[0].note[i];
                              
                              if(this.InstructionalNotes.codeRangeNotes.subSection[0].header && this.finalCodeRangeNotes){
                                for(let i=0;i<this.finalCodeRangeNotes.length;i++){
                                  let subPortion = this.InstructionalNotes.codeRangeNotes.subSection[0].header.split('(')[0];
                                  if(this.finalCodeRangeNotes[i].includes(subPortion)){
                                    
                                    this.InstructionalNotes.codeRangeNotes.subSection[0].header = '';
                                    
                                    this.InstructionalNotes.codeRangeNotes.subSection[0].header = this.finalCodeRangeNotes[i].concat();
                                  }
                                }
                              }

                            }
                          }
                        }
                        if (~indexForCR[k] && (!decimal && !alphaDecimal)) {
                          
                          let alphabetsAndDot = /^[a-zA-Z\.]+$/.test(noDuplicate[j]);
                          let alphabets = /^[a-zA-Z]+$/.test(noDuplicate[j]);
                          if (!alphabets && !alphabetsAndDot) {
                            let numberValue = '';
                            let DecimalValue = '';
                            numberValue = noDuplicate[j].toString().split(".")[0];
                            DecimalValue = noDuplicate[j].toString().split(".")[1];
                            if (numberValue != undefined || numberValue != "" && (DecimalValue == "" || DecimalValue == '' || DecimalValue == null)) {
                              noDuplicate[j] = '';
                              noDuplicate[j] = numberValue;
                            }
                            var anchorCloseTag = this.InstructionalNotes.codeRangeNotes.subSection[0].note[i].substr(indexForCR[k] - 1, 1);
                            var equalSign = this.InstructionalNotes.codeRangeNotes.subSection[0].note[i].substr(indexForCR[k] - 8, 1);
                            var questionSign = this.InstructionalNotes.codeRangeNotes.subSection[0].note[i].substr(indexForCR[k] - 5, 1);
                            
                            if (anchorCloseTag != '>' && anchorCloseTag != '=' && equalSign != '=' && questionSign != '?') {
                              let codeLength = indexForCR[k] + noDuplicate[j].length;
                              var output = [this.InstructionalNotes.codeRangeNotes.subSection[0].note[i].slice(0, indexForCR[k]), this.InstructionalNotes.codeRangeNotes.subSection[0].note[i].slice(indexForCR[k], codeLength), "</a>", this.InstructionalNotes.codeRangeNotes.subSection[0].note[i].slice(codeLength)].join('');
                              
                              var finalFormat = [output.slice(0, indexForCR[k]), '<a href=#/codeinfo?Code=' + noDuplicate[j] + '&CodeType=' + 'ICD-CM' + '>', output.slice(indexForCR[k])].join('');
                              
                              this.InstructionalNotes.codeRangeNotes.subSection[0].note[i] = '';
                              this.InstructionalNotes.codeRangeNotes.subSection[0].note[i] = finalFormat;
                              this.finalCodeRangeNotes[i] = this.InstructionalNotes.codeRangeNotes.subSection[0].note[i];

                              if(this.InstructionalNotes.codeRangeNotes.subSection[0].header && this.finalCodeRangeNotes){
                                for(let i=0;i<this.finalCodeRangeNotes.length;i++){
                                  let subPortion = this.InstructionalNotes.codeRangeNotes.subSection[0].header.split('(')[0];
                                  if(this.finalCodeRangeNotes[i].includes(subPortion)){
                                    
                                    this.InstructionalNotes.codeRangeNotes.subSection[0].header = '';
                                    
                                    this.InstructionalNotes.codeRangeNotes.subSection[0].header = this.finalCodeRangeNotes[i].concat();
                                  }
                                }
                              }

                            }
                          }
                        }
                      }
                     
                    }
                    else {
                      this.finalCodeRangeNotes[i] = this.InstructionalNotes.codeRangeNotes.subSection[0].note[i];
                    }
                  }
                }
              }
              else {
                this.finalCodeRangeNotes = this.InstructionalNotes.codeRangeNotes.subSection[0].note;
              }
            }

            // FOR BLOCK NOTES

            if (this.InstructionalNotes.sectionNotes.subSection.length > 0) {
              for (let i = 0; i < this.InstructionalNotes.sectionNotes.subSection[0].note.length; i++) {

                if (this.InstructionalNotes.sectionNotes.subSection[0].note[i].startsWith('Includes')) {
                  BNInclude.push(this.InstructionalNotes.sectionNotes.subSection[0].note[i]);
                }
                else if (this.InstructionalNotes.sectionNotes.subSection[0].note[i].startsWith('Excludes 1')) {
                  BNExclude1.push(this.InstructionalNotes.sectionNotes.subSection[0].note[i]);
                }
                else if (this.InstructionalNotes.sectionNotes.subSection[0].note[i].startsWith('Excludes 2')) {
                  
                  BNExclude2.push(this.InstructionalNotes.sectionNotes.subSection[0].note[i]);
                }
                else {
                  BNOthers.push(this.InstructionalNotes.sectionNotes.subSection[0].note[i]);
                }
              }
            }
            if (BNInclude.length > 0 || BNExclude1.length > 0 || BNExclude2.length > 0 || BNOthers.length > 0) {
              for (let i = 0; i < BNInclude.length; i++) {
                if (BNInclude[i].match('Includes header:')) {
                  BNInclude[i] = BNInclude[i].replace('Includes header:', '');
                  BNInclude[i] = BNInclude[i].charAt(0).toUpperCase() + BNInclude[i].slice(1);
                  BNInclude[i] = BNInclude[i].bold();
                }
                else if (BNInclude[i].match('Includes:')) {
                  BNInclude[i] = BNInclude[i].replace('Includes:', '');
                  BNInclude[i] = BNInclude[i].charAt(0).toUpperCase() + BNInclude[i].slice(1);
                }
              }
              for (let i = 0; i < BNExclude1.length; i++) {
                if (BNExclude1[i].match('Excludes 1 header:')) {
                  BNExclude1[i] = BNExclude1[i].replace('Excludes 1 header:', '');
                  BNExclude1[i] = BNExclude1[i].charAt(0).toUpperCase() + BNExclude1[i].slice(1);
                  BNExclude1[i] = BNExclude1[i].bold();
                }
                else if (BNExclude1[i].match('Excludes 1:')) {
                  BNExclude1[i] = BNExclude1[i].replace('Excludes 1:', '');
                  BNExclude1[i] = BNExclude1[i].charAt(0).toUpperCase() + BNExclude1[i].slice(1);
                }
              }
              for (let i = 0; i < BNExclude2.length; i++) {
                if (BNExclude2[i].match('Excludes 2 header:')) {
                  BNExclude2[i] = BNExclude2[i].replace('Excludes 2 header:', '');
                  BNExclude2[i] = BNExclude2[i].charAt(0).toUpperCase() + BNExclude2[i].slice(1);
                  BNExclude2[i] = BNExclude2[i].bold();
                }
                else if (BNExclude2[i].match('Excludes 2:')) {
                  BNExclude2[i] = BNExclude2[i].replace('Excludes 2:', '');
                  BNExclude2[i] = BNExclude2[i].charAt(0).toUpperCase() + BNExclude2[i].slice(1);
                }
              }
              this.InstructionalNotes.sectionNotes.subSection[0].note = [];
              if (BNInclude.length > 0) {
                this.InstructionalNotes.sectionNotes.subSection[0].note = this.InstructionalNotes.sectionNotes.subSection[0].note.concat("INCLUDES :");
                this.InstructionalNotes.sectionNotes.subSection[0].note = this.InstructionalNotes.sectionNotes.subSection[0].note.concat(BNInclude);
              }

              if (BNExclude1.length > 0) {
                this.InstructionalNotes.sectionNotes.subSection[0].note = this.InstructionalNotes.sectionNotes.subSection[0].note.concat("EXCLUDES 1:");
                this.InstructionalNotes.sectionNotes.subSection[0].note = this.InstructionalNotes.sectionNotes.subSection[0].note.concat(BNExclude1);
              }
              if (BNExclude2.length > 0) {
                this.InstructionalNotes.sectionNotes.subSection[0].note = this.InstructionalNotes.sectionNotes.subSection[0].note.concat("EXCLUDES 2:");
                this.InstructionalNotes.sectionNotes.subSection[0].note = this.InstructionalNotes.sectionNotes.subSection[0].note.concat(BNExclude2);
              }
              this.InstructionalNotes.sectionNotes.subSection[0].note = this.InstructionalNotes.sectionNotes.subSection[0].note.concat(BNOthers);
            }

            if(this.InstructionalNotes.sectionNotes.subSection.length>0){
              cloneInstructionalBNData = this.InstructionalNotes.sectionNotes.subSection[0].note.concat();
            }
            
            if (cloneInstructionalBNData.length > 0) {
              let replacedSymbols: any = [];
              let codesInParanthesis: any = [];
              for (let i = 0; i < cloneInstructionalBNData.length; i++) {
                cloneInstructionalBNData[i] = cloneInstructionalBNData[i].replace(/-/g, ',');
                cloneInstructionalBNData[i] = cloneInstructionalBNData[i].replace(/\s*,\s*/g, ",");
                replacedSymbols.push(cloneInstructionalBNData[i]);
              }
              for (let i = 0; i < replacedSymbols.length; i++) {
                if (replacedSymbols[i].includes('(')) {
                  var reBrackets = /\((.*?)\)/g;
                  var listOfText = [];
                  var found;
                  while (found = reBrackets.exec(replacedSymbols[i])) {
                    listOfText.push(found[1]);
                  };
                  if (listOfText.length > 0) {
                    for (let i = 0; i < listOfText.length; i++) {
                      if (listOfText[i].length >= 3) {
                        codesInParanthesis.push(listOfText[i]);
                      }
                    }
                  }
                }
              }
              if (codesInParanthesis.length > 0) {
                let codesInGuideString = codesInParanthesis.toString().replace(/"/g, "").replace(/'/g, "").replace(/\(|\)/g, "");
                // let codesInGuideString = codesInParanthesis.toString().split(" ");
                let noDuplicate: any = [];
                noDuplicate = Array.from(new Set(codesInGuideString.toString().split(',')));
                noDuplicate = noDuplicate.filter(this.notEmpty);
                // function notEmpty(value) {
                //   return value !== "";
                // }
                noDuplicate = noDuplicate.sort();
                noDuplicate = noDuplicate.reverse();
                this.htmlToAdd = '';
                this.finalBlockNotes = [];
                let indexForBlock:any=[];
                for (let i = 0; i < this.InstructionalNotes.sectionNotes.subSection[0].note.length; i++) {
                  for (let j = 0; j < noDuplicate.length; j++) {
                    if (this.InstructionalNotes.sectionNotes.subSection[0].note[i].includes(noDuplicate[j])) {
                      var index = (this.InstructionalNotes.sectionNotes.subSection[0].note[i].indexOf(noDuplicate[j]));
                      let decimal = /^[0-9]+([,.][0-9]+)?$/g.test(noDuplicate[j]);
                      let alphaDecimal = /^[0-9A-Z]+([,.][0-9A-Z]+)?$/g.test(noDuplicate[j]);
                      let alphabets = /^[a-zA-Z]+$/.test(noDuplicate[j]);
                      indexForBlock = this.findAllIndexOfCode(this.InstructionalNotes.sectionNotes.subSection[0].note[i], noDuplicate[j]);
                          for (let k = 0; k < indexForBlock.length; k++) {
                            if (~indexForBlock[k] && (decimal || alphaDecimal)) {
                              if (!alphabets) {
                                var anchorCloseTag = this.InstructionalNotes.sectionNotes.subSection[0].note[i].substr(indexForBlock[k] - 1, 1);
                                var equalSign = this.InstructionalNotes.sectionNotes.subSection[0].note[i].substr(indexForBlock[k] - 8, 1);
                                var questionSign = this.InstructionalNotes.sectionNotes.subSection[0].note[i].substr(indexForBlock[k] - 5, 1);
                                
                                if (anchorCloseTag != '>' && anchorCloseTag != '=' && equalSign != '=' && questionSign != '?') {
                                  
                                  let codeLength = indexForBlock[k] + noDuplicate[j].length;
                                  var output = [this.InstructionalNotes.sectionNotes.subSection[0].note[i].slice(0, indexForBlock[k]), this.InstructionalNotes.sectionNotes.subSection[0].note[i].slice(indexForBlock[k], codeLength), "</a>", this.InstructionalNotes.sectionNotes.subSection[0].note[i].slice(codeLength)].join('');
                                  
                                  var finalFormat = [output.slice(0, indexForBlock[k]), '<a href=#/codeinfo?Code=' + noDuplicate[j] + '&CodeType=' + 'ICD-CM' + '>', output.slice(indexForBlock[k])].join('');
                                  
                                  this.InstructionalNotes.sectionNotes.subSection[0].note[i] = '';
                                  this.InstructionalNotes.sectionNotes.subSection[0].note[i] = finalFormat;
                                  this.finalBlockNotes[i] = this.InstructionalNotes.sectionNotes.subSection[0].note[i];
                                 
                                  if(this.InstructionalNotes.sectionNotes.subSection[0].header && this.finalBlockNotes){
                                    for(let i=0;i<this.finalBlockNotes.length;i++){
                                      let subPortion = this.InstructionalNotes.sectionNotes.subSection[0].header.split('(')[0];
                                      if(this.finalBlockNotes[i].includes(subPortion)){
                                        
                                        this.InstructionalNotes.sectionNotes.subSection[0].header = '';
                                        
                                        this.InstructionalNotes.sectionNotes.subSection[0].header = this.finalBlockNotes[i].concat();
                                      }
                                    }
                                  }
                                }
                              }
                            }
                            if (~indexForBlock[k] && (!decimal && !alphaDecimal)) {
                              
                              let alphabetsAndDot = /^[a-zA-Z\.]+$/.test(noDuplicate[j]);
                              let alphabets = /^[a-zA-Z]+$/.test(noDuplicate[j]);
                              if (!alphabets && !alphabetsAndDot) {
                                let numberValue = '';
                                let DecimalValue = '';
                                numberValue = noDuplicate[j].toString().split(".")[0];
                                DecimalValue = noDuplicate[j].toString().split(".")[1];
                                if (numberValue != undefined || numberValue != "" && (DecimalValue == "" || DecimalValue == '' || DecimalValue == null)) {
                                  noDuplicate[j] = '';
                                  noDuplicate[j] = numberValue;
                                }
                                var anchorCloseTag = this.InstructionalNotes.sectionNotes.subSection[0].note[i].substr(indexForBlock[k] - 1, 1);
                                var equalSign = this.InstructionalNotes.sectionNotes.subSection[0].note[i].substr(indexForBlock[k] - 8, 1);
                                var questionSign = this.InstructionalNotes.sectionNotes.subSection[0].note[i].substr(indexForBlock[k] - 5, 1);
                                
                                if (anchorCloseTag != '>' && anchorCloseTag != '=' && equalSign != '=' && questionSign != '?') {
                                  let codeLength = indexForBlock[k] + noDuplicate[j].length;
                                  var output = [this.InstructionalNotes.sectionNotes.subSection[0].note[i].slice(0, indexForBlock[k]), this.InstructionalNotes.sectionNotes.subSection[0].note[i].slice(indexForBlock[k], codeLength), "</a>", this.InstructionalNotes.sectionNotes.subSection[0].note[i].slice(codeLength)].join('');
                                  
                                  var finalFormat = [output.slice(0, indexForBlock[k]), '<a href=#/codeinfo?Code=' + noDuplicate[j] + '&CodeType=' + 'ICD-CM' + '>', output.slice(indexForBlock[k])].join('');
                                  
                                  this.InstructionalNotes.sectionNotes.subSection[0].note[i] = '';
                                  this.InstructionalNotes.sectionNotes.subSection[0].note[i] = finalFormat;
                                  this.finalBlockNotes[i] = this.InstructionalNotes.sectionNotes.subSection[0].note[i];

                                  if(this.InstructionalNotes.sectionNotes.subSection[0].header && this.finalBlockNotes){
                                    for(let i=0;i<this.finalBlockNotes.length;i++){
                                      let subPortion = this.InstructionalNotes.sectionNotes.subSection[0].header.split('(')[0];
                                      if(this.finalBlockNotes[i].includes(subPortion)){
                                        
                                        this.InstructionalNotes.sectionNotes.subSection[0].header = '';
                                        
                                        this.InstructionalNotes.sectionNotes.subSection[0].header = this.finalBlockNotes[i].concat();
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                      // if (~index && (decimal || alphaDecimal)) {
                      //   if (!alphabets) {
                      //     this.htmlToAdd = '';
                      //     this.htmlToAdd = '<a href=#/codeinfo?Code=' + noDuplicate[j] + '&CodeType=' + this.codeInformation.BASE_CODE_TYPE + '>' + noDuplicate[j] + '</a>';
                      //     let codeLength = noDuplicate[j].length;
                      //     if (!this.InstructionalNotes.sectionNotes.subSection[0].note[i].includes('<a href=#/codeinfo?Code=' + noDuplicate[j])) {
                      //       this.InstructionalNotes.sectionNotes.subSection[0].note[i] = this.replaceAll(this.InstructionalNotes.sectionNotes.subSection[0].note[i], noDuplicate[j], this.htmlToAdd);
                      //       this.finalBlockNotes[i] = this.InstructionalNotes.sectionNotes.subSection[0].note[i];
                      //     }
                      //   }
                      // }
                      // if (~index && (!decimal && !alphaDecimal)) {
                      //   let alphabetsAndDot = /^[a-zA-Z\.]+$/.test(noDuplicate[j]);
                      //   let alphabets = /^[a-zA-Z]+$/.test(noDuplicate[j]);
                      //   if (!alphabets && !alphabetsAndDot) {
                      //     let numberValue = '';
                      //     let DecimalValue = '';
                      //     numberValue = noDuplicate[j].toString().split(".")[0];
                      //     DecimalValue = noDuplicate[j].toString().split(".")[1];
                      //     if (numberValue != undefined || numberValue != "" && (DecimalValue == "" || DecimalValue == '' || DecimalValue == null)) {
                      //       noDuplicate[j] = '';
                      //       noDuplicate[j] = numberValue;
                      //     }
                      //     this.htmlToAdd = '';
                      //     this.htmlToAdd = '<a href=#/codeinfo?Code=' + noDuplicate[j] + '&CodeType=' + this.codeInformation.BASE_CODE_TYPE + '>' + noDuplicate[j] + '</a>';
                      //     let codeLength = noDuplicate[j].length;
                      //     if (!this.InstructionalNotes.sectionNotes.subSection[0].note[i].includes('<a href=#/codeinfo?Code=' + noDuplicate[j])) {
                      //       this.InstructionalNotes.sectionNotes.subSection[0].note[i] = this.replaceAll(this.InstructionalNotes.sectionNotes.subSection[0].note[i], noDuplicate[j], this.htmlToAdd);
                      //       this.finalBlockNotes[i] = this.InstructionalNotes.sectionNotes.subSection[0].note[i];
                      //     }
                      //   }
                      // }
                    }
                    else {
                      this.finalBlockNotes[i] = this.InstructionalNotes.sectionNotes.subSection[0].note[i];
                    }
                  }
                }
              }
              else {
                this.finalBlockNotes = this.InstructionalNotes.sectionNotes.subSection[0].note;
              }
            }

            if (Object.keys(this.InstructionalNotes).length == 0) {
              this.noInstructionalNotes = true;
            }
          }
          else {
            this.noInstructionalNotes = true;
          }
        },
        error => { }
      )
    }
  }
  LoadMedicareCCI() {
    this.MedicareCciSrc = '';
    this.noMedicare = false;
    if (this.codeInformation.CODE != undefined) {
      this.Hcpcscallservice.GetMethod('/HCPCS/GetMedicareCci?Code=' + this.codeInformation.CODE).subscribe(
        (res: any) => {
          if (res.length > 0) {
            this.MedicareCciSrc = res;
          }
          else {
            this.noMedicare = true;
            this.MedicareCciSrc = '';
          }
          // if (Object.keys(this.MedicareCciSrc).length == 0) {
          //   this.notFound = true;
          // }
        },
        error => { }
      )
    }
  }

  LayTerms() {
    this.noLayTerms = false;
    this.LayTermsData = '';
    if (this.codeInformation.CODE != undefined) {
      this.Hcpcscallservice.GetMethod('/HCPCS/GetLayTermsData?Code=' + this.codeInformation.CODE + '&CodeType=' + this.ApiCodeType.toLowerCase()).subscribe(
        (res: any) => {
          if (res.length > 0) {
            this.LayTermsData = JSON.parse(res);
            if (this.LayTermsData.descLay == undefined || this.LayTermsData.descLay == '') {
              this.noLayTerms = true;
            }
          }
          else {
            this.noLayTerms = true;
          }
        },
        error => { }
      )
    }
  }
  Historical() {
    this.HistoricalData = '';
    this.noHistoricalData = false;
    if (this.codeInformation.CODE != undefined) {
      this.Hcpcscallservice.GetMethod('/HCPCS/GetHistoricalData?Code=' + this.codeInformation.CODE + '&CodeType=' + this.ApiCodeType.toLowerCase()).subscribe(
        (res: any) => {
          if (res.length > 0) {
            this.HistoricalData = JSON.parse(res);
            this.HistoricalData = this.HistoricalData.codeHistory
            if (Object.keys(this.HistoricalData).length == 0) {
              this.noHistoricalData = true;
            }
          }
          else {
            this.noHistoricalData = true;
          }
        },
        error => { }
      )
    }
  }
  excludedata1: any = [];
  excludedata2: any = [];
  includedata1: any = [];
  cloneexcludedata1: any = [];
  cloneexcludedata2: any = [];
  cloneincludedata1: any = [];

  IncludeExcludeNotesClick() {
    this.IncludesExcludesdata = '';
    this.noIncludesExcludes = false;
    if (this.codeInformation.CODE != undefined) {
      this.excludedata1 = [];
      this.excludedata2 = [];
      this.includedata1 = [];
      this.cloneexcludedata1 = [];
      this.cloneexcludedata2 = [];
      this.cloneincludedata1 = [];
      this.finalExcludedata1 = [];
      this.finalExcludedata2 = [];
      this.finalIncludedata1 = [];

      this.Hcpcscallservice.GetMethod('/HCPCS/GetIncludesExcludesNotes?Code=' + this.codeInformation.CODE + '&CodeType=' + this.codeInformation.BASE_CODE_TYPE.toLowerCase()).subscribe(
        (res: any) => {
          if (res.length > 0) {
            this.IncludesExcludesdata = JSON.parse(res);
            if (Object.keys(this.IncludesExcludesdata).length == 0) {
              this.noIncludesExcludes = true;
            }
            else {

              if (this.IncludesExcludesdata.excludesNotes1.excludesHeader1 != undefined) {
                this.excludedata1.push(this.IncludesExcludesdata.excludesNotes1.excludesHeader1);
                if (this.IncludesExcludesdata.excludesNotes1.note.length > 0) {
                  for (let i = 0; i <= this.IncludesExcludesdata.excludesNotes1.note.length - 1; i++) {
                    // this.IncludesExcludesdata.excludesNotes1.note[i] = this.IncludesExcludesdata.excludesNotes1.note[i].charAt(0).toUpperCase() + this.IncludesExcludesdata.excludesNotes1.note[i].slice(1);
                    this.excludedata1.push(this.IncludesExcludesdata.excludesNotes1.note[i].content)
                  }
                }
              }
              if (this.excludedata1.length > 0) {
                this.cloneexcludedata1 = this.excludedata1.concat();
                if (this.cloneexcludedata1.length > 0) {
                  let replacedSymbols: any = [];
                  let codesInParanthesis: any = [];
                  for (let i = 0; i < this.cloneexcludedata1.length; i++) {
                    this.cloneexcludedata1[i] = this.cloneexcludedata1[i].replace(/[\[\]']+/g, '');
                    this.cloneexcludedata1[i] = this.cloneexcludedata1[i].replace(/-/g, ',');
                    this.cloneexcludedata1[i] = this.cloneexcludedata1[i].replace(/\s*,\s*/g, ",");
                    replacedSymbols.push(this.cloneexcludedata1[i]);
                  }
                  for (let i = 0; i < replacedSymbols.length; i++) {
                    if (replacedSymbols[i].includes('(')) {
                      var reBrackets = /\((.*?)\)/g;
                      var listOfText = [];
                      var found;
                      while (found = reBrackets.exec(replacedSymbols[i])) {
                        listOfText.push(found[1]);
                      };
                      if (listOfText.length > 0) {
                        for (let i = 0; i < listOfText.length; i++) {
                          if (listOfText[i].length >= 3) {
                            codesInParanthesis.push(listOfText[i]);
                          }
                        }
                      }
                    }
                  }
                  if (codesInParanthesis.length > 0) {
                    let codesInGuideString = codesInParanthesis.toString().replace(/"/g, "").replace(/'/g, "").replace(/\(|\)/g, "");
                    // let codesInGuideString = codesInParanthesis.toString().split(" ");
                    let noDuplicate: any = [];
                    noDuplicate = Array.from(new Set(codesInGuideString.toString().split(',')));
                    noDuplicate = noDuplicate.filter(this.notEmpty);
                    // function notEmpty(value) {
                    //   return value !== "";
                    // }
                    noDuplicate = noDuplicate.sort();
                    noDuplicate = noDuplicate.reverse();
                    this.htmlToAdd = '';
                    this.finalExcludedata1 = [];
                    let indexListE1: any = [];
                    for (let i = 0; i < this.excludedata1.length; i++) {
                      for (let j = 0; j < noDuplicate.length; j++) {
                        if (this.excludedata1[i].includes(noDuplicate[j])) {
                          var index = (this.excludedata1[i].indexOf(noDuplicate[j]));
                          let decimal = /^[0-9]+([,.][0-9]+)?$/g.test(noDuplicate[j]);
                          let alphaDecimal = /^[0-9A-Z]+([,.][0-9A-Z]+)?$/g.test(noDuplicate[j]);
                          let alphabets = /^[a-zA-Z]+$/.test(noDuplicate[j]);

                          indexListE1 = this.findAllIndexOfCode(this.excludedata1[i], noDuplicate[j]);
                          for (let k = 0; k < indexListE1.length; k++) {
                            if (~indexListE1[k] && (decimal || alphaDecimal)) {
                              if (!alphabets) {
                                var anchorCloseTag = this.excludedata1[i].substr(indexListE1[k] - 1, 1);
                                var equalSign = this.excludedata1[i].substr(indexListE1[k] - 8, 1);
                                var questionSign = this.excludedata1[i].substr(indexListE1[k] - 5, 1);
                                
                                if (anchorCloseTag != '>' && anchorCloseTag != '=' && equalSign != '=' && questionSign != '?') {
                                  
                                  let codeLength = indexListE1[k] + noDuplicate[j].length;
                                  var output = [this.excludedata1[i].slice(0, indexListE1[k]), this.excludedata1[i].slice(indexListE1[k], codeLength), "</a>", this.excludedata1[i].slice(codeLength)].join('');
                                  
                                  var finalFormat = [output.slice(0, indexListE1[k]), '<a href=#/codeinfo?Code=' + noDuplicate[j] + '&CodeType=' + 'ICD-CM' + '>', output.slice(indexListE1[k])].join('');
                                  
                                  this.excludedata1[i] = '';
                                  this.excludedata1[i] = finalFormat;
                                  this.finalExcludedata1[i] = this.excludedata1[i];
                                }
                              }
                            }
                            if (~indexListE1[k] && (!decimal && !alphaDecimal)) {
                              let alphabetsAndDot = /^[a-zA-Z\.]+$/.test(noDuplicate[j]);
                              let alphabets = /^[a-zA-Z]+$/.test(noDuplicate[j]);
                              if (!alphabets && !alphabetsAndDot) {
                                let numberValue = '';
                                let DecimalValue = '';
                                numberValue = noDuplicate[j].toString().split(".")[0];
                                DecimalValue = noDuplicate[j].toString().split(".")[1];
                                if (numberValue != undefined || numberValue != "" && (DecimalValue == "" || DecimalValue == '' || DecimalValue == null)) {
                                  noDuplicate[j] = '';
                                  noDuplicate[j] = numberValue;
                                }
                                var anchorCloseTag = this.excludedata1[i].substr(indexListE1[k] - 1, 1);
                                var equalSign = this.excludedata1[i].substr(indexListE1[k] - 8, 1);
                                var questionSign = this.excludedata1[i].substr(indexListE1[k] - 5, 1);
                                
                                if (anchorCloseTag != '>' && anchorCloseTag != '=' && equalSign != '=' && questionSign != '?') {
                                  let codeLength = indexListE1[k] + noDuplicate[j].length;
                                  var output = [this.excludedata1[i].slice(0, indexListE1[k]), this.excludedata1[i].slice(indexListE1[k], codeLength), "</a>", this.excludedata1[i].slice(codeLength)].join('');
                                  
                                  var finalFormat = [output.slice(0, indexListE1[k]), '<a href=#/codeinfo?Code=' + noDuplicate[j] + '&CodeType=' + 'ICD-CM' + '>', output.slice(indexListE1[k])].join('');
                                  
                                  this.excludedata1[i] = '';
                                  this.excludedata1[i] = finalFormat;
                                  this.finalExcludedata1[i] = this.excludedata1[i];
                                }
                              }
                            }
                          }
                        }
                        else {
                          this.finalExcludedata1[i] = this.excludedata1[i];
                        }
                      }
                    }
                  }
                  else {
                    this.finalExcludedata1 = this.excludedata1;
                  }
                }
              }
              if (this.IncludesExcludesdata.excludesNotes2!= undefined) {
                if (this.IncludesExcludesdata.excludesNotes2.excludesHeader2 != undefined) {
                  this.excludedata2.push(this.IncludesExcludesdata.excludesNotes2.excludesHeader2);
                }
                if (this.IncludesExcludesdata.excludesNotes2.note.length > 0) {
                  for (let i = 0; i <= this.IncludesExcludesdata.excludesNotes2.note.length - 1; i++) {
                    // this.IncludesExcludesdata.excludesNotes2.note[i] = this.IncludesExcludesdata.excludesNotes2.note[i].charAt(0).toUpperCase() + this.IncludesExcludesdata.excludesNotes2.note[i].slice(1);
                    this.excludedata2.push(this.IncludesExcludesdata.excludesNotes2.note[i].content)
                  }
                }
              }
              if (this.excludedata2.length > 0) {
                this.cloneexcludedata2 = this.excludedata2.concat();
                if (this.cloneexcludedata2.length > 0) {
                  let replacedSymbols: any = [];
                  let codesInParanthesis: any = [];
                  for (let i = 0; i < this.cloneexcludedata2.length; i++) {
                    this.cloneexcludedata2[i] = this.cloneexcludedata2[i].replace(/[\[\]']+/g, '');
                    this.cloneexcludedata2[i] = this.cloneexcludedata2[i].replace(/-/g, ',');
                    this.cloneexcludedata2[i] = this.cloneexcludedata2[i].replace(/\s*,\s*/g, ",");
                    replacedSymbols.push(this.cloneexcludedata2[i]);
                  }
                  for (let i = 0; i < replacedSymbols.length; i++) {
                    if (replacedSymbols[i].includes('(')) {
                      var reBrackets = /\((.*?)\)/g;
                      var listOfText = [];
                      var found;
                      while (found = reBrackets.exec(replacedSymbols[i])) {
                        listOfText.push(found[1]);
                      };
                      if (listOfText.length > 0) {
                        for (let i = 0; i < listOfText.length; i++) {
                          if (listOfText[i].length >= 3) {
                            codesInParanthesis.push(listOfText[i]);
                          }
                        }
                      }
                    }
                  }
                  if (codesInParanthesis.length > 0) {
                    let codesInGuideString = codesInParanthesis.toString().replace(/"/g, "").replace(/'/g, "").replace(/\(|\)/g, "");
                    // let codesInGuideString = codesInParanthesis.toString().split(" ");
                    let noDuplicate: any = [];
                    noDuplicate = Array.from(new Set(codesInGuideString.toString().split(',')));
                    noDuplicate = noDuplicate.filter(this.notEmpty);
                    noDuplicate = noDuplicate.sort();
                    noDuplicate = noDuplicate.reverse();
                    this.htmlToAdd = '';
                    this.finalExcludedata2 = [];
                    let indexList: any = [];
                    for (let i = 0; i < this.excludedata2.length; i++) {

                      for (let j = 0; j < noDuplicate.length; j++) {

                        if (this.excludedata2[i].includes(noDuplicate[j])) {


                          let decimal = /^[0-9]+([,.][0-9]+)?$/g.test(noDuplicate[j]);
                          let alphaDecimal = /^[0-9A-Z]+([,.][0-9A-Z]+)?$/g.test(noDuplicate[j]);
                          let alphabets = /^[a-zA-Z]+$/.test(noDuplicate[j]);

                          // to be changed for everything

                          indexList = this.findAllIndexOfCode(this.excludedata2[i], noDuplicate[j]);
                          for (let k = 0; k < indexList.length; k++) {
                            if (~indexList[k] && (decimal || alphaDecimal)) {
                              if (!alphabets) {
                                var anchorCloseTag = this.excludedata2[i].substr(indexList[k] - 1, 1);
                                var equalSign = this.excludedata2[i].substr(indexList[k] - 8, 1);
                                var questionSign = this.excludedata2[i].substr(indexList[k] - 5, 1);
                                
                                if (anchorCloseTag != '>' && anchorCloseTag != '=' && equalSign != '=' && questionSign != '?') {
                                  
                                  let codeLength = indexList[k] + noDuplicate[j].length;
                                  var output = [this.excludedata2[i].slice(0, indexList[k]), this.excludedata2[i].slice(indexList[k], codeLength), "</a>", this.excludedata2[i].slice(codeLength)].join('');
                                  
                                  var finalFormat = [output.slice(0, indexList[k]), '<a href=#/codeinfo?Code=' + noDuplicate[j] + '&CodeType=' + 'ICD-CM' + '>', output.slice(indexList[k])].join('');
                                  
                                  this.excludedata2[i] = '';
                                  this.excludedata2[i] = finalFormat;
                                  this.finalExcludedata2[i] = this.excludedata2[i];
                                }
                              }
                            }
                            if (~indexList[k] && (!decimal && !alphaDecimal)) {
                              
                              let alphabetsAndDot = /^[a-zA-Z\.]+$/.test(noDuplicate[j]);
                              let alphabets = /^[a-zA-Z]+$/.test(noDuplicate[j]);
                              if (!alphabets && !alphabetsAndDot) {
                                let numberValue = '';
                                let DecimalValue = '';
                                numberValue = noDuplicate[j].toString().split(".")[0];
                                DecimalValue = noDuplicate[j].toString().split(".")[1];
                                if (numberValue != undefined || numberValue != "" && (DecimalValue == "" || DecimalValue == '' || DecimalValue == null)) {
                                  noDuplicate[j] = '';
                                  noDuplicate[j] = numberValue;
                                }
                                var anchorCloseTag = this.excludedata2[i].substr(indexList[k] - 1, 1);
                                var equalSign = this.excludedata2[i].substr(indexList[k] - 8, 1);
                                var questionSign = this.excludedata2[i].substr(indexList[k] - 5, 1);
                                
                                if (anchorCloseTag != '>' && anchorCloseTag != '=' && equalSign != '=' && questionSign != '?') {
                                  let codeLength = indexList[k] + noDuplicate[j].length;
                                  var output = [this.excludedata2[i].slice(0, indexList[k]), this.excludedata2[i].slice(indexList[k], codeLength), "</a>", this.excludedata2[i].slice(codeLength)].join('');
                                  
                                  var finalFormat = [output.slice(0, indexList[k]), '<a href=#/codeinfo?Code=' + noDuplicate[j] + '&CodeType=' + 'ICD-CM' + '>', output.slice(indexList[k])].join('');
                                  
                                  this.excludedata2[i] = '';
                                  this.excludedata2[i] = finalFormat;
                                  this.finalExcludedata2[i] = this.excludedata2[i];
                                }
                              }
                            }
                          }
                        }
                        else {
                          this.finalExcludedata2[i] = this.excludedata2[i];
                        }
                      }
                    }
                  }
                  else {
                    this.finalExcludedata2 = this.excludedata2;
                  }
                }
              }
              if (this.IncludesExcludesdata.includesNotes!= undefined) {
                
                if(this.IncludesExcludesdata.includesNotes.includesHeader!=undefined){
                  this.includedata1.push(this.IncludesExcludesdata.includesNotes.includesHeader);
                }
                if (this.IncludesExcludesdata.includesNotes.note.length > 0) {
                  for (let i = 0; i <= this.IncludesExcludesdata.includesNotes.note.length - 1; i++) {
                    this.includedata1.push(this.IncludesExcludesdata.includesNotes.note[i].content)
                  }
                }
              }
              if (this.includedata1.length > 0) {
                
                this.cloneincludedata1 = this.includedata1.concat();
                if (this.cloneincludedata1.length > 0) {
                  let replacedSymbols: any = [];
                  let codesInParanthesis: any = [];
                  for (let i = 0; i < this.cloneincludedata1.length; i++) {
                    this.cloneincludedata1[i] = this.cloneincludedata1[i].replace(/[\[\]']+/g, '');
                    this.cloneincludedata1[i] = this.cloneincludedata1[i].replace(/-/g, ',');
                    this.cloneincludedata1[i] = this.cloneincludedata1[i].replace(/\s*,\s*/g, ",");
                    replacedSymbols.push(this.cloneincludedata1[i]);
                  }
                  for (let i = 0; i < replacedSymbols.length; i++) {
                    if (replacedSymbols[i].includes('(')) {
                      var reBrackets = /\((.*?)\)/g;
                      var listOfText = [];
                      var found;
                      while (found = reBrackets.exec(replacedSymbols[i])) {
                        listOfText.push(found[1]);
                      };
                      if (listOfText.length > 0) {
                        for (let i = 0; i < listOfText.length; i++) {
                          if (listOfText[i].length >= 3) {
                            codesInParanthesis.push(listOfText[i]);
                          }
                        }
                      }
                    }
                  }
                  if (codesInParanthesis.length > 0) {
                    let codesInGuideString = codesInParanthesis.toString().replace(/"/g, "").replace(/'/g, "").replace(/\(|\)/g, "");
                    // let codesInGuideString = codesInParanthesis.toString().split(" ");
                    let noDuplicate: any = [];
                    noDuplicate = Array.from(new Set(codesInGuideString.toString().split(',')));
                    noDuplicate = noDuplicate.filter(this.notEmpty);
                    // function notEmpty(value) {
                    //   return value !== "";
                    // }
                    noDuplicate = noDuplicate.sort();
                    noDuplicate = noDuplicate.reverse();
                    this.htmlToAdd = '';
                    this.finalIncludedata1 = [];
                    let indexForInclude: any = [];
                    for (let i = 0; i < this.includedata1.length; i++) {
                      for (let j = 0; j < noDuplicate.length; j++) {
                        if (this.includedata1[i].includes(noDuplicate[j])) {
                          var index = (this.includedata1[i].indexOf(noDuplicate[j]));
                          let decimal = /^[0-9]+([,.][0-9]+)?$/g.test(noDuplicate[j]);
                          let alphaDecimal = /^[0-9A-Z]+([,.][0-9A-Z]+)?$/g.test(noDuplicate[j]);
                          let alphabets = /^[a-zA-Z]+$/.test(noDuplicate[j]);

                          indexForInclude = this.findAllIndexOfCode(this.includedata1[i], noDuplicate[j]);

                          for (let k = 0; k < indexForInclude.length; k++) {
                            if (~indexForInclude[k] && (decimal || alphaDecimal)) {
                              
                              if (!alphabets) {
                                var anchorCloseTag = this.includedata1[i].substr(indexForInclude[k] - 1, 1);
                                var equalSign = this.includedata1[i].substr(indexForInclude[k] - 8, 1);
                                var questionSign = this.includedata1[i].substr(indexForInclude[k] - 5, 1);
                                
                                if (anchorCloseTag != '>' && anchorCloseTag != '=' && equalSign != '=' && questionSign != '?') {
                                  
                                  let codeLength = indexForInclude[k] + noDuplicate[j].length;
                                  var output = [this.includedata1[i].slice(0, indexForInclude[k]), this.includedata1[i].slice(indexForInclude[k], codeLength), "</a>", this.includedata1[i].slice(codeLength)].join('');
                                  
                                  var finalFormat = [output.slice(0, indexForInclude[k]), '<a href=#/codeinfo?Code=' + noDuplicate[j] + '&CodeType=' + 'ICD-CM' + '>', output.slice(indexForInclude[k])].join('');
                                  
                                  this.includedata1[i] = '';
                                  this.includedata1[i] = finalFormat;
                                  this.finalIncludedata1[i] = this.includedata1[i];
                                }
                              }
                            }
                            if (~indexForInclude[k] && (!decimal && !alphaDecimal)) {
                              
                              let alphabetsAndDot = /^[a-zA-Z\.]+$/.test(noDuplicate[j]);
                              let alphabets = /^[a-zA-Z]+$/.test(noDuplicate[j]);
                              if (!alphabets && !alphabetsAndDot) {
                                let numberValue = '';
                                let DecimalValue = '';
                                numberValue = noDuplicate[j].toString().split(".")[0];
                                DecimalValue = noDuplicate[j].toString().split(".")[1];
                                if (numberValue != undefined || numberValue != "" && (DecimalValue == "" || DecimalValue == '' || DecimalValue == null)) {
                                  noDuplicate[j] = '';
                                  noDuplicate[j] = numberValue;
                                }
                                var anchorCloseTag = this.includedata1[i].substr(indexForInclude[k] - 1, 1);
                                var equalSign = this.includedata1[i].substr(indexForInclude[k] - 8, 1);
                                var questionSign = this.includedata1[i].substr(indexForInclude[k] - 5, 1);
                                
                                if (anchorCloseTag != '>' && anchorCloseTag != '=' && equalSign != '=' && questionSign != '?') {
                                  let codeLength = indexForInclude[k] + noDuplicate[j].length;
                                  var output = [this.includedata1[i].slice(0, indexForInclude[k]), this.includedata1[i].slice(indexForInclude[k], codeLength), "</a>", this.includedata1[i].slice(codeLength)].join('');
                                  
                                  var finalFormat = [output.slice(0, indexForInclude[k]), '<a href=#/codeinfo?Code=' + noDuplicate[j] + '&CodeType=' + 'ICD-CM' + '>', output.slice(indexForInclude[k])].join('');
                                  
                                  this.includedata1[i] = '';
                                  this.includedata1[i] = finalFormat;
                                  this.finalIncludedata1[i] = this.includedata1[i];
                                }
                              }
                            }
                          }
                          // if (~index && (decimal || alphaDecimal)) {
                          //   if (!alphabets) {
                          //     this.htmlToAdd = '';
                          //     this.htmlToAdd = '<a href=#/codeinfo?Code=' + noDuplicate[j] + '&CodeType=' + this.codeInformation.BASE_CODE_TYPE + '>' + noDuplicate[j] + '</a>';
                          //     let codeLength = noDuplicate[j].length;
                          //     if (!this.includedata1[i].includes(+ noDuplicate[j] + '</a>')) {
                          //       this.includedata1[i] = this.replaceAll(this.includedata1[i], noDuplicate[j], this.htmlToAdd);
                          //       this.finalIncludedata1[i] = this.includedata1[i];
                          //     }
                          //   }
                          // }

                          // if (~index && (!decimal && !alphaDecimal)) {
                          //   let alphabetsAndDot = /^[a-zA-Z\.]+$/.test(noDuplicate[j]);
                          //   let alphabets = /^[a-zA-Z]+$/.test(noDuplicate[j]);
                          //   if (!alphabets && !alphabetsAndDot) {
                          //     let numberValue = '';
                          //     let DecimalValue = '';
                          //     numberValue = noDuplicate[j].toString().split(".")[0];
                          //     DecimalValue = noDuplicate[j].toString().split(".")[1];
                          //     if (numberValue != undefined || numberValue != "" && (DecimalValue == "" || DecimalValue == '' || DecimalValue == null)) {
                          //       noDuplicate[j] = '';
                          //       noDuplicate[j] = numberValue;
                          //     }
                          //     this.htmlToAdd = '';
                          //     this.htmlToAdd = '<a href=#/codeinfo?Code=' + noDuplicate[j] + '&CodeType=' + this.codeInformation.BASE_CODE_TYPE + '>' + noDuplicate[j] + '</a>';
                          //     let codeLength = noDuplicate[j].length;
                          //     if (!this.includedata1[i].includes(+ noDuplicate[j] + '</a>')) {
                          //       this.includedata1[i] = this.replaceAll(this.includedata1[i], noDuplicate[j], this.htmlToAdd);
                          //       this.finalIncludedata1[i] = this.includedata1[i];
                          //     }
                          //   }
                          // }
                        }
                        else {
                          this.finalIncludedata1[i] = this.includedata1[i];
                        }
                      }
                    }
                  }
                  else {
                    this.finalIncludedata1 = this.includedata1;
                  }
                }
              }
            }
          }
          else {
            this.noIncludesExcludes = true;
          }
        },
        error => { }
      )
    }
  }
  LoadCptGuideLinesData() {
    this.noGuideLines = false;
    this.apidata = '';
    this.cloneApiData = '';
    let split = [];
    this.finalApiData = [];
    this.guideLinesData = [];
    if (this.codeInformation.CODE != undefined) {
      this.Hcpcscallservice.GetMethod('/HCPCS/GetApiData?Code=' + this.codeInformation.CODE + '&CodeType=' + this.codeInformation.BASE_CODE_TYPE.toLowerCase()).subscribe(
        (res: any) => {
          if (res.length > 0) {
            this.apidata = JSON.parse(res);
            this.cloneApiData = JSON.parse(res);
            if (this.cloneApiData.item.length > 0) {
              this.guideLinesData = [];
              this.codesInGuide = []
              for (let i = 0; i < this.cloneApiData.item.length; i++) {
                this.cloneApiData.item[i] = this.cloneApiData.item[i].replace(/[\[\]']+/g, '');
                this.cloneApiData.item[i] = this.cloneApiData.item[i].replace(/-/g, ',');
                this.cloneApiData.item[i] = this.cloneApiData.item[i].replace(/\s*,\s*/g, ",");
                this.guideLinesData.push(this.cloneApiData.item[i]);
              }
              if (this.guideLinesData[0].startsWith("INCLUDES")) {
                this.commonIndex = 0;
              }
              else {
                this.commonIndex = 1;
              }
              for (let i = this.commonIndex; i < this.guideLinesData.length; i++) {
                if (this.guideLinesData[i].includes('(')) {
                  let codesInBetweenParanthesis = this.guideLinesData[i].indexOf("(") + 1;
                  var sep = this.guideLinesData[i].slice(codesInBetweenParanthesis, this.guideLinesData[i].lastIndexOf(")"));
                  if (sep.length >= 5) {
                    this.codesInGuide.push(sep);
                  }
                }
              }
              if (this.codesInGuide.length > 0) {
                this.codesInGuide = this.codesInGuide.toString().replace(/"/g, "").replace(/'/g, "").replace(/\(|\)/g, "");
                let codesInGuideString = this.codesInGuide.toString().split(" ");
                this.noDup = '';
                this.noDup = Array.from(new Set(codesInGuideString.toString().split(',')));
                this.htmlToAdd = '';
                this.finalApiData = [];
                for (let i = 0; i < this.apidata.item.length; i++) {
                  for (let j = 0; j < this.noDup.length; j++) {
                    if (this.apidata.item[i].includes(this.noDup[j])) {
                      var index = (this.apidata.item[i].indexOf(this.noDup[j]));
                      if (~index && (/^([0-9])+([0-9A-Z]+)$/i.test(this.noDup[j]))) {
                        this.htmlToAdd = '<a href=#/codeinfo?Code=' + this.noDup[j] + '&CodeType=' + this.codeInformation.BASE_CODE_TYPE + '>' + this.noDup[j] + '</a>';
                        this.apidata.item[i] = this.replaceAll(this.apidata.item[i], this.noDup[j], this.htmlToAdd);
                        this.finalApiData[i] = this.apidata.item[i];
                      }
                    }
                    else {
                      this.finalApiData[i] = this.apidata.item[i];
                    }
                  }
                }
              }
              else {
                this.finalApiData = this.apidata.item;
              }
            }

            if (Object.keys(this.apidata.item).length == 0) {
              this.noGuideLines = true;
            }
          }
          else {
            this.noGuideLines = true;
          }
        },
        error => { }
      )
    }
  }
  replaceAll(string, search, replace) {
    return string.split(search).join(replace);
  }
  notEmpty(value) {
    return value !== "";
  }
  findAllIndexOfCode(fullString: string, searchString: string) {
    var regex = new RegExp(searchString, "g");
    var result, indices = [];
    while ((result = regex.exec(fullString))) {
      indices.push(result.index);
    }
    indices.sort(function (a, b) {
      return b - a;
    });
    return indices;
  }

  LoadCptInstructionsData() {
    this.instructionsData = '';
    this.noInstructions = false;
    this.finalInstructionsData = [];
    let cloneInstructionsData: any = [];
    if (this.codeInformation.CODE != undefined) {
      this.Hcpcscallservice.GetMethod('/HCPCS/GetInstructionsData?Code=' + this.codeInformation.CODE + '&CodeType=' + this.codeInformation.BASE_CODE_TYPE.toLowerCase()).subscribe(
        (res: any) => {

          if (res.length > 0) {
            this.instructionsData = JSON.parse(res);
            let include: any = [];
            let exclude: any = [];
            let others: any = [];
            for (let i = 0; i < this.instructionsData.item.length; i++) {
              if (this.instructionsData.item[i].startsWith('Includes')) {
                this.instructionsData.item[i] = this.instructionsData.item[i].replace('Includes', '');
                include.push(this.instructionsData.item[i]);
              }
              else if (this.instructionsData.item[i].startsWith('Excludes')) {
                this.instructionsData.item[i] = this.instructionsData.item[i].replace('Excludes', '');
                exclude.push(this.instructionsData.item[i]);
              }
              else {
                others.push(this.instructionsData.item[i]);
              }
            }
            if (include.length > 0 || exclude.length > 0 || others.length > 0) {
              this.instructionsData.item = [];
              if (include.length > 0) {
                this.instructionsData.item = this.instructionsData.item.concat("INCLUDES:");
                this.instructionsData.item = this.instructionsData.item.concat(include);
              }
              if (exclude.length > 0) {
                this.instructionsData.item = this.instructionsData.item.concat("EXCLUDES:");
                this.instructionsData.item = this.instructionsData.item.concat(exclude);
              }
              this.instructionsData.item = this.instructionsData.item.concat(others);
            }
            cloneInstructionsData = this.instructionsData.item.concat();
            if (cloneInstructionsData.length > 0) {
              let replacedSymbols: any = [];
              let codesInParanthesis: any = [];
              for (let i = 0; i < cloneInstructionsData.length; i++) {
                cloneInstructionsData[i] = cloneInstructionsData[i].replace(/[\[\]']+/g, '');
                cloneInstructionsData[i] = cloneInstructionsData[i].replace(/-/g, ',');
                cloneInstructionsData[i] = cloneInstructionsData[i].replace(/\s*,\s*/g, ",");
                replacedSymbols.push(cloneInstructionsData[i]);
              }
              for (let i = 0; i < replacedSymbols.length; i++) {
                if (replacedSymbols[i].includes('(')) {
                  let codesInBetweenParanthesis = replacedSymbols[i].indexOf("(") + 1;
                  var sep = replacedSymbols[i].slice(codesInBetweenParanthesis, replacedSymbols[i].lastIndexOf(")"));
                  if (sep.length >= 5) {
                    codesInParanthesis.push(sep);
                  }
                }
              }
              if (codesInParanthesis.length > 0) {
                codesInParanthesis = codesInParanthesis.toString().replace(/"/g, "").replace(/'/g, "").replace(/\(|\)/g, "");
                let codesInGuideString = codesInParanthesis.toString().split(" ");
                let noDuplicate: any = [];
                noDuplicate = Array.from(new Set(codesInGuideString.toString().split(',')));
                this.htmlToAdd = '';
                this.finalInstructionsData = [];
                for (let i = 0; i < this.instructionsData.item.length; i++) {
                  for (let j = 0; j < noDuplicate.length; j++) {
                    if (this.instructionsData.item[i].includes(noDuplicate[j])) {
                      var index = (this.instructionsData.item[i].indexOf(noDuplicate[j]));
                      if (~index && (/^([0-9])+([0-9A-Z]+)$/i.test(noDuplicate[j]))) {
                        this.htmlToAdd = '<a href=#/codeinfo?Code=' + noDuplicate[j] + '&CodeType=' + this.codeInformation.BASE_CODE_TYPE + '>' + noDuplicate[j] + '</a>';
                        this.instructionsData.item[i] = this.replaceAll(this.instructionsData.item[i], noDuplicate[j], this.htmlToAdd);
                        this.finalInstructionsData[i] = this.instructionsData.item[i];
                      }
                    }
                    else {
                      this.finalInstructionsData[i] = this.instructionsData.item[i];
                    }
                  }
                }
              }
              else {
                this.finalInstructionsData = this.instructionsData.item;
              }
            }

            if (Object.keys(this.instructionsData.item).length == 0) {
              this.noInstructions = true;
            }
          }
          else {
            this.noInstructions = true;
          }
        },
        error => { }
      )
    }
  }
  LoadIllustrationImages() {
    this.imageItself = '';
    this.alternateImg = '';
    if (this.codeInformation.CODE != undefined) {
      this.Hcpcscallservice.GetMethod('/HCPCS/GetIllustrationImages?Code=' + this.codeInformation.CODE + '&CodeType=' + this.codeInformation.BASE_CODE_TYPE.toLowerCase()).subscribe(
        (res: any) => {
          this.illustrationImages = JSON.parse(res);
          if (this.illustrationImages.error) {
            this.alternateImg = this.illustrationImages.info[0];
          }
          else {
            this.imgHref = this.illustrationImages[0].href;
            this.loadImage();
          }
        },
        error => { }
      )
    }
  }
  imageBlobUrl: string;
  loadImage(): void {
    this.imageItself = '';
    this.alternateImg = '';
    this.Hcpcscallservice.GetMethod('/HCPCS/GetImageFromAPI?ImageLink=' + this.imgHref)
      .subscribe(
        (val) => {

          this.imageItself = "data:image/png;base64," + val;
          // (<HTMLInputElement>document.getElementById("ItemPreview")).src= "data:image/png;base64," + val;
        },
        error => {

        });
  }
  LoadColorCodesData() {
    this.colorCodesData = [];
    this.notFound = false;
    if (this.codeInformation.CODE != undefined) {
      this.Hcpcscallservice.GetMethod('/HCPCS/GetColorCodesData?Code=' + this.codeInformation.CODE + '&CodeType=' + this.ApiCodeType.toLowerCase()).subscribe(
        (res: any) => {
          if (res.length > 0) {
            this.colorCodesData = JSON.parse(res);
            if (Object.keys(this.colorCodesData).length == 0) {
              this.notFound = true;
            }
          }
          else {
            this.notFound = true;
          }
        },
        error => { }
      )
    }
  }
  isString(val): boolean {
    return typeof val === 'string';
  }
  isObject(val): boolean {
    return typeof val === 'object';
  }
  crosstype1: any;
  crosstype2: any;
  crosstype3: any;

  checkCrossRef() {
    if (this.codeInformation.CODE != undefined) {
      if (this.codeInformation.MIPS == 'Y') {
        this.Mips = false;
      }
      else {
        this.Mips = true;
      }
      this.crosstype1 = this.codeInformation.X_CODE_TYPE1.split("-")[1];
      this.crosstype2 = this.codeInformation.X_CODE_TYPE2.split("-")[1];
      this.crosstype3 = this.codeInformation.X_CODE_TYPE3.split("-")[1];
      this.codeInformation.X_CODE_TYPE1 = this.codeInformation.X_CODE_TYPE1.replace('-', ' ↔ ');
      this.codeInformation.X_CODE_TYPE2 = this.codeInformation.X_CODE_TYPE2.replace('-', ' ↔ ');
      this.codeInformation.X_CODE_TYPE3 = this.codeInformation.X_CODE_TYPE3.replace('-', ' ↔ ');

      if (this.codeInformation.BASE_CODE_TYPE == 'ICD-PCS') {
        this.InstructionalNoteshide = true;
        this.GuideLineshide = true;
        this.instructionsHide = true;
        this.IncludeExcludeNoteshide = true;
      }
      else if (this.codeInformation.BASE_CODE_TYPE == 'ICD-CM') {
        this.InstructionalNoteshide = false;
        this.GuideLineshide = true;
        this.instructionsHide = true;
        this.IncludeExcludeNoteshide = false;
      }
      else if (this.codeInformation.BASE_CODE_TYPE == 'HCPCS') {
        this.instructionsHide = true;
        this.InstructionalNoteshide = true;
        this.GuideLineshide = false;
        this.IncludeExcludeNoteshide = true;
      }
      else {
        this.InstructionalNoteshide = true;
        this.GuideLineshide = false;
        this.instructionsHide = false;
        this.IncludeExcludeNoteshide = true;
      }

    }
    if (this.codeInformation.X_CODE_TYPE1_COUNT <= 0) {
      this.CM = true;
    }
    else {
      this.CM = false;
    }
    if (this.codeInformation.X_CODE_TYPE2_COUNT <= 0) {
      this.PCS = true;
    }
    else {
      this.PCS = false;
    }
    if (this.codeInformation.X_CODE_TYPE3_COUNT <= 0) {
      this.HCPCS = true;
    } else {
      this.HCPCS = false;
    }

    if (this.codeInformation.BASE_CODE_TYPE == 'CPT') {
      this.ApiCodeType = types.ApiCodeTypes.CPT;
    }
    else if (this.codeInformation.BASE_CODE_TYPE == 'HCPCS') {
      this.ApiCodeType = types.ApiCodeTypes.HCPCS;
    }
    if (this.codeInformation.BASE_CODE_TYPE == 'ICD-CM') {
      this.ApiCodeType = types.ApiCodeTypes.ICD10CM;
    }
    if (this.codeInformation.BASE_CODE_TYPE == 'ICD-PCS') {
      this.ApiCodeType = types.ApiCodeTypes.ICD10PCS;
    }
  }
  DRGClick(Code) {
    this.dialog.open(DRGDialogComponent, {
      width: '50%',
      data: Code + '-' + this.codeInformation.X_CODE_TYPE1.split('↔')[1].trim()
    });
  }
  alphadata: any = [];

  CMData(alpha) {

    if (alpha == undefined) {
      alpha = 'NO';
    }
    this.service.GetCrossWalkData(this.codeInformation.CODE, this.codeInformation.X_CODE_TYPE1.split('↔')[1].trim(), alpha).subscribe(
      res => {

        this.CMDatasrc = res;


        let data = this.CMDatasrc[0].STARTINDEXES.split(',');
        this.alphadata = [];
        for (let i = 0; i < data.length; i++) {
          this.alphadata.push(data[i]);
        }

      },
      error => { }
    )
  }
  PCSData() {
    this.service.GetCrossWalkData(this.codeInformation.CODE, this.codeInformation.X_CODE_TYPE2.split('↔')[1].trim(), 'NO').subscribe(
      res => {
        this.PCSDatasrc = res;
      },
      error => { }
    )
  }
  HCPCSData() {
    this.service.GetCrossWalkData(this.codeInformation.CODE, this.codeInformation.X_CODE_TYPE3.split('↔')[1].trim(), 'NO').subscribe(
      res => {
        this.HCPCSDatasrc = res;
      },
      error => { }
    )
  }
  RevenueData() {
    this.RevenueDataSrc = '';
    this.output = [];
    this.noRevenueData = false;
    this.Hcpcscallservice.GetMethod('/HCPCS/GetCrossRevCode?Code=' + this.codeInformation.CODE + '&CodeType=' + this.ApiCodeType.toLowerCase()).subscribe(
      (res: any) => {
        if (res.length > 0) {
          this.RevenueDataSrc = JSON.parse(res);
          if (Object.keys(this.RevenueDataSrc).length > 0) {
            var resArr = [];
            this.RevenueDataSrc.item.forEach(function (item) {
              var i = resArr.findIndex(x => x.revCode == item.revCode);
              if (i <= -1) {
                resArr.push({
                  revCode: item.revCode, revCodeDesc: item.revCodeDesc,
                  tobFacilityCode: item.tobFacilityCode, tobFacilityCodeDesc: item.tobFacilityCodeDesc,
                  note: item.note
                });
              }
            });
            this.output = resArr;
          }
          else {
            this.RevenueDataSrc = '';
            this.noRevenueData = true;
          }
        }
        else {
          this.RevenueDataSrc = '';
          this.noRevenueData = true;
        }
      },
      error => { }
    )
  }
  HCCData() {
    this.HCCDataSrc = '';
    this.noHCCCross = false;
    this.Hcpcscallservice.GetMethod('/HCPCS/GetHccIcdXwalk?Code=' + this.codeInformation.CODE).subscribe(
      res => {
        if (res.length > 0) {
          this.HCCDataSrc = res[0];
          // if (Object.keys(this.HCCDataSrc).length == 0) {
          //   this.notFound = true;
          // }
        }
        else {
          this.noHCCCross = true;
          this.HCCDataSrc = '';
        }

      },
      error => { }
    )
  }
  codeInfo(CodeInfo: any) {
    if (CodeInfo[0].STATUS != 'D') {
      this.codeInformation = CodeInfo[0];
      this.ExpandColorCodes = true;
      this.checkCrossRef();
      this.LoadColorCodesData();
      this.exmodifier = false;
      this.exmodifierASC = false;
      this.MueEditsOpen = false;
      this.ExpandLayTerms = false;
      this.ExpandHistorical = false;
      this.ExpandPdf = false;
      this.ExpandMedicare = false;
      this.ExpandFeeSchedule = false;
      this.ExpandFeeLab = false;
      this.ExpandFeeAnesthesia = false;
      this.ExpandCrossWalk = false;
      this.ExpandFeePEN = false;
      this.ExpandFeePOS = false;
      this.ExpandFeeAmbulance = false;
      this.Type1 = false;
      this.Type2 = false;
      this.Type3 = false;
      this.ExpandMips = false;
      this.expandRevenue = false;
      this.expandHCC = false;
      this.CodeDesc = true;
      this.ExpandIllustration = false;
    }
    else {
      let RedirectValue;
      if (CodeInfo[0].BASE_CODE_TYPE == 'CPT') {
        RedirectValue = "/DeletedCodes";
      } else if (CodeInfo[0].BASE_CODE_TYPE == 'HCPCS') {
        RedirectValue = "/HcpcsDeletedCode";
      } else if (CodeInfo[0].BASE_CODE_TYPE == 'ICD-CM') {
        RedirectValue = "/Icd10CmDeletedCodes";
      } else if (CodeInfo[0].BASE_CODE_TYPE == 'ICD-PCS') {
        RedirectValue = "/Icd10PcsDeletedCodes";
      }
      this.router.navigate([RedirectValue], { queryParams: { Code: CodeInfo[0].CODE } })
    }
  }
  LoadModifier_P() {
    this.Modifier_p = '';
    this.noModifierP = false;
    if (this.codeInformation.BASE_CODE_TYPE != undefined) {
      this.service.GetAllowModifier_p(this.codeInformation.CODE, this.codeInformation.BASE_CODE_TYPE).subscribe(
        res => {
          if (res.length > 0) {
            this.noModifierP = false;
            this.Modifier_p = res;
          }
          else {
            this.Modifier_p = '';
            this.noModifierP = true;
          }
          // if (Object.keys(this.Modifier_p).length == 0) {
          //   this.notFound = true;
          // }
        },
        error => { }
      )
    }
  }
  LoadModifier_ASP() {
    this.Modifier_ASP = '';
    this.noModifierASP = false;
    if (this.codeInformation.BASE_CODE_TYPE != undefined) {
      this.service.GetAllowModifier_ASP(this.codeInformation.CODE, this.codeInformation.BASE_CODE_TYPE).subscribe(
        res => {
          if (res.length > 0) {
            this.Modifier_ASP = res;
            this.noModifierASP = false;
          }
          else {
            this.Modifier_ASP = '';
            this.noModifierASP = true;
          }
          // if (Object.keys(this.Modifier_ASP).length == 0) {
          //   this.notFound = true;
          // }
        },
        error => { }
      )
    }
  }
  arrowleft() {
    this.codeInformation.CODE = this.codeInformation.PREVIOUS_VALUE;
    let codetypevalue = this.codeInformation.BASE_CODE_TYPE;
    this.service.getdatabycode(this.codeInformation.CODE).subscribe(
      res => {
        if (res.length <= 1) {
          this.codeInformation = res[0];
        } else {
          for (let i = 0; i <= res.length - 1; i++) {
            if (res[i].BASE_CODE_TYPE == codetypevalue) {
              this.codeInformation = res[i];
            }
          }
        }
        this.checkCrossRef();
        this.LoadColorCodesData();
        this.exmodifier = false;
        this.exmodifierASC = false;
        this.CodeDesc = true;
        this.MueEditsOpen = false;
        this.ExpandLayTerms = false;
        this.ExpandHistorical = false;
        this.ExpandPdf = false;
        this.ExpandMedicare = false;
        this.ExpandFeeSchedule = false;
        this.ExpandFeeLab = false;
        this.ExpandFeeAnesthesia = false;
        this.ExpandCrossWalk = false;
        this.ExpandFeePEN = false;
        this.ExpandFeePOS = false;
        this.ExpandFeeAmbulance = false;
        this.Type1 = false;
        this.Type2 = false;
        this.Type3 = false;
        this.ExpandMips = false;
        this.expandRevenue = false;
        this.expandHCC = false;
        this.ExpandIllustration = false;
      },
      error => { }
    )
  }
  arrowright() {
    this.codeInformation.CODE = this.codeInformation.NEXT_VALUE;
    let codetypevalue1 = this.codeInformation.BASE_CODE_TYPE;
    this.service.getdatabycode(this.codeInformation.CODE).subscribe(
      res => {
        if (res.length <= 1) {
          this.codeInformation = res[0];
        } else {
          for (let i = 0; i <= res.length - 1; i++) {
            if (res[i].BASE_CODE_TYPE == codetypevalue1) {
              this.codeInformation = res[i];
            }
          }
        }
        this.checkCrossRef();
        this.LoadColorCodesData();
        this.exmodifier = false;
        this.exmodifierASC = false;
        this.CodeDesc = true;
        this.MueEditsOpen = false;
        this.ExpandLayTerms = false;
        this.ExpandHistorical = false;
        this.ExpandPdf = false;
        this.ExpandMedicare = false;
        this.ExpandFeeSchedule = false;
        this.ExpandFeeLab = false;
        this.ExpandFeeAnesthesia = false;
        this.ExpandCrossWalk = false;
        this.ExpandFeePEN = false;
        this.ExpandFeePOS = false;
        this.ExpandFeeAmbulance = false;
        this.Type1 = false;
        this.Type2 = false;
        this.Type3 = false;
        this.ExpandMips = false;
        this.expandRevenue = false;
        this.expandHCC = false;
        this.ExpandIllustration = false;
      },
      error => { }
    )
  }
  pdfdatasrc: any;
  Download() {
    this.pdfdatasrc = '';
    this.noDocument = false;
    if (this.codeInformation.CODE != undefined) {
      this.Hcpcscallservice.GetMethod('/HCC/GetPdfByCode?Code=' + this.codeInformation.CODE + '&CodeType=' + this.ApiCodeType.toLowerCase()).subscribe(
        (res: any) => {
          if (JSON.parse(res).error == undefined) {
            this.pdfdatasrc = JSON.parse(res);

            if (Object.keys(this.pdfdatasrc).length == 0) {
              this.noDocument = true;
              this.pdfdatasrc.length = 0;
            }
          }
          else {
            this.noDocument = true;
          }
        },
        error => { }
      )
    }
  }
  downloadFile(url) {
    let pdfurl = "https://realtimeecontent.com/ws" + url;
    this.router.navigate(["pdfview"], { queryParams: { url: pdfurl, Code: this.codeInformation.CODE, CodeType: this.codeInformation.BASE_CODE_TYPE } });
  }
  AddNotesClick() {
    this.Notes.Code = this.codeInformation.CODE;
    this.Notes.CodeNotes = this.codeInformation.NOTES;
    this.service.SaveNotes(this.Notes).subscribe(
      res => {
        if (res) {
          this.AlertMessage.open(AlertComponent, {
            width: '25%',
            data: 'Notes Added Successfully!!!!'
          });
        }
        else {
          this.AlertMessage.open(AlertComponent, {
            width: '25%',
            data: 'Something Went Worng!!!!'
          });
        }
      }
      , error => {

      }
    )

  }
  AddfavoriteClick() {
    this.FavoriteCode.Code = this.codeInformation.CODE;
    this.FavoriteCode.Code_Type = this.codeInformation.BASE_CODE_TYPE;
    this.service.addFavoritCode(this.FavoriteCode).subscribe(
      res => {
        if (res) {
          this.AlertMessage.open(AlertComponent, {
            width: '25%',
            data: 'Favorite Code Added Successfully!!!!'
          });
        }
        else {
          this.AlertMessage.open(AlertComponent, {
            width: '25%',
            data: 'Something Went Worng!!!!'
          });
        }
      }
      , error => {
      }
    )
  }
}


