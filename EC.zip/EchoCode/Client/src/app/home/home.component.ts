import { Component, OnInit, ViewChild } from '@angular/core';
import * as types from '../models/CodeSearch';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';
import {MatSort} from '@angular/material/sort';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Router} from '@angular/router';
import { Service} from '../Services/apicall';
import {MatSnackBar,MatDialog} from '@angular/material';
import{AlertComponent} from '../alert/alert.component';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})


export class HomeComponent implements OnInit {
  now: Date = new Date();
  favcodes:any;
  TextBox1:any;
  TextBox2:any;
  TextBox3:any;
  TextBox4:any;
  TextBox5:any;
  TextBox6:any;
  TextBox7:any;
  TextBox8:any;
  TextBox9:any;
  TextBox10:any;
  NF:any="1";
  CodeCollection=[];
  toppingList: types.topping[] = [
    { value: '1', viewValue: 'CPT' },
    { value: '2', viewValue: 'HCPCS' },
    { value: '3', viewValue: 'ICD-10-CM' }
  ];  
  VersionDate = new Date();
  currentPanel :any;
   
  constructor(private http: HttpClient,public AlertMessage: MatDialog,private route:Router ,private service:Service,private snackBar: MatSnackBar) {
    
   }

  ngOnInit() {        
    this.service.getFavoritedata().subscribe(
      res =>{
        this.favcodes=res;
      },
      error => { }  
    )
   
  }
  // arrowClick(arrowValue:string){
  //   if(arrowValue=='lcd'){
  //     window.open("https://www.cms.gov/medicare-coverage-database/search/advanced-search.aspx");
  //   }
  //   else if(arrowValue=='internet'){
  //     window.open("https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/Internet-Only-Manuals-IOMs");
  //   }
  //   else if(arrowValue=='trans'){
  //     window.open("https://www.cms.gov/Regulations-and-Guidance/Guidance/Transmittals");
  //   }
  //   else if(arrowValue=='mln'){
  //     window.open("https://www.cms.gov/Outreach-and-Education/Medicare-Learning-Network-MLN/MLNMattersArticles");
  //   }
  //   else{

  //   }
  // }
  ValidateClick(){
    // let Textboxdetail=['this.TextBox1'];
    // for(let i=1;i<=6;i++){
      
    // }
    if(this.TextBox1){
  this.CodeCollection.push(this.TextBox1.toUpperCase());
    }
    if(this.TextBox2){
      this.CodeCollection.push(this.TextBox2.toUpperCase());
  }
  if(this.TextBox3){
     this.CodeCollection.push(this.TextBox3.toUpperCase());
     }
  if(this.TextBox4){
     this.CodeCollection.push(this.TextBox4.toUpperCase());
     }
   if(this.TextBox5){
      this.CodeCollection.push(this.TextBox5.toUpperCase());
     }
   if(this.TextBox6){
      this.CodeCollection.push(this.TextBox6.toUpperCase());
    } 
    if(this.TextBox7){
      this.CodeCollection.push(this.TextBox7.toUpperCase());
      }
   if(this.TextBox8){
      this.CodeCollection.push(this.TextBox8.toUpperCase());
      }
    if(this.TextBox9){
       this.CodeCollection.push(this.TextBox9.toUpperCase());
      }
    if(this.TextBox10){
       this.CodeCollection.push(this.TextBox10.toUpperCase());
     }  
    if(Object.keys(this.CodeCollection).length != 0){
    this.route.navigate(["/CCIEDITCHECK"],{queryParams:{CodesDetails:this.CodeCollection,RadioCheck:this.NF}})
    }  
  }
  Clearclick(){
    this.TextBox1='';
    this.TextBox2='';
    this.TextBox3='';
    this.TextBox4='';
    this.TextBox5='';
    this.TextBox6='';
    this.TextBox7='';
    this.TextBox8='';
    this.TextBox9='';
    this.TextBox10='';
  }
  codeInfo1(CodeInfo:types.CodeInfo)
  { 
    if(CodeInfo[0].STATUS != 'D'){      
    this.route.navigate(["/codeinfo"],{ queryParams: { Code: CodeInfo[0].CODE } });
        }
        else{
          let RedirectValue;
          if(CodeInfo[0].BASE_CODE_TYPE == 'CPT')
            {
              RedirectValue="/DeletedCodes";
            }else if(CodeInfo[0].BASE_CODE_TYPE == 'HCPCS')
            {
              RedirectValue="/HcpcsDeletedCode";
            }else if(CodeInfo[0].BASE_CODE_TYPE == 'ICD-CM')
            {
              RedirectValue="/Icd10CmDeletedCodes";
            }else if(CodeInfo[0].BASE_CODE_TYPE == 'ICD-PCS')
            {
              RedirectValue="/Icd10PcsDeletedCodes";
            }
          this.route.navigate([RedirectValue],{queryParams: { Code: CodeInfo[0].CODE}})
        }
        
  }
  FindCode(Code){
    this.service.getdatabycode(Code.Code).subscribe(
      res =>{
        if(res[0].STATUS != 'D'){
        this.route.navigate(["/codeinfo"],{ queryParams: { Code:res[0].CODE} });
        }else{
          this.route.navigate(["/DeletedCodes"])
        }
      },
      error => { }  
    )
  }
  DeleteFavCode(data){
    this.service.DeleteFavCode(data.Code).subscribe(
      res =>{
        if(res){
          this.service.getFavoritedata().subscribe(
            res =>{
              this.favcodes=res;
            },
            error => { }  
          )
          this.AlertMessage.open(AlertComponent,{
            width:'25%',
            data:'Code Deleted Sucessfully!!!!'          
          }); 
          }else{
            this.AlertMessage.open(AlertComponent,{
              width:'25%',
              data:'Something Went Worng!!!!'          
            }); 
       
        }
      },
      error => { }  
    )
  }

}

