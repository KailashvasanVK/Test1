import { Input,Component, OnInit, EventEmitter,Output, ChangeDetectorRef } from '@angular/core';
import { Service} from '../Services/apicall';
import {Router} from '@angular/router';
import { MatSnackBar, MatDialog } from '@angular/material';
import { AlertComponent } from '../alert/alert.component';

@Component({
  selector: 'app-searchbar',
  templateUrl: './searchbar.component.html',
  styleUrls: ['./searchbar.component.css']
})

export class SearchbarComponent implements OnInit {
  allcodes={} as any;
  passwordButton:any;
  passwordMode:any
  simpleProducts:any;
  Codes:any;
 
  @Input() code :any;
  @Input() searchby :any ='Term & Code';
  @Output() codeInfo = new EventEmitter();
  constructor(private service: Service,public AlertMessage: MatDialog,private route:Router,private cd: ChangeDetectorRef) {    
    this.passwordMode = 'password';
    this.simpleProducts = ['Term & Code'];    
    this.passwordButton = {
    icon: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAkCAYAAADhAJiYAAABR0lEQVR4Ae3VAUQDYRiH8XA4HEIYhjBAOIQQBsABAoQDhBAOYTgMEIYBwhDCEMJhCCGEIcAwhCEMwzC8PXgjL3Hn++6K7uEHO+N/5+5ur62t4SL0kaoEPTRejCm2EAtzpAhQawHGkJLe0KtzTAExPvCICQps7HHE8N4t5JsXHMEW4toMe0cH3uqbMXmJ+yPGGqIm8NYMou5RthSidjiEc12I2qLjcDIDOHcOUQWqdgVRMzg3gKghqnYKUQs4lzsO6pqnzeR2yR9Qtdi8KJ1LHM8wM0+oc6F5yZ1V/O8ColJ4aWQ+BQco0w1ErRDCSx1zlV7RxU9FsB/hC3gtwQ6iNhgi1uMhjnGJJcScQC2lZlQZK4gaw3snmJcYskaGwPw+Qi0luMPSjHhChn189ew2yn9RO6od1cCo9C+NmiLArxchR4D/UVvbJ0/xvmJ6b7wKAAAAAElFTkSuQmCC",
    color:"#fff",
    onClick: () => {
     
      if(this.code != undefined && this.code!='')
        {
        this.service.getdatabycode(this.code).subscribe(
        res =>{
          if (res.length == 1){        
            this.codeInfo.emit(res)
          }else if(res.length >1){
            this.route.navigate(["/MultipleCode"],{queryParams:{code:this.code}})
          }else if(res.length == 0)
          {
            this.route.navigate(["/TermSearch"],{queryParams:{Term:this.code}})
          }
        },
        error => { }  
      )
    
  }
}   
 } 
 
}
searchClick() {
  if(this.code.length < 3){
    this.route.navigate(["/allmodifier"],{queryParams:{code:this.code}})
    this.code=null;
  }else{  
    if(this.code.trim() != undefined && this.code.trim() !='')
    {
   this.service.getdatabycode(this.code).subscribe(
    res =>{
      if (res.length == 1){        
        this.codeInfo.emit(res)
      }else if(res.length >1){
        this.route.navigate(["/MultipleCode"],{queryParams:{code:this.code}})
      }else if(res.length == 0)
      {
        this.route.navigate(["/TermSearch"],{queryParams:{Term:this.code}})
      }
    },
    error => { }  
  )
}
  }
}
CodeChanged(){
  if(this.code.length < 3){
    this.route.navigate(["/allmodifier"],{queryParams:{code:this.code}})
    this.code=null;
  }else{ 
  if(this.code.trim() != undefined && this.code.trim()!='')
    {
      this.service.getdatabycode(this.code).subscribe(
        res =>{
          if (res.length == 1){        
            this.codeInfo.emit(res)
          }else if(res.length >1){
            this.route.navigate(["/MultipleCode"],{queryParams:{code:this.code}})
          }else if(res.length == 0)
          {
            this.route.navigate(["/TermSearch"],{queryParams:{Term:this.code}})
          }
        },
        error => { }  
      )
}
  }
}
ngOnInit() {
  this.Codes=[];  
}
ngOnChanges(chg) {
  this.Codes=[];
}
HandleKeyPress(e){
  if(this.code.length < 3){
    this.route.navigate(["/allmodifier"],{queryParams:{code:this.code}})
    this.code=null;
  }else{ 
  this.Codes=[];
  if(e.event.key=='Enter'){
    this.service.getdatabycode(this.code).subscribe(
      res =>{
        if(res.length >0)
          {
            this.codeInfo.emit(res);
          }
      },
      error => { }  
    )
  }
  }
}
CodevalueChanged(data){  
  this.Codes=[];
  // if(data.value != null) {
  //   if(this.allcodes != undefined)
  //     this.Codes= this.allcodes.filter(t => t.CODE.toLowerCase().includes(data.value.toLowerCase()))
  // }
 
  if(data.value != null){
   this.Codes=[];
  let count =+data.value.length;
  if(count >2)
    { 
      this.Codes=[];
     this.service.getAllCodes(data.value).subscribe(
     res =>{     
      this.Codes=[];
      this.Codes=res;  
    },
    error => { }  
  )
  }
}
}
}

