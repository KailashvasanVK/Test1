import { Pipe, PipeTransform } from '@angular/core';
import { HCPCSApiCall } from './Services/HCPCSApiCall';
@Pipe({
  name: 'clientmapping'
})
export class ClientmappingPipe implements PipeTransform {
  data: any;
  constructor(private service: HCPCSApiCall) {
   
    
  }
  transform(value: any, ...args: any[]): any {
    if(this.data ! = undefined)
    var d = this.data.filter(t => t.CLIENT_ID == value)
    return d.CLIENT_NAME;
  }

} 
