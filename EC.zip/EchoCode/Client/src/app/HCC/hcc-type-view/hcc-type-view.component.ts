import { Component, OnInit, ViewChild, HostListener } from '@angular/core';
import { HCPCSApiCall } from '../../Services/HCPCSApiCall';
import { ActivatedRoute, Router } from '@angular/router';
import { SearchbarComponent } from "src/app/searchbar/searchbar.component";

@Component({
  selector: 'app-hcc-type-view',
  templateUrl: './hcc-type-view.component.html',
  styleUrls: ['./hcc-type-view.component.css']
})
export class HccTypeViewComponent implements OnInit {

  constructor(private service: HCPCSApiCall, private router: Router, private route: ActivatedRoute) { }
  @HostListener('window:load', ['$event']) onload($event) {
    this.router.navigate(['/HccTypeView'])
  }
hcctypedatasrc:any;
TypeDetailDatasrc:any;
PreviousValuedhide:any=true;
NextValuedhide:any=true;
CodeType:any;
  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      if (params != undefined) {
        this.CodeType=params.codetype;
        this.service.GetMethod('/HCC/GetHccIcdXwalk?Code='+params.code+'&CodeType='+params.codetype).subscribe(
          res =>{
            this.hcctypedatasrc=res[0];
            if(this.hcctypedatasrc.PREVIOUS_VALUE == null)
              {
                 this.PreviousValuedhide=false;
              }else{
                {
                  this.PreviousValuedhide=true;
               }
              }
              if(this.hcctypedatasrc.NEXT_VALUE == null)
                {
                   this.NextValuedhide=false;
                }else{
                  this.NextValuedhide=true;
               }
          },
          error => { }  
        )
        this.service.GetMethod('/HCC/getXwalkDetails?Code='+params.code+'&CodeType='+params.codetype).subscribe(
          res =>{
            this.TypeDetailDatasrc=res;
          },
          error => { }  
        )
      };
    });
  }
  arrowleft(){
    this.hcctypedatasrc.CODE=this.hcctypedatasrc.PREVIOUS_VALUE;
    this.service.GetMethod('/HCC/GetHccIcdXwalk?Code='+this.hcctypedatasrc.CODE+'&CodeType='+this.CodeType).subscribe(
      res =>{
        this.hcctypedatasrc=res[0];
        if(this.hcctypedatasrc.PREVIOUS_VALUE == null)
          {
             this.PreviousValuedhide=false;
          }else{
            {
              this.PreviousValuedhide=true;
           }
          }
          if(this.hcctypedatasrc.NEXT_VALUE == null)
            {
               this.NextValuedhide=false;
            }else{
              this.NextValuedhide=true;
           }
      },
      error => { }  
    )
    this.service.GetMethod('/HCC/getXwalkDetails?Code='+this.hcctypedatasrc.CODE+'&CodeType='+this.CodeType).subscribe(
      res =>{
        this.TypeDetailDatasrc=res;
      },
      error => { }  
    )
  }
  arrowright(){
    this.hcctypedatasrc.CODE=this.hcctypedatasrc.NEXT_VALUE;
    this.service.GetMethod('/HCC/GetHccIcdXwalk?Code='+this.hcctypedatasrc.CODE+'&CodeType='+this.CodeType).subscribe(
      res =>{
        this.hcctypedatasrc=res[0];
        if(this.hcctypedatasrc.PREVIOUS_VALUE == null)
          {
             this.PreviousValuedhide=false;
          }else{
            {
              this.PreviousValuedhide=true;
           }
          }
          if(this.hcctypedatasrc.NEXT_VALUE == null)
            {
               this.NextValuedhide=false;
            }else{
              this.NextValuedhide=true;
           }
      },
      error => { }  
    )
    this.service.GetMethod('/HCC/getXwalkDetails?Code='+this.hcctypedatasrc.CODE+'&CodeType='+this.CodeType).subscribe(
      res =>{
        this.TypeDetailDatasrc=res;
      },
      error => { }  
    )
  }
  Backclick()
  {
    if(this.CodeType == 'ESRD')
      {
        this.router.navigate(["HccEsrd"]);
      }else if(this.CodeType == 'V22'){
        this.router.navigate(["HccMedicareV22"]);
      }else if(this.CodeType == 'V24'){
        this.router.navigate(["HccMedicareV24"]);
      }else {
        this.router.navigate(["HccRxhcc"]);
      }
  }
  redirectCodeinfo(data){
         
          this.router.navigate(["/codeinfo"],{ queryParams: { Code:data,CodeType:'ICD-CM'} });
       
  }
  TypeView(data:any){
    if(data[0].STATUS == 'D'){
      let RedirectValue;
      if(data[0].BASE_CODE_TYPE == 'CPT')
        {
          RedirectValue="/DeletedCodes";
        }else if(data[0].BASE_CODE_TYPE == 'HCPCS')
        {
          RedirectValue="/HcpcsDeletedCode";
        }else if(data[0].BASE_CODE_TYPE == 'ICD-CM')
        {
          RedirectValue="/Icd10CmDeletedCodes";
        }else if(data[0].BASE_CODE_TYPE == 'ICD-PCS')
        {
          RedirectValue="/Icd10PcsDeletedCodes";
        }
      this.router.navigate([RedirectValue],{queryParams: { Code: data[0].CODE}})
    }else{
      this.router.navigate(["/codeinfo"], { queryParams: { Code: data[0].CODE} });
    }
  }
}
