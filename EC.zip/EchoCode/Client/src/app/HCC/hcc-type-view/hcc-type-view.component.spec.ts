import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HccTypeViewComponent } from './hcc-type-view.component';

describe('HccTypeViewComponent', () => {
  let component: HccTypeViewComponent;
  let fixture: ComponentFixture<HccTypeViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HccTypeViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HccTypeViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
