import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RxhccComponent } from './rxhcc.component';

describe('RxhccComponent', () => {
  let component: RxhccComponent;
  let fixture: ComponentFixture<RxhccComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RxhccComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RxhccComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
