import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Service } from '../../Services/apicall';
import { Router, ActivatedRoute } from '@angular/router';
import { HCPCSApiCall } from '../../Services/HCPCSApiCall';

@Component({
  selector: 'app-rxhcc',
  templateUrl: './rxhcc.component.html',
  styleUrls: ['./rxhcc.component.css']
})
export class RxhccComponent implements OnInit {
  rxHccCodesData:any;
  constructor(private service: Service, private HCPCSService: HCPCSApiCall, private router: Router, private route: ActivatedRoute) { }
  ngOnInit() {
    this.GetRxHccCodes();
  }
  
  rxHccCode(data: any) {
    if (data[0].STATUS == 'D') {
      this.service.GetDeletedCode(data[0].CODE).subscribe(
        res => {
          this.router.navigate(["/DeletedCodes"], { queryParams: { Code: data[0].CODE } })
        },
        error => { }
      )
    } else {
      this.router.navigate(["/codeinfo"], { queryParams: { Code: data[0].CODE} });
    }
  }
  CodeClick(data){
    this.router.navigate(["HccTypeView"],{queryParams: { code: data,codetype:'RX'}})
  }
  GetRxHccCodes() {
    this.HCPCSService.GetMethod('/HCC/GetRxHccCode?CodeType=RXHCC').subscribe(
      (res: any) => {
        this.rxHccCodesData = res;
      },
      error => { }
    )
  }
}
