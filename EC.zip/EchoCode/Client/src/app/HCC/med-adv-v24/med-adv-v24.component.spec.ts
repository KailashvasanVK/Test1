import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MedAdvV24Component } from './med-adv-v24.component';

describe('MedAdvV24Component', () => {
  let component: MedAdvV24Component;
  let fixture: ComponentFixture<MedAdvV24Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MedAdvV24Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedAdvV24Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
