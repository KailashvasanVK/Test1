import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Service } from '../../Services/apicall';
import { Router, ActivatedRoute } from '@angular/router';
import { HCPCSApiCall } from '../../Services/HCPCSApiCall';

@Component({
  selector: 'app-med-adv-v24',
  templateUrl: './med-adv-v24.component.html',
  styleUrls: ['./med-adv-v24.component.css']
})
export class MedAdvV24Component implements OnInit {

  MedAdvV24CodesData: any;
  constructor(private service: Service, private HCPCSService: HCPCSApiCall, private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {
    this.GetMedAdvV24Codes();
  }
  MedAdvV24Code(data: any) {
    if (data[0].STATUS == 'D') {
      this.service.GetDeletedCode(data[0].CODE).subscribe(
        res => {
          this.router.navigate(["/DeletedCodes"], { queryParams: { Code: data[0].CODE } })
        },
        error => { }
      )
    } else {
      this.router.navigate(["/codeinfo"], { queryParams: { Code: data[0].CODE} });
    }
  }
  CodeClick(data){
    this.router.navigate(["HccTypeView"],{queryParams: { code: data,codetype:'V24'}})
  }
  GetMedAdvV24Codes() {
    this.HCPCSService.GetMethod('/HCC/GetRxHccCode?CodeType=MedAdv_V24').subscribe(
      (res: any) => {
        this.MedAdvV24CodesData = res;
      },
      error => { }
    )
  }
}
