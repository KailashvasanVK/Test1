import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MedAdvV22Component } from './med-adv-v22.component';

describe('MedAdvV22Component', () => {
  let component: MedAdvV22Component;
  let fixture: ComponentFixture<MedAdvV22Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MedAdvV22Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedAdvV22Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
