import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Service } from '../../Services/apicall';
import { Router, ActivatedRoute } from '@angular/router';
import { HCPCSApiCall } from '../../Services/HCPCSApiCall';

@Component({
  selector: 'app-med-adv-v22',
  templateUrl: './med-adv-v22.component.html',
  styleUrls: ['./med-adv-v22.component.css']
})
export class MedAdvV22Component implements OnInit {

  MedAdvV22CodesData: any;
  constructor(private service: Service, private HCPCSService: HCPCSApiCall, private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {
    this.GetMedAdvV22Codes();
  }
  MedAdvV22Code(data: any) {
    if (data[0].STATUS == 'D') {
      this.service.GetDeletedCode(data[0].CODE).subscribe(
        res => {
          this.router.navigate(["/DeletedCodes"], { queryParams: { Code: data[0].CODE } })
        },
        error => { }
      )
    } else {
      this.router.navigate(["/codeinfo"], { queryParams: { Code: data[0].CODE} });
    }
  }
  GetMedAdvV22Codes() {
    this.HCPCSService.GetMethod('/HCC/GetRxHccCode?CodeType=MedAdv_V22').subscribe(
      (res: any) => {
        this.MedAdvV22CodesData = res;
      },
      error => { }
    )
  }
  CodeClick(data){
    this.router.navigate(["HccTypeView"],{queryParams: { code: data,codetype:'V22'}})
  }
}
