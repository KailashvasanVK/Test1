import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HccEsrdComponent } from './hcc-esrd.component';

describe('HccEsrdComponent', () => {
  let component: HccEsrdComponent;
  let fixture: ComponentFixture<HccEsrdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HccEsrdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HccEsrdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
