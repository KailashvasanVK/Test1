import { Component, OnInit,HostListener } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Service } from '../../Services/apicall';
import { Router, ActivatedRoute } from '@angular/router';
import { HCPCSApiCall } from '../../Services/HCPCSApiCall';

@Component({
  selector: 'app-hcc-esrd',
  templateUrl: './hcc-esrd.component.html',
  styleUrls: ['./hcc-esrd.component.css']
})
export class HccEsrdComponent implements OnInit {

  EsrdCodesData:any;
  constructor(private service: Service, private HCPCSService: HCPCSApiCall, private router: Router, private route: ActivatedRoute) { }
 
  ngOnInit() {
    this.GetESRDCodes();
  }

  EsrdCode(data: any) {
    if (data[0].STATUS == 'D') {
      this.service.GetDeletedCode(data[0].CODE).subscribe(
        res => {
          this.router.navigate(["/DeletedCodes"], { queryParams: { Code: data[0].CODE } })
        },
        error => { }
      )
    } else {
      this.router.navigate(["/codeinfo"], { queryParams: { Code: data[0].CODE} });
    }
  }

  GetESRDCodes() {
    this.HCPCSService.GetMethod('/HCC/GetRxHccCode?CodeType=ESRD').subscribe(
      (res: any) => {
        this.EsrdCodesData = res;
      },
      error => { }
    )
  }
  CodeClick(data){
    this.router.navigate(["HccTypeView"],{queryParams: { code: data,codetype:'ESRD'}})
  }

}
