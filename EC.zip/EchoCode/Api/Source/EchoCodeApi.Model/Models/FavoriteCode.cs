﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EchoCodeApi.Model.Models
{
   public class FavoriteCode
    {
        public string Code { get; set; }
        public string Code_Type { get; set; }
        public string Login_Id { get; set; }
    }
}
