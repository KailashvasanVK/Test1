﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EchoCodeApi.Model.Models
{
    public class LatestUpdateData
    {
        public int NewsID { get; set; }
        public int Client_Id { get; set; }
        public string News { get; set; }
        public string UserName { get; set; }
        public string Status { get; set; }
    }
}
