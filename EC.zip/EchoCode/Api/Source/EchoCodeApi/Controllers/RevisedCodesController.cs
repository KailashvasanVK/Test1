﻿using EchoCodeApi.Business.Authorization.Interface;
using EchoCodeApi.Entity;
using EchoCodeApi.Models;
using Newtonsoft.Json;
using System;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace EchoCodeApi.Controllers
{
    [Authorize]
    [RoutePrefix("RevisedCodes")]
    public class RevisedCodesController : ApiController
    {
        private readonly IRevisedCodeInfo _revisedCodeInfo;
        private readonly string UserName;
        private readonly DateTime date = DateTime.Now;

        public RevisedCodesController(IRevisedCodeInfo revisedCodeInfo)
        {
            _revisedCodeInfo = revisedCodeInfo;
            UserName = HttpContext.Current.User.Identity.Name.Split(new string[] { @"\" }, StringSplitOptions.None).LastOrDefault();
        }

        [HttpGet]
        [Route("GetNewCodes")]
        public async Task<DataTable> GetNewCodes(string CodeType)
        {
            try
            {
                DataTable data= await _revisedCodeInfo.GetNewCodes(CodeType);
                Searchinfo.SaveUserInfo(CodeType, JsonConvert.SerializeObject(data), "GetNewCodes", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetNewCodes", ex.Message, ex.StackTrace);
                throw;

            }
        }

        [HttpGet]
        [Route("GetRevisedCodes")]
        public async Task<DataTable> GetRevisedCodes(string CodeType)
        {
            try
            {
                DataTable data= await _revisedCodeInfo.GetRevisedCodes(CodeType);
                Searchinfo.SaveUserInfo(CodeType, JsonConvert.SerializeObject(data), "GetRevisedCodes", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetNewCodes", ex.Message, ex.StackTrace);
                throw;

            }
        }


        [HttpGet]
        [Route("GetAllIcdCmDeletedCode")]
        public async Task<DataTable> GetAllHCPCSDeletedCode()
        {
            try
            {
                DataTable data= await _revisedCodeInfo.GetAllIcdCmDeletedCode();
                Searchinfo.SaveUserInfo("", JsonConvert.SerializeObject(data), "GetAllIcdCmDeletedCode", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetAllIcdCmDeletedCode", ex.Message, ex.StackTrace);
                throw;
            }
        }

        [HttpGet]
        [Route("GetAllIcdPcsDeletedCode")]
        public async Task<DataTable> GetAllIcdPcsDeletedCode()
        {
            try
            {
                DataTable data= await _revisedCodeInfo.GetAllIcdPcsDeletedCode();
                Searchinfo.SaveUserInfo("", JsonConvert.SerializeObject(data), "GetAllIcdPcsDeletedCode", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetAllIcdPcsDeletedCode", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetAllIcdPcsDeletedCode")]
        public async Task<DataTable> GetHCpcsSpecNavigation()
        {
            try
            {
                DataTable data = await _revisedCodeInfo.GetHCpcsSpecNavigation();
                Searchinfo.SaveUserInfo("", JsonConvert.SerializeObject(data), "GetHCpcsSpecNavigation", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetHCpcsSpecNavigation", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetCPtspecnavigation")]
        public async Task<DataTable> GetCPtspecnavigation()
        {
            try
            {
                DataTable data = await _revisedCodeInfo.GetCPtspecnavigation();
                Searchinfo.SaveUserInfo("", JsonConvert.SerializeObject(data), "GetCPtspecnavigation", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetCPtspecnavigation", ex.Message, ex.StackTrace);
                throw;
            }
        }

        private void SaveErrorLog(string Method, string Msg, string Stack)
        {
            using (var enitity = new EchoCodeEntities())
            {
                enitity.T_Error_Log.Add(new T_Error_Log
                {
                    MethodName = Method,
                    ErrorMessage = Msg,
                    stacktrace = Stack,
                    CreatedBy = UserName,
                    CreatedOn = date
                });
                enitity.SaveChanges();
            }
        }
    }
}
