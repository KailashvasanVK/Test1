﻿using EchoCodeApi.Business.Authorization.Interface;
using EchoCodeApi.Entity;
using EchoCodeApi.Model.Models;
using EchoCodeApi.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;

using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace EchoCodeApi.Controllers
{
    [Authorize]
    [RoutePrefix("HCPCS")]
    public class HCPCSController : ApiController
    {
        private readonly IHCPCS_CodeInfo _HcpcsCodeInfo;
        private readonly string UserName;
        private readonly DateTime date = DateTime.Now;
        public HCPCSController(IHCPCS_CodeInfo HcpcsCodeInfo)
        {
            _HcpcsCodeInfo = HcpcsCodeInfo;
            UserName = HttpContext.Current.User.Identity.Name.Split(new string[] { @"\" }, StringSplitOptions.None).LastOrDefault();
        }
        [HttpGet]
        [Route("GetAllHCPCSDeletedCode")]
        public async Task<DataTable> GetAllHCPCSDeletedCode()
        {
            try
            {
                DataTable data= await _HcpcsCodeInfo.GetAllHCPCSDeletedCode();
                Searchinfo.SaveUserInfo("", JsonConvert.SerializeObject(data), "GetAllHCPCSDeletedCode", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetAllHCPCSDeletedCode", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetAllClientInfo")]
        public async Task<DataTable> GetAllClientInfo()
        {
            try
            {
                DataTable data= await _HcpcsCodeInfo.GetAllClientInfo();
                Searchinfo.SaveUserInfo("", JsonConvert.SerializeObject(data), "GetAllClientInfo", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetAllClientInfo", ex.Message, ex.StackTrace);

                throw;
            }
        }
        
        [HttpGet]
        [Route("GetLatestUpdateData")]
        public async Task<DataTable> GetLatestUpdateData()
        {
            try
            {
                DataTable data =await _HcpcsCodeInfo.GetLatestUpdateData();
                Searchinfo.SaveUserInfo("", JsonConvert.SerializeObject(data), "GetLatestUpdateData", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetLatestUpdateData", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetDRGCodeData")]
        public async Task<DataTable> GetDRGCodeData(string Code,string CodeType)
        {
            try
            {
                DataTable data= await _HcpcsCodeInfo.GetDRGCodeData(Code,CodeType);
                Searchinfo.SaveUserInfo(Code+";"+CodeType, JsonConvert.SerializeObject(data), "GetDRGCodeData", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetDRGCodeData", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetPCDCodeList")]
        public async Task<DataTable> GetPCDCodeList()
        {
            try
            {
                DataTable data= await _HcpcsCodeInfo.GetPCDCodeList();
                Searchinfo.SaveUserInfo("", JsonConvert.SerializeObject(data), "GetPCDCodeList", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetPCDCodeList", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetApiData")]
        public async Task<string> GetApiData(string Code, string CodeType)
        {
            try
            {
               string data= await _HcpcsCodeInfo.GetApiData(Code,CodeType);
                Searchinfo.SaveUserInfo(Code+";"+CodeType, data, "GetApiData", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetApiData", ex.Message, ex.StackTrace);
                throw;
            }
        }

        [HttpGet]
        [Route("GetInstructionsData")]
        public async Task<string> GetInstructionsData(string Code, string CodeType)
        {
            try
            {
                string data = await _HcpcsCodeInfo.GetInstructionsData(Code, CodeType);
                Searchinfo.SaveUserInfo(Code + ";" + CodeType, data, "GetInstructionsData", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetInstructionsData", ex.Message, ex.StackTrace);
                throw;
            }
        }

        [HttpGet]
        [Route("GetColorCodesData")]
        public async Task<string> GetColorCodesData(string Code, string CodeType)
        {
            try
            {
                string data = await _HcpcsCodeInfo.GetColorCodesData(Code, CodeType);
                Searchinfo.SaveUserInfo(Code + ";" + CodeType, data, "GetColorCodesData", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetColorCodesData", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetIllustrationImages")]
        public async Task<string> GetIllustrationImages(string Code, string CodeType)
        {
            try
            {
                string data = await _HcpcsCodeInfo.GetIllustrationImages(Code, CodeType);
                Searchinfo.SaveUserInfo(Code + ";" + CodeType, data, "GetIllustrationImages", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetIllustrationImages", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetImageFromAPI")]
        public async Task<byte[]> GetImageFromAPI(string ImageLink)
        {
            try
            {
                byte[] data = await _HcpcsCodeInfo.GetImageFromAPI(ImageLink);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetImageFromAPI", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetCrossRevCode")]
        public async Task<string> GetCrossRevCode(string Code, string CodeType)
        {
            try
            {
                string data = await _HcpcsCodeInfo.GetCrossRevCode(Code, CodeType);
                Searchinfo.SaveUserInfo(Code + ";" + CodeType, data, "GetCrossRevCode", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetCrossRevCode", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetHccIcdXwalk")]
        public async Task<DataTable> GetHccIcdXwalk(string Code)
        {
            try
            {
                DataTable data = await _HcpcsCodeInfo.GetHccIcdXwalk(Code);
                Searchinfo.SaveUserInfo(Code ,JsonConvert.SerializeObject(data), "GetHccIcdXwalk", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetHccIcdXwalk", ex.Message, ex.StackTrace);
                throw;
            }
        }
        // GetCrossCptHcpcsCode
        [HttpGet]
        [Route("GetCrossCptHcpcsCode")]
        public async Task<string> GetCrossCptHcpcsCode(string Code, string CodeType)
        {
            try
            {
                string data = await _HcpcsCodeInfo.GetCrossCptHcpcsCode(Code, CodeType);
                Searchinfo.SaveUserInfo(Code + ";" + CodeType, data, "GetCrossCptHcpcsCode", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetCrossCptHcpcsCode", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetHistoricalData")]
        public async Task<string> GetHistoricalData(string Code, string CodeType)
        {
            try
            {
                if(CodeType.Contains("-"))
                {
                    CodeType = CodeType.Replace("-", "10");
                }
                string data = await _HcpcsCodeInfo.GetHistoricalData(Code, CodeType);
                Searchinfo.SaveUserInfo(Code + ";" + CodeType, data, "GetHistoricalData", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetHistoricalData", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetLayTermsData")]
        public async Task<string> GetLayTermsData(string Code, string CodeType)
        {
            try
            {
                string data = await _HcpcsCodeInfo.GetLayTermsData(Code, CodeType);
                Searchinfo.SaveUserInfo(Code + ";" + CodeType, data, "GetLayTermsData", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetLayTermsData", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetInstructionalNotes")]
        public async Task<string> GetInstructionalNotes(string Code)
        {
            try
            {
                string CodeType = "icd10cm";
                string data = await _HcpcsCodeInfo.GetInstructionalNotes(Code, CodeType);
                Searchinfo.SaveUserInfo(Code + ";" + CodeType, data, "GetInstructionalNotes", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetInstructionalNotes", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetIncludesExcludesNotes")]
        public async Task<string> GetIncludesExcludesNotes(string Code)
        {
            try
            {
                string CodeType = "icd10cm";
                string data = await _HcpcsCodeInfo.GetIncludesExcludesNotes(Code, CodeType);
                Searchinfo.SaveUserInfo(Code + ";" + CodeType, data, "GetIncludesExcludesNotes", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetIncludesExcludesNotes", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetICDCMCodeList")]
        public async Task<DataTable> GetICDCMCodeList()
        {
            try
            {
                return await _HcpcsCodeInfo.GetICDCMCodeList();
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetICDCMCodeList", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetHCPCSCodeList")]
        public async Task<DataTable> GetHCPCSCodeList()
        {
            try
            {
                return await _HcpcsCodeInfo.GetHCPCSCodeList();
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetHCPCSCodeList", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetDrgCodeGrp")]
        public async Task<DataTable> GetDrgCodeGrp()
        {
            try
            {
                return await _HcpcsCodeInfo.GetDrgCodeGroup();
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetDrgCodeGrp", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetDrgCodeGrpDtl")]
        public async Task<DataTable> GetDrgCodeGrpDtl(string Code)
        {
            try
            {
                return await _HcpcsCodeInfo.GetDrgCodeDtl(Code);
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetDrgCodeGrpDtl", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetCPTCodeList")]
        public async Task<DataTable> GetCPTCodeList()
        {
            try
            {
                return await _HcpcsCodeInfo.GetCPTCodeList();
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetCPTCodeList", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetMueData")]
        public async Task<DataTable> GetMueData(string Code)
        {
            try
            {
                return await _HcpcsCodeInfo.GetMueData(Code);
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetMueData", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetMedicareCci")]
        public async Task<DataTable> GetMedicareCci(string Code)
        {
            try
            {
                return await _HcpcsCodeInfo.GetMedicareCci(Code);
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetMedicareCci", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetFaclityEditCheck")]
        public async Task<DataTable> GetFaclityEditCheck(string Code)
        {
            try
            {
                Code = Code.Remove(Code.Length - 1, 1);
                return await _HcpcsCodeInfo.GetFacilityEditCheck(Code);
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetFaclityEditCheck", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetNonFaclityEditCheck")]
        public async Task<DataTable> GetNonFaclityEditCheck(string Code)
        {
            try
            {
                Code = Code.Remove(Code.Length - 1, 1);
                return await _HcpcsCodeInfo.GetNonFacilityEditCheck(Code);
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetNonFaclityEditCheck", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetFeeScheduleData")]
        public async Task<DataTable> GetFeeScheduleData(string Code,string Medicare)
        {
            try
            {
                return await _HcpcsCodeInfo.GetFeescheduleData(Code, Medicare);
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetFeeScheduleData", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetMedicareCarrierdata")]
        public async Task<DataTable> GetMedicareCarrierdata()
        {
            try
            {
                return await _HcpcsCodeInfo.GetMedicareCarrierdata();
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetMedicareCarrierdata", ex.Message, ex.StackTrace);
                throw;
            }
        }

        [HttpGet]
        [Route("GetPhysicalUnitsdata")]
        public async Task<DataTable> GetPhysicalUnitsdata()
        {
            try
            {
                return await _HcpcsCodeInfo.GetPhysicalUnitsdata();
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetPhysicalUnitsdata", ex.Message, ex.StackTrace);
                throw;
            }
        }

        [HttpGet]
        [Route("GetQualifyUnitsdata")]
        public async Task<DataTable> GetQualifyUnitsdata()
        {
            try
            {
                return await _HcpcsCodeInfo.GetQualifyUnitsdata();
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetQualifyUnitsdata", ex.Message, ex.StackTrace);
                throw;
            }
        }
        // GetFeeAnesthesiaData
        [HttpGet]
        [Route("GetFeeAnesthesiaData")]
        public async Task<DataTable> GetFeeAnesthesiaData(string Code, string LocalityValue)
        {
            try
            {
                return await _HcpcsCodeInfo.GetFeeAnesthesiaData(Code, LocalityValue);
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetFeeAnesthesiaData", ex.Message, ex.StackTrace);
                throw;
            }
        }

        [HttpPost]
        [Route("AddLatestUpdate")]
        public async Task<IHttpActionResult> AddLatestUpdate(HttpRequestMessage LatestUpdateData)
        {
            try
            {
                var content = LatestUpdateData.Content;
                string jsonContent = content.ReadAsStringAsync().Result;
                LatestUpdateData News = Newtonsoft.Json.JsonConvert.DeserializeObject<LatestUpdateData>(jsonContent);
                News.UserName = UserName;
                bool res =await _HcpcsCodeInfo.AddLatestUpdate(News);
                return Ok(true); 
            }
            catch (Exception ex)
            {
                SaveErrorLog("AddLatestUpdate",ex.Message,ex.StackTrace);
                throw;
            }
        }
        private void SaveErrorLog(string Method, string Msg, string Stack)
        {
            try
            {
                using (var enitity = new EchoCodeEntities())
                {
                    enitity.T_Error_Log.Add(new T_Error_Log
                    {
                        MethodName = Method,
                        ErrorMessage = Msg,
                        stacktrace = Stack,
                        CreatedBy = UserName,
                        CreatedOn = date
                    });
                    enitity.SaveChanges();
                }
            }
            catch (Exception ex)
            {

                throw;
            }
            
        }
    }
}
