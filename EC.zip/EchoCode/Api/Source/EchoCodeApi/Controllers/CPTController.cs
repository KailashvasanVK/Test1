﻿using EchoCodeApi.Business.Authorization.Interface;
using EchoCodeApi.Entity;
using EchoCodeApi.Models;
using Newtonsoft.Json;
using System;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace EchoCodeApi.Controllers
{
    [Authorize]
    [RoutePrefix("CPT")]
    public class CPTController : ApiController
    {
        private readonly ICodesInformation _codeInformation;
        private readonly string UserName;
        private readonly DateTime date = DateTime.Now;
        public CPTController(ICodesInformation codesInformation)
        {
            _codeInformation = codesInformation;
            UserName= HttpContext.Current.User.Identity.Name.Split(new string[] { @"\" }, StringSplitOptions.None).LastOrDefault();
        }

        [HttpGet]
        [Route("GetCptDeletedCodes")]
        public async Task<DataTable> GetCptDeletedCodes(string Code)
        {
            try
            {
                DataTable data= await _codeInformation.GetCPTDeletedCdes(Code);
                Searchinfo.SaveUserInfo(Code, JsonConvert.SerializeObject(data), "GetCptDeletedCodes", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetCptDeletedCodes", ex.Message,ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetAllCPTDeletedCode")]
        public async Task<DataTable> GetAllCPTDeletedCode()
        {
            try
            {
                return await _codeInformation.GetAllCPTDeletedCode();
            }
            catch (Exception ex)
            {

                SaveErrorLog("GetAllCPTDeletedCode", ex.Message,ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetAllCPTModifierCodeLink")]
        public async Task<DataTable> GetAllCPTModifierCodeLink(string CodeType)
        {
            try
            {
                DataTable data =await _codeInformation.GetAllCPTModifierCodeLink(CodeType);
                Searchinfo.SaveUserInfo(CodeType, JsonConvert.SerializeObject(data), "GetAllCPTModifierCodeLink", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetAllCPTModifierCodeLink", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetAllCPTModifierCode")]
        public async Task<DataTable> GetAllCPTModifierCode(string Code, string CodeType)
        {
            try
            {
                DataTable data= await _codeInformation.GetAllCPTModifierCode(Code, CodeType);
                Searchinfo.SaveUserInfo(Code+";"+CodeType, JsonConvert.SerializeObject(data), "GetAllCPTModifierCode", UserName);
                return data;
            }

            catch (Exception ex)
            {

                SaveErrorLog("GetAllCPTModifierCode", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetCrossWalkData")]
        public async Task<DataTable> GetCrossWalkData(string Code, string CodeType,string Alpha)
        {
            try
            {
                DataTable data= await _codeInformation.GetCrossCodeData(Code, CodeType, Alpha);
                Searchinfo.SaveUserInfo(Code + ";" + CodeType, JsonConvert.SerializeObject(data), "GetCrossWalkData", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetCrossWalkData", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetAllowModifierdataP")]
        public async Task<DataTable> GetAllowModifierdataP(string Code,string CodeType)
        {
            try
            {
                DataTable data= await _codeInformation.GetModifierCodeCPTHCPCS(Code, CodeType);
                Searchinfo.SaveUserInfo(Code + ";" + CodeType, JsonConvert.SerializeObject(data), "GetAllowModifierdataP", UserName);
                return await _codeInformation.GetModifierCodeCPTHCPCS(Code, CodeType);
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetAllowModifierdataP", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetAllowModifierdataASP")]
        public async Task<DataTable> GetAllowModifierdataASP(string Code, string CodeType)
        {
            try
            {
                DataTable data= await _codeInformation.GetModifierCodeASP(Code, CodeType);
                Searchinfo.SaveUserInfo(Code + ";" + CodeType, JsonConvert.SerializeObject(data), "GetAllowModifierdataASP", UserName);
                return data;
            }

            catch (Exception ex)
            {

                SaveErrorLog("GetAllowModifierdataASP", ex.Message, ex.StackTrace);
                throw;
            }
        }
        private void SaveErrorLog(string Method, string Msg, string Stack)
        {
            using (var enitity = new EchoCodeEntities())
            {
                enitity.T_Error_Log.Add(new T_Error_Log
                {
                    MethodName = Method,
                    ErrorMessage = Msg,
                    stacktrace = Stack,
                    CreatedBy = UserName,
                    CreatedOn = date
                });
                enitity.SaveChanges();
            }
        }
    }
}
