﻿using EchoCodeApi.Business.Authorization.Interface;
using System;
using System.Web.Http;

namespace EchoCodeApi.Controllers
{
    [Authorize]
    [RoutePrefix("api/values")]
    public class ValuesController : ApiController
    {
        private readonly IUserInformation _userInformation;
        
       public ValuesController(IUserInformation userInformation)
        {
            _userInformation = userInformation;
        }   
       
        [HttpGet]
        [Route("GetUserName")]
       public string GetUserName()
        {
            try
            {
                string UserName = _userInformation.GetUsernameProvider();
                return UserName;
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
