﻿using EchoCodeApi.Business.Authorization.Interface;
using EchoCodeApi.Entity;
using EchoCodeApi.Model.Models;
using EchoCodeApi.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;

using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace EchoCodeApi.Controllers
{
    [Authorize]
    [RoutePrefix("HCC")]
    public class HCCController : ApiController
    {
        private readonly IHCC_CodeInfo _HccCodeInfo;
        private readonly string UserName;
        private readonly DateTime date = DateTime.Now;
        public HCCController()
        {
        }
        public HCCController(IHCC_CodeInfo HccCodeInfo)
        {
            _HccCodeInfo = HccCodeInfo;
            UserName = HttpContext.Current.User.Identity.Name.Split(new string[] { @"\" }, StringSplitOptions.None).LastOrDefault();
        }
        [HttpGet]
        [Route("GetRxHccCode")]
        public async Task<DataTable> GetRxHccCode(string CodeType)
        {
            try
            {DataTable data= await _HccCodeInfo.GetRxHccCode(CodeType);
                Searchinfo.SaveUserInfo(CodeType, JsonConvert.SerializeObject(data), "GetRxHccCode", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetRxHccCode", ex.Message, ex.StackTrace);
                throw;
            }
        }

        [HttpGet]
        [Route("getXwalkDetails")]
        public async Task<DataTable> getXwalkDetails(string Code,string CodeType)
        {
            try
            {
                DataTable data= await _HccCodeInfo.getXwalkDetails(Code,CodeType);
                Searchinfo.SaveUserInfo(Code+";"+CodeType, JsonConvert.SerializeObject(data), "getXwalkDetails", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("getXwalkDetails", ex.Message, ex.StackTrace);
                throw;
            }
        }

        [HttpGet]
        [Route("GetHccIcdXwalk")]
        public async Task<DataTable> GetHccIcdXwalk(string Code,string CodeType)
        {
            try
            {
                DataTable data= await _HccCodeInfo.GetHccIcdXwalk(Code,CodeType);
                Searchinfo.SaveUserInfo(Code + ";" + CodeType, JsonConvert.SerializeObject(data), "GetHccIcdXwalk", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetHccIcdXwalk", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("getmaidata")]
        public async Task<DataTable> getmaidata()
        {
            try
            {
                DataTable data= await _HccCodeInfo.getmaidesc();
                Searchinfo.SaveUserInfo("", JsonConvert.SerializeObject(data), "getmaidata", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("getmaidata", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetPdfByCode")]
        public async Task<string> GetPdfByCode(string Code, string CodeType)
        {
            try
            {
                string data= await _HccCodeInfo.GetPdfByCode(Code, CodeType);
                Searchinfo.SaveUserInfo(Code+";"+CodeType, data, "GetPdfByCode", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetPdfByCode", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetIndexSearchData")]
        public async Task<string> GetIndexSearchData(string Code, string CodeType)
        {
            try
            {
                string data = await _HccCodeInfo.IndexSearchdata(Code, CodeType);
                Searchinfo.SaveUserInfo(Code + ";" + CodeType, data, "GetIndexSearchData", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetPdfByCode", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetAllModifierData")]
        public async Task<DataTable> GetAllModifierData(string data)
        {
            try
            {
                DataTable result = await _HccCodeInfo.GetAllModifierdata(data);
                Searchinfo.SaveUserInfo(data, JsonConvert.SerializeObject(result), "GetAllModifierData", UserName);
                return result;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetPdfByCode", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("getpdfAuth")]
        public async Task<byte[]> getpdfAuth(string url)
        {
            try
            {
                return await _HccCodeInfo.getpdfAuth(url);
            }
            catch (Exception ex)
            {
                SaveErrorLog("getpdfAuth", ex.Message, ex.StackTrace);
                throw;
            }
        }
        private void SaveErrorLog(string Method, string Msg, string Stack)
        {
            try
            {
                using (var enitity = new EchoCodeEntities())
                {
                    enitity.T_Error_Log.Add(new T_Error_Log
                    {
                        MethodName = Method,
                        ErrorMessage = Msg,
                        stacktrace = Stack,
                        CreatedBy = UserName,
                        CreatedOn = date
                    });
                    enitity.SaveChanges();
                }
            }
            catch (Exception ex)
            {

                throw;
            }
            
        }
    }
}
