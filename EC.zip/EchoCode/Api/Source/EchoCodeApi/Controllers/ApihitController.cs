﻿using EchoCodeApi.Business.Authorization.Interface;
using EchoCodeApi.Entity;
using EchoCodeApi.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace EchoCodeApi.Controllers
{
    [Authorize]
    [RoutePrefix("Apihit")]
    public class ApihitController : ApiController
    {
        private readonly IApiInformation _ApiInformation;

        private readonly string UserName;
        private readonly DateTime date = DateTime.Now;
        public ApihitController(IApiInformation apiInformation)
        {
            _ApiInformation = apiInformation;
            UserName = HttpContext.Current.User.Identity.Name.Split(new string[] { @"\" }, StringSplitOptions.None).LastOrDefault();
        }
        [HttpGet]
        [Route("GetApiTreeData")]
        public async Task<string> GetApiTreeData(string Term, string CodeType)
        {
            try
            {
                
                string data = await _ApiInformation.GetApiTreeData(Term, CodeType);
                Searchinfo.SaveUserInfo($"{Term},{CodeType}", data, "TermSearch", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetApiTreeData", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetGlobalCalcData")]
        public async Task<DataTable> GetGlobalCalcData (string Date, string Codes)
        {
            try
            {
                DateTime Datetimedata = DateTime.Parse(Date);
                Codes = Codes.Remove(Codes.Length - 1, 1);
                DataTable data = await _ApiInformation.GetGlobalCalcData(Datetimedata, Codes);
                Searchinfo.SaveUserInfo(data+";"+Codes,JsonConvert.SerializeObject(data), "GetGlobalCalcData", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetGlobalCalcData", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetGlobalSurgData")]
        public async Task<DataTable> GetGlobalSurgData()
        {
            try
            {
                DataTable data = await _ApiInformation.GetGlobalSurgData();
                Searchinfo.SaveUserInfo("", JsonConvert.SerializeObject(data), "GetGlobalSurgData", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetGlobalCalcData", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetSpecialtyData")]
        public async Task<DataTable> GetSpecialtyData()
        {
            try
            {
                DataTable data = await _ApiInformation.GetSpecialtyData();
                Searchinfo.SaveUserInfo("", JsonConvert.SerializeObject(data), "GetSpecialtyData", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetSpecialtyData", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetFeeStates")]
        public async Task<DataTable> GetFeeStates()
        {
            try
            {
                DataTable data = await _ApiInformation.GetFeeStates();
                Searchinfo.SaveUserInfo("", JsonConvert.SerializeObject(data), "GetFeeStates", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetFeeStates", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetSpecialtyGridData")]
        public async Task<DataTable> GetSpecialtyGridData(string Code,string Speciality)
        {
            try
            {
                DataTable data = await _ApiInformation.GetSpecialtygridData(Code,Speciality);
                Searchinfo.SaveUserInfo(Code+";"+ Speciality, JsonConvert.SerializeObject(data), "GetSpecialtyGridData", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetSpecialtyGridData", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetFeeDmePen")]
        public async Task<DataTable> GetFeeDmePen(string Code, string State)
        {
            try
            {
                DataTable data = await _ApiInformation.GetFeeDmePen(Code, State);
                Searchinfo.SaveUserInfo(Code + ";" + State, JsonConvert.SerializeObject(data), "GetFeeDmePen", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetFeeDmePen", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetFeeAmbulancedata")]
        public async Task<DataTable> GetFeeAmbulancedata(string Code, string State)
        {
            try
            {
                DataTable data = await _ApiInformation.GetFeeAmbulancedata(Code, State);
                Searchinfo.SaveUserInfo(Code + ";" + State, JsonConvert.SerializeObject(data), "GetFeeAmbulancedata", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetFeeAmbulancedata", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetFeeDmePos")]
        public async Task<DataTable> GetFeeDmePos(string Code, string State)
        {
            try
            {
                DataTable data = await _ApiInformation.GetFeeDmePos(Code, State);
                Searchinfo.SaveUserInfo(Code + ";" + State, JsonConvert.SerializeObject(data), "GetFeeDmePos", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetFeeDmePos", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetFeeLabData")]
        public async Task<DataTable> GetFeeLabData(string Code)
        {
            try
            {
                DataTable data = await _ApiInformation.GetFeeLabData(Code);
                Searchinfo.SaveUserInfo(Code, JsonConvert.SerializeObject(data), "GetFeeLabData", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetSpecialtyData", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetAsaCrossWalkData")]
        public async Task<DataTable> GetAsaCrossWalkData(string Code)
        {
            try
            {
                DataTable data = await _ApiInformation.GetAsaCrossWalkData(Code);
                Searchinfo.SaveUserInfo(Code, JsonConvert.SerializeObject(data), "GetAsaCrossWalkData", UserName);
                return data;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetSpecialtyData", ex.Message, ex.StackTrace);
                throw;
            }
        }
        private void SaveErrorLog(string Method, string Msg, string Stack)
        {
            try
            {
                using (var enitity = new EchoCodeEntities())
                {
                    enitity.T_Error_Log.Add(new T_Error_Log
                    {
                        MethodName = Method,
                        ErrorMessage = Msg,
                        stacktrace = Stack,
                        CreatedBy = UserName,
                        CreatedOn = date
                    });
                    enitity.SaveChanges();
                }
            }
            catch (Exception ex)
            {

                throw;
            }

        }
    }
}
