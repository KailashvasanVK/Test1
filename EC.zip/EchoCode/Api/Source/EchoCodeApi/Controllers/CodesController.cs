﻿using EchoCodeApi.Business.Authorization.Interface;
using EchoCodeApi.Entity;
using EchoCodeApi.Model.Models;
using EchoCodeApi.Models;
using Newtonsoft.Json;
using System;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.Description;

namespace EchoCodeApi.Controllers
{
    [Authorize]
    [RoutePrefix("Codes")]
    public class CodesController : ApiController
    {
        
        private readonly ICodesInformation _codeInformation;
        private readonly string UserName;
        private readonly DateTime date = DateTime.Now;
        string JSONresult;
        public CodesController(ICodesInformation codesInformation)
        {
            _codeInformation = codesInformation;
            UserName = HttpContext.Current.User.Identity.Name.Split(new string[] { @"\" }, StringSplitOptions.None).LastOrDefault();
        }
        [HttpGet]
        [Route("Getallcodes")]
        public async Task<DataTable> Getallcodes(string Code)
        {
            try
            {
                //Task<DataTable> task = new Task<DataTable>(_codeInformation.Getallcodes);
                //task.Start();
                //DataTable dt = await task;
                //return dt;
                DataTable dt = _codeInformation.Getallcodes(Code);                
                return dt;
            }
            catch (Exception ex)
            {
                SaveErrorLog("Getallcodes", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpGet]
        [Route("GetDataByCode")]
        public DataTable GetDataByCode(string Code)
        {
            try
            {
                DataTable dt = _codeInformation.GetDataByCode(Code, UserName);                
                JSONresult = JsonConvert.SerializeObject(dt);
                Searchinfo.SaveUserInfo(Code, JSONresult, "CodeInfoSearch",UserName);
                return dt;
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetDataByCode", ex.Message, ex.StackTrace);
                throw;               

            }
        }
        [HttpGet]
        [Route("DeleteFavCode")]
        public async Task<bool> DeleteFavCode(string Code)
        {
            try
            {
                return await _codeInformation.DeleteFavCode(Code);
            }
            catch (Exception ex)
            {
                SaveErrorLog("DeleteFavCode", ex.Message, ex.StackTrace);
                throw;
                
            }
        }
        [HttpGet]
        [Route("GetFavoriteData")]
        public async Task<object> GetFavoriteData()
        {
            try
            {
                return await _codeInformation.GetFavoriteData(UserName);
            }
            catch (Exception ex)
            {
                SaveErrorLog("GetFavoriteData", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpPost]
        [Route("SaveFavoriteCode")]
        public async Task<IHttpActionResult> SaveFavoriteCode(HttpRequestMessage favoriteCode)
        {
            try
            {
                var content = favoriteCode.Content;
                string jsonContent = content.ReadAsStringAsync().Result;
                FavoriteCode code = Newtonsoft.Json.JsonConvert.DeserializeObject<FavoriteCode>(jsonContent);
                code.Login_Id = UserName;
                bool res =await _codeInformation.AddFavoriteCode(code);
                if (true)     
                    return Ok(true);                               
            }
            catch (Exception ex)
            {
                SaveErrorLog("SaveFavoriteCode", ex.Message, ex.StackTrace);
                throw;
            }
        }
        [HttpPost]
        [Route("SaveNotes")]
        public async Task<IHttpActionResult> SaveNotes(HttpRequestMessage Notes)
        {
            try
            {
                var content = Notes.Content;
                string jsonContent = content.ReadAsStringAsync().Result;
                Notes code = Newtonsoft.Json.JsonConvert.DeserializeObject<Notes>(jsonContent);
                code.Login_Id = UserName;
                bool res = await _codeInformation.AddNotes(code);
                if (true)
                    return Ok(true);
            }
            catch (Exception ex)
            {
                SaveErrorLog("SaveNotes", ex.Message, ex.StackTrace);
                throw;
                
            }
        }
        [HttpGet]
        [Route("GetUserName")]
        public string GetUserName()
        {
            try
            {
                
                return UserName;
            }
            catch (Exception ex)
            {

                SaveErrorLog("GetUserName",ex.Message,ex.StackTrace);
                    throw;
                
            }
        }
        private void SaveErrorLog(string Method, string Msg, string Stack)
        {
            using (var enitity = new EchoCodeEntities())
            {
                enitity.T_Error_Log.Add(new T_Error_Log
                {
                    MethodName = Method,
                    ErrorMessage = Msg,
                    stacktrace = Stack,
                    CreatedBy = UserName,
                    CreatedOn = date
                });
                enitity.SaveChanges();
            }
        }
        
    }
}
