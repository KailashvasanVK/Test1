﻿using EchoCodeApi.Entity;
using System;

namespace EchoCodeApi.Models
{
    public static class Searchinfo
    {
        private  readonly static DateTime date = DateTime.Now;
        internal async static void SaveUserInfo(string Input, string Responce, string Module,string UserName)
        {
            using (var enitity = new EchoCodeEntities())
            {
                enitity.T_User_Log_Info.Add(new T_User_Log_Info
                {
                    Input = Input,
                    Responce = Responce,
                    Username = UserName,
                    CreatedOn = date,
                    Module = Module
                });
                enitity.SaveChanges();
            }
        }
    }
}