﻿using EchoCodeApi.Business.Authorization.Implementation;
using EchoCodeApi.Business.Authorization.Interface;
using EchoCodeApi.DataAccess.Authorization.Implementation;
using EchoCodeApi.DataAccess.Authorization.Interface;
using EchoCodeApi.Models;
using System.Web.Http;
using System.Web.Http.Cors;
using Unity;

namespace EchoCodeApi
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services

            // Web API routes
            var container = new UnityContainer();
            container.RegisterType<IUserInformation, userInformation>();
            container.RegisterType<IuserInformationProvider, UserInformationProvider>();
            container.RegisterType<ICodesInformation,CodesInformation>();
            container.RegisterType<ICodesInformationProvider, CodesInformationProvider>();
            container.RegisterType<IHCPCS_CodeInfo, HCPCS_CodeInfo>();
            container.RegisterType<IHCPCS_CodeInfoProvider, HCPCS_CodeInfoProvider>();
            container.RegisterType<IApiInformation, ApiInformation>();
            container.RegisterType<IApiInformationProvider, ApiInformationProvider>();
            container.RegisterType<IRevisedCodeInfo, RevisedCodeInfo>();
            container.RegisterType<IRevicedCodeInfoProvider, RevisedCodeInfoProvider>();
            container.RegisterType<IHCC_CodeInfo, HCC_CodeInfo>();
            container.RegisterType<IHCC_CodeInfoProvider, HCC_CodeInfoProvider>();
            config.DependencyResolver = new UnityResolver(container);
            //config.MessageHandlers.Add(new CorsHandler());
            config.MapHttpAttributeRoutes();
            //var corsAttr = new EnableCorsAttribute("http://localhost:4200", "*","GET,POST");
            //config.EnableCors(corsAttr);

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );
        }
    }
}
