using EchoCodeApi.Business.Authorization.Implementation;
using EchoCodeApi.Business.Authorization.Interface;
using EchoCodeApi.DataAccess.Authorization.Implementation;
using EchoCodeApi.DataAccess.Authorization.Interface;

using System.Web.Mvc;
using Unity;
using Unity.Mvc5;

namespace EchoCodeApi
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
			var container = new UnityContainer();

            // register all your components with the container here
            // it is NOT necessary to register your controllers

            // e.g. container.RegisterType<ITestService, TestService>();
            
            DependencyResolver.SetResolver(new UnityDependencyResolver(container));
        }
    }
}