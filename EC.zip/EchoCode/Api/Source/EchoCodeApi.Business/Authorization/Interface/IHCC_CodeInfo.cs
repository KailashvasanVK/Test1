﻿using EchoCodeApi.Model.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EchoCodeApi.Business.Authorization.Interface
{
    public interface IHCC_CodeInfo
    {
        Task<DataTable> GetRxHccCode(string CodeType);
        Task<DataTable> getXwalkDetails(string Code, string CodeType);

        Task<DataTable> GetHccIcdXwalk(string Code, string CodeType);
        Task<string> GetPdfByCode(string Code, string CodeType);
        Task<byte[]> getpdfAuth(string url);
        Task<DataTable> getmaidesc();
        Task<string> IndexSearchdata(string Code, string CodeType);
        Task<DataTable> GetAllModifierdata(string data);
    }
}
