﻿using EchoCodeApi.Model.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EchoCodeApi.Business.Authorization.Interface
{
    public interface ICodesInformation
    {
        DataTable Getallcodes(string Code);
        Task<DataTable> GetAllCPTModifierCodeLink(string CodeType);
        Task<DataTable> GetCrossCodeData(string Code, string CodeType, string Alpha);
        Task<DataTable> GetModifierCodeASP(string Code, string CodeType);
        Task<DataTable> GetModifierCodeCPTHCPCS(string Code, string Codetype);

        Task<DataTable> GetAllCPTModifierCode(string Code, string CodeType);
        DataTable GetDataByCode(string Code,string UserName);
        Task<bool> AddFavoriteCode(FavoriteCode favoriteCode);
        Task<object> GetFavoriteData(string UserName);

        Task<bool> DeleteFavCode(string Code);

        Task<bool> AddNotes(Notes notes);
        Task<DataTable> GetCPTDeletedCdes(string Code);

        Task<DataTable> GetAllCPTDeletedCode();
    }
}
