﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EchoCodeApi.Business.Authorization.Interface
{
    public interface IRevisedCodeInfo
    {
        Task<DataTable> GetNewCodes(string CodeType);
        Task<DataTable> GetRevisedCodes(string CodeType);
        Task<DataTable> GetAllIcdCmDeletedCode();
        Task<DataTable> GetAllIcdPcsDeletedCode();
        Task<DataTable> GetHCpcsSpecNavigation();
        Task<DataTable> GetCPtspecnavigation();
    }
}
