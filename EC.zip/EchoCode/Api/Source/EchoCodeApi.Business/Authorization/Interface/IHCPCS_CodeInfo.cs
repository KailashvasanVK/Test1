﻿using EchoCodeApi.Model.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EchoCodeApi.Business.Authorization.Interface
{
    public interface IHCPCS_CodeInfo
    {
        Task<string> GetApiData(string Code, string CodeType);
        Task<DataTable> GetNonFacilityEditCheck(string Code);
        Task<DataTable> GetMedicareCarrierdata();
        Task<string> GetIncludesExcludesNotes(string Code, string CodeType);
        Task<string> GetInstructionalNotes(string Code, string CodeType);
        Task<DataTable> GetFacilityEditCheck(string Code);
        Task<DataTable> GetDrgCodeDtl(string Code);
        Task<DataTable> GetDrgCodeGroup();
        Task<DataTable> GetAllHCPCSDeletedCode();
        Task<DataTable> GetMueData(string Code);
        Task<DataTable> GetFeescheduleData(string Code, string Medicare);
        Task<string> GetHistoricalData(string Code, string CodeType);
        Task<string> GetLayTermsData(string Code, string CodeType);
        Task<DataTable> GetAllClientInfo();
        Task<DataTable> GetHccIcdXwalk(string Code);
        Task<DataTable> GetDRGCodeData(string Code, string CodeType);
        Task<DataTable> GetCPTCodeList();
        Task<DataTable> GetHCPCSCodeList();
        Task<DataTable> GetMedicareCci(string Code);
        Task<DataTable> GetICDCMCodeList();
        Task<DataTable> GetPCDCodeList();
        Task<DataTable> GetLatestUpdateData();
        Task<bool> AddLatestUpdate(LatestUpdateData latestUpdateData);
        Task<DataTable> GetPhysicalUnitsdata();
        Task<DataTable> GetQualifyUnitsdata();
        Task<DataTable> GetFeeAnesthesiaData(string Code, string LocalityValue);
        Task<string> GetInstructionsData(string Code, string CodeType);
        Task<string> GetColorCodesData(string Code, string CodeType);
        Task<string> GetIllustrationImages(string Code, string CodeType);
        Task<byte[]> GetImageFromAPI(string ImageLink);
        Task<string> GetCrossRevCode(string Code, string CodeType);
        Task<string> GetCrossCptHcpcsCode(string Code, string CodeType);

    }
}
