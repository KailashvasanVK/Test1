﻿
namespace EchoCodeApi.Business.Authorization.Interface
{
    public interface IUserInformation
    {
        string GetUsernameProvider();
    }
}
