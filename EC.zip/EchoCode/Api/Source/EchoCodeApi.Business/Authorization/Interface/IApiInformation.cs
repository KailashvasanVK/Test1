﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EchoCodeApi.Business.Authorization.Interface
{
   public interface IApiInformation
    {
        Task<string> GetApiTreeData(string Term, string CodeType);
        Task<DataTable> GetGlobalCalcData(DateTime Date, string Codes);

        Task<DataTable> GetGlobalSurgData();
        Task<DataTable> GetSpecialtyData();
        Task<DataTable> GetSpecialtygridData(string Code, string Speciality);
        Task<DataTable> GetFeeLabData(string Code);
        Task<DataTable> GetAsaCrossWalkData(string Code);
        Task<DataTable> GetFeeDmePen(string Code, string State);
        Task<DataTable> GetFeeStates();

        Task<DataTable> GetFeeDmePos(string Code, string State);

        Task<DataTable> GetFeeAmbulancedata(string Code, string State);

    }
}
