﻿using EchoCodeApi.Business.Authorization.Interface;
using EchoCodeApi.DataAccess.Authorization.Implementation;
using EchoCodeApi.DataAccess.Authorization.Interface;
using System;

namespace EchoCodeApi.Business.Authorization.Implementation
{
    public class userInformation : IUserInformation
    {
        private readonly IuserInformationProvider _userInformationProvider;
        public userInformation(IuserInformationProvider userInformationProvider)
        {
            _userInformationProvider = userInformationProvider;
        }
        
        public string GetUsernameProvider()
        {
            try
            {
                string UserName = _userInformationProvider.GetUserName();
                return UserName;
            }
            catch (Exception ex)
            {
                throw;
            }
           
        }
        
    }
}
