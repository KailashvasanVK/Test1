﻿using EchoCodeApi.Business.Authorization.Interface;
using EchoCodeApi.DataAccess.Authorization.Interface;
using EchoCodeApi.Model.Models;
using System;
using System.Data;
using System.Threading.Tasks;

namespace EchoCodeApi.Business.Authorization.Implementation
{
    public class CodesInformation : ICodesInformation
    {
        private readonly ICodesInformationProvider _codesInformationProvider;
        public CodesInformation(ICodesInformationProvider codesInformationProvider )
        {
            _codesInformationProvider = codesInformationProvider;
        }
        public DataTable Getallcodes(string Code)
        {
            try
            {
                DataTable Codes = _codesInformationProvider.Getallcodes(Code);
                return Codes;
            }
            catch (Exception)
            {

                throw;
            }          
        }
        public async Task<DataTable> GetCPTDeletedCdes(string Code)
        {
            try
            {
                DataTable Codes =await _codesInformationProvider.GetCptDeletedCodes(Code);
                return Codes;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetAllCPTModifierCode(string Code,string CodeType)
        {
            try
            {
                DataTable Codes =await _codesInformationProvider.GetAllCPTModifierCode(Code, CodeType);
                return Codes;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetAllCPTDeletedCode()
        {
            try
            {
                DataTable Codes =await _codesInformationProvider.GetAllCPTDeletedCode();
                return Codes;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetAllCPTModifierCodeLink(string CodeType)
        {
            try
            {
                DataTable Codes =await _codesInformationProvider.GetAllCPTModifierCodeLink(CodeType);
                return Codes;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public  DataTable GetDataByCode(string Code,string UserName)
        {
            try
            {
                DataTable Codedata = _codesInformationProvider.GetDataByCode(Code, UserName);
                return Codedata;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetCrossCodeData(string Code, string CodeType, string Alpha)
        {
            try
            {
                DataTable CrossCodeData =await _codesInformationProvider.GetCrossWalkData(Code, CodeType,Alpha);
                return CrossCodeData;
            }
            catch (Exception)
            {

                throw;
            }
        } 
        public async Task<DataTable> GetModifierCodeCPTHCPCS(string Code, string CodeType)
        {
            try
            {
                DataTable ModifierCodeData =await _codesInformationProvider.GetModifierCodeCPTHCPCS(Code, CodeType);
                return ModifierCodeData;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetModifierCodeASP(string Code, string CodeType)
        {
            try
            {
                DataTable ModifierCodeData =await _codesInformationProvider.GetModifierCodeASP(Code, CodeType);
                return ModifierCodeData;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<object> GetFavoriteData(string UserName)
        {
            try
            {
                object FavoriteData =await _codesInformationProvider.GetFavoriteData(UserName);
                return FavoriteData;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<bool> DeleteFavCode(string Code)
        {
            try
            {
                bool Result =await _codesInformationProvider.DeleteFavCode(Code);
                return true;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<bool> AddFavoriteCode(FavoriteCode favoriteCode)
        {
            try
            {
                bool Result =await _codesInformationProvider.AddFavoriteCode(favoriteCode);
                return true;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<bool> AddNotes(Notes notes)
        {
            try
            {
                bool Result =await _codesInformationProvider.AddNotes(notes);
                return true;
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
