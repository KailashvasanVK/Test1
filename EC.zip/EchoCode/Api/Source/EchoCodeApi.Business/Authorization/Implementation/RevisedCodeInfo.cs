﻿using EchoCodeApi.Business.Authorization.Interface;
using EchoCodeApi.DataAccess.Authorization.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EchoCodeApi.Business.Authorization.Implementation
{
    public class RevisedCodeInfo:IRevisedCodeInfo
    {
        private readonly IRevicedCodeInfoProvider _revisedCodeInfoProvider;
        public RevisedCodeInfo(IRevicedCodeInfoProvider revisedCodeInfoProvider)
        {
            _revisedCodeInfoProvider = revisedCodeInfoProvider;
        }
        public async Task<DataTable> GetNewCodes(string CodeType)
        {
            try
            {
                DataTable result = await _revisedCodeInfoProvider.GetNewCodes(CodeType);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetRevisedCodes(string CodeType)
        {
            try
            {
                DataTable result = await _revisedCodeInfoProvider.GetRevisedCodes(CodeType);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetAllIcdCmDeletedCode()
        {
            try
            {
                DataTable result = await _revisedCodeInfoProvider.GetAllIcdCmDeletedCode();
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetAllIcdPcsDeletedCode()
        {
            try
            {
                DataTable result = await _revisedCodeInfoProvider.GetAllIcdPcsDeletedCode();
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetHCpcsSpecNavigation()
        {
            try
            {
                DataTable result = await _revisedCodeInfoProvider.GetHCpcsSpecNavigation();
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetCPtspecnavigation()
        {
            try
            {
                DataTable result = await _revisedCodeInfoProvider.GetCPtspecnavigation();
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
