﻿using EchoCodeApi.Business.Authorization.Interface;
using EchoCodeApi.DataAccess.Authorization.Interface;
using EchoCodeApi.Model.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EchoCodeApi.Business.Authorization.Implementation
{
    public class HCPCS_CodeInfo:IHCPCS_CodeInfo
    {
        public readonly IHCPCS_CodeInfoProvider _HCPCS_CodeInfoProvider;

        public HCPCS_CodeInfo(IHCPCS_CodeInfoProvider HCPCS_CodeInfoProvider)
        {
            _HCPCS_CodeInfoProvider = HCPCS_CodeInfoProvider;
        }
        public async Task<DataTable> GetAllHCPCSDeletedCode()
        {
            try
            {
                DataTable Codes =await _HCPCS_CodeInfoProvider.GetAllHCPCSDeletedCode();
                return Codes;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetAllClientInfo()
        {
            try
            {
                DataTable ClientInfo = await _HCPCS_CodeInfoProvider.GetAllClientInfo();
                return ClientInfo;
            }
            catch (Exception)
            {

                throw;
            }
        }
        
        public async Task<DataTable> GetDRGCodeData(string Code, string CodeType)
        {
            try
            {
                DataTable DRGCodeData = await _HCPCS_CodeInfoProvider.GetDRGData(Code, CodeType);
                return DRGCodeData;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetLatestUpdateData()
        {
            try
            {
                DataTable LatestData =await _HCPCS_CodeInfoProvider.GetLatestUpdateData();
                return LatestData;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetDrgCodeGroup()
        {
            try
            {
                DataTable result = await _HCPCS_CodeInfoProvider.GetDrgCodeGroup();
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetDrgCodeDtl(string Code)
        {
            try
            {
                DataTable result = await _HCPCS_CodeInfoProvider.GetDrgCodeDtl(Code);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<bool> AddLatestUpdate(LatestUpdateData latestUpdateData)
        {
            try
            {
                var result =await _HCPCS_CodeInfoProvider.AddLatestUpdate(latestUpdateData);
                return true;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public async Task<DataTable> GetCPTCodeList()
        {
            try
            {
                DataTable CPTData =await _HCPCS_CodeInfoProvider.GetCPTCodeList();
                return CPTData;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public async Task<DataTable> GetHCPCSCodeList()
        {
            try
            {
                DataTable HCPCSData =await _HCPCS_CodeInfoProvider.GetHCPCSCodeList();
                return HCPCSData;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public async Task<DataTable> GetICDCMCodeList()
        {
            try
            {
                DataTable ICDCMData =await _HCPCS_CodeInfoProvider.GetICDCMCodeList();
                return ICDCMData;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public async Task<DataTable> GetPCDCodeList()
        {
            try
            {
                DataTable PCDData =await _HCPCS_CodeInfoProvider.GetPCDCodeList();
                return PCDData;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetMueData(string Code)
        {
            try
            {
                DataTable Result =await _HCPCS_CodeInfoProvider.GetMueData(Code);
                return Result;
            }
            catch (Exception)
            {

                throw;
            }
        }
       
        public async Task<string> GetApiData(string Code, string CodeType)
        {
            try
            {
                string result = await _HCPCS_CodeInfoProvider.GetAPiData(Code,CodeType);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public async Task<string> GetInstructionsData(string Code, string CodeType)
        {
            try
            {
                string result = await _HCPCS_CodeInfoProvider.GetInstructionsData(Code, CodeType);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<string> GetColorCodesData(string Code, string CodeType)
        {
            try
            {
                string result = await _HCPCS_CodeInfoProvider.GetColorCodesData(Code, CodeType);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<string> GetIllustrationImages(string Code, string CodeType)
        {
            try
            {
                string result = await _HCPCS_CodeInfoProvider.GetIllustrationImages(Code, CodeType);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetHccIcdXwalk(string Code)
        {
            try
            {
                DataTable result = await _HCPCS_CodeInfoProvider.GetHccIcdXwalk(Code);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<byte[]> GetImageFromAPI(string ImageLink)
        {
            try
            {
                byte[] result = await _HCPCS_CodeInfoProvider.GetImageFromAPI(ImageLink);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<string> GetCrossRevCode(string Code, string CodeType)
        {
            try
            {
                string result = await _HCPCS_CodeInfoProvider.GetCrossRevCode(Code, CodeType);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<string> GetCrossCptHcpcsCode(string Code, string CodeType)
        {
            try
            {
                string result = await _HCPCS_CodeInfoProvider.GetCrossCptHcpcsCode(Code, CodeType);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<string> GetIncludesExcludesNotes(string Code, string CodeType)
        {
            try
            {
                string result = await _HCPCS_CodeInfoProvider.GetIncludesExcludesNotes(Code, CodeType);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<string> GetHistoricalData(string Code, string CodeType)
        {
            try
            {
                string result = await _HCPCS_CodeInfoProvider.GetHistoricalData(Code, CodeType);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetMedicareCci(string Code)
        {
            try
            {
                DataTable result = await _HCPCS_CodeInfoProvider.GetMedicareCci(Code);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetFeescheduleData(string Code,string Medicare)
        {
            try
            {
                DataTable result = await _HCPCS_CodeInfoProvider.GetFeescheduleData(Code,Medicare);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetMedicareCarrierdata()
        {
            try
            {
                DataTable result = await _HCPCS_CodeInfoProvider.GetMedicareCarrierdata();
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetPhysicalUnitsdata()
        {
            try
            {
                DataTable result = await _HCPCS_CodeInfoProvider.GetPhysicalUnitsdata();
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetQualifyUnitsdata()
        {
            try
            {
                DataTable result = await _HCPCS_CodeInfoProvider.GetQualifyUnitsdata();
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetFeeAnesthesiaData(string Code, string LocalityValue)
        {
            try
            {
                DataTable result = await _HCPCS_CodeInfoProvider.GetFeeAnesthesiaData(Code, LocalityValue);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetNonFacilityEditCheck(string Code)
        {
            try
            {
                DataTable result = await _HCPCS_CodeInfoProvider.GetNonFacilityEditCheck(Code);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetFacilityEditCheck(string Code)
        {
            try
            {
                DataTable result = await _HCPCS_CodeInfoProvider.GetFacilityEditCheck(Code);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<string> GetLayTermsData(string Code, string CodeType)
        {
            try
            {
                string result = await _HCPCS_CodeInfoProvider.GetLayTermsData(Code, CodeType);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<string> GetInstructionalNotes(string Code, string CodeType)
        {
            try
            {
                string result = await _HCPCS_CodeInfoProvider.GetInstructionalNotes(Code, CodeType);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }

    }
}
