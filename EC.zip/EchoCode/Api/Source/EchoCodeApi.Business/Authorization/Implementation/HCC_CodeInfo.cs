﻿using EchoCodeApi.Business.Authorization.Interface;
using EchoCodeApi.DataAccess.Authorization.Interface;
using EchoCodeApi.Model.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EchoCodeApi.Business.Authorization.Implementation
{
    public class HCC_CodeInfo:IHCC_CodeInfo
    {
        public readonly IHCC_CodeInfoProvider _HCC_CodeInfoProvider;

        public HCC_CodeInfo(IHCC_CodeInfoProvider HCC_CodeInfoProvider)
        {
            _HCC_CodeInfoProvider = HCC_CodeInfoProvider;
        }
        public async Task<DataTable> GetRxHccCode(string CodeType)
        {
            try
            {
                DataTable Codes = await _HCC_CodeInfoProvider.GetRxHccCode(CodeType);
                return Codes;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> getXwalkDetails(string Code, string CodeType)
        {
            try
            {
                DataTable Codes = await _HCC_CodeInfoProvider.getXwalkDetails(Code,CodeType);
                return Codes;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetHccIcdXwalk(string Code, string CodeType)
        {
            try
            {
                DataTable Codes = await _HCC_CodeInfoProvider.GetHccIcdXwalk(Code,CodeType);
                return Codes;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<string> IndexSearchdata(string Code, string CodeType)
        {
            try
            {
                string Codes = await _HCC_CodeInfoProvider.IndexSearchdata(Code, CodeType);
                return Codes;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetAllModifierdata(string data)
        {
            try
            {
                DataTable Codes = await _HCC_CodeInfoProvider.GetAllModifierdata(data);
                return Codes;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<string> GetPdfByCode(string Code, string CodeType)
        {
            try
            {
                string result = await _HCC_CodeInfoProvider.GetPdfByCode(Code, CodeType);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<byte[]> getpdfAuth(string url)
        {
            try
            {
                byte[] result = await _HCC_CodeInfoProvider.getpdfAuth(url);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> getmaidesc()
        {
            try
            {
                DataTable result = await _HCC_CodeInfoProvider.getmaidesc();
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
