﻿using EchoCodeApi.Business.Authorization.Interface;
using EchoCodeApi.DataAccess.Authorization.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EchoCodeApi.Business.Authorization.Implementation
{
    public class ApiInformation : IApiInformation
    {
        private readonly IApiInformationProvider _ApiInformationProvider;

        public ApiInformation(IApiInformationProvider apiInformationProvider)
        {
            _ApiInformationProvider = apiInformationProvider;
        }
        public async Task<string> GetApiTreeData(string Term, string CodeType)
        {
            try
            {
                string result = await _ApiInformationProvider.GetApiTreeData(Term, CodeType);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetGlobalCalcData(DateTime Date, string Codes)
        {
            try
            {
                DataTable result = await _ApiInformationProvider.GetGlobaldata(Date, Codes);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetGlobalSurgData()
        {
            try
            {
                DataTable result = await _ApiInformationProvider.GetGlobalSurgData();
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetSpecialtyData()
        {
            try
            {
                DataTable result = await _ApiInformationProvider.GetSpecialtyData();
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetFeeStates()
        {
            try
            {
                DataTable result = await _ApiInformationProvider.GetFeeStates();
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public async Task<DataTable> GetFeeLabData(string Code)
        {
            try
            {
                DataTable result = await _ApiInformationProvider.GetFeeLabData(Code);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetAsaCrossWalkData(string Code)
        {
            try
            {
                DataTable result = await _ApiInformationProvider.GetAsaCrossWalkData(Code);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public async Task<DataTable> GetSpecialtygridData(string Code, string Speciality)
        {
            try
            {
                DataTable result = await _ApiInformationProvider.GetSpecialtygridData(Code, Speciality);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetFeeDmePen(string Code, string State)
        {
            try
            {
                DataTable result = await _ApiInformationProvider.GetFeeDmePen(Code, State);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetFeeDmePos(string Code, string State)
        {
            try
            {
                DataTable result = await _ApiInformationProvider.GetFeeDmePos(Code, State);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetFeeAmbulancedata(string Code, string State)
        {
            try
            {
                DataTable result = await _ApiInformationProvider.GetFeeAmbulancedata(Code, State);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }

    }
}

