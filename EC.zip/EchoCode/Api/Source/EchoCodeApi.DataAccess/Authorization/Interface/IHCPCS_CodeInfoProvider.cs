﻿using EchoCodeApi.Model.Models;
using System.Data;
using System.Threading.Tasks;

namespace EchoCodeApi.DataAccess.Authorization.Interface
{
   public interface IHCPCS_CodeInfoProvider
    {
        Task<string> GetAPiData(string Code, string CodeType);
        Task<DataTable> GetNonFacilityEditCheck(string Code);
        Task<string> GetIncludesExcludesNotes(string Code, string CodeType);
        Task<string> GetInstructionalNotes(string Code, string CodeType);
        Task<DataTable> GetFacilityEditCheck(string Code);
        Task<DataTable> GetMedicareCarrierdata();
        Task<DataTable> GetAllHCPCSDeletedCode();
        Task<DataTable> GetMedicareCci(string Code);
        Task<DataTable> GetFeescheduleData(string Code, string Medicare);
        Task<DataTable> GetDrgCodeDtl(string Code);
        Task<DataTable> GetDrgCodeGroup();
        Task<DataTable> GetMueData(string Code);
        Task<DataTable> GetCPTCodeList();
        Task<DataTable> GetHCPCSCodeList();
        Task<DataTable> GetICDCMCodeList();
        Task<DataTable> GetPCDCodeList();
        Task<DataTable> GetAllClientInfo();
        Task<DataTable> GetDRGData(string Code, string CodeType);
        Task<DataTable> GetLatestUpdateData();
        Task<bool> AddLatestUpdate(LatestUpdateData latestUpdateData);
        Task<string> GetHistoricalData(string Code, string CodeType);
        Task<string> GetLayTermsData(string Code, string CodeType);
        Task<DataTable> GetPhysicalUnitsdata();
        Task<DataTable> GetQualifyUnitsdata();
        Task<DataTable> GetHccIcdXwalk(string Code);
        Task<DataTable> GetFeeAnesthesiaData(string Code, string LocalityValue);
        Task<string> GetInstructionsData(string Code, string CodeType);
        Task<string> GetColorCodesData(string Code, string CodeType);
        Task<string> GetIllustrationImages(string Code, string CodeType);
        Task<byte[]> GetImageFromAPI(string ImageLink);
        Task<string> GetCrossRevCode(string Code, string CodeType);
        Task<string> GetCrossCptHcpcsCode(string Code, string CodeType);
    }
}
