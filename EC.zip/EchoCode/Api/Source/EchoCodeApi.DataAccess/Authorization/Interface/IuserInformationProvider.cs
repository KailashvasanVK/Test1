﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EchoCodeApi.DataAccess.Authorization.Interface
{
   public interface IuserInformationProvider
    {
        string GetUserName();
    }
}
