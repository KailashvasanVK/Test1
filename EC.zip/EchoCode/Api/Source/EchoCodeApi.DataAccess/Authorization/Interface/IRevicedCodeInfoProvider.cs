﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EchoCodeApi.DataAccess.Authorization.Interface
{
    public interface IRevicedCodeInfoProvider
    {
        Task<DataTable> GetNewCodes(string CodeType);
        Task<DataTable> GetRevisedCodes(string CodeType);
        Task<DataTable> GetAllIcdCmDeletedCode();
        Task<DataTable> GetAllIcdPcsDeletedCode();
        Task<DataTable> GetHCpcsSpecNavigation();
        Task<DataTable> GetCPtspecnavigation();
    }
}
