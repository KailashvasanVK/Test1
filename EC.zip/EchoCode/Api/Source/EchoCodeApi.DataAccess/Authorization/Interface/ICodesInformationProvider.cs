﻿using EchoCodeApi.Model.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EchoCodeApi.DataAccess.Authorization.Interface
{
    public interface ICodesInformationProvider
    {
        DataTable Getallcodes(string Code);
        Task<DataTable> GetModifierCodeCPTHCPCS(string Code, string Codetype);
        Task<DataTable> GetModifierCodeASP(string Code, string Codetype);
        Task<DataTable> GetAllCPTModifierCode(string Code,string CodeType);
        Task<DataTable> GetCrossWalkData(string Code, string CodeType, string Alpha);
        Task<DataTable> GetAllCPTModifierCodeLink(string CodeType);
        DataTable GetDataByCode(string Code,string UserName);
        Task<bool> AddFavoriteCode(FavoriteCode favoriteCode);
        Task<object> GetFavoriteData(string UserName);

        Task<bool> DeleteFavCode(string Code);

        Task<bool> AddNotes(Notes notes);

        Task<DataTable> GetCptDeletedCodes(string Code);
        Task<DataTable> GetAllCPTDeletedCode();
    }
}
