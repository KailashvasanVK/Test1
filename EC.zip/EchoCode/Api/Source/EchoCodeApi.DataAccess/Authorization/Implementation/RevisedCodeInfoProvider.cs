﻿using EchoCodeApi.DataAccess.Authorization.Interface;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EchoCodeApi.DataAccess.Authorization.Implementation
{
    public class RevisedCodeInfoProvider:IRevicedCodeInfoProvider
    {
        readonly string ConnString = ConfigurationManager.ConnectionStrings["ConnEchoCode"].ConnectionString;
        public async Task<DataTable> GetNewCodes(string CodeType)
        {
            try
            {
                string ProcedureName;
                if (CodeType =="CPT")
                {
                    ProcedureName = "SP_GET_CPT_NEW_CODES";
                }
                else if(CodeType == "HCPCS")
                {
                    ProcedureName = "SP_GET_HCPCS_NEW_CODES";
                }
                else if (CodeType == "ICDCM")
                {
                    ProcedureName = "SP_GET_ICD_CM_NEW_CODES";
                }
                else
                {
                    ProcedureName = "SP_GET_ICD_PCS_NEW_CODES";
                }
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand(ProcedureName))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {
                throw;
            }
        }
    
    public async Task<DataTable> GetRevisedCodes(string CodeType)
    {
        try
        {
            string ProcedureName;
            if (CodeType == "CPT")
            {
                ProcedureName = "SP_GET_CPT_REVISED_CODES";
            }
            else if (CodeType == "HCPCS")
            {
                ProcedureName = "SP_GET_HCPCS_REVISED_CODES";
            }
            else if (CodeType == "ICDCM")
            {
                ProcedureName = "SP_GET_ICD_CM_REVISED_CODES";
            }
            else
            {
                ProcedureName = "SP_GET_ICD_PCS_REVISED_CODES";
            }
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(ConnString))
            {
                using (SqlCommand cmd = new SqlCommand(ProcedureName))
                {
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        sda.Fill(dt);
                    }
                }
            }
            return dt;
        }
        catch (Exception)
        {

            throw;
        }
    }
        public async Task<DataTable> GetHCpcsSpecNavigation()
        {
            try
            {
               
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_GET_HCPCS_SPEC_NAV_LEVELS_ALL"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetCPtspecnavigation()
        {
            try
            {
                
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_GET_CPT_SPECIALITY_NAVIGATION_LEVELS_ALL"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetAllIcdCmDeletedCode()
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_GET_ICD_CM_DELETED_CODES"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }

        }
        public async Task<DataTable> GetAllIcdPcsDeletedCode()
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_GET_ICD_PCS_DELETED_CODES"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }

        }
    }
}
