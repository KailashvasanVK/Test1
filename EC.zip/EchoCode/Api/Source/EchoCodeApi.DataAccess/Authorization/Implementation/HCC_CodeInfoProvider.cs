﻿using EchoCodeApi.DataAccess.Authorization.Interface;
using EchoCodeApi.Entity;
using EchoCodeApi.Model.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace EchoCodeApi.DataAccess.Authorization.Implementation
{
    public class HCC_CodeInfoProvider:IHCC_CodeInfoProvider
    {
        readonly string ConnString = ConfigurationManager.ConnectionStrings["ConnEchoCode"].ConnectionString;
        private readonly string Password;
        public HCC_CodeInfoProvider()
        {
            using (var enitity = new EchoCodeEntities())
            {
                Password = enitity.T_Api_Credential.SingleOrDefault(t => t.id == 1).Password.ToString();
                Password = Decrypt(Password);
            }
            ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls | SecurityProtocolType.Ssl3;

        }
        public static string Decrypt(string cipherText)
        {
            string EncryptionKey = "Accesshealthcare";
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return cipherText;
        }
        public async Task<DataTable> GetRxHccCode(string CodeType)
        {
            try
            {
                string ProcedureName;
                if (CodeType == "RXHCC")
                {
                    ProcedureName = "SP_GET_HCC_RX";
                }
                else if (CodeType == "ESRD")
                {
                    ProcedureName = "SP_GET_HCC_ESRD";
                }
                else if (CodeType == "MedAdv_V22")
                {
                    ProcedureName = "SP_GET_HCC_V22";
                }
                else
                {
                    ProcedureName = "SP_GET_HCC_V24";
                }
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand(ProcedureName))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }

        }
        public async Task<DataTable> GetHccIcdXwalk(string Code,string CodeType)
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_GET_HCC_ALL_TYPE_DTLS_BY_CODE"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@P_CODE", Code);
                        cmd.Parameters.AddWithValue("@P_TYPE", CodeType);
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
        
        public async Task<DataTable> getmaidesc()
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_GET_MAI_DESC"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;                        
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }

                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetAllModifierdata(string data)
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_MODIFIER_TYPE_BY_MODIFIER"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@P_MODIFIER", data);
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }

                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> getXwalkDetails(string Code, string CodeType)
        {
            try
            {
                string ProcedureName;
                if (CodeType == "RX")
                {
                    ProcedureName = "SP_GET_HCC_RX_ICD_XWALK";
                }
                else if (CodeType == "ESRD")
                {
                    ProcedureName = "SP_GET_HCC_ESRD_ICD_XWALK";
                }
                else if (CodeType == "V22")
                {
                    ProcedureName = "SP_GET_HCC_V22_ICD_XWALK";
                }
                else
                {
                    ProcedureName = "SP_GET_HCC_V24_ICD_XWALK";
                }
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand(ProcedureName))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@P_CODE", Code);
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))                            
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }

        }
        public async Task<string> GetPdfByCode(string Code, string CodeType)
        {
            try
            {
                HttpClient httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Accept.Clear();
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var byteArray = Encoding.ASCII.GetBytes($"Access_Heatlh_1:{Password}");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));
                HttpResponseMessage response = await httpClient.GetAsync($"https://realtimeecontent.com/ws/codetype/{CodeType}/{Code}/cdi");
                HttpContent content = response.Content;
                string result = await content.ReadAsStringAsync();
                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<string> IndexSearchdata(string Code, string CodeType)
        {
            try
            {
                HttpClient httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Accept.Clear();
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var byteArray = Encoding.ASCII.GetBytes($"Access_Heatlh_1:{Password}");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));
                HttpResponseMessage response = await httpClient.GetAsync($"https://realtimeecontent.com/ws/codetype/{CodeType}/indexsearch/{Code}?maxresults=11000");
                HttpContent content = response.Content;
                string result = await content.ReadAsStringAsync();
                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<byte[]> getpdfAuth(string url)
        {
            try
            {
                HttpClient httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Accept.Clear();
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/pdf"));
                var byteArray = Encoding.ASCII.GetBytes($"Access_Heatlh_1:{Password}");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));
                HttpResponseMessage response = await httpClient.GetAsync(url);
                HttpContent content = response.Content;
                byte[] result = await content.ReadAsByteArrayAsync();
                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
   

