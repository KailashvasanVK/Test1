﻿using EchoCodeApi.DataAccess.Authorization.Interface;
using EchoCodeApi.Entity;
using EchoCodeApi.Model.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace EchoCodeApi.DataAccess.Authorization.Implementation
{
    public class HCPCS_CodeInfoProvider: IHCPCS_CodeInfoProvider
    {
        readonly string ConnString = ConfigurationManager.ConnectionStrings["ConnEchoCode"].ConnectionString;
        private readonly string Password;

        public HCPCS_CodeInfoProvider()
        {
            using (var enitity = new EchoCodeEntities())
            {
                Password = enitity.T_Api_Credential.SingleOrDefault(t => t.id == 1).Password.ToString();
                Password = Decrypt(Password);
            }
            ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls | SecurityProtocolType.Ssl3;
        }
        public static string Decrypt(string cipherText)
        {
            string EncryptionKey = "Accesshealthcare";
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return cipherText;
        }
        public async Task<DataTable> GetAllHCPCSDeletedCode()
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_DELETED_HCPCS_CODES"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
           
        }
        public async Task<DataTable> GetAllClientInfo()
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_GET_CLIENT_INFO"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetCPTCodeList()
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_CPT_CODE_SUGGESTION_SEARCH"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
        
        public async Task<DataTable> GetHCPCSCodeList()
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_HCPCS_CODE_SUGGESTION_SEARCH"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
        
        public async Task<DataTable> GetICDCMCodeList()
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_ICD_CM_CODE_SUGGESTION_SEARCH"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetMedicareCarrierdata()
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_GET_FEE_STATES"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetDrgCodeGroup()
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_GET_DRG_CODE_GROUP"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetDrgCodeDtl(string Code)
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_GET_DRG_CODES_DTLS_BY_CODE_RANGE"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@P_CODE_RANGE", Code);
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public async Task<string> GetAPiData(string Code,string CodeType)
        {
            try
            {
                HttpClient httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Accept.Clear();
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var byteArray = Encoding.ASCII.GetBytes($"Access_Heatlh_1:{Password}");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));
                HttpResponseMessage response = await httpClient.GetAsync($"https://realtimeecontent.com/ws/codetype/{CodeType}/{Code}/sectionnotes");
                HttpContent content = response.Content;
                string result = await content.ReadAsStringAsync();
                return result;
            }
            catch (Exception)
            {               
                throw;
            }
        }
        public async Task<string> GetInstructionsData(string Code, string CodeType)
        {
            try
            {
                HttpClient httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Accept.Clear();
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var byteArray = Encoding.ASCII.GetBytes($"Access_Heatlh_1:{Password}");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));
                HttpResponseMessage response = await httpClient.GetAsync($"https://realtimeecontent.com/ws/codetype/{CodeType}/{Code}/instructions");
                HttpContent content = response.Content;
                string result = await content.ReadAsStringAsync();
                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<string> GetColorCodesData(string Code, string CodeType)
        {
            try
            {
                HttpClient httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Accept.Clear();
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var byteArray = Encoding.ASCII.GetBytes($"Access_Heatlh_1:{Password}");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));
                HttpResponseMessage response = await httpClient.GetAsync($"https://realtimeecontent.com/ws/codetype/{CodeType}/{Code}/color-codes");
                HttpContent content = response.Content;
                string result = await content.ReadAsStringAsync();
                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<string> GetIllustrationImages(string Code, string CodeType)
        {
            try
            {
                HttpClient httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Accept.Clear();
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var byteArray = Encoding.ASCII.GetBytes($"Access_Heatlh_1:{Password}");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));
                HttpResponseMessage response = await httpClient.GetAsync($"https://realtimeecontent.com/ws/codetype/{CodeType}/{Code}/images");
                HttpContent content = response.Content;
                string result = await content.ReadAsStringAsync();
                //GetImageFromAPI(result.)
                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }
        // GetImageFromAPI
        public async Task<byte[]> GetImageFromAPI(string ImageLink)
        {
            try
            {
                HttpClient httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Accept.Clear();
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("image/*"));
                var byteArray = Encoding.ASCII.GetBytes($"Access_Heatlh_1:{Password}");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));
                HttpResponseMessage response = await httpClient.GetAsync($"https://realtimeecontent.com{ImageLink}");
                HttpContent content = response.Content;
                byte[] result = await content.ReadAsByteArrayAsync();
                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<string> GetCrossRevCode(string Code, string CodeType)
        {
            try
            {
                HttpClient httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Accept.Clear();
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var byteArray = Encoding.ASCII.GetBytes($"Access_Heatlh_1:{Password}");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));
                HttpResponseMessage response = await httpClient.GetAsync($"https://realtimeecontent.com/ws/codetype/{CodeType}/{Code}/revenuecodes");
                HttpContent content = response.Content;
                string result = await content.ReadAsStringAsync();
                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<string> GetCrossCptHcpcsCode(string Code, string CodeType)
        {
            try
            {
                HttpClient httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Accept.Clear();
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var byteArray = Encoding.ASCII.GetBytes($"Access_Heatlh_1:{Password}");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));
                HttpResponseMessage response = await httpClient.GetAsync($"https://realtimeecontent.com/ws/codetype/revenue/{Code}/{CodeType}");
                HttpContent content = response.Content;
                string result = await content.ReadAsStringAsync();
                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<string> GetLayTermsData(string Code, string CodeType)
        {
            try
            {
                HttpClient httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Accept.Clear();
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var byteArray = Encoding.ASCII.GetBytes($"Access_Heatlh_1:{Password}");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));
                HttpResponseMessage response = await httpClient.GetAsync($"https://realtimeecontent.com/ws/codetype/{CodeType}/{Code}/properties?data=desc-lay");
                HttpContent content = response.Content;
                string result = await content.ReadAsStringAsync();
                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }
        
        public async Task<string> GetHistoricalData(string Code, string CodeType)
        {
            try
            {
                HttpClient httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Accept.Clear();
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var byteArray = Encoding.ASCII.GetBytes($"Access_Heatlh_1:{Password}");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));
                HttpResponseMessage response = await httpClient.GetAsync($"https://realtimeecontent.com/ws/codetype/{CodeType}/{Code}/codehistory");
                HttpContent content = response.Content;
                string result = await content.ReadAsStringAsync();
                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<string> GetInstructionalNotes(string Code, string CodeType)
        {
            try
            {
                HttpClient httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Accept.Clear();
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var byteArray = Encoding.ASCII.GetBytes($"Access_Heatlh_1:{Password}");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));
                HttpResponseMessage response = await httpClient.GetAsync($"https://realtimeecontent.com/ws/codetype/{CodeType}/{Code}/instructional-notes");
                HttpContent content = response.Content;
                string result = await content.ReadAsStringAsync();
                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<string> GetIncludesExcludesNotes(string Code, string CodeType)
        {
            try
            {
                HttpClient httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Accept.Clear();
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var byteArray = Encoding.ASCII.GetBytes($"Access_Heatlh_1:{Password}");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));
                HttpResponseMessage response = await httpClient.GetAsync($"https://realtimeecontent.com/ws/codetype/{CodeType}/{Code}/includesexcludesnotes");
                HttpContent content = response.Content;
                string result = await content.ReadAsStringAsync();
                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<DataTable> GetPCDCodeList()
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_ICD_PCS_CODE_SUGGESTION_SEARCH"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetMueData(string Code)
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_GET_MUE"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@P_CODE", Code);
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetHccIcdXwalk(string Code)
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_GET_HCC_ICD_XWALK"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@P_CODE", Code);
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetFacilityEditCheck(string Code)
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_GET_MCR_FACILTY_BY_CODES"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@P_CODES", Code);
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetNonFacilityEditCheck(string Code)
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_GET_MCR_NON_FACILTY_BY_CODES"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@P_CODES", Code);
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetFeescheduleData(string Code,string Medicare)
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_GET_FEE_SCHEDULE_RVU"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@P_CODE", Code);
                        cmd.Parameters.AddWithValue("@P_LOCALITY_VALUE", Medicare);
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetMedicareCci(string Code)
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_GET_CLAIMS_MCR_BY_CODE"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@P_CODE", Code);
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetDRGData(string Code, string CodeType)
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_GET_ICD_DRG_DTLS"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@CODE", Code);
                        cmd.Parameters.AddWithValue("@TYPE", CodeType);
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetLatestUpdateData()
        {
            try
            {

                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_GET_ALL_LATEST_UPDATES"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;

            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<bool> AddLatestUpdate(LatestUpdateData latestUpdateData)
        {
            try
            {

                var date = DateTime.Now;
                using (var entity=new EchoCodeEntities())
                {
                    var result = entity.LATEST_UPDATES.FirstOrDefault(_ => _.CLIENT_ID == latestUpdateData.Client_Id);
                    if (result == null)
                    {
                        entity.LATEST_UPDATES.Add(new LATEST_UPDATES()
                        {
                            CLIENT_ID = latestUpdateData.Client_Id,
                            CREATED_BY = latestUpdateData.UserName,
                            DEL_FLG = "N",
                            NEWS = latestUpdateData.News,
                            CREATED_ON = date
                        });
                    }else
                    {                       
                        result.CLIENT_ID = latestUpdateData.Client_Id;
                        result.NEWS = latestUpdateData.News;
                        result.UPDATED_BY = latestUpdateData.UserName;
                        result.UPDATED_ON = date;                       
                    }
                   
                    entity.SaveChanges();
                }
                    return true;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<DataTable> GetPhysicalUnitsdata()
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_GET_FEE_ANES_PHYSICAL_STATUS_UNITS"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetQualifyUnitsdata()
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_GET_FEE_ANES_QUALIFY_CIRCUM_UNITS"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
        // GetFeeAnesthesiaData
        public async Task<DataTable> GetFeeAnesthesiaData(string Code, string LocalityValue)
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_GET_FEE_ANESTHESIA"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@P_CODE", Code);
                        cmd.Parameters.AddWithValue("@P_STATE", LocalityValue);
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
    }

}
