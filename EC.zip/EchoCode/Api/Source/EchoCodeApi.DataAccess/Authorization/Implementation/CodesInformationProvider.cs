﻿using EchoCodeApi.DataAccess.Authorization.Interface;
using EchoCodeApi.Entity;
using EchoCodeApi.Model.Models;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace EchoCodeApi.DataAccess.Authorization.Implementation
{

    public class CodesInformationProvider : ICodesInformationProvider
    {
        readonly string ConnString = ConfigurationManager.ConnectionStrings["ConnEchoCode"].ConnectionString;
        public DataTable Getallcodes(string Code)
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_DIRECT_SUGGESTION_SEARCH"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@CODE", Code);
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {
                throw;
            }

        }
        public async Task<DataTable> GetCptDeletedCodes(string Code)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(ConnString))
            {
                using (SqlCommand cmd = new SqlCommand("SP_ALL_DELETED_CODES_BY_CODE"))
                {
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@P_CODE", Code);
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        sda.Fill(dt);
                    }
                }
            }
            return dt;
        }
        public async Task<DataTable> GetAllCPTDeletedCode()
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(ConnString))
            {
                using (SqlCommand cmd = new SqlCommand("SP_DELETED_CPT_CODES"))
                {
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        sda.Fill(dt);
                    }
                }
            }
            return dt;
        }
        public async Task<DataTable> GetModifierCodeCPTHCPCS(string Code,string Codetype)
        {
            try
            {
                string ProcedureName;
                if (Codetype=="CPT" )
                {
                    ProcedureName = "SP_GET_ALLOWED_MODIFIERS_BY_CPT_CODE";
                }
                else
                {
                    ProcedureName = "SP_GET_ALLOWED_MODIFIERS_BY_HCPCS_CODE";
                }

                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand(ProcedureName))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@CODE", Code);
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetModifierCodeASP(string Code, string Codetype)
        {
            try
            {
                //string ProcedureName;
                //if (Codetype == "CPT")
                //{
                //    ProcedureName = "SP_GET_ALLOWED_MODIFIERS_AMB_BY_CPT_CODE";
                //}
                //else
                //{
                //    ProcedureName = "SP_GET_ALLOWED_MODIFIERS_AMB_BY_HCPCS_CODE";
                //}

                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_GET_ALLOWED_MODIFIER_FACILITY"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@p_CODE", Code);
                        cmd.Parameters.AddWithValue("@P_TYPE", Codetype);
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetAllCPTModifierCode(string Code,string CodeType)
        {
            try
            {
                string ProcedureName;
                if (CodeType == "CPT")
                {
                    ProcedureName = "SP_GET_CPT_CODES_BY_MODIFIER";
                }
                else
                {
                    ProcedureName = "SP_GET_HCPCS_CODES_BY_MODIFIER";
                }
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand(ProcedureName))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@CODE", Code);
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetAllCPTModifierCodeLink(string CodeType)
        {
            string ProcedureName;
            if (CodeType == "CPT")
            {
                ProcedureName = "SP_GET_CPT_MODIFERS_ALL";
            }
            else
            {
                ProcedureName = "SP_GET_HCPCS_MODIFERS_ALL";
            }
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(ConnString))
            {
                using (SqlCommand cmd = new SqlCommand(ProcedureName))
                {
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        sda.Fill(dt);
                    }
                }
            }
            return dt;
        }
        public DataTable GetDataByCode(string Code, string UserName)
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_DIRECT_SEARCH_NEW"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@P_SEARCHTERMS", Code);
                        cmd.Parameters.AddWithValue("@P_LOGON_ID", UserName);
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<DataTable> GetCrossWalkData(string Code, string CodeType,string Alpha)
        {
            try
            {
                if(Alpha == "NO")
                {
                    Alpha = null;
                }
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_GET_CROSSWALK_CODES_ALPHA"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@CODE", Code);
                        cmd.Parameters.AddWithValue("@TYPE", CodeType);
                        cmd.Parameters.AddWithValue("@CROSS_CODE_INDEX", Alpha);
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        } 
        public async Task<object> GetFavoriteData(string UserName)
        {
            try
            {
                using (var entity = new EchoCodeEntities())
                {
                    var Data = entity.FAVORITE_CODES.Where(_ => _.LOGON_USER == UserName).Select(s => new FavoriteCode()
                    {
                        Code = s.CODE,
                        Code_Type = s.CODE_TYPE
                    }).ToList();

                    return Data;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<bool> DeleteFavCode(string Code)
        {
            try
            {
                using (var entity = new EchoCodeEntities())
                {
                    var Data = entity.FAVORITE_CODES.FirstOrDefault(_ => _.CODE == Code);
                    entity.FAVORITE_CODES.Remove(Data);
                    entity.SaveChanges();
                    return true;
                }

            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<bool> AddFavoriteCode(FavoriteCode favoriteCode)
        {
            try
            {
                using (var entity = new EchoCodeEntities())
                {
                    int data = entity.FAVORITE_CODES.Count(_ => _.CODE == favoriteCode.Code && _.LOGON_USER == favoriteCode.Login_Id);
                    if (data == 0)
                    {
                        entity.FAVORITE_CODES.Add(new FAVORITE_CODES()
                        {
                            CODE = favoriteCode.Code,
                            CODE_TYPE = favoriteCode.Code_Type,
                            LOGON_USER = favoriteCode.Login_Id,
                            CREATED_ON = DateTime.Now
                        });
                        entity.SaveChanges();
                    }
                }
                return true;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<bool> AddNotes(Notes notes)
        {
            try
            {
                DateTime now = DateTime.Now;
                using (var entity = new EchoCodeEntities())
                {
                    var count = entity.USER_NOTES.Count(_ => _.CODE == notes.Code);
                    if (count == 0)
                    {
                        entity.USER_NOTES.Add(new USER_NOTES()
                        {
                            CODE = notes.Code,
                            LOGON_USER = notes.Login_Id,
                            NOTES = notes.CodeNotes,
                            CREATED_ON = now
                        });
                    }
                    else
                    {
                        var result = entity.USER_NOTES.FirstOrDefault(_ => _.CODE == notes.Code);
                        result.NOTES = notes.CodeNotes;
                        result.UPDATED_ON = now;
                    }
                    entity.SaveChanges();

                }
                return true;
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
