﻿using EchoCodeApi.DataAccess.Authorization.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EchoCodeApi.DataAccess.Authorization.Implementation
{
   public class UserInformationProvider : IuserInformationProvider
    {
       
        public string GetUserName()
        {
            return "Naveen";
        }
    }
}
