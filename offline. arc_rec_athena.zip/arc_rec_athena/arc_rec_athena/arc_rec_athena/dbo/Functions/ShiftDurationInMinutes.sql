﻿CREATE function [dbo].[ShiftDurationInMinutes]
(
@StartTime Time
,@EndTime Time
,@DeductTime decimal(9,2)
)returns Decimal(15,2)
As

Begin
--DECLARE @StartTime TIME = '18:30:00.0000000'
--DECLARE @EndTime TIME = '03:30:00.0000000'

Declare @DiffTime Time = CONVERT(TIME(0), ((Convert(datetime,@EndTime) - convert(datetime,@StartTime))))
Declare @TotMinutes as Decimal(15,2)
Set @TotMinutes = (DATEPART(HOUR, CONVERT(DATETIME, @DiffTime)) * 60) + (DATEPART(MINUTE, CONVERT(DATETIME, @DiffTime)))
--Set @TotMinutes = CONVERT(Decimal(15,2), REPLACE(Substring(CONVERT(varchar,@DiffTime),0,6),':','.')) * 60
return ((cast(((@TotMinutes)-@DeductTime) as int)/60)+cast(('0.'+ RIGHT('0'+convert(varchar(10),cast(((@TotMinutes)-@DeductTime)%60 as int)),2)) as numeric(18,2)))
--return @TotMinutes
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ShiftDurationInMinutes] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ShiftDurationInMinutes] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ShiftDurationInMinutes] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ShiftDurationInMinutes] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ShiftDurationInMinutes] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ShiftDurationInMinutes] TO [DB_DMLSupport]
    AS [dbo];

