﻿CREATE FUNCTION dbo.ARC_REC_CandidateAppearance   
 (@REC_ID int)  
RETURNS int  
AS  
  
BEGIN  
  
-- Declare the return variable here  
--declare  @REC_ID int  
--set @REC_ID = 1303272  
Declare @NoOfAppearance int=0  

Select @NoOfAppearance = COUNT(*) from
(
Select REC_ID,CONVERT(date,CREATED_DT) as AppDate from ARC_REC_TYPING_TEST where REC_ID = @REC_ID
Union
Select REC_ID,CONVERT(date,CREATED_DT) as AppDate from ARC_REC_TEST where REC_ID = @REC_ID
Union
Select REC_ID,CONVERT(date,CREATED_DT) as AppDate from ARC_REC_CANDIATE_PROFILE where REC_ID = @REC_ID
Union
Select REC_ID,CONVERT(date,CREATED_DT) as AppDate from ARC_REC_CANDIATE_PROFILE_LOG where REC_ID = @REC_ID
) x Group by REC_ID
  
-- SELECT @NoOfAppearance = count(DISTINCT(CONVERT(varchar,CREATED_DT,106))) FROM ARC_REC_CANDIATE_PROFILE_LOG where REC_ID = @REC_ID and   
--cast(CREATED_DT as DATE) < (Select cast(CREATED_DT as DATE) from ARC_REC_CANDIATE_PROFILE where REC_ID = @REC_ID) 

--set @NoOfAppearance = @NoOfAppearance +1 -- adding current visit
  
----select @NoOfAppearance  
return (@NoOfAppearance)  
  
END

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_CandidateAppearance] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CandidateAppearance] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_CandidateAppearance] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CandidateAppearance] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_CandidateAppearance] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CandidateAppearance] TO [DB_DMLSupport]
    AS [dbo];

