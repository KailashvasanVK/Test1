﻿Create Function dbo.AssoicateName(@Nt_username varchar(100))  
returns varchar(100)  
begin  
Declare @Associate varchar(100)  
  
select @Associate=FIRSTNAME+' '+LASTNAME  from  
    ARC_REC_USER_INFO CI                               
   inner join ARC_REC_CANDIDATE CD on CD.REC_ID =ci.REC_ID       
   inner join arc_fin_client_info d on  d.CLIENT_ID =ci.CLIENT_ID        
where CI.NT_USERNAME=@NT_UserName      
  
return @Associate  
End  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AssoicateName] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AssoicateName] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AssoicateName] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AssoicateName] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AssoicateName] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AssoicateName] TO [DB_DMLSupport]
    AS [dbo];

