﻿ Create Function dbo.RR_Order_get(@tem int)  
 returns varchar(30)  
 as   
 begin   
 Declare @value varchar(30)  
  set @value= ( case when @tem%5=1 and @tem%4 =1  then CONVERT(varchar(10),@tem)+'st'  
 when  @tem%5=2 and @tem%4 =2 then CONVERT(varchar(10),@tem)+'nd'  
 when  @tem%5=3 and @tem%4 =3  then CONVERT(varchar(10),@tem)+'rd' else  
 CONVERT(varchar(10),@tem)+'th' end  
 )  
 return @value  
 end  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Order_get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Order_get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Order_get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Order_get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Order_get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Order_get] TO [DB_DMLSupport]
    AS [dbo];

