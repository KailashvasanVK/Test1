﻿CREATE function age(@Dob date)
returns int
as
begin
declare @age int
select @age=datediff(day,@dob,getdate())/365
Return @age
end
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[age] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[age] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[age] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[age] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[age] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[age] TO [DB_DMLSupport]
    AS [dbo];

