﻿CREATE function dbo.PollCount(@poll_id INT,@Opt tinyint)         
returns int      
AS            
BEGIN         
Declare @tc numeric(18,2)=0,@op numeric(18,2) ,@output numeric(18,2)        
        
set @tc=(SELECT isnull(COUNT(*),0) FROM ARC_Forum_Polls_Results WHERE POLL_ID=@poll_id and STATUS =1 )        
--set @tc=(SELECT isnull(COUNT(*),0) FROM arc_rec_user_info WHERE active=1 )        
      
Set @op =(SELECT isnull(COUNT(*),0) FROM ARC_Forum_Polls_Results WHERE POLL_ID=@poll_id AND OPT=@Opt and STATUS =1 )        
        
--set @output= ( SELECT (case when @tc =0 or @op=0 then 0 else (@op*1.0/@tc*100) end))      
        
return @op        
              
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[PollCount] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[PollCount] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[PollCount] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[PollCount] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[PollCount] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[PollCount] TO [DB_DMLSupport]
    AS [dbo];

