﻿CREATE function [dbo].[ConcatenateName]
(
@FirstName Varchar(100)
,@MiddleName Varchar(100)
,@LastName varchar(100)
)returns varchar(300)
As
Begin
return Ltrim(isnull(@firstName,'') + case when isnull(@MiddleName,'') <> '' then ' ' + isnull(@MiddleName,'') else '' end + case when isnull(@LastName,'') <> '' then ' ' + isnull(@LastName,'') else '' end)
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ConcatenateName] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ConcatenateName] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ConcatenateName] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ConcatenateName] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ConcatenateName] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ConcatenateName] TO [DB_DMLSupport]
    AS [dbo];

