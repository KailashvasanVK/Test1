﻿  
CREATE function dbo.RemoveDuplicateChar(@rst1 varchar(max))  
returns varchar(max)  
as  
Begin  
declare @i int,@c char,@d char  
declare @rst varchar(8000)  
set @i=1  
set @rst=substring(@rst1,0,1)  
set @d=''  
set @c=''  
  
while @i<=len(@rst1)  
begin  
set @c=substring(@rst1,@i,1)  
set @d=substring(@rst1,@i-10,1)  
if charindex(@c,@d,1)=0  
set @rst=@rst+@c  
set @i=@i+1  
set @c =''  
end  
return @rst  
End  
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RemoveDuplicateChar] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RemoveDuplicateChar] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RemoveDuplicateChar] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RemoveDuplicateChar] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RemoveDuplicateChar] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RemoveDuplicateChar] TO [DB_DMLSupport]
    AS [dbo];

