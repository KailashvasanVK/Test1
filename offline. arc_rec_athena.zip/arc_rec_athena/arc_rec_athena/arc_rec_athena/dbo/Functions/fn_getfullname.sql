﻿CREATE function dbo.fn_getfullname(@userid int) returns varchar(256)      
as      
begin      
Declare @Typeid smallint=1,@Fullname NVARCHAR(30)    
      
 IF @Typeid = 1 --Associate                
 SELECT  @Fullname = UserName  FROM mrplogin  where userid = @userid              
      
return @Fullname      
end      
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[fn_getfullname] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[fn_getfullname] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[fn_getfullname] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[fn_getfullname] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[fn_getfullname] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[fn_getfullname] TO [DB_DMLSupport]
    AS [dbo];

