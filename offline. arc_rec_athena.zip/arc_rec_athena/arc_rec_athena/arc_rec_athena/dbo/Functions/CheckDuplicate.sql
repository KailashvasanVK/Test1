﻿Create FUNCTION CheckDuplicate()
RETURNS int
AS 
BEGIN
   DECLARE @retval int =0
    select @retval=case when isnull(( SELECT COUNT(*) FROM  Tem1 where Name is Not null and Name <>''
    group by Name having COUNT(*)>1),1)=1 then 1 else 0 end
      RETURN isnull(@retval,0)
END;

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CheckDuplicate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CheckDuplicate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CheckDuplicate] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CheckDuplicate] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CheckDuplicate] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CheckDuplicate] TO [DB_DMLSupport]
    AS [dbo];

