﻿CREATE function ARC_REC_GetBackUpUsersEmailId(@ReportingTo varchar(50))
Returns varchar(max)
As
Begin
-- declare @ReportingTo varchar(50) = 'sanjeev.britto'
Declare @cc VARCHAR(MAX)
Set @CC = isnull((Select ';' + ui.NT_USERNAME + '@accesshealthcare.co' From ARC_Flow_Athena..ADM_AccessFunctionality As fun
Inner Join ARC_REC_Athena..ARC_REC_USER_INFO as Ui on ui.USERID = fun.UserId and ui.REPORTING_TO = @ReportingTo
Where fun.functionality = 'B' FOR XML PATH('')),'')
return case when len(@CC) > 0 then  Substring(@CC, 2, (len(@CC)))  else ''  end
End




GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_GetBackUpUsersEmailId] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_GetBackUpUsersEmailId] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_GetBackUpUsersEmailId] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_GetBackUpUsersEmailId] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_GetBackUpUsersEmailId] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_GetBackUpUsersEmailId] TO [DB_DMLSupport]
    AS [dbo];

