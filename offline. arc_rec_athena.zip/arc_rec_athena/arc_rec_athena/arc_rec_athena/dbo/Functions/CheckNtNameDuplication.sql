﻿Create FUNCTION CheckNtNameDuplication()
RETURNS int
AS 
BEGIN
   DECLARE @retval int =0
    select @retval=case when isnull(( SELECT COUNT(*) FROM  ARC_REC_USER_INFO where NT_USERNAME is Not null and NT_USERNAME <>''
    group by NT_USERNAME having COUNT(*)>1),1)=1 then 1 else 0 end
      RETURN isnull(@retval,0)
END;

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CheckNtNameDuplication] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CheckNtNameDuplication] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CheckNtNameDuplication] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CheckNtNameDuplication] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CheckNtNameDuplication] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CheckNtNameDuplication] TO [DB_DMLSupport]
    AS [dbo];

