﻿CREATE FUNCTION dbo.REMOVE_DUPLICATE_INSTR
(@datalen_tocheck INT,@string VARCHAR(255))
RETURNS VARCHAR(255)
AS
BEGIN
DECLARE @str VARCHAR(255)
DECLARE @count INT
DECLARE @start INT
DECLARE @result VARCHAR(255)
DECLARE @end INT
SET @start=1
SET @end=@datalen_tocheck
SET @count=@datalen_tocheck
SET @str = @string
WHILE (@count <=255)
BEGIN
IF (@result IS NULL)
BEGIN
SET @result=''
END
SET @result=@result+SUBSTRING(@str,@start,@end)
SET @str=REPLACE(@str,SUBSTRING(@str,@start,@end),'')
SET @count=@count+@datalen_tocheck
END
RETURN @result
END

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[REMOVE_DUPLICATE_INSTR] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[REMOVE_DUPLICATE_INSTR] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[REMOVE_DUPLICATE_INSTR] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[REMOVE_DUPLICATE_INSTR] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[REMOVE_DUPLICATE_INSTR] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[REMOVE_DUPLICATE_INSTR] TO [DB_DMLSupport]
    AS [dbo];

