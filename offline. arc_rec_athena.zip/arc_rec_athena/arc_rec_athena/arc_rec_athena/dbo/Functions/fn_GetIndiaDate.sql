﻿CREATE Function [dbo].fn_GetIndiaDate()          
Returns DateTime            
As            
Begin            
 /*            
 Created By     :        Kartik. S            
 Created On     :        03/14/2006            
 Purpose        :        To return India DateTime          
 Note           :        UTC-5.30           
 */            
 Declare @IndiaDate DateTime            
             
 --For GMT to IST - GMT + 5:30 Hrs            
 Set @IndiaDate = DateAdd(n,330, Getutcdate())          
 Return(@IndiaDate)            
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[fn_GetIndiaDate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[fn_GetIndiaDate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[fn_GetIndiaDate] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[fn_GetIndiaDate] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[fn_GetIndiaDate] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[fn_GetIndiaDate] TO [DB_DMLSupport]
    AS [dbo];

