﻿
CREATE Function GetIsDeclaredOff
(
	@Date date,
	@UserId int
)
Returns int
As
Begin

Declare @IsDeclaredOff int = 0,
@HOLIDAY_LISTTYPE int=0, 
@WEEK_OFF_DAYS varchar(max),
@HOLIDAY_DATE varchar(10)
	 

	declare @athenantusername varchar(100)=''
	select @athenantusername=nt_username from arc_rec_user_info (nolock) where userid=@userid
	
	declare @recuserid int=0
	select @recuserid=userid from arc_rec..arc_reC_user_info (nolock)  where nt_username=@athenantusername
	
	 Set @HOLIDAY_LISTTYPE=isnull((Select HolidayTypeID from arc_rec..arc_rec_user_info (nolock)  where UserId=@recuserid ),2) /**/
	 Set @HOLIDAY_DATE = isnull((Select Convert(varchar,HOLIDAY_DATE) from  arc_rec..ARC_REC_LEAVE_HOLIDAYLIST (nolock)  where HOLIDAY_DATE=@Date and LISTTYPE =@HOLIDAY_LISTTYPE),'')
	 
	 Set @WEEK_OFF_DAYS = Isnull((select top 1 WEEK_OFF_DAYS from arc_rec..arc_rec_associate_week_off (nolock)  where userid = @recuserid and Active=1
	 and EFF_DT_FROM<=@Date order by EFF_DT_FROM desc),'')
	 
	 Declare @WeekOffDays table (WeekOffDay varchar(10),IsWeekOff bit)
	 Insert into @WeekOffDays(WeekOffDay,IsWeekOff)
	 select items as [WeekOffDay],0 from dbo.fnSplitString(@WEEK_OFF_DAYS,',')
     
	if(@HOLIDAY_DATE <>'')
		Set  @IsDeclaredOff=1
	else if(select count(IsWeekOff) from  @WeekOffDays)>0
		Select @IsDeclaredOff = case when  WeekOffDay=DATENAME(WEEKDAY,@Date) then 1 else 0 end from  @WeekOffDays where WeekOffDay=DATENAME(WEEKDAY,@Date)
	else  
		Select @IsDeclaredOff =case when DATENAME(WEEKDAY,@Date) in ('Saturday','Sunday') then 1 else 0 end

	 Return @IsDeclaredOff
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[GetIsDeclaredOff] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[GetIsDeclaredOff] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[GetIsDeclaredOff] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[GetIsDeclaredOff] TO [DB_DMLSupport]
    AS [dbo];

