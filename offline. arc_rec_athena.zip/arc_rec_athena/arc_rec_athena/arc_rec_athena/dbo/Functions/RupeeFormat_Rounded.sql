﻿    
CREATE function dbo.RupeeFormat_Rounded(@v float)      
      
/*      
      
Created By    : udhayaganesh p       
      
Created on    : 30 Aug 2011     
      
Description   : Convert numbers to currency of indian system      
      
*/      
      
returns varchar(100)      
      
as      
      
begin      
      
  declare @res varchar(100)      
      
  declare @p1 varchar(100)      
      
  declare @p2 varchar(100)      
      
  declare @len INT      
      
       
      
  select @len = len (@v)      
      
             
      
  if @len > 3       
      
  BEGIN      
      
  set @res = replace(convert (varchar(100), convert(money, @v), 3 ) , ',','')      
      
  set @p1 = left(@res, charindex('.', @res)-1)      
      
  set @p2 = substring(@res, charindex('.', @res), 12)      
      
  set @res = right(@p1, 3) + @p2      
      
  set @p1 = left(@p1, len(@p1)-3)      
      
  while (@p1<>'')      
      
  begin      
      
    set @res = right(@p1, 2) + ',' + @res      
      
    if (len(@p1) > 2)      
      
      set @p1 = left(@p1, len(@p1)-2)      
      
    else       
      
      set @p1= ''      
      
  end      
      
  END      
      
ELSE      
      
       BEGIN      
      
declare @smallAmt numeric(18,2)      
      
set @smallAmt = @v      
      
       SET @res = @smallAmt      
      
                    
      
       END      
      
--       RETURN @res         
       RETURN left(@res, (len(@res) - 3))    
      
                    
      
             
      
end      
      
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RupeeFormat_Rounded] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RupeeFormat_Rounded] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RupeeFormat_Rounded] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RupeeFormat_Rounded] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RupeeFormat_Rounded] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RupeeFormat_Rounded] TO [DB_DMLSupport]
    AS [dbo];

