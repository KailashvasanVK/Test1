﻿CREATE FUNCTION InitCap (
 @string varchar(255)
)  
RETURNS varchar(255) AS


BEGIN 

 RETURN upper(left(@string, 1)) + LOWER(right(@string, len(@string) - 1) )

END
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[InitCap] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[InitCap] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[InitCap] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[InitCap] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[InitCap] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[InitCap] TO [DB_DMLSupport]
    AS [dbo];

