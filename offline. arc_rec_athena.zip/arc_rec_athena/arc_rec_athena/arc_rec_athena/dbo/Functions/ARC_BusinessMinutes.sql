﻿CREATE function ARC_BusinessMinutes(@dFrom datetime,@dTo datetime)
Returns int as
Begin
--Declare @dFrom datetime = '2014-06-14 09:00:00'
--Declare @dTo datetime  = '2014-06-14 22:00:00'
Declare @Min int = 0
Declare @tempTo datetime = @dTo
if DATEPART(DD,@dFrom) = DATEPART(DD,@dTo)
	Begin
	if DATENAME(Weekday,@dFrom) <> 'Saturday' and DATENAME(Weekday,@dFrom) <> 'Sunday' and (Select COUNT(*) from ARC_REC_Athena..ARC_REC_LEAVE_HOLIDAYLIST Where HOLIDAY_DATE = Convert(date,@dFrom) and listType = 2) <> 1
		Set @Min = DATEDIFF(MINUTE,@dFrom,@dTo)	
	End
Else
	While @dFrom <= @dTo
	Begin
	Set @tempTo = CONVERT(datetime,DateAdd(DD,1,Convert(date,@dFrom)))	
	if @tempTo > @dTo
		Set @tempTo = @dTo
	if DATENAME(Weekday,@dFrom) <> 'Saturday' and DATENAME(Weekday,@dFrom) <> 'Sunday' and (Select COUNT(*) from ARC_REC_Athena..ARC_REC_LEAVE_HOLIDAYLIST Where HOLIDAY_DATE = Convert(date,@dFrom) and listType = 2) <> 1
		begin
		Set @Min += DATEDIFF(MINUTE,@dFrom,@tempTo)	
		end
	Set @dFrom = DATEADD(DD,1,Convert(date,@dFrom))
	End
	--Select @Min,@Min/60.0
Return @Min
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_BusinessMinutes] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_BusinessMinutes] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_BusinessMinutes] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_BusinessMinutes] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_BusinessMinutes] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_BusinessMinutes] TO [DB_DMLSupport]
    AS [dbo];

