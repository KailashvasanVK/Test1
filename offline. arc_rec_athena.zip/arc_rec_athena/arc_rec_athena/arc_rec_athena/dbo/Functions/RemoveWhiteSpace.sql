﻿CREATE FUNCTION dbo.RemoveWhiteSpace (@str varchar(max))
RETURNS varchar(max)
AS
BEGIN
     DECLARE @ShowWhiteSpace varchar(max);
     SET @ShowWhiteSpace = @str
     SET @ShowWhiteSpace = REPLACE( @ShowWhiteSpace, CHAR(32), '')
   SET @ShowWhiteSpace = REPLACE( @ShowWhiteSpace, CHAR(160), '')
     RETURN(@ShowWhiteSpace)
END


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RemoveWhiteSpace] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RemoveWhiteSpace] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RemoveWhiteSpace] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RemoveWhiteSpace] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RemoveWhiteSpace] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RemoveWhiteSpace] TO [DB_DMLSupport]
    AS [dbo];

