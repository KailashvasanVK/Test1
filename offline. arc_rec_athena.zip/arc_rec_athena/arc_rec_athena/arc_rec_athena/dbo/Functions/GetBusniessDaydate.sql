﻿ Create Function dbo.GetBusniessDaydate(@businessday int)
 Returns date
 as 
 begin
 Declare @BusinessdayofDate date
 select @BusinessdayofDate=DayDate from (
 select ROW_NUMBER() over(order by daydate desc) BusinessDay , DayDate,datepart(DW,daydate) WeekNumber,DATENAME(WEEKDAY,DayDate) WeekName
 from ARC_ATHENA.Dbaevnt.Listthedate_GiveRange(GETDATE()-365,GETDATE()) MQ
 where not exists(
 select  HOLIDAY_DATE,datepart(DW,HOLIDAY_DATE) WeekNumber,DATENAME(WEEKDAY,HOLIDAY_DATE) from Athena_Holidaylist 
 where HOLIDAY_DATE=MQ.DayDate ) and datepart(DW,daydate) not in (1,7)
 ) AS U where BusinessDay=@BusinessDay

 return @BusinessdayofDate
 End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[GetBusniessDaydate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[GetBusniessDaydate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[GetBusniessDaydate] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[GetBusniessDaydate] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[GetBusniessDaydate] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[GetBusniessDaydate] TO [DB_DMLSupport]
    AS [dbo];

