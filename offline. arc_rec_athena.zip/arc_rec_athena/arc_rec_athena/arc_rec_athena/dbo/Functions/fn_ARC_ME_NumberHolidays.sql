﻿CREATE Function fn_ARC_ME_NumberHolidays(@dFrom datetime, @dTo   datetime)
Returns int as
BEGIN
   Declare @nHolidays int
   Set @nHolidays = 0
   While @dFrom <= @dTo Begin
      If datepart(dw, @dFrom) = 1 
		Set @nHolidays = @nHolidays + 1
      else      
		select @nHolidays = @nHolidays +  (select COUNT(*) from ARC_REC_LEAVE_HOLIDAYLIST where HOLIDAY_DATE = CONVERT(DATE,@dFrom) and LISTTYPE = 2)
      Set @dFrom = DateAdd(d, 1, @dFrom)
   End
   Return (@nHolidays)
END

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[fn_ARC_ME_NumberHolidays] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[fn_ARC_ME_NumberHolidays] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[fn_ARC_ME_NumberHolidays] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[fn_ARC_ME_NumberHolidays] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[fn_ARC_ME_NumberHolidays] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[fn_ARC_ME_NumberHolidays] TO [DB_DMLSupport]
    AS [dbo];

