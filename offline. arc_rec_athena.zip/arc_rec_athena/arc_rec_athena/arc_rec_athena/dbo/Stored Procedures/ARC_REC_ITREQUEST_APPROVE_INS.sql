﻿CREATE PROCEDURE ARC_REC_ITREQUEST_APPROVE_INS              
(              
@HRID INT,          
@TYPE Char,            
@COMMENTS VARCHAR(500),              
@PRIORITY VARCHAR(15),              
@APPROVESTATUS VARCHAR(15),              
@APPROVEBY INT,        
@SCHEDULE INT,        
@RequestStatus varchar(15) output             
)              
AS              
BEGIN    
DECLARE @xml VARCHAR(MAX)                      
DECLARE @body VARCHAR(MAX)       
        
If @type='O'             
Begin        
UPDATE ARC_REC_ITREQUEST SET ApprovedComments=@COMMENTS,Priority=@PRIORITY,ApproveStatus=@APPROVESTATUS,              
ApprovedBy=@APPROVEBY , RequestStatus =(case when @APPROVESTATUS='Approve' then 2 else 3 end),ApprovedOn=getdate(),      
SCHID=@SCHEDULE            
WHERE RequestId=@HRID           
select @RequestStatus = @APPROVESTATUS   
Exec ARC_REC_ITREQUEST_APPROVAL_MAIL_ALERT  @RequestId=@HRID      
End         
Else        
Begin        
UPDATE ARC_REC_ITREQUEST_HISTORY SET ApprovedComments=@COMMENTS,Priority=@PRIORITY,ApproveStatus=@APPROVESTATUS,              
ApprovedBy=@APPROVEBY , RequestStatus =(case when @APPROVESTATUS='Approve' then 2 else 3 end),ApprovedOn=getdate(),      
SCHID=@SCHEDULE            
WHERE HRID=@HRID         
select @RequestStatus = @APPROVESTATUS  
Exec ARC_REC_ITREQUEST_APPROVAL_HISTORY_MAIL_ALERT @RequestId=@HRID    
End         
END
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_APPROVE_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_APPROVE_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_APPROVE_INS] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_APPROVE_INS] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_APPROVE_INS] TO [DB_DMLSupport]
    AS [dbo];

