﻿CREATE Procedure RR_AccessPrivilage_Get  
(  
@NTUserName varchar(500)=null  
)  
As  
/*  
RR_AccessPrivilage_Get @NTUserName='seena.ambaturu'  
*/  
Begin  
select UserId,NTUserName from RR_AccessPrivilage where NTUserName=@NTUserName and Status=1  
End  
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_AccessPrivilage_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_AccessPrivilage_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_AccessPrivilage_Get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_AccessPrivilage_Get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_AccessPrivilage_Get] TO [DB_DMLSupport]
    AS [dbo];

