﻿
CREATE proc HD_Athena_GetSupervisors
As
Begin
select ui.USERID as UserId, FIRSTNAME+' '+LASTNAME as Name  
from ARC_REC_USER_INFO  as ui
inner join HD_Athena_ApprovalUsers as apu on apu.UserId = Ui.USERID
where ui.AHS_PRL = 'Y' and ui.ACTIVE = 1
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_GetSupervisors] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetSupervisors] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetSupervisors] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_GetSupervisors] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetSupervisors] TO [DB_DMLSupport]
    AS [dbo];

