﻿CREATE proc Attendance_General_Shift_Exe_Job     
as          
Begin          
declare @From datetime=convert(date,getdate()),@to datetime=convert(date,getdate())            
            
select @From,@to             
            
insert into UL_Attendance(UserAccount,Shiftid,UserFullName,LoginDate,Logout,WMin,Whours,HMin,Hhours,FMin,Fhours,Date)            
exec UserTrackingReport_General_Shift @from,@to  
       
            
end 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Attendance_General_Shift_Exe_Job] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Attendance_General_Shift_Exe_Job] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Attendance_General_Shift_Exe_Job] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Attendance_General_Shift_Exe_Job] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Attendance_General_Shift_Exe_Job] TO [DB_DMLSupport]
    AS [dbo];

