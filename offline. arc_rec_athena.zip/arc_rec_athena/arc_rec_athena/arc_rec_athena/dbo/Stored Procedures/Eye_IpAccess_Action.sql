﻿CREATE procedure Eye_IpAccess_Action
@UserId int,
@FacilityId int 
as
Begin
 Select COUNT(*) as result  from Eye_IpAccess  where UserId  = @UserId and FacilityId = @FacilityId
 Exec EyeBayStatus @FacilityId = @FacilityId
 End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Eye_IpAccess_Action] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Eye_IpAccess_Action] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Eye_IpAccess_Action] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Eye_IpAccess_Action] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Eye_IpAccess_Action] TO [DB_DMLSupport]
    AS [dbo];

