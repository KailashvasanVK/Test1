﻿CREATE PROCEDURE ARC_Lounge_Message_Comments                    
@MsgId int,                    
@NT_Username NVarchar(100)=Null ,                    
@PageIndex int=1,                                                                         
@PageSize int=5                    
--@PageCount INT OUTPUT                        
/*                     
 CreatedBy : Udhayaganesh.p                    
 Purpose   : Get the Respective Message Comments                     
                     
 Execution : Exec ARC_Lounge_Message_Comments 1,6,10,'balaji.kumar'                    
                     
 Exec ARC_Lounge_Message_Comments 1,'balaji.kumar',1,5,0                    
 Go                    
 Exec ARC_Lounge_Message_Comments 1,'balaji.kumar',5,5,0                    
             
 exec ARC_Lounge_Message_Comments @MsgId=1,@NT_Username=N'varunnair.m ',@PageIndex=1,@PageSize=5                  
                     
 */                    
As                                                      
BEGIN                      
                    
 DECLARE @RecordCount INT,@PageCount INT                     
                 
                                                                              
                     
Select * into #TempTableComments from (                                                  
SELECT ROW_NUMBER()over(order by cmt.id desc) RowNumber,cmt.id,cmt.MsgId,cmt.CommentText,cmt.CommentedBy,                                  
isnull(Ci.FIRSTNAME+' '+ci.LASTNAME,'')+' | ' Commentor,        
 --+ d.CLIENT_NAME Commentor,                                                  
CONVERT(VARCHAR(19),CommentedOn) as CommentedOn ,ProfileImage=                                                  
(case when PROFILE_IMAGE_NAME is not null then'https://arc.accesshealthcare.co/arc_rec/images/candidate/'+PROFILE_IMAGE_NAME                                                  
else  'https://arc.accesshealthcare.co/arc_rec/images/userimg.jpg' end),isnull(CLIENT_NAME,'Shared Services') Client ,                    
(select count(id) from ARC_Forum_Lounge_Comment_Likes cl where cl.CommId=cmt.id and cl.Status=1)'LikeCount',                    
(select count(id) from ARC_Forum_Lounge_Comment_Flags cl where cl.CmtId=cmt.id and cl.Status=1)'ReportCount',                     
PostOwner=(case when cmt.CommentedBy =@NT_Username OR @NT_Username in ('Hepsiba.Raj','Udhayaganesh.p') then 1 else 0 End)            
,Likes=isnull((select COUNT(*) from ARC_Forum_Lounge_Comment_Likes CL where CL.CommId=cmt.id and CL.LikedBy=@NT_username and CL.status=1 ),0)                                             
,ReportAbuse=isnull((select  COUNT(*) from ARC_Forum_Lounge_Comment_Flags CF where CF.CmtId=cmt.id and CF.ReportedBy=@NT_username and CF.status=1 ),0)   
,CountryFlag=isnull('../ARC_Lounge/Flag/'+convert(varchar(10),fc.CountryId)+'.png','')                                             
from ARC_Forum_Lounge_Message_Comments cmt                                    
Inner join ARC_REC_USER_INFO CI on CI.NT_USERNAME =cmt.CommentedBy                                                   
Inner join ARC_REC_CANDIDATE CD on CD.REC_ID =ci.REC_ID                                         
Inner join arc_fin_client_info d on  d.CLIENT_ID =ci.CLIENT_ID  
left join ARC_REC_FootballTeams FT on FT.UserId = CI.USERID      
left join ARC_REC_FootballCountries FC on FC.CountryId = FT.CountryId and FC.Status=1                                                   
where cmt.Status=1 AND cmt.MsgId=@MsgId                     
) As Udhay                    
                    
SELECT @RecordCount = COUNT(*) FROM #TempTableComments                                                                                  
                                                               
SET @PageCount = CEILING(CAST(@RecordCount AS DECIMAL(10, 2)) / CAST(@PageSize AS DECIMAL(10, 2)))                      
                    
                            
SELECT * FROM #TempTableComments                                                                    
WHERE RowNumber BETWEEN(@PageIndex -1) * @PageSize + 1 AND(((@PageIndex -1) * @PageSize + 1) + @PageSize) - 1                   
                
SELECT  @PageCount'PageCount'                                                                      
                                                                                      
                  DROP TABLE #TempTableComments                            
                    
 END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comments] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comments] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comments] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comments] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comments] TO [DB_DMLSupport]
    AS [dbo];

