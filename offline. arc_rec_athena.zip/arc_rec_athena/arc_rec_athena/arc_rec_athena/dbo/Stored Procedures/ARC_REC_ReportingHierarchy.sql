﻿CREATE proc [dbo].[ARC_REC_ReportingHierarchy]                  
@USERID int                  
AS                  
Begin              
/*            
            
Created By : Bhuvaneswari Ravichandran            
Purpose : To list all users of given reporting person from highrarical view and the users             
should not added in Athena users already.            

declare @userid int=4351
            
*/


select 
userinfo.userid as UserId,userinfo.nt_username  as Name,userinfo.nt_username as UserName,Hrf.FunctionName
,recdr.level As Level
from arc_rec..DirectReports (nolock) recdr
join arc_rec_user_info (nolock) sup on sup.nt_username=recdr.parent
join arc_rec_user_info (nolock) userinfo on userinfo.nt_username=recdr.username
inner join HR_Functionality (nolock)    Hrf on Hrf.FunctionalityId =  userinfo.FUNCTIONALITY_ID   
where sup.userid=@userID
and userinfo.active=1
order by recdr.level

/*
WITH DirectReports (UserId, Name, UserName,FunctionName, [Level])                  
AS                  
(              
-- Anchor member definition                  
select USERID as UserId,NT_USERNAME as Name,NT_USERNAME as UserName,FunctionName,0 AS [Level] from ARC_REC_USER_INFO    usr 
inner join HR_Functionality    Hrf on Hrf.FunctionalityId =  usr.FUNCTIONALITY_ID                  
where ACTIVE = 1 and AHS_PRL = 'Y' and                       
REPORTING_TO = (select NT_USERNAME from ARC_REC_USER_INFO where USERID = @USERID) -- if any condition, will add in future.                          
and isnull(NT_USERNAME,'') <> ''          
            
UNION ALL                  
-- Recursive member definition                  
select ui.USERID  as UserId,ui.NT_USERNAME as Name,ui.NT_USERNAME as UserName,Hrf.FunctionName,    
Level + 1                  
from ARC_REC_USER_INFO ui                     
inner join HR_Functionality    Hrf on Hrf.FunctionalityId =  ui.FUNCTIONALITY_ID                  
INNER JOIN DirectReports d on d.UserName = ui.REPORTING_TO                  
where ui.ACTIVE = 1 and ui.AHS_PRL = 'Y' and isnull(ui.NT_USERNAME,'') <> ''                    
                    
)                  
SELECT UserId, Name, UserName,FunctionName , [Level]                  
FROM DirectReports       
--order by Level      
*/             
                 
End 

GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ReportingHierarchy] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ReportingHierarchy] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ReportingHierarchy] TO [DB_DMLSupport]
    AS [dbo];

