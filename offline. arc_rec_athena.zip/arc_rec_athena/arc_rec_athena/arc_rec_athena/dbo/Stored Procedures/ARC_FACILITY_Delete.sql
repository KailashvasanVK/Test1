﻿  
CREATE PROCEDURE [dbo].[ARC_FACILITY_Delete](@PID VARCHAR(100),@DeletedBy INT,@Type TINYINT)      
AS      
SET NOCOUNT ON      
BEGIN      
DECLARE @Flag AS INT      
SET @Flag=0      
/*Route Master Details Delete*/      
IF @Type=1       
BEGIN       
  IF  EXISTS(SELECT '*' FROM ARC_Facility_RouteMaster WHERE RouteID=@PID And Status=1)      
  BEGIN      
    UPDATE ARC_Facility_RouteMaster SET Status=0,DeletedBy=@DeletedBy,DeletedDt=GETDATE()     
    WHERE RouteID=@PID    
    SET @Flag=1      
  END      
  ELSE      
  BEGIN      
    SET @Flag=2      
  END      
END      
/*Cab Master Details Delete*/      
ELSE IF @Type=2      
BEGIN      
  IF  EXISTS(SELECT '*' FROM ARC_Facility_CABMaster WHERE CabID=@PID And Status=1)      
  BEGIN      
    UPDATE ARC_Facility_CABMaster SET Status=0,DeletedBy=@DeletedBy,DeletedDt=GETDATE()     
    WHERE CabID=@PID    
    SET @Flag=1      
  END      
  ELSE      
  BEGIN      
    SET @Flag=2      
  END      
END      
/*Driver Master Details Delete*/      
ELSE IF @Type=3      
BEGIN      
  IF  EXISTS(SELECT '*' FROM ARC_Facility_DriverMaster WHERE DriverID=@PID And Status=1)      
  BEGIN      
   UPDATE ARC_Facility_DriverMaster SET Status=0,DeletedBy=@DeletedBy,DeletedDt=GETDATE()     
   WHERE DriverID=@PID    
   SET @Flag=1      
  END      
  ELSE      
  BEGIN      
   SET @Flag=2      
  END      
END       
SELECT Result=@Flag        
END  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FACILITY_Delete] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FACILITY_Delete] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FACILITY_Delete] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FACILITY_Delete] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FACILITY_Delete] TO [DB_DMLSupport]
    AS [dbo];

