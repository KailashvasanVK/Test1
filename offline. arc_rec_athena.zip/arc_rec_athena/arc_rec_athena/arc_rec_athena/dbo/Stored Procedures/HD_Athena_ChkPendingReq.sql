﻿CREATE proc HD_Athena_ChkPendingReq    
      @UserId int    
AS    
Begin    
if( select COUNT(*) from HD_Athena_Transfer t
inner join HD_ISSUE_REQUEST tr on t.ReqId = tr.ISS_REQID and tr.ACTIVE = 'Y'
where t.UserId = @UserId and t.Status in (0,1)) > 0     
begin    
  select '1' as Result    
end    
else if ( select COUNT(*) from HD_AthenaUsers t 
inner join HD_ISSUE_REQUEST tr on t.Issue_ReqId = tr.ISS_REQID and tr.ACTIVE = 'Y'
where t.UserId = @UserId and t.Status < 1) > 0     
begin    
  select '1' as Result    
end    
else if ( select COUNT(*) from HD_Athena_Terminate t
inner join HD_ISSUE_REQUEST tr on t.ReqId = tr.ISS_REQID and tr.ACTIVE = 'Y'
where t.UserId = @UserId and t.Status < 1) > 0     
begin    
  select '1' as Result    
end    
else     
 select '0' as Result    
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_ChkPendingReq] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_ChkPendingReq] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_ChkPendingReq] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_ChkPendingReq] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_ChkPendingReq] TO [DB_DMLSupport]
    AS [dbo];

