﻿CREATE PROCEDURE [DBO].[ARC_KIN_USER_RIGHTS_INFO]          
@UID INT = NULL          
,@NTUSERNAME VARCHAR(100) = NULL          
,@ACTION VARCHAR(50) = NULL          
AS          
          
BEGIN          
 IF @ACTION = 'GET_RIGHTS'          
 BEGIN          
  SELECT * FROM ARC_KIN_USER_RIGHTS           
  WHERE STATUS=1 AND UID=@UID          
 END          
           
 IF @ACTION = 'GET_USERID'          
 BEGIN          
  SELECT USERID FROM ARC_REC_USER_INFO          
  WHERE ACTIVE<>0 AND NT_USERNAME=@NTUSERNAME          
 END    
     
  IF @ACTION = 'CHECK_RIGHTS'          
 BEGIN          
  SELECT UI.NT_USERNAME,HD.Designation,HD.DesigId FROM ARC_REC_USER_INFO UI    
  INNER JOIN HR_Designation HD ON HD.DesigId=UI.DESIGNATION_ID     
  WHERE UI.ACTIVE=1 AND (UI.DESIGNATION_ID IN (4,9,10,11,12,14,15,20,21,33) OR UI.USERID IN(822,828,934,1693,1974))  AND UI.USERID=@UID        
 END            
END        
    
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_KIN_USER_RIGHTS_INFO] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_KIN_USER_RIGHTS_INFO] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_KIN_USER_RIGHTS_INFO] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_KIN_USER_RIGHTS_INFO] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_KIN_USER_RIGHTS_INFO] TO [DB_DMLSupport]
    AS [dbo];

