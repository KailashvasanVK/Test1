﻿Create Proc Knol_Cleanup
As
begin
select MIN(scoreid) Scoreid,convert(date,CreatedOn) Date,userid,ReferenceId,COUNT(*) CC into #Temptalb from RR_SCOREBOARD   
where ReferenceInfo='KNOL_READ' and status=1
and convert(date,CreatedOn)>=CONVERT(date,getdate()-2) 
group by userid,ReferenceId,convert(date,CreatedOn) having COUNT(*)>1 order by COUNT(*) desc 


update b set b.Status =0,Points =0 from #Temptalb a
inner join RR_SCOREBOARD b on a.Userid =b.Userid
where a.Scoreid <>b.Scoreid   and a.ReferenceId=b.ReferenceId 

select * from #Temptalb

drop table #Temptalb
end
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Knol_Cleanup] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Knol_Cleanup] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Knol_Cleanup] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Knol_Cleanup] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Knol_Cleanup] TO [DB_DMLSupport]
    AS [dbo];

