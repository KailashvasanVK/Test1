﻿CREATE procedure ARC_REC_UserprofileAssociates          
       @FunctionalityID int=0,      
       @CLIENT_ID int=0,      
       @SHIFT_ID int=0,      
       @ASSOCIATE_ID int=0,    
       @SearchStr varchar(100) = '',    
    @SearchPattern varchar(4) = '=' /** = or % **/                   
As          
Begin          
  if OBJECT_ID('tempdb..#UserprofileAssociatesView') is not null drop table #UserprofileAssociatesView    
Create Table #UserprofileAssociatesView([CheckAll] varchar(max),EMPCODE varchar(20),NAME varchar(100),FunctionName varchar(100) ,REPORTING_TO varchar(100),Designation varchar(100),CLIENT_NAME  varchar(100),SHIFT_NAME varchar(50))     
    
      
if(@ASSOCIATE_ID  > 0 )          
begin     
insert into #UserprofileAssociatesView([CheckAll],EMPCODE,NAME,FunctionName,REPORTING_TO,Designation,CLIENT_NAME,SHIFT_NAME)                              
         
select x.[CheckAll],x.EMPCODE,x.NAME,x.FunctionName,x.REPORTING_TO,x.Designation,x.CLIENT_NAME,si.SHIFT_NAME      
 from (      
select '<input type="checkbox" style="margin-left: 20px;" class="CheckAll" id="'+convert(varchar,ui.USERID)+'">' as [CheckAll],      
ui.EMPCODE,ui.FIRSTNAME+' '+ui.LASTNAME as NAME,f.FunctionName,ui.REPORTING_TO,          
d.Designation,cl.CLIENT_NAME,      
(      
select top 1 st.SHIFT_ID from ARC_REC_SHIFT_TRAN st      
where st.USERID = ui.USERID order by st.CREATED_DT desc      
) as SHIFT_ID      
from ARC_REC_USER_INFO ui          
left join HR_Functionality f on ui.FUNCTIONALITY_ID = f.FunctionalityId          
left join HR_Designation d on ui.DESIGNATION_ID = d.DesigId          
left join ARC_FIN_CLIENT_INFO cl on ui.CLIENT_ID = cl.CLIENT_ID          
where ui.AHS_PRL = 'Y' and ui.ACTIVE = 1 and ui.FUNCTIONALITY_ID = @FunctionalityID and cl.CLIENT_ID=@CLIENT_ID        
and ui.USERID = @ASSOCIATE_ID      
and ui.USERID <> 535   -- shaji userid          
  )x      
left join ARC_REC_SHIFT_INFO si on x.SHIFT_ID = si.SHIFT_ID      
order by x.NAME       
end         
else if(@SHIFT_ID > 0)      
begin      
insert into #UserprofileAssociatesView([CheckAll],EMPCODE,NAME,FunctionName,REPORTING_TO,Designation,CLIENT_NAME,SHIFT_NAME)                              
select x.[CheckAll],x.EMPCODE,x.NAME,x.FunctionName,x.REPORTING_TO,x.Designation,x.CLIENT_NAME,si.SHIFT_NAME      
 from (      
select '<input type="checkbox" style="margin-left: 20px;" class="CheckAll" id="'+convert(varchar,ui.USERID)+'">' as [CheckAll],      
ui.EMPCODE,ui.FIRSTNAME+' '+ui.LASTNAME as NAME,f.FunctionName,ui.REPORTING_TO,          
d.Designation,cl.CLIENT_NAME,      
(      
select top 1 st.SHIFT_ID from ARC_REC_SHIFT_TRAN st      
where st.USERID = ui.USERID order by st.CREATED_DT desc      
) as SHIFT_ID      
from ARC_REC_USER_INFO ui          
left join HR_Functionality f on ui.FUNCTIONALITY_ID = f.FunctionalityId          
left join HR_Designation d on ui.DESIGNATION_ID = d.DesigId          
left join ARC_FIN_CLIENT_INFO cl on ui.CLIENT_ID = cl.CLIENT_ID          
where ui.AHS_PRL = 'Y' and ui.ACTIVE = 1 and ui.FUNCTIONALITY_ID = @FunctionalityID and cl.CLIENT_ID=@CLIENT_ID        
and ui.USERID <> 535   -- shaji userid          
  )x      
left join ARC_REC_SHIFT_INFO si on x.SHIFT_ID = si.SHIFT_ID      
where x.SHIFT_ID = @SHIFT_ID      
order by x.NAME       
end      
else      
begin      
insert into #UserprofileAssociatesView([CheckAll],EMPCODE,NAME,FunctionName,REPORTING_TO,Designation,CLIENT_NAME,SHIFT_NAME)                              
select x.[CheckAll],x.EMPCODE,x.NAME,x.FunctionName,x.REPORTING_TO,x.Designation,x.CLIENT_NAME,si.SHIFT_NAME      
 from (      
select '<input type="checkbox" style="margin-left: 20px;" class="CheckAll" id="'+convert(varchar,ui.USERID)+'">' as [CheckAll],      
ui.EMPCODE,ui.FIRSTNAME+' '+ui.LASTNAME as NAME,f.FunctionName,ui.REPORTING_TO,          
d.Designation,cl.CLIENT_NAME,      
(      
select top 1 st.SHIFT_ID from ARC_REC_SHIFT_TRAN st      
where st.USERID = ui.USERID order by st.CREATED_DT desc      
) as SHIFT_ID      
from ARC_REC_USER_INFO ui          
left join HR_Functionality f on ui.FUNCTIONALITY_ID = f.FunctionalityId          
left join HR_Designation d on ui.DESIGNATION_ID = d.DesigId          
left join ARC_FIN_CLIENT_INFO cl on ui.CLIENT_ID = cl.CLIENT_ID          
where ui.AHS_PRL = 'Y' and ui.ACTIVE = 1 and ui.FUNCTIONALITY_ID = @FunctionalityID and cl.CLIENT_ID=@CLIENT_ID        
and ui.USERID <> 535   -- shaji userid          
  )x      
left join ARC_REC_SHIFT_INFO si on x.SHIFT_ID = si.SHIFT_ID      
--order by x.NAME       
end      
  Declare @OrderStr varchar(100)           
SET @OrderStr  = ' order by NAME'     
     
Exec FilterTable    
@DbName = 'tempdb'    
,@TblName = '#UserprofileAssociatesView'    
,@SearchStr = @SearchStr    
,@SearchPattern = @SearchPattern    
,@OrderStr = @OrderStr    
if OBJECT_ID('tempdb..#UserprofileAssociatesView') is not null drop table #UserprofileAssociatesView    
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_UserprofileAssociates] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UserprofileAssociates] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UserprofileAssociates] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_UserprofileAssociates] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UserprofileAssociates] TO [DB_DMLSupport]
    AS [dbo];

