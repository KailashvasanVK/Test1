﻿CREATE Proc BirthdayWishes          
as          
Begin         
if exists(select 'x' from WhomeBirthdaytoday where   BirthDay IS not null)      
begin       
update ARC_Forum_Lounge_Messages set priority=0 where priority>=1 and ID not in (9377)          
insert into ARC_Forum_Lounge_Messages(MsgContent,Status,CreatedBy,CreatedOn,ModifiedBy,ModifiedOn,Priority)          
select BirthDay,1,'accesshealthcare',GETDATE(),null,null,1 from WhomeBirthdaytoday where BirthDay IS not null       
End       
ELSE    
BEGIN    
update ARC_Forum_Lounge_Messages set priority=0 where priority>=1  AND MsgId<>0 and ID not in (9377)        
    
End       
end 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[BirthdayWishes] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[BirthdayWishes] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[BirthdayWishes] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[BirthdayWishes] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[BirthdayWishes] TO [DB_DMLSupport]
    AS [dbo];

