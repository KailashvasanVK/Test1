﻿CREATE proc Attendance_entry_process      
as        
begin      
declare @From datetime=convert(date,getdate()-1)        
          
select @From        
  
insert into ARC_REC_Attendance(userid,nt_username,date,shiftid,Logon,Logout,TotalHrs,WorkHours,LockHrs,Designid,Functionalityid,Createdby,Createdon,Client_id)        
select * from (        
select ui.userid,UI.NT_USERNAME,@From date,st.SHIFT_ID ,Ai.LoginDate,AI.Logout,isnull(Whours ,0) WorkHrs,isnull(Fhours,0)     
TotalHrs,isnull(Hhours,0) LockHrs,UI.DESIGNATION_ID,UI.FUNCTIONALITY_ID,1 CBy,GETDATE() CON,CLIENT_ID        
from ARC_REC_USER_INFO  UI        
left outer join ARC_REC_SHIFT_traN ST on ST.USERID =UI.USERID         
left join UL_Attendance AI on UI.NT_USERNAME =AI.UserAccount        
and   date=@From )  as udhaya         
where USERID is not null             
          
end
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Attendance_entry_process] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Attendance_entry_process] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Attendance_entry_process] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Attendance_entry_process] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Attendance_entry_process] TO [DB_DMLSupport]
    AS [dbo];

