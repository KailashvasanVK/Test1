﻿CREATE PROCEDURE  ARC_Forum_MessageBoard_Insert                                                                              
@Headline VARCHAR(500),                                                                              
@MessageText VARCHAR(Max),                                                                              
@NT_User VARCHAR(75),                                                                   
@CoverPhotoId int=0,                                                                   
@Status TINYINT,                                                              
@ContentWithOutImage varchar(max),                                                            
@AlbumId int=0,                                            
@Extenstion varchar(250)=null,                        
@FacilityType tinyint=1,                        
@HTMLInnerImage varchar(100)                                                                               
                                                                            
AS                                                                             
/*                                                                              
                                                                              
DECLARE @output int=0                                                                              
Exec ARC_Forum_MessageBoard_Insert 'Test','Test','Udhai',@output OUTPUT                                                                              
select @output as output                                                            
                                                      
SP_ARC_FORUM_MessageBoard_update                      
                  
                  
exec ARC_Forum_MessageBoard_Insert @Headline='Teste342',@MessageText='Test 3245                  
                   
',@NT_User='udhayaganesh.p',@ContentWithOutImage=N'Test 3245                  
                  
                  
',@CoverPhotoId=0,@AlbumId=0,@Extenstion='Teste342.pdf',@FacilityType=2,@HTMLinnerimage='206.jpeg',@Status=1                   
                                                                    
                                                                              
*/                                                                              
BEGIN                          
                        
Declare @AHSImage varchar(200)='172.19.5.3\arc_forum\Newdeskimage\'+ @HTMLInnerImage,                        
@ManilaImage varchar(200)='172.25.4.66\manila_forum\Newdeskimage\', @Filetransfer varchar(500),                    
@filepathAHS varchar(200)='172.19.5.3\arc_forum\Attachement\' ,                                         
@filepathManila varchar(200)='172.25.4.66\manila_forum\Attachement\'    
,@innerUrl Nvarchar(500)='<img src=''https://www.accesshealthcare.co/Webforum/'      
    
      
    
    
if @HTMLInnerImage is null      
Begin        
set @HTMLInnerImage='278_123.jpeg'    
End    
    
set @innerUrl=@innerUrl+@HTMLInnerImage+'''/>'     
    
                   
                        
if @FacilityType=1                        
Begin                                                                            
DECLARE @output INT=0,@filepath varchar(100)='\\172.19.5.3\ARC_forum\Attachement\'                                      
                                    
if @Extenstion = null                                    
set @Extenstion=''                                                                             
                                                                            
IF NOT EXISTS (SELECT 'x' FROM ARC_Forum_MessageBoard(nolock) WHERE Headline=@Headline and CreatedOn <>GETDATE()  )                                                                              
 BEGIN                                                                        
 INSERT INTO ARC_Forum_MessageBoard(Headline,Messagetext,CoverPhotoId,CreatedBy,Status,ContentWithOutImage,AlbumId,Extension,FacilityType)                                                   
 VALUES (@Headline,@MessageText,@CoverPhotoId,@NT_User,@Status,@ContentWithOutImage,@AlbumId,@Extenstion,@FacilityType)                                                                 
 SET @output=IDENT_CURRENT('ARC_Forum_MessageBoard')                                            
set @filepath=@filepath +@Extenstion             
          
insert into ARC_Forum_lounge_messages(MsgContent,Status,CreatedBy,CreatedOn,Priority,Type,Msgid)                                  
select @Headline,1,'accesshealthcare',GETDATE(),isnull(MAX(priority),0)+1,2,@output from ARC_Forum_lounge_messages                                   
                  
                                                                 
if  exists (select top 1 'x' from ARC_Forum_MessageBoard where msgid=@output and  @Status =1 and isnull(mailstatus,0) <>1   )                                                      
Begin                                                             
/* IF Artical has Publised Mail Will trigger */              
                                            
IF @Extenstion <>''                                          
BEGIN                                                    
set @ContentWithOutImage =@ContentWithOutImage+'<P><B>Legal Disclaimer:</B><P>                              
<P>The information contained in this message (including all attachments) may be privileged and confidential.                               
It is intended to be read only by the individual or entity to whom it is addressed or by their designee.                               
If the reader of this message is not the intended recipient, please destroy this message immediately and also please note that you are on notice that any distribution of this message, in any form, is strictly prohibited.                              
If you have received this message in error, please immediately notify the sender and delete or destroy any copy of this message!</p>'                              
                                                      
EXEC msdb.dbo.sp_send_dbmail                                                         
@profile_name = 'Newsdesk',                                                                                                                                
@recipients = 'all@accesshealthcare.co',                                                                                                                                                                           
@subject=@Headline,                                                      
@body = @ContentWithOutImage,                                                                                                        
@body_format  = 'HTML',                                      
@file_attachments =@filepath                                                              
                            
                            
                                                                                     
                                                      
update ARC_Forum_MessageBoard set mailstatus=1  WHERE MsgId=@output                                               
END                                            
ELSE                                            
BEGIN           
      
if len(@ContentWithOutImage)>30      
Begin                              
                              
set @ContentWithOutImage =@ContentWithOutImage+'<P><B>Legal Disclaimer:</B><P>                              
<P>The information contained in this message (including all attachments) may be privileged and confidential.                               
It is intended to be read only by the individual or entity to whom it is addressed or by their designee.                               
If the reader of this message is not the intended recipient, please destroy this message immediately and also please note that you are on notice that any distribution of this message, in any form, is strictly prohibited.                              
If you have received this message in error, please immediately notify the sender and delete or destroy any copy of this message!</p>'                              
                           
EXEC msdb.dbo.sp_send_dbmail                                                                                                                                                                
@profile_name = 'Newsdesk',                                                                            
@recipients = 'all@accesshealthcare.co',                                                                                                          
@subject=@Headline,                                                                                                   
@body = @ContentWithOutImage,                                                                                   
@body_format  = 'HTML'             
End                           
                            
                
--insert into ARC_Forum_lounge_messages(MsgContent,Status,CreatedBy,CreatedOn,Priority,Type,Msgid)                                  
--select @Headline,1,'accesshealthcare',GETDATE(),isnull(MAX(priority),0)+1,2,@output from ARC_Forum_lounge_messages                                   
                                                                       
                                            
update ARC_Forum_MessageBoard set mailstatus=1  WHERE MsgId=@output                                               
                                               
                                                 
END                                                                                                
End                                                        
 SELECT isnull(@output,0) AS OUTPUT                                                             
 END                                                                              
ELSE                                                                        
 BEGIN                                                                       
 SELECT isnull(@output,0) AS OUTPUT                                                                 
 END    ---                           
End /*   Facility type  = 1        */                            
if @FacilityType=2                        
Begin                                                                            
DECLARE @Manila varchar(100)='\\172.25.4.66\manila_Forum\Attachement\'                                      
                                    
if @Extenstion = null                                  
set @Extenstion=''                                                                             
                                                                            
IF NOT EXISTS (SELECT 'x' FROM [172.25.4.66].manila_rec.dbo.ARC_Forum_MessageBoard WHERE Headline=@Headline and CreatedOn <>GETDATE()  )                                                                              
 BEGIN                                                                        
 INSERT INTO [172.25.4.66].manila_rec.dbo.ARC_Forum_MessageBoard(Headline,Messagetext,CoverPhotoId,CreatedBy,Status,ContentWithOutImage,AlbumId,Extension,FacilityType)                                                                   
 VALUES (@Headline,@MessageText,@CoverPhotoId,@NT_User,@Status,@ContentWithOutImage,@AlbumId,@Extenstion,@FacilityType)                                                                 

 SET @output=(select MAX(msgid) from [172.25.4.66].manila_rec.dbo.ARC_Forum_MessageBoard )                      

set @filepath=@filepath +@Extenstion                     
                  
set @Manila= @Manila+@Extenstion              
          
                            
insert into [172.25.4.66].manila_rec.dbo.ARC_Forum_lounge_messages(MsgContent,Status,CreatedBy,CreatedOn,Priority,Type,Msgid)                                  
select @Headline,1,'accesshealthcare',GETDATE(),isnull(MAX(priority),0)+1,2,@output from ARC_Forum_lounge_messages                                                                                                         
               
                    
set @filepathAHS =@filepathAHS+@Extenstion                   
IF @Extenstion <>''                 
BEGIN                 
set @Filetransfer = N'COPY "\\' + @filepathAHS + '" "\\' + @filepathManila + '"'                        
                        
EXEC xp_cmdshell @Filetransfer                 
END                   
                
set @Filetransfer = N'COPY "\\' + @AHSImage + '" "\\' + @ManilaImage + '"'                        
                        
EXEC   xp_cmdshell @Filetransfer                 
                                                                 
if  exists (select top 1 'x' from [172.25.4.66].manila_rec.dbo.ARC_Forum_MessageBoard 
where msgid=@output and  @Status =1 and isnull(mailstatus,0) <>1   )                                                      
Begin                                                             
/* IF Artical has Publised Mail Will trigger */                
                                            
IF @Extenstion <>''                                          
BEGIN     
    
                                 
                              
set @ContentWithOutImage =@ContentWithOutImage+'<P><B>Legal Disclaimer:</B><P>                              
<P>The information contained in this message (including all attachments) may be privileged and confidential.                               
It is intended to be read only by the individual or entity to whom it is addressed or by their designee.                               
If the reader of this message is not the intended recipient, please destroy this message immediately and also please note that you are on notice that any distribution of this message, in any form, is strictly prohibited.                              
If you have received this message in error, please immediately notify the sender and delete or destroy any copy of this message!</p>'                              
                       
EXEC msdb.dbo.sp_send_dbmail                                                                                                                                                                
@profile_name = 'Newsdesk',                                                                                     
@recipients = 'Manilaall@accesshealthcare.co',   
@blind_copy_recipients='hepsiba.raj@accesshealthcare.co;udhayaganesh.p@accesshealthcare.co',  
@subject=@Headline,                      
@body = @ContentWithOutImage,                                                                                                      
@body_format  = 'HTML',                                      
@file_attachments =@Manila                                                              
                            
                                                     
update [172.25.4.66].manila_rec.dbo.ARC_Forum_MessageBoard set mailstatus=1  WHERE MsgId=@output                          
                        
                                             
END                                            
ELSE                                            
BEGIN         
    
if @innerUrl is null            
begin                 
set @innerUrl =''            
end                               
                              
set @ContentWithOutImage =@ContentWithOutImage+@innerUrl+'<P><B>Legal Disclaimer:</B><P>                              
<P>The information contained in this message (including all attachments) may be privileged and confidential.                               
It is intended to be read only by the individual or entity to whom it is addressed or by their designee.                               
If the reader of this message is not the intended recipient, please destroy this message immediately and also please note that you are on notice that any distribution of this message, in any form, is strictly prohibited.                              
If you have received this message in error, please immediately notify the sender and delete or destroy any copy of this message!</p>'                              
                                      
EXEC msdb.dbo.sp_send_dbmail                                                                                                                          
@profile_name = 'Newsdesk',                                                          
@recipients = 'Manilaall@accesshealthcare.co',  
@blind_copy_recipients='hepsiba.raj@accesshealthcare.co;udhayaganesh.p@accesshealthcare.co',                                                                                                                                                                          
@subject=@Headline,                                                                                                   
@body = @ContentWithOutImage,                                                                                   
@body_format  = 'HTML'                                  
                            
                            
--insert into [172.25.4.66].manila_rec.dbo.ARC_Forum_lounge_messages(MsgContent,Status,CreatedBy,CreatedOn,Priority,Type,Msgid)                                  
--select @Headline,1,'accesshealthcare',GETDATE(),isnull(MAX(priority),0)+1,2,@output from ARC_Forum_lounge_messages           
                                                                       
                                            
update [172.25.4.66].manila_rec.dbo.ARC_Forum_MessageBoard set mailstatus=1  WHERE MsgId=@output                          
                        
                                                 
END                                                
                         
End                                                        
 SELECT isnull(@output,0) AS OUTPUT                                                             
 END                                                                              
ELSE                                                                              
 BEGIN                               
 SELECT isnull(@output,0) AS OUTPUT                                                                 
 END    ---                           
End /*   Facility type  = 2        */                          
ENd
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_Insert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_Insert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_Insert] TO [DB_DMLSupport]
    AS [dbo];

