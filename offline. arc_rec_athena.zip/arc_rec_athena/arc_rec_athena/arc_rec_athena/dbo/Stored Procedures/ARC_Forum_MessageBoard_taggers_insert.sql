﻿CREATE procedure ARC_Forum_MessageBoard_taggers_insert    
(    
@msgId int,    
@ntUserId varchar(75),    
@FacilityType tinyint=1    
)          
as          
begin     
IF @FacilityType=1    
    
Begin    
 insert into Arc_Forum_MessageBoard_Taggedusers(MsgId,NT_userid) values (@msgId,@ntUserId)    
End    
    
Else IF @FacilityType=2    
    
Begin    
 insert into [172.25.4.66].manila_rec.dbo.Arc_Forum_MessageBoard_Taggedusers(MsgId,NT_userid) values (@msgId,@ntUserId)    
End     
Else IF @FacilityType=3    
Begin    
 insert into Arc_Forum_MessageBoard_Taggedusers(MsgId,NT_userid) values (@msgId,@ntUserId)    
  
 insert into [172.25.4.66].manila_rec.dbo.Arc_Forum_MessageBoard_Taggedusers(MsgId,NT_userid) values (@msgId,@ntUserId)    
End  
        
end
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_taggers_insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_taggers_insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_taggers_insert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_taggers_insert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_taggers_insert] TO [DB_DMLSupport]
    AS [dbo];

