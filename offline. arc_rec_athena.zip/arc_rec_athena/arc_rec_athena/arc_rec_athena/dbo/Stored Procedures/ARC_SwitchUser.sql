﻿CREATE procedure ARC_SwitchUser    
AS    
Begin    
Select * from (  
Select  UI.NT_USERNAME , UI.NT_USERNAME + '>' + HF.FunctionName as LoginName    
 from ARC_REC_Athena..ARC_REC_USER_INFO  UI    
 inner join HR_Functionality HF on HF.FunctionalityId = UI.FUNCTIONALITY_ID     
 where AHS_PRL = 'Y' and ACTIVE = 1  and ui.nt_username <> ''  
 -- order by USERID      
 )x order by Loginname  
 End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_SwitchUser] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_SwitchUser] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_SwitchUser] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_SwitchUser] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_SwitchUser] TO [DB_DMLSupport]
    AS [dbo];

