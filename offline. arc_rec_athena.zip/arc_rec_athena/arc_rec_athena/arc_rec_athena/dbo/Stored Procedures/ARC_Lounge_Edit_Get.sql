﻿CREATE Proc ARC_Lounge_Edit_Get    
@Msgid int,    
@NT_Username Varchar(100)    
As    
Begin    
if Exists (select 'x' from ARC_Forum_Lounge_Messages where  Id=@msgid and ( CreatedBy=@NT_Username    
or @NT_Username in (select NTUsername from ARC_Lounge_Admin)) )    
Begin    
select ID,MsgContent from ARC_Forum_Lounge_Messages where Id=@msgid and CreatedBy=@NT_Username    
End    
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Edit_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Edit_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Edit_Get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Edit_Get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Edit_Get] TO [DB_DMLSupport]
    AS [dbo];

