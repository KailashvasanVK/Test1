﻿CREATE Proc Arc_Rec_CapmanAccess_Validate
@NT_UserName varchar(75)=NUll,
@output int=0 
As
Begin
 SET NOCOUNT ON;
IF exists (select 'x' from Arc_Rec_CapmanAccess where NT_UserName=@NT_UserName )
Set @output=1
Else
set @output=0
Select @output 'Output'
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Arc_Rec_CapmanAccess_Validate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Arc_Rec_CapmanAccess_Validate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Arc_Rec_CapmanAccess_Validate] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Arc_Rec_CapmanAccess_Validate] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Arc_Rec_CapmanAccess_Validate] TO [DB_DMLSupport]
    AS [dbo];

