﻿create proc HD_Athena_ChkPendingReqTermination
						@UserId int
AS
Begin
if( select COUNT(*) from HD_Athena_Transfer where UserId = 1049 and Status in (0,1)) > 0 
begin
		select '1' as Result
end
else if ( select COUNT(*) from HD_AthenaUsers where UserId = 1049 and Status < 1) > 0 
begin
		select '1' as Result
end
else 
	select '0' as Result
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_ChkPendingReqTermination] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_ChkPendingReqTermination] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_ChkPendingReqTermination] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_ChkPendingReqTermination] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_ChkPendingReqTermination] TO [DB_DMLSupport]
    AS [dbo];

