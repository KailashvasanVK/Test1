﻿CREATE Procedure ARC_REC_CAPMAN_Facility        
(        
@facilityid int=0,    
@ShiftId int=0        
)        
As        
/*       
     
ARC_REC_CAPMAN_Facility @facilityid=2, @ShiftId=1       
    
    
*/        
Begin        
        
select EF.Facilityid,EF.FacilityName+' - '+EF.LevelName Facility,'Floor Capacity'=(select count(*) from Eye_IPDetails a where a.status in(1,0) and a.facilityid=EF.facilityid),    
'Opertion Capacity'=(select count(*) from Eye_IPDetails B where b.status in(1) and B.facilityid=EF.facilityid),    
'Blocked'=(select count(*) from ARC_REC_CAPMAN C where  C.facilityid=EF.facilityid and c.Shiftid=@ShiftId and c.status=1 and baystatus=1 ),    
'Free'=(select count(*) from ARC_REC_CAPMAN C where  C.facilityid=EF.facilityid and c.Shiftid=@ShiftId and c.status=1 and baystatus=0 )    
from Eye_Facility EF where Facilityid=@facilityid     
  
  
Select ROW_NUMBER() over(order by Client) 'Sl.No',Client,[Opertion Capacity],Blocked,'Utilized %'=cast((Blocked*1.0/[Opertion Capacity])*100 as Numeric(8,0)) from (  
select Ci.CLIENT_NAME Client,'Opertion Capacity'=(select count(*) from Eye_IPDetails B where b.status in(1) and B.facilityid=@facilityid)  
,COUNT(*) Blocked from ARC_REC_CAPMAN CM,ARC_FIN_CLIENT_INFO CI  
where CM.ClientID=Ci.CLIENT_ID and  Facilityid=@facilityid and Shiftid=@ShiftId   
Group By Client_Name ) As SUB1  
    
        
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_Facility] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_Facility] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_Facility] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_Facility] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_Facility] TO [DB_DMLSupport]
    AS [dbo];

