﻿CREATE Proc ARC_CBT_ACCESS_Get                  
@NT_USERNAME Varchar(100)='udhayaganesh.p',    
@Apptype tinyint=0                 
as                  
Begin                            
select * from(                
select UI.Userid,UI.NT_username,@Apptype Apptype from ARC_REC_InductionMaster  IM                  
Inner join ARC_REC_USER_INFO_VY UI on UI.Userid=IM.userid                  
where Trainee='Y' and NT_UserName=@NT_USERNAME   
union    
select Userid,NT_UserName,@Apptype Apptype from     
ARC_REC_USER_INFO_VY Where Userid in(807,847,2351)    
) as udhaya where NT_UserName=@NT_USERNAME  and UserId not in (select CreatedBy from ARC_CBT_FEEDBACK_ENTRY)  
  
               
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_CBT_ACCESS_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_CBT_ACCESS_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_CBT_ACCESS_Get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_CBT_ACCESS_Get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_CBT_ACCESS_Get] TO [DB_DMLSupport]
    AS [dbo];

