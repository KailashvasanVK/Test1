﻿CREATE PROCEDURE ARC_REC_SELF_ATTENDANCE_INS                        
 @USERID INT                        
 ,@ATTENDANCE_DATE DATE                        
 ,@ATT_TYPE CHAR(1)                 
 ,@LOGIN_TIME DATETIME=null                
 ,@LOGOUT_TIME DATETIME =null                     
 ,@WORKED_HRS NUMERIC(8,2)      
 ,@REASON_ID INT=0      
 ,@VERIFIED_COMMENTS VARCHAR(1000)=''                        
 ,@CREATED_BY INT            
AS                      
BEGIN                        
 declare @Aid int     
 --check existing self attendance              
 IF NOT EXISTS(SELECT * FROM ARC_REC_SELF_ATTENDANCE WHERE USERID = @USERID AND CONVERT(VARCHAR,ATTENDANCE_DATE,111) = CONVERT(VARCHAR,@ATTENDANCE_DATE,111))                        
 BEGIN    
   --attendance type full present or half present     
 IF (@ATT_TYPE <> '')                       
 BEGIN   
                   
   INSERT INTO ARC_REC_SELF_ATTENDANCE(USERID,ATTENDANCE_DATE,ATT_TYPE,LOGIN_TIME,LOGOUT_TIME,WORKED_HRS,CREATED_BY)                        
   SELECT @USERID,@ATTENDANCE_DATE,@ATT_TYPE,@LOGIN_TIME,@LOGOUT_TIME,@WORKED_HRS,@CREATED_BY          
           
   if(SELECT ISNULL(COUNT(*),0) FROM ARC_REC_USER_INFO WHERE USERID = @CREATED_BY and FUNCTIONALITY_ID = 6 ) > 0 -- update if hr edit the attendance       
   begin     
        
   UPDATE ARC_REC_Attendance set        
   Verified_By = @CREATED_BY,        
   Verified_Present = @ATT_TYPE,    
   P_days = Case when @ATT_TYPE = 'F' then 1 when @ATT_TYPE = 'H' then 0.5 else 0 end   
   where Userid = @USERID and CONVERT(VARCHAR,[DATE],111) = CONVERT(VARCHAR,@ATTENDANCE_DATE,111)       
           
   Select @Aid = Aid from ARC_REC_Attendance where Userid = @USERID and CONVERT(VARCHAR,[DATE],111) = CONVERT(VARCHAR,@ATTENDANCE_DATE,111)       
           
   INSERT INTO ARC_ME_DISCRIPENCY_TRAN( AID,DIS_TYPE, VERIFIED_PRESENT,VERIFIED_BY,VERIFIED_COMMENTS,CREATED_DT,ATT_DATE,USERID)            
   SELECT @Aid,@REASON_ID,@ATT_TYPE,@CREATED_BY,@VERIFIED_COMMENTS,GETDATE(),@ATTENDANCE_DATE,@USERID         
           
           
   end    
                          
  END                      
 END                       
 ELSE         
 BEGIN                      
   IF (@ATT_TYPE <> '')                      
    BEGIN           
      
    --move to self attendance log               
      INSERT INTO ARC_REC_SELF_ATTENDANCE_LOG(USERID,ATTENDANCE_DATE,ATT_TYPE,LOGIN_TIME,LOGOUT_TIME,WORKED_HRS,CREATED_BY,CREATED_DT)                    
         SELECT USERID,ATTENDANCE_DATE,ATT_TYPE,@LOGIN_TIME,@LOGOUT_TIME,WORKED_HRS,CREATED_BY,CREATED_DT FROM ARC_REC_SELF_ATTENDANCE  WHERE USERID = @USERID AND CONVERT(VARCHAR,ATTENDANCE_DATE,111) = CONVERT(VARCHAR,@ATTENDANCE_DATE,111)                
  
  
    
    --update self attendance  
   UPDATE ARC_REC_SELF_ATTENDANCE SET                        
   ATT_TYPE = @ATT_TYPE,                        
   WORKED_HRS = @WORKED_HRS,                      
   CREATED_BY = @CREATED_BY ,              
   LOGIN_TIME = @LOGIN_TIME,              
   LOGOUT_TIME = @LOGOUT_TIME                     
   WHERE USERID = @USERID AND CONVERT(VARCHAR,ATTENDANCE_DATE,111) = CONVERT(VARCHAR,@ATTENDANCE_DATE,111)         
              
   if(SELECT ISNULL(COUNT(*),0) FROM ARC_REC_USER_INFO WHERE USERID = @CREATED_BY and FUNCTIONALITY_ID = 6 ) > 0 -- update only edited by hr       
   begin        
   UPDATE ARC_REC_Attendance set        
     Verified_By = @CREATED_BY,        
     Verified_Present = @ATT_TYPE,      
     Verified_Comments =@VERIFIED_COMMENTS,        
     P_days = Case when @ATT_TYPE = 'F' then 1 when @ATT_TYPE = 'H' then 0.5 else 0 end    
     where Userid = @USERID and CONVERT(VARCHAR,[DATE],111) = CONVERT(VARCHAR,@ATTENDANCE_DATE,111)       
           
            
    Select @Aid = Aid from ARC_REC_Attendance where Userid = @USERID and CONVERT(VARCHAR,[DATE],111) = CONVERT(VARCHAR,@ATTENDANCE_DATE,111)       
           
     INSERT INTO ARC_ME_DISCRIPENCY_TRAN( AID,DIS_TYPE, VERIFIED_PRESENT,VERIFIED_BY,VERIFIED_COMMENTS,CREATED_DT,ATT_DATE,USERID)            
     SELECT @Aid,@REASON_ID,@ATT_TYPE,@CREATED_BY,@VERIFIED_COMMENTS,GETDATE(),@ATTENDANCE_DATE,@USERID         
      
        
   end                        
           
  END                      
   ELSE                      
    BEGIN                      
  INSERT INTO ARC_REC_SELF_ATTENDANCE_LOG(USERID,ATTENDANCE_DATE,ATT_TYPE,LOGIN_TIME,LOGOUT_TIME,WORKED_HRS,CREATED_BY,CREATED_DT)                    
  SELECT USERID,ATTENDANCE_DATE,ATT_TYPE,LOGIN_TIME,LOGOUT_TIME,WORKED_HRS,CREATED_BY,CREATED_DT FROM ARC_REC_SELF_ATTENDANCE WHERE USERID = @USERID AND CONVERT(VARCHAR,ATTENDANCE_DATE,111) = CONVERT(VARCHAR,@ATTENDANCE_DATE,111)                     
  DELETE FROM ARC_REC_SELF_ATTENDANCE WHERE USERID = @USERID AND CONVERT(VARCHAR,ATTENDANCE_DATE,111) = CONVERT(VARCHAR,@ATTENDANCE_DATE,111)                           
      
  if EXISTS (SELECT * FROM ARC_REC_USER_INFO WHERE USERID = @CREATED_BY and FUNCTIONALITY_ID = 6 )    
  begin    
   update ARC_REC_Attendance set    
   Verified_By = @CREATED_BY,Verified_Present = 'NP',Verified_Comments = @VERIFIED_COMMENTS    
   ,P_days = 0    
   where Userid = @USERID and [date] = @ATTENDANCE_DATE    
  end    
      
    END                      
                         
END                      
                      
END     
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_SELF_ATTENDANCE_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_SELF_ATTENDANCE_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_SELF_ATTENDANCE_INS] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_SELF_ATTENDANCE_INS] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_SELF_ATTENDANCE_INS] TO [DB_DMLSupport]
    AS [dbo];

