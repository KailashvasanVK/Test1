﻿ CREATE PROCEDURE [dbo].[ARC_FACILITY_INSERT]  
 @Name VARCHAR(100) = NULL  
 ,@CreatedBy INT = NULL  
 ,@Type TINYINT = NULL  
 ,@ShiftId INT = NULL  
 ,@DriverName VARCHAR(50) = NULL 
 ,@DriverContactNo varchar(50) = null 
AS    
SET NOCOUNT ON    
BEGIN    
DECLARE @Flag AS INT    
SET @Flag=0    
/*Route Master Details Insert*/    
IF @Type=1     
BEGIN     
  IF NOT EXISTS(SELECT '*' FROM ARC_Facility_RouteMaster WHERE Routename=@Name And Status=1 AND ShiftId=@ShiftId)    
  BEGIN    
   INSERT INTO ARC_Facility_RouteMaster(Routename,ShiftId,Status,CreatedBy,CreatedDt)    
   SELECT @Name,@ShiftId,1,@CreatedBy,GETDATE()    
   SET @Flag=1    
  END    
  ELSE    
  BEGIN    
   SET @Flag=2    
  END    
END    
/*Cab Master Details Insert*/    
ELSE IF @Type=2    
BEGIN    
 IF NOT EXISTS(SELECT '*' FROM ARC_Facility_CABMaster WHERE CabNo=@Name AND DriverName=@DriverName And Status=1)    
  BEGIN    
   INSERT INTO ARC_Facility_CABMaster(CabNo,DriverName,DriverContactNo,Status,CreatedBy,CreatedDt)    
   SELECT @Name,@DriverName,@DriverContactNo,1,@CreatedBy,GETDATE()    
   SET @Flag=1    
  END    
  ELSE    
  BEGIN    
   SET @Flag=2    
  END    
END    
/*Driver Master Details Insert*/    
ELSE IF @Type=3    
BEGIN    
 IF NOT EXISTS(SELECT '*' FROM ARC_Facility_DriverMaster WHERE Drivername=@Name And Status=1)    
  BEGIN    
   INSERT INTO ARC_Facility_DriverMaster(Drivername,Status,CreatedBy,CreatedDt)    
   SELECT @Name,1,@CreatedBy,GETDATE()    
   SET @Flag=1    
  END    
  ELSE    
  BEGIN    
   SET @Flag=2    
  END    
END     
SELECT Result=@Flag      
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FACILITY_INSERT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FACILITY_INSERT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FACILITY_INSERT] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FACILITY_INSERT] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FACILITY_INSERT] TO [DB_DMLSupport]
    AS [dbo];

