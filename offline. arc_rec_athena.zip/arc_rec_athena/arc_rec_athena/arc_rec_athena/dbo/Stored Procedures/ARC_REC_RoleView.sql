﻿CREATE procedure [dbo].[ARC_REC_RoleView]        
@RoleId  int = 0,  
@USERID int = 0   
As        
/*        
Purpose    : To get the active (status =1) role name and id to view  using Role id.    
Impact to  : Rolecreation.aspx     
Created by : Karthik IC.        
Created on : 09 April 2013.        
Exec ARC_REC_RoleView         
*/        
Begin     
Select  RoleName,RoleId   from  ARC_REC_Role  ARR  inner join ARC_REC_USER_INFO  ARUI on ARUI.USERID =@USERID 
Where Status = 1  and RoleId = (case when isnull(@RoleId ,0) = 0 then RoleId else @RoleId end) 
and ARR.FUNCTIONALITY_ID = arui.FUNCTIONALITY_ID   
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_RoleView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_RoleView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_RoleView] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_RoleView] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_RoleView] TO [DB_DMLSupport]
    AS [dbo];

