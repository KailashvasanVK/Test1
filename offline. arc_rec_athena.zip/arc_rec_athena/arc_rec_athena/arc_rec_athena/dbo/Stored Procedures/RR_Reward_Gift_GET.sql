﻿CREATE Proc RR_Reward_Gift_GET                
@LLID int                
as               
/*              
RR_Reward_Gift_GET @LLID=1        
*/               
begin                
select ll.LLId,Pid,ProductName,ll.League +' League' League, RewardPath,RewardGiftPath,        
Purchasepoint,AboutProduct,ImageType from RR_Product_Details pd    
inner join RR_LeagueLevel ll on ll.LLId=pd.LLID             
where ll.llid=@LLID and pd.status=1 order by purchasepoint    
               
End        
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Reward_Gift_GET] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Reward_Gift_GET] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Reward_Gift_GET] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Reward_Gift_GET] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Reward_Gift_GET] TO [DB_DMLSupport]
    AS [dbo];

