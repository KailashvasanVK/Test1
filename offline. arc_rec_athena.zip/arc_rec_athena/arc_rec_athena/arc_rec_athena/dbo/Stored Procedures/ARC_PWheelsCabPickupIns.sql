﻿CREATE PROCEDURE ARC_PWheelsCabPickupIns           
 @NAME VARCHAR(50) = '',            
 @EMPCODE VARCHAR(10) = '',            
 @PickupType VARCHAR(50) = '',            
 @PickupPoint VARCHAR(50) = '',            
 @PickupTime VARCHAR(10) = '',       
 @CabNumber VARCHAR(50) = '',      
 @DriverName VARCHAR(50) = '',      
 @DriverNumber VARCHAR(50) = '',          
 @Shift VARCHAR(50) = '',            
 @FileName VARCHAR(75) = '',         
 @USERID int          
AS            
BEGIN           
   INSERT INTO ARC_WheelsCabPickup(NAME,EMPCODE,PickupType,PickupPoint,PickupTime    ,CabNumber ,DriverNumber ,DriverName ,Shift ,FileName , CREATED_BY ,CREATED_DT)          
  VALUES(@NAME,dbo.RemoveWhiteSpace(@EMPCODE),@PickupType,@PickupPoint,@PickupTime    ,@CabNumber ,@DriverNumber ,@DriverName ,@Shift, @FileName ,@USERID ,GETDATE())       
END   

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_PWheelsCabPickupIns] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_PWheelsCabPickupIns] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_PWheelsCabPickupIns] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_PWheelsCabPickupIns] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_PWheelsCabPickupIns] TO [DB_DMLSupport]
    AS [dbo];

