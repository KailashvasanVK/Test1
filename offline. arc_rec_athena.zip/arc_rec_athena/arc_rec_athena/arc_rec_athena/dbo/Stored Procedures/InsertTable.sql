﻿ CREATE PROCEDURE [InsertTable]   @myTableType temporaryUpload readonly  AS   BEGIN   insert into [dbo].temporaryUpload select * from @myTableType    END     
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[InsertTable] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[InsertTable] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[InsertTable] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[InsertTable] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[InsertTable] TO [DB_DMLSupport]
    AS [dbo];

