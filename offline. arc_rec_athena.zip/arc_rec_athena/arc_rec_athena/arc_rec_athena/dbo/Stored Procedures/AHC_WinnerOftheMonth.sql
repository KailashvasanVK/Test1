﻿CREATE procedure AHC_WinnerOftheMonth        
as        
Begin        

select top 1 FBID +'~'+FBName As Winner  
 from FB_WinnerOfTheMonth where Status=1 and WMonth =DATEPART(MONTH,GETDATE()) and WYear =DATEPART(YEAR,GETDATE())   
  
        
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AHC_WinnerOftheMonth] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHC_WinnerOftheMonth] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHC_WinnerOftheMonth] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AHC_WinnerOftheMonth] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHC_WinnerOftheMonth] TO [DB_DMLSupport]
    AS [dbo];

