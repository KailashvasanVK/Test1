﻿CREATE Proc Forum_Employee_birthday                        
as                        
begin                        
          
if not exists (select 'x' from ARC_REC_USER_Info_VY with (nolock)                  
 WHERE DATEPART(MONTH,DOB)=DATEPART(MONTH,GETDATE())          
 AND DATEPART(DAY ,DOB)=DATEPART(DAY,GETDATE())   )          
 Begin                     
select '<b>No Birthdays Today!</b>','',1,'https://arc.accesshealthcare.co/arc_rec/images/userimg.jpg',''                
 end          
 else          
 begin          
 
select Associate Employee,DOB,1 type,
PhotoURL=(case when PROFILE_IMAGE_NAME is null                        
then 'https://arc.accesshealthcare.co/arc_rec/images/userimg.jpg' else                        
'https://arc.accesshealthcare.co/arc_rec/images/candidate/'+PROFILE_IMAGE_NAME end),Client_name Client
 from ARC_REC_USER_Info_VY  with (nolock) where DATEPART(MONTH,DOB)=DATEPART(MONTH,GETDATE())          
 AND DATEPART(DAY ,DOB)=DATEPART(DAY,GETDATE())
                      
end           
end
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Forum_Employee_birthday] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Forum_Employee_birthday] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Forum_Employee_birthday] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Forum_Employee_birthday] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Forum_Employee_birthday] TO [DB_DMLSupport]
    AS [dbo];

