﻿Create proc RR_user_update_score
@userid int,
@score int 
as
begin
update  RR_scoreboard set points=@score where userid =@userid and Scoreid in (select top 1 Scoreid from RR_scoreboard where userid =@userid)
end

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_user_update_score] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_user_update_score] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_user_update_score] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_user_update_score] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_user_update_score] TO [DB_DMLSupport]
    AS [dbo];

