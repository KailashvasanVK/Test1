﻿create proc [dbo].[HD_Athena_GetRoles]
As
Begin
select RoleId,[Role] from HD_Athena_Role
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_GetRoles] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetRoles] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetRoles] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_GetRoles] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetRoles] TO [DB_DMLSupport]
    AS [dbo];

