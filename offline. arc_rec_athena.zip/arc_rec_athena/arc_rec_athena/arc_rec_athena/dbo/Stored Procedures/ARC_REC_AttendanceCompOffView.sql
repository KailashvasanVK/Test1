﻿--ARC_REC_AttendanceCompOffView @FunctionalityID=16,@ClientID='0',@DESIGNATION_ID='0'
CREATE Procedure ARC_REC_AttendanceCompOffView        
 (                    
  @FunctionalityID int = 0                  
 ,@ClientID int = 0          
 ,@DESIGNATION_ID int = 0                 
 ,@SearchStr varchar(100) = ''                                          
 ,@SearchPattern varchar(4) = '=' /** = or % **/             
                                    
)         
 As        
 Begin        
   if OBJECT_ID('tempdb..#AttendanceCompOffView') is not null drop table AttendanceCompOffView         
            
    Declare @sql as varchar(max)         
    set @sql = 'Select        
    ''<input type="checkbox" class="checkinput" id="'' + CONVERT(varchar,ISNULL(UI.USERID,0)) + ''">'' AS checkinput,ui.EMPCODE,               
 ui.FIRSTNAME + '' '' +(case when (select CTL_VALUE  from ARC_REC_SOFTCONTROL Where CTL_ID = ''CANDIDATE_MIDDLENAME'' )= ''y''     then isnull(Ui.MiddleName,'''') else '''' end) + isnull(ui.LASTNAME,'''')as UserName,   
 HRF.FunctionName,cl.Client_Name as Client,HRD.Designation         
 into #AttendanceCompOffView        
 from ARC_REC_USER_INFO ui        
 left Join ARC_FIN_CLIENT_INFO cl on ui.CLIENT_ID = cl.Client_Id        
 left Join ARC_REC_CANDIATE_PROFILE cr on ui.REC_ID = cr.REC_ID        
 left Join HR_Functionality HRF on ui.FUNCTIONALITY_ID = HRF.FunctionalityId        
 left Join HR_Designation HRD on ui.DESIGNATION_ID = HRD.DesigId             
 Where ui.ACTIVE = 1 AND ui.AHS_PRL = ''Y'' and isnull(ui.EMPCODE,'''') <> ''''         
  '                      
  if(@FunctionalityId > 0)                            
  Set @sql = @sql + ' and UI.FUNCTIONALITY_ID ='+convert(varchar,@FunctionalityId)                            
                              
  if(@ClientId > 0)                            
  Set @sql = @sql + ' and UI.CLIENT_ID ='+convert(varchar,@ClientId)                            
                              
  if(@DESIGNATION_ID > 0)                            
  Set @sql = @sql + ' and UI.DESIGNATION_ID ='+convert(varchar,@DESIGNATION_ID)    
  
  
  
  Set @sql = @sql + ' order by ui.EMPCODE '           
                             
 Set @sql = @sql + '          
   Exec FilterTable               
   @DbName = ''tempdb''               
  ,@TblName = ''#AttendanceCompOffView''               
  ,@SearchStr = ''' + @SearchStr + '''        
  ,@SearchPattern = ''' + @SearchPattern + '''        
  ,@OrderStr = ''''               
  If OBJECT_ID(''tempdb..#AttendanceCompOffView'') is not null drop table #AttendanceCompOffView'        
    print @sql                      
 exec(@sql)               
 End   
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_AttendanceCompOffView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AttendanceCompOffView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AttendanceCompOffView] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_AttendanceCompOffView] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AttendanceCompOffView] TO [DB_DMLSupport]
    AS [dbo];

