﻿Create Procedure ARC_Rec_RecruitFormAccessSp
(
@UserId int
)
As
Begin
Select RecForm.FormId,RecForm.FormName,RecForm.FormShortName from ARC_Rec_RecruitFormAccess as FormAcc
inner join ARC_Rec_RecruitForm as RecForm on RecForm.FormId = FormAcc.FormId
Where FormAcc.UserId = @UserId
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Rec_RecruitFormAccessSp] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Rec_RecruitFormAccessSp] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Rec_RecruitFormAccessSp] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Rec_RecruitFormAccessSp] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Rec_RecruitFormAccessSp] TO [DB_DMLSupport]
    AS [dbo];

