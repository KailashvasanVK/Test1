﻿CREATE PROCEDURE [dbo].[S1_HR_ASSESSMENT_INS]            
(              
@AHS_SCHEDULEID INT            
,@AHS_RECID INT            
,@ASSESS_MODE VARCHAR(1)              
,@PRESENTATION VARCHAR(1)              
,@COMMUNICATION VARCHAR(1)              
,@INITIATIVE VARCHAR(1)            
,@SELF_CONFIDENCE VARCHAR(1)            
,@ADAPTABILITY VARCHAR(1)            
,@EXP_QUALITY VARCHAR(1)            
,@TECHNICAL_SKILLS VARCHAR(1)            
,@SUPERVISORY_SKILLS VARCHAR(1)            
,@GROWTH_POTENTIAL VARCHAR(1)            
,@OTHER_SKILLS VARCHAR(1)            
,@OVERALL_PERFORMANCE VARCHAR(1)            
,@REMARKS VARCHAR(MAX)            
,@APPLICANT_STATUS VARCHAR(1)            
,@RESULT VARCHAR(1)            
,@CTC DECIMAL                
,@JOINDATE DATE                
,@JOIN_TIME TIME              
,@JOIN_DAYS INT                
,@CREATED_BY INT            
)            
AS            
BEGIN                 
            
if not exists (select top 1 'x' from ARC_REC_ASSESSMENT where rec_id =@AHS_RECID and ASSESS_MODE='H' )          
Begin          
              
 INSERT INTO ARC_REC_ASSESSMENT            
  (REC_ID,ASSESS_MODE,PRESENTATION,COMMUNICATION,INITIATIVE,SELF_CONFIDENCE,ADAPTABILITY,EXP_QUALITY,              
  TECHNICAL_SKILLS,SUPERVISORY_SKILLS,GROWTH_POTENTIAL,OTHER_SKILLS,OVERALL_PERFORMANCE,REMARKS,              
  APPLICANT_STATUS,CREATED_BY,RESULT,CTC,JOINDATE,JOIN_DAYS,SCHEDULE_ID,JOIN_TIME)              
               
                
 VALUES            
  (@AHS_RECID,@ASSESS_MODE,@PRESENTATION,@COMMUNICATION,@INITIATIVE,@SELF_CONFIDENCE,@ADAPTABILITY,@EXP_QUALITY,              
  @TECHNICAL_SKILLS,@SUPERVISORY_SKILLS,@GROWTH_POTENTIAL,@OTHER_SKILLS,@OVERALL_PERFORMANCE,@REMARKS,              
  @APPLICANT_STATUS,1666,@RESULT,@CTC,@JOINDATE,@JOIN_DAYS,@AHS_SCHEDULEID,@JOIN_TIME)            
          
End            
            
                
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[S1_HR_ASSESSMENT_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[S1_HR_ASSESSMENT_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[S1_HR_ASSESSMENT_INS] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[S1_HR_ASSESSMENT_INS] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[S1_HR_ASSESSMENT_INS] TO [DB_DMLSupport]
    AS [dbo];

