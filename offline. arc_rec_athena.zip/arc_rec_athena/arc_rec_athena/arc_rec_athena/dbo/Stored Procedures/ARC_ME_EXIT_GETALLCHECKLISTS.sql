﻿
CREATE procedure ARC_ME_EXIT_GETALLCHECKLISTS      
      @EMPCODE VARCHAR(50)      
AS      
BEGIN      
select ct.CHK_ID,i.FUNCTIONALITY_ID,      
case when i.FUNCTIONALITY_ID = 5 then 'Finance checklist'       
  when i.FUNCTIONALITY_ID = 6 then 'HR checklist'       
  when i.FUNCTIONALITY_ID = 8 then 'Network checklist'       
  when i.FUNCTIONALITY_ID = 9 then 'Admin checklist'     
  else 'Op checklist' end as Chk_type,      
  i.CHK_TEXT,       
ct.CHK_REMARK,ui.FIRSTNAME+' '+ui.LASTNAME as CREATED_BY from ARC_ME_EXIT_CHECKLIST_TRAN ct      
inner join ARC_ME_EXIT_CHECKLIST_INFO I on ct.CHK_ID = i.CHK_ID      
inner join ARC_REC_USER_INFO UI on ct.CREATED_BY = UI.USERID      
where REG_ID = (select REG_ID FROM ARC_ME_EXIT where EMPCODE = @EMPCODE and ACTIVE = 'Y')      
END
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_EXIT_GETALLCHECKLISTS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_EXIT_GETALLCHECKLISTS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_EXIT_GETALLCHECKLISTS] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_EXIT_GETALLCHECKLISTS] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_EXIT_GETALLCHECKLISTS] TO [DB_DMLSupport]
    AS [dbo];

