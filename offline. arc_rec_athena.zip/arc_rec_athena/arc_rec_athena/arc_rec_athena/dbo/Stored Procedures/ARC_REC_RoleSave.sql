﻿CREATE Procedure ARC_REC_RoleSave
@ApplicationId int,
@Status int = 1 ,
@CREATED_BY  int ,
@RoleName varchar(50),
@RoleId int = 0 
As
/*
To Save the Role Details into Db
*/
Begin
if Exists( Select RoleId from ARC_REC_Role   where RoleId = @RoleId  ) and  @RoleId <>0
Begin
	Insert into ARC_REC_RoleLog (RoleName,CREATED_BY,Status,ModuleMenuId,FUNCTIONALITY_ID,RoleId,CREATED_DT,DefaultRole)
	Select RoleName,CREATED_BY,Status,ModuleMenuId,FUNCTIONALITY_ID,RoleId,CREATED_DT,DefaultRole from ARC_REC_Role Where RoleId = @RoleId	
	update ARC_REC_Role set RoleName=@RoleName,CREATED_BY =@CREATED_BY,CREATED_DT=getDate(),Status=@Status,ModuleMenuId =@ApplicationId Where RoleId = @RoleId	
End
Else If @RoleId  = 0
Begin
	Insert into ARC_REC_Role   (RoleName,CREATED_BY,Status,ModuleMenuId,FUNCTIONALITY_ID)
	Select @RoleName,@CREATED_BY,@Status,@ApplicationId,1
	SELECT @RoleId = SCOPE_IDENTITY()
	-- Default to set full rights for user's created role
	Insert into ARC_REC_UserRole ( UserId,RoleId,CREATED_BY,FUNCTIONALITY_ID,AccessLevel)
	Select @CREATED_BY ,@RoleId, @CREATED_BY,0,'F'	
End
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_RoleSave] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_RoleSave] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_RoleSave] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_RoleSave] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_RoleSave] TO [DB_DMLSupport]
    AS [dbo];

