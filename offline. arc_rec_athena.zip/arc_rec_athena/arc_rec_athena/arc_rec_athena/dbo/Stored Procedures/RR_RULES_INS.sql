﻿create Proc RR_RULES_INS        
(        
@RULES VARCHAR(1000),        
@STATUS TINYINT=1,        
@CREATEDBY int,    
@ERROR varchar(100) out     
)        
as          
/*        
RR_RULES_INS @RULES='test6',@STATUS=1,@CREATEDBY=807        
*/        
begin        
SET NOCOUNT ON; -- SET NOCOUNT ON added to prevent extra result sets from    
-- interfering with SELECT statements.    
IF NOT EXISTS(SELECT * FROM RR_Rules WHERE Rules=@RULES)    
BEGIN    
INSERT INTO RR_Rules(Rules,Status,CreatedBy,CreatedOn) VALUES(@RULES,@STATUS,@CREATEDBY,GETDATE())       
SET @ERROR='Rules Added Successfully'    
End    
ELSE    
BEGIN    
SET @ERROR='Rules Already Exists!'    
END     
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_RULES_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_RULES_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_RULES_INS] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_RULES_INS] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_RULES_INS] TO [DB_DMLSupport]
    AS [dbo];

