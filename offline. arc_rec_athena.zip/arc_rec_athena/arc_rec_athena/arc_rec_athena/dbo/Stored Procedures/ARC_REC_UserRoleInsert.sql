﻿CREATE procedure [dbo].[ARC_REC_UserRoleInsert]    
@UserId int    
,@RoleId int    
,@CREATED_BY int
As    
/*                  
Purpose    : To move the existing role into log table and assign the user role.    
Impact to  : RoleTranConfig.aspx    
Created by : Karthik Ic    
Created on : 16 april 2013    
*/    
Begin    
declare @FUNCTIONALITY_ID int 
set @FUNCTIONALITY_ID  = (Select FUNCTIONALITY_ID from ARC_REC_USER_INFO Where userid =@CREATED_BY )
if exists( Select top 1 'x' from ARC_REC_UserRole  Where UserId = @UserId and FUNCTIONALITY_ID= @FUNCTIONALITY_ID  )
Begin
print 'update'
Insert into ARC_REC_UserRoleLog (UserId,RoleId,CREATED_BY,CREATED_DT,FUNCTIONALITY_ID)
Select UserId,RoleId,CREATED_BY,CREATED_DT,FUNCTIONALITY_ID from ARC_REC_UserRole
Where UserId = @UserId and FUNCTIONALITY_ID= @FUNCTIONALITY_ID
Update ARC_REC_UserRole  set RoleId = @RoleId,CREATED_BY = @CREATED_BY,CREATED_DT = GETDATE()
Where UserId =@UserId and FUNCTIONALITY_ID = @FUNCTIONALITY_ID    
End  
Else    
Begin    
print 'insert'
Insert into ARC_REC_UserRole (UserId,RoleId,CREATED_BY,FUNCTIONALITY_ID)    
Select @UserId,@RoleId,@CREATED_BY,@FUNCTIONALITY_ID    
End    
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_UserRoleInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UserRoleInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UserRoleInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_UserRoleInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UserRoleInsert] TO [DB_DMLSupport]
    AS [dbo];

