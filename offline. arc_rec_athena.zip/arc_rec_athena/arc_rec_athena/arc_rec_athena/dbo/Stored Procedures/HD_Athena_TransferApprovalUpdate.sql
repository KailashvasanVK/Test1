﻿CREATE PROCEDURE [dbo].[HD_Athena_TransferApprovalUpdate]
  @ReqId INT  
 ,@CreatedBy INT  
 ,@Status int  
 ,@TransferId VARCHAR(MAX) = ''
AS
BEGIN
   
   if(@Status = 1)
    begin
		update HD_Athena_Transfer set [Status] = @Status where ReqId = @ReqId and
		 TransferId in (SELECT items FROM fnSplitString(@TransferId,','))
		
	    update HD_Athena_Transfer set [Status] = 2 where ReqId = @ReqId and [Status] = 0
	    and TransferId not in (SELECT items FROM fnSplitString(@TransferId,','))
	    
    end
END

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_TransferApprovalUpdate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_TransferApprovalUpdate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_TransferApprovalUpdate] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_TransferApprovalUpdate] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_TransferApprovalUpdate] TO [DB_DMLSupport]
    AS [dbo];

