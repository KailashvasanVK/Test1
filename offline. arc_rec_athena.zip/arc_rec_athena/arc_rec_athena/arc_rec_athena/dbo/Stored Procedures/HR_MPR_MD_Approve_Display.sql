﻿CREATE Procedure dbo.HR_MPR_MD_Approve_Display(@Mprid int)              
as             
/*          
  Created By : Udhayaganesh.p      
  Created On : 27 th Aug 2013      
        
  HR_MPR_MD_Approve_Display 333      
        
        
       
 */          
 Begin        
            
SELECT              
 convert(varchar(25), mpr.CreatedDate, 107) as 'Raisedon',             
convert(varchar(25), mpr.ExpDate, 107) as [ExpectedDate],        
 um.UserName,             
 tm.TrainingCentre,             
 f.FunctionName,             
 d.Designation,             
'Rs.' + dbo.RupeeFormat_Rounded(cast(mpr.SalaryMin as varchar)) as [Salmin],          
'Rs.' + dbo.RupeeFormat_Rounded(cast(mpr.SalaryMax as varchar)) as [SalMax],       
UMA.UserName MDApproved,convert(varchar(25),mpr.MDApprovedDate, 107) as 'MDApprovedon',      
         
 mpr.* FROM               
HR_MPR mpr INNER JOIN HR_functionality f on f.FunctionalityId = mpr.FunctionalityId              
INNER JOIN HR_designation d on d.desigId = mpr.desigID              
INNER JOIN TM_TrainingCentreMaster tm on tm.Tcid = mpr.Tcid              
INNER JOIN mis_user_master um on um.UserId = mpr.CreatedBy      
left join MIS_User_Master UMA on UMA.UserId =mpr.MDApprovedBy               
where mpr.MPRId = @MPRId          
      
end
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_MPR_MD_Approve_Display] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_MD_Approve_Display] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_MD_Approve_Display] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_MPR_MD_Approve_Display] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_MD_Approve_Display] TO [DB_DMLSupport]
    AS [dbo];

