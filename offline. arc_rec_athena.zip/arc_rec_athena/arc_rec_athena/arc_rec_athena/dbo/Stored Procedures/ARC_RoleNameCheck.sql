﻿CREATE procedure ARC_RoleNameCheck  
@UserId  int ,  
@RoleName varchar(50),
@RoleId varchar(50)    
as  
/*  
Purpose    : To check the user role already existing or not  
Impact to  : RoleCreation.aspx  
Created by : Karthik Ic  
Created on : 15 april 2013  
ARC_RoleNameCheck   @RoleId =27 ,@RoleName ='admin',@UserId  = 19
*/  
Begin  
If exists (Select top 1 'x'   from  ARC_REC_Role Where RoleName = @RoleName and  FUNCTIONALITY_ID = (select FUNCTIONALITY_ID from ARC_REC_USER_INFO  where USERID =@UserId))  
Begin   
If exists (Select top 1 'x'   from  ARC_REC_Role  ARR  Where RoleName = @RoleName and RoleId = @RoleId )  
Select 0 as Result   -- not existing 
Else
Select 1 as Result  -- already existing 
End   
Else
Select 0 as Result -- not existing 
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_RoleNameCheck] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_RoleNameCheck] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_RoleNameCheck] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_RoleNameCheck] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_RoleNameCheck] TO [DB_DMLSupport]
    AS [dbo];

