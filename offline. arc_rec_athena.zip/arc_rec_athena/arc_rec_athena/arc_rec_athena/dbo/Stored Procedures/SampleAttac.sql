﻿Create Proc SampleAttac
as
EXEC msdb.dbo.sp_send_dbmail                                                                                                                    
@profile_name = 'Newsdesk',                                                                                                                                  
@recipients = 'udhayaganesh.p@laurusedutech.com',          
@blind_copy_recipients ='udhayaganesh.p@laurusedutech.com',                                                                                                          
@subject='test',                                                                                                                                                                                
@body = 'test',                                                            
@body_format  = 'HTML',  
@file_attachments ='\\172.19.5.3\ARC_forum\Attachement\a.txt'  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[SampleAttac] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SampleAttac] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SampleAttac] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[SampleAttac] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SampleAttac] TO [DB_DMLSupport]
    AS [dbo];

