﻿CREATE Proc ARC_REC_Document_Acknowledge_Popup          
@userid int=0   
/*
Created By : Udhayaganesh.p
Purpose    : Get the un acknowledge Document List for Respective Associate
*/         
As                    
Begin            
select ld.DocID,DocumentName,PathName,Publish, CONVERT(varchar(19),createdon) CreatedOn,                      
UI.FIRSTNAME+''+UI.Lastname CreatedBy,Status,NT_Username,UI.Userid,ld.publish [Type]                     
from ARC_REC_LegalDocument LD                      
inner join ARC_REC_USER_INFO UI on UI.Userid=LD.createdby                    
where Ld.DocID not in (select DocID from  ARC_REC_Document_Acknowledge where AcknowledgeBy=@userid)             
and Ld.publish=1 and ld.status=1 Order By createdon desc                    
end 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_Document_Acknowledge_Popup] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Document_Acknowledge_Popup] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Document_Acknowledge_Popup] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_Document_Acknowledge_Popup] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Document_Acknowledge_Popup] TO [DB_DMLSupport]
    AS [dbo];

