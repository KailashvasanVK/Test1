﻿CREATE PROCEDURE [dbo].[HR_GetModulesAndForms]        
@ApplicationId as INT,        
@UserId as INT        
    
AS        
        
BEGIN        
        
      
      
 SELECT distinct am.ModuleId, am.Module, isnull(am.ImagePath, 'empty') as [Image]         
 , case when @ApplicationId=1 then isnull(am.ordval_Assessment, 1000)        
 when @ApplicationId=2 then isnull(am.ordval_CentralAdmin, 1000)        
 when @ApplicationId=3 then isnull(am.ordval_Training, 1000)        
 end        
 FROM MAP_Userroles ur        
 INNER JOIN MAP_Accessprivileges ap on ap.PrivilegeType = ur.PrivilegeType and ap.PrivilegeRole = ur.PrivilegeRole and ap.ApplicationId = ur.ApplicationId        
 INNER JOIN MAP_ApplicationForms af on af.FormCode = ap.FormCode and ap.ApplicationId = af.ApplicationId        
 INNER JOIN MAP_ApplicationModule am on am.ModuleId = af.ModuleId         
 AND af.ApplicationId = @ApplicationId        
 AND ur.userid=@UserId AND af.Status = 1        
 Where af.Menudisplay = 1  and ap.status = 1    
 ORDER BY         
 case when @ApplicationId=1 then isnull(am.ordval_Assessment, 1000)        
 when @ApplicationId=2 then isnull(am.ordval_CentralAdmin, 1000)        
 when @ApplicationId=3 then isnull(am.ordval_Training, 1000)        
 end        
      
      
 SELECT         
 ROW_NUMBER() OVER (ORDER BY am.ModuleId, af.Ordval) AS [Slno],        
 am.ModuleId as [ModId], am.Module as [ModName],         
 af.FormCode as [FC],        
 af.FormName as [FName],        
 af.TabDisplayName as [TabName],        
 af.PageURL as [URL],        
 af.PageDescription as [Desc],        
 af.Ordval        
      
 FROM MAP_Userroles ur         
 INNER JOIN MAP_Accessprivileges ap on ap.PrivilegeType = ur.PrivilegeType and ap.PrivilegeRole = ur.PrivilegeRole and ap.ApplicationId = ur.ApplicationId        
 INNER JOIN MAP_ApplicationForms af on af.FormCode = ap.FormCode and ap.ApplicationId = af.ApplicationId        
 INNER JOIN MAP_ApplicationModule am on am.ModuleId = af.ModuleId         
 AND af.ApplicationId = @ApplicationId        
 AND ur.userid=@UserId AND af.Status = 1        
 Where af.Menudisplay = 1  and ap.status = 1    
 ORDER BY am.ModuleId, af.Ordval        
      
        
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_GetModulesAndForms] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_GetModulesAndForms] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_GetModulesAndForms] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_GetModulesAndForms] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_GetModulesAndForms] TO [DB_DMLSupport]
    AS [dbo];

