﻿create proc [dbo].[HD_Athena_GetDepartment]
As
Begin
select Department,DeptId from HD_Athena_Department
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_GetDepartment] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetDepartment] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetDepartment] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_GetDepartment] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetDepartment] TO [DB_DMLSupport]
    AS [dbo];

