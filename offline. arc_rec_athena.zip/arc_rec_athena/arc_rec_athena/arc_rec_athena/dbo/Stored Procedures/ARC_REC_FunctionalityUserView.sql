﻿CREATE procedure [dbo].[ARC_REC_FunctionalityUserView]   
@FUNCTIONALITY_ID int  = 0,                 
@USERID int                 
As    
/*   
            
 Purpose    : To get all user details based on functionality Id   
 Created by : Karthik Ic   
 Created on : 04 april 2013   
 Impact to  : RoleTranConfig.aspx          
 Exec ARC_REC_FunctionalityUserView 3,10        
 Exec ARC_REC_FunctionalityUserView 0,19  
 Note : FunctionalityId :- 8 : FunctionName :- Shared Services - Information Technology  
*/   
Begin         
---- To get the user name,userid, empCode and functionallity  for particular user functionality... ----         
Select USERID,FIRSTNAME + ' ' + LASTNAME as Name,ARUI.EMPCODE as EMPCODE ,HRF.FunctionName  as FunctionName        
from  arc_rec_user_info       ARUI      inner join        
HR_Functionality  HRF on HRF.FunctionalityId   = ARUI.FUNCTIONALITY_ID  
Where   
ARUI.FUNCTIONALITY_ID <> 8 and    
 --ARUI.FUNCTIONALITY_ID = (select top 1 FUNCTIONALITY_ID  from arc_rec_user_info     where USERID  =   @USERID)   and   
 ARUI.USERID not in (@USERID) and ARUI.ACTIVE = 1 and ARUI.AHS_PRL = 'Y'     
order by HRF.FunctionalityId    
End  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_FunctionalityUserView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_FunctionalityUserView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_FunctionalityUserView] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_FunctionalityUserView] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_FunctionalityUserView] TO [DB_DMLSupport]
    AS [dbo];

