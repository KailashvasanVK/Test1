﻿       
             
CREATE PROCEDURE [DBO].[ARC_KIN_QUERIES_INFO]                
@ACTION VARCHAR(50) = NULL                
AS                
                
BEGIN                
 SELECT Row_Number() Over ( Order By KQ.QID ) As SNo, KQ.QID,KQ.QUERY,RUI.NT_USERNAME,CONVERT(varchar(10),KQ.CREATEDDT,101) as CREATEDDT              
 ,KAI.ROOTCAUSE,KAI.ACTIONITEM,HF.JobTitle    
 FROM ARC_KIN_QUERIES KQ              
 INNER JOIN ARC_REC_USER_INFO RUI ON RUI.USERID=KQ.CREATEDBY    
 LEFT JOIN   ARC_KIN_ACTION_ITEMS KAI ON KAI.QID=KQ.QID   
 INNER JOIN HR_Functionality HF ON HF.FunctionalityId=RUI.FUNCTIONALITY_ID           
 WHERE KQ.STATUS=1          
 ORDER BY QID ASC                
                 
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_KIN_QUERIES_INFO] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_KIN_QUERIES_INFO] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_KIN_QUERIES_INFO] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_KIN_QUERIES_INFO] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_KIN_QUERIES_INFO] TO [DB_DMLSupport]
    AS [dbo];

