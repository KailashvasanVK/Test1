﻿CREATE Proc [dbo].[RR_UserScorestatusBar_Get]        
@userid int=1        
as        
begin      
      
select UB.LLId,Convert(varchar(10),SDpoint) +'/'+Convert(varchar(10),ll.EndPpoint) As TotalScroll ,ub.league,
Percentage=(case when sdpoint =0 then 0 else     
cast((SDpoint*1.0/EndPpoint)*100 as numeric(18,2)) end) ,sdpoint   
from  RR_UserBanner  UB     
inner join RR_leaguelevel LL on UB.LLId=ll.LLId    
where userid=@userid        
        
       
         
end  

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_UserScorestatusBar_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_UserScorestatusBar_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_UserScorestatusBar_Get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_UserScorestatusBar_Get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_UserScorestatusBar_Get] TO [DB_DMLSupport]
    AS [dbo];

