﻿CREATE proc ARC_ME_ELSettlement    
     @EmpCode varchar(50),    
     @DateOfCredit date,    
     @CreatedBy int    
As    
Begin    
declare @UserId as int    
select @UserId = USERID from ARC_REC_USER_INFO where EMPCODE = @EmpCode    
if(select count(UserId) from ARC_REC_LEAVES_EL_Settled where UserId = @UserId and datepart(year,DateOfCredit) = datepart(year,@DateOfCredit)) = 0  
begin  
insert into ARC_REC_LEAVES_EL_Settled(UserId,DateOfCredit,CreatedBy,CreatedDt)    
select @UserId,@DateOfCredit,@CreatedBy,GETDATE()    
end  
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_ELSettlement] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_ELSettlement] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_ELSettlement] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_ELSettlement] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_ELSettlement] TO [DB_DMLSupport]
    AS [dbo];

