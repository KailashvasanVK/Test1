﻿CREATE PROCEDURE ARC_Lounge_Comments_Artical_Get                                
@MsgId INT=0,        
@Ntusername nvarchar(100)=null                               
AS                                     
/*                                  
exec ARC_Lounge_Comments_Artical_Get @MsgId=25         
      
select * from ARc_forum_lounge_messages where msgid=25        
      
select * from ARC_Forum_MessageBoard where msgid=25         
                      
*/                                   
BEGIN                   
                                  
  select LM.ID'MsgId',MB.MsgId'Artid',Headline,MessageText,coverPhotoId,PhotoName,PhototPath,                            
  CONVERT(VARCHAR(12),mb.CreatedOn,107) CreatedOn,mb.AlbumId ,isnull(Extension,'null') as Extension,                
  TagAssociate= (SELECT STUFF(( select distinct                                          
  ','+ convert(varchar(100), CI.FIRSTNAME+' '+ci.LASTNAME )          
  from  ARC_REC_USER_Info CI                                                             
  INNER JOIN ARC_REC_CANDIDATE C ON C.REC_ID = CI.REC_ID                                           
  inner join ARC_Forum_MessageBoard_Taggedusers ML  on  Ml.msgid =mb.msgid                     
  WHERE ml.NT_userid =CI.NT_USERNAME   FOR XML PATH('')), 1, 1, '')),          
  (select count(ml.MsgId) from ARC_Forum_Lounge_Message_Likes_VY ml where ml.MsgId=LM.ID and ml.status=1)'LikeCount',                  
 (select COUNT(mc.MsgId) from ARC_Forum_Lounge_Message_Comments_VY mc where mc.MsgId=LM.ID and mc.Status=1) 'CommentCount',          
  LM.ID,        
  Likes=isnull((select count(distinct MsgId) from ARC_Forum_Lounge_Message_Likes mll
   where mll.MsgId=LM.ID and LikedBy=@Ntusername and mll.status=1),0)                              
  from ARC_Forum_MessageBoard mb           
  left join ARC_Forum_Lounge_Messages LM on LM.MsgId=mb.MsgId                    
  left join ARC_Forum_Album_Gallery pg on pg.PhotoId=mb.CoverPhotoId                          
  where mb.MsgId =@MsgId AND mb.Status=1                        
          
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Comments_Artical_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Comments_Artical_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Comments_Artical_Get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Comments_Artical_Get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Comments_Artical_Get] TO [DB_DMLSupport]
    AS [dbo];

