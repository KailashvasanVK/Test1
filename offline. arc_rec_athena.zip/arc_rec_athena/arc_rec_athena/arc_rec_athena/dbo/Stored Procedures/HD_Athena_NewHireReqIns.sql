﻿CREATE  procedure [dbo].[HD_Athena_NewHireReqIns]          
      @ReqId int,          
      @UserId int,          
      @DeptId int,          
      @RoleId int,  
      @HasCitrixReq char(1),                
      @CreatedBy int                      
AS          
Begin          
insert into HD_AthenaUsers(Issue_ReqId,UserId,DeptId,RoleId,HasCitrixReq,Status,CreatedBy,CreatedDt)    
select @ReqId,@UserId,@DeptId,@RoleId,@HasCitrixReq,0,@CreatedBy,GETDATE()          
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_NewHireReqIns] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_NewHireReqIns] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_NewHireReqIns] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_NewHireReqIns] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_NewHireReqIns] TO [DB_DMLSupport]
    AS [dbo];

