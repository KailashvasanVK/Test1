﻿CREATE procedure [dbo].[ARC_REC_SupervisorCustomers]          
       @SUPERVISOR_ID INT                
as                
begin         
select ui.CustomerID as CLIENT_ID,cl.CLIENT_NAME  from ARC_REC_UserCustomer ui               
inner join ARC_REC_CustomerView cl on ui.CustomerID = cl.CLIENT_ID              
where ui.USERID = @SUPERVISOR_ID order by ui.UCid             
end 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_SupervisorCustomers] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_SupervisorCustomers] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_SupervisorCustomers] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_SupervisorCustomers] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_SupervisorCustomers] TO [DB_DMLSupport]
    AS [dbo];

