﻿CREATE procedure ARC_REC_SubmitInduction              
 @REC_IDS varchar(Max),                     
 @SUPERVISOR_ID INT,                     
 @CUSTOMER_ID INT,                     
 @CREATED_BY INT,                     
 @SHIFT_ID INT,                      
 @TRIANEE char(1),                     
 @EMAIL_ACCESSID INT,                     
 @FOLDER_ACCESSID INT,                     
 @DISTRIBUTION_ACCESSID INT,                     
 @INDUCTION_TAKEN BIT=0,                      
 @FunctionalityId int,                      
 @DesignationId int,              
 @FacilityId int,                      
 @DOJ date=''               
               
As                     
Begin                     
Declare @Reporting varchar(200)                     
declare @ind_count int                     
select @Reporting = NT_USERNAME from ARC_REC_USER_INFO where USERID = @SUPERVISOR_ID                     
if OBJECT_ID('tempdb..#IndexAssociates') is not null drop table #IndexAssociates                         
create table #IndexAssociates(REC_ID int,USERID Int,EMPCODE VARCHAR(100))                    
Insert into #IndexAssociates(REC_ID)                     
Select distinct(items) from dbo.fnSplitString(@REC_IDS,',') 

delete from #IndexAssociates where REC_ID not in (select REC_ID from ARC_REC_USER_INFO)
                    
update #IndexAssociates set                    
USERID = ui.USERID                    
from #IndexAssociates ia                    
inner join ARC_REC_USER_INFO ui on ia.REC_ID = ui.REC_ID                     
                     
insert into ARC_REC_Superviosrlog(UserId,SupervisorId,CreatedBy,CreatedDt,ModifiedBy,ModifiedDt)                     
select ia.USERID,uir.USERID,ui.CREATED_BY,ui.CREATED_DT,@CREATED_BY,GETDATE()   
from ARC_REC_USER_INFO ui                     
inner join #IndexAssociates ia on ui.USERID = ia.USERID                        
inner join ARC_REC_USER_INFO uir on ui.REPORTING_TO = uir.NT_USERNAME                       
                      
--insert into ARC_REC_Superviosrlog(UserId,SupervisorId,CreatedBy,CreatedDt)                     
--select USERID,@SUPERVISOR_ID,@CREATED_BY,GETDATE() from #IndexAssociates                      
                         
                     
insert into ARC_REC_SHIFT_TRAN(USERID,SHIFT_ID,Effect_DATE,CREATED_BY,CREATED_DT)                     
select USERID,@SHIFT_ID,GETDATE(),@CREATED_BY,GETDATE() from #IndexAssociates                  
                      
insert into ARC_REC_UserCustomerLog(UCid,UserId,CustomerID,CREATED_BY,CREATED_DT)                      
select UCid,UserId,CustomerID,CREATED_BY,CREATED_DT from ARC_REC_UserCustomer where UserId in (select USERID from #IndexAssociates)                        
                        
delete from ARC_REC_UserCustomer where UserId in (select USERID from #IndexAssociates)                        
                      
insert into ARC_REC_UserCustomer(UserId,CustomerId,CREATED_BY,CREATED_DT)                      
select USERID,@CUSTOMER_ID,@CREATED_BY,GETDATE() from #IndexAssociates                     
                        
Insert into ARC_REC_FunctionalityLog(USERID,FUNCTIONALITY_ID,CREATED_BY,CREATED_DT)                      
Select ui.Userid,ui.FUNCTIONALITY_ID,ui.CREATED_BY,ui.CREATED_DT                       
from ARC_REC_USER_INFO as ui                      
inner join #IndexAssociates as indAsso on indAsso.USERID = ui.USERID                      
Where ui.FUNCTIONALITY_ID <> @FunctionalityId                      
                      
Insert into ARC_REC_Designationlog(Userid,DesignationId,CreatedBy,CreatedDt,IsPromoted)                      
Select ui.Userid,ui.DESIGNATION_ID,ui.CREATED_BY,ui.CREATED_DT,'N'                      
from ARC_REC_USER_INFO as ui                      
inner join #IndexAssociates as indAsso on indAsso.USERID = ui.USERID                      
Where ui.DESIGNATION_ID <> @DesignationId                      
                      
                        
update ARC_REC_USER_INFO set                    
REPORTING_TO = @Reporting,                    
CLIENT_ID = @CUSTOMER_ID, --later on insert into UserCustomer                    
LastCustomerId = @CUSTOMER_ID, --later on insert into UserCustomer                    
FUNCTIONALITY_ID  = @FunctionalityId,           
DESIGNATION_ID = @DesignationId                    
where USERID in (select USERID from #IndexAssociates)                         
                     
DECLARE @USERID INT                     
Declare @Temp_Id int                     
--SELECT @Temp_Id =  ISNULL(COUNT(*),0) + 1 from ARC_REC_USER_INFO where ISNULL(empcode,'') <> ''                        
Declare @tempPrefix varchar(10) = isnull((Select CTL_VALUE from ARC_REC_SOFTCONTROL where CTL_ID = 'EmpCodePrefix'),'') + (Select Prefix from Arc_Rec_EmpCodePrefix Where [YEAR] = DATEPART(YYYY,getdate())) + REPLICATE('0',2-LEN(DATEPART(M,GETDATE()))) +   
 
                        
convert(varchar,DATEPART(M,GETDATE()))              
                        
select @Temp_Id = Isnull(Max(Convert(int,SUBSTRING(EMPCODE,LEN(@tempPrefix)+1,20))),0) + 1 from ARC_REC_USER_INFO                        
where ISNULL(AHS_PRL,'') = 'Y' and  ISNULL(empcode,'') <> ''            
                     
DECLARE @REC_ID AS INT                     
DECLARE EMP_CURSOR CURSOR FOR                    
                    
Select USERID,REC_ID from #IndexAssociates FOR UPDATE OF EMPCODE                     
OPEN EMP_CURSOR                     
FETCH NEXT FROM EMP_CURSOR INTO @USERID,@REC_ID                     
WHILE @@FETCH_STATUS = 0                     
 BEGIN                     
 while 1=1                     
  begin                     
  Declare @len int                     
  declare @EMPCODE as varchar(50)                     
                  
  Select @len = case when LEN(@Temp_Id) <= 3 then 3 else LEN(@Temp_Id) end                     
  --set @EMPCODE = case when DATEPART(YYYY,GETDATE()) = 2013 then 'D' else 'E' end + REPLICATE('0',2-LEN(DATEPART(M,GETDATE()))) +  convert(varchar,DATEPART(M,GETDATE())) + REPLICATE('0',@len-LEN(@Temp_Id)) + convert(varchar,@Temp_Id)                     
                  
  set @EMPCODE = isnull((Select CTL_VALUE from ARC_REC_SOFTCONTROL where CTL_ID = 'EmpCodePrefix'),'') +           
  (Select Prefix from Arc_Rec_EmpCodePrefix Where [YEAR] = DATEPART(YYYY,getdate())) + REPLICATE('0',2-LEN(DATEPART(M,GETDATE()))) +  convert(varchar,DATEPART(M,GETDATE())) + REPLICATE('0',@len-LEN(@Temp_Id)) + convert(varchar,@Temp_Id)              
  if ((select COUNT(*) from ARC_REC_USER_INFO Where EMPCODE = @EMPCODE) > 0 or (select COUNT(*) from #IndexAssociates where EMPCODE = @EMPCODE) > 0)                    
  begin    
   --Set @Temp_Id += 1         
       
   select @Temp_Id = Isnull(Max(Convert(int,SUBSTRING(EMPCODE,LEN(@tempPrefix)+1,20))),0) + 1 from ARC_REC_USER_INFO                        
   where ISNULL(AHS_PRL,'') = 'Y' and  ISNULL(empcode,'') <> ''      
       
   set @EMPCODE = isnull((Select CTL_VALUE from ARC_REC_SOFTCONTROL where CTL_ID = 'EmpCodePrefix'),'') +           
   (Select Prefix from Arc_Rec_EmpCodePrefix Where [YEAR] = DATEPART(YYYY,getdate())) + REPLICATE('0',2-LEN(DATEPART(M,GETDATE()))) +  convert(varchar,DATEPART(M,GETDATE())) + REPLICATE('0',@len-LEN(@Temp_Id)) + convert(varchar,@Temp_Id)                  
               
   update #IndexAssociates set EMPCODE = @EMPCODE                     
   where USERID = @USERID and REC_ID = @REC_ID       
    
   update ARC_REC_USER_INFO set                     
   EMPCODE = @EMPCODE,ACTIVE = 1,DOJ =@DOJ      
   where USERID = @USERID and REC_ID = @REC_ID                       
       
   select @Temp_Id = Isnull(Max(Convert(int,SUBSTRING(EMPCODE,LEN(@tempPrefix)+1,20))),0) + 1 from ARC_REC_USER_INFO                        
   where ISNULL(AHS_PRL,'') = 'Y' and  ISNULL(empcode,'') <> ''      
       
   end    
    
  Else                     
   begin        
                    
   update #IndexAssociates set EMPCODE = @EMPCODE                     
   where USERID = @USERID and REC_ID = @REC_ID       
    
   update ARC_REC_USER_INFO set                     
   EMPCODE = @EMPCODE,ACTIVE = 1,DOJ =@DOJ      
   where USERID = @USERID and REC_ID = @REC_ID                       
    
   --Set @Temp_Id += 1       
       
       
   select @Temp_Id = Isnull(Max(Convert(int,SUBSTRING(EMPCODE,LEN(@tempPrefix)+1,20))),0) + 1 from ARC_REC_USER_INFO                  
   where ISNULL(AHS_PRL,'') = 'Y' and  ISNULL(empcode,'') <> ''      
                  
   Break                     
   end                     
  end                     
 FETCH NEXT FROM EMP_CURSOR INTO @USERID,@REC_ID                     
 END                     
CLOSE EMP_CURSOR                     
DEALLOCATE EMP_CURSOR                       
                      
              
-- update ARC_REC_USER_INFO set                     
--EMPCODE = id.EMPCODE,ACTIVE = 1,DOJ =@DOJ                      
--from ARC_REC_USER_INFO ui                     
--join #IndexAssociates id on ui.USERID = id.USERID and ui.REC_ID = id.REC_ID              
                     
DECLARE @BODY AS VARCHAR(MAX)                     
select @ind_count= isnull(count(*),0) from #IndexAssociates                     
                  
declare @CommentsText varchar(max)                  
declare @ProximityCommentsText varchar(max)           
          
DECLARE @AssociatesString AS varchar(max)=''                 
declare @AssociateEmpCode as varchar(100)              
declare @AssName as varchar(max)=''           
DECLARE Ass_Cursor CURSOR FOR              
Select USERID,EMPCODE from #IndexAssociates                     
OPEN Ass_Cursor                     
FETCH NEXT FROM Ass_Cursor INTO @USERID,@AssociateEmpCode                     
WHILE @@FETCH_STATUS = 0                     
 BEGIN                     
 while 1=1                     
  begin                     
                  
   select @AssName = FIRSTNAME+' '+LASTNAME+' ( '+EMPCODE+' ) ' from ARC_REC_USER_INFO where USERID= @USERID and EMPCODE = @AssociateEmpCode        
   set @AssociatesString = @AssociatesString + @AssName + ','         
   Break                     
   end                     
                   
 FETCH NEXT FROM Ass_Cursor INTO @USERID,@AssociateEmpCode                     
 END                   
CLOSE Ass_Cursor                     
DEALLOCATE Ass_Cursor           
          
if(@AssociatesString <> '')          
   set @AssociatesString = SUBSTRING(@AssociatesString,0,LEN(@AssociatesString)-1)              
                  
set @CommentsText = 'The induction has been completed for '+convert(varchar,@ind_count)+' [ '+@AssociatesString+' ] associates. Kindly review and close this NTLogin Request'                  
set @ProximityCommentsText  = 'The induction has been completed for '+convert(varchar,@ind_count)+' [ '+@AssociatesString+' ] associates. Kindly review and close this Proximity Request'              
                 
                  
--set @CommentsText = 'The induction has been completed for '+convert(varchar,@ind_count)+' associates. Kindly review and close this NTLogin Request'                  
--set @ProximityCommentsText  = 'The induction has been completed for '+convert(varchar,@ind_count)+' associates. Kindly review and close this Proximity Request'              
--    if OBJECT_ID('tempdb..#IssReqTb') is not null drop table #IssReqTb                  
--create table #IssReqTb(NTReqId int)                    
--insert into #IssReqTb (NTReqId)                
              
declare @NTReqId int                  
Declare @ProximityReqId int     
declare @NTIssueTypeId int
declare @ProximityIssueTypeId int
select @NTIssueTypeId = CTL_VALUE from ARC_REC_SOFTCONTROL where CTL_ID = 'NT Request'
select @ProximityIssueTypeId = CTL_VALUE from ARC_REC_SOFTCONTROL where CTL_ID = 'Proximity and ID card Request'
          
              
EXEC HD_AUTO_ISSREQUEST @ISSUE_ID=@NTIssueTypeId,@COMMENTS=@CommentsText,@CREATED_BY=@CREATED_BY                  
Select @NTReqId = IDENT_CURRENT('HD_ISSUE_REQUEST')              
EXEC HD_AUTO_ISSREQUEST @ISSUE_ID=@ProximityIssueTypeId,@COMMENTS=@ProximityCommentsText ,@CREATED_BY=@CREATED_BY                  
Select @ProximityReqId = IDENT_CURRENT('HD_ISSUE_REQUEST')                  
                  
--if OBJECT_ID('tempdb..#IssReqTb') is not null drop table #IssReqTb                  
--create table #IssReqTb(NTReqId int)                    
--insert into #IssReqTb (NTReqId)      
--select Top 1 ISS_REQID from HD_ISSUE_REQUEST where ISSUE_ID = 117 and COMMENTS = @CommentsText and CREATED_BY = @CREATED_BY order by CREATED_DT desc              
--set @ProximityReqId =  (select Top 1 ISS_REQID from HD_ISSUE_REQUEST where ISSUE_ID =  126 and COMMENTS = @ProximityCommentsText  and CREATED_BY = @CREATED_BY order by CREATED_DT desc)              
              
--select @NTReqId = NTReqId from #IssReqTb                  
              
insert into ARC_REC_InductionMaster(NTReqId,UserId,SupervisorId,CustomerId,CreatedBy,CreatedDt,Trainee,EmailAccessId,FolderAccessId,DistributionAccessId,InductionTaken,ProximityReqId,FacilityId)                     
select @NTReqId,USERID,@SUPERVISOR_ID,@CUSTOMER_ID,@CREATED_BY,GETDATE(),@TRIANEE,@EMAIL_ACCESSID,@FOLDER_ACCESSID,@DISTRIBUTION_ACCESSID,@INDUCTION_TAKEN,@ProximityReqId,@FacilityId from #IndexAssociates                        
                       
                       
                
insert into ARC_REC_IDCard(Name,Emp_Code,Dept,BG,Add1,Add2,Add3,Add4,Emergency_no,SourceFile)                
select ui.FIRSTNAME+' '+ui.LASTNAME,ui.EMPCODE,can.PROFILE_IMAGE_NAME,bg.GroupName,                
fm.Add1,fm.Add2,fm.Add3,fm.Add4,canp.EMER_CONTACT_NO,can.PROFILE_IMAGE_NAME                
from #IndexAssociates ia                
inner join ARC_REC_USER_INFO ui on ia.USERID = ui.USERID                
inner join ARC_REC_CANDIDATE can on ui.REC_ID = can.REC_ID                
inner join ARC_REC_CANDIATE_PROFILE canp on can.REC_ID = canp.REC_ID                
left join ARC_REC_BloodGroup bg on canp.BLOODGROUP = bg.BloodGroup               
inner join ARC_REC_FacilityMaster fm on fm.FacilityId = @FacilityId              
                       
--select @BODY = '<p>  Hi, <br /><br />                      
--The induction has been completed for '+convert(varchar,@ind_count)+' associates.                
--Kindly <a href="https://arc.accesshealthcare.co/ARC_REC/NTrequest.aspx">Click here</a> to review this NTLogin Request.                     
--<br /><br /><img src="https://arc.accesshealthcare.co/arc_me/Images/arc_recruit.png"/>                     
--<br/> ** This is a system generated mail. Please do not respond to this mail.**</p>'                     
                       
--INSERT INTO ARC_REC_MAIL_TRAN(FROM_MAILID,RECIPIENTS,SUBJECT_TEXT,BODY,ISHTML)                        
--select 'mail.recruit@accesshealthcare.co','ithelpdesk@accesshealthcare.co','NTLogin Request',@BODY,'Y'                   
                  
                  
                  
                        
if OBJECT_ID('tempdb..#AttendanceDate') is not null drop table #AttendanceDate                     
Create table #AttendanceDate(AttDate date)                     
if isnull(@DOJ,'') <> '' and @DOJ < CONVERT(date,GETDATE())                     
 Begin                       
 Declare @tDate date                     
 Set @tDate = @DOJ                    
 While @tDate < CONVERT(date,getdate())                     
  Begin                     
                        
                        
Insert into ARC_REC_Attendance(Userid,NT_UserName,[Date],Shiftid,Designid,Functionalityid,CreatedBy,Createdon,                      
Shift_from,Shift_to,Client_id)                      
                       
 select ia.USERID,'' as Nt_UserName,@tDate,@SHIFT_ID,ui.DESIGNATION_ID,                      
 ui.FUNCTIONALITY_ID,1 as CreatedBy,GETDATE() as CreatedOn,sh.SHIFT_FROM,sh.SHIFT_TO,ui.CLIENT_ID                      
 from #IndexAssociates ia                      
 inner join ARC_REC_USER_INFO ui on ia.USERID = ui.USERID                      
 inner join ARC_REC_SHIFT_INFO as sh on sh.SHIFT_ID = @SHIFT_ID                     
 Where @tDate not in (select [DATE] from ARC_REC_Attendance Where Userid = @userid)                    
                    
 --select * from ARC_REC_Attendance where Userid in (select Userid from #IndexAssociates where [date] = @tDate)                    
 Set @tDate = DATEADD(DD,1,@tDate)                    
 End        
 End                    
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_SubmitInduction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_SubmitInduction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_SubmitInduction] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_SubmitInduction] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_SubmitInduction] TO [DB_DMLSupport]
    AS [dbo];

