﻿CREATE procedure ARC_REC_ITREQUEST_APPROVED_GET_all                    
(                    
@SupervisorID int =0                   
)                    
AS                    
/*                    
ARC_REC_ITREQUEST_APPROVED_GET @SupervisorID=807                    
*/                    
BEGIN                    
Select  ROW_NUMBER() OVER (ORDER BY AITR.RequestId DESC) AS 'Sl_No',                    
AITR.RequestId,RequestType=(case when RequestType=1 then 'New request' when RequestType=2 then 'Change request' end),                    
FunctionName,                    
Description ,Reason ,Benifit as 'Benefit',                    
Priority,ApproveStatus,ISNULL(SH.SCHEDULENAME,'') As SCHEDULENAME,    
UI.FIRSTNAME +' '+ ui.LASTNAME as CreateName,ApprovedComments,AITR.CreatedOn,
SI.FIRSTNAME +' '+ SI.LASTNAME as ApprovedBy ,AITR.ApprovedOn                
from                     
ARC_REC_ITREQUEST AITR             
inner join HR_Functionality HRF on AITR.FunctionId=hrf.FunctionalityId                    
left join ARC_REC_USER_INFO ui on ui.userId=AITR.CreatedBy    
left join ARC_REC_USER_INFO Si on Si.userId=AITR.Supervisor     
 
LEFT join ARC_REC_ITREQUEST_SCHEDULE Sh ON SH.SCHID=AITR.SCHID                 
where  AITR.statusId=1 and AITR.ApprovedBy is not null  and AITR.approvestatus='Approve'                  
union all            
Select  ROW_NUMBER() OVER (ORDER BY AITR.RequestId DESC) AS 'Sl_No',                    
AITR.RequestId,RequestType=(case when RequestType=1 then 'New request' when RequestType=2 then 'Change request' end),                    
FunctionName,                    
Description ,Reason ,Benifit as 'Benefit',                    
Priority,ApproveStatus,ISNULL(SH.SCHEDULENAME,'') As SCHEDULENAME,    
UI.FIRSTNAME +' '+ ui.LASTNAME as CreateName,ApprovedComments,AITR.CreatedOn,
SI.FIRSTNAME +' '+ SI.LASTNAME as ApprovedBy ,AITR.ApprovedOn                   
from                     
ARC_REC_ITREQUEST_history AITR             
inner join HR_Functionality HRF on AITR.FunctionId=hrf.FunctionalityId                    
left join ARC_REC_USER_INFO ui on ui.userId=AITR.CreatedBy   
left join ARC_REC_USER_INFO Si on Si.userId=AITR.Supervisor     
 
LEFT join ARC_REC_ITREQUEST_SCHEDULE Sh ON SH.SCHID=AITR.SCHID    
where  AITR.statusId=1    and AITR.ApprovedBy is not null   and AITR.approvestatus='Approve'                                  
order by AITR.RequestId,AITR.ApproveStatus            
            
               
                 
                    
END
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_APPROVED_GET_all] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_APPROVED_GET_all] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_APPROVED_GET_all] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_APPROVED_GET_all] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_APPROVED_GET_all] TO [DB_DMLSupport]
    AS [dbo];

