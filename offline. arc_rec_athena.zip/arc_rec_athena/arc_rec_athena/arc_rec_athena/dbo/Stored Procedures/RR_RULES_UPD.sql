﻿CREATE Proc RR_RULES_UPD        
(        
@Ruleid int,      
@RULES VARCHAR(1000),        
@STATUS TINYINT=1,    
@ERROR varchar(50)OUT    
)        
as          
/*        
RR_RULES_UPD @RULES='test78',@STATUS=1,@Ruleid=1        
*/        
begin        
SET NOCOUNT ON;    
IF NOT EXISTS(SELECT * FROM RR_Rules WHERE Rules=@RULES AND Ruleid !=@Ruleid)    
BEGIN    
Update RR_Rules set Rules=@RULES,STATUS=@STATUS,UpdateOn=GETDATE() WHERE Ruleid=@Ruleid      
SET @ERROR='Rules Updated Successfully!'    
END    
ELSE     
BEGIN    
SET @ERROR='Rules Already Exists!'    
END    
END  

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_RULES_UPD] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_RULES_UPD] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_RULES_UPD] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_RULES_UPD] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_RULES_UPD] TO [DB_DMLSupport]
    AS [dbo];

