﻿CREATE procedure ARC_REC_ITREQUEST_APPROVED_GET                  
(                  
@SupervisorID int                  
)                  
AS                  
/*                  
ARC_REC_ITREQUEST_APPROVED_GET @SupervisorID=807                  
*/                  
BEGIN                  
Select  ROW_NUMBER() OVER (ORDER BY AITR.RequestId DESC) AS 'Sl_No',                  
AITR.RequestId,RequestType=(case when RequestType=1 then 'New request' when RequestType=2 then 'Change request' end),                  
FunctionId,FunctionName, RequestFrom=(case when RequestFrom=1 then 'Client' when RequestFrom=2 then 'Internal' end),                   
(Case when LEN(Description)>50 then SUBSTRING(Description,1,50) + '...' else Description end) As Description,                      
(case when LEN(reason) >50 then substring(Reason,1,50) + '...' else Reason end )As Reason,                      
(case when len(Benifit)> 50 then Substring(Benifit,1,50) + '...' else benifit end) As Benifit,                  
Description as 'Desc',Reason as 'Res',Benifit as 'Ben',                  
AITR.CreatedBy,Priority,ApproveStatus,Supervisor,ISNULL(SH.SCHEDULENAME,'') As SCHEDULENAME,  
FIRSTNAME +' '+ LASTNAME as CreateName,ApprovedComments,RequestStatus,'O' Type,RequestId HRID,AITR.CreatedOn                 
from                   
ARC_REC_ITREQUEST AITR           
inner join HR_Functionality HRF on AITR.FunctionId=hrf.FunctionalityId                  
left join ARC_REC_USER_INFO ui on ui.userId=AITR.CreatedBy   
LEFT join ARC_REC_ITREQUEST_SCHEDULE Sh ON SH.SCHID=AITR.SCHID               
where Supervisor=@SupervisorID and AITR.statusId=1 and AITR.ApprovedBy is not null                  
union all          
Select  ROW_NUMBER() OVER (ORDER BY AITR.RequestId DESC) AS 'Sl_No',                  
AITR.RequestId,RequestType=(case when RequestType=1 then 'New request' when RequestType=2 then 'Change request' end),                  
FunctionId,FunctionName, RequestFrom=(case when RequestFrom=1 then 'Client' when RequestFrom=2 then 'Internal' end),                   
(Case when LEN(Description)>50 then SUBSTRING(Description,1,50) + '...' else Description end) As Description,                      
(case when LEN(reason) >50 then substring(Reason,1,50) + '...' else Reason end )As Reason,                      
(case when len(Benifit)> 50 then Substring(Benifit,1,50) + '...' else benifit end) As Benifit,                  
Description as 'Desc',Reason as 'Res',Benifit as 'Ben',                  
AITR.CreatedBy,Priority,ApproveStatus,Supervisor,ISNULL(SH.SCHEDULENAME,'') As SCHEDULENAME,  
FIRSTNAME +' '+ LASTNAME as CreateName,ApprovedComments,RequestStatus,'H' Type,HRID,        
AITR.CreatedOn                
from                   
ARC_REC_ITREQUEST_history AITR           
inner join HR_Functionality HRF on AITR.FunctionId=hrf.FunctionalityId                  
left join ARC_REC_USER_INFO ui on ui.userId=AITR.CreatedBy  
LEFT join ARC_REC_ITREQUEST_SCHEDULE Sh ON SH.SCHID=AITR.SCHID  
where Supervisor=@SupervisorID and AITR.statusId=1    and AITR.ApprovedBy is not null                
order by AITR.RequestId,AITR.ApproveStatus          
          
             
               
                  
END
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_APPROVED_GET] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_APPROVED_GET] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_APPROVED_GET] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_APPROVED_GET] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_APPROVED_GET] TO [DB_DMLSupport]
    AS [dbo];

