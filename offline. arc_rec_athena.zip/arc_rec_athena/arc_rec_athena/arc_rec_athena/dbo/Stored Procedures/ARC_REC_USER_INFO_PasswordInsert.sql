﻿CREATE procedure  [dbo].[ARC_REC_USER_INFO_PasswordInsert]  
@USERID int,    
@Password varchar(15),
@CREATED_BY int
as         
/*        
 Purpose      : To move the user exists details to log table        
 Created By   : Karthik IC    
 Created Date : 18 June 2013    
 Impact to    : UserCreation.aspx    
*/        
Begin        
    
    insert into  ARC_REC_Athena..ARC_REC_USER_INFO_lOG(USERID,FIRSTNAME,LASTNAME,NT_USERNAME,DESIGNATION_ID,FUNCTIONALITY_ID,REC_ID,ACTIVE,CREATED_BY,CREATED_DT,  
REPORTING_TO,EMPCODE,CLIENT_ID,DOJ,userName,Password,EmailId,AccountType,ExtUser)

Select USERID,FIRSTNAME,LASTNAME,NT_USERNAME,DESIGNATION_ID,FUNCTIONALITY_ID,REC_ID,ACTIVE,CREATED_BY,CREATED_DT,  
REPORTING_TO,EMPCODE,CLIENT_ID,DOJ,userName,Password,EmailId,AccountType,ExtUser  from ARC_REC_Athena..ARC_REC_USER_INFO  where USERID =@USERID

    Update ARC_REC_Athena..ARC_REC_USER_INFO   set Password=@Password,CREATED_BY=@USERID,CREATED_DT=GETDATE() where USERID=@USERID 
--Select USERID,FIRSTNAME,LASTNAME,NT_USERNAME,DESIGNATION_ID,FUNCTIONALITY_ID,REC_ID,ACTIVE,CREATED_BY,CREATED_DT,AHS_PRL,  
--REPORTING_TO,EMPCODE,CLIENT_ID,DOJ,userName,Password,EmailId,AccountType,ExtUser         
--into #temp1    
--From ARC_REC_USER_INFO where USERID = @USERID    
    
--Insert into ARC_REC_USER_INFO_Log (USERID,FIRSTNAME,LASTNAME,NT_USERNAME,DESIGNATION_ID,FUNCTIONALITY_ID,REC_ID,ACTIVE,CREATED_BY,CREATED_DT,  
--REPORTING_TO,EMPCODE,CLIENT_ID,DOJ,userName,Password,EmailId,AccountType,ExtUser)  
  
--Select USERID,FIRSTNAME,LASTNAME,NT_USERNAME,DESIGNATION_ID,FUNCTIONALITY_ID,REC_ID,ACTIVE,CREATED_BY,CREATED_DT,  
--REPORTING_TO,EMPCODE,CLIENT_ID,DOJ,userName,Password,EmailId,AccountType,ExtUser         
--From #temp1    
    
--Delete From ARC_REC_USER_INFO where USERID = @USERID        
    
--Insert into ARC_REC_USER_INFO (FIRSTNAME,LASTNAME,NT_USERNAME,DESIGNATION_ID,FUNCTIONALITY_ID,REC_ID,ACTIVE,CREATED_BY,AHS_PRL,  
--REPORTING_TO,EMPCODE,CLIENT_ID,DOJ,userName,Password,EmailId,AccountType,ExtUser)        
    
--Select FIRSTNAME,LASTNAME,NT_USERNAME,DESIGNATION_ID,FUNCTIONALITY_ID,REC_ID,ACTIVE,@CREATED_BY,AHS_PRL,  
--REPORTING_TO,EMPCODE,CLIENT_ID,DOJ,userName,@Password,EmailId,AccountType,ExtUser  
--From #temp1  
  
--drop table #temp1  
End



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_USER_INFO_PasswordInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_USER_INFO_PasswordInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_USER_INFO_PasswordInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_USER_INFO_PasswordInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_USER_INFO_PasswordInsert] TO [DB_DMLSupport]
    AS [dbo];

