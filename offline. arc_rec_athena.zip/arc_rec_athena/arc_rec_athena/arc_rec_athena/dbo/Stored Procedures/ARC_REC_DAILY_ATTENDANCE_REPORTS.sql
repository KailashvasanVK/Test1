﻿--ARC_REC_DAILY_ATTENDANCE_REPORTS 19,19,1,1,12   
CREATE PROCEDURE ARC_REC_DAILY_ATTENDANCE_REPORTS    
@USER_ID INT,   
@VIEWER_ID INT,   
@FUNCTIONALITY_ID INT,   
@CLIENT_ID INT,   
@MONTH_INDEX INT=0  
AS    
BEGIN    
DECLARE @month TINYINT  
--DECLARE @USER_ID  INT   
--SET @USER_ID = 19    
  
--Declare@VIEWER_ID INT,   
--@FUNCTIONALITY_ID INT,   
--@CLIENT_ID INT,   
--@MONTH_INDEX INT=0  
--Set @VIEWER_ID = 19    
--set @MONTH_INDEX = 6    
    
IF @MONTH_INDEX > 0   
 SET @month = @MONTH_INDEX   
ELSE   
 SET @month = DATEPART(MONTH,GETDATE());  
    
    
 declare @fromdate date  
declare @monthlastdate date   
declare @todate date    
declare @currentdate int  
set @currentdate = DATEPART(d,getdate())   
set @fromdate = datename(yyyy,GETDATE()) + '-' + CONVERT(VARCHAR,@Month) + '-' + '01'  
set @monthlastdate = DATEADD(mm,1, Convert(date,datename(yyyy,GETDATE()) + '-' + CONVERT(VARCHAR,@MONTH) + '-' + '01'))  

if(@Month = datepart(m,GETDATE()) and DATEPART(d,getdate()) > 1)   
    
begin   
 set @todate = GETDATE()  
 --set @todate = datename(yyyy,GETDATE()) + '-' + CONVERT(VARCHAR,@Month) + '-' + convert(varchar,DATEPART(d,convert(date,DATEADD(d,-1,GETDATE()))))   
 end  
else if(@Month = datepart(m,GETDATE()))   
begin    
 set @todate = datename(yyyy,GETDATE()) + '-' + CONVERT(VARCHAR,@Month) + '-' + convert(varchar,DATEPART(d,getdate()))    
 end    
else if(@Month < datepart(m,GETDATE()))   
begin   
  set @todate = convert(date,DATEADD(d,-1,@monthlastdate))    
  end   
  
  
    
 IF OBJECT_ID('TEMPDB..#DailyAttendance','U') IS NOT NULL DROP TABLE #DailyAttendance    
 CREATE TABLE #DailyAttendance (AID INT,USERID INT,ATTENDANCE_DATE DATE,ATT_TYPE VARCHAR(100),TOTAL_HRS NUMERIC(8,2),LATEIN NUMERIC(8,2),ADVANCEOUT NUMERIC(8,2) ,CREATED_BY INT,CREATED_DT DATETIME,   
 APPLIED_LEAVE INT,LEAVE_TYPE VARCHAR(50),LEAVE_MODE VARCHAR(50),REASON VARCHAR(MAX),  
 ATT_DESC VARCHAR(MAX),LOGIN_TIME DATETIME,LOGOUT_TIME DATETIME,ACT_LOGIN_TIME DATETIME,ACT_LOGOUT_TIME DATETIME)   
    
 if OBJECT_ID('tempdb..#att_users') is not null drop table #att_users    
create table #att_users(Userid int,UserType Varchar(5))   
if @USER_ID > 0   
   
insert into #att_users(Userid,UserType)select @USER_ID,'A'  
   
ELSE IF @FUNCTIONALITY_ID > 0 AND @CLIENT_ID > 0    
begin    
 insert into #att_users(Userid,UserType)  
 (select userid,'A' from ARC_REC_USER_INFO where ACTIVE = 1 and FUNCTIONALITY_ID = @FUNCTIONALITY_ID AND CLIENT_ID = @CLIENT_ID    
 union all  
 select USERID,'A' from ARC_REC_USER_INFO where ACTIVE = 2 and AHS_PRL='Y'   
 and FUNCTIONALITY_ID = @FUNCTIONALITY_ID and CLIENT_ID = @CLIENT_ID   
 and CREATED_DT between @fromdate and @todate  
 --and DATEPART(year,CREATED_DT) = DATEPART(year,@todate)  --and DATEPART(month,CREATED_DT) <= DATEPART(MONTH,@todate)  
   
   
 )  
  end  
    
 ELSE IF @FUNCTIONALITY_ID > 0  
 begin   
  insert into #att_users(Userid,UserType)  
    
  (select userid,'A' from ARC_REC_USER_INFO where ACTIVE = 1 and FUNCTIONALITY_ID = @FUNCTIONALITY_ID  
  union all  
 select USERID,'A' from ARC_REC_USER_INFO where ACTIVE = 2 and AHS_PRL='Y'   
 and FUNCTIONALITY_ID = @FUNCTIONALITY_ID   
 --and DATEPART(year,CREATED_DT) = DATEPART(year,@todate)  
 --and DATEPART(month,CREATED_DT) <= DATEPART(MONTH,@todate)  
 and CREATED_DT between @fromdate and @todate  
 )  
end   
    
 ELSE IF @CLIENT_ID > 0    
 begin   
 insert into #att_users(Userid,UserType)  
   
 (select userid,'A' from ARC_REC_USER_INFO where ACTIVE = 1  AND CLIENT_ID = @CLIENT_ID  
 union all select USERID,'A' from ARC_REC_USER_INFO where ACTIVE = 2 and AHS_PRL='Y'   
 and CLIENT_ID = @CLIENT_ID  
 and CREATED_DT between @fromdate and @todate  
 --and DATEPART(year,CREATED_DT) = DATEPART(year,@todate)  
 --and DATEPART(month,CREATED_DT) <= DATEPART(MONTH,@todate)  
 )  
 end   
 ELSE    
 begin   
 insert into #att_users(Userid,UserType)  
 (select userid,'A' from ARC_REC_USER_INFO where ACTIVE = 1   
 union all  
 select USERID,'A' from ARC_REC_USER_INFO where ACTIVE = 2 and AHS_PRL='Y'    
 and CREATED_DT between @fromdate and @todate )    
  --and DATEPART(year,CREATED_DT) = DATEPART(year,@todate)  
  --and DATEPART(month,CREATED_DT) <= DATEPART(MONTH,@todate)   
   
 end   
  
    
   
    
   
  update #att_users set   
  UserType = x.ATT_TYPE   
  from #att_users as at   
  join (select USERID,ATT_TYPE from ARC_REC_ATTENDANCE_ACCESS where ATT_TYPE = 'S' and USERID in (select USERID from #att_users))x on x.USERID = at.Userid    
  
  --select * from #att_users where UserType = 'S'    
  
  INSERT INTO #DailyAttendance(AID,USERID,ATTENDANCE_DATE,ATT_TYPE,TOTAL_HRS,APPLIED_LEAVE,LEAVE_TYPE,LEAVE_MODE,REASON,ATT_DESC    
  ,LATEIN,ADVANCEOUT,LOGIN_TIME,LOGOUT_TIME,ACT_LOGIN_TIME,ACT_LOGOUT_TIME)    
  
SELECT Aid,USERID,[DATE]    
,(CASE WHEN ISNULL(Verified_By,0) <> 0 THEN  
CASE WHEN Verified_Present = 'F' THEN 'Full Present' WHEN Verified_Present = 'H' THEN 'Half Present'  ELSE  'Absent' END   
WHEN TOTALHRS > 7.45 THEN 'Full Present' WHEN TotalHrs > 4.5 THEN 'Half Present' ELSE 'Absent'  
end)   
,TOTALHRS,0,'','','','',LateIn,LateOut,LogOn,LogOut,ActLogin,ActLogout   
FROM ARC_REC_Attendance where Userid in (select Userid from #att_users where UserType = 'A')  
and DATEPART(YEAR,[DATE]) = DATEPART(YEAR,GETDATE()) and DATEPART(MONTH,[DATE]) = @month   
--and [DATE] >= (select DOJ from ARC_REC_USER_INFO where USERID = @USER_ID)  
   
   
declare @tdate date   
set @tdate = convert(varchar,DATEPART(yyyy,getdate())) + '-' + convert(varchar,@month) + '-' + '01'   
   
   
while (datepart(mm,@tdate) = @month)   
begin   
INSERT INTO #DailyAttendance(USERID,ATTENDANCE_DATE,ATT_TYPE,TOTAL_HRS,APPLIED_LEAVE,REASON,ATT_DESC)    
SELECT Userid,@tdate AS ATTENDANCE_DATE,'' AS ATT_TYPE,'0' AS TOTAL_HRS,0 AS APPLIED_LEAVE,''  AS REASON,'' from #att_users    
where @tdate <= CONVERT(DATE,getdate()) and UserType = 'S'    
set @tdate = DATEADD(DAY,1,@tdate)   
end   
/* Update self attendance */   
UPDATE #DailyAttendance set  
AID = SF.AID,  
ATT_TYPE = CASE WHEN SF.ATT_TYPE = 'F' THEN 'Full Present' WHEN SF.ATT_TYPE = 'H' THEN 'Half Present' END,  
TOTAL_HRS = SF.WORKED_HRS,  
CREATED_BY = SF.CREATED_BY,  
CREATED_DT = SF.CREATED_DT,  
LOGIN_TIME = SF.LOGIN_TIME,    
LOGOUT_TIME = SF.LOGOUT_TIME,    
ACT_LOGIN_TIME = att.ActLogin,    
ACT_LOGOUT_TIME = att.ActLogout    
FROM #DailyAttendance SA JOIN ARC_REC_SELF_ATTENDANCE SF  
ON SA.USERID = SF.USERID AND SA.ATTENDANCE_DATE = SF.ATTENDANCE_DATE   
left join ARC_REC_Attendance as att on att.Userid = sa.USERID and att.Date = sa.ATTENDANCE_DATE    
   
   
UPDATE #DailyAttendance SET   
ATT_TYPE = case when lr.LEAVE_MODE = 'F' then 'Full LWP' else 'Half Present' end,   
APPLIED_LEAVE = 1,    
REASON = LR.REASON    
FROM #DailyAttendance SA JOIN ARC_REC_LEAVE_REQUEST LR    
ON SA.USERID = LR.CREATED_BY AND ((SA.ATTENDANCE_DATE BETWEEN LR.FROMDATE AND LR.TODATE) OR (SA.ATTENDANCE_DATE = LR.FROMDATE) OR (SA.ATTENDANCE_DATE =  LR.TODATE))    
AND LR.LEAVE_STATUS IN (1,3) AND LR.ACTIVE = 'Y' AND LR.TYPEID <> 5 and SA.USERID IN (SELECT USERID from #att_users where UserType = 'S')  
   
UPDATE A1  SET  
A1.ATT_DESC = A2.ATT_TYPE    
+(CASE WHEN A2.TOTAL_HRS > 0 THEN ' - '+CONVERT(VARCHAR,A2.TOTAL_HRS)+' Hrs' ELSE '' END)+(CASE WHEN A2.APPLIED_LEAVE > 0 THEN ' (Leave Applied - '+A2.REASON+') ' ELSE '' END)  
FROM #DailyAttendance A1 JOIN #DailyAttendance A2 ON A1.ATTENDANCE_DATE = A2.ATTENDANCE_DATE and A1.USERID = A2.USERID and A1.USERID in (SELECT USERID from #att_users where UserType = 'S')    
  
   
   
/* Update mannual attendance */   
UPDATE #DailyAttendance SET   
ATT_TYPE = CASE WHEN LR.TYPEID = 6 THEN case when lr.LEAVE_MODE = 'F' then 'Full LOP' else 'Half LOP' end    
  ELSE case when lr.LEAVE_MODE = 'F' then 'Full LWP' else 'Half Present' end end,   
LEAVE_TYPE = LTP.SHORT_TEXT,  
LEAVE_MODE = case when lr.LEAVE_MODE = 'F' then 'Full ' else 'Half ' end + case when LR.TYPEID = 6 THEN 'LOP' ELSE 'LWP' END,    
APPLIED_LEAVE = 1,   
REASON = LR.REASON   
FROM #DailyAttendance SA  
INNER JOIN ARC_REC_LEAVE_TRAN AS LT ON LT.LEAVE_DATE = SA.ATTENDANCE_DATE  
INNER JOIN ARC_REC_LEAVE_REQUEST LR ON LR.LEAVE_REQID = LT.LEAVE_REQID AND LR.LEAVE_STATUS = 1 AND LR.CREATED_BY = SA.USERID and lr.TYPEID <> 5 and lr.ACTIVE = 'Y'   
and SA.USERID NOT IN(SELECT USERID from #att_users where UserType = 'S' )   
INNER JOIN ARC_REC_LEAVE_TYPES AS LTP ON LTP.TYPEID = LR.TYPEID  
   
   
/** updating requested permission for mannual attendance */    
update #DailyAttendance set ATT_TYPE = 'Full Present', LEAVE_TYPE = ltp.short_Text    
 from #DailyAttendance  as av  
 inner join ARC_REC_LEAVE_REQUEST as lr on lr.CREATED_BY = av.Userid  and lr.ACTIVE = 'Y'    
 inner join ARC_REC_LEAVE_TYPES as ltp on ltp.TYPEID = lr.TYPEID   
 and CONVERT(CHAR(10),LR.FROMDATE,20) = CONVERT(CHAR(10), AV.ATTENDANCE_DATE,20)  
 and lr.TYPEID = 5 and LEAVE_STATUS = 1 and    
 av.LOGIN_TIME between lr.FROMDATE and lr.TODATE    
 where AV.LATEIN > 0 and av.ATT_TYPE = 'Half Present'    
 and av.USERID not in (SELECT USERID from #att_users where UserType = 'S')   
    
  update #DailyAttendance set ATT_TYPE = 'Full Present', Leave_Type = ltp.short_Text   
 from #DailyAttendance as av  
 inner join ARC_REC_LEAVE_REQUEST as lr on lr.CREATED_BY = av.Userid and lr.ACTIVE = 'Y'    
 inner join ARC_REC_LEAVE_TYPES as ltp on ltp.TYPEID = lr.TYPEID   
 and lr.TYPEID = 5 and LEAVE_STATUS = 1   
 and av.LOGOUT_TIME between lr.FROMDATE and lr.TODATE    
 where AV.ADVANCEOUT > 0 and av.ATT_TYPE = 'Half Present'    
and av.USERID not in (SELECT USERID from #att_users where UserType = 'S')   
   
   
UPDATE #DailyAttendance SET  
LEAVE_TYPE = CASE WHEN AV.ATT_TYPE = 'Half Present' THEN '' ELSE 'Holiday' END ,    
ATT_TYPE = CASE WHEN AV.ATT_TYPE = 'Half Present' THEN AV.ATT_TYPE    
ELSE 'Holiday' END  
FROM #DailyAttendance  AS AV  
INNER JOIN ARC_REC_USER_INFO AS UI ON UI.USERID = AV.USERID    
INNER JOIN (   
SELECT DATE FROM  
 (  
 SELECT ATT.Date,ATT.Shiftid,ATT.Userid  
 ,CASE WHEN DATENAME(WEEKDAY,ATT.Date) = 'Sunday' then ATT.DATE  
 WHEN DATENAME(WEEKDAY,ATT.Date) = 'Saturday' AND ISNULL(SI.SatOffEligible,'N') = 'N' THEN null  
 WHEN UI.FUNCTIONALITY_ID = 3 AND DATENAME(WEEKDAY,ATT.Date) = 'Saturday' THEN ATT.DATE  
 WHEN DATENAME(WEEKDAY,ATT.Date) = 'Saturday' AND ISNULL(SI.HOLIDAY_SAT,'Y') = 'Y' THEN ATT.DATE   
 WHEN HL.HOLIDAY_DATE IS NOT NULL THEN HL.HOLIDAY_DATE  
 ELSE NULL END AS HOLIDAY    
 ,HL.* FROM ARC_REC_Attendance AS ATT    
 INNER JOIN ARC_REC_USER_INFO AS UI (NOLOCK) ON UI.USERID = ATT.Userid   
 INNER JOIN ARC_REC_SHIFT_INFO AS SI ON SI.SHIFT_ID = ATT.Shiftid  
 LEFT JOIN ARC_REC_LEAVE_HOLIDAYLIST AS HL ON HL.HOLIDAY_DATE = ATT.Date AND HL.LISTTYPE = SI.HOLIDAY_LISTTYPE  
 WHERE ATT.Date > '2012-12-31' and ATT.Userid = @USER_ID and   
 DATEPART(YEAR,[DATE]) = DATEPART(YEAR,GETDATE()) and DATEPART(MONTH,[DATE]) = @month  
 and [DATE] >= (select DOJ from ARC_REC_USER_INFO where USERID = @USER_ID)   
 )X WHERE X.HOLIDAY IS NOT NULL  
)Y ON Y.Date = AV.ATTENDANCE_DATE   
where (av.ATT_TYPE = 'Absent' OR av.ATT_TYPE = 'Half Present')  
  and av.USERID not in (SELECT USERID from #att_users where UserType = 'S')   
  
  
  UPDATE A1  SET   
A1.ATT_DESC = CASE WHEN A2.ATT_TYPE = 'Absent' THEN 'Full LOP - Total Hrs : '+ CONVERT(VARCHAR,A2.TOTAL_HRS) + case when A2.LATEIN > 0 then ' - Late In : ' +  
 CONVERT(VARCHAR,A2.LATEIN) else '' end + case when A2.ADVANCEOUT> 0 then ' - Advance out : ' +   
 CONVERT(VARCHAR,A2.ADVANCEOUT) else '' END  
 WHEN A2.ATT_TYPE = 'Half Present' AND A2.LEAVE_TYPE = 'Holiday' THEN 'Half Present - Half LWP (Holiday)'  
WHEN A2.ATT_TYPE = 'Half Present' AND A2.APPLIED_LEAVE = 1 THEN 'Half Present - Half LWP'+' (Leave Applied - '+A2.REASON+') '   
 ELSE A2.ATT_TYPE END +(  
CASE WHEN A2.ATT_TYPE = 'Holiday' AND A2.TOTAL_HRS > 0 THEN ' - Total Hrs : '+ CONVERT(VARCHAR,A2.TOTAL_HRS) + case when A2.LATEIN > 0 then ' - Late In : ' +   
 CONVERT(VARCHAR,A2.LATEIN) else '' end + case when A2.ADVANCEOUT> 0 then ' - Advance out : ' + CONVERT(VARCHAR,A2.ADVANCEOUT) else '' end   
 WHEN A2.ATT_TYPE = 'Holiday' THEN ''  
 WHEN A2.TOTAL_HRS > 0 THEN ' - Total Hrs : '+ CONVERT(VARCHAR,A2.TOTAL_HRS) + case when A2.LATEIN > 0 then ' - Late In : ' + CONVERT(VARCHAR,A2.LATEIN) else '' end + case when A2.ADVANCEOUT> 0 then ' - Advance out : '   
 + CONVERT(VARCHAR,A2.ADVANCEOUT) else '' end   
 WHEN A2.APPLIED_LEAVE > 0 THEN ' (Leave Applied - '+A2.REASON+') '  
 ELSE '' END)   
    
FROM #DailyAttendance A1 JOIN #DailyAttendance A2 ON A1.ATTENDANCE_DATE = A2.ATTENDANCE_DATE and a1.USERID = a2.USERID  
and a1.USERID not in (SELECT USERID from #att_users where UserType = 'S')    
   
--select * from #DailyAttendance order by USERID,ATTENDANCE_DATE   
   
--SELECT AID,USERID,CONVERT(VARCHAR,ATTENDANCE_DATE,113) AS ATTENDANCE_DATE,ATT_TYPE,TOTAL_HRS,APPLIED_LEAVE,LEAVE_TYPE,LEAVE_MODE,REASON,ATT_DESC,    
--LOGIN_TIME,LOGOUT_TIME FROM #DailyAttendance where USERID not in (SELECT USERID from #att_users where UserType = 'S')  
   
SELECT    
--att.USERID,   
ui.FIRSTNAME+' '+ui.LASTNAME as NAME,CONVERT(VARCHAR,att.ATTENDANCE_DATE,113) AS ATT_DATE,   
--att.ATT_TYPE,att.TOTAL_HRS,   
att.ATT_DESC    
,convert(varchar(50),att.ACT_LOGIN_TIME,106)+' '+RIGHT(CONVERT(VARCHAR, att.ACT_LOGIN_TIME, 100),7)  as LOGIN_TIME    
,convert(varchar(50),att.ACT_LOGOUT_TIME,106)+' '+RIGHT(CONVERT(VARCHAR, att.ACT_LOGOUT_TIME, 100),7)  as LOGOUT_TIME   
,convert(varchar(50),att.LOGIN_TIME,106)+' '+RIGHT(CONVERT(VARCHAR, att.LOGIN_TIME, 100),7)  as [BATCH Start]    
,convert(varchar(50),att.LOGOUT_TIME,106)+' '+RIGHT(CONVERT(VARCHAR, att.LOGOUT_TIME, 100),7)  as [BATCH End]    
--,att.APPLIED_LEAVE,att.LEAVE_TYPE,att.REASON  
FROM #DailyAttendance att   
inner join ARC_REC_USER_INFO ui on att.USERID = ui.USERID   
order by att.USERID,att.ATTENDANCE_DATE    
    
--where ATTENDANCE_DATE >= (select DOJ from ARC_REC_USER_INFO where USERID = @USER_ID)   
  
END  
    
    
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_DAILY_ATTENDANCE_REPORTS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_DAILY_ATTENDANCE_REPORTS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_DAILY_ATTENDANCE_REPORTS] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_DAILY_ATTENDANCE_REPORTS] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_DAILY_ATTENDANCE_REPORTS] TO [DB_DMLSupport]
    AS [dbo];

