﻿CREATE PROCEDURE [dbo].[ARC_FORUM_GetTimeZone](    
@statename varchar(150)=NULL    
)      
AS      
BEGIN       
select statename,statetimezone,frmutcdiff,StateDespri from usstatestimedets     
where statename= (case when @statename Is NUll then statename else @statename end) order by statename asc   
    
END      
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FORUM_GetTimeZone] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_GetTimeZone] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_GetTimeZone] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FORUM_GetTimeZone] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_GetTimeZone] TO [DB_DMLSupport]
    AS [dbo];

