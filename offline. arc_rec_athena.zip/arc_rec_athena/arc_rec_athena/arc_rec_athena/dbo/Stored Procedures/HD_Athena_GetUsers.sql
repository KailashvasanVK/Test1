﻿CREATE proc [dbo].[HD_Athena_GetUsers]
As
Begin
select ui.NT_USERNAME as Name,hd.UserId,hd.AthenaUserName,hd.CitrixUserName,hd.HasCitrixReq from HD_AthenaUsers hd
inner join ARC_REC_USER_INFO ui on hd.UserId = ui.USERID
where hd.UserId not in (select UserId from HD_Athena_Terminate where Status = 3 )  -- processed termination    
and hd.AthenaUserName is not null and hd.[Status] = 3
End 


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_GetUsers] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetUsers] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetUsers] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_GetUsers] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetUsers] TO [DB_DMLSupport]
    AS [dbo];

