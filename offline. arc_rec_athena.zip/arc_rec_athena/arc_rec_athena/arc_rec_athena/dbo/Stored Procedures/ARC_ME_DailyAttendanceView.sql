﻿CREATE Proc ARC_ME_DailyAttendanceView        
(        
  @FromDate date /* Mandatory */        
 ,@ToDate date /* Mandatory */        
 ,@SessionUserId int/* Mandatory */        
 ,@FunctionalityID int = 0 /* Optional by default 0 if session user is normal or supervisor */        
 ,@ClientID int = 0 /* Optional by default 0 if session user is normal */        
 ,@Active int = 1 /* Optional by default 1 if session user is normal */        
 ,@UserId int = 0 /* Optional by default 1 if session user is normal */   
 ,@ListTeamMates varchar(1) = 'N'
 ,@SearchStr varchar(100) = ''                              
 ,@SearchPattern varchar(4) = '=' /** = or % **/ 
                        
)        
As        
Begin        
  
--if @FunctionalityID = 0  
-- begin  
-- Select @FunctionalityID = FUNCTIONALITY_ID,@ClientID = CLIENT_ID from ARC_REC_USER_INFO where USERID = @SessionUserId  
-- End  
--ARC_ME_DailyAttendanceView @FromDAte = '2013-12-01',@Todate = '2013-12-31',@SessionUserId = 1,@UserId = 0  
Declare @Qry varchar(max)        
Declare @localdbserver varchar(25) = (Select CTL_VALUE from ARC_REC_SOFTCONTROL where CTL_ID = 'localdbserver')        
if OBJECT_ID('tempdb..#DateWiseAttendance') is not null drop table #DateWiseAttendance        
Create Table #DateWiseAttendance(Aid int,UserId int,[Date] date,Attendance varchar(100),CompOffEligible int,IsDeclaredOff int,OTEligible int,Present varchar(25),NotPresent varchar(25),LeaveType varchar(25))        
Set @Qry = '        
Insert into #DateWiseAttendance(Aid,UserId,[Date],Attendance,CompOffEligible,IsDeclaredOff,OTEligible,Present,NotPresent,LeaveType)        
SELECT Aid,UserId,[Date],Attendance,CompOffEligible,IsDeclaredOff,OTEligible,Present,NotPresent,LeaveType FROM  OPENROWSET(        
''sqloledb''        
,''Server='+@localdbserver+';Trusted_Connection=yes;''        
,''exec ARC_REC_Athena..ARC_ME_MonthlyAttendanceView        
@FromDate = '''''+CONVERT(varchar,@fromDate)+'''''        
,@ToDate = '''''+CONVERT(varchar,@toDate)+'''''        
,@SessionUserId = '+CONVERT(varchar,@SessionUserId)+'        
,@FunctionalityID = '+CONVERT(varchar,@FunctionalityID)+'        
,@ClientID = '+CONVERT(varchar,@ClientID)+'        
,@Active = '+convert(varchar,@Active)+'        
,@SupListAll='''''+@ListTeamMates+'''''  
,@UserId = '+CONVERT(varchar,@UserId)+'        
,@View = ''''DateWise'''''')        
'        
Exec (@Qry)        
create index hash_DateWiseAttendance_userid on #DateWiseAttendance(Aid,[date],UserId)     


Select '<button onclick="return OpenDialog('+convert(varchar,DailyAtt.UserId,0)+','''+convert(varchar,DailyAtt.Date,106)+''','''+ui.NT_USERNAME+''')"            
class="Action ui-button ui-widget ui-state-default ui-corner-all ui-button-icon-only"       
id="btnAckAction" role="button" aria-disabled="false" title="Show Eventlogs">                            
<span class="ui-button-icon-primary ui-icon ui-icon-copy"></span><span class="ui-button-text">Show Eventlogs</span>      
</button>' as [ACTION],      
convert(varchar,DailyAtt.Date,106) as [Date],ui.NT_USERNAME as [Employee]  
,convert(varchar,att.ActLogin,100) as [Logged In]        
,convert(varchar,att.ActLogout,100) as [Logged Out]        
,shift.SHIFT_NAME  [Shift]        
,ISNULL(selfAtt.LOGIN_TIME,att.LogOn) as [Batch StartTime]        
,ISNULL(selfAtt.LOGOUT_TIME,att.LogOut) as [Batch EndTime]        
,att.TotalHrs,att.WorkHours,att.LockHrs        
,att.LateIn,att.LateOut as [Advance Out]        
,DailyAtt.Attendance        
,Verified.NT_USERNAME [Verified By]        
,att.Verified_Comments [Verified Remarks]        
into #DailyAttendanceView from #DateWiseAttendance as DailyAtt        
inner join ARC_REC_Attendance as Att on Att.Aid = DailyAtt.Aid        
inner join ARC_REC_USER_INFO as Ui on Ui.UserId = DailyAtt.UserId        
left join ARC_REC_USER_INFO as Verified on Verified.USERID = att.Verified_By        
inner join ARC_REC_SHIFT_INFO as Shift on Shift.SHIFT_ID = att.Shiftid        
left join ARC_REC_SELF_ATTENDANCE as selfAtt on selfAtt.USERID = att.Userid and selfAtt.ATTENDANCE_DATE = DailyAtt.Date        
 order by DailyAtt.Date desc      
      
Declare @OrderStr varchar(100)         
SET @OrderStr  = ' Order by [Employee],[Date]'            
Exec FilterTable              
@DbName = 'tempdb'  
,@TblName = '#DailyAttendanceView'  
,@SearchStr = @SearchStr  
,@SearchPattern = @SearchPattern  
,@OrderStr = @OrderStr  
if OBJECT_ID('tempdb..#DailyAttendanceView') is not null drop table #DailyAttendanceView          
      
End  
  



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_DailyAttendanceView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_DailyAttendanceView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_DailyAttendanceView] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_DailyAttendanceView] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_DailyAttendanceView] TO [DB_DMLSupport]
    AS [dbo];

