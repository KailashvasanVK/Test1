﻿
create proc ARC_ME_DiscrepancyMark
      @AID INT         
      ,@REASON_ID INT             
      ,@VERIFIED_OPTION CHAR(2)          
      ,@COMMENTS VARCHAR(MAX)              
      ,@OTEligible bit
      ,@CREATED_BY INT              
AS              
              
BEGIN              
UPDATE ARC_REC_Attendance set              
Verified_Present = @VERIFIED_OPTION,              
Verified_Comments = @COMMENTS,          
Verified_By = @CREATED_BY ,
P_days =  Case when @VERIFIED_OPTION = 'F' then 1 when @VERIFIED_OPTION = 'H' then 0.5 else 0 end,  
OTEligible = @OTEligible               
where Aid = @AID      
  
declare @UserId int  
declare @Att_date date    
select @UserId = Userid,@Att_date = [DATE] from ARC_REC_Attendance where Aid = @AID               
        
INSERT INTO ARC_ME_DISCRIPENCY_TRAN( AID,DIS_TYPE, VERIFIED_PRESENT,VERIFIED_BY,VERIFIED_COMMENTS,CREATED_DT,ATT_DATE,USERID)        
SELECT @AID,@REASON_ID,@VERIFIED_OPTION,@CREATED_BY,@COMMENTS,GETDATE(),@Att_date,@UserId        
END   
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_DiscrepancyMark] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_DiscrepancyMark] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_DiscrepancyMark] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_DiscrepancyMark] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_DiscrepancyMark] TO [DB_DMLSupport]
    AS [dbo];

