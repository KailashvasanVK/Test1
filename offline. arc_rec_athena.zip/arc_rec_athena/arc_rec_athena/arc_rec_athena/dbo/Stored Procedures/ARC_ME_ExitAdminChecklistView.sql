﻿--ARC_ME_ExitAdminChecklistView @SupervisorId=910        
CREATE procedure ARC_ME_ExitAdminChecklistView                      
     @SupervisorId int, --                            
     @SearchStr varchar(100) = '',                          
     @SearchPattern varchar(4) = '=' /** = or % **/                        
As                      
Begin                      
                        
if exists (SELECT * from ARC_ME_EXIT_CHKLIST_ACCESS  where CHKLIST_TYPE='AD' and IS_ACTIVE = 1 and USERID = @SupervisorId)                    
    begin                           
                      
SELECT st.TicketId as [Ticket ID],E.REG_ID as [REG_ID~Hide],E.EMPCODE,(C.FIRSTNAME+' '+C.LASTNAME) AS [NAME],                
 E.REASON_ID as [REASON_ID~Hide],R.REASON as [REASON~Hide],                
 E.FEEDBACK as [FEEDBACK~Hide],                
 E.SUPERVISOR_ID as [SUPERVISOR_ID~Hide],                      
 (U.FIRSTNAME+' '+U.LASTNAME) AS [SUPERVISOR~Hide],                
 Convert(varchar,E.NOTICE_PERIOD)+' ( '+ convert(varchar,D.NoticePeriod)+' ) ' AS NOTICE,                      
 E.OTHER_REASON as [OTHER_REASON~Hide],F.FunctionName AS FUNCTIONALITY,                
 CI.CLIENT_NAME as CLIENT,                
 CONVERT(VARCHAR,E.CREATED_DT,106) AS [REQUESTED ON],                                                    
 CONVERT(VARCHAR,E.RELDATE_HR,106) AS [RELIEVING DATE],                
 '<button onclick="return OpenDialog('+convert(varchar,E.REG_ID)+');" class="Action ui-button ui-widget ui-state-default ui-corner-all ui-button-icon-only" id="btnAckAction" role="button" aria-disabled="false" title="CheckList action">              
 <span class="ui-button-icon-primary ui-icon ui-icon-copy"></span>                
 <span class="ui-button-text">Admin Checklist</span></button>' as [ACTION]                  
 into #AdminchecklistView                
 FROM ARC_ME_EXIT E           
 inner join ARC_ME_EXIT_STATUS_TRAN st on e.REG_ID = st.REG_ID                                                       
 INNER JOIN (SELECT MAX(S_ID) as S_ID FROM ARC_ME_EXIT_STATUS_TRAN                 
 GROUP BY REG_ID)T                                                                     
 ON T.S_ID = st.S_ID          
 INNER JOIN ARC_ME_EXIT_REASON_INFO R ON R.REASON_ID= E.REASON_ID                      
 INNER JOIN ARC_REC_USER_INFO U                      
 ON E.SUPERVISOR_ID = U.USERID                      
 INNER JOIN ARC_REC_USER_INFO C                
 ON E.CREATED_BY = C.USERID                                                        
 LEFT JOIN HR_Designation D ON C.DESIGNATION_ID = D.DesigId                                               
 LEFT JOIN HR_Functionality F                                               
 ON C.FUNCTIONALITY_ID = F.FunctionalityId                                                                        
 LEFT JOIN ARC_REC_CustomerView CI                      
 ON C.CLIENT_ID = CI.CLIENT_ID          
 where st.STATUS_ID = 6       
                     
  Exec FilterTable                          
   @DbName = 'tempdb'                          
  ,@TblName = '#AdminchecklistView'                      
  ,@SearchStr = @SearchStr                      
  ,@SearchPattern = @SearchPattern                      
  ,@OrderStr = ''                        
  if OBJECT_ID('tempdb..#AdminchecklistView') is not null drop table #AdminchecklistView                      
                    
  end                    
End 



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_ExitAdminChecklistView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_ExitAdminChecklistView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_ExitAdminChecklistView] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_ExitAdminChecklistView] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_ExitAdminChecklistView] TO [DB_DMLSupport]
    AS [dbo];

