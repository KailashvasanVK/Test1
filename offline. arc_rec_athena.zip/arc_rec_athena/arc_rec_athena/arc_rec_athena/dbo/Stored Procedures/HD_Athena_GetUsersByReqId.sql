﻿CREATE procedure [dbo].[HD_Athena_GetUsersByReqId]               
      @ReqId int                    
                                    
AS                    
Begin              
select au.AthenaUserId,au.Issue_ReqId as ReqId,ir.TICKET_ID as TicketId,au.UserId,      
ui.FIRSTNAME as FirstName ,ui.LASTNAME as LastName,d.Department,r.Role,          
case when au.HasCitrixReq = 'Y' then 'Yes' else 'No' end as HasCitrix,          
case when au.AthenaUserName IS null then 'Not updated' else au.AthenaUserName end as AthenaUserName,              
case when au.HasCitrixReq = 'Y' and au.CitrixUserName IS null then 'Not updated'      
when au.HasCitrixReq = 'N' then 'NR'      
else au.CitrixUserName end as CitrixUserName,    
au.Comments              
from HD_AthenaUsers au              
inner join HD_ISSUE_REQUEST ir on au.Issue_ReqId = ir.ISS_REQID        
inner join ARC_REC_USER_INFO ui on au.UserId = ui.USERID          
inner join HD_Athena_Department d on au.DeptId = d.DeptId              
inner join HD_athena_Role r on au.RoleId = r.RoleId              
where au.Issue_ReqId = @ReqId and au.[status] <> 2 -- not equal to rejected status          
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_GetUsersByReqId] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetUsersByReqId] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetUsersByReqId] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_GetUsersByReqId] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetUsersByReqId] TO [DB_DMLSupport]
    AS [dbo];

