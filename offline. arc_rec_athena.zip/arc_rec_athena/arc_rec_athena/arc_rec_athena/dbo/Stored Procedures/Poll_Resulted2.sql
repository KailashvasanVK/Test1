﻿CREATE Proc Poll_Resulted2(@year VARCHAR(4)=NULL,@month VARCHAR(2)=NULL)              
As         
/*  exec Poll_Resulted2 @year='2013',@month=NULL   

exec Poll_Resulted2 @year='2013',@month='4'

   */

BEGIN        
        
 IF @month IS NOT NULL         
         
 IF EXISTS (SELECT TOP 1'x' FROM (             
select distinct  a.poll_id,Poll,Opt1,Opt2,Opt3,Opt4,OP1P=dbo.PollCount(a.poll_id,1),                              
OP2P=dbo.PollCount(a.poll_id,2),OP3P=dbo.PollCount(a.poll_id,3),            
OP4P=dbo.PollCount(a.poll_id,4),OPA1=dbo.Pollresult(a.poll_id,1),OPA2=dbo.Pollresult(a.poll_id,2),             
OPA3=dbo.Pollresult(a.poll_id,3),OPA4=dbo.Pollresult(a.poll_id,4),CONVERT(VARCHAR(12),a.SCHEDULED_ON,107) as CREATED_ON             
from ARC_Forum_Polls a                               
left join ARC_Forum_Polls_Results b on b.poll_id=A.poll_id                  
where a.status=1 and a.SCHEDULED_ON <= convert(date,GETDATE()) AND month(a.SCHEDULED_ON) = @month 
AND a.poll_id NOT IN (select TOP 1 a.poll_id                           
from ARC_Forum_Polls a where a.SCHEDULED_ON <= convert(date,GETDATE())                           
order by SCHEDULED_ON desc )  )    as Udhaya)     
  
Begin    
  
Print 'hi'  
            
select *,[No.Of.Polled]=(OP1P+OP2P+OP3P+OP4P) from (             
select distinct  a.poll_id,Poll,Opt1,Opt2,Opt3,Opt4,OP1P=dbo.PollCount(a.poll_id,1),                              
OP2P=dbo.PollCount(a.poll_id,2),OP3P=dbo.PollCount(a.poll_id,3),            
OP4P=dbo.PollCount(a.poll_id,4),OPA1=dbo.Pollresult(a.poll_id,1),OPA2=dbo.Pollresult(a.poll_id,2),             
OPA3=dbo.Pollresult(a.poll_id,3),OPA4=dbo.Pollresult(a.poll_id,4),CONVERT(VARCHAR(12),a.SCHEDULED_ON,107) as CREATED_ON             
from ARC_Forum_Polls a                               
left join ARC_Forum_Polls_Results b on b.poll_id=A.poll_id                  
where a.status=1 and a.SCHEDULED_ON <= convert(date,GETDATE()) AND month(a.SCHEDULED_ON) = @month AND a.poll_id NOT IN (select TOP 1 a.poll_id                           
from ARC_Forum_Polls a                                                    
order by SCHEDULED_ON desc  )    )    as Udhaya                        
order by Udhaya.CREATED_ON desc     
  
End     
        
ELSE        
  
Begin  
  
Print 'hi 1'  
  
 select *,[No.Of.Polled]=(OP1P+OP2P+OP3P+OP4P) from (             
select distinct  a.poll_id,Poll,Opt1,Opt2,Opt3,Opt4,OP1P=dbo.PollCount(a.poll_id,1),                              
OP2P=dbo.PollCount(a.poll_id,2),OP3P=dbo.PollCount(a.poll_id,3),            
OP4P=dbo.PollCount(a.poll_id,4),OPA1=dbo.Pollresult(a.poll_id,1),OPA2=dbo.Pollresult(a.poll_id,2),             
OPA3=dbo.Pollresult(a.poll_id,3),OPA4=dbo.Pollresult(a.poll_id,4),CONVERT(VARCHAR(12),a.SCHEDULED_ON,107) as CREATED_ON             
from ARC_Forum_Polls a                               
left join ARC_Forum_Polls_Results b on b.poll_id=A.poll_id                  
where a.status=1 AND month(a.SCHEDULED_ON) = datepart(month,(DATEADD(MONTH,-1,getdate()))) 
and a.SCHEDULED_ON <= convert(date,GETDATE())
)    as Udhaya                        
order by Udhaya.CREATED_ON desc        
  
END    
        
ELSE        
IF EXISTS (SELECT TOP 1 'x' FROM (             
select distinct  a.poll_id,Poll,Opt1,Opt2,Opt3,Opt4,OP1P=dbo.PollCount(a.poll_id,1),                              
OP2P=dbo.PollCount(a.poll_id,2),OP3P=dbo.PollCount(a.poll_id,3),            
OP4P=dbo.PollCount(a.poll_id,4),OPA1=dbo.Pollresult(a.poll_id,1),OPA2=dbo.Pollresult(a.poll_id,2),             
OPA3=dbo.Pollresult(a.poll_id,3),OPA4=dbo.Pollresult(a.poll_id,4),CONVERT(VARCHAR(12),a.SCHEDULED_ON,107) as CREATED_ON             
from ARC_Forum_Polls a                               
left join ARC_Forum_Polls_Results b on b.poll_id=A.poll_id                  
where a.status=1 and a.SCHEDULED_ON <= convert(date,GETDATE()) AND month(a.SCHEDULED_ON) = datepart(mm,getdate()) AND a.poll_id NOT IN (select TOP 1 a.poll_id                           
from ARC_Forum_Polls a                            
      
where a.SCHEDULED_ON <= convert(date,GETDATE()) and a.status=1                 
                     
order by a.SCHEDULED_ON desc  )    )    as Udhaya        
order by Udhaya.CREATED_ON desc   )    

begin   
 
Print 'hi3'         
 
select *,[No.Of.Polled]=(OP1P+OP2P+OP3P+OP4P),CREATED_ON   FROM (             
select distinct  a.poll_id,Poll,Opt1,Opt2,Opt3,Opt4,OP1P=dbo.PollCount(a.poll_id,1),         
OP2P=dbo.PollCount(a.poll_id,2),OP3P=dbo.PollCount(a.poll_id,3),            
OP4P=dbo.PollCount(a.poll_id,4),OPA1=dbo.Pollresult(a.poll_id,1),OPA2=dbo.Pollresult(a.poll_id,2),             
OPA3=dbo.Pollresult(a.poll_id,3),OPA4=dbo.Pollresult(a.poll_id,4),CONVERT(VARCHAR(12),a.SCHEDULED_ON,107) as CREATED_ON             
from ARC_Forum_Polls a                               
left join ARC_Forum_Polls_Results b on b.poll_id=A.poll_id                  
where a.status=1 
and a.SCHEDULED_ON <= convert(date,GETDATE()) AND month(a.SCHEDULED_ON) = datepart(mm,getdate()) 
 AND a.poll_id NOT IN (select TOP 1 a.poll_id                           
from ARC_Forum_Polls a                            
                      
where a.SCHEDULED_ON <= convert(date,GETDATE()) and a.status=1                 
                     
order by a.SCHEDULED_ON desc  )   )    as Udhaya        
order by Udhaya.CREATED_ON desc    

end     
        
ELSE        

begin   
 
Print 'hi4'   
           
select *,[No.Of.Polled]=(OP1P+OP2P+OP3P+OP4P),CREATED_ON  FROM (         
select distinct  a.poll_id,Poll,Opt1,Opt2,Opt3,Opt4,OP1P=dbo.PollCount(a.poll_id,1),                              
OP2P=dbo.PollCount(a.poll_id,2),OP3P=dbo.PollCount(a.poll_id,3),            
OP4P=dbo.PollCount(a.poll_id,4),OPA1=dbo.Pollresult(a.poll_id,1),OPA2=dbo.Pollresult(a.poll_id,2),             
OPA3=dbo.Pollresult(a.poll_id,3),OPA4=dbo.Pollresult(a.poll_id,4),CONVERT(VARCHAR(12),a.SCHEDULED_ON,107)as CREATED_ON             
from ARC_Forum_Polls a                               
left join ARC_Forum_Polls_Results b on b.poll_id=A.poll_id                  
where a.status=1 and a.SCHEDULED_ON <= convert(date,GETDATE()) AND month(a.SCHEDULED_ON) = datepart(mm,getdate())-1 AND a.poll_id NOT IN (select TOP 1 a.poll_id                           
from ARC_Forum_Polls a                            
                      
where a.SCHEDULED_ON <= convert(date,GETDATE()) and a.status=1                 
                     
order by a.SCHEDULED_ON desc  )    )  as Udhaya        
order by Udhaya.CREATED_ON desc         
        
 end       
        
END
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Poll_Resulted2] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Poll_Resulted2] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Poll_Resulted2] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Poll_Resulted2] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Poll_Resulted2] TO [DB_DMLSupport]
    AS [dbo];

