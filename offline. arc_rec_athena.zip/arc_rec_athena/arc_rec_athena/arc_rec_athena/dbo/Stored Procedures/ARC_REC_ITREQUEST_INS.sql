﻿CREATE PROCEDURE ARC_REC_ITREQUEST_INS            
(      
@REQUESTID int=0,      
@RequestType tinyint,            
@FunctionalityId int,            
@RequestFrom tinyint,            
@RequestDescriptin varchar(max),            
@RequestReason varchar(max),            
@RequestBenifit varchar(max),            
@Supervisor int,            
@RequestStatus int=1,            
@CreatedBy INT,            
@Attach_Filename varchar(500),  
@Request_Id int output,           
@AttachementId int output            
)            
As            
/*            
            
Create by  : seena.A            
Created on : Nov 07 2013            
            
DECLARE @CID INT            
Exec ARC_REC_ITREQUEST_INS @RequestType=1,@FunctionalityId=1,@RequestFrom=1,@RequestDescriptin='TEST',            
@RequestReason='TEST',@RequestBenifit='TEST',@Supervisor=1,@RequestStatus='OPEND',@CreatedBy='1'            
,@Attach_Filename='AnalyticsSDSD.png',@AttachementId=@CID output            
            
DECLARE @CID INT            
Exec ARC_REC_ITREQUEST_INS @RequestType=1,@FunctionalityId=1,@RequestFrom=1,@RequestDescriptin='TEST',            
@RequestReason='TEST',@RequestBenifit='TEST',@Supervisor=1,@RequestStatus='OPEND',@CreatedBy='1'            
,@Attach_Filename='',@AttachementId=@CID output            
            
         
            
            
*/            
Begin            
--DECLARE @REQUESTID INT            
            
INSERT INTO ARC_REC_ITREQUEST(RequestType,FunctionId,RequestFrom,Description,Reason,Benifit,            
Supervisor,RequestStatus,CreatedBy,StatusId)            
VALUES(@RequestType,@FunctionalityId,@RequestFrom,@RequestDescriptin,@RequestReason,@RequestBenifit,            
@Supervisor,@RequestStatus,@CreatedBy,1)          
        
set  @REQUESTID = IDENT_CURRENT('ARC_REC_ITREQUEST')        
            
IF @Attach_Filename <>''            
BEGIN            
            
INSERT INTO ARC_REC_ITREQUEST_ATTACHMENT(AFileName,Requestid,CreatedBy,StatusId)            
VALUES (CONVERT(VARCHAR,@REQUESTID) + '_' + @Attach_Filename,@REQUESTID,@CreatedBy,1)            
END    
  
SELECT @Request_Id=@REQUESTID,@AttachementId=@REQUESTID          
            
End      
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_INS] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_INS] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_INS] TO [DB_DMLSupport]
    AS [dbo];

