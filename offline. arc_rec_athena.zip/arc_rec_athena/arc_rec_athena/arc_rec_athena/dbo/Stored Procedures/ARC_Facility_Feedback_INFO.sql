﻿    
CREATE PROCEDURE [dbo].[ARC_Facility_Feedback_INFO]      
@ACTION VARCHAR(50) = NULL      
,@FID INT = NULL      
,@RouteID INT = NULL      
,@CabID INT = NULL      
,@DriverID INT = NULL      
,@TripType INT = NULL      
,@DrivingStyle VARCHAR(50) = NULL      
,@B2 VARCHAR(1) = NULL      
,@B3 VARCHAR(1) = NULL      
,@B4 VARCHAR(1) = NULL      
,@B5 VARCHAR(1) = NULL      
,@B6 VARCHAR(1) = NULL      
,@B7 VARCHAR(1) = NULL      
,@N1 VARCHAR(1) = NULL      
,@Comments VARCHAR(800) = NULL      
,@CreatedBy INT = NULL    
,@FRMDATE VARCHAR(10) = NULL    
,@TODATE VARCHAR(10) = NULL    
,@RESULT INT = NULL    
    
AS      
      
BEGIN      
 IF @ACTION = 'INSERT'       
 BEGIN    
 IF NOT EXISTS(SELECT FID FROM ARC_Facility_FeedbackDtls WHERE RouteID=@RouteID     
 AND CabID=@CabID AND  TripType=@TripType AND CONVERT(VARCHAR,CreatedDt,101)=CONVERT(VARCHAR, GETDATE(),101)    
 AND CreatedBy=@CreatedBy)    
 BEGIN    
  INSERT INTO ARC_Facility_FeedbackDtls      
  (RouteID,CabID,TripType,DrivingStyle,B2,B3,B4,B5,B6,B7,N1,Comments,FBstatus,Status,CreatedBy,CreatedDt)      
  VALUES      
  (@RouteID,@CabID,@TripType,@DrivingStyle,@B2,@B3,@B4,@B5,@B6,@B7,@N1,@Comments,1,1,@CreatedBy,GETDATE())  
  
  SET @RESULT=1      
 END  
 ELSE  
 BEGIN  
  SET @RESULT=0  
 END    
 SELECT @RESULT  
 END      
       
 IF @ACTION = 'SELECT_BY_USER'      
 BEGIN      
  SELECT FB.FID,RM.Routename,CM.CabNo,CM.Drivername,TRIP = CASE WHEN FB.TripType = 1 THEN 'Pick-Up' ELSE 'Drop' END    
  ,FB.Comments,CONVERT(VARCHAR,FB.CreatedDt,101) AS CreatedDt    
  ,FBstatus = CASE WHEN FB.FBstatus = 1 THEN 'Pending' ELSE 'Completed' END    
  ,FB.FBComments    
  FROM ARC_Facility_FeedbackDtls FB     
  INNER JOIN ARC_Facility_RouteMaster RM ON RM.RouteID=FB.RouteID    
  INNER JOIN ARC_Facility_CABMaster CM ON CM.CabID=FB.CabID    
  WHERE FB.Status=1 AND FB.CreatedBy=@CreatedBy       
 END     
     
 IF @ACTION = 'SELECT_BY_ADMIN'      
 BEGIN      
  SELECT FB.FID,RM.Routename,CM.CabNo,CM.Drivername,TRIP = CASE WHEN FB.TripType = 1 THEN 'Pick-Up' ELSE 'Drop' END      
  ,FB.Comments,CreatedDt = CONVERT(VARCHAR,FB.CreatedDt,101) ,CREATEDBY = UI.NT_USERNAME    
  ,FB.FBstatus,CM.DriverContactNo
  ,ShiftName = (    
      SELECT TOP 1  SI.SHIFT_NAME FROM ARC_REC_SHIFT_TRAN ST    
      INNER JOIN ARC_REC_SHIFT_INFO SI ON SI.SHIFT_ID=ST.SHIFT_ID    
      WHERE USERID=FB.CreatedBy    
      ORDER BY CREATED_DT DESC    
      )     
  FROM ARC_Facility_FeedbackDtls FB     
  INNER JOIN ARC_Facility_RouteMaster RM ON RM.RouteID=FB.RouteID    
  INNER JOIN ARC_Facility_CABMaster CM ON CM.CabID=FB.CabID    
  INNER JOIN ARC_REC_USER_INFO UI ON UI.USERID=FB.CreatedBy     
  WHERE FB.Status=1 AND FB.FBstatus=1        
 END     
       
 IF @ACTION = 'DELETE'      
 BEGIN      
  UPDATE ARC_Facility_FeedbackDtls       
  SET Status=0,UpdatedBy=@CreatedBy,UpdatedDt=GETDATE()      
  WHERE FID=@FID      
 END      
       
 IF @ACTION = 'PAGELOAD_DDL'      
 BEGIN      
  --SELECT RouteID AS ID,Routename AS NAME FROM ARC_Facility_RouteMaster      
  --WHERE Status = 1  
 SELECT RM.ROUTEID AS ID,RM.ROUTENAME AS NAME   
 FROM ARC_FACILITY_ROUTEMASTER RM  
 INNER JOIN ARC_REC_SHIFT_TRAN ST ON ST.SHIFT_ID=RM.SHIFTID AND ST.USERID=@CreatedBy      
 WHERE RM.STATUS = 1       
        
  SELECT CabID AS ID,CabNo AS NAME FROM ARC_Facility_CABMaster      
  WHERE Status = 1       
        
  SELECT DriverID AS ID,Drivername AS NAME FROM ARC_Facility_DriverMaster      
  WHERE Status = 1        
 END    
 IF @ACTION = 'SELECT_BY_FID'      
 BEGIN    
 SELECT DrivingStyle,B2,B3,B4,B5,B6,B6,B7,N1    
 FROM ARC_Facility_FeedbackDtls    
 WHERE FID=@FID AND Status=1    
 END    
     
 IF @ACTION = 'GET_RIGHTS'      
 BEGIN    
 SELECT TYPE FROM ARC_FACILITY_USER_RIGHTS    
 WHERE UID=@CreatedBy AND STATUS=1    
 END    
     
 IF @ACTION = 'FB_CREATOR'      
 BEGIN    
 SELECT CRATEDBY = UI.NT_USERNAME, CREATEDDT = CONVERT(VARCHAR,FD.CreatedDt,101),FD.Comments     
 FROM ARC_Facility_FeedbackDtls FD    
 INNER JOIN ARC_REC_USER_INFO UI ON UI.USERID=FD.CreatedBy    
 WHERE FD.FID=@FID     
 END    
     
 IF @ACTION = 'ACTION_TAKEN'      
 BEGIN  
 IF NOT EXISTS(SELECT * FROM ARC_Facility_FeedbackDtls WHERE FBstatus=2 AND FBComments=@Comments AND FID = @FID   
 AND UpdatedBy=@CreatedBy AND CONVERT(VARCHAR, UpdatedDt,101) = CONVERT(VARCHAR,GETDATE(),101))  
 BEGIN  
  UPDATE ARC_Facility_FeedbackDtls SET FBstatus=2,FBComments=@Comments,UpdatedBy=@CreatedBy,UpdatedDt=GETDATE()    
  WHERE FID=@FID  
  
  SET @RESULT=1  
 END  
 ELSE  
 BEGIN  
  SET @RESULT=0  
 END    
 SELECT @RESULT  
 END    
     
 IF @ACTION = 'REPORTS'      
 BEGIN    
  IF @FRMDATE = '' OR @TODATE = ''    
  BEGIN      
  SELECT FB.FID,RM.Routename,CM.CabNo,CM.Drivername,TripType = CASE WHEN FB.TripType = 1 THEN 'Pick-Up' ELSE 'Drop' END    
  ,FB.Comments AS AssociateComments,UI.NT_USERNAME AS RaisedBy,CONVERT(VARCHAR,FB.CreatedDt,101) AS RaisedDt    
  ,ShiftName = (    
      SELECT TOP 1  SI.SHIFT_NAME FROM ARC_REC_SHIFT_TRAN ST    
      INNER JOIN ARC_REC_SHIFT_INFO SI ON SI.SHIFT_ID=ST.SHIFT_ID    
      WHERE USERID=FB.CreatedBy    
      ORDER BY CREATED_DT DESC    
      )    
  ,Status = CASE WHEN FB.FBstatus = 1 THEN 'Pending' ELSE 'Completed' END    
  ,FB.FBComments AS ActionComments,CM.DriverContactNo    
  FROM ARC_Facility_FeedbackDtls FB     
  INNER JOIN ARC_Facility_RouteMaster RM ON RM.RouteID=FB.RouteID    
  INNER JOIN ARC_Facility_CABMaster CM ON CM.CabID=FB.CabID    
  INNER JOIN ARC_REC_USER_INFO UI ON UI.USERID=FB.CreatedBy      
  WHERE FB.Status=1 AND DATEPART(M,FB.CreatedDt) = DATEPART(M,GETDATE())    
  END    
  ELSE    
  BEGIN    
  SELECT FB.FID,RM.Routename,CM.CabNo,CM.Drivername,TripType = CASE WHEN FB.TripType = 1 THEN 'Pick-Up' ELSE 'Drop' END    
  ,FB.Comments AS AssociateComments,UI.NT_USERNAME AS RaisedBy,CONVERT(VARCHAR,FB.CreatedDt,101) AS RaisedDt    
  ,ShiftName = (    
      SELECT TOP 1  SI.SHIFT_NAME FROM ARC_REC_SHIFT_TRAN ST    
      INNER JOIN ARC_REC_SHIFT_INFO SI ON SI.SHIFT_ID=ST.SHIFT_ID    
      WHERE USERID=FB.CreatedBy    
      ORDER BY CREATED_DT DESC    
     )    
  ,Status = CASE WHEN FB.FBstatus = 1 THEN 'Pending' ELSE 'Completed' END    
  ,FB.FBComments AS ActionComments,CM.DriverContactNo    
  FROM ARC_Facility_FeedbackDtls FB     
  INNER JOIN ARC_Facility_RouteMaster RM ON RM.RouteID=FB.RouteID    
  INNER JOIN ARC_Facility_CABMaster CM ON CM.CabID=FB.CabID    
  INNER JOIN ARC_REC_USER_INFO UI ON UI.USERID=FB.CreatedBy      
  WHERE FB.Status=1 AND CONVERT(VARCHAR,FB.CreatedDt,101) BETWEEN @FRMDATE AND @TODATE    
  END        
 END  
   
 IF @ACTION = 'SELECTSHIFT'  
 BEGIN  
 SELECT SHIFT_ID,SHIFT_NAME FROM ARC_REC_SHIFT_INFO  
 WHERE SHIFT_ID BETWEEN 1 AND 5  
 END  
   
 IF @ACTION = 'GET_DRIVER'  
 BEGIN  
 SELECT DriverName FROM ARC_Facility_CABMaster  
 WHERE CabID=@CabID  
 END   
       
END      
      
      
      

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Facility_Feedback_INFO] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Facility_Feedback_INFO] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Facility_Feedback_INFO] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Facility_Feedback_INFO] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Facility_Feedback_INFO] TO [DB_DMLSupport]
    AS [dbo];

