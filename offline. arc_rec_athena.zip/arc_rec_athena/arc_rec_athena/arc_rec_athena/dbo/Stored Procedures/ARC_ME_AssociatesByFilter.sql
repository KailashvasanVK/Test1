﻿--ARC_ME_AssociatesByFilter 0 ,0 ,2,'2014-04-01','2014-04-30'
CREATE procedure ARC_ME_AssociatesByFilter        
       @FunctionalityId int        
       ,@ClientId int        
       ,@Active int=1   
       ,@FromDate date=''  
       ,@ToDate date=''   
       ,@SupervisorId int = 0  
               
As        
Begin      
if isnull(@SupervisorId,0) = 0 Set @SupervisorId = 0  
if(isnull(@Active,0) = 0) set @Active = 1    
 if OBJECT_ID('tempdb..#LoadAssociates ') is not null drop table #LoadAssociates           
 declare @qry as varchar(max)        
 Set @qry = 'select ui.USERID as UserId,ui.EMPCODE as EmpCode,ui.FIRSTNAME+'' ''+ui.LASTNAME+'' - (''+ui.EMPCODE+'')'' as EmpName from ARC_REC_USER_INFO ui where  ui.EMPCODE is not null and isnull(ui.AHS_PRL,''Y'') = ''Y'''        
         
 if(@FunctionalityId > 0)        
 set @qry = @qry + ' and ui.FUNCTIONALITY_ID = '+CONVERT(varchar,@FunctionalityId)        
 if(@ClientId > 0)        
 set @qry = @qry + ' and ui.CLIENT_ID = '+CONVERT(varchar,@ClientId)        
 if (@SupervisorId > 0)  
 Set @qry = @qry + ' and ui.Reporting_to in (Select NT_USERNAME from arc_Rec_user_info where userid = '+CONVERT(varchar,@SupervisorId)+')'       
     
 if(@Active = 2 and @FromDate <> '' and @ToDate <> '')   
 set @qry = @qry + ' and ui.ACTIVE = '+CONVERT(varchar,@Active)+' and UserId in (Select distinct(UserId) from ARC_REC_AssociateDOLView Where DOL Between '''+CONVERT(varchar,@FromDate)+''' and '''+CONVERT(varchar,@ToDate)+''')'          
 else  
  set @qry = @qry + ' and ui.ACTIVE = '+CONVERT(varchar,@Active)   
   
     
 --if(@SupervisorId > 0)        
 --set @qry = @qry + ' and ui.REPORTING_TO = (select NT_USERNAME from ARC_REC_USER_INFO where USERID = '+CONVERT(varchar,@SupervisorId)+')'        
         
set @qry = @qry + ' order by EmpName'        
print(@qry)         
Exec(@qry)        
End  
  
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_AssociatesByFilter] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_AssociatesByFilter] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_AssociatesByFilter] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_AssociatesByFilter] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_AssociatesByFilter] TO [DB_DMLSupport]
    AS [dbo];

