﻿CREATE PROCEDURE dbo.Leap_GetUserPwdDetails    
   
 @UserId INT    
AS    
BEGIN    
  
 SET NOCOUNT ON;    
    
 SELECT     
  UserId,    
  UserName,    
  Password    
    
 FROM    
  mrplogin    
 WHERE     
  Statusid = 1    
 AND    
  UserId = @UserId    
END    
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Leap_GetUserPwdDetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Leap_GetUserPwdDetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Leap_GetUserPwdDetails] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Leap_GetUserPwdDetails] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Leap_GetUserPwdDetails] TO [DB_DMLSupport]
    AS [dbo];

