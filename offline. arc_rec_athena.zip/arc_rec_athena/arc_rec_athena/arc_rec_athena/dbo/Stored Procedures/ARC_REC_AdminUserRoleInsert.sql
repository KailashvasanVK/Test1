﻿CREATE procedure ARC_REC_AdminUserRoleInsert
@UserId int
,@RoleId int
,@CREATED_BY int
,@FUNCTIONALITY_ID int =0
As
/*
Purpose    : To move the existing role into log table and assign the user role to all functionality.
Impact to  : adminRoleTranConfig.aspx
Created by : Karthik Ic
Created on : 10 sep 2013
*/
Begin
-- declare @FUNCTIONALITY_ID int 
if (@FUNCTIONALITY_ID = 0 )
set @FUNCTIONALITY_ID  = (Select FUNCTIONALITY_ID from ARC_REC_USER_INFO Where userid =@CREATED_BY )
print @FUNCTIONALITY_ID
if exists( Select top 1 'x' from ARC_REC_UserRole  Where UserId = @UserId and FUNCTIONALITY_ID= @FUNCTIONALITY_ID  )
Begin
print 'update'
Insert into ARC_REC_UserRoleLog (UserId,RoleId,CREATED_BY,CREATED_DT,FUNCTIONALITY_ID)
Select UserId,RoleId,CREATED_BY,CREATED_DT,FUNCTIONALITY_ID from ARC_REC_UserRole
Where UserId = @UserId and FUNCTIONALITY_ID= @FUNCTIONALITY_ID
Update ARC_REC_UserRole  set RoleId = @RoleId,CREATED_BY = @CREATED_BY,CREATED_DT = GETDATE()
Where UserId =@UserId and FUNCTIONALITY_ID = @FUNCTIONALITY_ID
End
Else
Begin
print 'insert'
Insert into ARC_REC_UserRole (UserId,RoleId,CREATED_BY,FUNCTIONALITY_ID)
Select @UserId,@RoleId,@CREATED_BY,@FUNCTIONALITY_ID
End
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_AdminUserRoleInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AdminUserRoleInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AdminUserRoleInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_AdminUserRoleInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AdminUserRoleInsert] TO [DB_DMLSupport]
    AS [dbo];

