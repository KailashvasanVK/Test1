﻿CREATE PROCEDURE ARC_REC_Proximity_Manage 
@ProxyId INT, 
@ProximityNo VARCHAR(10), 
@Comments VARCHAR(200), 
@CREATED_BY INT, 
@Response VARCHAR(MAX) OUT 
 
AS
BEGIN
 DECLARE @ProxCount INT

  SELECT @ProxCount = COUNT(Proxy.ProximityNo) FROM ARC_REC_Proximity Proxy 
  inner join ARC_REC_USER_INFO  UI on UI.EMPCODE = Proxy.EmpCode and ui.ACTIVE <> 0 and ui.AHS_PRL='Y' 
  Where Proxy.ProximityNo = @ProximityNo and Proxy.ProxyId <> @ProxyId --and Proxy.InductionId <> @InductionId 
 
 IF (@ProxCount < 1) 
  BEGIN 
   INSERT INTO ARC_REC_Proximity_Log(ProxyId,EmpCode,ProximityNo,Comments,CREATED_DT,CREATED_BY,InductionId) 
   SELECT ProxyId,EmpCode,ProximityNo,Comments,CREATED_DT,CREATED_BY,InductionId FROM ARC_REC_Proximity 
   WHERE ProxyId = @ProxyId; 
   UPDATE ARC_REC_Proximity SET ProximityNo = @ProximityNo,Comments = @Comments, CREATED_DT = GETDATE(), 
   CREATED_BY = @CREATED_BY WHERE ProxyId = @ProxyId; 
     SET @Response = 'SUCCESS';  
    END 
 ELSE 
   SET @Response = 'ProximityNo already exists';         
END 


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_Proximity_Manage] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Proximity_Manage] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Proximity_Manage] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_Proximity_Manage] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Proximity_Manage] TO [DB_DMLSupport]
    AS [dbo];

