﻿  
CREATE Proc ARC_REC_Attendance_Actual_Time_Update  
as  
Begin  
declare @from datetime=convert(date,dateadd(day,-1,getdate()))  
  
print @from  
  
;With Table1 ( NT_username,Fromdate,Maxin,Maxout,shiftid,logon,logout)  
As  
(  
select NT_username,date Fromdate,  
Maxin=(  
convert(datetime,DATEADD(day,0,date))+' '+convert(varchar(10),dateadd(HH,-5,convert(varchar(5),a.SHIFT_FROM,108)),108)   
),  
Maxout=(Case when shiftid IN(1,4) then  
convert(datetime,DATEADD(day,0,date))+' '+convert(varchar(10),dateadd(HH,+5,convert(varchar(5),a.SHIFT_to,108)),108)   
else   
convert(datetime,DATEADD(day,1,date))+' '+convert(varchar(10),dateadd(HH,+6,convert(varchar(5),a.SHIFT_to,108)),108) end)  
,a.Shiftid,logon,a.logout  
from arc_rec_attendance a  
inner join ARC_REC_SHIFT_INFO B on a.Shiftid=b.SHIFT_ID  
where  a.LogOn is not null and a.logout is not null   
and a.date=@from   
)select shiftid,fromdate,NT_username,  
Actlogin=(select MIN(eventtime) from   
Userlock.dbo.UserLogonEvents b where b.UserAccount  =a.NT_username and eventtime>=max(a.maxin) and eventtime<max(a.maxout)  
and CONVERT(date,eventtime)>=@from),  
actlogout=( select MAX(eventtime) from   
Userlock.dbo.UserLogonEvents b where b.UserAccount  =a.NT_username  
and eventtime<max(a.maxout) and eventtime>=max(a.Maxin ) and CONVERT(date,eventtime)>=@from  )   
into #talbeactual from Table1 a   
group by fromdate,NT_username,shiftid  
order by fromdate   
  
update a set a.ActLogin=b.ActLogin,a.ActLogout=b.ActLogout  from ARC_REC_Attendance a    
inner join #talbeactual b on a.NT_UserName =b.nt_username and a.Date=b.fromdate  

SELECT * FROM #talbeactual
  
Drop table #talbeactual  
  
END
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_Attendance_Actual_Time_Update] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Attendance_Actual_Time_Update] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Attendance_Actual_Time_Update] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_Attendance_Actual_Time_Update] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Attendance_Actual_Time_Update] TO [DB_DMLSupport]
    AS [dbo];

