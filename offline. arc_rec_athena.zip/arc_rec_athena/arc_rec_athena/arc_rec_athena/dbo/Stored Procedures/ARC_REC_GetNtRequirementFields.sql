﻿create procedure ARC_REC_GetNtRequirementFields  
       @FieldType varchar(2)  
As  
Begin  
select RqId,[Description] from ARC_REC_NtRequirementFields where FieldType = @FieldType  
  
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_GetNtRequirementFields] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_GetNtRequirementFields] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_GetNtRequirementFields] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_GetNtRequirementFields] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_GetNtRequirementFields] TO [DB_DMLSupport]
    AS [dbo];

