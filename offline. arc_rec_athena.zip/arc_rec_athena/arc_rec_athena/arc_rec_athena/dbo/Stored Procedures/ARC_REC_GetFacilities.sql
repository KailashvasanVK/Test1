﻿create proc ARC_REC_GetFacilities
As
Begin
select FacilityId,FacilityName,Add1,Add2,Add3,Add4 from ARC_REC_FacilityMaster where Active = 'Y'
End



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_GetFacilities] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_GetFacilities] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_GetFacilities] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_GetFacilities] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_GetFacilities] TO [DB_DMLSupport]
    AS [dbo];

