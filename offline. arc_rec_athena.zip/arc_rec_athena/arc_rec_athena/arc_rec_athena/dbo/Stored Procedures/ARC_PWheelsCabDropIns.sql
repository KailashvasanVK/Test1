﻿CREATE PROCEDURE ARC_PWheelsCabDropIns      
 @NAME VARCHAR(50) = '',            
 @EMPCODE VARCHAR(10) = '',            
 @DropType VARCHAR(50) = '',            
 @DropPoint VARCHAR(50) = '',            
 @CabNumber VARCHAR(50) = '',      
 @DriverNumber VARCHAR(50) = '',          
 @Shift VARCHAR(50) = '',            
 @DriverName VARCHAR(50) = '',      
 @FileName VARCHAR(75) = '',         
 @USERID int        
AS      
BEGIN      
 INSERT INTO ARC_WheelsCabDrop(NAME,EMPCODE,DropType,DropPoint,CabNumber,Shift      
    ,DriverName,DriverNumber,FileName,CREATED_BY,CREATED_DT)      
    VALUES(@NAME,dbo.RemoveWhiteSpace(@EMPCODE),@DropType,@DropPoint,@CabNumber,      
    @Shift,@DriverName,@DriverNumber,@FileName,@USERID,GETDATE())  
 END

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_PWheelsCabDropIns] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_PWheelsCabDropIns] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_PWheelsCabDropIns] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_PWheelsCabDropIns] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_PWheelsCabDropIns] TO [DB_DMLSupport]
    AS [dbo];

