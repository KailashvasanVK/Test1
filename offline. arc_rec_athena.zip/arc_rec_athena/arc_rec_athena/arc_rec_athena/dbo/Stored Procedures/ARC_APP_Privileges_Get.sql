﻿CREATE Proc ARC_APP_Privileges_Get      
@Userid int=0,      
@NTUserName Varchar(100)=Null,      
@Apptype int      
/*        
      
Created By : Udhayaganesh Pachiyappan    
Purpose    : Get the access privileges of particular Forms (or) App    
    
Exec ARC_APP_Privileges_Get 807,Null,1      
      
      
Exec ARC_APP_Privileges_Get 807,'udhayaganesh.p',1      
      
Exec ARC_APP_Privileges_Get 0,'udhayaganesh.p',1      
      
      
*/      
AS     
Begin      
Declare @SPName Nvarchar(100),@APUserid int  
select @SPName=NtUserName,@APUserid=Userid from ARC_APP_Privileges where Apptype =@Apptype   
If @APUserid!=0  
Begin 
 if @NTUserName is not null      
 Begin      
 Select Userid,NtUserName,Apptype from ARC_APP_Privileges where NTUserName=@NTUserName and Apptype=@Apptype   and Status =1      
 End  
 Else if @Userid <>0      
 begin      
 Select Userid,NtUserName,Apptype from ARC_APP_Privileges where userid=@Userid and Apptype=@Apptype and Status =1      
 End  
End    
Else   
Begin  
 Exec @SPName @NTUserName,@Apptype  
End   
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_APP_Privileges_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_APP_Privileges_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_APP_Privileges_Get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_APP_Privileges_Get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_APP_Privileges_Get] TO [DB_DMLSupport]
    AS [dbo];

