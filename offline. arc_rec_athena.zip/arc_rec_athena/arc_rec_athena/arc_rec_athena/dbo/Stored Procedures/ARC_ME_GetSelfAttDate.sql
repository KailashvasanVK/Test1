﻿CREATE procedure ARC_ME_GetSelfAttDate  
       @UserId int  
       ,@Attdate date  
As  
Begin    
--declare @UserId int  
--declare @Attdate date  
--set @UserId = 16  
--set @Attdate = '2013-10-03'  
declare @ShiftId int    
select @ShiftId =st.SHIFT_ID from ARC_REC_SHIFT_TRAN st where USERID = @UserId order by CREATED_DT desc  
if exists(select * from ARC_REC_SHIFT_INFO where SHIFT_ID = @ShiftId and SHIFT_FROM > '12:00:00.0000000')  
begin  
 select convert(varchar,@Attdate,101) as LoginDate,convert(varchar,DATEADD(day,1,@Attdate),101) as LogoutDate  
end  
else  
 select convert(varchar,@Attdate,101) as LoginDate, convert(varchar,@Attdate,101) as LogoutDate     
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_GetSelfAttDate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_GetSelfAttDate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_GetSelfAttDate] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_GetSelfAttDate] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_GetSelfAttDate] TO [DB_DMLSupport]
    AS [dbo];

