﻿CREATE Proc IndexRebulitTableGet          
as          
Begin          
Declare @TableName varchar(400),@tc int=0;          
          
if exists (select OBJECT_NAME('MIS_Frag_Tables'))          
drop table MIS_Frag_Tables          
          
Create table MIS_Frag_Tables          
(          
id int identity(1,1),          
Name varchar(400),          
Frag_count int,          
)          
    
insert into MIS_Frag_Tables(Name,Frag_count)          
SELECT object_name(object_id),avg(avg_fragmentation_in_percent)   
FROM sys.dm_db_index_physical_stats (DB_ID(), NULL, NULL, NULL, NULL)   
where avg_fragmentation_in_percent>10
Group by object_id
          
    
select * from MIS_Frag_Tables where Frag_count <>0          
          
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[IndexRebulitTableGet] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[IndexRebulitTableGet] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[IndexRebulitTableGet] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[IndexRebulitTableGet] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[IndexRebulitTableGet] TO [DB_DMLSupport]
    AS [dbo];

