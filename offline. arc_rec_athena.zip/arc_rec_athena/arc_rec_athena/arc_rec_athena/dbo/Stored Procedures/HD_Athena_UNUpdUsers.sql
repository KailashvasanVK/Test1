﻿CREATE proc [dbo].[HD_Athena_UNUpdUsers]    
     @ReportingTo int  
As    
Begin    
select USERID as UserId,FIRSTNAME +' '+LASTNAME as Name,NT_USERNAME as UserName from ARC_REC_USER_INFO   
where ACTIVE = 1 and AHS_PRL = 'Y' and 
REPORTING_TO = (select NT_USERNAME from ARC_REC_USER_INFO where USERID = @ReportingTo) -- if any condition, will add in future.    
and USERID not in (select UserId from HD_AthenaUsers)
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_UNUpdUsers] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_UNUpdUsers] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_UNUpdUsers] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_UNUpdUsers] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_UNUpdUsers] TO [DB_DMLSupport]
    AS [dbo];

