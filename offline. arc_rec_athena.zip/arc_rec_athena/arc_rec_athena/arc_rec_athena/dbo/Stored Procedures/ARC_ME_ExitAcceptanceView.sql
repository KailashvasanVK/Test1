﻿ CREATE procedure ARC_ME_ExitAcceptanceView      
     @SupervisorId int, --            
     @SearchStr varchar(100) = '',          
     @SearchPattern varchar(4) = '=' /** = or % **/        
  As      
  Begin      
        
  SELECT E.REG_ID as [REG_ID~Hide],E.EMPCODE,(C.FIRSTNAME+' '+C.LASTNAME) AS NAME,CI.CLIENT_NAME as [CLIENT NAME],E.REASON_ID as [REASON_ID~Hide],      
  R.REASON as [REASON TYPE],E.FEEDBACK as REASON,E.SUPERVISOR_ID as [SUPERVISOR_ID~Hide],      
  (U.FIRSTNAME+' '+U.LASTNAME) AS [SUPERVISOR~Hide],convert(varchar,E.NOTICE_PERIOD)+' ( '+ convert(varchar,D.NoticePeriod)+' ) ' AS NOTICE,      
  ACK.REMARKS AS [ACK_COMMENTS~Hide],          
  E.OTHER_REASON as [OTHER_REASON~Hide],            
  CONVERT(VARCHAR,E.CREATED_DT,106) AS [REQUEST ON],    
   '<button onclick="return OpenDialog('+convert(varchar,E.REG_ID)+');" class="Action ui-button ui-widget ui-state-default ui-corner-all ui-button-icon-only" id="btnAckAction" role="button" aria-disabled="false" title="Exit Ack">    
   <span class="ui-button-icon-primary ui-icon ui-icon-copy"></span><span class="ui-button-text">Exit Acceptance</span></button>' as [ACTION]            
   into #AcceptanceView FROM ARC_ME_EXIT E             
  INNER JOIN ARC_ME_EXIT_REASON_INFO R            
  ON R.REASON_ID= E.REASON_ID            
  INNER JOIN ARC_REC_USER_INFO U            
  ON E.SUPERVISOR_ID = U.USERID            
  INNER JOIN ARC_REC_USER_INFO C            
  ON E.CREATED_BY = C.USERID            
  LEFT JOIN HR_Designation D ON C.DESIGNATION_ID = D.DesigId                                     
  LEFT JOIN ARC_REC_CustomerView CI            
  ON C.CLIENT_ID = CI.CLIENT_ID           
  LEFT JOIN ARC_ME_EXIT_STATUS_TRAN ACK              
  ON E.REG_ID = ACk.REG_ID AND ACK.STATUS_ID = 2              
  WHERE E.ACTIVE = 'Y' and E.REG_ID IN ( SELECT REG_ID FROM ARC_ME_EXIT_STATUS_TRAN             
  GROUP BY REG_ID HAVING MAX(STATUS_ID) = 2 ) AND ISNULL(E.EMPCODE,'') <> ''      
            
  Exec FilterTable          
  @DbName = 'tempdb'          
  ,@TblName = '#AcceptanceView'      
  ,@SearchStr = @SearchStr      
  ,@SearchPattern = @SearchPattern      
  ,@OrderStr = ''        
  if OBJECT_ID('tempdb..#AcceptanceView') is not null drop table #AcceptanceView        
        
  End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_ExitAcceptanceView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_ExitAcceptanceView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_ExitAcceptanceView] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_ExitAcceptanceView] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_ExitAcceptanceView] TO [DB_DMLSupport]
    AS [dbo];

