﻿Create Proc ManualDateAttendanceProcess
 @From date,
 @to date
 As
 Begin          
                   
            
insert into UL_Attendance(UserAccount,Shiftid,UserFullName,LoginDate,Logout,WMin,Whours,HMin,Hhours,FMin,Fhours,Date)            
exec UserTrackingReport_new_job @from,@to            
           

insert into ARC_REC_Attendance(userid,nt_username,date,shiftid,Logon,Logout,TotalHrs,WorkHours,LockHrs,Designid,Functionalityid,Createdby,Createdon,Client_id )              
select * from (              
select distinct ui.userid,UI.NT_USERNAME,@From date,AI.Shiftid ,Ai.LoginDate,AI.Logout,isnull(Whours ,0) WorkHrs,isnull(Fhours,0)           
TotalHrs,isnull(Hhours,0) LockHrs,UI.DESIGNATION_ID,UI.FUNCTIONALITY_ID,1 CBy,GETDATE() CON,CLIENT_ID               
from ARC_REC_USER_INFO  UI              
left join UL_Attendance AI on UI.NT_USERNAME =AI.UserAccount             
and   date=@From   )  as udhaya               
where USERID is not null and USERID not in (select USERID from ARC_REC_Attendance where date=@From)   


exec Attendance_LateinOut_update_manual @from

update a set a.Shift_From=b.SHIFT_FROM,a.Shift_to = b.SHIFT_TO  
from  ARC_REC_Attendance a
inner join ARC_REC_SHIFT_INFO b on a.Shiftid =b.SHIFT_ID 
where a.Shift_From is null  and a.shift_to is null and ISNUMERIC(a.Shiftid)=1
and a.Date =@from

exec Attendance_shift_Marking_Jobs_Manual @from

exec ARC_REC_Attendance_Actual_Time_Update_manual @from

End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ManualDateAttendanceProcess] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ManualDateAttendanceProcess] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ManualDateAttendanceProcess] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ManualDateAttendanceProcess] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ManualDateAttendanceProcess] TO [DB_DMLSupport]
    AS [dbo];

