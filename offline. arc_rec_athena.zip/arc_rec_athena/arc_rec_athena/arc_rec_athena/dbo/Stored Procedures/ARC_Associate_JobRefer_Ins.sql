﻿CREATE Proc ARC_Associate_JobRefer_Ins                                                 
@RefName Varchar(30)=Null,                                                          
@RefEmailId Varchar(50) =Null,                                                          
@RefMobile Varchar(50) =Null,                        
@VANIP Varchar(20) =Null,                                                          
@HostIP Varchar(20) =Null,                                                          
@FBName Varchar(100)=Null ,                                                 
@SessionId varchar(100)=Null,                                                
@Position varchar(50)=null,                                                
@FBUserId varchar(100)=null,                                                
@FBEmailId varchar(250)=Null,                                                
@FBLike int=1                                                         
AS                                                          
/*                   
                
exec AHC_JobRefer_Ins @RefName='udhai',@RefMobile='9884722558',@RefEmailId='udhai@gmail.com',                
@VANIP='172.19.5.2',@HostIP='172.19.5.92',@FBUserId='100000073922681',@FBName='Udhayaganesh Pachiyappan',                
@FBEMailID='vigoudhaya@gmail.com',@FBLike='1',@Position=NULL                                                       
                                                          
Created By : UdhayaGanesh P                                                          
Created On : 11th Sep 2012                                                          
Purpose    : Refer job opening in FaceBook Application                                                          
                                                          
AHC_JobRefer_Ins  @RefName='udhaya',@RefEmailId='rajaan@gmail.com',                                                      
             @RefMobile='98890909099',@VANIP='',@HostIP='',@FBName='seee',@SessionId='',@FBUserId='1000000234567',                                                
             @FBEmailId='seena@gamil.com',@FBLike=1,@Position='1'                                                   
                                                                    
select * from AHC_JobRefer where FBEmaiId ='seena@gamil.com'                                                 
and Position ='1' and CONVERT(date,CreatedOn)>=GETDATE()-90 and RefEmailId ='rajaan@gmail.com'                                                
                                              
exec AHC_JobRefer_Ins @RefName='udhayaganeshp',@RefMobile='9884722558',@RefEmailId='vigoudhaya@yahoo.com',                                              
@VANIP='172.17.4.240',@HostIP='172.17.3.100',@FBUserId='100000073922681',@FBName='Udhayaganesh Pachiyappan',                                              
@FBEMailID='vigoudhaya@gmail.com',@FBLike=NULL,@Position='R1'                                             
                                            
exec AHC_JobRefer_Ins @RefName='udhaya',@RefMobile='9884722558',@RefEmailId='vigoudhaya@gmail.com',@VANIP='172.17.4.240',                                            
@HostIP='172.17.3.108',@FBUserId=NULL,@FBName=NULL,@FBEMailID=NULL,@FBLike=NULL,@Position='R1'                                             
                                                                       
Truncate table AHC_JobRefer                                                          
                                                          
*/                                                          
                                                          
Begin                                                          
                                                          
Declare @Refralno Varchar(20)='',@temp Varchar(20)='',@Referid int=0,@msgnew varchar(max)='',                                              
@header varchar(10)='Job Refer' ,@designation varchar(100),@header1 varchar(200) ='',@msgnew1 varchar(max)=''  

set @FBEmailId=ltrim(rtrim(@FBName))+'@accesshealthcare.co'
                               
             
if not exists(select 'x' from AHC_AppLikeUsers where Userid=@FBUserId and status=1 and @FBUserId is not null)                                    
begin                        
Insert into AHC_AppLikeUsers                                   
(UserId,UserName,UserEmailId,Status)                                     
values (@FBUserId,@FBName,@FBEmailId,1)                                  
                                
end                                         
                                                          
If not exists(select 'x' from AHC_JobRefer where FBEmaiId =@FBEmailId and Position =@Position and CONVERT(date,CreatedOn)>=GETDATE()-90 and RefEmailId =@RefEmailId )                                                          
begin                                         
                                        
exec ARC_REC_Athena..SP_INS_ARC_REC_CANDIDATE @RefName,@RefMobile,1,@Refralno Output                                         
                                      
                                      
if @Position is null                                      
set @Position ='imgRef4'                             
                                                      
Insert into  AHC_JobRefer(RefName,ReferNo,refEmailId,refMobile,VANIP,HostIP,FBName,sessionvalue,FBUserId,Position,FBEmaiId,FBLike)                                                           
select @RefName,@Refralno,@RefEmailId,@RefMobile,@VANIP,@HostIP,@FBName,@SessionId,@FBUserId,@Position,@FBEmailId,@FBLike                                     
                            
                            
insert into ARC_REC_APPLICANT_STATUS_FB(REC_ID,CREATED_DT,STATUS_ID)                            
select @Refralno,GETDATE(),11                                                          
                                                       
                                                          
select 'Thank you for referal, Your refral number as : '+ @Refralno  as Output                                                
                                              
                                              
if @Position ='imgRef1'                                                
begin                                                
set @designation ='Billing Executive'                                                
end                                                
else if @Position ='imgRef2'                                                
Begin                                                
set @designation ='Revenue Cycle Executive'                                                
end                                                
else if @Position ='imgRef3'                                               
begin                                                
set @designation ='Coding Executive (Specialized in Radiology / ER / Hospital coding)'                                                
end                                         
else if @Position ='imgRef4'                                          
                                              
begin                                         
set @designation ='General'                                              
                                              
end                                                 
                                              
--set @header1='You referred to [ '+@designation+' ] position at Access Healthcare by [ '+@FBName +' ]'                                              
                                          
set @header1='You have been referred at Access Healthcare by [ '+@FBName +' ]'                                              
                                        
                    
If @Refralno !='' and @Position is not null and @FBEmailId is not null                                               
begin                                                
set @msgnew = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">'                            
SET @msgnew = @msgnew + '<html xmlns="http://www.w3.org/1999/xhtml" >'                                                                                      
SET @msgnew = @msgnew + '<head>'         
SET @msgnew = @msgnew + '<title>Report</title>'                                                                                                                                          
SET @msgnew = @msgnew + '<style type=text/css>'                                                                                                                                                                     
SET @msgnew = @msgnew + '<!-- .tableHeader{  font-family: Arial, Verdana, Helvetica, sans-serif; font-size: 12px; font-weight: normal; font-style: normal ;color:#FFF }'      
SET @msgnew = @msgnew + '.tableTxt{  font-family:  Arial, Verdana, Helvetica, sans-serif; font-size: 12px; font-weight: normal; font-style: normal  }-->'                                                          
SET @msgnew = @msgnew + '</style>'                                                                                                                                                  
SET @msgnew = @msgnew + '</head>'                                                                                                                                 
SET @msgnew = @msgnew + '<body>'                                                                            
SET @msgnew = @msgnew + '<table>'                                                                                                     
SET @msgnew = @msgnew + '<tr> Hi,'                                                 
SET @msgnew = @msgnew + '<tr><td>&nbsp;</td> </tr>'                                                                                                                            
SET @msgnew = @msgnew + '<tr>                                                
                                                
Thank you for referring '+@RefName+' for [ '+@designation+' ] at Access Healthcare. We appreciate you taking the time to refer your friends for this position.                                              
Your referral ID is [ '+@Refralno+' ].</tr>                                                
 <tr> You may use this ID to learn more about the recruitment status of your referral.                                                
  You are eligible for a cash award of up to Rs.10,000 should your referral be selected for this position and                                               
upon the completion of a 90 day tenure with us.</tr>                                                
   <tr><td>&nbsp;</td> </tr>                                                 
To know more about our company, please visit http://www.accesshealthcare.co/ .</tr>'      
SET @msgnew = @msgnew + '</tr>'                                            
SET @msgnew = @msgnew + '<tr><td>&nbsp;</td> </tr>'                                                       
SET @msgnew = @msgnew + '<tr><td>Warm Regards,</td> </tr>'                                                       
SET @msgnew = @msgnew + '<tr><td>Access Healthcare</td> </tr>            
<tr><TD></td></tr>                                     
<tr><TD></td></tr>              
<tr><td>This is a system generated mail. Please do not respond to this mail.</td></tr>            
<tr><TD></td></tr>                                     
<tr><TD></td></tr>            
<TR><B>Legal Disclaimer:</B></TR>            
<tr>The information contained in this message (including all attachments) may be privileged and confidential.             
It is intended to be read only by the individual or entity to whom it is addressed or by their designee.             
If the reader of this message is not the intended recipient, please destroy this message immediately and also please note that you are on notice that any distribution of this message, in any form, is strictly prohibited.            
If you have received this message in error, please immediately notify the sender and delete or destroy any copy of this message!            
</td></tr>'                                                       
set @msgnew=@msgnew+'</table></body></html>'      
        
select @msgnew            
set @msgnew1 = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">'                                                                                           
SET @msgnew1 = @msgnew1 + '<html xmlns="http://www.w3.org/1999/xhtml" >'                                                                                                           
SET @msgnew1 = @msgnew1 + '<head>'                                                                                                                                                                                    
SET @msgnew1 = @msgnew1 + '<title>Report</title>'                                                                                                                                          
SET @msgnew1 = @msgnew1 + '<style type=text/css>'                                                                                                                                                                                
SET @msgnew1 = @msgnew1 + '<!-- .tableHeader{  font-family: Arial, Verdana, Helvetica, sans-serif; font-size: 12px; font-weight: normal; font-style: normal ;color:#FFF }'                                                                                    


  
    
      
SET @msgnew1 = @msgnew1 + '.tableTxt{ font-family:  Arial, Verdana, Helvetica, sans-serif; font-size: 12px; font-weight: normal; font-style: normal  }-->'                                                          
SET @msgnew1 = @msgnew1 + '</style>'                                                                                                                                                  
SET @msgnew1 = @msgnew1 + '</head>'                                                                                                                                                            
SET @msgnew1 = @msgnew1 + '<body>'                   
SET @msgnew1 = @msgnew1 + '<table>'                                                                                                                   
SET @msgnew1 = @msgnew1 + '<tr> Hi,'                                                 
SET @msgnew1 = @msgnew1 + '<tr><td></td> </tr>'                                                                                                         
SET @msgnew1 = @msgnew1 + '<tr>       
      
'+@FBName+' has referred  '+@RefName+' for '+@designation +' position at Accesshealthcare. The details are as below: </tr>                                        
  <tr><tr><td></td> </tr>                                  
    <tr><tr><td>Name : '+ @RefName+'</td> </tr>                                                 
  <tr><tr><td></td> </tr>                                                 
  <tr><tr><td>Contact Number : '+ @RefMobile+'</td> </tr>                               
  <tr><td></td> </tr>                              
  <tr><tr><td>Email ID : '+ @RefEmailId+'</td> </tr>                               
  <tr><td></td> </tr>                              
  '                                                
SET @msgnew1 = @msgnew1 + '</tr>'                                                       
SET @msgnew1 = @msgnew1 + '<tr><td></td> </tr>'             
SET @msgnew1 = @msgnew1 + '<tr><td>Regards,</td> </tr>'                         
SET @msgnew1 = @msgnew1 + '<tr><td>Refer and Win</td> </tr>              
<tr><TD></td></tr>                                     
<tr><TD></td></tr>              
<tr><td>This is a system generated mail. Please do not respond to this mail.</td></tr>            
<tr><TD></td></tr>                                     
<tr><TD></td></tr>            
<TR><B>Legal Disclaimer:</B></TR>            
<tr>The information contained in this message (including all attachments) may be privileged and confidential.             
It is intended to be read only by the individual or entity to whom it is addressed or by their designee.             
If the reader of this message is not the intended recipient, please destroy this message immediately and also please note that you are on notice that any distribution of this message, in any form, is strictly prohibited.            
If you have received this message in error, please immediately notify the sender and delete or destroy any copy of this message!            
</td></tr>'                                                       
set @msgnew1=@msgnew1+'</table></body></html>'                                            
                                            
print 'refered by'                                               
                                              
--Get mail for regered by                                               
EXEC msdb.dbo.sp_send_dbmail                                                                                                                                                                                                       
@profile_name = 'ARC_DBmail',                                                       
@recipients=@FBEmailId,                                                 
@subject=@header ,                                                   
@body = @msgnew,                                                       
@body_format  = 'HTML'                               
                          
EXEC msdb.dbo.sp_send_dbmail                                                                                                                                                                                                       
@profile_name = 'ARC_DBmail',                                                       
@recipients='hr@accesshealthcare.co',                                                       
@copy_recipients='hepsiba.raj@accesshealthcare.co',                  
@blind_copy_recipients='udhayaganesh.p@accesshealthcare.co',                                               
@subject=@header ,                                                   
@body = @msgnew1 ,                                                       
@body_format  = 'HTML'                                            
                                              
                                               
                                                
end                                              
                     
                                               
                                              
If @Refralno !='' and @Position is not null  and @RefEmailId is not null  and @FBName is not null                                            
begin                                              
set @msgnew=''                                              
                                              
set @msgnew = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">'                                                                                
SET @msgnew = @msgnew + '<html xmlns="http://www.w3.org/1999/xhtml" >'                                                                                                                                  
SET @msgnew = @msgnew + '<head>'                                                                             
SET @msgnew = @msgnew + '<title>Report</title>'                                                                                                                                          
SET @msgnew = @msgnew + '<style type=text/css>'                                                 
SET @msgnew = @msgnew + '<!-- .tableHeader{  font-family: Arial, Verdana, Helvetica, sans-serif; font-size: 12px; font-weight: normal; font-style: normal ;color:#FFF }'                                                                                      
 
  
    
     
        
           
            
              
               
                  
                    
                       
              
                          
SET @msgnew = @msgnew + '.tableTxt{  font-family:  Arial, Verdana, Helvetica, sans-serif; font-size: 12px; font-weight: normal; font-style: normal  }-->'                                                          
SET @msgnew = @msgnew + '</style>'                                                                                                                                                  
SET @msgnew = @msgnew + '</head>'                                           
SET @msgnew = @msgnew + '<body>'                                                                            
SET @msgnew = @msgnew + '<table>'                                                                          
SET @msgnew = @msgnew + '<tr> Hi,'                                                 
SET @msgnew = @msgnew + '<tr><td>&nbsp;</td> </tr>'                                                                                                                                                                            
SET @msgnew = @msgnew + '<tr>                                                
                                     
                                              
 You have been referred to the  [ '+@designation+' ] position at Access Healthcare by [ '+@FBName +' ].                                              
  Your referral ID is [ '+@Refralno+' ].</tr>                                                
 <tr> You will receive a call from our recruitment team shortly.                                              
  Please use this referral ID [ '+@Refralno+' ] for the recruitment process.                                               
</tr>                                                
   <tr><td>&nbsp;</td> </tr>                                                 
To know more about our company, please visit http://www.accesshealthcare.co/ .</tr>'                                                
                                                                                                                               
                                                          
SET @msgnew = @msgnew + '</tr>'                                                       
SET @msgnew = @msgnew + '<tr><td>&nbsp;</td> </tr>'                                                       
SET @msgnew = @msgnew + '<tr><td>Warm Regards,</td> </tr>'                                                       
SET @msgnew = @msgnew + '<tr><td>Access Healthcare</td> </tr>              
<tr><TD></td></tr>                                     
<tr><TD></td></tr>              
<tr><td>This is a system generated mail. Please do not respond to this mail.</td></tr>            
<tr><TD></td></tr>                                     
<tr><TD></td></tr>            
<TR><B>Legal Disclaimer:</B></TR>            
<tr>The information contained in this message (including all attachments) may be privileged and confidential.             
It is intended to be read only by the individual or entity to whom it is addressed or by their designee.             
If the reader of this message is not the intended recipient, please destroy this message immediately and also please note that you are on notice that any distribution of this message, in any form, is strictly prohibited.            
If you have received this message in error, please immediately notify the sender and delete or destroy any copy of this message!            
</td></tr>'                                                       
set @msgnew=@msgnew+'</table></body></html>'                                       
                                                
select @msgnew                                    
                                         
select @RefEmailId                                            
                                              
-----Get mail for refferal                          
EXEC msdb.dbo.sp_send_dbmail                 
@profile_name = 'ARC_DBmail',                                                       
@recipients=@RefEmailId ,                                                       
@copy_recipients='hr@accesshealthcare.co',                                                
@subject=@header1,                                                   
@body = @msgnew,                                                       
@body_format  = 'HTML'                                               
                                            
            
                                              
set @msgnew=''                                              
end     --second if end                                                        
 end                                                      
else                                                          
Begin                                                          
                                                          
select 'You refered this person as on : ' + convert(varchar(15),CreatedOn,110) +'. Same person you can refer after 3 months for the date of refered.' as Output                                                      
 from AHC_JobRefer where FBEmaiId =@FBEmailId and Position=@Position and RefEmailId =@RefEmailId                     
                                                          
End      --else last                                                    
                                                          
                                               
ENd--proc end 

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Associate_JobRefer_Ins] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Associate_JobRefer_Ins] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Associate_JobRefer_Ins] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Associate_JobRefer_Ins] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Associate_JobRefer_Ins] TO [DB_DMLSupport]
    AS [dbo];

