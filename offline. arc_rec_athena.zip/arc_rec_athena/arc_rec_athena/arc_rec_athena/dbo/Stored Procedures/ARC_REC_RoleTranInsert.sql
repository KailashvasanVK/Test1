﻿CREATE Procedure [dbo].[ARC_REC_RoleTranInsert]
@RoleId int,
@MenuId int ,
@CREATED_BY int,
@RoleRead tinyint = 0,
@RoleWrite tinyint = 0
As
/*
Purpose    : To store the user role and menu details in to ARC_REC_RoleTran
			 @RoleRead and  @RoleWrite Status  - 1 Checked, 0 UmChecked   
Impact to  : RoleCreation.aspx    
Created by : Karthik Ic        
Created on : 09 april 2013
*/       
Begin      
------------- Insert new data into ARC_REC_RoleTran table  ------------       
Insert into ARC_REC_RoleTran(RoleId,MenuId,RoleRead,RoleWrite,CREATED_BY)
Select  @RoleId,@MenuId,@RoleRead,@RoleWrite,@CREATED_BY
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_RoleTranInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_RoleTranInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_RoleTranInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_RoleTranInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_RoleTranInsert] TO [DB_DMLSupport]
    AS [dbo];

