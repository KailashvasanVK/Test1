﻿CREATE procedure HD_StationeryAction                                                
 @Action VARCHAR(75),                                              
 @USERID INT=0,                                            
 @ItemId INT=0,                
 @Status INT,                                    
 @ISS_REQID INT=0                  
 AS                                       
Begin                                                
If  @Action = 'ARC_StationeryItems'                                                
-- Purpose :  To Get Stationary Items in DropdownList                                                
 BEGIN                                                
   SELECT ItemId,ItemName FROM HD_StatineryItemmaster WHERE Active = 1 ORDER BY ItemName                        
 END                                              
If @Action = 'ARC_StationeryQuickList'                        
-- Purpose : To Get Stationary Quicklist Table                                              
  BEGIN                                              
 SELECT SI.ItemName,SR.ItemId,SI.Quantity AS ItemType,SR.Quantity FROM HD_StationeryRequest AS SR   INNER JOIN               (SELECT MAX(ISS_REQID) AS MAX_ISS_REQID FROM HD_StationeryRequest WHERE CreatedBy = @USERID) a ON a.MAX_ISS_REQID = SR.ISS_REQID  
                                            
 INNER JOIN HD_StatineryItemmaster SI ON SI.ItemId = SR.ItemId                                              
 WHERE SR.CreatedBy = @USERID ORDER BY SI.ItemName                                              
  END                                            
If @Action = 'ARC_StationeryItemType'                                            
-- Purpose : To Get Stationary Item Type for Ddl                                            
  BEGIN                                            
    SELECT Quantity FROM HD_StatineryItemmaster WHERE ItemId = @ItemId                                            
  END                                      
IF @Action = 'ARC_Stationery_Details'                                      
-- Purpose : To Get Stationary Item Details for Stationary Approve and Process                             
   BEGIN                                      
 SELECT SR.ISS_REQID,SI.ItemName,SR.ItemId,SI.Quantity AS ItemType,SR.Quantity,IR.TICKET_ID                                      
 FROM HD_StationeryRequest AS SR                                       
 INNER JOIN HD_ISSUE_REQUEST AS IR ON IR.ISS_REQID = SR.ISS_REQID                                      
 INNER JOIN HD_StatineryItemmaster SI ON SI.ItemId = SR.ItemId                                       
 WHERE SR.Status = @Status and SR.ISS_REQID = @ISS_REQID ORDER BY SI.ItemName                                      
   END                                      
IF @Action = 'ARC_StationeryTicketFlow'                                      
-- Purpose : To Get Stationary Item for TicketFlow                                    
   BEGIN       
       
   declare @lastupdatedstatus as int    
   select @lastupdatedstatus =(select top 1 ISSUE_STATUS from HD_ISSUE_TRAN where ISS_REQID = @ISS_REQID order by CREATED_DT desc)    
  SELECT SI.ItemName,SI.Quantity AS ItemType,SR.Quantity,                
  CASE WHEN @lastupdatedstatus = 0 and SR.[Status] = 0 THEN 'Pending - Supervisor Approval'         
   WHEN @lastupdatedstatus = 1 and SR.[Status] = 1 THEN 'Pending - Resolution'         
   WHEN @lastupdatedstatus = 1 and SR.[Status] = 2 THEN 'Rejected by Supervisor'      
   WHEN @lastupdatedstatus = 2 THEN 'Rejected by Supervisor'      
   WHEN @lastupdatedstatus = 3  and SR.[Status] = 1 THEN 'InProgress'        
   WHEN @lastupdatedstatus = 3  and SR.[Status] = 2 THEN 'Rejected by Supervisor'    
   WHEN @lastupdatedstatus = 4  THEN 'Request Released'     
   WHEN @lastupdatedstatus = 7  THEN 'Request Rejected'     
   WHEN @lastupdatedstatus = 8  and SR.[Status] = 3  THEN 'Provided and Waiting - Acknowledge'     
   WHEN @lastupdatedstatus = 8  and SR.[Status] = 4  THEN 'Rejected by Facility Team'     
   WHEN @lastupdatedstatus = 8  and SR.[Status] = 2  THEN 'Rejected by Supervisor'     
   WHEN @lastupdatedstatus = 5  and SR.[Status] = 5  THEN 'Completed'     
   WHEN @lastupdatedstatus = 5  and SR.[Status] = 4  THEN 'Rejected by Facility Team'    
   WHEN @lastupdatedstatus = 5  and SR.[Status] = 2  THEN 'Rejected by Supervisor'      
  else '' end as [Status]                
  FROM HD_StationeryRequest AS SR                                       
  INNER JOIN HD_ISSUE_REQUEST AS IR ON IR.ISS_REQID = SR.ISS_REQID                                      
  INNER JOIN HD_StatineryItemmaster SI ON SI.ItemId = SR.ItemId                                       
  WHERE SR.ISS_REQID = @ISS_REQID ORDER BY SI.ItemName                                      
   END                  
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_StationeryAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_StationeryAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_StationeryAction] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_StationeryAction] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_StationeryAction] TO [DB_DMLSupport]
    AS [dbo];

