﻿CREATE Proc ARC_Lounge_Message_Comment_ReportAbuse_Ins              
 @CmtId int,              
 @NT_Username Varchar(100)              
 /*               
 CreatedBy : Udhayaganesh.p              
 Purpose   : Associate Report the Comments to be accounted              
               
 Execution : Exec ARC_Lounge_Message_Comment_ReportAbuse_Ins 6,'varunnair.m'             
             
 Exec ARC_Lounge_Message_Comment_ReportAbuse_Ins 7,'varunnair.m'            
               
 */              
 As              
 Begin              
 if not Exists(select top 1 'x' from ARC_Forum_Lounge_Comment_Flags where ReportedBy =@NT_Username        
 and CmtId =@CmtId and Status=1)              
 Begin              
 Insert into ARC_Forum_Lounge_Comment_Flags(CmtId,ReportedBy,ReportedOn,Status)              
 Values(@CmtId,@NT_Username,GETDATE(),1)              
 Select COUNT(*) ReportCount,1 'ReportAbuse',CmtId from ARC_Forum_Lounge_Comment_Flags         
 where CmtId=@CmtId and Status=1 group by CmtId             
 End            
 End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comment_ReportAbuse_Ins] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comment_ReportAbuse_Ins] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comment_ReportAbuse_Ins] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comment_ReportAbuse_Ins] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comment_ReportAbuse_Ins] TO [DB_DMLSupport]
    AS [dbo];

