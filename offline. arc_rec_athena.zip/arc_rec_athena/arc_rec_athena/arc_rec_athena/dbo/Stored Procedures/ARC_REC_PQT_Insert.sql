﻿CREATE Procedure ARC_REC_PQT_Insert            
(            
@SESSIONID varchar(500),            
@TragetDate Datetime,            
@CreatedBy varchar(100),            
@Type tinyint=1            
)            
As            
/*            
            
Insert into ARC_REC_ProductionQT(TRAGETDATE,NTUSERNAME,PTARGET,PACHIEVED,PERCENTAGE,RTYPE,CreateBy,CreatedOn,StatusId)            
select TRAGETDATE,NTUSERNAME,PTARGET,PACHIEVED,PERCENTAGE,RTYPE,'seena.ambatur',getdate(),1 from ARC_Rec_ProductionQT_Temp             
where SESSIONID='42xoi1yl3x0cpghvbfdmt2kv847635321262295967408_ProductQT' and TRAGETDATE='2014-04-01 00:00:00.000'            
            
ARC_REC_PQT_Insert @SessionId='42xoi1yl3x0cpghvbfdmt2kv847635321263209947408_ProductQT',            
@TragetDate='2014-04-01',@CreatedBy='seena.ambaturu'            
            
*/            
Begin            
if @Type =1        
begin        
select COUNT(*) TotalInserted from (            
select T.TRAGETDATE,T.NTUSERNAME,T.PTARGET,T.PACHIEVED,T.PERCENTAGE,            
RTYPE= case when O.NTUSERNAME=T.NTUSERNAME and  O.TRAGETDATE=T.TRAGETDATE  then 'Duplicate' else 'New' end                
from ARC_Rec_ProductionQT_Temp T            
left join ARC_Rec_ProductionQT O on O.NTUSERNAME=T.NTUSERNAME and  O.TRAGETDATE=T.TRAGETDATE   and o.RTYPE=T.RTYPE           
where SESSIONID=@SESSIONID and T.TRAGETDATE=@TragetDate and T.RTYPE =@Type             
) as seena where RTYPE='New'          
            
INSERT INTO ARC_REC_ProductionQT            
(TRAGETDATE,NTUSERNAME,PTARGET,PACHIEVED,PERCENTAGE,RTYPE,CreateBy,CreatedOn,StatusId )         
        
select TRAGETDATE,NTUSERNAME,PTARGET,PACHIEVED,PERCENTAGE,@Type,@CreatedBy,getdate(),1 from (            
select T.TRAGETDATE,T.NTUSERNAME,T.PTARGET,T.PACHIEVED,T.PERCENTAGE,            
RTYPE= case when O.NTUSERNAME=T.NTUSERNAME and  O.TRAGETDATE=T.TRAGETDATE  then 'Duplicate' else 'New' end                
from ARC_Rec_ProductionQT_Temp T            
left join ARC_Rec_ProductionQT O on O.NTUSERNAME=T.NTUSERNAME and  O.TRAGETDATE=T.TRAGETDATE  and o.RTYPE=T.RTYPE            
where SESSIONID=@SESSIONID and T.TRAGETDATE=@TragetDate and T.RTYPE =@Type             
) as seena where RTYPE='New'         
        
insert into RR_scoreboard(Userid,Cid,points,status,CreatedOn,ReferenceInfo,ReferenceId)        
select v.userid,B.cid,b.points,1,TRAGETDATE,'ARC_Rec_ProductionQT',pqtid        
from ARC_Rec_ProductionQT T          
inner join RR_CRITERA_MASTER b on b.cid in (28,29)         
inner Join ARC_REC_USER_INFO_VY V on V.nt_username=T.NTUSERNAME        
where T.Rtype=1 and b.STATUS =1  and T.PERCENTAGE>=b.startrange and T.PERCENTAGE<=b.endrange        
and pqtid not in (select ReferenceId from RR_scoreboard where ReferenceInfo='ARC_Rec_ProductionQT')        
        
        
End            
Else if @Type =2        
Begin            
select COUNT(*) TotalInserted from (            
select T.TRAGETDATE,T.NTUSERNAME,T.PTARGET,T.PACHIEVED,T.PERCENTAGE,            
RTYPE= case when O.NTUSERNAME=T.NTUSERNAME and  O.TRAGETDATE=T.TRAGETDATE  then 'Duplicate' else 'New' end                
from ARC_Rec_ProductionQT_Temp T            
left join ARC_Rec_ProductionQT O on O.NTUSERNAME=T.NTUSERNAME and  O.TRAGETDATE=T.TRAGETDATE   and o.RTYPE=T.RTYPE           
where SESSIONID=@SESSIONID and T.TRAGETDATE=@TragetDate and T.RTYPE =@Type             
) as seena where RTYPE='New'          
            
INSERT INTO ARC_REC_ProductionQT            
(TRAGETDATE,NTUSERNAME,PTARGET,PACHIEVED,PERCENTAGE,RTYPE,CreateBy,CreatedOn,StatusId )         
        
select TRAGETDATE,NTUSERNAME,PTARGET,PACHIEVED,PERCENTAGE,@Type,@CreatedBy,getdate(),1 from (            
select T.TRAGETDATE,T.NTUSERNAME,T.PTARGET,T.PACHIEVED,T.PERCENTAGE,            
RTYPE= case when O.NTUSERNAME=T.NTUSERNAME and  O.TRAGETDATE=T.TRAGETDATE  then 'Duplicate' else 'New' end                
from ARC_Rec_ProductionQT_Temp T            
left join ARC_Rec_ProductionQT O on O.NTUSERNAME=T.NTUSERNAME and  O.TRAGETDATE=T.TRAGETDATE  and o.RTYPE=T.RTYPE            
where SESSIONID=@SESSIONID and T.TRAGETDATE=@TragetDate and T.RTYPE =@Type             
) as seena where RTYPE='New'         
        
insert into RR_scoreboard(Userid,Cid,points,status,CreatedOn,ReferenceInfo,ReferenceId)        
select v.userid,B.cid,b.points,1,TRAGETDATE,'ARC_Rec_ProductionQT',pqtid    from ARC_Rec_ProductionQT T          
inner join RR_CRITERA_MASTER b on b.cid in (31,32)        
inner Join ARC_REC_USER_INFO_VY V on V.nt_username=T.NTUSERNAME        
where T.Rtype=2 and b.STATUS =1 and T.PERCENTAGE>=b.startrange and T.PERCENTAGE<=b.endrange        
and pqtid not in (select ReferenceId from RR_scoreboard where ReferenceInfo='ARC_Rec_ProductionQT')        
        
           
End        
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_PQT_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_PQT_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_PQT_Insert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_PQT_Insert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_PQT_Insert] TO [DB_DMLSupport]
    AS [dbo];

