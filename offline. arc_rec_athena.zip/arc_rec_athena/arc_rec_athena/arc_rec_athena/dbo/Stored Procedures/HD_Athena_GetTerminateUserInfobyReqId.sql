﻿CREATE PROCEDURE HD_Athena_GetTerminateUserInfobyReqId          
@ReqId int              
AS              
BEGIN        
--declare @ReqId as int=602    
declare @Userid as int    
select @Userid = UserId from HD_Athena_Terminate where ReqId = @ReqId    
    
IF OBJECT_ID('TEMPDB..#IsCitrixBoxrequired') IS NOT NULL DROP TABLE #IsCitrixBoxrequired        
create table #IsCitrixBoxrequired(UserId int,RoleId int, DeptId int, NeedCitrixBox char(1))    
insert into #IsCitrixBoxrequired(UserId,RoleId,DeptId,NeedCitrixBox)    
Exec HD_AthenaTransferIsRequiredCitrix @Userid = @Userid    
    
  
    
select ter.TerminateId,ter.ReqId, ir.TICKET_ID as TicketId,ter.UserId,    
ui.FIRSTNAME as FirstName ,ui.LASTNAME as LastName,    
[Department] = (Select Department from HD_Athena_Department Where DeptId =  isnull((Select top 1 DeptId from HD_Athena_Transfer Where UserId = ter.UserId Order by TransferId desc),
aur.DeptId))    
,[Role] = (Select Role from HD_Athena_Role Where RoleId =  isnull((Select top 1 RoleId from HD_Athena_Transfer Where UserId = ter.UserId Order by TransferId desc),
aur.RoleId))    
,(select case when NeedCitrixBox='Y' then 'N' when NeedCitrixBox = 'N' then  'Y' else '' end from #IsCitrixBoxrequired where UserId = @Userid ) as NeedCitrixBox    
,ter.CitrixReqId as [CitrixTktId]    
from HD_Athena_Terminate ter     
inner join (select UserId,MAX(AthenaUserId) as AthenaUserId from HD_AthenaUsers group by UserId) maxr on ter.UserId = maxr.UserId
left join HD_AthenaUsers aur on aur.AthenaUserId = maxr.AthenaUserId
inner join HD_ISSUE_REQUEST ir on ter.ReqId = ir.ISS_REQID          
inner join ARC_REC_USER_INFO ui on ui.USERID = ter.UserId        
where ter.ReqId = @ReqId and aur.[Status] = 3
          
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_GetTerminateUserInfobyReqId] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetTerminateUserInfobyReqId] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetTerminateUserInfobyReqId] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_GetTerminateUserInfobyReqId] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetTerminateUserInfobyReqId] TO [DB_DMLSupport]
    AS [dbo];

