﻿Create Procedure LoadCountries
@ACTION_NAME  varchar(200)
as
begin
Select CountryId,CountryName from ARC_REC_FootballCountries
end

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[LoadCountries] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[LoadCountries] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[LoadCountries] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[LoadCountries] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[LoadCountries] TO [DB_DMLSupport]
    AS [dbo];

