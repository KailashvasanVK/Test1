﻿CREATE procedure [dbo].[HD_CabAction]              
 @Action VARCHAR(75),                        
 @USERID INT=0,                  
 @Status INT,                       
 @ISS_REQID INT=0      
 AS      
Begin      
IF @Action = 'ARC_Cab_Details'                        
-- Purpose : To Cab Item Details for Cab Approve and Process                       
 BEGIN                        
  SELECT CR.ReqId, DBO.ConcatenateName(UI.FIRSTNAME,UI.MiddleName,UI.LASTNAME)+' ( '+UI.EMPCODE+' )' as Name,                        
  CR.AssociateId, REPLACE(CONVERT(VARCHAR(11), CR.TravelDt, 106), ' ', '-') AS TravelDt,                        
  (CASE CR.Mode WHEN 'D' THEN 'Drop' WHEN 'P' Then 'PickUp' END) as Mode,CR.Place,CR.LandMark,IR.TICKET_ID                      
  FROM HD_CabRequests AS CR                        
  INNER JOIN HD_ISSUE_REQUEST AS IR ON IR.ISS_REQID = CR.ReqId                        
  INNER JOIN ARC_REC_USER_INFO AS UI ON UI.USERID = CR.AssociateId                        
  WHERE CR.Status = @Status and CR.ReqId = @ISS_REQID ORDER BY Name                        
 END                        
IF @Action = 'ARC_CabTicketFlow'                        
-- Purpose : To Cab Item Details for Cab Approve                        
 BEGIN         
 declare @lastupdatedstatus as int        
   select @lastupdatedstatus =(select top 1 ISSUE_STATUS from HD_ISSUE_TRAN   
   where ISS_REQID = @ISS_REQID order by       CREATED_DT desc)       
   SELECT ReqId, DBO.ConcatenateName(UI.FIRSTNAME,UI.MiddleName,UI.LASTNAME)+' ( '+UI.EMPCODE+' )' as Name,                        
   CR.AssociateId, REPLACE(CONVERT(VARCHAR(11), CR.TravelDt, 106), ' ', '-') AS TravelDt,  
   CONVERT(varchar(15),CR.TravelTime,100) as TravelTime,        
   (CASE CR.Mode WHEN 'D' THEN 'Drop' WHEN 'P' THEN 'PickUp' END) as Mode,CR.Place,CR.LandMark,                    
   CASE WHEN @lastupdatedstatus = 0 and CR.[Status] = 0 THEN 'Pending - Supervisor Approval'             
   WHEN @lastupdatedstatus = 1 and CR.[Status] = 1 THEN 'Pending - Resolution'             
   WHEN @lastupdatedstatus = 1 and CR.[Status] = 2 THEN 'Rejected by Supervisor'          
   WHEN @lastupdatedstatus = 2 THEN 'Rejected by Supervisor'          
   WHEN @lastupdatedstatus = 3  and CR.[Status] = 1 THEN 'InProgress'            
   WHEN @lastupdatedstatus = 3  and CR.[Status] = 2 THEN 'Rejected by Supervisor'        
   WHEN @lastupdatedstatus = 4  THEN 'Request Released'         
   WHEN @lastupdatedstatus = 7  THEN 'Request Rejected'         
   WHEN @lastupdatedstatus = 8  and CR.[Status] = 3  THEN 'Provided and Waiting - Acknowledge'         
   WHEN @lastupdatedstatus = 8  and CR.[Status] = 4  THEN 'Rejected by Facility Team'         
   WHEN @lastupdatedstatus = 8  and CR.[Status] = 2  THEN 'Rejected by Supervisor'         
   WHEN @lastupdatedstatus = 5  and CR.[Status] = 5  THEN 'Completed'         
   WHEN @lastupdatedstatus = 5  and CR.[Status] = 4  THEN 'Rejected by Facility Team'        
   WHEN @lastupdatedstatus = 5  and CR.[Status] = 2  THEN 'Rejected by Supervisor'          
  else '' end as [Status]                      
  FROM HD_CabRequests AS CR                        
  INNER JOIN HD_ISSUE_REQUEST AS IR ON IR.ISS_REQID = CR.ReqId                        
  INNER JOIN ARC_REC_USER_INFO AS UI ON UI.USERID = CR.AssociateId                        
  WHERE CR.ReqId = @ISS_REQID ORDER BY Name      
 END                         
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_CabAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_CabAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_CabAction] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_CabAction] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_CabAction] TO [DB_DMLSupport]
    AS [dbo];

