﻿ CREATE Procedure ARC_REC_ActiveAssociatesNtInfo
(
 @frmDate date = null
,@toDate date = null
,@RptType varchar(1) = 'D' /* (D)etailed (S)ummary */
,@MonthWise varchar(1) = 'Y' /* (y)es (n)o */
,@SearchStr varchar(100) = ''
,@SearchPattern varchar(4) = '=' /** = or % **/     
)
As
Begin
/** Req Param 
--Declare @frmDate date
--Declare @toDate date
--Declare @RptType varchar(1) /* (D)etailed (S)ummary */
--Declare @MonthWise varchar(1) /* (y)es (n)o */
--Set @RptType = 'D'
--Set @MonthWise = 'Y'
--Set @frmDate = '2013-08-01' 
--Set @toDate = '2013-10-30'
**/


Declare @TblName varchar(25)=''
Declare @Orderby varchar(100) =''

if isnull(@frmDate,'')  = '' begin Set @frmDate = '1900-01-01' Set @toDate = CONVERT(date,getdate()) end
if OBJECT_ID('tempdb..#ActiveAss') is not null drop table #ActiveAss
Select Convert(varchar(50),ui.EMPCODE) AS [EmpCode]
,Convert(varchar,ui.NT_USERNAME) as [AssociateNtId]
,Convert(varchar,ui.FIRSTNAME) as [FirstName]
,Convert(varchar,ui.LASTNAME) as [LastName]
,Convert(varchar,cus.Client_Name) as [Client]
,Convert(varchar,func.FunctionName) [Functionality]
,Convert(varchar,ui.DOJ,101) as DOJ
,CONVERT(varchar(3),'')  as [ColHead]
,Convert(int,DATENAME(YEAR,ui.DOJ) + RIGHT('00' + Convert(varchar,DATEPart(MM,ui.DOJ)),2))  as [Month~Hide]
,CONVERT(int,1)  as [Result~Hide]
into #ActiveAss
from ARC_REC_USER_INFO as ui
inner join ARC_REC_CustomerView as cus on cus.Client_Id = ui.CLIENT_ID
inner join HR_Functionality as func on func.FunctionalityId = ui.FUNCTIONALITY_ID
Where ui.ACTIVE = 1 and ui.AHS_PRL = 'Y' and ui.DOJ between @frmDate and @toDate

if @RptType = 'D'
	Begin	
	set @TblName = '#ActiveAss'
	if ISNULL(@MonthWise,'') = 'Y'
		    Begin			
			set @Orderby = ' Order by [Month~Hide],[Result~Hide]'
 			Insert into #ActiveAss([AssociateNtId],[Month~Hide],[Result~Hide],ColHead)
			Select DATENAME(MONTH,DOJ) + ', ' +  DATENAME(YEAR,DOJ) + ' (' +  Convert(varchar,COUNT(*)) + ')'
			,Convert(int,DATENAME(YEAR,DOJ) + RIGHT('00' + Convert(varchar,DATEPart(MM,DOJ)),2))
			,0,'T'		 	
			 from #ActiveAss Group by DATENAME(MONTH,DOJ) + ', ' +  DATENAME(YEAR,DOJ),Convert(int,DATENAME(YEAR,DOJ) + RIGHT('00' + Convert(varchar,DATEPart(MM,DOJ)),2))
	        End
	End
Else if @RptType = 'S' /* Summary */
	Begin
	if OBJECT_ID('tempdb..#ActiveGAss') is not null drop table #ActiveGAss
	set @TblName = '#ActiveGAss'
		Select [Month],[Count],ColHead
		into #ActiveGAss
		from 
		(		
			Select DATENAME(MONTH,DOJ) + ', ' +  DATENAME(YEAR,DOJ) as [Month]
			,COUNT(*) as [Count],CONVERT(varchar(3),'') as ColHead
			from #ActiveAss Group by DATENAME(MONTH,DOJ) + ', ' +  DATENAME(YEAR,DOJ),Convert(int,DATENAME(YEAR,DOJ) + RIGHT('00' + Convert(varchar,DATEPart(MM,DOJ)),2))		
			Union all
			Select 'Grand Total' as [Month]
			,COUNT(*) as [Count],'G' as ColHead
			from #ActiveAss 
			)  as t
	End
	
Exec FilterTable    
  @DbName = 'tempdb'    
 ,@TblName = @TblName
 ,@SearchStr = @SearchStr
 ,@SearchPattern = @SearchPattern
 ,@OrderStr = @Orderby 
if OBJECT_ID('tempdb..#ActiveAss') is not null drop table #ActiveAss
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ActiveAssociatesNtInfo] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ActiveAssociatesNtInfo] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ActiveAssociatesNtInfo] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ActiveAssociatesNtInfo] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ActiveAssociatesNtInfo] TO [DB_DMLSupport]
    AS [dbo];

