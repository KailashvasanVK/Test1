﻿--ARC_REC_AssociateCustomerStatus 432
CREATE procedure [dbo].[ARC_REC_AssociateCustomerStatus]        
      @ASSOCIATE_ID INT        
As        
begin        

select rep.FIRSTNAME+' '+rep.LASTNAME+' ('+rep.EMPCODE+')' As Reproting_person,rep.USERID as ReportingPersonId from ARC_REC_USER_INFO ui        
inner join ARC_REC_USER_INFO rep on ui.REPORTING_TO = rep.NT_USERNAME        
where ui.USERID = @ASSOCIATE_ID        
        
select ui.CLIENT_ID,cl.CLIENT_NAME  from ARC_REC_USER_INFO ui         
inner join ARC_FIN_CLIENT_INFO cl on ui.CLIENT_ID = cl.CLIENT_ID        
where ui.USERID = @ASSOCIATE_ID             
    
end  
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_AssociateCustomerStatus] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AssociateCustomerStatus] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AssociateCustomerStatus] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_AssociateCustomerStatus] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AssociateCustomerStatus] TO [DB_DMLSupport]
    AS [dbo];

