﻿CREATE procedure ARC_REC_Validate_NTlogin  
      @NTLOGINS VARCHAR(MAX)  
As  
BEGIN  
  
if OBJECT_ID('tempdb..#Ntlogin') is not null drop table #Ntlogin              
create table #Ntlogin(NT_USERNAME varchar(100))            
Insert into #Ntlogin(NT_USERNAME)          
Select items from dbo.fnSplitString(@NTLOGINS,'-')       
  
select NT_USERNAME from #Ntlogin where NT_USERNAME in (
select NT_USERNAME from ARC_REC_USER_INFO
)  or NT_USERNAME in (Select NT_USERNAME from #Ntlogin group by NT_USERNAME having count(*)>1) 
END

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_Validate_NTlogin] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Validate_NTlogin] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Validate_NTlogin] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_Validate_NTlogin] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Validate_NTlogin] TO [DB_DMLSupport]
    AS [dbo];

