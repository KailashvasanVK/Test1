﻿CREATE PROCEDURE [dbo].[HD_Athena_NewHireApprovalUpdate]   
  @ReqId INT
 ,@CreatedBy INT
 ,@Status int
 ,@AthenaUserIds VARCHAR(MAX) = ''      
AS  
BEGIN  

if(@Status = 1)
begin
  update HD_AthenaUsers set
  [Status] = @Status
  where Issue_ReqId = @ReqId and AthenaUserId in (SELECT items FROM fnSplitString(@AthenaUserIds,','))
  
  update HD_AthenaUsers set
  [Status] = 2
  where Issue_ReqId = @ReqId and [status] = 0
  and AthenaUserId not in (SELECT items FROM fnSplitString(@AthenaUserIds,','))
  
 end
END

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_NewHireApprovalUpdate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_NewHireApprovalUpdate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_NewHireApprovalUpdate] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_NewHireApprovalUpdate] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_NewHireApprovalUpdate] TO [DB_DMLSupport]
    AS [dbo];

