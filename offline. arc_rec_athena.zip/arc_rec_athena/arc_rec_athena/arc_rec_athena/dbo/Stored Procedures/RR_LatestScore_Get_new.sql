﻿CREATE PROCEDURE RR_LatestScore_Get_new                                                
@PageIndex INT = 1                                                                
,@PageSize INT = 30                                                                
,@PageCount INT OUTPUT                    
AS                                                  
/*                                                
      
Created By  : Udhayaganesh P                                           
      
Purpose     : Get the Latest update's of Associate Events                
      
      
Exec RR_LatestScore_Get 1,20,0               
      
      
*/                                                
BEGIN                                                  
SET NOCOUNT ON;                                                  
SELECT ROW_NUMBER() OVER                                                  
(                                                  
ORDER BY ls.CreatedOn desc                                                  
)AS RowNumber                                                  
,UI.USERID                                                
,' received '+ CONVERT(VARCHAR, LS.Points) +' SDPs '+CM.Feeds As Points             
,isnull('https://arc.accesshealthcare.co/arc_rec/images/candidate/'+c.PROFILE_IMAGE_NAME,'https://arc.accesshealthcare.co/arc_rec/images/userimg.jpg') as REC_ID                                                
,FIRSTNAME +' '+ LASTNAME+' ' As Name                                                     
,NT_USERNAME                                                  
,EMPCODE                                                  
,REPORTING_TO                                                
, [Time]=(case      
when DATEDIFF(MINUTE,LS.createdon,GETDATE())>=0  and DATEDIFF(MINUTE,LS.createdon,GETDATE())<2   then CONVERT(varchar(10),DATEDIFF(MINUTE,LS.createdon,GETDATE()))+' minute ago'       
when DATEDIFF(MINUTE,LS.createdon,GETDATE())>=2  and DATEDIFF(MINUTE,LS.createdon,GETDATE())<60  then CONVERT(varchar(10),DATEDIFF(MINUTE,LS.createdon,GETDATE()))+' minutes ago'      
when DATEDIFF(MINUTE,LS.createdon,GETDATE())>=60 and DATEDIFF(MINUTE,LS.createdon,GETDATE())<120 then CONVERT(varchar(10),DATEDIFF(MINUTE,LS.createdon,GETDATE())/60)+' hour ago'      
when DATEDIFF(MINUTE,LS.createdon,GETDATE())>=120 and DATEDIFF(MINUTE,LS.createdon,GETDATE())<1440 then CONVERT(varchar(10),DATEDIFF(MINUTE,LS.createdon,GETDATE())/60)+' hours ago'         
when DATEDIFF(day,LS.createdon,GETDATE())>=1 and DATEDIFF(day,LS.createdon,GETDATE())<2 then CONVERT(varchar(10),DATEDIFF(day,LS.createdon,GETDATE()))+' day ago'                                       
when DATEDIFF(day,LS.createdon,GETDATE())>=2 then CONVERT(varchar(10),DATEDIFF(day,LS.createdon,GETDATE()))+' days ago'end )                                             
,FIRSTNAME,ls.CreatedOn,ci.CLIENT_NAME Client                                               
INTO #Results                                                  
FROM ARC_REC_USER_INFO  UI                                        
Inner JOin RR_SCOREBOARD LS on LS.userid=UI.USERID                                        
inner join RR_CRITERA_MASTER CM on CM.CID=LS.CID                          
inner join ARC_FIN_CLIENT_INFO CI on CI.CLIENT_ID=ui.CLIENT_ID             
inner join ARC_REC_CANDIDATE C on c.REC_ID=ui.REC_ID                                                         
where UI.ACTIVE=1 and UI.AHS_PRL='Y'                         
      
DECLARE @RecordCount INT                                                                
SELECT @RecordCount = COUNT(*) FROM #Results                                                                
      
SET @PageCount = CEILING(CAST(@RecordCount AS DECIMAL(10, 2)) / CAST(@PageSize AS DECIMAL(10, 2)))                                                                
PRINT       @PageCount                       
      
SELECT * FROM #Results                                                  
WHERE RowNumber BETWEEN(@PageIndex -1) * @PageSize + 1 AND(((@PageIndex -1) * @PageSize + 1) + @PageSize) - 1                         
      
      
DROP TABLE #Results                                                   
END
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_LatestScore_Get_new] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_LatestScore_Get_new] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_LatestScore_Get_new] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_LatestScore_Get_new] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_LatestScore_Get_new] TO [DB_DMLSupport]
    AS [dbo];

