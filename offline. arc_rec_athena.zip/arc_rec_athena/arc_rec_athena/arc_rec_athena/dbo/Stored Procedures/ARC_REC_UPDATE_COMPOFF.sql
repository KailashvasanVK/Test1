﻿--ARC_REC_UPDATE_COMPOFF 1792,'ADD','3/29/2014 12:00:00 AM','Comp Off Added',1608,null
CREATE Procedure ARC_REC_UPDATE_COMPOFF          
 @UserID Varchar(Max)             
,@CompOffStatus Varchar (40)          
,@CompOffDate Date          
,@Comments Varchar(3000)          
,@CreatedBy INT           
,@Response varchar(max) OUT           
 As          
 Begin          
           
 Declare @CurDate as date                
 Declare @Pay_MaxDate as date              
 Select @CurDate = convert(date ,GETDATE())                 
 Select @Pay_MaxDate = MAX(PAY_ROLL_DATE) from ARC_ME_PAYROLL             
 if (CONVERT(date ,@CompOffDate) > @CurDate )          
  begin          
   select @Response = 'Please select valid comp-off date';          
   return;          
  end            
 --else if (@Pay_MaxDate > CONVERT(date ,@CompOffDate))      
 -- begin          
 --  select @Response = 'The comp-off date must be greater than payroll date!';          
 --  return;          
 -- end            
 else if @CompOffStatus = 'ADD' or @CompOffStatus = 'REMOVE'         
  begin          
   Select @Response = 'SUCCESS';   
        
   if OBJECT_ID('tempdb..#CompOffupdateUsers') IS NOT NULL DROP TABLE #CompOffupdateUsers   
   create table #CompOffupdateUsers(UserId int,Att_Date date)  
   insert into #CompOffupdateUsers(UserId,Att_Date)  
   select items,@CompOffDate from fnSplitString(@UserID,',')  
     
    Update ARC_REC_Attendance Set CompOffEligible = case when @CompOffStatus = 'ADD' then 1 else 0 end  
   where Date = Convert(Date, @CompOffDate) AND Userid IN (select UserId from #CompOffupdateUsers)   
     
    insert into ARC_Me_CompOffUpdates(UserId,Att_Date,IsCompOffEligible,Comments,CreatedBy,CreatedDt)                   
   select UserId,Att_Date,case when @CompOffStatus = 'ADD' then 1 else 0 end,@Comments,@CreatedBy,GETDATE()   
   from #CompOffupdateUsers where UserId in (select Userid from ARC_REC_Attendance where [Date] = Convert(Date, @CompOffDate) AND Userid IN (select UserId from #CompOffupdateUsers) )  
     
  end          
  
 END
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_UPDATE_COMPOFF] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UPDATE_COMPOFF] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UPDATE_COMPOFF] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_UPDATE_COMPOFF] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UPDATE_COMPOFF] TO [DB_DMLSupport]
    AS [dbo];

