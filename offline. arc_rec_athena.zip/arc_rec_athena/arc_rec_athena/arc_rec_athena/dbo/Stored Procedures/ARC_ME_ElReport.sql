﻿--ARC_ME_ElReport @Action='PayEL',@Month=5,@Year=2014,@Active=2,@ElEligility=1
CREATE Procedure ARC_ME_ElReport    
(   
@Action varchar(10)='',   
@Active int = 1 /** Mandatory **/    
,@Month int = 1 /** Mandatory **/    
,@Year int = 2014 /** Mandatory **/    
,@ElEligility int = 1 /** Optional - by default 0 **/    
,@SearchStr varchar(100) = ''      
,@SearchPattern varchar(4) = '=' /** = or % **/     
)    
As    
Begin  
--declare @Action varchar(100)='PayEL'  
--Declare @Active int = 0 /** Mandatory **/    
--Declare @Month int = 5 /** Mandatory **/    
--Declare @Year int = 2014 /** Mandatory **/    
--Declare @ElEligility int = 1  
--Declare @SearchStr varchar(100) = ''      
--Declare @SearchPattern varchar(4) = '=' /** = or % **/     
    
Declare @RptLastDate date = DateAdd(DD,-1,dateadd(mm,1, Convert(date,Convert(varchar,@Year) + '-' + Convert(varchar,@Month) + '-01')))    
Declare @Qry varchar(max)    
if OBJECT_ID('tempdb..#ElUsers') is not null drop table #ElUsers    
Create Table #ElUsers(UserId int,EmpCode varchar(10),Doj date,PreDoj date)    
Set @Qry = '    
Insert into #ELUsers(userId,Empcode,Doj,PreDoj)    
Select ui.USERID,ui.EMPCODE,ui.DOJ as Doj,ui.PreDoj    
from ARC_REC_USER_INFO as ui    
Where ui.AHS_PRL = ''Y'' and DATEDIFF(MM,ISNULL(PreDoj,Doj),GETDATE()) >= 13 and ACTIVE in (1,2)'    
if @Active = 2 Set @Qry += ' And UserId in (Select UserId from ARC_REC_AssociateDOLView Where DOL <= '''+CONVERT(varchar,@RptLastDate)+''')'    
print (@Qry)    
Exec (@Qry)    
    
if OBJECT_ID('tempdb..#ElTable') is not null drop table #ElTable    
Select ui.USERID,isnull(opeIT.Leaves,ope.LEAVES) as Leaves, Convert(varchar(30),'Opening') as Sep    
into #ElTable    
from #ElUsers as ui    
left join ARC_REC_LEAVE_OPENING as ope on ope.Employee_Id = ui.UserId and datepart(YYYY,ope.OPENING_DATE) = @Year - 1 and ope.TYPEID = 3    
left join ARC_REC_LeaveOpeningForITNet as opeIT on opeIT.Employee_Id = ui.UserId and datepart(YYYY,opeIT.OPENING_DATE) = @Year and opeIT.TYPEID = 3    
    
Set @Qry = ''    
Declare @tMonth int = 1    
While @tMonth <= @Month    
Begin    
Declare @tDate date = Convert(date,Convert(varchar,@year) + '-' + convert(varchar,@tMonth) + '-01')    
Insert into #ElTable(USERID,Leaves,Sep)    
Select USERID,1 as Leaves    
,DATENAME(MM,@tdate) from #ElUsers     
Where DATEDIFF(MM,ISNULL(PreDoj,Doj),@tDate) >= 13 and @tDate > Doj     
    
Insert into #ElTable(USERID,Leaves,Sep)    
Select LR.CREATED_BY as UserId,-1*Sum(Case when LR.LEAVE_MODE = 'F' then 1 when LR.LEAVE_MODE = 'H' then 0.5 else 0 end) as LeaveDays    
,DateName(MM,LT.LEAVE_DATE) as MMonth    
from ARC_REC_LEAVE_REQUEST as LR    
inner join ARC_REC_LEAVE_TRAN as LT on LT.LEAVE_REQID = LR.LEAVE_REQID and DatePart(YYYY,LT.LEAVE_DATE) = @Year and DATEPART(MM,LT.Leave_Date) = DatePart(MM,@tDate)    
where LR.TYPEID = 3     
Group by LR.CREATED_BY,DateName(MM,LT.LEAVE_DATE)     
    
Set @qry += '    
,Convert(Decimal(9,2),Sum(Case When Sep = '''+DateName(MM,@tDate)+''' then Leaves else 0 end)) as [' + DateName(MM,@tDate) + ']'    
--Set @qry = 'Alter table #ElUsers Add [' + Substring(DATENAME(MM,@tdate),1,3) + ', Cr] Decimal(9,2)    
--Alter table #ElUsers Add [' + Substring(DATENAME(MM,@tdate),1,3) + ', Availed] Decimal(9,2)'    
--Exec (@qry)    
Set @tMonth +=1    
End    
If OBJECT_ID('tempdb..#tempELBalance') is not null drop table #tempELBalance    
Set @qry = 'Select el.UserId,ui.EmpCode,dbo.ConcatenateName(ui.FirstName,ui.MiddleName,ui.LastName) as [Name],desig.Designation,    
func.FunctionName [Functionality],ci.Client_Name [Client],Convert(Decimal(9,2),Sum(Case When Sep = ''Opening'' then Leaves else 0 end)) as [Opening]' + @qry +    
',Convert(decimal(9,2),0) as [Settled]  
,Convert(decimal(9,2),Sum(isnull(Leaves,0))) as [Closing]  
,case when ui.active = 1 then ''Active'' else ''Resigned'' end as Status    
into #tempELBalance    
from #ElTable as el    
inner join arc_rec_user_info as ui on ui.userid = el.UserId    
inner join HR_Designation as desig on desig.DesigId = ui.DESIGNATION_ID    
inner join HR_Functionality as func on func.FunctionalityId = ui.FUNCTIONALITY_ID    
inner join ARC_FIN_CLIENT_INFO as ci on ci.Client_Id = ui.CLIENT_ID    
Group by el.USERID,ui.EmpCode,ui.FirstName,ui.MiddleName,ui.LastName,desig.Designation,func.FunctionName,ci.Client_Name,ui.active'    
  
   
Set @qry = @qry +' Update #tempELBalance  Set Settled = (select count(userid)*24 from ARC_REC_LEAVES_EL_Settled where userid = t.userid)  
from #tempELBalance  as t  
Update #tempELBalance  Set [Closing] = [Closing] - isnull(Settled,0) ' 
 if @ElEligility = 1 and @Action = 'PayEL' and @Active  = 1 Set @Qry += '  
select ''<button onclick="return OpenDialog('''''''+'+EmpCode+'+''''''');"                 
class="Action ui-button ui-widget ui-state-default ui-corner-all ui-button-icon-only" id="btnAckAction" role="button" aria-disabled="false" title="Pay EL">                                  
<span class="ui-button-icon-primary ui-icon ui-icon-copy"></span><span class="ui-button-text">Pay Earned Leave</span></button>'' [ACTION],* into #tempELBalanceNew from #tempELBalance   
 where [Closing] >= 24 and [Status]  = ''Active'''   
  
 else if @ElEligility = 1 and @Action = 'PayEL' and @Active  = 2  Set @Qry += '  
select ''<button onclick="return OpenDialog('''''''+'+EmpCode+'+''''''');"                 
class="Action ui-button ui-widget ui-state-default ui-corner-all ui-button-icon-only" id="btnAckAction" role="button" aria-disabled="false" title="Pay EL">                                  
<span class="ui-button-icon-primary ui-icon ui-icon-copy"></span><span class="ui-button-text">Pay Earned Leave</span></button>'' [ACTION],* into #tempELBalanceNew from #tempELBalance   
 where [Closing] >= 24 and [Status]  = ''Resigned'''  
 
 else if @ElEligility = 1 and @Active  = 1
 set @Qry += ' select * into #tempELBalanceNew from #tempELBalance where [Closing] >= 24  and [Status]  = ''Active'''    
 else if @ElEligility = 1 and @Active  = 2
 set @Qry += ' select * into #tempELBalanceNew from #tempELBalance where [Closing] >= 24  and [Status]  = ''Resigned''' 
  else if @ElEligility = 1
  set @Qry += ' select * into #tempELBalanceNew from #tempELBalance where [Closing] >= 24 '
 else  
 Set @Qry += ' select * into #tempELBalanceNew from #tempELBalance '  
  
declare @QryExec varchar(max)    
set @QryExec = '    
Exec FilterTable     
@DbName = ''tempdb'',    
@TblName = ''#tempELBalanceNew'',    
@SearchStr = ''' + @SearchStr + ''',    
@SearchPattern =''' +  @SearchPattern + ''',    
@OrderStr = '''' '    
print (@Qry +' '+ @QryExec )    
Exec (@Qry +' '+ @QryExec )    
End  
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_ElReport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_ElReport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_ElReport] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_ElReport] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_ElReport] TO [DB_DMLSupport]
    AS [dbo];

