﻿CREATE procedure HD_Athena_TerminateUpdreqId           
      @ReqId int                                           
      ,@CitrixReqId varchar(50)            
      ,@UpdatedBy int        
      ,@Comments varchar(2000)    
As            
begin              
update HD_Athena_Terminate set
CitrixReqId = @CitrixReqId,Comments = @Comments
where ReqId = @ReqId
end 

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_TerminateUpdreqId] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_TerminateUpdreqId] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_TerminateUpdreqId] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_TerminateUpdreqId] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_TerminateUpdreqId] TO [DB_DMLSupport]
    AS [dbo];

