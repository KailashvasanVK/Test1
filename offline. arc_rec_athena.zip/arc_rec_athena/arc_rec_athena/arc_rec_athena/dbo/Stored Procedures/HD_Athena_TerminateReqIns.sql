﻿CREATE procedure [dbo].[HD_Athena_TerminateReqIns]            
      @ReqId int,            
      @UserId int,               
      @CreatedBy int                        
AS            
Begin            
insert into HD_Athena_Terminate(ReqId,UserId,CreatedBy,CreatedDt,[Status])      
select @ReqId,@UserId,@CreatedBy,GETDATE(),0            
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_TerminateReqIns] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_TerminateReqIns] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_TerminateReqIns] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_TerminateReqIns] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_TerminateReqIns] TO [DB_DMLSupport]
    AS [dbo];

