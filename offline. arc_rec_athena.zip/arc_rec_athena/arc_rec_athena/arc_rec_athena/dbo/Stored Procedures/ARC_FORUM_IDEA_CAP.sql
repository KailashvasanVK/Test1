﻿CREATE PROC ARC_FORUM_IDEA_CAP      
@NT_Username Varchar(100)='Udhayaganesh.p'  
/*   
  
ARC_FORUM_IDEA_CAP 'krishnan.mariap'   
  
select top 1 * from ARC_Forum_USER_IDEAS where Created_by ='krishnan.mariap' order by 

 created_on desc 

select datediff(minute,'2014-02-19 00:58:56.453',getdate())

select 1440/60

*/      
AS      
Begin    
  
Declare @lastpost Datetime  

select top 1  @lastpost=created_on from ARC_Forum_USER_IDEAS where Created_BY=@NT_Username  order by created_on desc 
 print @lastpost
 If exists (Select Top 1 'x'from ARC_Forum_USER_IDEAS where Created_BY=@NT_Username and        
 DATEDIFF(minute,@lastpost,GETDATE())<=(1440+30))        
 Begin        
 Select 'Your Idea Post Quota Exceed Today !..' Message        
 End    

End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FORUM_IDEA_CAP] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_IDEA_CAP] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_IDEA_CAP] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FORUM_IDEA_CAP] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_IDEA_CAP] TO [DB_DMLSupport]
    AS [dbo];

