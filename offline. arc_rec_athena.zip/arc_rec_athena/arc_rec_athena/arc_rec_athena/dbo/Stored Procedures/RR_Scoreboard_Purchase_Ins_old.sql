﻿CREATE Proc [dbo].[RR_Scoreboard_Purchase_Ins_old]                            
@LLID int,                            
@Pid int,                            
@Userid int,                            
@PurchaseType tinyint                            
AS                            
/*                            
                            
Created By : Udhayaganesh P                            
                            
Purpose    : Redeem the gift                            
                            
select * from rr_Leaguelevel                    
                         
                            
Exec RR_Scoreboard_Purchase_Ins @LLID=1,@Pid=2,@Userid=807,@PurchaseType=1  
  
  
exec RR_Scoreboard_Purchase_Ins @LLID=1,@Pid=7,@Userid=807,@PurchaseType=3  
                         
                            
*/                            
Begin                            
If @PurchaseType=1 /* Purchase a gift */                            
Begin                           
IF exists (select 'x' from RR_UserBanner UB                         
inner join RR_product_details PM on pm.PurchasePoint<= (case when ub.LLId =1 then  ub.PrchPoint            
when ub.LLId =2 then  ub.PrchPoint - 50000           
when ub.LLId =3 then  ub.PrchPoint  - 150000          
when ub.LLId =4 then  ub.PrchPoint  - 300000          
when ub.LLId =5 then  ub.PrchPoint  - 600000 end)          
where USERID=@Userid and pm.Pid=@Pid and pm.LLID=@LLID )                        
 begin                    
 if exists(select 'x' from RR_product_details where LLID =@LLID and ImageType <>2 and Pid=@Pid )                
 begin                    
 insert into RR_Scoreboard_Purchase(userid,Pid,Purchased,RequestedOn,purchasestatus)                            
 select @Userid,@Pid,0,GETDATE(),@PurchaseType                            
 Select 'Great Pick!' As 'Output'                 
 end                
 else                
 begin                
  insert into RR_Scoreboard_Purchase(userid,Pid,Purchased,RequestedOn,purchasestatus)                            
 select @Userid,Pid,0,GETDATE(),3  from RR_product_details  where LLID =@LLID and ImageType<>2                 
 and Pid not IN (select Pid from RR_Scoreboard_Purchase where Userid =@Userid and LLID =@LLID)          
 union                
 select @Userid,@Pid,0,GETDATE(),1                
 Select 'Great Pick!' As 'Output'                 
 end                           
 End                            
 else                        
 begin                        
 select 'Oops! You are not eligible to redeem this!'  As 'Output'                            
 End                        
End                        
Else if @PurchaseType=2                            
begin                            
 IF exists (select 'x' from RR_UserBanner UB                         
inner join RR_product_details PM on pm.PurchasePoint<= (case when ub.LLId =1 then  ub.PrchPoint            
when ub.LLId =2 then  ub.PrchPoint - 50000           
when ub.LLId =3 then  ub.PrchPoint  - 150000          
when ub.LLId =4 then  ub.PrchPoint  - 300000          
when ub.LLId =5 then  ub.PrchPoint  - 600000 end)            
where USERID=@Userid and pm.Pid=@Pid and pm.LLID=@LLID )                        
 begin                           
 --insert into RR_Scoreboard_Purchase(userid,Pid,Purchased,RequestedOn,purchasestatus)                            
 --select @Userid,@Pid,0,GETDATE(),@PurchaseType                            
 Select 'Yay! Awesome deal!' As 'Output'                          
 End                            
 else                        
 begin                        
 select 'Oops! You are not eligible to redeem this!'  As 'Output'                            
 End                          
end                            
Else if @PurchaseType=3                            
Begin                            
if not exists (select top 1 'x' from RR_Scoreboard_Purchase SP                             
inner join RR_product_details PD on SP.pid=Pd.pid and llid=@llid and sp.PurchaseStatus=1 and USERID=@Userid )                            
 Begin                 
 IF exists (select 'x' from RR_UserBanner UB                         
inner join RR_product_details PM On pm.PurchasePoint<= (case when ub.LLId =1 then  ub.PrchPoint            
when ub.LLId =2 then  ub.PrchPoint - 50000           
when ub.LLId =3 then  ub.PrchPoint  - 150000          
when ub.LLId =4 then  ub.PrchPoint  - 300000          
when ub.LLId =5 then  ub.PrchPoint  - 600000 end)           
where USERID=@Userid and pm.ImageType=2 and pm.LLID=@LLID )                        
 begin                          
 insert into RR_Scoreboard_Purchase(userid,Pid,Purchased,RequestedOn,purchasestatus)                            
              
 --select @Userid Userid,Pid,0,GETDATE()eventdate,@PurchaseType purchasestatus               
 --from RR_product_details where ImageType <>2 and  llid=@llid                      
 --union                
 select @Userid,Pid,0,GETDATE(),1 from RR_product_details where ImageType =2 and  llid=@llid and pid=@Pid               
                        
 Select 'Woohoo! That’s a striking choice!' As 'Output'                            
 end              
 Else                            
 begin                            
  select 'Oops! You are not eligible to redeem this!'  As 'Output'                            
 End               
 END                            
 Else                            
 begin                            
  select 'Oops! You are not eligible to redeem this!'  As 'Output'                            
 End                            
End                            
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Scoreboard_Purchase_Ins_old] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Scoreboard_Purchase_Ins_old] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Scoreboard_Purchase_Ins_old] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Scoreboard_Purchase_Ins_old] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Scoreboard_Purchase_Ins_old] TO [DB_DMLSupport]
    AS [dbo];

