﻿CREATE procedure ARC_REC_SupervisorConfig              
      @USER_ID int,                      
      @SUPERVISOR_ID INT,                      
      @CUSTOMER_IDS varchar(max),      
      @PRIORITY_CUSTOMER INT,                      
      @CREATED_BY INT          
As              
Begin              
Declare @Reporting varchar(200)                              
select @Reporting = NT_USERNAME from ARC_REC_USER_INFO where USERID = @SUPERVISOR_ID                                       
if OBJECT_ID('tempdb..#CustomerConfig') is not null drop table #CustomerConfig                        
create table #CustomerConfig(USERID int,SUPERVOSOR_ID int,CUSTOMER_ID int,PrimaryCust bit default 0,RwId int identity)                      
Insert into #CustomerConfig(USERID,SUPERVOSOR_ID,CUSTOMER_ID)                    
Select @USER_ID,@SUPERVISOR_ID,items from dbo.fnSplitString(@CUSTOMER_IDS,',')           
  
Update #CustomerConfig Set PrimaryCust = @PRIORITY_CUSTOMER  
  
declare @OldReportingto int
select @OldReportingto = USERID from ARC_REC_USER_INFO where NT_USERNAME = (select REPORTING_TO from ARC_REC_USER_INFO where USERID = @USER_ID)
insert into ARC_REC_Superviosrlog(UserId,SupervisorId,CreatedBy,CreatedDt,OldReportingTo)                
select @USER_ID,@SUPERVISOR_ID,@CREATED_BY,GETDATE(),@OldReportingto
  
Exec [ARC_UserCustomerMove] @UserId = @User_ID  
--Update ARC_REC_UserCustomerLog Set Active = 0 Where UserId = @USER_ID and CONVERT(date,CREATED_DT) = CONVERT(date,getdate())  
  
--Declare @CustomerLogGroupId int = isnull((Select MAX(LogGroupId) from ARC_REC_UserCustomerLog),0) + 1  
--insert into ARC_REC_UserCustomerLog(UCid,UserId,CustomerID,CREATED_BY,CREATED_DT,PrimaryCust,LogGroupId)  
--select UCid,UserId,CustomerID,CREATED_BY,CREATED_DT,PrimaryCust,@CustomerLogGroupId from ARC_REC_UserCustomer where UserId = @USER_ID  
--delete from ARC_REC_UserCustomer where UserId = @USER_ID 

declare @OldCustomerId int
select @OldCustomerId = LastCustomerId from ARC_REC_USER_INFO where USERID = @USER_ID
   
  
insert into ARC_REC_UserCustomer(UserId,CustomerId,CREATED_BY,CREATED_DT,PrimaryCust,OldCustomerId)  
select @USER_ID,CUSTOMER_ID,@CREATED_BY,GETDATE(),PrimaryCust,@OldCustomerId from #CustomerConfig  
        
--insert into ARC_REC_CustomerLog(UserId,CustomerId,CreatedBy,CreatedDt)              
--select USERID,CUSTOMER_ID,@CREATED_BY,GETDATE() from #CustomerConfig           
Declare @LastCustomerId int 
Select top 1 @LastCustomerId = cc.CUSTOMER_ID from #CustomerConfig as cc
inner join ARC_Flow_Athena..ADM_Customer as ac on ac.CustomerId = cc.CUSTOMER_ID and isnull(ac.CmpKey,'') <> ''
Order by cc.RwId

update ARC_REC_USER_INFO set  
REPORTING_TO = @Reporting,  
CLIENT_ID = @PRIORITY_CUSTOMER, --later on insert into UserCustomer  
LastCustomerId = @LastCustomerId  --later on insert into UserCustomer  
where USERID = @USER_ID  

  
End  





GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_SupervisorConfig] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_SupervisorConfig] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_SupervisorConfig] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_SupervisorConfig] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_SupervisorConfig] TO [DB_DMLSupport]
    AS [dbo];

