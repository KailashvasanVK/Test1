﻿
CREATE Proc ARC_ME_MonthlyAttendanceView    
(    
  @FromDate date /* Mandatory */    
 ,@ToDate date /* Mandatory */    
 ,@SessionUserId int/* Mandatory */    
 ,@FunctionalityID int = 0 /* Optional by default 0 if session user is normal or supervisor */    
 ,@ClientID int = 0 /* Optional by default 0 if session user is normal */    
 ,@Active int = 1 /* Optional by default 1 if session user is normal */    
 ,@UserId int = 0 /* Optional by default 1 if session user is normal */    
 ,@View VARCHAR(50) = 'Detailed'/* Detailed,Summary,DateWise */   
 ,@SupListAll varchar(1) = 'N' /* List all associates comes under @sessionUser **/  
 ,@SearchStr varchar(100) = ''                            
 ,@SearchPattern varchar(4) = '=' /** = or % **/     
)    
As    
Begin    
--select * from ARC_REC_USER_INFO where EMPCODE = 'e022278'

SET FMTONLY OFF    
SET NOCOUNT ON    
------ARC_ME_MonthlyAttendanceView @FromDate='1-Jan-214',@ToDate='6-Jan-2014',@SessionUserId=7,@UserId=0,@Active=1,@FunctionalityID=0,@ClientID=0,@View='Summary'  
------ARC_ME_MonthlyAttendanceView @FromDate='1-Jan-2014',@ToDate='6-Jan-2014',@SessionUserId=1,@UserId=1,@Active=1,@FunctionalityID=0,@ClientID=0,@View='DateWise',@SupListAll = 'Y'
------ARC_ME_MonthlyAttendanceView  @FromDate='01-Dec-2013',@ToDate='31-Dec-2013',@SessionUserId=1,@UserId=0,@Active=1,@FunctionalityID=0,@ClientID=0,@View='Detailed'  
----Declare @SupListAll varchar(1) 
----Declare @FromDate date = '2014-06-01' /* Mandatory */    
----Declare @ToDate date = '2014-06-30' /* Mandatory */    
----Declare @FunctionalityID int = 0 /* Optional by default 0 if session user is normal or supervisor */    
----Declare @ClientID int = 0 /* Optional by default 0 if session user is normal */    
----Declare @Active int = 1 /* Optional by default 1 if session user is normal */    
----Declare @UserId int = 1687 /* Optional by default 1 if session user is normal */    
----Declare @SessionUserId int = 1687--19 /* Mandatory */    
----Declare @View VARCHAR(50) = 'detailed'/* Detailed,Summary,DateWise */    
----Declare @SearchStr varchar(100) = ''                            
----Declare @SearchPattern varchar(4) = '=' /** = or % **/     

if Isnull(@SupListAll,'') = '' Set @SupListAll = 'N'  
Declare @tQry varchar(max)  
Declare @Qry varchar(max)    
Begin /** Select Associate based on param filter **/    
If OBJECT_ID('tempdb..#Att_Users') is not null drop table #Att_Users    
Create table #Att_Users(Userid int)      
If isnull(@UserId,0) <> 0  and @SupListAll = 'N'   
 Insert into #Att_Users(Userid)Select @UserId
Else    
  Begin    
 Set @Qry = 'Insert into #Att_users(Userid)     
 Select Userid from ARC_REC_USER_INFO where isnull(EmpCode,'''') <> '''' and isnull(AHS_PRL,''Y'') = ''Y'' and Active = '+ Case when @Active = 1 then '1' else '2' end +''    
  if @FunctionalityID > 0      
 Set @Qry += ' and FUNCTIONALITY_ID = '+convert(varchar,@FunctionalityID)      
  if @ClientID > 0      
     Set @Qry += ' and CLIENT_ID = '+convert(varchar,@ClientID)    
  if @Active <> 1  
  Set @Qry += ' and UserId in (Select UserId from ARC_REC_AssociateDOLView Where DOL Between '''+CONVERT(varchar,@FromDate)+''' and '''+CONVERT(varchar,@ToDate)+''')'  
  if @SupListAll = 'Y'  
 Begin    
 Set @tQry = '
 Insert into #Att_Users(Userid)Select UserId from ARC_REC_USER_INFO Where USERID = '+CONVERT(varchar,@UserId)+'
 and isnull(AHS_PRL,''Y'') = ''Y'' and Active = '+ Case when @Active = 1 then '1' else '2' end +''
 Exec(@tQry)
 Set @Qry += ' and Reporting_To = (Select NT_USERNAME from ARC_REC_USER_INFO Where UserId = '+Convert(varchar,@UserId)+')'    
 End          
  if @SupListAll = 'N' and (Select COUNT(*) from ARC_REC_USER_INFO where USERID = @SessionUserId and FUNCTIONALITY_ID = 6 /* HR */) = 0  
 Begin    
 Set @tQry = '
 Insert into #Att_Users(Userid)Select UserId from ARC_REC_USER_INFO Where USERID = '+CONVERT(varchar,@SessionUserId)+'
 and isnull(AHS_PRL,''Y'') = ''Y'' and Active = '+ Case when @Active = 1 then '1' else '2' end +''
 Exec(@tQry)
 Set @Qry += ' and Reporting_To = (Select NT_USERNAME from ARC_REC_USER_INFO Where UserId = '+Convert(varchar,@SessionUserId)+')'    
 End  
 print (@Qry)      
 Exec (@Qry)    
  End  
End    
  --select * from #Att_Users  
if OBJECT_ID('tempdb..#EmpAttendance') is not null drop table #EmpAttendance    
Create table #EmpAttendance(Aid int,UserId int,[Date] date,P_Days decimal(15,2),CompOffEligible int,IsDeclaredOff int,OTEligible int,Present varchar(20),NotPresent varchar(20),LeaveType varchar(5),ContiniousLOP bit)    
create index hash_EmpAttendance_userid on #EmpAttendance(userid,[date])       
create index hash_EmpAttendance_mark on #EmpAttendance(NotPresent,Present)    
    
Insert into #EmpAttendance(Aid,UserId,[Date],P_Days,CompOffEligible,IsDeclaredOff,OTEligible,Present,NotPresent,ContiniousLOP)    
Select distinct att.Aid,Att.Userid,att.Date,isnull(att.P_days,0),isnull(att.CompOffEligible,0)CompOffEligible,isnull(att.IsDeclaredOff,0)IsDeclaredOff,isnull(att.OTEligible,0)OTEligible    
,case when isnull(P_days,0)= 0 and isnull(IsDeclaredOff,0) = 1 then 'Holiday'     
   when isnull(P_days,0) = 1 then 'Full Present'     
   when isnull(P_days,0) = 0.5 and att.LateIn <= 2 and att.LateOut <= 2 and isnull(lr.ACTIVE,'') = 'Y' then 'Full Present' 
   when isnull(P_days,0) = 0.5 then 'Half Present'    
   else '' end as Present    
,case when isnull(IsDeclaredOff,0) = 1 then 'Holiday' else '' end as NotPresent    
,0 as ContiniousLOP    
from ARC_REC_Attendance as Att    
inner join #Att_Users as Users on Users.Userid = att.Userid    
left join ARC_REC_LEAVE_REQUEST as LR on LR.CREATED_BY = Att.Userid and Convert(date,LR.FROMDATE) = att.Date and lr.TYPEID = 5 and lr.LEAVE_STATUS = 1 and lr.ACTIVE = 'Y'
Where att.Date between @FromDate and @ToDate    
    
update #EmpAttendance set LeaveType = ltp.short_Text        
,NotPresent = case when lr.LEAVE_MODE = 'F' then 'Full ' else 'Half ' end + CASE WHEN LR.TYPEID = 6 THEN  'LOP' ELSE 'LWP' END    
from #EmpAttendance  as av      
inner join arc_Rec_leave_tran as lt on lt.LEAVE_DATE = av.Date      
inner join arc_Rec_leave_request lr on lr.LEAVE_REQID = lt.LEAVE_REQID and lr.LEAVE_STATUS = 1 and lr.CREATED_BY = av.Userid and lr.TYPEID <> 5 and lr.ACTIVE = 'Y'
inner join ARC_REC_LEAVE_TYPES as ltp on ltp.TYPEID = lr.TYPEID

/* UnInformed LOP mark */    
Update #EmpAttendance Set NotPresent = case when att.P_Days = 0 then 'Full' else 'Half' end + ' LOP(U)',LeaveType = 'LOP'    
from #EmpAttendance as Att
inner join ARC_REC_LEAVE_TYPES as LP on LP.TYPEID = 6     
Where Att.P_Days <> 1 and isnull(NotPresent,'') = '' and ISNULL(Present,'') <> 'Full Present'

if (Select COUNT(*) from ARC_REC_SOFTCONTROL Where CTL_ID = 'ContinuosLOP' and CTL_VALUE = 'Y') > 0    
Begin/** update continuos lop **/       
 update #EmpAttendance  set ContiniousLOP = case when isnull((select top 1 NotPresent from #EmpAttendance where Userid = t.Userid and [DATE] < t.date     
               and isnull(NotPresent,'') <> 'Holiday' order by date desc),'') in ('Full LOP','Full LOP(U)')    
             and   isnull((select top 1 NotPresent from #EmpAttendance where Userid = t.Userid and [DATE] > t.date     
               and isnull(NotPresent,'') <> 'Holiday' order by date),'') in ('Full LOP','Full LOP(U)') then 1 else 0 end       
 from #EmpAttendance as t    
 where t.NotPresent = 'Holiday'    
 update emp set ContiniousLOP = 1
 from #EmpAttendance as emp
 inner join ARC_REC_AssociateDOLView as doldView on doldView.UserId = emp.UserId and emp.Date >= doldView.DOL
 Update #EmpAttendance Set IsDeclaredOff = 0,NotPresent = 'Full LOP',Present = '',LeaveType = 'LOP' Where ContiniousLOP = 1    
End    

Update #EmpAttendance Set P_Days = case when Present = 'Full Present' then 1 when Present = 'Half Present' then 0.5 else 0 end
    
Declare @DateColumnStruct varchar(max) = ''    
Declare @DateColumnNames varchar(max) = ''    
Declare @PresentComputeColumn varchar(max) = ''    
Declare @NotPresentComputeColumn varchar(max) = ''    
Declare @tDate date = @FromDate    
While @tDate <= @ToDate and @tDate <= Convert(date,GETDATE())    
 Begin     
 Set @PresentComputeColumn += '    
 ,Max(Case when att.[Date] = '''+CONVERT(varchar,@tDate)+''' then att.Present else '''' end) as [' + rtrim(ltrim(substring(CONVERT(varchar,@tDate,107),1,8))) + rtrim(ltrim(substring(datename(WEEKDAY,@tDate),1,3))) + ']'     
 Set @NotPresentComputeColumn += '    
 ,Max(Case when att.[Date] = '''+CONVERT(varchar,@tDate)+''' then att.NotPresent else '''' end) as [' + rtrim(ltrim(substring(CONVERT(varchar,@tDate,107),1,8))) + rtrim(ltrim(substring(datename(WEEKDAY,@tDate),1,3))) + ']'     
 Set @DateColumnStruct += ',[' + rtrim(ltrim(substring(CONVERT(varchar,@tDate,107),1,8))) + rtrim(ltrim(substring(datename(WEEKDAY,@tDate),1,3))) + '] varchar(25)'    
 Set @DateColumnNames += ',[' + rtrim(ltrim(substring(CONVERT(varchar,@tDate,107),1,8))) + rtrim(ltrim(substring(datename(WEEKDAY,@tDate),1,3))) + ']'    
 Set @tDate = DATEADD(DD,1,@tDate)    
 End    
Declare @LeaveTypeComputeColumns varchar(max) = ''    
Declare @LeaveTypeColumnStruct varchar(max) = ''    
Declare @LeaveTypeColumnNames varchar(max) = ''    
Declare @LeaveType varchar(20)    
Declare CurLeaveType Cursor For Select SHORT_TEXT from ARC_REC_LEAVE_TYPES Where TYPEID <> 5    
Open CurLeaveType    
While 1=1     Begin    
 Fetch next from CurLeaveType into @LeaveType    
 if @@FETCH_STATUS = -1 break     
 Set @LeaveTypeComputeColumns += '    
 ,Convert(Decimal(9,2),(Select Sum(Case when P_Days = 0 then 1 when P_Days = 0.5 then 0.5 else 0 end) from #EmpAttendance Where UserId = Att.UserId and LeaveType = '''+@LeaveType+''')) as ''['+@LeaveType+']'''    
 Set @LeaveTypeColumnStruct += ',['+@LeaveType+'] Decimal(9,2)'    
 Set @LeaveTypeColumnNames += ',['+@LeaveType+']'    
 End    
Close CurLeaveType    
DeAllocate CurLeaveType    

if @View = 'Detailed'    
 Begin    
  
 Set @Qry = '    
  
 if OBJECT_ID(''tempdb..#EmpAttendanceDetailedView'') is not null drop table #EmpAttendanceDetailedView    
 Create Table #EmpAttendanceDetailedView(EmpCode varchar(20),[Name] varchar(300),[Functionality] varchar(100),[Client] varchar(100)    
 ,Present Decimal(9,2)' + @LeaveTypeColumnStruct + '    
 ,[Att Mode] varchar(2)' + @DateColumnStruct +  '    
 ,[EmpCode~Hide] varchar(20)    
 )    
 Insert into #EmpAttendanceDetailedView    
 (    
 EmpCode,[Name],[Functionality],[Client]    
 ,[Att Mode]' + @DateColumnNames + ',Present' + @LeaveTypeColumnNames + '    
 ,[EmpCode~Hide]    
 )    
 Select ui.EMPCODE as [EmpCode],dbo.ConcatenateName(ui.FIRSTNAME,ui.MIDDLENAME,ui.LASTNAME) as [Name]    
 ,func.FunctionName [Functionality],cl.Client_Name [Client],''P'' [Att Mode]    
 '+@PresentComputeColumn+'    
 ,Convert(Decimal(9,2),(Select Sum(Case when IsDeclaredOff = 1 and isnull(LeaveType,'''') <> ''ML'' then 1 else P_Days end) from #EmpAttendance Where UserId = Att.UserId)) as Present    
 '+@LeaveTypeComputeColumns+'    
 ,ui.EMPCODE as [EmpCode~Hide]    
 from #EmpAttendance as Att    
 inner join ARC_REC_USER_INFO as Ui on Ui.USERID = att.UserId    
 left join HR_Functionality as func on func.FunctionalityId = ui.FUNCTIONALITY_ID    
 left join ARC_FIN_CLIENT_INFO as Cl on Cl.Client_Id = ui.CLIENT_ID    
 Group by ui.EMPCODE,ui.FIRSTNAME,ui.MIDDLENAME,ui.LASTNAME,func.FunctionName,cl.Client_Name,Att.UserId    
    
 Insert into #EmpAttendanceDetailedView    
 (    
 EmpCode,[Name],[Functionality],[Client]    
 ,[Att Mode]' + @DateColumnNames + '    
 ,[EmpCode~Hide]    
 )    
 Select '''' as [EmpCode],'''' as [Name]    
 ,'''' [Functionality],'''' [Client],''NP'' [Att Mode]    
 '+@NotPresentComputeColumn+'    
 ,ui.EMPCODE as [EmpCode~Hide]    
 from #EmpAttendance as Att    
 inner join ARC_REC_USER_INFO as Ui on Ui.USERID = att.UserId    
 left join HR_Functionality as func on func.FunctionalityId = ui.FUNCTIONALITY_ID    
 left join ARC_FIN_CLIENT_INFO as Cl on Cl.Client_Id = ui.CLIENT_ID    
Group by ui.EMPCODE,ui.FIRSTNAME,ui.MIDDLENAME,ui.LASTNAME,func.FunctionName,cl.Client_Name    
     
 Select * into #MonthAttendance from #EmpAttendanceDetailedView as Att    
 Order by Att.[EmpCode~Hide],Att.[Att Mode] desc   
  
 Declare @OrderStr varchar(100)                                     
SET @OrderStr  = ''''      
Exec FilterTable                     
@DbName = tempdb                             
,@TblName = #MonthAttendance  
,@SearchStr = '''+@SearchStr+'''                              
,@SearchPattern = '''+@SearchPattern+'''                             
,@OrderStr = @OrderStr'                              
    
  
 print(@Qry)   
 Exec (@Qry)    
 End    
Else if @View = 'Summary'   
 Begin    
 Set @Qry = '    
 if OBJECT_ID(''tempdb..#EmpAttendanceSummaryView'') is not null drop table #EmpAttendanceSummaryView    
 Create Table #EmpAttendanceSummaryView(EmpCode varchar(20),[Name] varchar(300),[Functionality] varchar(100),[Client] varchar(100)    
 ,Present Decimal(9,2)' + @LeaveTypeColumnStruct + '     
 ,[EmpCode~Hide] varchar(20)    
 )  
 Insert into #EmpAttendanceSummaryView    
 (    
 EmpCode,[Name],[Functionality],[Client]     
 ,Present' + @LeaveTypeColumnNames + '    
 ,[EmpCode~Hide]    
 )    
 Select ui.EMPCODE as [EmpCode],dbo.ConcatenateName(ui.FIRSTNAME,ui.MIDDLENAME,ui.LASTNAME) as [Name]    
 ,func.FunctionName [Functionality],cl.Client_Name [Client]      
 ,Convert(Decimal(9,2),(Select Sum(Case when IsDeclaredOff = 1 and isnull(LeaveType,'''') <> ''ML'' then 1 else P_Days end) from #EmpAttendance Where UserId = Att.UserId)) as Present    
 '+@LeaveTypeComputeColumns+'    
 ,ui.EMPCODE as [EmpCode~Hide]    
 from #EmpAttendance as Att    
 inner join ARC_REC_USER_INFO as Ui on Ui.USERID = att.UserId    
 left join HR_Functionality as func on func.FunctionalityId = ui.FUNCTIONALITY_ID    
 left join ARC_FIN_CLIENT_INFO as Cl on Cl.Client_Id = ui.CLIENT_ID    
 Group by ui.EMPCODE,ui.FIRSTNAME,ui.MIDDLENAME,ui.LASTNAME,func.FunctionName,cl.Client_Name,Att.UserId   
   
 Select * from #EmpAttendanceSummaryView as Att    
 Order by Att.[EmpCode~Hide]'    
 Exec (@Qry)    
   
 End    
if @View = 'DateWise'    
 Begin    
   
  Select Aid,UserId,[Date]    
  ,Ltrim(    
  Case when Present = NotPresent then isnull(Present,'') else ISNULL(Present,'') + ' ' + ISNULL(NotPresent,'') end     
  + isnull(case when isnull(LeaveType,'') <> 'LOP' then '(' + LeaveType + ')' else '' end,'')    
  ) as Attendance      
  ,CompOffEligible,IsDeclaredOff,OTEligible,Present,NotPresent,Isnull(LeaveType,'') as LeaveType,P_Days   
  from #EmpAttendance    
    
 End    
End



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_MonthlyAttendanceView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_MonthlyAttendanceView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_MonthlyAttendanceView] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_MonthlyAttendanceView] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_MonthlyAttendanceView] TO [DB_DMLSupport]
    AS [dbo];

