﻿CREATE Proc [dbo].[RR_Load_TeamMates]                    
@userid int =535,              
@Awardid int=0                   
/*                    
Created By : udhayaganesh P                    
Purpose  : To load the Team Members                    
                    
select * from ARC_REC_USER_INFO_VY  where Reporting_to='Harapriya.N'                  
                  
exec RR_Load_TeamMates @userid=489,@Awardid=2   

select USERID,UI.FIRSTNAME+' '+ui.LASTNAME Associate,NT_USERNAME  from ARC_REC_USER_INFO UI                    
inner Join ARC_FIN_CLIENT_INFO CI on CI.CLIENT_ID=Ui.CLIENT_ID                     
where UI.ACTIVE=1 and AHS_PRL='Y' and NT_USERNAME<>''and FUNCTIONALITY_ID= @FUNCTIONALITY_ID                     
order by NT_USERNAME                          
                  
                  
*/                    
As                    
Begin                    
                    
Declare @FUNCTIONALITY_ID int,@clientid int,@type tinyint,@Reporting_to varchar(100)                   
select @clientid=CLIENT_ID,@FUNCTIONALITY_ID=FunctionalityId,@Reporting_to=NT_UserName from ARC_REC_USER_INFO_VY  where USERID=@userid              
            
select @type=StartRange  from RR_CRITERA_MASTER where status=1 and CID=@Awardid   

Print @clientid 
Print @FUNCTIONALITY_ID         
            
If @Awardid <33            
Begin             
                    
if @clientid=16 and @FUNCTIONALITY_ID=11 and @Awardid <>7                   
begin                    
print 'MD'                    
select USERID,UI.FIRSTNAME+' '+ui.LASTNAME Associate,NT_USERNAME  from ARC_REC_USER_INFO UI                    
inner Join ARC_FIN_CLIENT_INFO CI on CI.CLIENT_ID=Ui.CLIENT_ID                     
where UI.ACTIVE=1 and AHS_PRL='Y' and NT_USERNAME<>''                    
order by NT_USERNAME                     
end                    
else if  @clientid=16 and @FUNCTIONALITY_ID<>11  and @Awardid <>7                  
begin                    
select USERID,UI.FIRSTNAME+' '+ui.LASTNAME Associate,NT_USERNAME  from ARC_REC_USER_INFO UI                    
inner Join ARC_FIN_CLIENT_INFO CI on CI.CLIENT_ID=Ui.CLIENT_ID                     
where UI.ACTIVE=1 and AHS_PRL='Y' and NT_USERNAME<>''and FUNCTIONALITY_ID= @FUNCTIONALITY_ID                     
order by NT_USERNAME                    
end                    
else if @Awardid not in (1,2,3,4,7)    
begin                    
select USERID,UI.FIRSTNAME+' '+ui.LASTNAME Associate,NT_USERNAME  from ARC_REC_USER_INFO  UI                    
inner Join ARC_FIN_CLIENT_INFO CI on CI.CLIENT_ID=Ui.CLIENT_ID                     
where UI.ACTIVE=1 and AHS_PRL='y'   and ui.CLIENT_ID =@clientid                  
and FUNCTIONALITY_ID= @FUNCTIONALITY_ID                       
order by NT_USERNAME                    
end         
else if @Awardid =7                  
begin                    
select USERID,UI.FIRSTNAME+' '+ui.LASTNAME Associate,NT_USERNAME  from ARC_REC_USER_INFO  UI                    
inner Join ARC_FIN_CLIENT_INFO CI on CI.CLIENT_ID=Ui.CLIENT_ID                     
where UI.ACTIVE=1 and AHS_PRL='y' and USERID  <> @userid   and ui.CLIENT_ID =@clientid                  
and FUNCTIONALITY_ID= @FUNCTIONALITY_ID                       
order by NT_USERNAME                    
end    
Else if @Awardid in(1,2,3,4)    
begin    
print 'hi'    
select USERID,UI.FIRSTNAME+' '+ui.LASTNAME Associate,NT_USERNAME  from ARC_REC_USER_INFO  UI                    
inner Join ARC_FIN_CLIENT_INFO CI on CI.CLIENT_ID=Ui.CLIENT_ID                     
where UI.ACTIVE=1 and AHS_PRL='y' and UI.REPORTING_TO = @Reporting_to    
union    
select USERID,UI.FIRSTNAME+' '+ui.LASTNAME Associate,NT_USERNAME  from ARC_REC_USER_INFO  UI                    
inner Join ARC_FIN_CLIENT_INFO CI on CI.CLIENT_ID=Ui.CLIENT_ID                     
where UI.ACTIVE=1 and AHS_PRL='y' and UI.NT_USERNAME = @Reporting_to    
end              
End          
Else if @Awardid>=33 and @Awardid<47 and @type=1            
Begin            
select USERID, Associate,NT_USERNAME  from ARC_REC_USER_INFO_VY  UI                    
inner join RR_Quality_Audit  QA on QA.empcode=ui.Empcode              
where QA.type=1 and QA.Status =1 order by Associate           
end             
else             
begin            
select USERID, Associate,NT_USERNAME  from ARC_REC_USER_INFO_VY  UI                    
inner join RR_Quality_Audit  QA on QA.empcode=ui.Empcode              
where QA.type=2 and QA.Status =1   order by Associate           
end                 
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Load_TeamMates] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Load_TeamMates] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Load_TeamMates] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Load_TeamMates] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Load_TeamMates] TO [DB_DMLSupport]
    AS [dbo];

