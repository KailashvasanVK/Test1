﻿CREATE PROCEDURE [dbo].[AHS_HR_RESIGN_Get]                      
(                        
@EMPCODE varchar(15)           
                     
)                   
/*                  
Created By : Udhayaganesh P                  
Created On : Sep 07 2013                  
Purpose    : To get the Candidate Assessment details                   
Execution  : AHS_HR_RESIGN_Get @EMPCODE= D02846       
              
              
*/                      
AS                      
BEGIN                           
                      
if EXISTS (select top 1 'x' from ARC_REC_CANDIDATE C      
inner join ARC_REC_USER_INFO UI on Ui.REC_ID =c.REC_ID       
inner join ARC_ME_EXIT E on e.EMPCODE =ui.EMPCODE    
inner join ARC_ME_EXIT_STATUS_TRAN ET on ET.REG_ID =e.REG_ID       
where RegByAHS =0 and ui.EMPCODE =@EMPCODE and ET.STATUS_ID =4 )                    
Begin       
            
select top 1 c.REC_ID,e.RELDATE_HR,convert(varchar(20),et.CREATED_DT,120) Closeron,    
ACTIVE=(case when e.active='Y' then 1 else 0 end)    
from ARC_REC_CANDIDATE C      
inner join ARC_REC_USER_INFO UI on Ui.REC_ID =c.REC_ID       
inner join ARC_ME_EXIT E on e.EMPCODE =ui.EMPCODE            
inner join ARC_ME_EXIT_STATUS_TRAN ET on ET.REG_ID =e.REG_ID       
where ET.STATUS_ID =4 and ui.EMPCODE =@EMPCODE and c.RegByAHS =0    
order by e.CREATED_DT desc  
                    
End                       
                          
END
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AHS_HR_RESIGN_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHS_HR_RESIGN_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHS_HR_RESIGN_Get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AHS_HR_RESIGN_Get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHS_HR_RESIGN_Get] TO [DB_DMLSupport]
    AS [dbo];

