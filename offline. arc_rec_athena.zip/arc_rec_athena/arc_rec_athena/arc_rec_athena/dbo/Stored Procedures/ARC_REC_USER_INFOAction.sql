﻿CREATE procedure [dbo].[ARC_REC_USER_INFOAction]        
@Action varchar(50),          
@USERID int = 0 ,    
@CreatedBy int = 0 ,    
@UserName varchar(100)= null      
,@Password varchar(15)= null  
As          
/*          
Created By   : Karthik IC                  
Created Date : 18 June 2013                  
Impact to    : UserCreation.aspx          
ARC_REC_USER_INFOAction  'GetUserDetails',1704          
*/          
Begin          
if @Action = 'GetUserDetails'          
/* Purpose      : To get the user basic details  */          
Begin          
Select USERID,FIRSTNAME +' '+ LASTNAME as FullName,FIRSTNAME,LASTNAME,Password ,EmailId,UserName,          
case when AccountType = 'A' then 'Admin' else 'General' end  as Account          
from ARC_REC_USER_INFO          
Where ExtUser ='Y'    
and LastCustomerId = (Select LastCustomerId from ARC_REC_USER_INFO Where USERID = @CreatedBy)  
and ACTIVE = 1 and USERID  = (case when isnull(@USERID,0) = 0 then  USERID else @USERID end)     
--and USERID  <>  @CreatedBy  
End          
if @Action = 'ValidateUserName'          
/* Purpose      : To validate the user name already exists or not */          
Begin          
if exists(Select top 1 'x' from ARC_REC_USER_INFO where UserName =@UserName and userid <> @USERID)      
Begin      
Select 1 as Result -- Exists      
End      
else       
Begin      
Select 0 as Result -- Not Exists      
End        
End  
if @Action  = 'VerifyUserLogin'    
-- Purpose : To validate the user name and password --    
Begin    
 Select info.USERID,info.FIRSTNAME,info.LASTNAME,info.EmailId,info.UserName,info.LastCustomerId,info.AccountType,cus.CmpKey 
 from  ARC_REC_USER_INFO info  
 inner join ARC_Flow_Athena..ADM_Customer cus on cus.CustomerId = info.LastCustomerId  
 Where ExtUser = 'y' and UserName = @UserName and Password = @Password and info.ACTIVE= 1
End         
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_USER_INFOAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_USER_INFOAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_USER_INFOAction] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_USER_INFOAction] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_USER_INFOAction] TO [DB_DMLSupport]
    AS [dbo];

