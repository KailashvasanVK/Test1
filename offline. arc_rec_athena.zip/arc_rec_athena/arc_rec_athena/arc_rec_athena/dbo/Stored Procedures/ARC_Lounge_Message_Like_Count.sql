﻿CREATE procedure ARC_Lounge_Message_Like_Count(@MsgId int=0)      
 as      
 begin      
 select COUNT(ml.id)'MsgLikeCount',ml.MsgId,ml.status  from ARC_Forum_Lounge_Message_Likes ml 
 where  ml.MsgId=@MsgId and ml.Status=1  
 group by ml.MsgId,ml.status 
 end 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Message_Like_Count] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Like_Count] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Like_Count] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Message_Like_Count] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Like_Count] TO [DB_DMLSupport]
    AS [dbo];

