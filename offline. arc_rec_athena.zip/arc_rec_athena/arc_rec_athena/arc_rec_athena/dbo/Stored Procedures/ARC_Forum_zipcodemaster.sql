﻿CREATE PROCEDURE [dbo].[ARC_Forum_zipcodemaster](@zipcode varchar(50))    
AS    
BEGIN     
select City,State,isnull(areacode,'Nil') areacode from ZipcodeHeaderMaster where zip=@zipcode    
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Forum_zipcodemaster] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_zipcodemaster] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_zipcodemaster] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Forum_zipcodemaster] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_zipcodemaster] TO [DB_DMLSupport]
    AS [dbo];

