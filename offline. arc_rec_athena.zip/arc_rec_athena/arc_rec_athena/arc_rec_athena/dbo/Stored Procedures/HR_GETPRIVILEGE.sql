﻿CREATE PROCEDURE  [dbo].[HR_GETPRIVILEGE]                                    
(                                  
 @TCid tinyint,                               
 @applnid  numeric (18),                                    
 @userid  numeric (18),                                    
 @formcode varchar(15)                                  
)                                  
AS                                    
Begin   
SET NOCOUNT ON                                  
/*                                    
 Name : Udhayaganesh.p   
 
 select * from Mrplogin   
 
 HR_GETPRIVILEGE Null,2,1,'MPR-MDAPPRVE'
 
 select * from MAP_Accessprivileges
                           
*/                                    
  
IF @TCID IS NULL and @userid not in(1,8)
Begin  
Print 'other'  
select CASE WHEN B.Status = 0 THEN 0 ELSE isnull(b.[Read], 0) END as ReadVal,                   
case when B.STATUS = 0 THEN 0 ELSE isnull(b.Write, 0) END as WriteVal,                   
CASE WHEN B.STATUS = 0 THEN 0 ELSE isnull(b.[Modify], 0) END as ModifyVal,                   
CASE WHEN B.STATUS = 0 THEN 0 ELSE isnull(b.[Delete], 0) END as 'DeleteVal'  ,        
 a.UserId, a.TCId, a.PrivilegeType, a.PrivilegeRole        
from                             
MAP_USERROLES a                            
inner join MAP_Accessprivileges b on a.PrivilegeType = b.PrivilegeType                             
 and a.PrivilegeRole = b.PrivilegeRole                              
 and b.FormCode = @formcode                             
 and a.ApplicationId = b.ApplicationId                            
 and b.ApplicationId = @applnid                            
where a.UserId = @userid and a.Applicationid = @applnid  and b.formcode<>'MPR-MDAPPRVE'   
end                          
Else   
Begin  
select CASE WHEN B.Status = 0 THEN 0 ELSE isnull(b.[Read], 0) END as ReadVal,                   
case when B.STATUS = 0 THEN 0 ELSE isnull(b.Write, 0) END as WriteVal,                   
CASE WHEN B.STATUS = 0 THEN 0 ELSE isnull(b.[Modify], 0) END as ModifyVal,                   
CASE WHEN B.STATUS = 0 THEN 0 ELSE isnull(b.[Delete], 0) END as 'DeleteVal'  ,        
 a.UserId, a.TCId, a.PrivilegeType, a.PrivilegeRole        
from                             
MAP_USERROLES a                            
inner join MAP_Accessprivileges b on a.PrivilegeType = b.PrivilegeType                             
 and a.PrivilegeRole = b.PrivilegeRole                              
 and b.FormCode = @formcode                             
 and a.ApplicationId = b.ApplicationId                            
 and b.ApplicationId = @applnid                            
where a.UserId in(1,8) and a.Applicationid = @applnid   and userid=@userid
End  
SET NOCOUNT OFF              
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_GETPRIVILEGE] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_GETPRIVILEGE] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_GETPRIVILEGE] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_GETPRIVILEGE] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_GETPRIVILEGE] TO [DB_DMLSupport]
    AS [dbo];

