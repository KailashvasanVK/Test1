﻿CREATE procedure ARC_Lounge_Message_Comments_Flag          
(          
@CmtId int ,                
@PageIndex int=1,                                                                     
@PageSize int=5            
)           
as            
/*          
           
 CreatedBy : Udhayaganesh.p                
           
 Purpose   : Get the Respective Message like Report Abuse details           
           
 Exec ARC_Lounge_Message_Flag 2455,1,5          
           
           
              
*/            
begin              
Declare @RecordCount int                
          
                
select * into #Liketemp from(                
select  ROW_NUMBER() over (order by CF.id desc)RowNumber ,cf.CmtId CmtId,isnull(Ci.FIRSTNAME+' '+ci.LASTNAME,'') +' | ' Creator,          
CONVERT(VARCHAR(19),ReportedOn) as LikedOn ,PROFILE_IMAGE_NAME=                                                                    
(case when PROFILE_IMAGE_NAME is not null                         
 then'https://arc.accesshealthcare.co/arc_rec/images/candidate/'+PROFILE_IMAGE_NAME else                            
 'https://arc.accesshealthcare.co/arc_rec/images/userimg.jpg' end),Replace(d.CLIENT_NAME,'Newyork','New York')Client           
from ARC_Forum_Lounge_Comment_Flags CF              
inner join ARC_REC_USER_INFO CI on CI.NT_USERNAME =CF.ReportedBy                                                                     
Inner join ARC_REC_CANDIDATE CD on CD.REC_ID =ci.REC_ID                                             
Inner join arc_fin_client_info d on  d.CLIENT_ID =ci.CLIENT_ID                
where CF.CmtId =@CmtId and CF.Status=1              
)               
as temptab             
          
SELECT @RecordCount = COUNT(*) FROM #Liketemp              
          
select RowNumber,Creator,Client,LikedOn,PROFILE_IMAGE_NAME from #Liketemp           
 where  RowNumber BETWEEN(@PageIndex -1) * @PageSize + 1 AND(((@PageIndex -1) * @PageSize + 1) + @PageSize) - 1      
       
 SELECT @RecordCount 'PageCnt',(Select top 1 CmtId from #Liketemp) 'CmtId'           
          
Drop table #Liketemp                                     
              
end
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comments_Flag] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comments_Flag] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comments_Flag] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comments_Flag] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comments_Flag] TO [DB_DMLSupport]
    AS [dbo];

