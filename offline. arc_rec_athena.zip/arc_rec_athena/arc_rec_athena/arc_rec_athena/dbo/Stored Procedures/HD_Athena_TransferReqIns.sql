﻿CREATE procedure HD_Athena_TransferReqIns                
      @ReqId int,                
      @UserId int,                   
      @RoleId int,    
      @DeptId int,    
      @HasCitrix char(1), 
      @TransferDate date,   
      @CreatedBy int                            
AS                
Begin                
insert into HD_Athena_Transfer(ReqId,UserId,RoleId,DeptId,AddCitrix,TransferDate,CreatedBy,CreatedDt,[Status])          
select @ReqId,@UserId,@RoleId,@DeptId,@HasCitrix,@TransferDate,@CreatedBy,GETDATE(),0                
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_TransferReqIns] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_TransferReqIns] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_TransferReqIns] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_TransferReqIns] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_TransferReqIns] TO [DB_DMLSupport]
    AS [dbo];

