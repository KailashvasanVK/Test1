﻿CREATE Proc AR_OpenPosition      
as      
begin      
DECLARE @xml VARCHAR(MAX)                    
DECLARE @body VARCHAR(MAX)         
    
    
select ROW_NUMBER() over (order by Designation) ,      
Designation ,FunctionName AS  'td','',[New Position / Attrition]       
 ,convert(varchar(20),[ARMS Date Raised],110) ,      
convert(varchar(20),[ARMS Traget date],110)       
,TotalPositions-[Number of position closed]       
from ARMS_Status_report WHERE TotalPositions> [Number of position closed]      
AND FunctionName='Operations - Revenue Cycle'     
    
      
SET @xml = CAST((select ROW_NUMBER() over (order by Designation) AS 'td',''    
,'AR'  AS 'td',''       
,Designation AS 'td',''    
,CONVERT(varchar(10),expfromyears) + ' to ' +CONVERT(varchar(10),exptoyears) +' Years'  AS 'td',''    
,Skillset  AS 'td',''     
,TotalPositions  AS 'td',''     
,TotalPositions-[Number of position closed]  AS 'td',''     
,convert(varchar(20),[ARMS Date Raised],110) AS 'td',''      
,convert(varchar(20),[ARMS Traget date],110) AS 'td',''      
,dbo.RupeeFormat_Rounded(SalaryMin)  AS 'td',''    
,dbo.RupeeFormat_Rounded(SalaryMax)  AS 'td'     
    
from ARMS_S1_Status_report WHERE TotalPositions> [Number of position closed]      
AND FunctionName='Operations - Revenue Cycle'      
FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))          
            
      
SET @body ='<html><body>                    
<style type=text/css>                                                                                                                                   
<!-- .tableHeader{  font-family: Calibri(bold); font-size: 12px; font-weight: normal; font-style: normal ;color:#FFF }                                                                                                           
                      
.tableTxt{  font-family: Calibri(bold); font-size: 16px; font-weight: normal; font-style: normal  }-->                    
</style>                     
                   
<table>                     
<tr><td   class=tableTxt><B>Dear All,</B></td> </tr> </br>                            
<tr >                    
<td  class=tableTxt>Please find below AR opening position in Access Healthcare pvt ltd.          
 <td></tr>                    
<tr><TD></td></tr></table></br>                     
                    
<table width="100%"  border=-1 align=center cellpadding=0 cellspacing=1 >                    
<tr class=tableHeader bgcolor=#2567aa  align=center color=#FFFFFF><td style="padding:5px"><b>Sl.No</b></font></td>                     
<td style="padding:5px"><b> Process </b></td><td style="padding:5px"><b> Position</b> </td><td style="padding:5px"><b> Years of experience</b> </td><td style="padding:5px"><b> Skill set required</b></td>                    
<td style="padding:5px"><b> No. of openings </b></td><td style="padding:5px"><b>Positions pending closure </b></td><td style="padding:5px"><b>ARMS request raised on</b></td>    
<td style="padding:5px"><b>Expected date of closure</b></td><td style="padding:5px"><b>Minimum salary</b></td><td style="padding:5px"><b>Maximum salary</b></td></tr>'      
                      
                     
SET @body = @body + @xml +'</table width="100%" ></br>                    
<table>            
<tr><td>&nbsp;</td> </tr>                  
<tr><td>Warm Regards,</td> </tr>      
<tr><td>Access Healthcare</td> </tr>       
<tr><TD></td></tr>                                 
<tr><TD></td></tr>          
<tr><td>This is a system generated mail. Please do not respond to this mail.</td></tr>        
<tr><TD></td></tr>                                 
<tr><TD></td></tr>        
<TR><B>Legal Disclaimer:</B></TR>        
<tr>The information contained in this message (including all attachments) may be privileged and confidential.         
It is intended to be read only by the individual or entity to whom it is addressed or by their designee.         
If the reader of this message is not the intended recipient, please destroy this message immediately and also please note that you are on notice that any distribution of this message, in any form, is strictly prohibited.        
If you have received this message in error, please immediately notify the sender and delete or destroy any copy of this message!        
</td></tr>'                
            
EXEC msdb.dbo.sp_send_dbmail                                                                                                                                                                                                   
@profile_name = 'ARC_DBmail',                                                   
@recipients='Anushadaduvai.a@laurusedutech.com' ,      
@blind_copy_recipients ='udhayaganesh.p@accesshealthcare.co' ,                                                   
@subject='AHS AR Open Position',                                               
@body = @body,                                                   
@body_format  = 'HTML'     
    
      
 select @body         
       
 end
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AR_OpenPosition] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AR_OpenPosition] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AR_OpenPosition] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AR_OpenPosition] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AR_OpenPosition] TO [DB_DMLSupport]
    AS [dbo];

