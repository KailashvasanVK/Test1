﻿Create Proc AHS_FB_Refer_Details
as
select ReferNo [Recruitment ID],Refname Name,RefEmailId,RefMobile,fbname ReferedBy,CreatedOn ReferedOn,Position =(
case when Position ='imgRef1' then 'Billing Executive' 
when Position ='imgRef2' then 'Revenue Cycle Executive' 
when Position ='imgRef3' then 'Coding Executive (Specialized in Radiology / ER / Hospital coding)' 
when Position ='imgRef4' then 'General' end) from AHC_JobRefer


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AHS_FB_Refer_Details] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHS_FB_Refer_Details] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHS_FB_Refer_Details] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AHS_FB_Refer_Details] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHS_FB_Refer_Details] TO [DB_DMLSupport]
    AS [dbo];

