﻿CREATE proc Manual_attendance_Process
@From date,
@to date  
as        
Begin        
         
select @From,@to           
          
insert into UL_Attendance(UserAccount,Shiftid,UserFullName,LoginDate,Logout,WMin,Whours,HMin,Hhours,FMin,Fhours,Date)          
exec UserTrackingReport_new_job @from,@to          
          
end 

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Manual_attendance_Process] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Manual_attendance_Process] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Manual_attendance_Process] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Manual_attendance_Process] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Manual_attendance_Process] TO [DB_DMLSupport]
    AS [dbo];

