﻿CREATE Proc DB_Reindex_BasedOnFragmentation      
as      
Begin      
set Nocount on      
Declare @tableName Varchar(400),@tc int=0,@Frag_count int,@qry nvarchar(1000);      
      
select id,Name,Frag_count  into #temptable from MIS_Frag_Tables where Frag_count>0   
      
        
set @tc = (select COUNT(*) from #temptable)      
  
select @tc    
        
while @tc!=0        
begin        
        
select @TableName =Name,@Frag_count=Frag_count from #temptable  order by id     
    
select @TableName     
      
If @Frag_count>=30      
Begin      
DBCC DBReindex(@TableName,'',70)      
end      
Else      
Begin      
set @qry= 'ALTER INDEX ALL ON '+@TableName+' REORGANIZE ; '      
 EXEC sp_executesql @qry      
End      
        
        
set @tc=@tc-1        
delete from #temptable where name =@TableName        
end         
drop table #temptable       
      
set Nocount OFF      
        
        
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[DB_Reindex_BasedOnFragmentation] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[DB_Reindex_BasedOnFragmentation] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[DB_Reindex_BasedOnFragmentation] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[DB_Reindex_BasedOnFragmentation] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[DB_Reindex_BasedOnFragmentation] TO [DB_DMLSupport]
    AS [dbo];

