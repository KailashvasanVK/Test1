﻿CREATE Proc ARC_REC_ErrorLogInsert
(
@LogDescription varchar(1000) = ''
,@FormDescription varchar(1000) = ''
,@NtUserName varchar(250) = ''
,@ErrId varchar(50) = ''
,@ErrType varchar(250) = ''
,@ErrorStackTrace varchar(8000) = ''
,@AppName varchar(50) = ''
)
As
Begin
Insert into ARC_REC_ErrorLog(

LogDescription,FormDescription,NtUserName,ErrId,ErrType,ErrorStackTrace,AppName
)Values(@LogDescription,@FormDescription,@NtUserName,@ErrId,@ErrType,@ErrorStackTrace,@AppName)
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ErrorLogInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ErrorLogInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ErrorLogInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ErrorLogInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ErrorLogInsert] TO [DB_DMLSupport]
    AS [dbo];

