﻿
create proc Manual_file_send
as
declare @Headline VARCHAR(500),                                
@MessageText VARCHAR(Max),                                
@NT_User VARCHAR(75),                     
@CoverPhotoId int=0,                     
@Status TINYINT,                
@ContentWithOutImage varchar(max)=null,              
@AlbumId int=0    

select  @ContentWithOutImage=ContentWithOutImage,@Headline=Headline  from ARC_Forum_MessageBoard where MsgId =47 and Status =2                        

if @ContentWithOutImage is not null
begin
EXEC msdb.dbo.sp_send_dbmail                                                                                                                  
@profile_name = 'Newsdesk',                                                                                                                                
@recipients = 'all@accesshealthcare.co',        
@blind_copy_recipients ='udhayaganesh.p@laurusedutech.com',                                                                                                        
@subject=@Headline,                                                                                                                                                                              
@body = @ContentWithOutImage,                                                          
@body_format  = 'HTML',
@file_attachments ='F:\udhaya\Internal Quality Audit Schedule.pdf'

update ARC_Forum_MessageBoard set Status =1 where MsgId =47 

end
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Manual_file_send] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Manual_file_send] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Manual_file_send] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Manual_file_send] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Manual_file_send] TO [DB_DMLSupport]
    AS [dbo];

