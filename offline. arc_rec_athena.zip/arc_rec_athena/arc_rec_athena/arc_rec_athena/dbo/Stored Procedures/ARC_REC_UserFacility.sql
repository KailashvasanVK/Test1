﻿Create Proc ARC_REC_UserFacility(@NtName varchar(75))
As
Begin
Select Top 1 Fac.FacilityId,Fac.FacilityName,Fac.LevelName from Userlock..UserLogonEvents  as UL
inner join Eye_IPDetails as EyeIp on EyeIp.BayIP = UL.ClientAddress
inner join Eye_Facility as Fac on Fac.FacilityId = EyeIp.Facilityid
Where UserAccount = @NtName Order by EventTime desc
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_UserFacility] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UserFacility] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UserFacility] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_UserFacility] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UserFacility] TO [DB_DMLSupport]
    AS [dbo];

