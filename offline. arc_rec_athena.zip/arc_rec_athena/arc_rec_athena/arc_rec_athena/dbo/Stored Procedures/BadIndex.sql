﻿  
Create Proc BadIndex    
as    
begin  
  SELECT 'TableName' = object_name(s.object_id), 'IndexName' =i.name, i.index_id,      
           'Total Writes' =  user_updates, 'Total Reads' = user_seeks + user_scans + user_lookups,      
            'Difference' = user_updates - (user_seeks + user_scans + user_lookups)      
   into #temp  FROM sys.dm_db_index_usage_stats AS s      
    INNER JOIN sys.indexes AS i      
    ON s.object_id = i.object_id  and is_primary_key =0    
    AND i.index_id = s.index_id      
    WHERE objectproperty(s.object_id,'IsUserTable') = 1      
    AND s.database_id =   DB_ID()          
    AND user_updates > (user_seeks + user_scans + user_lookups)      
    ORDER BY 'Difference' DESC, 'Total Writes' DESC, 'Total Reads' ASC;      
          
    select * from #temp      
    select 'Drop Index '+IndexName + ' On ' +  TableName from #temp  where index_id<>0  and indexname not like 'PK_%'    
    end
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[BadIndex] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[BadIndex] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[BadIndex] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[BadIndex] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[BadIndex] TO [DB_DMLSupport]
    AS [dbo];

