﻿CREATE proc ARC_REC_GetReportingToUserId  
     @UserId int  
As  
Begin  
select USERID as ReportingToUserId,FIRSTNAME+' '+LASTNAME as Name,NT_USERNAME from ARC_REC_USER_INFO where ACTIVE  =1  and NT_USERNAME =   
(Select REPORTING_TO from ARC_REC_USER_INFO where USERID = @UserId)  
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_GetReportingToUserId] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_GetReportingToUserId] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_GetReportingToUserId] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_GetReportingToUserId] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_GetReportingToUserId] TO [DB_DMLSupport]
    AS [dbo];

