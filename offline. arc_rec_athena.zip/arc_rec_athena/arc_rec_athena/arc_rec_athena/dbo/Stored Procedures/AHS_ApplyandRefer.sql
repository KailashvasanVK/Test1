﻿CREATE Proc AHS_ApplyandRefer              
 @FromDate datetime=null,                    
 @ToDate datetime=null,                             
 @CountryId int=null,                              
 @ZoneId int =null,                              
 @hubId int =null,                              
 @TCId int =null                      
as                      
Begin           
        
/*  AHS_ApplyandRefer @FromDate='2012-01-01', @ToDate='2013-12-01'              */        
          
select * from (          
select 'Refer' Type,FBName [Refered By],RefName [Referal],RefMobile Contact ,RefEmailId Email,FBEmaiId ReferedEmail,          
CreatedOn [Application Date],'Position'=        
(CASE WHEN Position='imgRef1' THEN 'Billing Executive'        
 WHEN Position='imgRef2' THEN 'Revenue Cycle Executive'        
 WHEN Position='imgRef3' THEN 'Coding Executive (Specialized in Radiology / ER / Hospital coding)'        
 WHEN Position='imgRef4' THEN 'General'        
        
        
 END ),Resume='' from ARC_REC_Athena..AHC_JobRefer           
union           
select 'Apply' Type,'Self',FBName ,Mobile ,FBEmaiId,'',convert(varchar(10),CreatedOn,110),        
'Position'=        
(CASE WHEN Position='imgApply1' THEN 'Billing Executive'        
 WHEN Position='imgApply2' THEN 'Revenue Cycle Executive'        
 WHEN Position='imgApply3' THEN 'Coding Executive (Specialized in Radiology / ER / Hospital coding)'        
 WHEN Position='imgApply4' THEN 'General'        
        
        
 END ) ,Resume='https://www.accesshealthcare.co/raw/resume/'+isnull(ApplyNo,'')+'.doc'          
        
from ARC_REC_Athena..AHC_JobApply           
) as udhaya where  [Application Date] >=@FromDate and [Application Date] <=@ToDate            
          
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AHS_ApplyandRefer] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHS_ApplyandRefer] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHS_ApplyandRefer] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AHS_ApplyandRefer] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHS_ApplyandRefer] TO [DB_DMLSupport]
    AS [dbo];

