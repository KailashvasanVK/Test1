﻿    
 CREATE Proc ARC_Lounge_Comment_Like_Ins        
 @CmtId int,        
 @NT_Username Varchar(100)        
 /*         
 CreatedBy : Udhayaganesh.p        
 Purpose   : Associate Like Comments to be accounted        
         
 Execution : Exec ARC_Lounge_Message_Like_Ins 2455,'gggffff.m'       
       
 exec ARC_Lounge_Message_Like_Ins @Msgid=2453,@NT_Username=N'varunnair.m '       
         
 */        
 As        
 Begin        
 if not Exists(select top 1 'x' from ARC_Forum_Lounge_Comment_Likes where LikedBy=@NT_Username and CommId=@CmtId and Status=1)        
 Begin        
 Insert into ARC_Forum_Lounge_Comment_Likes(CommId,LikedBy,LikedOn,Status)        
 Values(@CmtId,@NT_Username,GETDATE(),1)        
 Select COUNT(*) LikeCount,1'likes',CommId from ARC_Forum_Lounge_Comment_Likes where CommId=@CmtId and Status=1 group by CommId       
 End      
 End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Comment_Like_Ins] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Comment_Like_Ins] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Comment_Like_Ins] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Comment_Like_Ins] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Comment_Like_Ins] TO [DB_DMLSupport]
    AS [dbo];

