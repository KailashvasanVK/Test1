﻿CREATE Procedure Locks        
AS        
/*       
 Created By:UdhayaGanesh P      
 Created On:08/11/2010      
 Purpose :find present lock history    
*/       
Begin     
select  convert (smallint, req_spid) As spid,          
  rsc_dbid As dbid,          
  rsc_objid As ObjId,          
  rsc_indid As IndId,          
  substring (v.name, 1, 4) As Type,          
  substring (rsc_text, 1, 32) as Resource,          
  substring (u.name, 1, 8) As Mode,          
  substring (x.name, 1, 5) As Status          
          
 from  master.dbo.syslockinfo,          
  master.dbo.spt_values v,          
  master.dbo.spt_values x,          
  master.dbo.spt_values u          
          
 where master.dbo.syslockinfo.rsc_type = v.number          
   and v.type = 'LR'          
   and master.dbo.syslockinfo.req_status = x.number          
   and x.type = 'LS'          
   and master.dbo.syslockinfo.req_mode + 1 = u.number          
   and u.type = 'L'          
   and x.name = 'wait'        
 order by spid          
         
 END
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Locks] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Locks] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Locks] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Locks] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Locks] TO [DB_DMLSupport]
    AS [dbo];

