﻿CREATE Proc [dbo].[RR_Scoreboard_Purchase_Ins]                                      
@LLID int,                                      
@Pid int,                                      
@Userid int,                                      
@PurchaseType tinyint                                      
AS                                      
/*                                      
                                      
Created By : Udhayaganesh P                                      
                                      
Purpose    : Redeem the gift                                      
                                      
                                      
Exec RR_Scoreboard_Purchase_Ins @LLID=1,@Pid=7,@Userid=807,@PurchaseType=3          
      
Exec RR_Scoreboard_Purchase_Ins @LLID=2,@Pid=14,@Userid=807,@PurchaseType=3      
    
    
Exec RR_Scoreboard_Purchase_Ins @LLID=3,@Pid=21,@Userid=807,@PurchaseType=3     
    
    
Exec RR_Scoreboard_Purchase_Ins @LLID=1,@Pid=1,@Userid=807,@PurchaseType=1    
      
      
Exec RR_Scoreboard_Purchase_Ins @LLID=2,@Pid=14,@Userid=807,@PurchaseType=3       
    
select * from RR_LeagueLevel         
                                    
*/                                      
Begin    
Declare @PurchasePoint int,@UserLLID int,@userScore int      
    
select @PurchasePoint=PrchPoint,@UserLLID=LLID,@userScore=SDpoint from RR_UserBanner where USERID = @Userid   
  
if @UserLLID=2 and @userScore>=50001  
set @PurchasePoint=@PurchasePoint-50000  
ELSE IF @UserLLID=3 and @userScore>=150001  
set @PurchasePoint=@PurchasePoint-100000  
ELSE IF @UserLLID=4 and @userScore>=300001  
set @PurchasePoint=@PurchasePoint-150000  
ELSE IF @UserLLID=5 and @userScore>=600001  
set @PurchasePoint=@PurchasePoint-300000  
  
set @PurchasePoint= @PurchasePoint- isnull((select sum(points) from RR_User_Level_Purchase_Points where USERID = @Userid AND LLID=@LLID ),0)    
   
                                      
If @PurchaseType=1 /* Purchase a gift */                                      
Begin                                     
                             
  if exists(select 'x' from RR_product_details where LLID =@LLID and ImageType <>2 and Pid=@Pid and AchPurchasePoint<=@PurchasePoint )                          
  begin                              
  insert into RR_Scoreboard_Purchase(userid,Pid,Purchased,RequestedOn,purchasestatus)                                      
  select @Userid,@Pid,0,GETDATE(),@PurchaseType                                      
  Select 'Great Pick!' As 'Output' 
  
  Exec RR_Redeem_MailAlert @Pid,@Userid
  
                            
  End                                      
  else                                  
  begin                                  
  select 'Oops! You are not eligible to redeem this!'  As 'Output'                                      
  End     
End                                  
Else if @PurchaseType=2                                      
 begin                                 
 Select 'Yay! Awesome deal!' As 'Output'                                    
 End                                     
Else if @PurchaseType=3                                      
Begin                                      
 if exists(select 'x' from RR_product_details where LLID =@LLID and ImageType =2 and Pid=@Pid  and AchPurchasePoint<=@PurchasePoint)                          
  begin                              
  insert into RR_Scoreboard_Purchase(userid,Pid,Purchased,RequestedOn,purchasestatus)                                      
  select @Userid,@Pid,0,GETDATE(),@PurchaseType       
    Exec RR_Redeem_MailAlert @Pid,@Userid
                               
   Select 'Woohoo! That’s a striking choice!' As 'Output'                                      
  End                                      
  else                                  
  begin                                  
  select 'Oops! You are not eligible to redeem this!'  As 'Output'                                      
  End                   
End    
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Scoreboard_Purchase_Ins] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Scoreboard_Purchase_Ins] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Scoreboard_Purchase_Ins] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Scoreboard_Purchase_Ins] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Scoreboard_Purchase_Ins] TO [DB_DMLSupport]
    AS [dbo];

