﻿CREATE procedure  [dbo].[ARC_UserCustomerMove]
@UserId int
As
/*
Created by : Karthik Ic          
Created on : 03 May 2013          
Impact to  : UserCustomer.aspx      
Purpose    : To move  all data from log table and delete the data from userCustomer table.
*/
Begin
if (Select COUNT(*) from ARC_REC_UserCustomer Where UserId=@UserId) > 0
Begin
Declare @EffectiveTo date,@Active int
Set @EffectiveTo = DATEADD(DD,-1,getdate())
Set @Active = 1

if (Select COUNT(*) from ARC_REC_UserCustomer Where UserId = @UserId and CONVERT(date,CREATED_DT) = CONVERT(date,getdate())) > 0
Begin
Set @EffectiveTo = NULL
Set @Active = 0
End
Declare @CustomerLogGroupId int = isnull((Select MAX(LogGroupId) from ARC_REC_UserCustomerLog),0) + 1
Insert into ARC_REC_UserCustomerlog (UCid,CustomerID,UserId,CREATED_BY,CREATED_DT,PrimaryCust,LogGroupId,Active,EffectiveTo)
Select UCid,CustomerID,UserId,CREATED_BY,CREATED_DT,PrimaryCust,@CustomerLogGroupId,@Active,@EffectiveTo From  ARC_REC_UserCustomer Where UserId=@UserId 
Delete from ARC_REC_UserCustomer Where UserId=@UserId 
End
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_UserCustomerMove] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_UserCustomerMove] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_UserCustomerMove] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_UserCustomerMove] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_UserCustomerMove] TO [DB_DMLSupport]
    AS [dbo];

