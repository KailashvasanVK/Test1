﻿CREATE procedure [dbo].[ARC_REC_DesignationConfig]        
      @USER_IDS varchar(Max),                
      @DesignationID INT,                
      @IsPromoted char(1),                
      @CREATED_BY INT    
As        
Begin        
           
if OBJECT_ID('tempdb..#designationconfigusers') is not null drop table #designationconfigusers                    
create table #designationconfigusers(USERID Int,REC_ID Int)                  
Insert into #designationconfigusers(REC_ID)                
Select items from dbo.fnSplitString(@USER_IDS,',')

update  #designationconfigusers set
USERID = ui.USERID
from #designationconfigusers du
join ARC_REC_USER_INFO ui on ui.REC_ID = du.REC_ID

insert into ARC_REC_Designationlog (UserId,DesignationId,CreatedBy,CreatedDt,IsPromoted,OldDesignationId)  
select de.USERID,@DesignationID,@CREATED_BY,GETDATE(),@IsPromoted,ui.DESIGNATION_ID from #designationconfigusers  as de
inner join ARC_REC_USER_INFO as ui on ui.USERID = de.USERID

update ARC_REC_USER_INFO set
DESIGNATION_ID = @DesignationID
where USERID in (select USERID from #designationconfigusers)           

End 





GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_DesignationConfig] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_DesignationConfig] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_DesignationConfig] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_DesignationConfig] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_DesignationConfig] TO [DB_DMLSupport]
    AS [dbo];

