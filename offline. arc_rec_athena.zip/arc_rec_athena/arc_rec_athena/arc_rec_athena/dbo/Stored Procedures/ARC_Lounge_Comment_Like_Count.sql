﻿ CREATE procedure ARC_Lounge_Comment_Like_Count(@CmtId int=0)      
 as      
 begin      
 select COUNT(cl.id)'MsgLikeCount',cl.CommId,cl.status  from ARC_Forum_Lounge_Comment_Likes cl
 Where  cl.CommId=@CmtId and cl.Status=1   
 group by cl.CommId,cl.status      
       
 end 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Comment_Like_Count] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Comment_Like_Count] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Comment_Like_Count] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Comment_Like_Count] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Comment_Like_Count] TO [DB_DMLSupport]
    AS [dbo];

