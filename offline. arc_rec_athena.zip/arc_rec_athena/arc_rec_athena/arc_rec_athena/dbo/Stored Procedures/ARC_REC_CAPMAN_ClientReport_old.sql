﻿CREATE Procedure ARC_REC_CAPMAN_ClientReport_old         
(          
@ClientId int=0          
)          
As          
/*          
ARC_REC_CAPMAN_ClientReport @ClientId=0          
*/          
Begin          
          
Select CLIENT_ID 'SL.No',CLIENT_NAME Client,OnRoll 'On Rolls (A)',OpenPotion 'ARMS Open (B)',(OnRoll+OpenPotion) 'Total (A+B)' ,Blocked ' Blocked (C)','Tobe Block (A+B)-C'=((OnRoll+OpenPotion)-blocked)          
,'Utilized %'=Cast((case when (OnRoll+OpenPotion)!=0 then ((blocked*1.0/(OnRoll+OpenPotion))*100) else 0 end) as numeric(18,0))          
--,'Tobe Utilized %'=Cast((case when (OnRoll+OpenPotion)!=0 then ((((OnRoll+OpenPotion)-blocked)*1.0/(OnRoll+OpenPotion))*100) else 0 end) as numeric(18,0))          
          
 from  (                
select ci.CLIENT_ID,CLIENT_NAME ,                
OnRoll=(select COUNT(*) from ARC_REC_User_info UI where UI.CLIENT_ID=Ci.CLIENT_ID and UI.ACTIVE =1 ),                
OpenPotion=(select isnull(SUM(pending),0) from ARMS_Status where clientid=ci.client_id ) ,                
blocked=(select COUNT(*) from ARC_REC_CAPMAN where  clientid=ci.client_id  and Status =1 and BayStatus =1 )                
from ARC_FIN_CLIENT_INFO CI where CLIENT_ID =(case when @Clientid=0 then client_id else @Clientid end) ) as Udhaya            
          
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_ClientReport_old] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_ClientReport_old] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_ClientReport_old] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_ClientReport_old] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_ClientReport_old] TO [DB_DMLSupport]
    AS [dbo];

