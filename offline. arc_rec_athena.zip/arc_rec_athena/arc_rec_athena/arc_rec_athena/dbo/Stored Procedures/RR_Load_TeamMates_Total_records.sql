﻿create procedure [dbo].[RR_Load_TeamMates_Total_records]
as
begin

select MAX(tab1.rownumber) as total from (SELECT ROW_NUMBER() over (order by NT_USERNAME) as rownumber  from ARC_REC_USER_INFO UI    
inner Join ARC_FIN_CLIENT_INFO CI on CI.CLIENT_ID=Ui.CLIENT_ID     
where UI.ACTIVE=1 and AHS_PRL='Y' and USERID  <> 535 and NT_USERNAME<>'') as tab1
end

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Load_TeamMates_Total_records] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Load_TeamMates_Total_records] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Load_TeamMates_Total_records] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Load_TeamMates_Total_records] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Load_TeamMates_Total_records] TO [DB_DMLSupport]
    AS [dbo];

