﻿ CREATE PROCEDURE [dbo].[ARC_KIN_ACTION_ITEMS_INFO]                                                  
@ACTION VARCHAR(50) = NULL                              
,@QID INT = NULL                            
,@COMMENTS VARCHAR(MAX) = NULL           
,@FINALCOMMENTS VARCHAR(MAX) = NULL            
,@ROOTCAUSE VARCHAR(MAX) = NULL                             
,@MAILSTATUS BIT                            
,@STATUS TINYINT                            
,@CREATEDBY INT                          
,@FROMDT DATETIME                         
,@TODT DATETIME                        
,@STRQUERY VARCHAR(MAX)                         
AS                              
                              
BEGIN                           
                           
 IF @ACTION = 'INSERT'                              
 BEGIN                              
   INSERT INTO ARC_KIN_ACTION_ITEMS(QID,ACTIONITEM,ROOTCAUSE,STATUS,CREATEDBY,CREATEDDT)                            
   SELECT @QID,@COMMENTS,@ROOTCAUSE,1,@CREATEDBY,GETDATE()        
 END                          
                        
 IF @ACTION = 'QID_CHK_EXIST'                              
 BEGIN                              
   SELECT * FROM  ARC_KIN_ACTION_ITEMS WHERE QID=@QID AND STATUS=1                            
 END                          
                    
 IF @ACTION = 'INSERT_TRAN'                              
 BEGIN                              
   INSERT INTO ARC_KIN_TRANS(QID,FINALCOMMENTS,STATUS,CREATEDBY,CREATEDDT)                           
   SELECT @QID,@FINALCOMMENTS,1,@CREATEDBY,GETDATE()                        
   UPDATE ARC_KIN_QUERIES SET STATUS=0 WHERE QID=@QID AND STATUS=1                         
 END                        
                        
 IF @ACTION = 'QUERY_REPORTS'                              
 BEGIN                              
 SELECT ROW_NUMBER() OVER (ORDER BY KQ.QID) AS SNO,KQ.QID,KQ.QUERY AS GRIEVANCE,RUI.NT_USERNAME AS RAISEDBY,CONVERT(VARCHAR(10),KQ.CREATEDDT,101) AS RAISEDDT                      
 ,KAI.ACTIONITEM AS ACTIONCOMMENTS,RUI1.NT_USERNAME AS RESOLVEDBY,CONVERT(varchar(10),KAI.CREATEDDT,101) AS RESOLVEDDT                      
 ,CASE WHEN KT.STATUS = 1  AND KAI.ACTIONITEM IS NOT NULL                   
 THEN 'Completed'                  
 WHEN KAI.ACTIONITEM IS NOT NULL AND KQ.STATUS=1                   
 THEN 'Pending'                  
 ELSE 'Open'                 
 END  AS GRIEVANCESTATUS      
 ,KAI.ROOTCAUSE      
 ,KT.FINALCOMMENTS  
 ,HF.JobTitle AS Department                      
 FROM ARC_KIN_QUERIES KQ                        
 LEFT JOIN ARC_REC_USER_INFO RUI ON RUI.USERID=KQ.CREATEDBY                        
 LEFT JOIN ARC_KIN_ACTION_ITEMS KAI ON KAI.QID=KQ.QID                        
 LEFT JOIN ARC_REC_USER_INFO RUI1 ON RUI1.USERID=KAI.CREATEDBY                        
 LEFT JOIN ARC_KIN_TRANS KT ON KT.QID=KQ.QID  
 INNER JOIN HR_Functionality HF ON HF.FunctionalityId = RUI.FUNCTIONALITY_ID                         
           
 END                        
                     
 IF @ACTION = 'QUERY_SEARCH_RESULTS'                              
 BEGIN                              
   EXEC ('SELECT ROW_NUMBER() OVER (ORDER BY KQ.QID) AS SNO,KQ.QID,KQ.QUERY AS GRIEVANCE,RUI.NT_USERNAME AS RAISEDBY,CONVERT(VARCHAR(10),KQ.CREATEDDT,101) AS RAISEDDT                      
  ,KAI.ACTIONITEM AS ACTIONCOMMENTS,RUI1.NT_USERNAME AS RESOLVEDBY,CONVERT(varchar(10),KAI.CREATEDDT,101) AS RESOLVEDDT                      
  ,CASE WHEN KT.STATUS = 1  AND KAI.ACTIONITEM IS NOT NULL                   
  THEN ''Completed''                  
  WHEN KAI.ACTIONITEM IS NOT NULL AND KQ.STATUS=1                   
  THEN ''Pending''                  
  ELSE ''Open''                   
  END  AS GRIEVANCESTATUS      
  ,KAI.ROOTCAUSE      
  ,KT.FINALCOMMENTS  
  ,HF.JobTitle AS Department            
  FROM ARC_KIN_QUERIES KQ                        
  LEFT JOIN ARC_REC_USER_INFO RUI ON RUI.USERID=KQ.CREATEDBY          
  LEFT JOIN ARC_KIN_ACTION_ITEMS KAI ON KAI.QID=KQ.QID   
  LEFT JOIN ARC_REC_USER_INFO RUI1 ON RUI1.USERID=KAI.CREATEDBY                        
  LEFT JOIN ARC_KIN_TRANS KT ON KT.QID=KQ.QID  
  INNER JOIN HR_Functionality HF ON HF.FunctionalityId = RUI.FUNCTIONALITY_ID                         
  WHERE '+ @STRQUERY)                         
 END                      
                       
  IF @ACTION = 'CHART_QUERY_REPORTS'                         
  BEGIN                      
  SELECT         
  OPENED = COUNT(*),        
  PENDING = COUNT(CASE WHEN KQ.STATUS=1 AND KAI.ACTIONITEM IS NOT NULL THEN KQ.QID END),      COMPLETED = COUNT(CASE WHEN KQ.STATUS=0 AND KT.STATUS=1 AND KAI.ACTIONITEM IS NOT NULL THEN KQ.QID END)                      
  FROM  ARC_KIN_QUERIES KQ                    
  LEFT JOIN ARC_KIN_ACTION_ITEMS KAI ON KAI.QID=KQ.QID                    
  LEFT JOIN ARC_KIN_TRANS KT ON KT.QID=KQ.QID         
          
  END                                      
          
  IF @ACTION = 'CHART_QUERY_REPORTS_DATE'                              
  BEGIN                      
  SELECT         
  OPENED = COUNT(*),        
  PENDING = COUNT(CASE WHEN KQ.STATUS=1 AND KAI.ACTIONITEM IS NOT NULL THEN KQ.QID END),        
  COMPLETED = COUNT(CASE WHEN KQ.STATUS=0 AND KT.STATUS=1 AND KAI.ACTIONITEM IS NOT NULL THEN KQ.QID END)                      
  FROM  ARC_KIN_QUERIES KQ                    
  LEFT JOIN ARC_KIN_ACTION_ITEMS KAI ON KAI.QID=KQ.QID                    
  LEFT JOIN ARC_KIN_TRANS KT ON KT.QID=KQ.QID                      
  WHERE CONVERT(VARCHAR,KQ.CREATEDDT,101) BETWEEN @FROMDT AND @TODT                           
  END            
              
  IF @ACTION = 'QUERY_REPORTS_BYUSER'                              
  BEGIN                              
  SELECT ROW_NUMBER() OVER (ORDER BY KQ.QID) AS SNO,KQ.QID,KQ.QUERY,        
  RUI.NT_USERNAME AS CREATEDBY,        
  CONVERT(VARCHAR(10),KQ.CREATEDDT,101) AS CREATEDDT                        
  ,KT.FINALCOMMENTS AS COMMENTS,        
  RUI1.NT_USERNAME AS COMMENTBY,        
  CONVERT(varchar(10),KAI.CREATEDDT,101) AS COMMENTDT,        
  CASE WHEN KT.STATUS = 1  AND KAI.ACTIONITEM IS NOT NULL                     
  THEN 'Completed'                    
  WHEN KAI.ACTIONITEM IS NOT NULL AND KQ.STATUS=1                     
  THEN 'Pending'                    
  ELSE 'Open'                     
  END  AS STATUS                      
  FROM ARC_KIN_QUERIES KQ                        
  LEFT JOIN ARC_REC_USER_INFO RUI ON RUI.USERID=KQ.CREATEDBY                        
  LEFT JOIN ARC_KIN_ACTION_ITEMS KAI ON KAI.QID=KQ.QID                        
  LEFT JOIN ARC_REC_USER_INFO RUI1 ON RUI1.USERID=KAI.CREATEDBY                        
  LEFT JOIN ARC_KIN_TRANS KT ON KT.QID=KQ.QID                      
  WHERE KQ.CREATEDBY=@CREATEDBY                          
 END  
   
 IF @ACTION = 'SELECTBY_QID'                              
 BEGIN                              
 SELECT AKQ.QUERY    
 ,ARUI.NT_USERNAME AS RAISEDBY    
 ,CONVERT(VARCHAR,AKQ.CREATEDDT,101)AS RAISEDDT     
 ,AKAI.ACTIONITEM AS ACTCOMMENTS,AKAI.ROOTCAUSE    
 ,ARUI1.NT_USERNAME AS RESOLVEDBY    
 ,CONVERT(VARCHAR,AKAI.CREATEDDT ,101)AS RESOLVEDDT    
 ,AKT.FINALCOMMENTS    
 ,CASE WHEN AKT.STATUS = 1  AND AKAI.ACTIONITEM IS NOT NULL                     
 THEN 'Completed' WHEN AKAI.ACTIONITEM IS NOT NULL AND AKQ.STATUS=1                     
 THEN 'Pending' ELSE 'Open' END  AS STATUS    
    
 FROM ARC_KIN_QUERIES AKQ    
 INNER JOIN ARC_KIN_ACTION_ITEMS AKAI ON AKAI.QID=AKQ.QID    
 INNER JOIN ARC_REC_USER_INFO ARUI ON ARUI.USERID=AKQ.CREATEDBY    
 INNER JOIN ARC_REC_USER_INFO ARUI1 ON ARUI1.USERID=AKAI.CREATEDBY    
 LEFT JOIN ARC_KIN_TRANS AKT ON AKT.QID=AKQ.QID    
 WHERE AKQ.QID=@QID                              
 END   
                                                    
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_KIN_ACTION_ITEMS_INFO] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_KIN_ACTION_ITEMS_INFO] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_KIN_ACTION_ITEMS_INFO] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_KIN_ACTION_ITEMS_INFO] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_KIN_ACTION_ITEMS_INFO] TO [DB_DMLSupport]
    AS [dbo];

