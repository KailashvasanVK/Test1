﻿ CREATE Proc RR_UserBanner_Popup_Get                                
@userid int=1,              
@LLID int=1                 
as                                
/*                            
RR_UserBanner_Popup_Get @userid=807 ,@LLID=1                         
*/                            
begin                
Declare @prchpoint int,@sdpoint int             
            
select LLId,USERID,Name,photo,SDpoint,PrchPoint,League+' League' League,LeaguePath,Client,    
LeagueName=(select top 1 LeagueName from RR_UserBanner where LLID=@LLID ),    
LeagueBannerName=(select top 1 League+' League' from RR_LeagueLevel  where LLID=@LLID )       
 from      
  RR_UserBanner where userid=@userid                                                 
                  
select @prchpoint=prchpoint,@sdpoint=SDpoint from RR_UserBanner where userid=@userid               
select ROW_NUMBER() over( order by pd.PID  asc)sno, pd.PID,LLID,Productname,PPath,Purchasepoint,                                
Active=(case when purchasepoint <=@sdpoint then 1 else 0 end),                   
purchase=(case when p.PId Is not null then 1 else 0 end) ,                    
Purchasestatus =(Case when p.PurchaseStatus IS  null then ' Waiting !' when p.PurchaseStatus =1 then 'Reedemed the Gift' when  p.PurchaseStatus =2 then 'Waiting for Next Gift'                    
 when  p.PurchaseStatus =2 then 'Waiting for Big Gift' end)                    
 from RR_Product_Details PD                           
 left join RR_SCOREBOARD_PURCHASE P on p.PId=pd.Pid and p.Userid=@userid                          
where status=1   and LLID= @LLID              
end
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_UserBanner_Popup_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_UserBanner_Popup_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_UserBanner_Popup_Get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_UserBanner_Popup_Get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_UserBanner_Popup_Get] TO [DB_DMLSupport]
    AS [dbo];

