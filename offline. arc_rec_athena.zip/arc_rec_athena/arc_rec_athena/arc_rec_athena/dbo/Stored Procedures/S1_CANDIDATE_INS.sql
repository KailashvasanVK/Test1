﻿CREATE PROCEDURE [dbo].[S1_CANDIDATE_INS]                            
(                            
 @NAME VARCHAR(30)                            
,@CONTACTNO VARCHAR(15)                            
,@APPLY_FB INT=0                        
,@REC_ID VARCHAR(10) OUTPUT                            
)                            
AS                            
BEGIN

if not exists(select 'x' from ARC_REC_CANDIDATE where RegByAHS=0 and NAME=@NAME and CONTACTNO=@CONTACTNO )
begin
SELECT @REC_ID = ISNULL(COUNT(*),0) + 1 FROM ARC_REC_CANDIDATE                          
WHERE DATEPART(M,CREATED_DT) = DATEPART(M,GETDATE())                          
Declare @len int                      
Select @len = case when LEN(@rec_id) <= 3 then 3 else LEN(@REC_ID) end                      
SELECT @REC_ID = SUBSTRING(CONVERT(VARCHAR,GETDATE(),12),1,4) + REPLICATE('0',@len-LEN(@REC_ID)) + @REC_ID                         
                          
INSERT INTO ARC_REC_CANDIDATE(REC_ID,NAME,CONTACTNO,APPLY_FB,RegByAHS)                            
VALUES (@REC_ID,@NAME,@CONTACTNO,@APPLY_FB,0)        
  
update ARC_REC_CANDIDATE set PROFILE_IMAGE_NAME= @REC_ID+'.jpg' where rec_id=@REC_ID       
end      
else
begin

select @REC_ID =rec_id from ARC_REC_CANDIDATE where RegByAHS=0 and @NAME=@NAME and CONTACTNO=@CONTACTNO

update ARC_REC_CANDIDATE set PROFILE_IMAGE_NAME= @REC_ID+'.jpg' where rec_id=@REC_ID       

end
                          
END 


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[S1_CANDIDATE_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[S1_CANDIDATE_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[S1_CANDIDATE_INS] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[S1_CANDIDATE_INS] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[S1_CANDIDATE_INS] TO [DB_DMLSupport]
    AS [dbo];

