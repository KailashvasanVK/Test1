﻿CREATE PROCEDURE [dbo].[HR_InsertMPR]                  
                  
-----------------------------------------------------------                  
--Created By : Udhayaganesh p                  
--Created on : 30/8/2011                  
--Description : This SP is to insert into MPR Table                   
               
-----------------------------------------------------------                  
                  
 @TCId INT,                  
 @DesigId INT = NULL,                  
 @FunctionalityId INT = NULL,                  
 @TotalPositions tinyint = NULL,                  
 @SalaryMax INT = NULL,                  
 @SalaryMin INT = NULL,                  
 @ExpDate DATETIME = NULL,                  
 @FromExperience varchar(10) = NULL,                  
 @ToExperience varchar(10) = NULL,                  
 @Skillset VARCHAR(250) = NULL,                  
 @Qualification VARCHAR(100) = NULL,                  
 @NatureofWork VARCHAR(250) = NULL,                  
 @TargetIndustry VARCHAR(250) = NULL,                  
 @Reason VARCHAR(250) = NULL,                  
 @CreatedBy INT,        
 @Clientid int=0,      
 @Published tinyint,    
 @PositionType tinyint=0                
                       
                  
AS                  
                  
DECLARE @MPRId INT;                  
                  
 INSERT INTO HR_MPR                  
 (                  
  TCId,                  
  DesigId,                  
  FunctionalityId,                  
  TotalPositions,                  
  SalaryMax,                  
  SalaryMin,                  
  ExpDate,                  
  --Experience,                  
  expfromyears,                
  exptoyears,                 
  Skillset,                  
  Qualification,                  
  NatureofWork,                  
  TargetIndustry,                  
  Reason,                  
  CreatedBy,                  
  CreatedDate,                  
  ApprovalStatus,                  
  MPRStatus,        
  Clientid,      
  Published,    
  PositionType                 
                  
 )                  
                  
 VALUES                  
 (                  
  @TCId,                  
  @DesigId,                  
  @FunctionalityId,                  
  @TotalPositions,                  
  @SalaryMax,                  
  @SalaryMin,                  
  @ExpDate,                  
                
-- @Experience,                
 @FromExperience,                
 @ToExperience,                
                
  @Skillset,                  
  @Qualification,                  
  @NatureofWork,                  
  @TargetIndustry,                  
  @Reason,                  
  @CreatedBy,                  
  GETDATE(),                  
  0,                  
  0,        
  @Clientid,      
  @Published,    
  @PositionType                
 )                  
                  
  SET @MPRId = scope_Identity();                    
                  
                  
IF (@MPRId >= 1)                  
                  
 BEGIN                  
                  
                  
  SELECT                    
    convert(varchar(25), mpr.CreatedDate, 107) as 'Raisedon',                  
    um.UserName, tm.Facility TrainingCentre, f.FunctionName, d.Designation,                   
    convert(varchar(25), mpr.ExpDate, 107) as 'ExpDate',                
    mpr.expfromyears as 'FromExperience',                
    mpr.expToyears as 'ToExperience',                
    um.mailid as [MailId],                  
    dbo.RupeeFormat_Rounded(SalaryMax) as 'SalaryMax',                  
    dbo.RupeeFormat_Rounded(SalaryMin) as 'SalaryMin',        
    cl.CLIENT_NAME As ClientName, mpr.*                   
                  
                  
  FROM                   
   HR_MPR mpr INNER JOIN HR_functionality f on f.FunctionalityId = mpr.FunctionalityId                  
        INNER JOIN HR_designation d on d.desigId = mpr.desigID                  
        INNER JOIN HR_FacilityMaster tm on tm.Tcid = mpr.Tcid                  
        INNER JOIN mrplogin um on um.UserId = mpr.CreatedBy         
        inner join  ARC_FIN_CLIENT_INFO Cl on cl.CLIENT_ID =mpr.clientid                  
        where mpr.MPRId = @MPRId                  
                  
 END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_InsertMPR] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_InsertMPR] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_InsertMPR] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_InsertMPR] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_InsertMPR] TO [DB_DMLSupport]
    AS [dbo];

