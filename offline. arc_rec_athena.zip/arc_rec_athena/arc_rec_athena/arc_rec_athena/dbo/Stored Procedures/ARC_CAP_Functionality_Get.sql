﻿  
CREATE Proc ARC_CAP_Functionality_Get  
as  
select FunctionalityId,JobTitle  from HR_Functionality 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_CAP_Functionality_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_CAP_Functionality_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_CAP_Functionality_Get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_CAP_Functionality_Get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_CAP_Functionality_Get] TO [DB_DMLSupport]
    AS [dbo];

