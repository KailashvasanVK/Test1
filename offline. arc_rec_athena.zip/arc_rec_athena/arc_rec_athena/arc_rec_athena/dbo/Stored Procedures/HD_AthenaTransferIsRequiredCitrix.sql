﻿--HD_AthenaTransferIsRequiredCitrix 1049      
CREATE proc HD_AthenaTransferIsRequiredCitrix      
      @Userid int        
as        
begin        
--declare @AthenaUserid as int        
--set @AthenaUserid =31        
  declare @HasCitrix char(1)    
  IF OBJECT_ID('TEMPDB..#ExistingUserInfo') IS NOT NULL DROP TABLE #ExistingUserInfo  
  create table #ExistingUserInfo  (UserId int,RoleId int, DeptId int, NeedCitrix char(1))    
    
       
  if( select COUNT(*) from HD_Athena_Transfer where UserId = @Userid and Status = 3) > 0  
  begin  
  insert into #ExistingUserInfo(UserId,RoleId,DeptId)  
  select @Userid,RoleId,DeptId from HD_Athena_Transfer where UserId = @Userid  and Status = 3 
  end  
  else  
  begin  
  insert into #ExistingUserInfo(UserId,RoleId,DeptId)    
  select @Userid,RoleId,DeptId from HD_AthenaUsers where UserId = @Userid and Status = 3     
  end  
       
if( select COUNT(*) from HD_Athena_Transfer where UserId = @Userid and AddCitrix <> '') > 0        
begin   
      select @HasCitrix = AddCitrix from HD_Athena_Transfer where UserId = @Userid and AddCitrix <> '' order by TransferId desc          
      if(@HasCitrix = 'Y')        
  set @HasCitrix = 'N'         
   else if(@HasCitrix = 'N')          
  set @HasCitrix = 'Y'         
       
end        
else        
begin        
select @HasCitrix = HasCitrixReq from HD_AthenaUsers where UserId = @Userid        
if(@HasCitrix = 'Y')        
  set @HasCitrix = 'N'         
   else          
  set @HasCitrix = 'Y'         
end        
update #ExistingUserInfo set  
NeedCitrix = @HasCitrix  
where UserId = @Userid  
  
select * from #ExistingUserInfo  
end  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_AthenaTransferIsRequiredCitrix] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_AthenaTransferIsRequiredCitrix] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_AthenaTransferIsRequiredCitrix] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_AthenaTransferIsRequiredCitrix] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_AthenaTransferIsRequiredCitrix] TO [DB_DMLSupport]
    AS [dbo];

