﻿CREATE proc ARC_REC_SchedulerInbox      
@SearchStr varchar(100) = '',                                             
@SearchPattern varchar(4) = '=' /** = or % **/       
AS      
Begin      
 Declare @OrderStr varchar(100)       
SELECT       
'<input name="active" type="checkbox" value="'+convert(varchar,S.REC_ID)+'*'+convert(varchar,SI.STATUS_ID)+'" class="CheckAll" id="'+convert(varchar,S.REC_ID)+'" />' as [CheckAll]      
,S.REC_ID as [REC_ID~Hide]
,'<div style="text-decoration:underline; cursor:pointer; color:#2A7FFF;" onclick="LoadCandidateInfo('+convert(varchar,S.REC_ID)+');">'+convert(varchar,S.REC_ID)+'</div>' AS CANDIDATE    
 ,(C.FIRSTNAME+' '+C.LASTNAME) AS NAME,CONVERT(VARCHAR,S.CREATED_DT,106) AS [PASSED ON]      
 ,C.REL_EXP as [REL_EXP~Hide],E.REL_EXP_TEXT as [EXPERIENCE],C.PROCESS_ID as [PROCESS_ID~Hide],P.PROCESS_NAME as PROCESS,SI.STATUS_ID as [STATUS_ID~Hide],      
 SI.STATUS_TEXT as [Status]      
 into #Recruit_InboxView FROM ARC_REC_CANDIDATE_STATUS S                               
 INNER JOIN ARC_REC_CANDIDATE_STATUS_INFO SI                  
 ON S.STATUS_ID =SI.STATUS_ID                    
 INNER JOIN ARC_REC_CANDIATE_PROFILE C                  
 ON S.REC_ID = C.REC_ID                 
 INNER JOIN ARC_REC_CANDIDATE D               
 ON C.REC_ID = D.REC_ID                 
 INNER JOIN ARC_REC_PROCESS_INFO P                 
 ON  C.PROCESS_ID = P.PROCESS_ID                  
 INNER JOIN ARC_REC_EXPERIENCE_INFO E                    
 ON C.REL_EXP =  E.REL_EXP                   
 WHERE S.STATUS_ID IN (1,2,3) AND S.SCHEDULE_ID = 0                 
 AND S.REC_ID NOT IN (SELECT REC_ID FROM ARC_REC_ASSESSMENT where ASSESS_MODE = 'S' AND APPLICANT_STATUS = 'S')                   
 AND S.REC_ID NOT IN (SELECT REC_ID FROM ARC_REC_USER_INFO where AHS_PRL = 'Y' AND ACTIVE = 1)      
       
 SET @OrderStr  = ' order by [PASSED ON] desc'                                                        
                                  
Exec FilterTable                                              
@DbName = 'tempdb'                                              
,@TblName = '#Recruit_InboxView'                                          
,@SearchStr = @SearchStr                                              
,@SearchPattern = @SearchPattern                                              
,@OrderStr = @OrderStr                                              
if OBJECT_ID('tempdb..#Recruit_InboxView') is not null drop table #Recruit_InboxView      
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_SchedulerInbox] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_SchedulerInbox] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_SchedulerInbox] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_SchedulerInbox] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_SchedulerInbox] TO [DB_DMLSupport]
    AS [dbo];

