﻿CREATE Proc ARC_ME_PendingLeaves  
(  
@UserId int  
,@Month int = 0  
,@Year int = 0  
,@EL_HasLimit varchar = 'Y'  
,@RptType varchar(30) = 'PendingLeaves' /** 'PendingLeavesDetailed' **/  
)  
As  
Begin  
--/**  
--Created By : Mohamed Safiyullah  
--Created On : 17 Dec 2013  
--Purpose : To get pending leaves details for all leave types  
--**/  
  
--Declare @Month int =6  
--Declare @Year int = 2014  
--Declare @UserId int = 321  
--Declare @EL_HasLimit varchar = 'N'  
--Declare @RptType varchar(30) = 'PendingLeaves'  
  
  
Declare @CompOffPending decimal(9,1) = 0  
Declare @Qry varchar(max)  
/** Setting default values **/  
Declare @ToDate date  
Declare @SystemDate date   
Set @SystemDate = GETDATE()  
if isnull(@Month,0) = 0 Set @Month = Datepart(MM,@SystemDate)  
if ISNULL(@Year,0) = 0 Set @Year = DATEPART(YYYY,@SystemDate)  
Set @ToDate = DateAdd(DD,-1,DateAdd(MM,1,Convert(date,Convert(varchar,@Year) + '-' + Convert(varchar,@Month) + '-' + '01')))  
Declare @UserActDoj date  
Declare @UserDoj date  
Select @UserDoj = Doj,@UserActDoj = ISNULL(predoj,doj) from ARC_REC_USER_INFO where USERID = @UserId  
  
Declare @AttStartDate date  
set @AttStartDate = Convert(date,convert(varchar,@Year) + '-01-01')  
if OBJECT_ID('tempdb..#CompOffCredit') IS NOT NULL DROP TABLE #CompOffCredit  
Create Table #CompOffCredit(CrDate date, Credit Decimal(5,1),CrValidateDate date, Debit Decimal(5,1),RowId int identity(1,1))  
if OBJECT_ID('tempdb..#CompOffAvailed') IS NOT NULL DROP TABLE #CompOffAvailed  
Create Table #CompOffAvailed(AvailedDate date, Availed Decimal(5,1),Adjusted Decimal(5,1),RowId int identity(1,1))  
  
if OBJECT_ID('tempdb..#GetPendingLeaves') IS NOT NULL DROP TABLE #GetPendingLeaves  
create table #GetPendingLeaves(Descript varchar(20), Credit Decimal(5,1),Debit Decimal(5,1),Closing Decimal(5,1),TypeId int,TypeText varchar(20), UserId int,RwId int identity,TranDate date)  
  
if OBJECT_ID('tempdb..#GetAvailedLeaves') IS NOT NULL DROP TABLE #GetAvailedLeaves  
Select *   
INTO #GetAvailedLeaves  
from  
(  
SELECT CASE WHEN LT.LEAVE_DATE IS NOT NULL THEN LT.LEAVE_DATE ELSE LR.FROMDATE END AS LEAVE_DATE,LR.TYPEID,LR.CREATED_BY AS UserId,LR.LEAVE_MODE  
FROM ARC_REC_LEAVE_REQUEST AS LR   
LEFT JOIN ARC_REC_LEAVE_TRAN AS LT  (nolock)  ON LT.LEAVE_REQID = LR.LEAVE_REQID  
WHERE LR.CREATED_BY = @UserId  
AND LR.ACTIVE = 'Y' AND LR.LEAVE_STATUS in(0,1)  
GROUP BY LR.TYPEID,LT.LEAVE_DATE,LR.FROMDATE,LR.CREATED_BY,lr.LEAVE_MODE  
) as availed   
Where datepart(yyyy,availed.LEAVE_DATE) = @Year  
  
Insert into #CompOffAvailed(AvailedDate,Availed)  
SELECT CASE WHEN LT.LEAVE_DATE IS NOT NULL THEN LT.LEAVE_DATE ELSE LR.FROMDATE END AS LEAVE_DATE,Case when LR.LEAVE_MODE = 'F' then 1 else 0.5 end  
FROM ARC_REC_LEAVE_REQUEST AS LR   
inner JOIN ARC_REC_LEAVE_TRAN AS LT  (nolock)  ON LT.LEAVE_REQID = LR.LEAVE_REQID  and datepart(yyyy,LT.LEAVE_DATE) = @Year  
WHERE LR.CREATED_BY = @UserId  
AND LR.ACTIVE = 'Y' AND LR.LEAVE_STATUS in(0,1) and lr.TYPEID = 4  
  
/** create date list **/    
Declare @tempStartDate date    
Declare @tempEndDate date    
Declare @tempToDate date        
Select @tempToDate = Case when MAX(leave_date) > @ToDate then MAX(leave_date) else @ToDate end  from #GetAvailedLeaves        
Set @tempToDate = DATEADD(dd,-1,DATEADD(MM,1,Convert(date,Convert(varchar,DATEPART(YYYY,@tempToDate)) + '-' + Convert(varchar,(DATEPART(MM,@tempToDate)))   + '-01')))  
set @tempStartDate = convert(varchar,DATEPART(yyyy,@AttStartDate)) + '-01-01'    
if OBJECT_ID('tempdb..#trandate_list') is not null drop table #trandate_list    
create table #trandate_list(trandate date)    
while  @tempStartDate <= @ToDate--@tempToDate  
  begin      
  if dateadd(mm,-1,@UserDoj) <= @tempStartDate  
  insert into #trandate_list(trandate)select @tempStartDate    
  set @tempStartDate = DATEADD(MONTH,1,@tempStartDate)    
  end    
  
   
insert into #GetPendingLeaves(Descript,Debit,Credit,Closing,TypeId,UserId,TypeText,TranDate)  
Select Descript,0,0,0,TypeId,@UserId,SHORT_TEXT,TranDate from  
(  
SELECT 'Opening' as Descript,LT.TYPEID,lt.SHORT_TEXT,1 Result,Convert(date,Null) TranDate  
FROM ARC_REC_LEAVE_TYPES AS LT   
union all  
SELECT DATENAME(MM,TL.trandate),LT.TYPEID,lt.SHORT_TEXT,2 Result,TL.trandate  
FROM #trandate_list AS TL  
inner join ARC_REC_LEAVE_TYPES as LT on 1=1  
)x  
order by TYPEID,Result,TranDate  
  
  
Begin /* Opening */  
 /** opening updation **/  
 update #GetPendingLeaves set Credit = LO.LEAVES,Closing = LO.LEAVES  
 from #GetPendingLeaves PL  
 inner join ARC_REC_LEAVE_OPENING  (nolock) as LO ON LO.EMPLOYEE_ID = @UserId AND LO.TYPEID = PL.TypeId and Datepart(YYYY,OPENING_DATE) = (@Year - 1)  
 Where Descript = 'Opening'  
 /** opening for it and network updation **/  
 update #GetPendingLeaves set Credit = LO.LEAVES,Closing = LO.LEAVES  
 from #GetPendingLeaves PL  
 inner join ARC_REC_LeaveOpeningForITNet  (nolock) as LO ON LO.EMPLOYEE_ID = @UserId AND LO.TYPEID = PL.TypeId and Datepart(YYYY,OPENING_DATE) = @Year  
 Where Descript = 'Opening'  
 /** opening updation for ml **/  
 update #GetPendingLeaves set Credit = 84 ,Closing = 84  
 where TypeId = 7 /** for ml **/ and Descript = 'Opening'  
   
 Insert into #CompOffCredit(CrDate,CrValidateDate,Credit)  
 Select convert(date,Convert(varchar,@Year) + '-01-01'),DATEADD(DD,90,convert(date,Convert(varchar,@Year) + '-01-01')), LEAVES as CompOff From ARC_REC_LEAVE_OPENING Where EMPLOYEE_ID = @UserId and Datepart(YYYY,OPENING_DATE) = (@Year - 1) and TYPEID = 4  
 union all  
 Select convert(date,Convert(varchar,@Year) + '-01-01'),DATEADD(DD,90,convert(date,Convert(varchar,@Year) + '-01-01')), LEAVES as CompOff From ARC_REC_LeaveOpeningForITNet Where EMPLOYEE_ID = @UserId and Datepart(YYYY,OPENING_DATE) = @Year and TYPEID = 4 
  
  
  
  
End  
  
Begin/** Update Credit leaves **/  
 update #GetPendingLeaves set Credit =       
 case when pl.TranDate <= @ToDate then       
  case when DATEPART(YEAR,PL.TranDate) = DATEPART(year,@UserDoj) and DATEPART(Month,PL.TranDate) = DATEPART(Month,@UserDoj) and DATEPART(DAY,@UserDoj) < 15 then 1       
  when DATEPART(YEAR,PL.TranDate) = DATEPART(year,@UserDoj) and DATEPART(Month,PL.TranDate) = DATEPART(Month,@UserDoj) and DATEPART(DAY,@UserDoj) > 15 then 0     
  when pl.TranDate > @UserDoj then 1 else 0 end      
   else 0 end      
 from #GetPendingLeaves PL    
 where pl.TypeId in (1,2) and Descript <> 'Opening'  
       
 update #GetPendingLeaves set Credit = case when ISNULL(DATEDIFF(month,@UserDoj,TranDate),0) > 12 then 1 else 0 end    
 from #GetPendingLeaves PL    
 where pl.TypeId = 3  and Descript <> 'Opening'  
 and pl.UserId not in (select Employee_Id from ARC_REC_LeaveOpeningForITNet)       
        
 update #GetPendingLeaves set Credit = case when (ISNULL(DATEDIFF(month,@UserActDoj,TranDate),0)) > 12 AND TranDate > @UserDoj then 1 else 0 end    
 from #GetPendingLeaves PL    
 where pl.TypeId = 3  and Descript <> 'Opening'  
 and pl.UserId in (select Employee_Id from ARC_REC_LeaveOpeningForITNet)  
  
 Insert into #CompOffCredit(CrDate,CrValidateDate, Credit)  
 Select Date,DATEADD(DD,90,date),P_Days as CompOff From ARC_REC_Attendance Where Userid = @UserId and DATEPART(YYYY,DATE) = @Year and isnull(CompOffEligible,0) = 1  
 and p_days > 0 Order by date  
   
 update #GetPendingLeaves set Credit = Comp.CompOff  
 from #GetPendingLeaves PL    
 inner join   
 (   
 Select DATENAME(MM,Date) as MMonth,SUM(P_Days) as CompOff From ARC_REC_Attendance Where Userid = @UserId and DATEPART(YYYY,DATE) = @Year and isnull(CompOffEligible,0) = 1  
 group by DATENAME(MM,Date)  
 ) as Comp on Comp.MMonth = dateName(MM,PL.TranDate)  
 where pl.TypeId = 4  and Descript <> 'Opening'  
   
 update #GetPendingLeaves set Credit = 2 where TypeId = 5  and Descript <> 'Opening'  
End  
Declare @t_AvailedDate date  
Declare @t_Availed decimal(5,1)  
Declare @crRowId int,@crPending decimal(5,1),@crDebit decimal(5,1)  
Declare curCompOffDr Cursor for select AvailedDate,Availed from #CompOffAvailed  
Open curCompOffDr  
while 1=1  
 Begin  
 Fetch next from curCompOffDr into @t_AvailedDate,@t_Availed  
 if @@FETCH_STATUS = -1 break  
 Declare curCompOffCr cursor for select RowId,isnull(Debit,0),isnull(Credit,0)-isnull(Debit,0) as Pending from #CompOffCredit where (isnull(Credit,0) - isnull(Debit,0)) > 0 and @t_AvailedDate <= CrValidateDate  
 open curCompOffCr  
 while 1=1  
Begin  
Fetch next from curCompOffCr into @crRowId,@crDebit,@crPending   
if @@FETCH_STATUS = -1 break  
Update #CompOffCredit Set Debit = isnull(Debit,0) + case when @t_Availed <= @crPending then  @t_Availed else @crPending end Where RowId = @crRowId  
Set @t_Availed = @t_Availed - @crPending  
if @t_Availed <= 0 Break  
End  
 close curCompOffCr  
 DeAllocate curCompOffCr  
 End  
Close curCompOffDr  
DeAllocate curCompOffDr  
  
--/** Checking comp-off **/  
--Select * from #CompOffAvailed  
--Select *,@SystemDate from #CompOffCredit  
  
Select @CompOffPending = isnull(SUM(isnull(Credit,0)-isnull(Debit,0)),0.0) from #CompOffCredit Where @SystemDate <= CrValidateDate --and isnull(credit,0) <> isnull(debit,0)  
Begin /** Update Debit **/  
update #GetPendingLeaves set Debit = AL.LEAVE_COUNT  
 FROM #GetPendingLeaves AS PL  
 INNER JOIN  
 (  
 SELECT TYPEID,SUM(CASE WHEN LEAVE_MODE = 'H' THEN 0.5 ELSE 1 END) LEAVE_COUNT,DATEPART(MONTH,LEAVE_DATE) AS LEAVE_MONTH,UserId  
 FROM #GetAvailedLeaves GROUP BY DATEPART(MONTH,LEAVE_DATE),TYPEID,UserId  
 ) AL ON AL.TYPEID = PL.TypeId AND AL.LEAVE_MONTH = DATEPART(MONTH,PL.TranDate) and al.UserId = pl.UserId  
End  
Begin /** Update Closing **/   
 Declare @RWIDLimit int = (Select MAX(RwId) from #GetPendingLeaves)  
 Declare @tRWID int = 1  
 Declare @preTypeId int = 0  
 Declare @Cr decimal(15,2) = 0  
 Declare @Dr decimal(15,2) = 0  
 Declare @Clo decimal(15,2) = 0  
 Declare @TypeId int = 0  
 While @tRWID <= @RWIDLimit  
Begin  
Select @TypeId = TypeId,@Cr = Credit,@Dr = Debit  from #GetPendingLeaves where RwId = @tRWID  
if @TypeId <> @preTypeId  
 Begin  
 Select @preTypeId = @TypeId,@Clo = 0  
 End  
if @TypeId = 2 /* SL */  
 Set @Clo = case when (@Clo + @Cr) > 24 then 24 else (@Clo + @Cr) end - @Dr  
else if @TypeId = 5  /* PER */  
Set @Clo = @Cr - @Dr  
else if @TypeId = 3 /* EL */  
 Begin  
 if @EL_HasLimit = 'Y'Set @Clo = case when @Clo = 24 then 0 else @Clo end  
 Set @Clo = (@Clo + @Cr) - @Dr  
 End  
else  
 Set @Clo = (@Clo + @Cr) - @Dr  
Update #GetPendingLeaves Set Closing = @Clo Where RwId = @tRWID   
Set @tRWID += 1  
End  
End  
  
if @RptType = 'PendingLeavesDetailed'  
 Select Descript as  MMonth,Credit,Debit,Closing,TypeId,RwId from #GetPendingLeaves where TypeId <> 4 order by RwId  
if @RptType = 'PendingLeavesWithLastAvailed'  
 Begin  
 Select UserId  
 ,PL.TypeId as TYPEID,tp.SHORT_TEXT,Debit as Availed,case when pl.TypeId = 4 then @CompOffPending else Closing end as Leaves    
 from #GetPendingLeaves as PL  
 inner join ARC_REC_LEAVE_TYPES as TP on TP.TYPEID = PL.TypeId and TP.TYPEID in (1,2,3,4,8,13,18)  
 inner join   
 (  
 Select TypeId,MAX(RwId)RwId from #GetPendingLeaves Group by TypeId  
 ) as Closing on Closing.TypeId = PL.TypeId and Closing.RwId = pl.RwId  
 End   
if @RptType = 'PendingLeaves'  
 Begin  
 Select * from (  
 Select UserId,PL.TypeId as TYPEID,tp.TYPE_TEXT,Closing as LEAVES from #GetPendingLeaves as PL  
 inner join ARC_REC_LEAVE_TYPES as TP on TP.TYPEID = PL.TypeId  
 inner join   
 (  
 Select TypeId,MAX(RwId)RwId from #GetPendingLeaves where TypeId <> 4 Group by TypeId  
 ) as Closing on Closing.TypeId = PL.TypeId and Closing.RwId = pl.RwId  
 )x  
 Union all  
 Select @UserId,4 as TypeId,'Comp Off' as Type_text,@CompOffPending   
 Order by  TypeId  
 End  
 
 --select * from #GetPendingLeaves  where TypeId = 3
if OBJECT_ID('tempdb..#CompOffCredit') IS NOT NULL DROP TABLE #CompOffCredit  
if OBJECT_ID('tempdb..#CompOffAvailed') IS NOT NULL DROP TABLE #CompOffAvailed  
if OBJECT_ID('tempdb..#GetPendingLeaves') IS NOT NULL DROP TABLE #GetPendingLeaves  
if OBJECT_ID('tempdb..#GetAvailedLeaves') IS NOT NULL DROP TABLE #GetAvailedLeaves  
End  
  
  
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_PendingLeaves] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_PendingLeaves] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_PendingLeaves] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_PendingLeaves] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_PendingLeaves] TO [DB_DMLSupport]
    AS [dbo];

