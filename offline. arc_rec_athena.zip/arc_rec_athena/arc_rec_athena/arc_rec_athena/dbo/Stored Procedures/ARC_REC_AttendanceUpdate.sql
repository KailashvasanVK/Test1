﻿CREATE Proc ARC_REC_AttendanceUpdate
(
 @AID INT       
,@REASON_ID INT           
,@VERIFIED_OPTION varCHAR(2)        
,@COMMENTS VARCHAR(MAX) = null
,@CREATED_BY INT
,@strLoggedOn varchar(25) = ''
,@strLoggedOut varchar(25)= ''
,@IsDeclaredOff  int = 0
,@OTEligible int = 0
,@CompOffEligible int = 0
)
As
Begin
declare @LoggedOn datetime 
set @LoggedOn  = case when  ISNULL(@strLoggedOn,'') = '' THEN null else  CONVERT(Datetime, @strLoggedOn, 120) end 
declare @LoggedOut datetime 
set @LoggedOut  = case when  ISNULL(@strLoggedOut,'') = '' THEN null else  CONVERT(Datetime, @strLoggedOut, 120) end 

Declare @UserId int
Declare @AttDate date
Select @UserId = UserId,@AttDate = [Date] from ARC_REC_Attendance Where Aid = @AID
if(@REASON_ID >0)
begin
INSERT INTO ARC_ME_DISCRIPENCY_TRAN(AID,DIS_TYPE, VERIFIED_PRESENT,VERIFIED_BY,VERIFIED_COMMENTS,CREATED_DT,ATT_DATE,USERID,OTEligible)
SELECT @Aid,@REASON_ID,@VERIFIED_OPTION,@CREATED_BY,@COMMENTS,GETDATE(),@AttDate,@USERID,@OTEligible
end
UPDATE ARC_REC_Attendance set            
Verified_Present = @VERIFIED_OPTION,
Verified_Comments = @COMMENTS,        
Verified_By = @CREATED_BY,
P_days = Case when @VERIFIED_OPTION = 'F' then 1 when @VERIFIED_OPTION = 'H' then 0.5 else 0 end,
OTEligible = @OTEligible
where Aid = @AID

if (Select COUNT(*) from ARC_REC_ATTENDANCE_ACCESS Where ATT_TYPE = 'S' and USERID = @UserId) > 0
	Begin /*Is Self Attendance User */
	INSERT INTO ARC_REC_SELF_ATTENDANCE_LOG(USERID,ATTENDANCE_DATE,ATT_TYPE,LOGIN_TIME,LOGOUT_TIME,WORKED_HRS,CREATED_BY,CREATED_DT)                
	SELECT USERID,ATTENDANCE_DATE,ATT_TYPE,LOGIN_TIME,LOGOUT_TIME,WORKED_HRS,CREATED_BY,CREATED_DT 
	FROM ARC_REC_SELF_ATTENDANCE WHERE USERID = @USERID AND ATTENDANCE_DATE = @AttDate
	DELETE FROM ARC_REC_SELF_ATTENDANCE WHERE USERID = @USERID AND ATTENDANCE_DATE = @AttDate
	INSERT INTO ARC_REC_SELF_ATTENDANCE(USERID,ATTENDANCE_DATE,ATT_TYPE,LOGIN_TIME,LOGOUT_TIME,WORKED_HRS,CREATED_BY)                    
	SELECT @USERID,@AttDate,@VERIFIED_OPTION,@LoggedOn,@LoggedOut,dbo.ShiftDurationInMinutes(@LoggedOn,@LoggedOut,0),@CREATED_BY      
	End
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_AttendanceUpdate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AttendanceUpdate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AttendanceUpdate] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_AttendanceUpdate] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AttendanceUpdate] TO [DB_DMLSupport]
    AS [dbo];

