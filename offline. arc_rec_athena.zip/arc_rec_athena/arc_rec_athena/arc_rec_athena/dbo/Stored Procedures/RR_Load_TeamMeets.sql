﻿CREATE Proc [dbo].[RR_Load_TeamMeets]  
@userid int =535  
/*  
Created By : udhayaganesh P  
Purpose  : To load the Team Members  
  
Exec RR_Load_TeamMeets   
  
select userid,NT_USERNAME,client_id,FUNCTIONALITY_ID,DESIGNATION_ID from ARC_REC_USER_INFO where DESIGNATION_ID in (11,14)  
  
select * from Hr_designation where status=1   
  
select userid,NT_USERNAME,client_id,FUNCTIONALITY_ID,DESIGNATION_ID from ARC_REC_USER_INFO where nt_username like '%arvind%'  
*/  
As  
Begin  
  
Declare @FUNCTIONALITY_ID int,@clientid int  
select @clientid=CLIENT_ID,@FUNCTIONALITY_ID=FUNCTIONALITY_ID from ARC_REC_USER_INFO where USERID=@userid  
  
if @clientid=16 and @FUNCTIONALITY_ID=11  
begin  
print 'MD'  
select USERID,NT_USERNAME  Associate from ARC_REC_USER_INFO UI  
inner Join ARC_FIN_CLIENT_INFO CI on CI.CLIENT_ID=Ui.CLIENT_ID   
where UI.ACTIVE=1 and AHS_PRL='Y' and USERID  <> @userid and NT_USERNAME<>''  
order by NT_USERNAME   
end  
else if  @clientid=16 and @FUNCTIONALITY_ID<>11  
begin  
select USERID,NT_USERNAME Associate from ARC_REC_USER_INFO UI  
inner Join ARC_FIN_CLIENT_INFO CI on CI.CLIENT_ID=Ui.CLIENT_ID   
where UI.ACTIVE=1 and AHS_PRL='Y' and USERID  <> @userid and NT_USERNAME<>''and FUNCTIONALITY_ID= @FUNCTIONALITY_ID   
order by NT_USERNAME  
end  
else  
begin  
select USERID,NT_USERNAME Associate from ARC_REC_USER_INFO  UI  
inner Join ARC_FIN_CLIENT_INFO CI on CI.CLIENT_ID=Ui.CLIENT_ID   
where UI.ACTIVE=1 and AHS_PRL='y' and USERID  <> @userid and ui.CLIENT_ID =@clientid  
and FUNCTIONALITY_ID= @FUNCTIONALITY_ID   
order by NT_USERNAME  
end  
End  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Load_TeamMeets] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Load_TeamMeets] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Load_TeamMeets] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Load_TeamMeets] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Load_TeamMeets] TO [DB_DMLSupport]
    AS [dbo];

