﻿
--ARC_REC_IndexAssociates @FunctionalityId = 0,@SearchStr = '',@SearchPattern = '',@Action = 'YetToJoin'
--ARC_REC_IndexAssociates @Action = 'InductionPending',@FunctionalityId = 0
CREATE procedure ARC_REC_IndexAssociates
  @Action varchar(100),
  @FunctionalityId int = null,
  @SearchStr varchar(100) = '', 
  @SearchPattern varchar(4) = '=' /** = or % **/ 
AS   
Begin
Declare @tblName varchar(100)
Set @tblName = '#InductionView' + @Action
Declare @Qry varchar(max)
Set @Qry = '
if object_id(''tempdb..'+@tblName+''') is not null drop table '+@tblName+'
if '''+@Action+''' /* @Action **/ = ''TodaysJoinees''
	Begin
	Select 
	''<input type="checkbox"  class="CheckAll" id="''+convert(varchar,ui.REC_ID)+''">'' as [CheckAll],
	ui.REC_ID as [RecId],ui.FIRSTNAME [First Name],ui.LASTNAME [Last Name],f.FunctionName as [Functionality],cl.CLIENT_NAME as [Client],   
	de.Designation,Convert(varchar,ui.DOJ,101) as [DOJ]
	into #InductionViewTodaysJoinees
	from ARC_REC_USER_INFO ui
	inner join HR_Functionality f on ui.FUNCTIONALITY_ID = f.FunctionalityId ' + Case when ISNULL(@FunctionalityId,0) <> 0 then ' and f.FunctionalityId = ' + CONVERT(varchar,@FunctionalityId) else '' end + '  
	inner join HR_Designation de on de.DesigId = ui.DESIGNATION_ID   
	inner join ARC_FIN_CLIENT_INFO cl on ui.CLIENT_ID = cl.CLIENT_ID
	Where ui.DOJ = convert(date,getdate()) and ui.ACTIVE = 0 and ui.AHS_PRL = ''Y''
	and Not exists (Select 1 from ARC_REC_InductionMaster ind where ind.UserId = ui.USERID)
	End
if '''+@Action+''' /* @Action **/ = ''YetToJoin''
	Begin	
	Select 
	''<input type="checkbox"  class="CheckAll" id="''+convert(varchar,ui.REC_ID)+''">'' as [CheckAll],
	ui.REC_ID as [RecId],ui.FIRSTNAME [First Name],ui.LASTNAME [Last Name],f.FunctionName as [Functionality],cl.CLIENT_NAME as [Client],   
	de.Designation,Convert(varchar,ui.DOJ,101) as [DOJ]
	into #InductionViewYetToJoin
	from ARC_REC_USER_INFO ui
	inner join HR_Functionality f on ui.FUNCTIONALITY_ID = f.FunctionalityId ' + Case when ISNULL(@FunctionalityId,0) <> 0 then ' and f.FunctionalityId = ' + CONVERT(varchar,@FunctionalityId) else '' end + '  
	inner join HR_Designation de on de.DesigId = ui.DESIGNATION_ID   
	inner join ARC_FIN_CLIENT_INFO cl on ui.CLIENT_ID = cl.CLIENT_ID
	Where ui.DOJ < Convert(date,getdate()) and ui.ACTIVE = 0 and ui.AHS_PRL = ''Y''
	and Not exists (Select 1 from ARC_REC_InductionMaster ind where ind.UserId = ui.USERID) 
	and Not exists (Select 1 from ARC_REC_HeldNotJoined held where held.UserId = ui.USERID and held.ReleasedBy = 0)
	End
if '''+@Action+''' /* @Action **/ = ''InductionPending''
	Begin 	
	Select
	''<input type="checkbox"  class="CheckAll" id="''+convert(varchar,ui.REC_ID)+''">'' as [CheckAll],
	ui.REC_ID as [RecId],ui.FIRSTNAME [First Name],ui.LASTNAME [Last Name],f.FunctionName as [Functionality],cl.CLIENT_NAME as [Client],   
	de.Designation,Convert(varchar,ui.DOJ,101) as [DOJ]
	into #InductionViewInductionPending
	from ARC_REC_USER_INFO ui
	inner join HR_Functionality f on ui.FUNCTIONALITY_ID = f.FunctionalityId ' + Case when ISNULL(@FunctionalityId,0) <> 0 then ' and f.FunctionalityId = ' + CONVERT(varchar,@FunctionalityId) else '' end + '    
	inner join HR_Designation de on de.DesigId = ui.DESIGNATION_ID   
	inner join ARC_FIN_CLIENT_INFO cl on ui.CLIENT_ID = cl.CLIENT_ID
	Where ui.ACTIVE = 1 and ui.AHS_PRL = ''Y''
	and exists (Select 1 from ARC_REC_InductionMaster ind where ind.UserId = ui.USERID and ind.InductionTaken = 0)
	End
if '''+@Action+''' /* @Action **/ = ''Held''
	Begin	
	Select 
	''<input type="checkbox"  class="CheckAll" id="''+convert(varchar,ui.REC_ID)+''">'' as [CheckAll],
	ui.REC_ID as [RecId],ui.FIRSTNAME [First Name],ui.LASTNAME [Last Name],f.FunctionName as [Functionality],cl.CLIENT_NAME as [Client],   
	de.Designation,Convert(varchar,ui.DOJ,101) as [DOJ],heldBy.NT_USERNAME [Held By],held.Remarks [Held Remark]
	into #InductionViewHeld
	from ARC_REC_USER_INFO ui
	inner join HR_Functionality f on ui.FUNCTIONALITY_ID = f.FunctionalityId ' + Case when ISNULL(@FunctionalityId,0) <> 0 then ' and f.FunctionalityId = ' + CONVERT(varchar,@FunctionalityId) else '' end + '  
	inner join HR_Designation de on de.DesigId = ui.DESIGNATION_ID   
	inner join ARC_FIN_CLIENT_INFO cl on ui.CLIENT_ID = cl.CLIENT_ID
	inner join ARC_REC_HeldNotJoined as Held on Held.UserId = ui.USERID and Held.ReleasedBy = 0
	inner join ARC_REC_USER_INFO as heldBy on heldBy.USERID = held.CreatedBy
	Where ui.ACTIVE = 0 and ui.AHS_PRL = ''Y''
	and not exists (Select 1 from ARC_REC_InductionMaster ind where ind.UserId = ui.USERID)
	End
Exec FilterTable  
@DbName = ''tempdb''
,@TblName = '''+@tblName+'''
,@SearchStr = '''+@SearchStr+'''
,@SearchPattern = '''+@SearchPattern+'''
,@OrderStr = '' order by [RecId] ''
if object_id(''tempdb..'+@tblName+''') is not null drop table '+@tblName+'
'
print @qry
Exec (@Qry)
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_IndexAssociates] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_IndexAssociates] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_IndexAssociates] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_IndexAssociates] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_IndexAssociates] TO [DB_DMLSupport]
    AS [dbo];

