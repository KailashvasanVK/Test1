﻿	CREATE proc ARC_ME_Attendancelock
	(
		@AttDate date,
		@Createdby int
	)
	As
	begin	
			/*  ARC_ME_Attendancelock @AttDate='27-Dec-2013',@Createdby=19
			 */
			declare @Month int
			declare @year int
			set @Month = DATEPART(MONTH,@AttDate)
			set @year = DATEPART(year,@AttDate)

			if exists (select 'X' from ARC_ME_PAYROLL where datepart(year,PAY_ROLL_DATE) = @year and DATEPART(month,PAY_ROLL_DATE) = @Month)
				begin
					RAISERROR('The attendance has been locked for this month already ',16,1)      
				end
		    else
				begin
					insert into ARC_ME_PAYROLL (PAY_ROLL_DATE,CREATED_BY,CREATED_DT)
					select @AttDate,@Createdby,GETDATE()
			END
	end


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_Attendancelock] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_Attendancelock] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_Attendancelock] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_Attendancelock] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_Attendancelock] TO [DB_DMLSupport]
    AS [dbo];

