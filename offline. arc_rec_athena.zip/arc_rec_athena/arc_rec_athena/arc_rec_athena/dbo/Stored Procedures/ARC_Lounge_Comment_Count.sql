﻿CREATE procedure ARC_Lounge_Comment_Count(@MsgId int=0)    
 as    
 begin    
 select COUNT(mc.id)'CommentCount',mc.MsgId,mc.status  from ARC_Forum_Lounge_Message_Comments mc 
  Where  mc.MsgId=@MsgId and mc.Status=1 
 group by mc.MsgId,mc.status    
     
 end 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Comment_Count] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Comment_Count] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Comment_Count] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Comment_Count] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Comment_Count] TO [DB_DMLSupport]
    AS [dbo];

