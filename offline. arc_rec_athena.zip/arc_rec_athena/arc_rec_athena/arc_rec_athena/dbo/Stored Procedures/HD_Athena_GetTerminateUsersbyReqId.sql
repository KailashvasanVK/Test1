﻿CREATE PROCEDURE [dbo].[HD_Athena_GetTerminateUsersbyReqId]    
@ReqId int    
AS    
BEGIN    
Select au.AthenaUserId,at.ReqId as ReqId,ir.TICKET_ID as TicketId,au.UserId,    
ui.FIRSTNAME as FirstName ,ui.LASTNAME as LastName,d.Department,r.Role,    
case when au.AthenaUserName IS null then 'Not updated' else au.AthenaUserName end as AthenaUserName    
from HD_Athena_Terminate at    
inner join HD_AthenaUsers au on au.UserId = at.UserId     
inner join HD_ISSUE_REQUEST ir on at.ReqId = ir.ISS_REQID    
inner join ARC_REC_USER_INFO ui on au.UserId = ui.USERID and ui.USERID = at.UserId    
inner join HD_Athena_Department d on au.DeptId = d.DeptId    
inner join HD_athena_Role r on au.RoleId = r.RoleId    
where at.ReqId = @ReqId    
END

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_GetTerminateUsersbyReqId] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetTerminateUsersbyReqId] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetTerminateUsersbyReqId] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_GetTerminateUsersbyReqId] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetTerminateUsersbyReqId] TO [DB_DMLSupport]
    AS [dbo];

