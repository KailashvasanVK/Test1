﻿CREATE Proc RR_Purchase_LK    
as    
select Associate,NT_username+'@accesshealthcare.co' EmailId,EMPcode Empcode,Reporting_to+'@accesshealthcare.co' Reporting_To    
,v.client_name ClientName,Functionname Funtionlity,Point [SDPS(currentSdps)], 'Active'  EmpStatus,pd.Productname,Sp.RequestedOn,
pd.PCost ProductCost from RR_scoreboard_purchase SP    
inner join ARC_REC_USER_INFO_VY V on v.userid=sp.userid    
inner join RR_SCOREBOARD_VY SV on SV.userid=v.userid    
inner join RR_product_details PD on PD.pid=sp.pid  
union    
select Associate,NT_username+'@accesshealthcare.co' EmailId,EMPcode,Reporting_to+'@accesshealthcare.co' Reporting_To    
,v.client_name,Functionname,Point, 'Resigned'  EmpStatus,pd.Productname,Sp.RequestedOn,
pd.PCost ProductCost  from RR_scoreboard_purchase SP    
inner join ARC_REC_USER_INFO_VYR V on v.userid=sp.userid    
inner join [RR_SCOREBOARD_VY_Temp] SV on SV.userid=v.userid    
inner join RR_product_details PD on PD.pid=sp.pid  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Purchase_LK] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Purchase_LK] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Purchase_LK] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Purchase_LK] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Purchase_LK] TO [DB_DMLSupport]
    AS [dbo];

