﻿CREATE PROCEDURE ARC_REC_NtViewAction
AS
BEGIN
	SELECT DISTINCT UI.USERID ,UI.FIRSTNAME + ' ' + UI.LASTNAME + ' - (' + ISNULL(UI.EMPCODE, ' ') +' ) ' AS NAME
	FROM ARC_REC_NTLogin NTL INNER JOIN  ARC_REC_USER_INFO AS UI ON UI.USERID  = NTL.CREATED_BY
	WHERE AHS_PRL = 'Y' AND     ACTIVE = 1 ORDER BY NAME;
END

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_NtViewAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_NtViewAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_NtViewAction] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_NtViewAction] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_NtViewAction] TO [DB_DMLSupport]
    AS [dbo];

