﻿Create Procedure RR_ReportingTo_get  
As  
Begin  
select Userid,Associate,NT_UserName  
 from ARC_REC_USER_INFO_VY U  
where NT_UserName in( select REPORTING_TO from  ARC_REC_USER_INFO_VY ) 
union
select Userid,Associate,NT_UserName  
 from ARC_REC_USER_INFO_VY U where Userid =807 
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_ReportingTo_get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_ReportingTo_get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_ReportingTo_get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_ReportingTo_get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_ReportingTo_get] TO [DB_DMLSupport]
    AS [dbo];

