﻿CREATE Proc Attendance_LateinOut_update              
as     
begin             
select a.Userid ,a.date,a.LogOn,LogOut,LateIn,LateOut             
,convert(varchar(20),a.Date,120 )+' '+convert(varchar(10),dateadd(HH,0,convert(varchar(5),b.SHIFT_FROM,108)),108) INTime    
            
,OutTime=(case when SHIFT_ID in(1,4) then             
 convert(varchar(20),a.date,120 )+' '+convert(varchar(10),dateadd(HH,0,convert(varchar(5),b.SHIFT_TO,108)),108)            
 else            
  convert(varchar(20),DATEADD(day,1,a.Date),120 )+' '+convert(varchar(10),dateadd(HH,0,convert(varchar(5),b.SHIFT_TO,108)),108)            
            
             
  end)            
  ,            
LateInmin=(datediff(MINUTE,            
convert(varchar(20),a.Date,120 )+' '+convert(varchar(10),dateadd(HH,0,convert(varchar(5),b.SHIFT_FROM,108)),108),            
LogOn)),            
            
            
LateOutmin=(            
case when SHIFT_ID in(1,4) then             
datediff(MINUTE,logout,            
convert(varchar(20),a.date,120 )+' '+convert(varchar(10),dateadd(HH,0,convert(varchar(5),b.SHIFT_to,108)),108))            
else             
datediff(MINUTE,logout,            
convert(varchar(20),DATEADD(day,1,a.Date),120 )+' '+convert(varchar(10),dateadd(HH,0,convert(varchar(5),b.SHIFT_to,108)),108))end            
)             
into #udhaya  from ARC_REC_Attendance a               
inner join ARC_REC_SHIFT_INFO  b on a.Shiftid =b.SHIFT_ID  where a.Date=convert(date,GETDATE()-1)              
and logon is not null              
order by Shiftid               
              
select *,              
              
lateinn=(cast(LateInmin as int)/60)+cast(('0.'+ RIGHT('0'+convert(varchar(10),cast(LateInmin%60 as int)),2)) as numeric(18,2)),                        
lateouto=(cast(LateOutmin as int)/60)+cast(('0.'+ RIGHT('0'+convert(varchar(10),cast(LateOutmin%60 as int)),2 )) as numeric(18,2))              
into #udhaya1 from #udhaya where LateOutmin >=0 and LateInmin>=0              
                
--   select a.Userid,a.lateinn,a.lateouto,b.LateIn,b.LateOut   from #udhaya1 a,ARC_REC_Attendance b              
-- where a.userid=b.userid and a.date=b.date              
                
                
 update b set b.LateIn =lateinn,b.lateout=lateouto from #udhaya1 a,ARC_REC_Attendance b              
 where a.userid=b.userid and a.date=b.date   
   
   
update arc_rec_attendance set p_days=1 where latein<=0.15 and lateout<=0.15  and Date=convert(date,GETDATE()-1) 
update arc_rec_attendance  set p_days=1 where datepart(dw,date) in(1,7)  and Date=convert(date,GETDATE()-1)   
update arc_rec_attendance  set p_days=1 where  date in( select HOLIDAY_DATE from ARC_REC_LEAVE_HOLIDAYLIST)   and Date=convert(date,GETDATE()-1)  
update arc_rec_attendance set p_days=0.5 where (latein>0.15 or lateout>0.15)  and Date=convert(date,GETDATE()-1) 
update arc_rec_attendance set p_days=0.5 where  Verified_Present ='H'  and Date>=convert(date,GETDATE()-7) 
update arc_rec_attendance set p_days=1 where  Verified_Present ='F'  and Date>=convert(date,GETDATE()-7) 
update arc_rec_attendance set p_days=0 where p_days is null and Verified_Present is null and Date>=convert(date,GETDATE()-7) 
update arc_rec_attendance set p_days=0 where  Verified_Present ='NP'  and Date>=convert(date,GETDATE()-7) 

update b set p_days=(case when a.att_type='h' then 0.5 when att_type='F' then 1 end) 
from  ARC_REC_SELF_ATTENDANCE a
inner join arc_rec_attendance b on a.userid=b.userid 
where a.ATTENDANCE_DATE =b.date    and b.Date>=convert(date,GETDATE()-7)        
                
  drop table #udhaya              
  drop table #udhaya1    
 end
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Attendance_LateinOut_update] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Attendance_LateinOut_update] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Attendance_LateinOut_update] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Attendance_LateinOut_update] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Attendance_LateinOut_update] TO [DB_DMLSupport]
    AS [dbo];

