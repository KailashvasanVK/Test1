﻿Create procedure AHC_DeleteSession  
(  
@SessionId varchar(100)  
)  
/*  
AHC_DeleteSession @SessionId='4kft2crvvivonkmp5i4v541w'  
*/  
As  
Begin  
update AHC_JobRefer set sessionvalue=null where sessionvalue =@SessionId  
End  
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AHC_DeleteSession] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHC_DeleteSession] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHC_DeleteSession] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AHC_DeleteSession] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHC_DeleteSession] TO [DB_DMLSupport]
    AS [dbo];

