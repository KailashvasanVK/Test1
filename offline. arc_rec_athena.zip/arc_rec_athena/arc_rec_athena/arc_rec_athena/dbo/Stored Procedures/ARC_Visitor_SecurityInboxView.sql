﻿CREATE PROCEDURE ARC_Visitor_SecurityInboxView  
     --@SearchStr varchar(max)                     
     --@PassNo varchar(5)='',              
     @SearchStr varchar(100) = '',            
     @SearchPattern varchar(4) = '=' /** = or % **/                    
AS                  
BEGIN                
   if OBJECT_ID('tempdb..#InboxResults') is not null drop table #InboxResults              
               
 create table #InboxResults([Params~Hide] varchar(max),[VISITOR_ID~Hide] int,CONTACT_PERSON varchar(max),VISITOR_NAME varchar(500),                    
 REASON varchar(200),VISIT_DATE varchar(20),IN_TIME varchar(10),OUT_TIME varchar(10),VISITOR_CONTACTNO varchar(20)                    
 ,[ACTION] varchar(max),VISITOR_PASSNO varchar(10))                     
                     
  declare @sql as varchar(max)                    
               
   set @sql = '                    
  insert into #InboxResults([Params~Hide],[VISITOR_ID~Hide],CONTACT_PERSON,VISITOR_NAME,REASON,VISIT_DATE,IN_TIME,OUT_TIME,VISITOR_CONTACTNO,[ACTION],VISITOR_PASSNO                    
  ) 
  select x.[Params~Hide],x.VISITOR_ID,x.CONTACT_PERSON,x.VISITOR_NAME,x.Reason,x.VISIT_DATE,x.IN_TIME,x.OUT_TIME,x.VISITOR_CONTACTNO,
 case when ISNULL(x.ENTERED_BYSECURITY,''N'') = ''N'' then                
  ''<button id="btnPrint" style="width:40px;height:25px;margin:5px"  class="print ui-button ui-widget ui-state-default ui-corner-all ui-button-icon-only" onclick="return UpdatePrintStatus(''+convert(varchar,x.VISITOR_ID)+'',''''''+convert(varchar(max),x.[Params~Hide])+'''''')">Print</button>''+                    
  ''<button id="btnOuttime" style="width:70px;height:25px;margin:5px"  class="outtime ui-button ui-widget ui-state-default ui-corner-all ui-button-icon-only" onclick="return UpdateOutTimeInstant(''+convert(varchar,x.VISITOR_ID)+'')">Outtime</button>''    
            
  else ''<button id="btnOuttime" style="width:70px;height:25px;margin:5px"  class="outtime ui-button ui-widget ui-state-default ui-corner-all ui-button-icon-only" onclick="return UpdateOutTimeInstant(''+convert(varchar,x.VISITOR_ID)+'')">Outtime</button>'' end as PrintButton ,x.VISITOR_PASSNO
 from (
SELECT 
  replace(replace(cast(VISITOR_ID as varchar) + '';'' + VISITOR_NAME + '';'' + UI.FIRSTNAME+'' ''+UI.LASTNAME + '';'' + fu.JobTitle + '';'' + rtrim(ltrim(V.REASON)) ,'';'',''#split#''),'' '',''#space#'')  as [Params~Hide],                  
  VISITOR_ID                   
  ,UI.FIRSTNAME+'' ''+UI.LASTNAME+''<br>(''+ Fu.JobTitle+'' - ''+P.MOBILE_NO+'')'' AS CONTACT_PERSON                     
  ,V.VISITOR_NAME                   
  ,rtrim(ltrim(V.REASON))Reason                        
  ,CONVERT(VARCHAR,V.VISIT_DATE,106) AS VISIT_DATE          
  ,case when ISNULL(V.ACT_INTIME,'''')= '''' then CONVERT(varchar(15),V.IN_TIME,100) else CONVERT(varchar(15),V.ACT_INTIME,100) end AS IN_TIME          
  ,CONVERT(varchar(15),V.OUT_TIME,100) AS OUT_TIME                   
  ,V.VISITOR_CONTACTNO                
  ,V.ENTERED_BYSECURITY
  ,V.VISITOR_PASSNO   
         
  FROM ARC_ME_VISITOR V               
  INNER JOIN ARC_REC_USER_INFO UI ON  UI.USERID = case when ISNULL(V.ENTERED_BYSECURITY,''N'')= ''N'' then V.CREATED_BY ELSE V.CONTACT_PERSONID END                
  LEFT JOIN ARC_REC_CANDIATE_PROFILE P ON  UI.REC_ID = P.REC_ID          
  inner join HR_Functionality as fu on fu.FunctionalityId = ui.FUNCTIONALITY_ID          
  where V.VISIT_DATE = CONVERT(DATE,GETDATE()) and V.ACTIVE  = 1               
   )x order by x.VISITOR_ID  desc
  '                    
            
 -- if(@PassNo <> '')                    
 --set @sql += ' and V.VISITOR_PASSNO like %'+@PassNo+'% order by v.VISITOR_ID  desc '                    
 -- else                  
 set @sql +=''                    
                     
   --select @sql                  
            
  print (@sql)                    
  exec (@sql)                    
            
  Exec FilterTable            
  @DbName = 'tempdb'            
  ,@TblName = '#InboxResults'        
  ,@SearchStr = @SearchStr        
  ,@SearchPattern = @SearchPattern        
  ,@OrderStr = ''          
if OBJECT_ID('tempdb..#InboxResults') is not null drop table #InboxResults                             
   
  --select REPLACE ( Params , '-' , '' ) as Params,VISITOR_ID,CONTACT_PERSON,VISITOR_NAME,REPLACE ( REASON , '-' , '' ) as REASON,VISIT_DATE,IN_TIME,OUT_TIME,VISITOR_CONTACTNO,PrintButton,VISITOR_PASSNO from #InboxResults                      
  --SELECT @RecCount = COUNT(*) FROM #TempIssueLog                 
  --if @displayLength=-1 set @displayLength = @RecCount             
            
END             
          


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Visitor_SecurityInboxView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Visitor_SecurityInboxView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Visitor_SecurityInboxView] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Visitor_SecurityInboxView] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Visitor_SecurityInboxView] TO [DB_DMLSupport]
    AS [dbo];

