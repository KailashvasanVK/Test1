﻿--ARC_REC_TraineeAttendanceUpdate @TRAINEE_IDS='1167,1186',@ATT_DATE='10-Oct-2013',@VERIFIED_PRESENT='H',@VERIFIED_By=16,@REMARKS='@VERIFIED_By'
CREATE procedure [dbo].[ARC_REC_TraineeAttendanceUpdate]      
       @TRAINEE_IDS varchar(max)      
       ,@ATT_DATE DATE      
       ,@VERIFIED_PRESENT char(2)      
       ,@VERIFIED_By int      
       ,@REMARKS varchar(500)      
             
As      
Begin      
if OBJECT_ID('tempdb..#traineeattendance') is not null drop table #traineeattendance                  
create table #traineeattendance(USERID Int,ATT_DATE date,VERIFIED_PRESENT CHAR(2),SHIFT_ID INT,EXISTING_AID INT)                
Insert into #traineeattendance(USERID,ATT_DATE,VERIFIED_PRESENT)              
Select items,@ATT_DATE,@VERIFIED_PRESENT from dbo.fnSplitString(@TRAINEE_IDS,',')       
    
update #traineeattendance set    
SHIFT_ID = (select top 1 SHIFT_ID from ARC_REC_SHIFT_TRAN where USERID = ta.USERID order by CREATED_DT desc )    
from #traineeattendance ta  

update #traineeattendance set
EXISTING_AID = att.Aid
from #traineeattendance ta
join ARC_REC_Attendance att on ta.USERID = att.Userid and ta.ATT_DATE = att.Date
  
    select * from #traineeattendance
    
insert into ARC_REC_TraineeAttendanceLog(Aid,Userid,NT_UserName,Date,Shiftid,LogOn,LogOut,    
TotalHrs,WorkHours,LockHrs,LateIn,LateOut,Designid,Functionalityid,CreatedBy,Createdon,Shift_from,Shift_to,    
Verified_Present,Verified_By,Verified_Comments,Client_id,ActLogin,ActLogout)    
    
select Aid,Userid,NT_UserName,Date,Shiftid,LogOn,LogOut,    
TotalHrs,WorkHours,LockHrs,LateIn,LateOut,Designid,Functionalityid,CreatedBy,Createdon,Shift_from,Shift_to,    
Verified_Present,Verified_By,Verified_Comments,Client_id,ActLogin,ActLogout     
from ARC_REC_Attendance where [date] = @ATT_DATE and Userid in (select USERID from #traineeattendance)    


   
 update ARC_REC_Attendance set   
 Verified_Present = @VERIFIED_PRESENT,  
 Verified_By = @VERIFIED_By,  
 Verified_Comments = @REMARKS  
 where [date] = @ATT_DATE and Userid in (select USERID from #traineeattendance where EXISTING_AID is not null)  
    
    
--delete from ARC_REC_Attendance where [date] = @ATT_DATE and Userid in (select USERID from #traineeattendance)    
      
 insert into ARC_REC_Attendance(Userid,NT_UserName,[Date],Shiftid,CreatedBy,Createdon,      
 Shift_from,Shift_to,Verified_Present,Verified_By,Verified_Comments,Designid,Functionalityid)      
 select ta.USERID,ui.NT_USERNAME,@ATT_DATE,ta.SHIFT_ID,@VERIFIED_By,GETDATE(),      
 si.SHIFT_FROM,si.SHIFT_TO,@VERIFIED_PRESENT,@VERIFIED_By,@REMARKS,ui.DESIGNATION_ID,ui.FUNCTIONALITY_ID      
  from #traineeattendance ta      
 left join ARC_REC_USER_INFO ui on ta.USERID = ui.USERID       
 left join ARC_REC_SHIFT_INFO si on ta.SHIFT_ID = si.SHIFT_ID 
 where ta.EXISTING_AID is null   
End   

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_TraineeAttendanceUpdate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_TraineeAttendanceUpdate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_TraineeAttendanceUpdate] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_TraineeAttendanceUpdate] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_TraineeAttendanceUpdate] TO [DB_DMLSupport]
    AS [dbo];

