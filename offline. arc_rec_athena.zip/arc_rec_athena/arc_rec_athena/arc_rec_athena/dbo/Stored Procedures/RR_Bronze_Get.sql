﻿CREATE PROCEDURE [dbo].RR_Bronze_Get                                                  
      @PageIndex INT = 1                                                  
      ,@PageSize INT = 10                                                  
      ,@PageCount INT OUTPUT                                                  
AS                                                  
/*                                                
                                                
declare @p3 int=1                                                
set @p3=2                                                
exec RR_Bronze_Get @PageIndex=1,@PageSize=30,@PageCount=@p3 output                                                
select @p3                                                
                                                
*/                                                
BEGIN                                                  
      SET NOCOUNT ON;                                                  
      SELECT ROW_NUMBER() OVER                                                  
            (                                                  
                  ORDER BY point desc                                                 
            )AS RowNumber                                                  
       ,UI.USERID                                                
      , CONVERT(VARCHAR, sv.Point)  As Points                                                
      ,'../arc_rec/images/candidate/'+PROFILE_IMAGE_NAME as REC_ID                                                
      ,FIRSTNAME +' '+ LASTNAME As Name                                                     
      ,NT_USERNAME,                                    
     ci.client_name FunctionName                                                  
    INTO #Results                                                  
       fROM ARC_REC_USER_INFO  UI                              
 inner join RR_SCOREBOARD_VY SV on SV.Userid=ui.USERID            
 inner join RR_LeagueLevel  LL on sv.Point>=ll.StartPoint and  sv.Point<ll.EndPpoint                 
      inner join ARC_FIN_CLIENT_INFO CI on CI.CLIENT_ID=ui.CLIENT_ID                                     
      where  LL.LLId=1 order by sv.Point desc                                      
                                             
                                                       
      DECLARE @RecordCount INT                                                  
      SELECT @RecordCount = COUNT(*) FROM #Results                                                  
                                                   
      SET @PageCount = CEILING(CAST(@RecordCount AS DECIMAL(10, 2)) / CAST(@PageSize AS DECIMAL(10, 2)))                                                  
      PRINT       @PageCount                                                  
                                                             
      SELECT top 10 REC_ID,RowNumber,USERID,Points= dbo.RR_Order_get(RowNumber)+' with ' + points + ' points',Name,FunctionName FROM #Results                                                  
      WHERE RowNumber BETWEEN(@PageIndex -1) * @PageSize + 1 AND(((@PageIndex -1) * @PageSize + 1) + @PageSize) - 1                                          
                                                      
      DROP TABLE #Results                                                  
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Bronze_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Bronze_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Bronze_Get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Bronze_Get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Bronze_Get] TO [DB_DMLSupport]
    AS [dbo];

