﻿CREATE Proc ARC_REC_CAPMAN_CLIENT_WISE_VIEW          
@Shiftid Int,          
@facility int           
AS     
/*

ARC_REC_CAPMAN_CLIENT_WISE_VIEW 1,1

*/     
Begin       
      
Declare @TemShift varchar(10)                   
            
if @ShiftId in(1,4)             
SET @TemShift='1,4'                       
ELSE             
SET @TemShift ='2,3,5'       
  
  
select Isnull(CLIENT_NAME,'Not Marked') CLIENT_NAME,isnull(lower(cc.ColorCode),'#ff8c00') ColorCode ,COUNT(*)  as Blocked    
into  #TempBlocked  
from ARC_REC_CAPMAN Cm  
Left Join ARC_FIN_CLIENT_INFO CI On CI.CLIENT_ID  =CM.ClientID   
Left join ARC_CLIENT_COLORCODE CC on CC.ClientId =CI.CLIENT_ID           
where facilityid=@facility  and status=1 and cm.ShiftId IN(select value from dbo.Split(@TemShift,','))   
Group By CI.CLIENT_NAME,CC.ColorCode   
  
select * from #TempBlocked where CLIENT_NAME not like '%Not Marked%'  
--select * from #TempBlocked where CLIENT_NAME like 'Not Marked'   
  
Drop table #TempBlocked  
  
        
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_CLIENT_WISE_VIEW] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_CLIENT_WISE_VIEW] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_CLIENT_WISE_VIEW] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_CLIENT_WISE_VIEW] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_CLIENT_WISE_VIEW] TO [DB_DMLSupport]
    AS [dbo];

