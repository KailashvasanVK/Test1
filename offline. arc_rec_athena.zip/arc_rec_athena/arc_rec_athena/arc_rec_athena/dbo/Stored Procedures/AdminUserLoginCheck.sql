﻿CREATE Procedure AdminUserLoginCheck
as
begin
	select PWD from  ARC_Login
end
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AdminUserLoginCheck] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AdminUserLoginCheck] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AdminUserLoginCheck] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AdminUserLoginCheck] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AdminUserLoginCheck] TO [DB_DMLSupport]
    AS [dbo];

