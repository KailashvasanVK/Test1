﻿--HD_Athena_ProcessedTickets @FromDate='03-May-2014',@ToDate='25-Jun-2014', @SearchStr='21250',@SearchPattern='%'
CREATE proc [dbo].[HD_Athena_ProcessedTickets]      
@FromDate date,      
@ToDate date      
,@SearchStr varchar(100) = '',                       
@SearchPattern varchar(4) = '=' /** = or % **/          
As      
Begin      
Declare @OrderStr varchar(100)       
select * into #Support_AthenaTicketView     
from (      
select     
[Type Of Request] = 'New Hire'     
,[ARC Ticket #] = ir.TICKET_ID     
,[ARC Ticket # Date]=convert(varchar,CONVERT(DATE,dbo.FormatTimeZone(ir.CREATED_DT,'EST')),101)    
,[AHS Manager that raises Ticket*] = crb.FIRSTNAME+' '+crb.LASTNAME     
,[AHS Manager who updated athenaNet Username] = upb.FIRSTNAME+' '+upb.LASTNAME     
,[Date of action taken on athenaNet name in athenaNet]  = convert(varchar,CONVERT(DATE,dbo.FormatTimeZone(au.AthenaUNUpdDt,'EST')),101)    
,[Agent First Name] = ui.FIRSTNAME     
,[Agent Last Name] = ui.LASTNAME     
,[Agent athenaNet Username] = au.AthenaUserName     
,[Department] = de.Department     
,[Role] = ro.Role     
,[Agent's Citrix Username (if applicable)**] =isnull(au.CitrixUserName,'-')     
,[athena Ticket # for Citrix Account Update***] = case when ISNULL(au.CitrixReqId,'0') <> '0' and LEFT(au.CitrixReqId,3) <> 'INC' then 'INC' + Convert(varchar,au.CitrixReqId) else '-' end   
,[Type of Ticket for Citrix Account Update] = 'New Request'     
,[Type of Citrix Transfer] = '-'     
,[Start Date at AHS on the athena account listed in the ARC system] = convert(varchar,CONVERT(DATE,dbo.FormatTimeZone(au.AthenaUNUpdDt,'EST')),101)     
,[Date of Department Transfer on the athena account (if applicable)] = '-'    
,[Termination Date of the day the agent departs from the athena account listed in ARC system] = '-'    
from HD_AthenaUsers au      
inner join HD_ISSUE_REQUEST ir on au.Issue_ReqId  = ir.ISS_REQID  and isnull(ir.ACTIVE,'Y') <> 'N'       
inner join ARC_REC_USER_INFO ui on au.UserId  = ui.USERID      
inner join ARC_REC_USER_INFO crb on au.CreatedBy  = crb.USERID      
inner join ARC_REC_USER_INFO upb on au.AthenaUNUpdatedBy  = upb.USERID      
inner join HD_Athena_Role ro on au.RoleId  = ro.RoleId      
inner join HD_Athena_Department de on au.DeptId  = de.DeptId      
where CONVERT(DATE,dbo.FormatTimeZone(au.CreatedDt,'EST')) BETWEEN @FromDate AND @ToDate     
and au.Status = 3    
union all      
Select     
[Type Of Request] = 'Transfer'     
,[ARC Ticket #] = ir.TICKET_ID     
,[ARC Ticket # Date]= convert(varchar,CONVERT(DATE,dbo.FormatTimeZone(ir.CREATED_DT,'EST')),101)    
,[AHS Manager that raises Ticket*] = crb.FIRSTNAME+' '+crb.LASTNAME     
,[AHS Manager who updated athenaNet Username] = upb.FIRSTNAME+' '+upb.LASTNAME     
,[Date of action taken on athenaNet name in athenaNet]  = convert(varchar,CONVERT(DATE,dbo.FormatTimeZone(au.UpdatedDt,'EST')),101)    
,[Agent First Name] = ui.FIRSTNAME     
,[Agent Last Name] = ui.LASTNAME     
,[Agent athenaNet Username] = aur.AthenaUserName     
,[Department] = (Select Department from HD_Athena_Department Where DeptId =  isnull((Select top 1 DeptId from HD_Athena_Transfer Where UserId = au.UserId and Status = 3 Order by TransferId desc),aur.DeptId))    
,[Role] = (Select Role from HD_Athena_Role Where RoleId =  isnull((Select top 1 RoleId from HD_Athena_Transfer Where UserId = au.UserId and Status = 3 Order by TransferId desc),aur.RoleId))    
,[Agent's Citrix Username (if applicable)**] =isnull(au.CitrixUserName,'-')     
,[athena Ticket # for Citrix Account Update***] = case when ISNULL(au.CitrixReqId,'0') <> '0' and LEFT(au.CitrixReqId,3) <> 'INC' then 'INC' + Convert(varchar,au.CitrixReqId) else '-' end   
,[Type of Ticket for Citrix Account Update] = case when au.AddCitrix = 'Y' then 'Transfer' when au.AddCitrix = 'N' then 'Termination' else '-' end    
,[Type of Citrix Transfer] = case when au.AddCitrix = 'Y' then 'Additional Access' when au.AddCitrix = 'N' then 'Remove Access' else '-' end    
,[Start Date at AHS on the athena account listed in the ARC system] = (Select top 1 convert(varchar,CONVERT(DATE,dbo.FormatTimeZone(CreatedDt,'EST')),101) from HD_AthenaUsers Where UserId = au.UserId Order by AthenaUserId)    
,[Date of Department Transfer on the athena account (if applicable)] = isnull(CONVERT(varchar,au.TransferDate,101),'-')    
,[Termination Date of the day the agent departs from the athena account listed in ARC system] = '-'     
from HD_Athena_Transfer au      
inner join HD_AthenaUsers aur on au.UserId = aur.UserId and au.Status = 3  
inner join HD_ISSUE_REQUEST ir on au.ReqId  = ir.ISS_REQID  and isnull(ir.ACTIVE,'Y') <> 'N'       
inner join ARC_REC_USER_INFO ui on au.UserId  = ui.USERID      
inner join ARC_REC_USER_INFO crb on au.CreatedBy  = crb.USERID      
inner join  ARC_REC_USER_INFO upb on au.UpdatedBy  = upb.USERID      
where CONVERT(DATE,dbo.FormatTimeZone(au.CreatedDt,'EST')) BETWEEN  @FromDate AND @ToDate      
and au.Status = 3    
union all      
Select     
[Type Of Request] = 'Termination'     
,[ARC Ticket #] = ir.TICKET_ID     
,[ARC Ticket # Date]=convert(varchar,CONVERT(DATE,dbo.FormatTimeZone(ir.CREATED_DT,'EST')),101)    
,[AHS Manager that raises Ticket*] = crb.FIRSTNAME+' '+crb.LASTNAME     
,[AHS Manager who updated athenaNet Username] = upb.FIRSTNAME+' '+upb.LASTNAME     
,[Date of action taken on athenaNet name in athenaNet]  = convert(varchar,CONVERT(DATE,dbo.FormatTimeZone(au.UpdatedDt,'EST')),101)    
,[Agent First Name] = ui.FIRSTNAME     
,[Agent Last Name] = ui.LASTNAME     
,[Agent athenaNet Username] = aur.AthenaUserName     
,[Department] = (Select Department from HD_Athena_Department Where DeptId =  isnull((Select top 1 DeptId from HD_Athena_Transfer Where UserId = au.UserId and Status = 3 Order by TransferId desc),aur.DeptId))    
,[Role] = (Select Role from HD_Athena_Role Where RoleId =  isnull((Select top 1 RoleId from HD_Athena_Transfer Where UserId = au.UserId and Status = 3 Order by TransferId desc),aur.RoleId))    
,[Agent's Citrix Username (if applicable)**] = isnull(isnull((Select top 1 CitrixUserName from HD_Athena_Transfer Where USERID = au.UserId and Status = 3 and isnull(CitrixUserName,'') <> ''  Order by TransferId desc),(Select top 1 CitrixUserName 
from HD_AthenaUsers   
Where USERID = au.UserId and Status = 3 and isnull(CitrixUserName,'') <> '' order by AthenaUserId desc)),'-')    
,[athena Ticket # for Citrix Account Update***] = case when ISNULL(au.CitrixReqId,'0') <> '0' and LEFT(au.CitrixReqId,3) <> 'INC' then 'INC' + Convert(varchar,au.CitrixReqId) else '-' end    
,[Type of Ticket for Citrix Account Update] = case when ISNULL(au.CitrixReqId,'0') <> '0' then 'Termination' else '-' end    
,[Type of Citrix Transfer] = '-'     
,[Start Date at AHS on the athena account listed in the ARC system] = (Select top 1 convert(varchar,CONVERT(DATE,dbo.FormatTimeZone(CreatedDt,'EST')),101) from HD_AthenaUsers Where UserId = au.UserId Order by AthenaUserId)    
,[Date of Department Transfer on the athena account (if applicable)] = '-'    
,[Termination Date of the day the agent departs from the athena account listed in ARC system] = convert(varchar,CONVERT(DATE,dbo.FormatTimeZone(au.UpdatedDt,'EST')),101)     
from HD_Athena_Terminate au      
inner join HD_AthenaUsers aur on au.UserId = aur.UserId and aur.Status = 3     
inner join HD_ISSUE_REQUEST ir on au.ReqId  = ir.ISS_REQID  and isnull(ir.ACTIVE,'Y') <> 'N'        
inner join ARC_REC_USER_INFO ui on au.UserId  = ui.USERID      
inner join ARC_REC_USER_INFO crb on au.CreatedBy  = crb.USERID      
inner join ARC_REC_USER_INFO upb on au.UpdatedBy  = upb.USERID       
where CONVERT(DATE,dbo.FormatTimeZone(au.CreatedDt,'EST')) BETWEEN  @FromDate AND @ToDate      
and au.Status = 3    
)x       
  
Order by x.[Date of action taken on athenaNet name in athenaNet],x.[ARC Ticket #]      
SET @OrderStr  = ''            
Exec FilterTable       
@DbName = 'tempdb'                        
,@TblName = '#Support_AthenaTicketView'                        
,@SearchStr = @SearchStr                        
,@SearchPattern = @SearchPattern                        
,@OrderStr = @OrderStr               
if OBJECT_ID('tempdb..#Support_AthenaTicketView') is not null drop table #Support_AthenaTicketView        
End    
   
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_ProcessedTickets] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_ProcessedTickets] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_ProcessedTickets] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_ProcessedTickets] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_ProcessedTickets] TO [DB_DMLSupport]
    AS [dbo];

