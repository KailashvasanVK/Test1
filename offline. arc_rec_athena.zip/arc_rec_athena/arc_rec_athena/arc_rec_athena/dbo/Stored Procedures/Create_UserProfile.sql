﻿  
CREATE Proc Create_UserProfile    
@NtName varchar(75),@Empcode varchar(10),@FirstName varchar(100),@CreatedUser varchar(75)    
as    
Begin    
--Declare @NtName varchar(75)  = 'vinoth.kumar2'    
--Declare @Empcode varchar(10) = 'E103688'    
--Declare @FirstName varchar(100) = 'Vinoth kumar.m'    
Declare @ClientId int = 25    
DECLARE @CreatedBy int=0  
  
SELECT @CreatedBy=USERID  FROM ARC_REC_USER_INFO Where NT_USERNAME = @CreatedUser  
  
IF NOT EXISTS(SELECT 1 FROM  ARC_REC_USER_INFO Where NT_USERNAME = @NtName and EMPCODE=@Empcode)  
BEGIN  
Insert into ARC_REC_USER_INFO(FIRSTNAME,LASTNAME,NT_USERNAME,DESIGNATION_ID,FUNCTIONALITY_ID,REC_ID    
,CREATED_BY,CREATED_DT,REPORTING_TO,EMPCODE,ACTIVE,CLIENT_ID,AHS_PRL,LastCustomerId)    
select @FirstName,'',@NtName,DESIGNATION_ID,FUNCTIONALITY_ID,0 as Rec_ID,@CreatedBy,GETDATE(),REPORTING_TO,@Empcode,1,@ClientId,'Y',@ClientId     
from ARC_REC_USER_INFO where nt_username = 'ramesh.raju'    
and NT_USERNAME not in (Select NT_USERNAME from ARC_REC_USER_INFO Where NT_USERNAME = @NtName)    
    
Declare @UserId int = 0    
Select @UserId = UserId from ARC_REC_USER_INFO Where NT_USERNAME = @NtName    
if ISNULL(@UserId,0) <> 0    
Begin    
Insert into ARC_REC_UserCustomer(CustomerID,UserId,CREATED_BY,CREATED_DT,PrimaryCust)    
Select @ClientId,@UserId,@CreatedBy,GETDATE(),1    
Where not exists (Select 1 from ARC_REC_UserCustomer Where UserId = @UserId and CustomerID = @ClientId)    
End    
END  
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Create_UserProfile] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Create_UserProfile] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Create_UserProfile] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Create_UserProfile] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Create_UserProfile] TO [DB_DMLSupport]
    AS [dbo];

