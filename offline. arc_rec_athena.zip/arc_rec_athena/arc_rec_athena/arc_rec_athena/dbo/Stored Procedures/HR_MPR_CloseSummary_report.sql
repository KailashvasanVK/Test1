﻿CREATE Procedure dbo.HR_MPR_CloseSummary_report                
 @FromDate datetime=null,                          
 @ToDate datetime=null,                                   
 @CountryId int=null,                                    
 @ZoneId int =null,                                    
 @hubId int =null,                                    
 @TCId int =null                                    
As                         
      
      
    
/*   HR_MPR_CloseSummary_report '2012-01-01','2013-04-05'        
    
exec HR_MPR_CloseSummary_report @FromDate='2013-04-01 00:00:00',@ToDate='2013-04-05 00:00:00'    
    
        */      
                   
   select                       
 mpr.MPRId as [ARMS ID],                          
                          
 de.Designation  as [Job title],                              
                          
mpr.TotalPositions as  [Requested(count)],                          
            
cd.PositionsClosed as [Selected(count)],                          
            
            
          
((mpr.TotalPositions) -( select sum(PositionsClosed) from HR_MPRClosedetails where      
 MPRId =cd.MPRId  group by MPRId )  ) as [Pending(count)],                           
            
cd.CreatedDate 'Closed On',                         
                          
                          
 isnull(ff.FunctionName,'')  + '-' + isnull(f.FunctionName,'') as [Functionality],                           
 um.UserName as [Raised by],                          
 convert(varchar(25), mpr.CreatedDate, 107) as [Raised date],                          
 convert(varchar(25), mpr.ExpDate, 107) as [Target date],                           
 tcm.Facility as [Facility],ci.CLIENT_NAME                 
                          
 from                               
  hr_MPR mpr inner join hr_Functionality f on mpr.FunctionalityId=f.FunctionalityId                                                       
  inner join hr_functionality ff on  ff.FunctionalityId  = f.FuncParentId                              
  inner join hr_designation de on mpr.DesigId = de.DesigId                              
  inner join HR_FacilityMaster tcm on tcm.TCId=mpr.TCId               
  left  join HR_MPRClosedetails CD On cd.MPRId =mpr.MPRId             
                           
 inner join mrplogin um on um.Userid = mpr.CreatedBy                   
 left join ARC_FIN_CLIENT_INFO CI on ci.CLIENT_ID =mpr .Clientid                      
 where mpr.ApprovalStatus =1 --and MPRStatus =1           
 and mpr.createddate>=@FromDate and mpr.createddate<=@ToDate 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_MPR_CloseSummary_report] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_CloseSummary_report] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_CloseSummary_report] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_MPR_CloseSummary_report] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_CloseSummary_report] TO [DB_DMLSupport]
    AS [dbo];

