﻿CREATE procedure ARC_REC_HeldNotJoinedInsert  
       @REC_IDS varchar(Max),    
       @HeldBy int,  
       @HeldRemark varchar(500)
         
As  
Begin  
if OBJECT_ID('tempdb..#HeldAssociates') is not null drop table #HeldAssociates
create table #HeldAssociates(REC_ID int)      
Insert into #HeldAssociates(REC_ID)    
Select Convert(int,items) from dbo.fnSplitString(@REC_IDS,',')    
Where items <> ''
Insert into ARC_REC_HeldNotJoined(UserId,Remarks,CreatedBy,CreatedDt)
Select ui.USERID,@HeldRemark,@HeldBy,GETDATE() from #HeldAssociates as held
inner join ARC_REC_USER_INFO as ui on ui.REC_ID = held.REC_ID
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_HeldNotJoinedInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_HeldNotJoinedInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_HeldNotJoinedInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_HeldNotJoinedInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_HeldNotJoinedInsert] TO [DB_DMLSupport]
    AS [dbo];

