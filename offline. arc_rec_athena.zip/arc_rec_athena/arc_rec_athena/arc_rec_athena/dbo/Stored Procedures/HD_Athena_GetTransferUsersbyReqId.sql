﻿CREATE PROCEDURE HD_Athena_GetTransferUsersbyReqId    
@ReqId int        
AS        
BEGIN        
Select at.TransferId,at.ReqId as ReqId,ir.TICKET_ID as TicketId,at.UserId,        
ui.FIRSTNAME as FirstName ,ui.LASTNAME as LastName,d.Department,r.Role,    
case when at.AddCitrix = 'Y' then 'Yes' when at.AddCitrix = 'N' then 'No' else '' end as HasCitrix,    
case when at.AddCitrix = 'Y' and at.CitrixUserName IS null then 'Not updated'            
when at.AddCitrix = 'N' then 'NR'            
else at.CitrixUserName end as CitrixUserName,
convert(varchar,at.TransferDate,106) as TransferDate    
from HD_Athena_Transfer at   
inner join HD_ISSUE_REQUEST ir on at.ReqId = ir.ISS_REQID        
inner join ARC_REC_USER_INFO ui on ui.USERID = at.UserId        
inner join HD_Athena_Department d on at.DeptId = d.DeptId        
inner join HD_athena_Role r on at.RoleId = r.RoleId        
where at.ReqId = @ReqId        
END
 
 

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_GetTransferUsersbyReqId] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetTransferUsersbyReqId] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetTransferUsersbyReqId] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_GetTransferUsersbyReqId] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetTransferUsersbyReqId] TO [DB_DMLSupport]
    AS [dbo];

