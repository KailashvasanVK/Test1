﻿CREATE PROCEDURE  [dbo].[HR_Department_Get]        
as        
begin        
 /*        
  Created By : Udhaya Ganesh P      
  Created Date : 30/08/2011    
  Purpose  : To fetch the department names        
       
 */       
 if exists(select 1 from HR_Functionality c        
   inner join HR_Functionality p on c.FuncParentId = p.FunctionalityId        
   where p.Status = 1 and c.Status = 1)        
 begin        
  select 0 as 'FunctionalityId', '-Select-' as 'FunctionName'        
   , '' as FuncParentName, '' as FuncName        
  union all        
  select c.FunctionalityId, c.FunctionName as 'FunctionName'        
   , c.FunctionName as FuncParentName, c.FunctionName as FuncName        
   from HR_Functionality c  where       
  c.Status = 1        
   order by FuncParentName, FuncName        
 end        
 else        
 begin        
  select 0 as 'FunctionalityId', '-No records-' as 'FunctionName', '' as FuncParentName, '' as FuncName         
 end        
end 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_Department_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_Department_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_Department_Get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_Department_Get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_Department_Get] TO [DB_DMLSupport]
    AS [dbo];

