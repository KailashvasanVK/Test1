﻿create procedure ARC_ME_CheckIsMultiDayShift  
       @UserId int  
      
As  
Begin    
--declare @UserId int  
--set @UserId = 16  
declare @ShiftId int    
select @ShiftId =st.SHIFT_ID from ARC_REC_SHIFT_TRAN st where USERID = @UserId order by CREATED_DT desc  
if exists(select * from ARC_REC_SHIFT_INFO where SHIFT_ID = @ShiftId and SHIFT_FROM > '12:00:00.0000000')  
 select 1 as Result
else  
 select 0 as Result
End  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_CheckIsMultiDayShift] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_CheckIsMultiDayShift] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_CheckIsMultiDayShift] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_CheckIsMultiDayShift] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_CheckIsMultiDayShift] TO [DB_DMLSupport]
    AS [dbo];

