﻿CREATE procedure ARC_AdminRoleConfigActions
@Action varchar(75),
@UserId  int  = 0,
@RoleName varchar(50) = null,
@AssignTo int = 0,
@RoleId int = 0,
@FUNCTIONALITY_ID int = 0
AS
/*
	Created by : Karthik Ic
	Created on : 06 Sep 2013
	Impact to  : AdminRoleConfig.aspx
	Purpose	   : To Assign the role for all funcionality and user using single user login.
*/
Begin
If @Action = 'ARC_Setup_MenuView'
-- Purpose  : To get the user menu details  --  
Begin  
Select MenuParentId,MenuDisplayText,MenuDescription, OutputPath,LogoFilePath,BaseFuntionality_Id,
DisplayOrder,MenuFileName,Boxno,MenuId  From  ARC_Setup_Menu ASM
--inner join ARC_REC_USER_INFO ARUI on ASM.BaseFuntionality_Id  in(0,ARUI.FUNCTIONALITY_ID )  and  ARUI.USERID = @USERID ----  Code and billing have same role ---- karthik.ic
inner join ARC_REC_USER_INFO ARUI on  ASM.BaseFuntionality_Id  in(0,@FUNCTIONALITY_ID)  and  ARUI.USERID = @USERID
order by DisplayOrder  
End  
else If @Action = 'ARC_REC_RoleGet' 
-- Purpose  : To get the active (status =1) role name and id to get for a functionality using user id.  --  
Begin  
Select  ASM.MenuParentId,ASM.MenuDisplayText,ASM.MenuDescription,ASM.OutputPath,ASM.LogoFilePath,ASM.BaseFuntionality_Id,ASM.MenuId,ASM.DisplayOrder,
ASM.MenuFileName From  ARC_Setup_Menu  ASM  inner join ARC_REC_USER_INFO  ARUI on ASM.BaseFuntionality_Id = (@FUNCTIONALITY_ID)
-- on ARUI.FUNCTIONALITY_ID  = ASM.BaseFuntionality_Id ----  Code and billing have same role ---- karthik.ic
Where arui.USERID = @USERID
End  
else If @Action = 'ARC_RoleNameCheck' 
-- Purpose  : To check the user role already existing or not  --  
Begin  
If exists (Select top 1 'x' from  ARC_REC_Role Where RoleName = @RoleName and  FUNCTIONALITY_ID = @FUNCTIONALITY_ID)  
Begin   
If exists (Select top 1 'x' from  ARC_REC_Role  ARR  Where RoleName = @RoleName and RoleId = @RoleId )  
Select 0 as Result -- not existing 
Else  
Select 1 as Result  -- already existing 
End   
Else  
Select 0 as Result -- not existing 
End  
else If @Action = 'ARC_RoleTranView' 
-- Purpose  : To get the Menu,Read,Write details for the Role using role id.  --  
Begin  
Select MenuId,RoleRead,RoleWrite  from ARC_REC_RoleTran  where RoleId = @RoleId
End  
else If @Action = 'ARC_REC_RoleTranMove' 
-- Purpose  : To move and delete the role and menu details from  ARC_REC_RoleTran into ARC_REC_RoleTranLog.  --  
Begin  
if exists(select  top 1 'x' from ARC_REC_RoleTran  where RoleId = @RoleId)  
begin  
------------ insert the data into log table  ------------   
Insert into ARC_REC_RoleTranlog(RoleId,MenuId,RoleRead,RoleWrite,CREATED_BY,CREATED_DT)
Select RoleId,MenuId,RoleRead,RoleWrite,CREATED_BY,CREATED_DT from ARC_REC_RoleTran Where RoleId = @RoleId
------------ Delete the data from ARC_REC_RoleTran table  ------------   
delete from ARC_REC_RoleTran Where RoleId = @RoleId
End  
End  
else If @Action = 'ARC_REC_RoleView'
-- Purpose  : To get the active (status =1) role name and id to view  using Role id. --  
Begin  
Select  ARR.RoleName,ARR.RoleId,ARR.DefaultRole from ARC_REC_Role ARR inner join ARC_REC_USER_INFO  ARUI on ARUI.USERID =@USERID
Where ARR.Status = 1  and ARR.RoleId = (case when isnull(@RoleId ,0) = 0 then ARR.RoleId else @RoleId end)
and ARR.FUNCTIONALITY_ID =  (@FUNCTIONALITY_ID) -- arui.FUNCTIONALITY_ID ---- billing and coding have same Role ----karthik ic
End
else If @Action = 'GetUserRole'
-- Purpose  : To get the user's current role --
Begin
SELECT  AUR.RoleId from  ARC_REC_UserRole AUR
Where AUR.USERID =@AssignTo  
and aur.FUNCTIONALITY_ID = (@FUNCTIONALITY_ID) 
End
else If @Action = 'GetFunctionality'
-- Purpose  : For AdminRoleConfig : Get all Active functionality.  --
Begin
Select FunctionName,FunctionalityId  from ARC_REC_Athena..hr_functionality Where Status = 1 
End
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_AdminRoleConfigActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_AdminRoleConfigActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_AdminRoleConfigActions] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_AdminRoleConfigActions] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_AdminRoleConfigActions] TO [DB_DMLSupport]
    AS [dbo];

