﻿--ARC_REC_NTrequests 0,'','='       
CREATE procedure ARC_REC_NTrequests       
@FunctionalityId int=0 ,       
@SearchStr varchar(100) = '',      
@SearchPattern varchar(4) = '=' /** = or % **/        
AS         
Begin      
----Declare @FunctionalityId int=0 ,       
----@SearchStr varchar(100) = '',      
----@SearchPattern varchar(4) = '%' /** = or % **/        

If OBJECT_ID('tempdb..#Test_NTrequestsView') is not null drop table #Test_NTrequestsView      
Create Table #Test_NTrequestsView(NT_FIRSTNAME varchar(50),NT_SecondName  varchar(50),NT_userNameCount int      
,NT_SystemName varchar(50),EmpCode varchar(10))      
insert into #Test_NTrequestsView(NT_FIRSTNAME,NT_SecondName,EmpCode)      
Select  REPLACE(REPLACE(Ui.FIRSTNAME,' ',''),'.',''),      
REPLACE(REPLACE((case when (select CTL_VALUE  from ARC_REC_SOFTCONTROL Where CTL_ID = 'CANDIDATE_MIDDLENAME' )= 'y' then isnull(Ui.MiddleName,'') else '' end) + isnull(ui.LASTNAME,''),' ',''),'.',''),EmpCode      
from  ARC_REC_USER_INFO ui        
 Where ISNULL(ui.AHS_PRL,'N') = 'Y' and ui.NT_USERNAME = '' and ui.ACTIVE=1   and       
 ui.FUNCTIONALITY_ID = (CASE WHEN @FunctionalityId  = 0 THEN  ui.FUNCTIONALITY_ID  else @functionalityId end )      
-- set nt_userName [only 15 char - first name as max 12 char + '.' + remining char Middle / Last Name as  min 2 char ]       
Update  #Test_NTrequestsView set  NT_SystemName =  LOWER (SUBSTRING(NT_FIRSTNAME,0,13) + '.' + SUBSTRING(NT_SecondName ,0,(16-LEN(SUBSTRING(NT_FIRSTNAME,0,13)+'.' ))))  where NT_SystemName is null       
-- get nt_userName count       

Declare @tEmpcode varchar(10)
Declare @tNt_Systemname varchar(100)
Declare @tDuplicateCount int = 0
Declare Cur Cursor for select Empcode,NT_SystemName from #Test_NTrequestsView 
open cur
while 1=1
Begin
fetch next from cur into @tEmpcode,@tNt_Systemname
if @@FETCH_STATUS = -1 break
Select @tDuplicateCount  = COUNT(*)
from
(
Select Nt_UserName from ARC_REC_USER_INFO Where NT_USERNAME like (@tNt_Systemname +'%')
Union 
Select nt_SystemName from #Test_NTrequestsView Where nt_SystemName like (@tNt_Systemname +'%') and isnull(NT_userNameCount,0) <> 0
)x
Update #Test_NTrequestsView Set NT_SystemName = NT_SystemName + case when @tDuplicateCount > 0 then CONVERT(varchar,@tDuplicateCount) else '' end,NT_userNameCount = @tDuplicateCount
Where EmpCode = @tEmpcode	
End
close cur
Deallocate cur

----Update  #Test_NTrequestsView set  NT_userNameCount = (Select COUNT(NT_USERNAME ) from  ARC_REC_USER_INFO  Where NT_USERNAME   like (nt_SystemName +'%')) Where NT_SystemName is not  null
------ add nt_userName Count if count > 0       
----Update  #Test_NTrequestsView set nt_SystemName   = nt_SystemName  + (Case when (NT_userNameCount) < 1 then '' else convert(varchar,NT_userNameCount )end )    where NT_SystemName is not  null       


      
If OBJECT_ID('tempdb..#NTrequestsView') is not null drop table #NTrequestsView       
Create Table #NTrequestsView([TICKET ID] int,EmpCode varchar(10),Facility varchar(50),FullName varchar(700),Doj varchar(15),[NT/EmailID] varchar(max)    
,[Email Access] varchar(50),[Dist List] varchar(50),[Folder Access] varchar(50),Client varchar(100),Designation varchar(100)    
,Functionality varchar(100),[Nt~Hide]   varchar(75) )       
    
      
Insert into #NTrequestsView([TICKET ID],EmpCode,Facility,Doj,FullName,[NT/EmailID],Functionality,Client,Designation,[Email Access],[Dist List],[Folder Access],[Nt~Hide]    )         
select HDIS.TICKET_ID ,  --im.IssReqId,      
ui.EMPCODE,isnull(fac.FacilityName,'') as Facility,convert(varchar,ui.doj,106),DBO.ConcatenateName(ui.FIRSTNAME,ui.MiddleName,ui.LASTNAME)    
,'<input type="text" style="width:97%;" class="txtbox" id="'+convert(varchar,ui.EMPCODE)+'" onkeypress="return ValidateSingleCode(event);" Readonly="Readonly" value ="'+ REPLACE(NTTest.NT_SystemName,' ','') +'">' as [NTUserName],      
f.FunctionName as FUNCTIONALITY,    
cl.CLIENT_NAME as CLIENT,    
d.Designation,    
emailAccess.Description as [Email Access]       
,distList.Description as [Dist List]       
,folderAccess.Description as [Folder Access]       
,REPLACE(NTTest.NT_SystemName,' ','') as [Nt~Hide]    
from ARC_REC_USER_INFO ui        
inner join ARC_REC_CANDIDATE can on ui.REC_ID = can.REC_ID        
inner join HR_Functionality f on ui.FUNCTIONALITY_ID = f.FunctionalityId       
inner join HR_Designation d on ui.DESIGNATION_ID= d.DesigId    
left join ARC_FIN_CLIENT_INFO cl on ui.CLIENT_ID = cl.CLIENT_ID        
inner join ARC_REC_InductionMaster im on ui.USERID = im.UserId     
left join ARC_REC_FacilityMaster fac on im.FacilityId = fac.FacilityId       
inner join ARC_REC_USER_INFO imb on im.CreatedBy = imb.USERID         
inner join HD_ISSUE_REQUEST HDIS on HDIS.ISS_REQID = im.NTReqId      
left join ARC_REC_NtRequirementFields as emailAccess on emailAccess.RqId = im.EmailAccessId       
left join ARC_REC_NtRequirementFields as distList on distList.RqId = im.DistributionAccessId       
left join ARC_REC_NtRequirementFields as folderAccess on folderAccess.RqId = im.FolderAccessId       
left join #Test_NTrequestsView NTTest on NTTest.EmpCode = ui.EMPCODE      
Where ISNULL(ui.AHS_PRL,'N') = 'Y'   and ui.NT_USERNAME = ''        
and ui.FUNCTIONALITY_ID = (case when @FunctionalityId = 0 then ui.FUNCTIONALITY_ID else @functionalityId end )  and ui.ACTIVE=1      
      
if OBJECT_ID('tempdb..#Test_NTrequestsView ') is not null drop table #Test_NTrequestsView      
      
Declare @OrderStr varchar(100)         = ' Order by Empcode'
SET @OrderStr  = ' order by EMPCODE'      
Exec FilterTable      
@DbName = 'tempdb'      
,@TblName = '#NTrequestsView'      
,@SearchStr = @SearchStr       
,@SearchPattern = @SearchPattern      
,@OrderStr = @OrderStr      
if OBJECT_ID('tempdb..#NTrequestsView') is not null drop table #NTrequestsView      
      
--if OBJECT_ID('tempdb..#NTrequestsView') is not null drop table #NTrequestsView       
--Create Table #NTrequestsView(IssReqId int,EmpCode varchar(10),FirstName varchar(50),LastName varchar(50),Functionality varchar(100)       
--,Client varchar(100),[Email Access] varchar(50),[Dist List] varchar(50),[Folder Access] varchar(50),[NTUserName]  varchar(max))      
      
--if(@FunctionalityId > 0)       
--begin         
--insert into #NTrequestsView(IssReqId,EmpCode,FirstName,LastName,Functionality,Client,[Email Access],[Dist List],[Folder Access],[NTUserName])         
--select im.IssReqId,ui.EMPCODE,ui.FIRSTNAME,ui.LASTNAME,f.FunctionName as FUNCTIONALITY,cl.CLIENT_NAME as CLIENT,        
--emailAccess.Description as [Email Access]       
--,distList.Description as [Dist List]       
--,folderAccess.Description as [Folder Access]       
--,'<input type="text" style="width:97%;" class="txtbox" id="'+convert(varchar,ui.EMPCODE)+'" onkeypress="return ValidateSingleCode(event);" Readonly="Readonly" value ="'+ui.FIRSTNAME+'.'+ui.LASTNAME +'">' as [NTUserName]         
--from ARC_REC_USER_INFO ui        
--inner join ARC_REC_CANDIDATE can on ui.REC_ID = can.REC_ID        
--inner join HR_Functionality f on ui.FUNCTIONALITY_ID = f.FunctionalityId       
--left join ARC_FIN_CLIENT_INFO cl on ui.CLIENT_ID = cl.CLIENT_ID        
--inner join ARC_REC_InductionMaster im on ui.USERID = im.UserId        
--inner join ARC_REC_USER_INFO imb on im.CreatedBy = imb.USERID         
--left join ARC_REC_NtRequirementFields as emailAccess on emailAccess.RqId = im.EmailAccessId       
--left join ARC_REC_NtRequirementFields as distList on distList.RqId = im.DistributionAccessId       
--left join ARC_REC_NtRequirementFields as folderAccess on folderAccess.RqId = im.FolderAccessId       
--where ISNULL(ui.AHS_PRL,'N') = 'Y' and ui.NT_USERNAME = '' and ui.FUNCTIONALITY_ID = @FunctionalityId and ui.ACTIVE=1         
----order by ui.EMPCODE       
--end      
--else      
--begin       
--insert into #NTrequestsView(IssReqId,EMPCODE,FIRSTNAME,LASTNAME,FUNCTIONALITY,CLIENT,[Email Access],[Dist List],[Folder Access],[NTUserName])         
--select im.IssReqId,ui.EMPCODE,ui.FIRSTNAME,ui.LASTNAME,f.FunctionName as FUNCTIONALITY,cl.CLIENT_NAME as CLIENT,       
--emailAccess.Description as [Email Access]       
--,distList.Description as [Dist List]       
--,folderAccess.Description as [Folder Access]        
--,'<input type="text" style="width:97%;" class="txtbox" id="'+convert(varchar,ui.EMPCODE)+'" onkeypress="return ValidateSingleCode(event);" Readonly="Readonly"  value ="'+ui.FirstName+'.'+ui.LastName +'">' as [NTUserName]         
--from ARC_REC_USER_INFO ui        
--inner join ARC_REC_CANDIDATE can on ui.REC_ID = can.REC_ID        
--inner join HR_Functionality f on ui.FUNCTIONALITY_ID = f.FunctionalityId       
--left join ARC_FIN_CLIENT_INFO cl on ui.CLIENT_ID = cl.CLIENT_ID        
--inner join ARC_REC_InductionMaster im on ui.USERID = im.UserId        
--inner join ARC_REC_USER_INFO imb on im.CreatedBy = imb.USERID        
--left join ARC_REC_NtRequirementFields as emailAccess on emailAccess.RqId = im.EmailAccessId       
--left join ARC_REC_NtRequirementFields as distList on distList.RqId = im.DistributionAccessId       
--left join ARC_REC_NtRequirementFields as folderAccess on folderAccess.RqId = im.FolderAccessId         
--where ISNULL(ui.AHS_PRL,'N') = 'Y' and ui.NT_USERNAME = '' and ui.ACTIVE=1        
----order by ui.EMPCODE       
--end      
--Declare @OrderStr varchar(100)         
--SET @OrderStr  = ' order by EMPCODE'      
--Exec FilterTable       
--@DbName = 'tempdb'       
--,@TblName = '#NTrequestsView'       
--,@SearchStr = @SearchStr       
--,@SearchPattern = @SearchPattern       
--,@OrderStr = @OrderStr       
--if OBJECT_ID('tempdb..#NTrequestsView') is not null drop table #NTrequestsView      
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_NTrequests] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_NTrequests] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_NTrequests] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_NTrequests] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_NTrequests] TO [DB_DMLSupport]
    AS [dbo];

