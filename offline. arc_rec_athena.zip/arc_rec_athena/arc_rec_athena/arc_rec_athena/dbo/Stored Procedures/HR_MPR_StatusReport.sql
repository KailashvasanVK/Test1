﻿CREATE Procedure dbo.HR_MPR_StatusReport(@userid int)                                
/*                                
 Created By  : UdhayaGanesh P                                
 Created On  : 30/08/2011                                
 Purpose   : To view list of Open/Closed MPR                              
  For summary page                                
Approval Status                              
--0 - Not Yet Approved; 1 - Approved (Check MPR_ApprovalMaster for details), 3 -Disapproved                              
MPR Status                              
0 - Open; 1 - Closed , 3 - Cancelled            
            
HR_MPR_StatusReport   1          
                            
*/                              
as                              
                              
SELECT                    
                       
 mpr.MPRId as [ARMS Id],                                
 tcm.Facility as [Facility],                
 --um.UserName as [Raised by],                                
 dbo.fn_getfullname(mpr.CreatedBy) as [Raised by],                                
 '<a title="ARMS Details" id='+ cast(mpr.MPRid as varchar) +'                                 
 href="#" url="/HR/MPR/MPRDisplay.aspx?MPRID='+ cast(mpr.MPRid as varchar) + '"                                 
 class=Link_Edit onclick="GB_show(this,550,650);" style="cursor:hand"><u>'+                                 
 de.Designation  +'</u></a>' as [Job title],                                    
  '<CENTER>'+ cast(mpr.TotalPositions as varchar) + '</center>' as  [Requested(count)],                                
 '<CENTER>' + cast((select isnull(sum(PositionsClosed), 0) from HR_MPRClosedetails where mprid = mpr.mprid) as varchar) + '</center>'  as [Selected(count)],                                
 '<center>' + cast(                    
 ((mpr.TotalPositions) -                                
 (select isnull(sum(PositionsClosed),0) from HR_MPRClosedetails where mprid = mpr.mprid)) as varchar) + '</center>' as [Pending(count)],                                
                    
 --isnull(ff.FunctionName,'')  + '-' +       
 isnull(f.FunctionName,'') as [Functionality],                                 
 convert(varchar(25), mpr.CreatedDate, 107) as [Raised date],                                
 convert(varchar(25), mpr.ExpDate, 107) as [Target date],                              
dbo.fn_getfullname(mpr.approvedby) as [Approved by],                              
--a.username as [Approved by],                              
 case mpr.approvalstatus when 0 then 'Not yet approved' when 1 then 'Approved' when 3 then 'Disapproved' end as [Approval status],                              
 case  when mpr.approvalstatus in(1,3) then                     
  case when mpr.mprstatus =0 and Mpr.Mprcancel= 0 then 'Open' when mpr.mprstatus =1     
   and Mpr.Mprcancel= 0 then 'Closed' when (Mpr.Mprcancel=1) then 'Cancelled' end                     
 end                    
as [ARMS status]                              
                               
                                
from                              
 hr_MPR mpr inner join hr_Functionality f on mpr.FunctionalityId=f.FunctionalityId                                                             
 --inner join hr_functionality ff on  ff.FunctionalityId  = f.FuncParentId                                    
 inner join hr_designation de on mpr.DesigId = de.DesigId                                    
 inner join HR_FacilityMaster tcm on tcm.TCId=mpr.TCId                                                     
order by mpr.CreatedDate desc 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_MPR_StatusReport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_StatusReport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_StatusReport] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_MPR_StatusReport] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_StatusReport] TO [DB_DMLSupport]
    AS [dbo];

