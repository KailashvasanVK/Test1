﻿--ARC_ME_AttAssociatesBySupervisor 2,0,'Y'
CREATE procedure ARC_ME_AttAssociatesBySupervisor               
       @SupervisorId int,    
       @ClientId int,    
       @IsSelfAttUser char(1)       
               
As        
Begin      
 declare @reporting as varchar(75)      
 select @reporting = NT_USERNAME from ARC_REC_USER_INFO where USERID=@SupervisorId      
       
 if OBJECT_ID('tempdb..#LoadAssociates ') is not null drop table #LoadAssociates           
 declare @qry as varchar(max)        
 Set @qry = 'select ui.USERID as UserId,ui.EMPCODE as EmpCode,ui.FIRSTNAME+'' ''+ui.LASTNAME+
case when isnull(ui.EMPCODE,'''')<> '''' then '' - (''+ ui.EMPCODE+'')''  else ''()'' end as EmpName  from ARC_REC_USER_INFO ui where isnull(ui.AHS_PRL,''Y'') = ''Y'' and ui.ACTIVE = 1 '             
    
if(@SupervisorId > 0)        
 set @qry = @qry + ' and ui.REPORTING_TO = '''+@reporting+''''     
if(@ClientId > 0)        
 set @qry = @qry + ' and ui.CLIENT_ID = '+CONVERT(varchar,@ClientId)        
if(@IsSelfAttUser = 'Y')    
 set @qry = @qry + 'union all select ui.USERID as UserId,ui.EMPCODE as EmpCode,
 ui.FIRSTNAME+'' ''+ui.LASTNAME+
case when isnull(ui.EMPCODE,'''')<> '''' then '' - (''+ ui.EMPCODE+'')''  else ''()'' end  as EmpName 
 from ARC_REC_USER_INFO ui where ui.USERID = '+CONVERT(varchar,@SupervisorId)     
         
set @qry = @qry + ' order by EmpName'        
print(@qry)         
Exec(@qry)        
End  
  


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_AttAssociatesBySupervisor] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_AttAssociatesBySupervisor] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_AttAssociatesBySupervisor] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_AttAssociatesBySupervisor] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_AttAssociatesBySupervisor] TO [DB_DMLSupport]
    AS [dbo];

