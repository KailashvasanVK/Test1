﻿CREATE procedure ARC_REC_Proximity_Insert
 @ProximityValue varchar(max), 
 @CREATED_BY int  
 As
/*
 * Purpose : To Insert the user's proximity details into Datatable
 *	
 */
Begin  
--Declare @ProximityValue varchar(max) = 'D071304~0008467742~12' 
--Declare @CREATED_BY int = 838 

If OBJECT_ID('tempdb..#tempProximity ') is not null drop table #tempProximity
 
 Create table #tempProximity (Proximity varchar(max), EmpCode varchar(10) ,ProximityNo varchar(10),InductionId int)
 Insert into #tempProximity (Proximity)
 Select items from dbo.fnSplitString(@ProximityValue,',') 
 Update #tempProximity Set 
 EmpCode = PARSENAME(REPLACE(Proximity, '~', '.'), 3), -- first value [EmpCode] 
 ProximityNo= PARSENAME(REPLACE(Proximity, '~', '.'), 2), -- Second Value [ProximityNo]
 InductionId= CAST( PARSENAME(REPLACE(Proximity, '~', '.'), 1) as int) -- last value [InductionId]
 
 Insert Into ARC_REC_Proximity (EmpCode,ProximityNo,InductionId,CREATED_BY)
 SELECT  TempProxy.EmpCode,TempProxy.ProximityNo,TempProxy.InductionId,@CREATED_BY as CREATED_BY
 FROM #tempProximity  as TempProxy
 Where  TempProxy.EmpCode  not in (Select EmpCode from ARC_REC_Proximity )
 and TempProxy.ProximityNo  not in(Select ProximityNo from #tempProximity group by ProximityNo having count(*)>1)
 End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_Proximity_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Proximity_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Proximity_Insert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_Proximity_Insert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Proximity_Insert] TO [DB_DMLSupport]
    AS [dbo];

