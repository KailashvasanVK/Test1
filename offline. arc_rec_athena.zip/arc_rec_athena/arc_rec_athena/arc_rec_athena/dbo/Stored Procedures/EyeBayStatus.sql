﻿CREATE Proc EyeBayStatus
(
@FacilityId int = 2
)
As
--Declare @FacilityId int = 2
Begin
/*
0 : Red
1,2 : Green
4 : Gray
*/
if OBJECT_ID('tempdb..#EyeStatus') is not null drop table #EyeStatus
Create Table #EyeStatus(BayNo varchar(20),BayIp varchar(20),UserName varchar(100),FirstName varchar(50),PhoneExt varchar(20)
,Designation varchar(50),Client varchar(100),ImagePath varchar(400),Status int,LogExists int
)
Insert into #EyeStatus(BayNo,BayIp,Status)
Select Bayno,BayIp,case when Status in (0,3) then 3 else 0 end from Eye_IPDetails (nolock) as eye
Where Facilityid = @FacilityId

Update #EyeStatus Set UserName = eyeView.FIRSTNAME + ' ' + eyeView.LASTNAME
,FirstName = eyeView.FIRSTNAME
,PhoneExt = eyeView.ExtNo
,Designation = eyeView.Designation
,Client = eyeView.Client_Name
,ImagePath = CASE WHEN ISNULL(eyeView.PROFILE_IMAGE_NAME,'') = '' THEN ISNULL(eyeView.PROFILE_IMAGE_NAME,'Images/UserImg.jpg') ELSE          
 'https://arc.accesshealthcare.co/arc_rec/images/candidate/' + eyeView.PROFILE_IMAGE_NAME END
,Status = case when eye.Status = 3 then 3 when eyeView.EventType in (1,3,5) then 1
       when eyeView.EventType = 2 then 2
       else 0 end 
 ,LogExists = 1      
from #EyeStatus as eye
inner join
	(
	Select eye.BayNo,eye.BayIP,ui.FIRSTNAME,ui.LASTNAME,eye.ExtNo,Desig.Designation,cus.Client_Name,cand.PROFILE_IMAGE_NAME,eye.Status,ulock.EventType
	from Eye_IPDetails as eye
	inner join 
	(
		Select ul.ClientAddress,ul.UserAccount,ul.EventTime,EventType,Eye.Facilityid 
		from
		(
			Select ClientAddress,Max(EventTime)EventTime
			from Userlock..UserLogonEvents as ul (nolock) 
			Where Eventtime>=GETDATE()-3
			group by ClientAddress
		)ulLast
		inner join Eye_IPDetails (nolock) as Eye on Eye.Facilityid = @FacilityId and Eye.BayIP = ulLast.ClientAddress
		inner join Userlock..UserLogonEvents UL(nolock) on UL.ClientAddress = ulLast.ClientAddress and ul.EventTime = ulLast.EventTime
		inner join ARC_REC_USER_INFO (nolock) as ui on ui.NT_USERNAME = ul.UserAccount
	) as ulock on ulock.ClientAddress = eye.BayIP and ulock.Facilityid = @FacilityId
	inner join ARC_REC_USER_INFO as ui on ui.NT_USERNAME = ulock.UserAccount
	inner join HR_Designation as Desig on Desig.DesigId = ui.DESIGNATION_ID
	inner join ARC_REC_CustomerView as Cus on Cus.Client_Id = ui.CLIENT_ID
	inner join ARC_REC_CANDIDATE Cand on Cand.REC_ID = ui.REC_ID        
	Where eye.Facilityid = @FacilityId
	) as eyeView on eyeView.BayNo = eye.BayNo 


Select * from #EyeStatus
select Particulars,Numbers from (            
select 'Floor capacity' Particulars,convert(varchar,Capacity) Numbers ,1 as priority from Eye_Facility Where FacilityId = @FacilityId
union            
select 'Total no of systems on the floor' , convert(varchar,COUNT(*))  ,2 from #EyeStatus where Status <> 3      
union            
select  'Total no of systems occupied',convert(varchar,COUNT(*)) ,3 from #EyeStatus where Status in (1,2)           
union            
select 'Percentage', Convert(varchar,Convert(int,((Select COUNT(*) from #EyeStatus where Status in (1,2)) / Convert(Decimal(9,2),(Select COUNT(*) from #EyeStatus where Status <> 3)))* 100)) + ' %',4
) as Eye order by priority            
if OBJECT_ID('tempdb..#EyeStatus') is not null drop table #EyeStatus
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[EyeBayStatus] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[EyeBayStatus] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[EyeBayStatus] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[EyeBayStatus] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[EyeBayStatus] TO [DB_DMLSupport]
    AS [dbo];

