﻿--ARC_ME_LeaveRequestValidation 846,2,1,'06-DEC-2013','06-DEC-2013'            
CREATE PROCEDURE ARC_ME_LeaveRequestValidation                      
 @USERID INT                                  
,@LEAVE_TYPEID INT=0                                                  
,@APPLIED_LEAVES DECIMAL(10,2)=0                         
,@FROMDATE DATE                                                  
,@TODATE DATE                       
AS                      
BEGIN                 
   DECLARE @PreviouslyAppliedLeaves AS DECIMAL(9,2) -- previously applied leaves for the same date                                        
   DECLARE @Result AS VARCHAR(MAX) -- result comments     
   SET @Result = 'SUCCESS'                                               
   DECLARE @LEAVE_MONTH AS INT  --- Applying leave month                                             
   DECLARE @LEAVE_YEAR AS INT   --- Applying leave year                                    
   DECLARE @VerifiedCheck AS INT  --- To check whether the att day verified before or not                      
   DECLARE @RemainigLeaves AS INT  -- Leave acccout balance                  
   DECLARE @SOFTCTL_VALUE VARCHAR(20)  -- soft ctl value regarding payroll                         
                        
   declare @Count as int                     
   declare @Dojdays as int  -- associate serving days from the doj                    
   declare @Doj as date                               
             
 --   declare @USERID INT                                  
 --declare @LEAVE_TYPEID INT=0                                                  
 --declare @APPLIED_LEAVES DECIMAL(10,2)                         
 --declare @FROMDATE DATE                                                  
 --declare @TODATE DATE                
                            
 --  SET @LEAVE_TYPEID = 1                      
 --  SET @USERID = 1451                      
 -- -- SET @LEAVE_TYPE = 'PTO'                      
 --  SET @FROMDATE = '06-Jan-2014'                      
 --  SET @TODATE = '06-Jan-2014'                      
 --  SET @APPLIED_LEAVES = 1                      
                         
   SET @LEAVE_MONTH = DATEPART(MONTH,@FROMDATE)                                              
   SET @LEAVE_YEAR = DATEPART(YEAR,@FROMDATE)                         
       select @SOFTCTL_VALUE =  CTL_VALUE from ARC_REC_SOFTCONTROL where CTL_ID = 'LEAVEREQ_PAYROLL_CHK'                                                   
                  
   IF OBJECT_ID('TEMPDB..#AVAILLEAVES','U') IS NOT NULL DROP TABLE #AVAILLEAVES                                                  
   CREATE TABLE #AVAILLEAVES (USERID INT,TYPEID INT,TYPE_TEXT VARCHAR(50),LEAVES DECIMAL(10,2))                                                  
   INSERT INTO #AVAILLEAVES                                                  
   EXEC ARC_ME_PendingLeaves  @UserId=@USERID,@Month = @LEAVE_MONTH,@Year=@LEAVE_YEAR              
                 
                          
  --select * from #AVAILLEAVES                                                                  
                                           
   SELECT @RemainigLeaves =  (ISNULL(LEAVES,0) - ISNULL(@APPLIED_LEAVES,0)) FROM #AVAILLEAVES WHERE TYPEID = @LEAVE_TYPEID                         
  -- select @REMAINING_LEAVES as RemainingLeaves                      
                               
   SET @PreviouslyAppliedLeaves = isnull((SELECT SUM(re.LEAVE_DAYS) FROM ARC_REC_LEAVE_REQUEST as re                                            
   inner join ARC_REC_LEAVE_TRAN as lt on lt.LEAVE_REQID = re.LEAVE_REQID and lt.LEAVE_DATE between @FROMDATE and @TODATE                      
   Where re.CREATED_BY = @USERID AND re.ACTIVE = 'Y' AND re.LEAVE_STATUS <> 2 and re.TYPEID <> 5 and re.LEAVE_MODE <> 'H' ),0)                        
                         
   SELECT @VerifiedCheck = COUNT(*) from ARC_REC_Attendance where Userid = @USERID and [DATE]                       
   between @FROMDATE and @TODATE and Verified_Present = 'F'                  
                        
     
  if @RemainigLeaves  >= 0                   
   begin                
                     
  if CONVERT(VARCHAR,@LEAVE_YEAR) <> CONVERT(VARCHAR,DATEPART(YEAR,GETDATE())) and @LEAVE_TYPEID = 1                                    
      SELECT @Result = 'Please check. You can apply leave for current year only.'                      
  else if (@PreviouslyAppliedLeaves > 0)                        
      SELECT @Result = 'Please check the list. You already applied for selected dates.'                  
  else if @VerifiedCheck > 0                                        
      SELECT @Result = 'Please check! The dates has been verified as "Full Present" already.'       
  else if (select COUNT(*) from ARC_ME_PAYROLL where DATEPART(Month,PAY_ROLL_DATE) = @LEAVE_MONTH and DATEPART(year,PAY_ROLL_DATE) = @LEAVE_YEAR) > 0 and @SOFTCTL_VALUE = 'N' and @LEAVE_TYPEID <> 5                                                          
    SELECT @Result = 'The Payroll has been generated already for this month!. You cannot apply leave in this month.'      
  else       
   begin                  
    if (@LEAVE_TYPEID = 8)  -- PTO        
     begin          
       select @Count = isnull(COUNT(*),0) from ARC_REC_LEAVE_REQUEST where CREATED_BY = @USERID and ACTIVE =  'Y'                       
        and LEAVE_STATUS <> 2 and TYPEID = @LEAVE_TYPEID and datepart(year,FROMDATE) = @LEAVE_YEAR                       
        and DATEPART(month,FROMDATE) = @LEAVE_MONTH                        
                      
       if(@Count > 0 and @Count < 5)                      
     SELECT @Result = 'Please check. You have taken Paid Time-Off leave already for this month.' -- if you wants to proceed further, you need to get Supervisor Approval.'                            
       else if (@Count > 5)                      
     SELECT @Result = 'Please check. Paid Time Off leave will not be granted for more than 5 days in a stretch and at a time.'                          
           
          end    
   end       
  end                  
  else                              
 SELECT @Result = 'You don''t have '+CONVERT(VARCHAR,@APPLIED_LEAVES)+' days leave in your selected leave account'                        
 SELECT @Result as RESULT                      
                         
 END     
     
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_LeaveRequestValidation] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_LeaveRequestValidation] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_LeaveRequestValidation] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_LeaveRequestValidation] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_LeaveRequestValidation] TO [DB_DMLSupport]
    AS [dbo];

