﻿CREATE Proc ARC_FORUM_LOUNGE_RULES_INS      
(      
@CONTENT VARCHAR(1000),      
@STATUS TINYINT=1,      
@CREATEDBY VARCHAR(50),    
@ERROR varchar(50) OUT     
)      
as        
/*      
ARC_FORUM_LOUNGE_RULES_INS @CONTENT='test6',@STATUS=1,@CREATEDBY='seena.ambaturu'      
*/      
begin      
SET NOCOUNT ON;    
IF NOT EXISTS(select * from ARC_FORUM_LOUNGE_HIGHlIGHT WHERE Content = @CONTENT)     
BEGIN    
INSERT INTO ARC_FORUM_LOUNGE_HIGHlIGHT(Content,Status,CreatedBy,CreatedOn) VALUES(@CONTENT,@STATUS,@CREATEDBY,GETDATE())      
SET @ERROR='Rules added Successfully!';    
END    
ELSE    
BEGIN    
SET @ERROR='Rules already Exists!';    
End    
END

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FORUM_LOUNGE_RULES_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_LOUNGE_RULES_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_LOUNGE_RULES_INS] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FORUM_LOUNGE_RULES_INS] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_LOUNGE_RULES_INS] TO [DB_DMLSupport]
    AS [dbo];

