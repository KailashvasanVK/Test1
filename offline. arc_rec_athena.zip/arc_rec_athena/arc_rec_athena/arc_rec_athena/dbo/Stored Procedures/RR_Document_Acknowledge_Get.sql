﻿CREATE Proc RR_Document_Acknowledge_Get        
@Docid int=0,        
@Clientid int=0,        
@Functionalityid int=0,        
@reportingto varchar(100)= Null,  
@Acknowledged varchar(5)='All'     
As        
/*          
 Created By  : Udhayaganesh P        
 Purpose     : Associate Wise Document Acknowledge Report        
         
 RR_Document_Acknowledge_Get @Docid=0,@Clientid=0,@FunctionalityId=0,@reportingTo =null        
 GO         
 RR_Document_Acknowledge_Get @Docid=1,@Clientid=0,@FunctionalityId=0,@reportingTo =null        
 Go        
 RR_Document_Acknowledge_Get @Docid=0,@Clientid=1,@FunctionalityId=0,@reportingTo =null        
 Go        
 RR_Document_Acknowledge_Get @Docid=0,@Clientid=0,@FunctionalityId=1,@reportingTo =null        
 Go        
 RR_Document_Acknowledge_Get @Docid=0,@Clientid=0,@FunctionalityId=0,@reportingTo ='Shaji.Ravi'        
         
 */        
Begin        
select  ROW_NUMBER() over(order by DocumentName,ClientName )'Sl,No' ,DocumentName,PublishedOn,EMPCODE,Associate,Designation,FunctionName,ClientName,Reporting_to,Acknowledged,AcknowledgeOn        
  from (        
select ld.DocID,uv.client_id,uv.FunctionalityId,ld.DocumentName,convert(varchar(20),LD.CreatedOn,110) PublishedOn,EMPCODE,Associate,Designation,FunctionName,        
Client_Name ClientName,Reporting_to,Acknowledged =Case When da.AcknowledgeBy IS Not Null then 'Yes' Else 'No' End        
,convert(varchar(20),Da.AcknowledgeOn,110) as AcknowledgeOn        
from ARC_REC_USER_INFO_VY uv (nolock)        
Left join ARC_REC_LegalDocument LD on  1=1        
Left Join ARC_REC_Document_Acknowledge DA on Da.DocId =ld.DocID and uv.userid=da.AcknowledgeBy        
) AS Data1         
where isnull(DocID,0) =(case when @DocID =0 then isnull(DocID,0) else @Docid end) and        
client_id =(case when @Clientid =0 then client_id else @Clientid end)and        
FunctionalityId =(case when @FunctionalityId =0 then FunctionalityId else @FunctionalityId end) and        
Reporting_to=(case when @reportingTo is Null then Reporting_to else @reportingTo end) and    
Acknowledged=(case when @Acknowledged ='All' then Acknowledged else @Acknowledged end)     
order by DocumentName,ClientName        
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Document_Acknowledge_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Document_Acknowledge_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Document_Acknowledge_Get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Document_Acknowledge_Get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Document_Acknowledge_Get] TO [DB_DMLSupport]
    AS [dbo];

