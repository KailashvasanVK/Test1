﻿CREATE PROCEDURE [dbo].[ARC_REC_TraineeAttendance]  
@Att_Date varchar(20)='',  
@UserID varchar(20)=''  
AS  
BEGIN    
 select Verified_Present,Verified_Comments from ARC_REC_Attendance where  Userid=@UserID and [Date]=@Att_Date  
END

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_TraineeAttendance] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_TraineeAttendance] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_TraineeAttendance] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_TraineeAttendance] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_TraineeAttendance] TO [DB_DMLSupport]
    AS [dbo];

