﻿CREATE Procedure ARC_FIN_CLIENT_GET           
@NTUserName Varchar(75)=NULL               
AS                
Begin             
If @NTUserName in('sanjeev.britto','deepa.bhat','Shaji.ravi','arvind.perumbal','Udhayaganesh.p','prince.jesudoss')          
Begin             
Select CLIENT_ID,CLIENT_NAME,SHORT_NAME from ARC_FIN_CLIENT_INFO                
      
End          
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FIN_CLIENT_GET] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FIN_CLIENT_GET] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FIN_CLIENT_GET] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FIN_CLIENT_GET] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FIN_CLIENT_GET] TO [DB_DMLSupport]
    AS [dbo];

