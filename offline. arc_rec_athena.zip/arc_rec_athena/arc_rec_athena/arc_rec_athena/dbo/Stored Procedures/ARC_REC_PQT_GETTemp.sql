﻿CREATE PROCEDURE ARC_REC_PQT_GETTemp        
(        
@SESSIONID VARCHAR(500),        
@TragetDate datetime,  
@Type tinyint=1      
)        
/*        
ARC_REC_PQT_GETTemp @SESSIONID='gitb2sp4qphs5zha5nok4w1l847635321328434695119_ProductQT',@TRAGETDATE='2014-04-02'        
*/        
AS        
BEGIN    
If @Type =1   
Begin     
select distinct convert(varchar(20),T.TRAGETDATE,110) TRAGETDATE,T.NTUSERNAME,T.PTARGET,T.PACHIEVED,T.PERCENTAGE,    
isnull(B.POINTS,0) SDPs,RTYPE= case when O.NTUSERNAME=T.NTUSERNAME and  O.TRAGETDATE=T.TRAGETDATE  then 'Duplicate' else 'New' end        
from ARC_Rec_ProductionQT_Temp T    
left join ARC_Rec_ProductionQT O on O.NTUSERNAME=T.NTUSERNAME and  O.TRAGETDATE=T.TRAGETDATE and o.RTYPE=T.RTYPE  
Left join RR_CRITERA_MASTER b on b.cid in (27,28,29) and T.PERCENTAGE>=b.startrange and T.PERCENTAGE<=b.endrange  
where SESSIONID=@SESSIONID and T.TRAGETDATE=@TragetDate and T.RTYPE =@Type     
End  
Else If @Type=2  
begin  
select distinct convert(varchar(20),T.TRAGETDATE,110) TRAGETDATE,T.NTUSERNAME,T.PTARGET,T.PACHIEVED,T.PERCENTAGE,    
isnull(B.POINTS,0) SDPs,RTYPE= case when O.NTUSERNAME=T.NTUSERNAME and  O.TRAGETDATE=T.TRAGETDATE  then 'Duplicate' else 'New' end        
from ARC_Rec_ProductionQT_Temp T    
left join ARC_Rec_ProductionQT O on O.NTUSERNAME=T.NTUSERNAME and  O.TRAGETDATE=T.TRAGETDATE and o.RTYPE=T.RTYPE  
Left join RR_CRITERA_MASTER b on b.cid in (30,31,32) and T.PERCENTAGE>=b.startrange and T.PERCENTAGE<=b.endrange  
where SESSIONID=@SESSIONID and T.TRAGETDATE=@TragetDate and T.RTYPE =@Type     
End   
END
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_PQT_GETTemp] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_PQT_GETTemp] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_PQT_GETTemp] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_PQT_GETTemp] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_PQT_GETTemp] TO [DB_DMLSupport]
    AS [dbo];

