﻿CREATE procedure ARC_REC_FunctionalityConfig
@REC_IDs varchar(max),
@NewFunctionalityId int = 0,
@CreatedBy int = 0
As
 --Declare @REC_IDs varchar(max)=N',13071106,13071100,1301077,13071104,13071103,13071175,13071101,13071105,13071102,13071099'
 --Declare @NewFunctionalityId int = 8
 --Declare @CreatedBy int = 1
Begin
If OBJECT_ID('tempdb..#FunctionalityConfigusers') is not null Drop table #FunctionalityConfigusers
Create table #FunctionalityConfigusers(UserId int,REC_ID Int)

Insert into #FunctionalityConfigusers(REC_ID)
Select items From dbo.fnSplitString(@REC_IDs,',')

Update  #FunctionalityConfigusers set  UserId  = ui.USERID
From #FunctionalityConfigusers Fcon join ARC_REC_USER_INFO ui on ui.REC_ID = Fcon.REC_ID

Insert into ARC_REC_FunctionalityLog(userid,FUNCTIONALITY_ID, CREATED_BY,CREATED_DT)
Select   UI.userid, UI.FUNCTIONALITY_ID,  UI.CREATED_BY, UI.CREATED_DT  From ARC_REC_Athena..ARC_REC_USER_INFO  UI 
Inner join #FunctionalityConfigusers FCon on FCon.UserId  = UI.USERID

Update UI  set FUNCTIONALITY_ID = @NewFunctionalityId,CREATED_BY = @CreatedBy  
From ARC_REC_Athena..ARC_REC_USER_INFO  UI 
Inner join #FunctionalityConfigusers FCon on FCon.UserId = UI.USERID 
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_FunctionalityConfig] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_FunctionalityConfig] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_FunctionalityConfig] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_FunctionalityConfig] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_FunctionalityConfig] TO [DB_DMLSupport]
    AS [dbo];

