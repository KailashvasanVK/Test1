﻿CREATE procedure ARC_REC_ProximityAction      
 @Action varchar(75),             
 @SearchStr varchar(100) = '',             
 @SearchPattern varchar(4) = '=', /** = or % **/             
 @ProxyId INT = 0,             
 @UserID INT = 0             
 AS             
 /*                   
Created by : Dineshbabu             
Created on : 13 Feb 2014             
Impact to  : ProximityRequest.aspx and ProximityChange.aspx             
*/             
Begin             
If @Action = 'ARC_Proximity_Request'             
-- Purpose :  To get user's details where ProximityNo is null             
  Begin             
   --Declare   @SearchStr varchar(100) = ''             
   --Declare   @SearchPattern varchar(4) = '=' /** = or % **/             
  if OBJECT_ID('tempdb..#ProximityView') is not null drop table #ProximityView             
  Select ind.InductionId [InductionId~Hide] ,CONVERT(varchar, ROW_NUMBER() OVER(ORDER BY ind.InductionId ASC)) AS SNo ,          
  IssReq.TICKET_ID [Ticket Id] ,Ui.FIRSTNAME + ' ' +(case when (select CTL_VALUE  from ARC_REC_SOFTCONTROL Where CTL_ID = 'CANDIDATE_MIDDLENAME' )= 'y' then isnull(Ui.MiddleName,'') else '' end) + isnull(ui.LASTNAME,'')as UserName ,           
  -- ui.NT_USERNAME as UserName          
 ui.EMPCODE , isnull(fac.FacilityName,'') as Facility,'<input type="text" style="width:97%;" class="txtbox" id="'+convert(varchar,ui.EMPCODE)+'" onkeypress="return ValidateNumberOnly(event,this);" maxlength ="10" InductionId = '+ CAST(ind.InductionId AS VARCHAR)+'>' as [ProximityNo] ,  
  hrd.Designation ,hrf.FunctionName ,cl.Client_Name as Client,ui.REPORTING_TO            
  ,CONVERT(VARCHAR(10), ui.DOJ, 105) AS DOJ , bg.GroupName as [Blood Group], cr.EMER_CONTACT_NO as [Emergency Contact Number]           
   into #ProximityView         
   from ARC_REC_InductionMaster as Ind             
   Inner join ARC_REC_USER_INFO as ui on ui.USERID = Ind.UserId             
   Inner join HD_ISSUE_REQUEST as IssReq on IssReq.ISS_REQID = ind.ProximityReqId             
   inner join  ARC_FIN_CLIENT_INFO cl on ui.CLIENT_ID = cl.CLIENT_ID             
   inner join ARC_REC_CANDIATE_PROFILE as cr on ui.REC_ID = cr.REC_ID          
   left join HR_Functionality  HRF on HRF.FunctionalityId = ui.FUNCTIONALITY_ID             
   left  join HR_Designation HRD on HRD.DesigId = DESIGNATION_ID             
   left join ARC_REC_BloodGroup bg on cr.BLOODGROUP = bg.BloodGroup    
   left join ARC_REC_FacilityMaster fac on Ind.FacilityId = fac.FacilityId          
   Where not exists (select 1 from ARC_REC_Proximity as pr Where pr.EmpCode = ui.EMPCODE) and ui.ACTIVE <> 2             
             
  Exec FilterTable             
   @DbName = 'tempdb'             
  ,@TblName = '#ProximityView'             
  ,@SearchStr = @SearchStr             
  ,@SearchPattern = @SearchPattern             
  ,@OrderStr = ''             
  If OBJECT_ID('tempdb..#ProximityView') is not null drop table #ProximityView             
  End              
             
Else If  @Action = 'ARC_Proximity_Manage'             
-- Purpose :  To get user's details to Manage             
  Begin             
  --Declare   @SearchStr varchar(100) = ''             
  --Declare   @SearchPattern varchar(4) = '=' /** = or % **/             
  --Declare  @userid   int = 306             
if OBJECT_ID('tempdb..#ProximityManageView') is not null drop table ProximityManageView             
  Select   '<button onclick="return ProximityDetails(''' + convert(varchar,ISNULL(Prox.ProxyId,0)) + ''',          
  ''' + CONVERT(varchar,ISNULL(UI.USERID,0)) + ''');"  class=  "Action ui-button ui-widget ui-state-default ui-    corner-all ui-button-icon-only" id="btnProximityManage" role="               
  button" aria-disabled="false" title="Proximity Manage Details">               
  <span class="ui-button-icon-primary ui-icon ui-icon-pencil"></span>               
  <span class="ui-button-text">&nbsp;</span></button>' as [ACTION] ,        
  CONVERT(varchar, ROW_NUMBER() OVER(ORDER BY ui.EMPCODE ASC)) AS SNo ,        
 ui.FIRSTNAME + ' ' +(case when (select CTL_VALUE  from ARC_REC_SOFTCONTROL Where CTL_ID = 'CANDIDATE_MIDDLENAME' )= 'y'   
 then isnull(Ui.MiddleName,'') else '' end) + isnull(ui.LASTNAME,'')as UserName, ui.EMPCODE,        
isnull(fac.FacilityName,'') as Facility,  
 --ui.NT_USERNAME as UserName,        
  Prox.ProximityNo , hrd.Designation, hrf.FunctionName,cl.Client_Name as Client, ui.REPORTING_TO , CONVERT(VARCHAR(10),  
   ui.DOJ, 105) AS DOJ ,  bg.GroupName as [Blood Group], cr.EMER_CONTACT_NO as [Emergency Contact Number]        
 into #ProximityManageView         
  from ARC_REC_Proximity as Prox           
 Inner join ARC_REC_USER_INFO as ui on UI.ACTIVE = 1 AND UI.AHS_PRL = 'Y' AND Prox.EmpCode = UI.EMPCODE and ui.USERID = (CASE WHEN @UserID = 0 THEN ui.USERID ELSE @UserID END)           
 inner join  ARC_FIN_CLIENT_INFO cl on ui.CLIENT_ID = cl.CLIENT_ID         
 inner join ARC_REC_CANDIATE_PROFILE as cr on ui.REC_ID = cr.REC_ID            
 left join HR_Functionality  HRF on HRF.FunctionalityId = ui.FUNCTIONALITY_ID           
 left  join HR_Designation HRD on HRD.DesigId = DESIGNATION_ID           
 left join ARC_REC_BloodGroup bg on cr.BLOODGROUP = bg.BloodGroup    
  left join ARC_REC_InductionMaster Ind on ui.USERID = Ind.UserId       
    left join ARC_REC_FacilityMaster fac on Ind.FacilityId = fac.FacilityId       
 Where ui.USERID = (case when ISNULL(@userid,0)=0 then ui.USERID else @UserID end )           
 and  exists (select 1 from ARC_REC_Proximity as pr Where pr.EmpCode = ui.EMPCODE)             
  Exec FilterTable                 
  @DbName = 'tempdb'            
  ,@TblName = '#ProximityManageView'            
  ,@SearchStr = @SearchStr                 
  ,@SearchPattern = @SearchPattern         
  ,@OrderStr = ''                 
  If OBJECT_ID('tempdb..#ProximityManageView') is not null drop table #ProximityManageView                 
 End               
             
Else If  @Action = 'ARC_ProximityManage_Dialog'            
-- Purpose :  To Get Proximity Details to show proximity manage                  
 BEGIN            
  SELECT ISNULL(Proxy.ProxyId,0) AS ProxyId, UI.NT_USERNAME,UI.EMPCODE , ISNULL(Proxy.ProximityNo,0) AS ProximityNo             
  ,UI.USERID FROM ARC_REC_USER_INFO UI             
  INNER JOIN ARC_REC_Proximity Proxy ON Proxy.EmpCode = UI.EMPCODE AND Proxy.ProxyId = @ProxyId             
  WHERE UI.ACTIVE = 1 AND UI.AHS_PRL = 'Y' and UI.USERID = @UserID             
 END             
             
Else If  @Action = 'ARC_ProximityAssociates'             
-- Purpose :  To Get Associates for User name and userid             
 BEGIN             
 SELECT FIRSTNAME + ' ' +  LASTNAME + ' - (' + ISNULL(EMPCODE, ' ') +' ) ' AS NAME, USERID FROM ARC_REC_USER_INFO WHERE AHS_PRL = 'Y' AND     ACTIVE = 1 ORDER BY NAME;                  
 END               
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ProximityAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ProximityAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ProximityAction] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ProximityAction] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ProximityAction] TO [DB_DMLSupport]
    AS [dbo];

