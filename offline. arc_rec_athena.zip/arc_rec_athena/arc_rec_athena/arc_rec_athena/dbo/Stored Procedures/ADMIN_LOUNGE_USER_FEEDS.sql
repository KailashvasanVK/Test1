﻿CREATE PROCEDURE ADMIN_LOUNGE_USER_FEEDS          
@Searchtext varchar(500)=null                  
AS        
BEGIN           
select ID,Content,type,CreatedBy,CONVERT(VARCHAR(19),CreatedOn)CreatedOn,ReportedBy,CONVERT(VARCHAR(19),ReportedOn)ReportedOn,fStatus from (                   
SELECT m.id AS id,CONVERT(VARCHAR(MAX), m.MsgContent) AS Content, dbo.AssoicateName(m.CreatedBy) +' | Email ID :- '+m.CreatedBy+'@accesshealthcare.co' AS CreatedBy,m.CreatedOn AS CreatedOn, dbo.AssoicateName(mf.ReportedBy)                 
 +' | Email ID :- '+ mf.ReportedBy +'@accesshealthcare.co'  AS ReportedBy,mf.ReportedOn AS ReportedOn ,mf.Status AS fStatus,'1' AS Type,mf.MsgId,m.Status AS Status                   
 FROM ARC_Forum_Lounge_Messages m                   
 inner JOIN ARC_Forum_Lounge_Message_Flags mf  ON  mf.MsgId=m.id           
 where mf.Status =1                 
UNION                    
SELECT c.id  AS id,CONVERT(VARCHAR(MAX), c.CommentText) AS Content,dbo.AssoicateName(c.CommentedBy) +' | Email ID :- '+C.CommentedBy+'@accesshealthcare.co'  AS CreatedBy,c.CommentedOn As CreatedOn,
dbo.AssoicateName(Cf.ReportedBy)+' | Email ID :- '+cf.ReportedBy+'@accesshealthcare.co' AS ReportedBy,cf.ReportedOn AS ReportedOn,                  
cf.Status AS fStatus,'2' AS Type,MsgId,c.Status AS Status  FROM  ARC_Forum_Lounge_Message_Comments c                   
inner  JOIN ARC_Forum_Lounge_Comment_Flags cf ON  cf.CmtId=c.id          
where cf.Status =1        
  ) as u WHERE Content         
 like ('%'+(                                  
  CASE                                  
   WHEN @Searchtext IS NOT NULL THEN @Searchtext                                  
   WHEN @Searchtext IS NULL THEN Content                         
  END )+'%') and                    
 u.Status=1       
 Order by MsgId desc,type                
                    
END
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADMIN_LOUNGE_USER_FEEDS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADMIN_LOUNGE_USER_FEEDS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADMIN_LOUNGE_USER_FEEDS] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADMIN_LOUNGE_USER_FEEDS] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADMIN_LOUNGE_USER_FEEDS] TO [DB_DMLSupport]
    AS [dbo];

