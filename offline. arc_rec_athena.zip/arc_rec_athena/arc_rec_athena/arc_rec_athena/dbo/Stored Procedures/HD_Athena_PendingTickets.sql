﻿CREATE proc [dbo].[HD_Athena_PendingTickets]    
@FromDate date,    
@ToDate date    
,@SearchStr varchar(100) = '',                     
@SearchPattern varchar(4) = '=' /** = or % **/        
As    
Begin    
--Declare @FromDate date = '2014-03-01'
--Declare @ToDate date    = '2014-04-08'
--Declare @SearchStr varchar(100) = '',                     
--@SearchPattern varchar(4) = '=' /** = or % **/        
if OBJECT_ID('tempdb..#Support_AthenaTicketView') is not null drop table #Support_AthenaTicketView      
Declare @OrderStr varchar(100)     
select * into #Support_AthenaTicketView   
from (    
select   
[Type Of Request] = 'New Hire'   
,[ARC Ticket #] = ir.TICKET_ID   
,[ARC Ticket # Date]=convert(varchar,CONVERT(DATE,dbo.FormatTimeZone(ir.CREATED_DT,'EST')),101)  
,[AHS Manager that raises Ticket*] = crb.FIRSTNAME+' '+crb.LASTNAME   
,[AHS Manager that approves Ticket*] = sup.FIRSTNAME+' '+sup.LASTNAME   
,[Agent First Name] = ui.FIRSTNAME   
,[Agent Last Name] = ui.LASTNAME   
,[Department] = de.Department   
,[Role] = ro.Role
,[Agent athenaNet Username] = au.AthenaUserName   
,[Agent's Citrix Username (if applicable)**] =isnull(au.CitrixUserName,'-')   
,[Status] = case when au.Status = 0 then 'Pending approval' when au.Status = 1 and isnull(au.AthenaUserName,'') <> '' and ISNULL(HasCitrixReq,'N') = 'Y' then 'Citrix Pending' when au.Status = 1 then 'Pending Resolution' else Convert(varchar,au.Status) end
from HD_AthenaUsers au    
inner join HD_ISSUE_REQUEST ir on au.Issue_ReqId  = ir.ISS_REQID  and isnull(ir.ACTIVE,'Y') <> 'N'     
inner join ARC_REC_USER_INFO ui on au.UserId  = ui.USERID    
inner join ARC_REC_USER_INFO crb on au.CreatedBy  = crb.USERID    
left join ARC_REC_USER_INFO sup on sup.UserId  = ir.FORWARD_TO
inner join HD_Athena_Role ro on au.RoleId  = ro.RoleId    
inner join HD_Athena_Department de on au.DeptId  = de.DeptId    
where CONVERT(DATE,dbo.FormatTimeZone(au.CreatedDt,'EST')) BETWEEN @FromDate AND @ToDate   
and au.Status in (0,1)  
union all    
Select   
[Type Of Request] = 'Transfer'   
,[ARC Ticket #] = ir.TICKET_ID   
,[ARC Ticket # Date]=convert(varchar,CONVERT(DATE,dbo.FormatTimeZone(ir.CREATED_DT,'EST')),101)  
,[AHS Manager that raises Ticket*] = crb.FIRSTNAME+' '+crb.LASTNAME   
,[AHS Manager that approves Ticket*] = sup.FIRSTNAME+' '+sup.LASTNAME   
,[Agent First Name] = ui.FIRSTNAME   
,[Agent Last Name] = ui.LASTNAME   
,[Agent athenaNet Username] = aur.AthenaUserName   
,[Agent's Citrix Username (if applicable)**] =isnull(au.CitrixUserName,'-')   
,[Department] = (Select Department from HD_Athena_Department Where DeptId =  isnull((Select top 1 DeptId from HD_Athena_Transfer Where UserId = au.UserId and Status = 3 Order by TransferId desc),aur.DeptId))  
,[Role] = (Select Role from HD_Athena_Role Where RoleId =  isnull((Select top 1 RoleId from HD_Athena_Transfer Where UserId = au.UserId and Status = 3 Order by TransferId desc),aur.RoleId))  
,[Status] = case when au.Status = 0 then 'Pending approval' when au.Status = 1 then 'Pending Resolution' else Convert(varchar,au.Status) end
from HD_Athena_Transfer au    
inner join HD_AthenaUsers aur on au.UserId = aur.UserId and au.Status = 3
inner join HD_ISSUE_REQUEST ir on au.ReqId  = ir.ISS_REQID  and isnull(ir.ACTIVE,'Y') <> 'N'     
left join ARC_REC_USER_INFO sup on sup.UserId  = ir.FORWARD_TO
inner join ARC_REC_USER_INFO ui on au.UserId  = ui.USERID    
inner join ARC_REC_USER_INFO crb on au.CreatedBy  = crb.USERID    
where CONVERT(DATE,dbo.FormatTimeZone(au.CreatedDt,'EST')) BETWEEN  @FromDate AND @ToDate    
and au.Status in (0,1)  
union all    
Select   
[Type Of Request] = 'Termination'   
,[ARC Ticket #] = ir.TICKET_ID   
,[ARC Ticket # Date]=convert(varchar,CONVERT(DATE,dbo.FormatTimeZone(ir.CREATED_DT,'EST')),101)  
,[AHS Manager that raises Ticket*] = crb.FIRSTNAME+' '+crb.LASTNAME   
,[AHS Manager that approves Ticket*] = sup.FIRSTNAME+' '+sup.LASTNAME   
,[Agent First Name] = ui.FIRSTNAME   
,[Agent Last Name] = ui.LASTNAME   
,[Department] = (Select Department from HD_Athena_Department Where DeptId =  isnull((Select top 1 DeptId from HD_Athena_Transfer Where UserId = au.UserId and Status = 3 Order by TransferId desc),aur.DeptId))  
,[Role] = (Select Role from HD_Athena_Role Where RoleId =  isnull((Select top 1 RoleId from HD_Athena_Transfer Where UserId = au.UserId and Status = 3 Order by TransferId desc),aur.RoleId))  
,[Agent athenaNet Username] = aur.AthenaUserName   
,[Agent's Citrix Username (if applicable)**] = isnull(isnull((Select top 1 CitrixUserName from HD_Athena_Transfer Where USERID = au.UserId and Status = 3 and isnull(CitrixUserName,'') <> ''  Order by TransferId desc),(Select top 1 CitrixUserName from HD_AthenaUsers 
Where USERID = au.UserId and Status = 3 and isnull(CitrixUserName,'') <> '' order by AthenaUserId desc)),'-')  
,[Status] = case when au.Status = 0 then 'Pending approval' when au.Status = 1 then 'Pending Resolution' else Convert(varchar,au.Status) end
from HD_Athena_Terminate au    
inner join HD_AthenaUsers aur on au.UserId = aur.UserId and aur.Status = 3   
inner join HD_ISSUE_REQUEST ir on au.ReqId  = ir.ISS_REQID  and isnull(ir.ACTIVE,'Y') <> 'N'      
inner join ARC_REC_USER_INFO ui on au.UserId  = ui.USERID    
inner join ARC_REC_USER_INFO crb on au.CreatedBy  = crb.USERID    
left join ARC_REC_USER_INFO sup on sup.UserId  = ir.FORWARD_TO
where CONVERT(DATE,dbo.FormatTimeZone(au.CreatedDt,'EST')) BETWEEN  @FromDate AND @ToDate    
and au.Status in (0,1)
)x     
Order by x.[ARC Ticket #]    
SET @OrderStr  = ''          
Exec FilterTable     
@DbName = 'tempdb'                      
,@TblName = '#Support_AthenaTicketView'                      
,@SearchStr = @SearchStr                      
,@SearchPattern = @SearchPattern                      
,@OrderStr = @OrderStr             
if OBJECT_ID('tempdb..#Support_AthenaTicketView') is not null drop table #Support_AthenaTicketView      
End  
 



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_PendingTickets] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_PendingTickets] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_PendingTickets] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_PendingTickets] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_PendingTickets] TO [DB_DMLSupport]
    AS [dbo];

