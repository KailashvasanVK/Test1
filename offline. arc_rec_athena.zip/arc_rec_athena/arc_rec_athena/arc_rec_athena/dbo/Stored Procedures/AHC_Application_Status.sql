﻿CREATE Proc AHC_Application_Status                
@Recruitmentid varchar(40)='1211434' ,          
@FBUserId varchar(100)=''              
as                
bEGIN              
DECLARE @RESULT VARCHAR(100)      
SET @RESULT = ''+'~'+''+'~'+''       
IF NOT EXISTS (SELECT 'CHECK' FROM ARC_REC_CANDIDATE AS CA WHERE CA.REC_ID = @Recruitmentid)      
 SET @RESULT = ''+'~'+''+'~'+''   
  
ELSE IF EXISTS (SELECT 'CHECK' FROM ARC_REC_CANDIDATE_STATUS AS CA WHERE CA.REC_ID = @Recruitmentid)      
 SELECT @RESULT = dbo.FN_ARC_REC_WORDCAPS(isnull(CP.FIRSTNAME + ' ' + isnull(CP.LASTNAME,''),'')) + '~' + CONVERT(VARCHAR,CP.CREATED_DT,106) + '~' +      
 CASE WHEN CS.STATUS_ID =0 THEN 'Waiting for interview schedule'      
 WHEN CS.STATUS_ID IN (1,2,3) THEN CASE WHEN CONVERT(VARCHAR,SCH.SC_DATE,106) IS NULL THEN 'Waiting for interview schedule' ELSE  'Interview scheduled on ' + CONVERT(VARCHAR,SCH.SC_DATE,106) END      
 WHEN CS.STATUS_ID = 4 THEN 'Interview completed - Selected'      
 WHEN CS.STATUS_ID IN (5,6,7) THEN 'Interview completed - Hold'      
 WHEN CS.STATUS_ID IN (8,9,10) THEN 'Interview completed - Not selected'    
 END       
 FROM ARC_REC_CANDIDATE_STATUS CS      
 LEFT JOIN ARC_REC_ASSESSMENT_SCHEDULED AS SCH ON SCH.SCHEDULE_ID = CS.SCHEDULE_ID      
 INNER JOIN ARC_REC_CANDIDATE AS CA ON CA.REC_ID = CS.REC_ID      
 INNER JOIN ARC_REC_CANDIATE_PROFILE AS CP ON CP.REC_ID = CS.REC_ID      
 WHERE CS.REC_ID = @Recruitmentid        
ELSE IF EXISTS (SELECT 'CHECK' FROM ARC_REC_APPLICANT_STATUS_FB AS CA WHERE CA.REC_ID = @Recruitmentid)      
 SELECT @RESULT = DBO.FN_ARC_REC_WORDCAPS(ISNULL(JR.REFNAME,JP.NAME))+'~'+CONVERT(VARCHAR,ISNULL(JR.CREATEDON,JP.CREATEDON),106)+'~'+SI.STATUS_TEXT      
 FROM      
 (      
 SELECT REC_ID,CREATED_DT,STATUS_ID FROM ARC_REC_APPLICANT_STATUS_FB       
 WHERE S_ID = (SELECT MAX(S_ID) FROM ARC_REC_APPLICANT_STATUS_FB WHERE REC_ID = @Recruitmentid)      
 ) AS CS       
 LEFT JOIN AHC_JOBREFER JR ON CS.REC_ID  =JR.REFERNO      
 LEFT JOIN AHC_JOBAPPLY AS JP ON CS.REC_ID = JP.APPLYNO         
 INNER JOIN ARC_REC_CANDIDATE_STATUS_INFO AS SI ON SI.STATUS_ID = CS.STATUS_ID      
SELECT ISNULL(@RESULT,''+'~'+''+'~'+'') AS [STATUS]      
   
End        
     

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AHC_Application_Status] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHC_Application_Status] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHC_Application_Status] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AHC_Application_Status] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHC_Application_Status] TO [DB_DMLSupport]
    AS [dbo];

