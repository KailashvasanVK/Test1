﻿CREATE Procedure ARC_REC_ITREQUESTID_GET            
(      
 @Action_Name varchar(50),      
 @RequestId int=0            
)            
As            
/*            
ARC_REC_ITREQUESTID_GET @Action_Name='GETUSER_DETAILS', @RequestId=1
Go        
ARC_REC_ITREQUESTID_GET @Action_Name='GETREQUEST_INFO', @RequestId=1         
        
*/            
Begin            
      
IF @Action_Name='GETUSER_DETAILS'           
Begin       
Select top 1            
RequestId,RequestType=(Case when RequestType=1 Then 'New request' else 'Change request' end),            
RequestFrom=(Case when RequestFrom=1 then 'Client' else 'Internal' end)            
,ui.FIRSTNAME+' '+ui.LASTNAME+' [ EmpCode: ' + isnull(ui.EMPCODE,'') +']' as CreatedBy,            
UI.NT_USERNAME,RequestStatus =(Priority),            
SuperVisorName=(select top 1 FIRSTNAME +' '+ LASTNAME from ARC_REC_USER_INFO ui         
inner join ARC_REC_ITREQUEST ITR on ui.USERID= ITR.Supervisor            
where RequestId=@RequestId)            
from             
ARC_REC_ITREQUEST IT        
inner join ARC_REC_USER_INFO UI on IT.CreatedBy=Ui.USERID            
where RequestId=@RequestId          
End       
IF @Action_Name='GETREQUEST_INFO'       
Begin      
Select top 1 RequestId,RequestType,FunctionId,RequestFrom, Description,Reason,Benifit,      
Supervisor,RequestStatus,CreatedBy      
from ARC_REC_ITREQUEST where RequestId=@RequestId       
End      
            
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ITREQUESTID_GET] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUESTID_GET] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUESTID_GET] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ITREQUESTID_GET] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUESTID_GET] TO [DB_DMLSupport]
    AS [dbo];

