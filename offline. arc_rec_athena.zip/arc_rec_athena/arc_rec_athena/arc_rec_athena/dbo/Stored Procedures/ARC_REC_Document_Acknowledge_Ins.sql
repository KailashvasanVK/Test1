﻿CREATE Proc ARC_REC_Document_Acknowledge_Ins            
@DocId int,            
@Userid int,          
@AckStatus tinyint            
/*            
            
select * from ARC_REC_Document_Acknowledge            
            
ARC_REC_Document_Acknowledge_Ins 1,807            
            
*/            
As            
Begin            
Declare @Ident int            
If not exists(select 'x' from ARC_REC_Document_Acknowledge where AcknowledgeBy=@Userid and Docid=@DocId)            
Begin            
            
insert into ARC_REC_Document_Acknowledge(Docid,AcknowledgeBy,AcknowledgeOn,AckStatus)            
select @DocId,@Userid,GETDATE(),@AckStatus           
            
set @Ident=IDENT_CURRENT('ARC_REC_Document_Acknowledge')            
      
if not exists(select 'x' from RR_SCOREBOARD where Userid=@Userid and ReferenceInfo='ARC_REC_Document_Acknowledge' and ReferenceId =@Ident)           
Begin      
insert into RR_SCOREBOARD(Userid,CID,Points,ReferenceId,ReferenceInfo)                  
select @Userid,CID,Points,@Ident,'ARC_REC_Document_Acknowledge' from RR_CRITERA_MASTER where CID=19 and STATUS=1             
End              
  /*    Mail Part Comment here         */                       
            
End            
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_Document_Acknowledge_Ins] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Document_Acknowledge_Ins] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Document_Acknowledge_Ins] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_Document_Acknowledge_Ins] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Document_Acknowledge_Ins] TO [DB_DMLSupport]
    AS [dbo];

