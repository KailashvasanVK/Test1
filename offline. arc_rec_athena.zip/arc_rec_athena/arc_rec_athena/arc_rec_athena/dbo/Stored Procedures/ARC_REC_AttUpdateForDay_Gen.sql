﻿CREATE Proc ARC_REC_AttUpdateForDay_Gen   
As    
Begin   
  
Declare @AttDate date=(select convert(date,GETDATE()))  
   
Exec ARC_REC_AttUpdateForDeclaredOff @AttDate = @AttDate    
Exec ARC_REC_AttUpdateForCompOffEligible  @AttDate = @AttDate    
/** Update on comp-off days for selfAttendance users **/  
Update ARC_REC_Attendance Set P_days = 0,TotalHrs = 0,WorkHours = 0,LateIn = 0,LateOut = 0  
Where [DATE] = @AttDate and CompOffEligible = 1 and Userid in (select Userid from ARC_REC_ATTENDANCE_ACCESS where ATT_TYPE = 'S')  
and LogOn is not null and isnull(Verified_By,0) = 0 and P_days > 0  
  
Exec ARC_REC_AttUpdateForPresent  @AttDate = @AttDate  
End  
  
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_AttUpdateForDay_Gen] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AttUpdateForDay_Gen] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AttUpdateForDay_Gen] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_AttUpdateForDay_Gen] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AttUpdateForDay_Gen] TO [DB_DMLSupport]
    AS [dbo];

