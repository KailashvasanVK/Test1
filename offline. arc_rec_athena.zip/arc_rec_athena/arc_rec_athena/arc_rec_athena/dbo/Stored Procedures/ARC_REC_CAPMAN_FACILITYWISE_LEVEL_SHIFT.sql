﻿CREATE PROC ARC_REC_CAPMAN_FACILITYWISE_LEVEL_SHIFT
@type VARCHAR(10)=NULL,
@Facility VARCHAR(30)='HQ',
@FacilityLevel VARCHAR(30)='HQ - Level 3'
AS  
Begin  
SELECT *,
[UT%]  =(CASE WHEN TotalCapacity=0 THEN 0 else
CAST((CapacityUtilized*1.0/TotalCapacity) *100 AS NUMERIC(18,2)) end )
FROM (  
SELECT SI.SHIFT_ID,SI.SHIFT_NAME,  
TotalCapacity=(SELECT COUNT(*) FROM dbo.ARC_REC_CAPMAN CM   
WHERE CM.FacilityId=EP.FacilityId and STATUS=1 AND cm.ShiftId=si.SHIFT_ID ),  
CapacityUtilized=(SELECT COUNT(*) FROM dbo.ARC_REC_CAPMAN CM   
WHERE CM.FacilityId=EP.FacilityId and STATUS=1 AND BayStatus=1  AND cm.ShiftId=si.SHIFT_ID ),  
CapacityAvaliable=(SELECT COUNT(*) FROM dbo.ARC_REC_CAPMAN CM   
WHERE CM.FacilityId=EP.FacilityId and STATUS=1 AND BayStatus=0  AND cm.ShiftId=si.SHIFT_ID)  
FROM dbo.Eye_Facility EP  
INNER JOIN ARC_REC_CAPMAN CP ON CP.FacilityId=ep.FacilityId
LEFT JOIN dbo.ARC_REC_SHIFT_INFO SI ON SI.SHIFT_ID=cp.ShiftId
WHERE FacilityName =@Facility AND FacilityName +' - '+ LevelName=@FacilityLevel
GROUP BY ep.FacilityId,SI.SHIFT_ID,SI.SHIFT_NAME
) AS Udhaya   
END  
  
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_FACILITYWISE_LEVEL_SHIFT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_FACILITYWISE_LEVEL_SHIFT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_FACILITYWISE_LEVEL_SHIFT] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_FACILITYWISE_LEVEL_SHIFT] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_FACILITYWISE_LEVEL_SHIFT] TO [DB_DMLSupport]
    AS [dbo];

