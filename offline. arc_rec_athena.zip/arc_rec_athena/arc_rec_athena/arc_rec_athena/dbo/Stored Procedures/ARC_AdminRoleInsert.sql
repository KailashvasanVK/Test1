﻿CREATE Procedure ARC_AdminRoleInsert
@RoleId int
,@RoleName varchar(50)
,@CREATED_BY int
,@FUNCTIONALITY_ID int 
As
/*
Purpose    : To create and edit the user role by Admin
Impact to  : adminRoleCreation.aspx
Created by : Karthik Ic
Created on : 10 Sep 2013
*/
Begin
if isnull( @RoleId ,0) = 0
Begin
If not exists (Select top 1 'x'   from  ARC_REC_Role Where RoleName = @RoleName and  FUNCTIONALITY_ID = @FUNCTIONALITY_ID)
Begin
Insert into ARC_REC_Role (RoleName,FUNCTIONALITY_ID,CREATED_BY)
Select @RoleName,@FUNCTIONALITY_ID,@CREATED_BY from ARC_REC_USER_INFO where userid = @CREATED_BY
set @RoleId = IDENT_CURRENT('ARC_REC_Role')
End
End
else
Begin
print 'update'
If not  exists (Select top 1 'x'   from  ARC_REC_Role  ARR  Where RoleName = @RoleName and RoleId <> @RoleId and  FUNCTIONALITY_ID = @FUNCTIONALITY_ID)
Begin
print 'move'
Insert into ARC_REC_Rolelog (RoleId,RoleName,FUNCTIONALITY_ID,CREATED_BY,CREATED_DT,Status ) -- ,DefaultRole)  <-------- added by karthik @  05 Sep 2013
Select RoleId,RoleName,FUNCTIONALITY_ID,CREATED_BY,CREATED_DT,Status  -- ,DefaultRole <-------- added by karthik @  05 Sep 2013
From ARC_REC_Role Where RoleId = @RoleId
print 'update'
Update ARC_REC_Role  set RoleName = @RoleName,CREATED_BY = @CREATED_BY,CREATED_DT = GETDATE() where RoleId = @RoleId
End
End
End
Select RoleName,RoleId from ARC_REC_Role  where RoleId = @RoleId
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_AdminRoleInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_AdminRoleInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_AdminRoleInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_AdminRoleInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_AdminRoleInsert] TO [DB_DMLSupport]
    AS [dbo];

