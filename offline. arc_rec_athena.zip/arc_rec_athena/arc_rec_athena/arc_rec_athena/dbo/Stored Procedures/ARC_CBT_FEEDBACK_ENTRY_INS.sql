﻿CREATE Procedure ARC_CBT_FEEDBACK_ENTRY_INS    
(    
@INFOID INT,    
@USERID INT,    
@FEEDBACKENTRY as xml     
)    
AS    
/*    
select * from ARC_CBT_FEEDBACK_ENTRY    
SELECT * FROM ARC_CBT_FEEDBACK_MASTER    
    
declare @INFOID int,@USERID int,@FEEDBACKENTRY as xml                                    
  set @INFOID =1                  
  set @USERID=807                       
  select  @FEEDBACKENTRY =                                                   
  '<ROOT>                         
  <FEEDBACK  QNO ="1" ANS="GOOD" ></FEEDBACK>                        
  <FEEDBACK  QNO ="2" ANS="VERYGOOD" ></FEEDBACK>                     
  </ROOT>'                            
                              
exec ARC_CBT_FEEDBACK_ENTRY_INS @INFOID,@USERID,@FEEDBACKENTRY      
    
*/    
BEGIN    
    
SET NOCOUNT ON    
    
CREATE TABLE #FEEDBACK(QNO INT,ANS VARCHAR(50))    
    
DECLARE @HANDLE INT    
EXEC sp_xml_preparedocument @HANDLE OUTPUT, @FEEDBACKENTRY    
INSERT INTO #FEEDBACK(QNO,ANS)    
SELECT * FROM OPENXML (@handle, '/ROOT/FEEDBACK',1)     
WITH (QNO INT,ANS VARCHAR(50))    
EXEC sp_xml_removedocument @HANDLE    
    
--SELECT @INFOID AS 'INFOID',QNO AS 'QUESTION_NO',ANS AS 'ANSWER',@USERID AS 'CREATEDBY',1 AS 'STATUSID' FROM #FEEDBACK    
    
INSERT INTO ARC_CBT_FEEDBACK_ENTRY(INFOID,QUESTION_NO,ANSWER,CREATEDBY,STATUSID)    
SELECT @INFOID AS 'INFOID',QNO AS 'QUESTION_NO',ANS AS 'ANSWER',@USERID AS 'CREATEDBY',1 AS 'STATUSID' FROM #FEEDBACK    
    
DROP TABLE #FEEDBACK    
    
SET NOCOUNT OFF    
    
END    
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_CBT_FEEDBACK_ENTRY_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_CBT_FEEDBACK_ENTRY_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_CBT_FEEDBACK_ENTRY_INS] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_CBT_FEEDBACK_ENTRY_INS] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_CBT_FEEDBACK_ENTRY_INS] TO [DB_DMLSupport]
    AS [dbo];

