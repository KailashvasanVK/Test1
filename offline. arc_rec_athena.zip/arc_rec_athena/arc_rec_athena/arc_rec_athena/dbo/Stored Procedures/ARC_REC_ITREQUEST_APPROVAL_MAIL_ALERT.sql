﻿CREATE Proc ARC_REC_ITREQUEST_APPROVAL_MAIL_ALERT            
@Requestid int=12            
as             
begin            
            
DECLARE @xml VARCHAR(MAX)                                
DECLARE @body VARCHAR(MAX)         
Declare @Name varchar(100),@subject varchar(50)           
        
select @Name=SI.FIRSTNAME +' '+ SI.LASTNAME from ARC_REC_ITREQUEST IR        
inner join ARC_REC_USER_INFO Si on Si.userId=IR.Supervisor          
where  IR.RequestId=@requestid                           
            
SET @xml = CAST((Select  ROW_NUMBER() OVER (ORDER BY AITR.RequestId DESC) AS 'td','' ,                                  
AITR.RequestId AS 'td','' ,(case when RequestType=1 then 'New request' when RequestType=2 then 'Change request' end)            
AS 'td','' ,                                  
FunctionName AS 'td','' ,                                  
Description AS 'td',''  ,Reason AS 'td','' ,Benifit AS 'td','' ,                                  
Priority AS 'td','' ,ApproveStatus AS 'td','' ,ISNULL(SH.SCHEDULENAME,'') AS 'td','' ,                  
UI.FIRSTNAME +' '+ ui.LASTNAME AS 'td','' ,ApprovedComments AS 'td','' ,convert(varchar(20),AITR.CreatedOn,110) AS 'td','' ,              
SI.FIRSTNAME +' '+ SI.LASTNAME AS 'td',''  ,convert(varchar(20),AITR.ApprovedOn,110) AS 'td',''                              
from                                   
ARC_REC_ITREQUEST AITR                           
inner join HR_Functionality HRF on AITR.FunctionId=hrf.FunctionalityId                                  
inner join ARC_REC_USER_INFO ui on ui.userId=AITR.CreatedBy                  
inner join ARC_REC_USER_INFO Si on Si.userId=AITR.Supervisor                   
left join ARC_REC_ITREQUEST_SCHEDULE Sh ON SH.SCHID=AITR.SCHID                               
where  AITR.statusId=1 and AITR.ApprovedBy is not null  and AITR.approvestatus='Approve'            
and AITR.RequestId=@requestid                     
FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))                      
            
select @xml            
            
SET @body ='<html><body>                                
<style type=text/css>                                                                                                                                               
<!-- .tableHeader{  font-family: Calibri(bold); font-size: 12px; font-weight: normal; font-style: normal ;color:#FFF }                                                                                                                       
                                  
.tableTxt{  font-family: Calibri(bold); font-size: 16px; font-weight: normal; font-style: normal  }-->                                
</style>                                 
                               
<table>                                 
<tr><td   class=tableTxt><B>Dear All,</B></td> </tr> </br>                                        
<tr >                                
<td  class=tableTxt>Please find below Change / New request approval details.                      
 <td></tr>                                
<tr><TD></td></tr></table></br>                                 
                                
<table width="100%"  border=-1 align=center cellpadding=0 cellspacing=1 >                                
<tr class=tableHeader bgcolor=#2567aa  align=center color=#FFFFFF><td style="padding:5px"><b>Sl.No</b></font></td>                                 
<td style="padding:5px"><b> RequestId </b></td>            
<td style="padding:5px"><b> RequestType</b> </td>            
<td style="padding:5px"><b> FunctionName</b> </td>            
<td style="padding:5px"><b>Description</b></td>                                
<td style="padding:5px"><b> Reason</b></td>            
<td style="padding:5px"><b>Benefit </b></td>            
<td style="padding:5px"><b>Priority</b></td>                
<td style="padding:5px"><b>ApproveStatus</b></td>            
<td style="padding:5px"><b>Period</b></td>            
<td style="padding:5px"><b>Requested By</b></td>            
           
<td style="padding:5px"><b>ApprovedComments</b></td>            
<td style="padding:5px"><b>Requested On</b></td>            
<td style="padding:5px"><b>Approved By</b></td>            
<td style="padding:5px"><b>Approved On</b></td>            
            
</tr>'         
            
            
                                 
SET @body = @body + @xml +'</table width="100%" ></br>                                
<table>                       
<tr><td>&nbsp;</td> </tr>                              
<tr><td>Warm Regards,</td> </tr>                  
<tr><td>'+@Name+'</td> </tr>                   
<tr><TD></td></tr>                                             
<tr><TD></td></tr>                      
<tr><td>This is a system generated mail. Please do not respond to this mail.</td></tr>                    
<tr><TD></td></tr>                                             
<tr><TD></td></tr>                    
<TR><B>Legal Disclaimer:</B></TR>                    
<tr>The information contained in this message (including all attachments) may be privileged and confidential.                     
It is intended to be read only by the individual or entity to whom it is addressed or by their designee.                     
If the reader of this message is not the intended recipient, please destroy this message immediately and also please note that you are on notice that any distribution of this message, in any form, is strictly prohibited.                    
If you have received this message in error, please immediately notify the sender and delete or destroy any copy of this message!                    
</td></tr>'          
      
select @body      
set @subject=  'IT Change Request Approval of Request - ' + convert(varchar(20),@requestid)       
      
if @body is not null      
Begin                     
                        
EXEC msdb.dbo.sp_send_dbmail                                                                                                                                                                                                               
@profile_name = 'ARC_DBmail',                                                               
@recipients='Mohamedsafiyu.a@accesshealthcare.co;ramakrishnan.go@accesshealthcare.co' ,             
@copy_recipients='Arvind Perumbala<arvind.perumbal@accesshealthcare.co>;udhayaganesh.p@accesshealthcare.co;ganesan.balasub@accesshealthcare.co; aakashnattam.ma@accesshealthcare.co',                 
@subject=@subject,    
@body = @body,                                                               
@body_format  = 'HTML'        
End             
            
End  
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_APPROVAL_MAIL_ALERT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_APPROVAL_MAIL_ALERT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_APPROVAL_MAIL_ALERT] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_APPROVAL_MAIL_ALERT] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_APPROVAL_MAIL_ALERT] TO [DB_DMLSupport]
    AS [dbo];

