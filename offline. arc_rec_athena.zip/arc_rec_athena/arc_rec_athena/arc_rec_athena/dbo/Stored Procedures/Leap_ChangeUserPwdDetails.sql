﻿    
    
CREATE PROCEDURE dbo.Leap_ChangeUserPwdDetails    
  
    
 @UserId INT,    
 @Password varchar(100),    
 @oldPWD varchar(100)    
AS    
BEGIN    
  
 SET NOCOUNT ON;    
    
     
 if exists (select * from mrplogin where  UserId = @UserId and Password = @oldPWD)    
 BEGIN    
  UPDATE      
   mrplogin    
  SET     
   Password = @Password    
  WHERE     
   UserId = @UserId    
 END    
 else     
 BEGIN    
  SELECT 'INVALID'    
 END    
    
END    
    
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Leap_ChangeUserPwdDetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Leap_ChangeUserPwdDetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Leap_ChangeUserPwdDetails] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Leap_ChangeUserPwdDetails] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Leap_ChangeUserPwdDetails] TO [DB_DMLSupport]
    AS [dbo];

