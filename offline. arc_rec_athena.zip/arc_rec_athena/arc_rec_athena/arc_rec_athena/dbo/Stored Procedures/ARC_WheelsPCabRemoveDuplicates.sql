﻿CREATE Proc ARC_WheelsPCabRemoveDuplicates
(
@Action varchar(10)
)
As
Begin
if @Action = 'Pickup'
	Begin
	Delete t from ARC_WheelsCabPickup t Where not exists (select 1 from ARC_REC_USER_INFO where EMPCODE = t.EMPCODE and AHS_PRL = 'Y' and ACTIVE = 1)
	Delete from ARC_WheelsCabPickup Where ISNULL(empcode,'') = ''
	End
else
	Begin
	Delete t from ARC_WheelsCabDrop t Where not exists (select 1 from ARC_REC_USER_INFO where EMPCODE = t.EMPCODE and AHS_PRL = 'Y' and ACTIVE = 1)	
	Delete from ARC_WheelsCabDrop Where ISNULL(empcode,'') = ''
	End
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_WheelsPCabRemoveDuplicates] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_WheelsPCabRemoveDuplicates] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_WheelsPCabRemoveDuplicates] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_WheelsPCabRemoveDuplicates] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_WheelsPCabRemoveDuplicates] TO [DB_DMLSupport]
    AS [dbo];

