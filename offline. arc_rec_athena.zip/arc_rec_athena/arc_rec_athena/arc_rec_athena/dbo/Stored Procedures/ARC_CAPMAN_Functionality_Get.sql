﻿CREATE Proc ARC_CAPMAN_Functionality_Get      
(    
@NTusername varchar(100)=null      
)    
as      
Begin    
select FunctionalityId,JobTitle  from HR_Functionality     
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_CAPMAN_Functionality_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_CAPMAN_Functionality_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_CAPMAN_Functionality_Get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_CAPMAN_Functionality_Get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_CAPMAN_Functionality_Get] TO [DB_DMLSupport]
    AS [dbo];

