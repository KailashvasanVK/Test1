﻿CREATE PROC RR_Associate_Points          
@userid int=807          
/*          
          
Created By : UdhayaGanesh          
          
PurPose    : Get the Associate Points Details          
          
*/          
AS          
Begin          
select ROW_NUMBER() over (order by SB.CreatedOn) 'Slno','Received ' + CM.Feeds Event,CONVERT(varchar(20),SB.CreatedOn,109) Eventdate,SB.points 'sdpoints' 
into #AssociatePoint from RR_SCOREBOARD SB          
inner join RR_Critera_master CM on CM.CID=SB.cid          
where SB.status=1 and SB.Userid=@userid  order by SB.CreatedOn desc         
  
select Slno,Event,CONVERT(varchar(20),Eventdate,109) Eventdate,sdpoints  from (
select * from #AssociatePoint   
union  
select 0,'----------Total Points----------',GETDATE(),SUM(sdpoints) from #AssociatePoint  
) as udh order by slno desc  
  
drop table #AssociatePoint  
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Associate_Points] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Associate_Points] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Associate_Points] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Associate_Points] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Associate_Points] TO [DB_DMLSupport]
    AS [dbo];

