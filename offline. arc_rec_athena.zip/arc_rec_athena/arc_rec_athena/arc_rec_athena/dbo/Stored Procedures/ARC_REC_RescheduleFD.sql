﻿--ARC_REC_RescheduleFD 1406604  
  
CREATE proc ARC_REC_RescheduleFD  
     @REC_ID int  
As  
Begin  
declare @Userid int  
select @Userid = USERID from ARC_REC_USER_INFO where REC_ID = @REC_ID  
  
delete from ARC_REC_UserCustomer where UserId = @Userid  
delete from ARC_REC_SHIFT_TRAN where USERID = @Userid  
delete from ARC_REC_TRANSPORT where USERID = @Userid  

declare @MPRID int
select  @MPRID = MPR_ID from ARC_REC_CLOSED where REC_ID = @REC_ID
  
delete from ARC_REC_CLOSED  where REC_ID = @REC_ID  

declare @MPRDetId int
set @MPRDetId = (select top 1 MPRDetId from HR_MPRClosedetails where MPRId= @MPRID order by CreatedDate desc)
--select @MPRDetId

delete from HR_MPRClosedetails where MPRId= @MPRID and MPRDetId = @MPRDetId
  
delete from ARC_REC_CANDIDATE_DOC_STATUS where REC_ID = @REC_ID  
  
delete from ARC_REC_SALARY_BREAKUP where REC_ID = @REC_ID  
  
update ARC_REC_CANDIDATE_STATUS set  
STATUS_ID = 3,SCHEDULE_ID= 0  
where REC_ID  = @REC_ID  
  
insert into ARC_REC_ASSESSMENT_LOG(REC_ID,ASSESS_MODE,PRESENTATION,COMMUNICATION,INITIATIVE,SELF_CONFIDENCE,ADAPTABILITY,EXP_QUALITY,TECHNICAL_SKILLS,  
SUPERVISORY_SKILLS,GROWTH_POTENTIAL,OTHER_SKILLS,OVERALL_PERFORMANCE,REMARKS,APPLICANT_STATUS,CREATED_BY,CREATED_DT,RESULT,CTC,JOINDATE,JOIN_DAYS,SCHEDULE_ID,  
JOIN_TIME)  
  
select REC_ID,ASSESS_MODE,PRESENTATION,COMMUNICATION,INITIATIVE,SELF_CONFIDENCE,ADAPTABILITY,EXP_QUALITY,TECHNICAL_SKILLS,  
SUPERVISORY_SKILLS,GROWTH_POTENTIAL,OTHER_SKILLS,OVERALL_PERFORMANCE,REMARKS,APPLICANT_STATUS,CREATED_BY,CREATED_DT,RESULT,CTC,JOINDATE,JOIN_DAYS,SCHEDULE_ID,  
JOIN_TIME from ARC_REC_ASSESSMENT where REC_ID = @REC_ID and ASSESS_MODE = 'S'  
  
delete from ARC_REC_ASSESSMENT where REC_ID = @REC_ID and ASSESS_MODE = 'S'  
  
delete from ARC_REC_ASSESSMENT_SCHEDULED where REC_ID = @REC_ID and STATUS_ID = 3  
  
delete from ARC_REC_USER_INFO where REC_ID = @REC_ID  
  
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_RescheduleFD] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_RescheduleFD] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_RescheduleFD] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_RescheduleFD] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_RescheduleFD] TO [DB_DMLSupport]
    AS [dbo];

