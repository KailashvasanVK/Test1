﻿--ARC_REC_AttendanceTrainees 16,'2013-10-07'    
CREATE procedure ARC_REC_AttendanceTrainees          
      @SUPERVISOR_ID INT,        
      @ATT_DATE DATE='',  
      @SearchStr varchar(100) = '',  
   @SearchPattern varchar(4) = '=' /** = or % **/         
As          
BEGIN     
if OBJECT_ID('tempdb..#AttendanceTraineesView') is not null drop table #AttendanceTraineesView  
Create Table #AttendanceTraineesView([CheckAll] varchar(max),EMPCODE varchar(10),NAME varchar(100),CLIENT_NAME varchar(100) ,ATTENDANCE varchar(100),REMARKS varchar(300))   
       
declare @reporting varchar(75)          
select @reporting = NT_USERNAME from ARC_REC_USER_INFO where USERID = @SUPERVISOR_ID    
insert into #AttendanceTraineesView([CheckAll],EMPCODE,NAME,CLIENT_NAME,ATTENDANCE,REMARKS)           
select '<input type="checkbox"  class="CheckAll" id="'+convert(varchar,ui.USERID)+'">' as [CheckAll],        
ui.EMPCODE,ui.FIRSTNAME+' '+ui.LASTNAME AS NAME,cl.CLIENT_NAME,        
case when att.Verified_Present = 'F' then 'Full Present'         
when att.Verified_Present = 'H' then 'Half Present'         
when att.Verified_Present = 'NP' then 'Absent' else '' end as ATTENDANCE, att.Verified_Comments as REMARKS        
from ARC_REC_InductionMaster im    
inner join ARC_REC_USER_INFO ui on ui.USERID = im.UserId        
left join HR_Designation d on ui.DESIGNATION_ID = d.DesigId          
left join ARC_FIN_CLIENT_INFO cl on ui.CLIENT_ID = cl.CLIENT_ID          
left join ARC_REC_Attendance att on ui.USERID = att.Userid and att.[date] = CONVERT(date,@ATT_DATE,101)        
where ui.REPORTING_TO = @reporting and isnull(im.Trainee,'') = 'Y'   
       
Declare @OrderStr varchar(100)         
SET @OrderStr  = ' '   
Exec FilterTable  
@DbName = 'tempdb'  
,@TblName = '#AttendanceTraineesView'  
,@SearchStr = @SearchStr  
,@SearchPattern = @SearchPattern  
,@OrderStr = @OrderStr  
if OBJECT_ID('tempdb..#AttendanceTraineesView') is not null drop table #AttendanceTraineesView      
END    
  
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_AttendanceTrainees] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AttendanceTrainees] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AttendanceTrainees] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_AttendanceTrainees] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AttendanceTrainees] TO [DB_DMLSupport]
    AS [dbo];

