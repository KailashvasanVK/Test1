﻿CREATE Proc S1_AR_OpenPosition        
as        
Begin        
  
create Table #temp  
(  
 [Sl.No] int,  
 Process varchar(50),  
 Position varchar(50),  
 Experience varchar(100),  
 [Skill set required] varchar(max),  
 [No. of openings] int,  
 [Positions pending closure] int,  
 [ARMs raised on] varchar(40),  
 [Expected date of closure] varchar(40),  
 [Minimum salary] varchar(100),  
 [Maximum salary] varchar(100),  
 Priority int    
)  
  
  
insert into #temp         
select convert (varchar(10),ROW_NUMBER() over (order by Designation)) 'Sl.No',          
'AR' 'Process',Designation 'Position',           
CONVERT(varchar(10),expfromyears) + ' to ' +CONVERT(varchar(10),exptoyears) +' Years' 'Experience' ,          
Skillset 'Skill set required',             
TotalPositions 'No. of openings',           
TotalPositions-[Number of position closed] 'Positions pending closure' ,             
convert(varchar(20),[ARMS Date Raised],110) 'ARMs raised on',             
convert(varchar(20),[ARMS Traget date],110) 'Expected date of closure',              
dbo.RupeeFormat_Rounded(SalaryMin) 'Minimum salary',            
dbo.RupeeFormat_Rounded(SalaryMax) 'Maximum salary',  
Priority=1       
            
from ARMS_S1_Status_report WHERE TotalPositions> [Number of position closed]              
AND FunctionName='Operations - Revenue Cycle'     
        
        
   
  
create Table #temp1  
(  
 [Sl.No] int,  
 Process varchar(10),  
 Position varchar(1),  
 Experience varchar(1),  
 [Skill set required] varchar(1),  
 [No. of openings] int,  
 [Positions pending closure] int,  
 [ARMs raised on] varchar(1),  
 [Expected date of closure] varchar(1),  
 [Minimum salary] varchar(1),  
 [Maximum salary] varchar(1),  
 Priority int    
)  
  
insert into #temp1   
select 'Sl.No'='',  
'process'='Total',  
'Position'='',  
'Experience'='',  
'Skillset'='',   
  
'No. of openings'=sum(TotalPositions) ,  
'Positions pending closure'=Sum(TotalPositions-[Number of position closed]),  
 'ARMs raised on'='',  
 'Expected date of closure'='',  
 'Minimum salary'='',  
 'Maximum salary' =''   
,Priority=2   
 from ARMS_S1_Status_report WHERE TotalPositions> [Number of position closed]           
AND FunctionName='Operations - Revenue Cycle'  
  
  
create Table #temp2  
(  
 [Sl.No] varchar(10),  
 Process varchar(50),  
 Position varchar(50),  
 Experience varchar(100),  
 [Skill set required] varchar(max),  
 [No. of openings] int,  
 [Positions pending closure] int,  
 [ARMs raised on] varchar(40),  
 [Expected date of closure] varchar(40),  
 [Minimum salary] varchar(100),  
 [Maximum salary] varchar(100),  
 Priority int    
)  
  
  
insert into #temp2 select * from #temp union select * from  #temp1 order by 12 asc    
  
select (case when [Sl.No]=0 then CONVERT(varchar,' ') else [Sl.No] end) as [SI.No],Process,Position,Experience,[Skill set required],[No. of openings],[Positions pending closure],  
[ARMs raised on],[Expected date of closure],[Minimum salary],[Maximum salary]  
  
 from #temp2   
  
  
  
drop table #temp,#temp1,#temp2  
  
end
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[S1_AR_OpenPosition] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[S1_AR_OpenPosition] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[S1_AR_OpenPosition] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[S1_AR_OpenPosition] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[S1_AR_OpenPosition] TO [DB_DMLSupport]
    AS [dbo];

