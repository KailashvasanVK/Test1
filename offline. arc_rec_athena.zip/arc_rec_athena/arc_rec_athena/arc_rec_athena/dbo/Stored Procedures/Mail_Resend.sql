﻿CREATE proc Mail_Resend    
@msgid int=0    
/*    Mail_Resend 107              */  
  
as    
begin    
declare @headline VARCHAR(100),@ContentWithOutImage varchar(max),  
@filepath varchar(100)='\\172.19.5.3\ARC_forum\Attachement\' ,@extenstion varchar(10)               
                                
    
select @headline=headline,@ContentWithOutImage=ContentWithOutImage,@extenstion=  
Extension  from ARC_Forum_MessageBoard where msgid =@msgid   
  
  
  
set @filepath=@filepath+CONVERT(varchar(10),@msgid )+@Extenstion              
                                 
if  exists (select top 1 'x' from ARC_Forum_MessageBoard where msgid=@msgid  )                      
Begin                             
/* IF Artical has Publised Mail Will trigger */              
            
IF @Extenstion <>''          
BEGIN                          
EXEC msdb.dbo.sp_send_dbmail                                                                                                                                
@profile_name = 'Newsdesk',                                                                                                                                              
@recipients = 'all@accesshealthcare.co',                      
--@recipients = 'udhayaganesh.p@laurusedutech.com',                      
@blind_copy_recipients ='udhayaganesh.p@laurusedutech.com',                                                                                                                      
@subject=@Headline,                                                                                                                                                                                            
@body = @ContentWithOutImage,                                                                        
@body_format  = 'HTML',      
@file_attachments =@filepath                              
                       
                      
update ARC_Forum_MessageBoard set mailstatus=1  WHERE MsgId=@msgid                
END            
ELSE            
BEGIN            
EXEC msdb.dbo.sp_send_dbmail                                                                                                                                
@profile_name = 'Newsdesk',                                                                                                                                              
@recipients = 'all@accesshealthcare.co',                      
--@recipients = 'udhayaganesh.p@laurusedutech.com',                      
@blind_copy_recipients ='udhayaganesh.p@laurusedutech.com',                                                                                                                      
@subject=@Headline,                                                                   
@body = @ContentWithOutImage,                                                   
@body_format  = 'HTML'              
            
update ARC_Forum_MessageBoard set mailstatus=1  WHERE MsgId=@msgid                
               
                 
END                 
    
    
--EXEC msdb.dbo.sp_send_dbmail                                                                                                                    
--@profile_name = 'Newsdesk',                                                                                                                                  
--@recipients = 'all@accesshealthcare.co',          
----@recipients = 'udhayaganesh.p@laurusedutech.com',          
--@blind_copy_recipients ='udhayaganesh.p@laurusedutech.com',                                                                                                          
--@subject=@Headline,                                                                                                                                                                                
--@body = @ContentWithOutImage,                                                            
--@body_format  = 'HTML'      
    
End  
end
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Mail_Resend] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Mail_Resend] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Mail_Resend] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Mail_Resend] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Mail_Resend] TO [DB_DMLSupport]
    AS [dbo];

