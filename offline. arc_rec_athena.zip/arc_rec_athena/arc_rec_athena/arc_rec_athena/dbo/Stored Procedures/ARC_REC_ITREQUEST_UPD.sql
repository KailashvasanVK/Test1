﻿CREATE PROCEDURE ARC_REC_ITREQUEST_UPD            
(               
@RequestID int,               
@RequestType tinyint,                  
@FunctionalityId int,                  
@RequestFrom tinyint,                  
@RequestDescriptin varchar(max),                  
@RequestReason varchar(max),                  
@RequestBenifit varchar(max),                  
@Supervisor int,                  
@RequestStatus int=1,                  
@CreatedBy INT,                  
@Attach_Filename varchar(500),       
@Request_Id int output,      
@AttachementId varchar(50) output                  
)                  
As                  
/*                  
                  
Create by  : seena.A                  
Created on : Nov 07 2013                  
                  
DECLARE @CID INT                  
Exec ARC_REC_ITREQUEST_INS @RequestType=1,@FunctionalityId=1,@RequestFrom=1,@RequestDescriptin='TEST',                  
@RequestReason='TEST',@RequestBenifit='TEST',@Supervisor=1,@RequestStatus='OPEND',@CreatedBy='1'                  
,@Attach_Filename='AnalyticsSDSD.png',@AttachementId=@CID output                  
                  
DECLARE @CID INT                  
Exec ARC_REC_ITREQUEST_INS @RequestType=1,@FunctionalityId=1,@RequestFrom=1,@RequestDescriptin='TEST',                  
@RequestReason='TEST',@RequestBenifit='TEST',@Supervisor=1,@RequestStatus='OPEND',@CreatedBy='1'                  
,@Attach_Filename='',@AttachementId=@CID output                  
                  
select * from arc_rec_ITrequest                  
select * from arc_rec_itrequest_attachment            
select * from ARC_REC_ITREQUEST_HISTORY                    
                  
truncate table ARC_REC_ITREQUEST                  
truncate table ARC_REC_ITREQUEST_ATTACHMENT            
truncate table ARC_REC_ITREQUEST_HISTORY                    
                  
                  
*/                  
Begin             
            
IF @RequestID > 0            
            
Begin            
    
if exists(select 'x' from ARC_REC_ITREQUEST where requestid=@RequestID and RequestStatus<>1 AND ISNULL(ApproveStatus,'DISApprove') ='DISApprove'  )    
Begin    
 Insert into ARC_REC_ITREQUEST_HISTORY             
 (RequestId,RequestType,FunctionId,RequestFrom,Description,Reason,Benifit,Supervisor,RequestStatus,            
 CreatedBy,CreatedOn,StatusId,ApprovedComments,Priority,ApproveStatus,ApprovedBy,ApprovedOn,            
 HistoryOn)      
            
 Select             
 RequestId,RequestType,FunctionId,RequestFrom,Description,Reason,Benifit,Supervisor,RequestStatus,            
 CreatedBy,CreatedOn,StatusId,ApprovedComments,Priority,ApproveStatus,ApprovedBy,ApprovedOn,GETDATE() from             
 ARC_REC_ITREQUEST where RequestId =@RequestID            
            
 UPDATE ARC_REC_ITREQUEST SET RequestType=@RequestType,RequestFrom=@RequestFrom,            
 Description=@RequestDescriptin,Reason=@RequestReason,Benifit=@RequestBenifit,Supervisor=@Supervisor,            
 CreatedBy=@CreatedBy,ApprovedComments='',Priority='', ApproveStatus='',ApprovedBy='',  
 RequestStatus=1 where RequestId=@RequestID  
       
End    
else IF exists(select 'x' from ARC_REC_ITREQUEST where requestid=@RequestID and RequestStatus=1 AND ApprovedBy IS NULL )    
begin    
    
 UPDATE ARC_REC_ITREQUEST SET RequestType=@RequestType,RequestFrom=@RequestFrom,            
 Description=@RequestDescriptin,Reason=@RequestReason,Benifit=@RequestBenifit,Supervisor=@Supervisor,            
 CreatedBy=@CreatedBy,ApprovedComments='',Priority='', ApproveStatus='', RequestStatus=1 where RequestId=@RequestID     
    
end            
                   
 IF @Attach_Filename <>''                  
 BEGIN             
 INSERT INTO ARC_REC_ITREQUEST_ATTACHMENT(AFileName,Requestid,CreatedBy,StatusId)                  
 VALUES (CONVERT(VARCHAR,@REQUESTID) + '_' + CONVERT(varchar,IDENT_CURRENT('ARC_REC_ITREQUEST_ATTACHMENT')) +'_' + @Attach_Filename,@REQUESTID,@CreatedBy,1)                        
End        
      
 SELECT @Request_Id=@RequestID,      
 @AttachementId= CONVERT(VARCHAR,@REQUESTID) + '_' + CONVERT(varchar,IDENT_CURRENT('ARC_REC_ITREQUEST_ATTACHMENT'))          
                  
END                  
                  
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_UPD] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_UPD] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_UPD] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_UPD] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_UPD] TO [DB_DMLSupport]
    AS [dbo];

