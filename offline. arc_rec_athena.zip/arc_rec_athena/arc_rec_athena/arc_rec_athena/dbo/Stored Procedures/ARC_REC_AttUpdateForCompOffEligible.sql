﻿CREATE Proc ARC_REC_AttUpdateForCompOffEligible  
(  
@AttDate date = null  
)  
As  
Begin  
/**  
Created By : Mohamed Safiyullah  
Purpose : To mark CompOffEligible at the time of attendance generation  
**/  
if @AttDate is null and SYSTEM_USER = 'ACCESSHEALTHCAR\mohamedsafiyu.a'  
 Begin   
 /** Need to mark for all days **/  
 Update ARC_REC_Attendance Set CompOffEligible = 1  
 From ARC_REC_Attendance as Att  
 inner join  
 (  
 SELECT ATT.Date,ATT.Shiftid,ATT.Userid  
 ,CASE WHEN DATENAME(WEEKDAY,ATT.Date) = 'Sunday' then NULL  
 WHEN UI.FUNCTIONALITY_ID = 3 AND DATENAME(WEEKDAY,ATT.Date) = 'Saturday' THEN null  
 WHEN UI.FUNCTIONALITY_ID = 16 AND DATENAME(WEEKDAY,ATT.Date) = 'Saturday' THEN null  -- Operations – Clinical requestId-92 
 WHEN DATENAME(WEEKDAY,ATT.Date) = 'Saturday' AND ISNULL(SI.HOLIDAY_SAT,'Y') = 'Y' THEN ATT.DATE  
 WHEN HL.HOLIDAY_DATE IS NOT NULL THEN HL.HOLIDAY_DATE     
 ELSE NULL END AS HOLIDAY   
 FROM arc_rec_attendance AS ATT  (nolock)      
 INNER JOIN ARC_REC_USER_INFO AS UI (NOLOCK) ON UI.USERID = ATT.Userid    
 INNER JOIN ARC_REC_SHIFT_INFO AS SI ON SI.SHIFT_ID = ATT.Shiftid  
 LEFT JOIN ARC_REC_LEAVE_HOLIDAYLIST AS HL  (nolock) ON HL.HOLIDAY_DATE = ATT.Date  
    AND      
    ((HL.HOLIDAY_DESCRIPTION <> 'Saturday' AND  HL.LISTTYPE = case when att.Functionalityid = 3 then 1 else SI.HOLIDAY_LISTTYPE end)     
    OR     
    (HL.HOLIDAY_DESCRIPTION = 'Saturday'))     
 WHERE ATT.Date > '2012-12-31'  
  
 )X  on X.HOLIDAY IS NOT NULL and Att.Date = x.Date and Att.Userid = x.Userid      
 WHERE ATT.Date > '2012-12-31'  
 End  
Else if @AttDate is not null  
 Begin  
 Update ARC_REC_Attendance Set CompOffEligible = 1  
 From ARC_REC_Attendance as Att  
 inner join  
 (  
 SELECT ATT.Date,ATT.Shiftid,ATT.Userid  
 ,CASE WHEN DATENAME(WEEKDAY,ATT.Date) = 'Sunday' then NULL  
 WHEN UI.FUNCTIONALITY_ID = 3 AND DATENAME(WEEKDAY,ATT.Date) = 'Saturday' THEN null  
 WHEN UI.FUNCTIONALITY_ID = 16 AND DATENAME(WEEKDAY,ATT.Date) = 'Saturday' THEN null  -- Operations – Clinical requestId-92 
 WHEN DATENAME(WEEKDAY,ATT.Date) = 'Saturday' AND ISNULL(SI.HOLIDAY_SAT,'Y') = 'Y' THEN ATT.DATE  
 WHEN HL.HOLIDAY_DATE IS NOT NULL THEN HL.HOLIDAY_DATE     
 ELSE NULL END AS HOLIDAY   
 FROM arc_rec_attendance AS ATT  (nolock)      
 INNER JOIN ARC_REC_USER_INFO AS UI (NOLOCK) ON UI.USERID = ATT.Userid    
 INNER JOIN ARC_REC_SHIFT_INFO AS SI ON SI.SHIFT_ID = ATT.Shiftid  
 LEFT JOIN ARC_REC_LEAVE_HOLIDAYLIST AS HL  (nolock) ON HL.HOLIDAY_DATE = ATT.Date  
    AND      
    ((HL.HOLIDAY_DESCRIPTION <> 'Saturday' AND  HL.LISTTYPE = case when att.Functionalityid = 3 then 1 else SI.HOLIDAY_LISTTYPE end)     
    OR     
    (HL.HOLIDAY_DESCRIPTION = 'Saturday'))     
 WHERE Att.Date = @AttDate and ATT.Date > '2012-12-31'  
  
 )X  on X.HOLIDAY IS NOT NULL and Att.Date = x.Date and Att.Userid = x.Userid      
 Where Att.Date = @AttDate  
 End  
End  
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_AttUpdateForCompOffEligible] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AttUpdateForCompOffEligible] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AttUpdateForCompOffEligible] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_AttUpdateForCompOffEligible] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AttUpdateForCompOffEligible] TO [DB_DMLSupport]
    AS [dbo];

