﻿CREATE procedure [dbo].[HD_Athena_UpdUserName]        
      @ReqId int        
      ,@UserId int      
      ,@AthenaUserName varchar(300)      
      ,@CitrixUserName varchar(300)        
      ,@CitrixReqId varchar(50)  
      ,@HasCitrix char(1)      
      ,@UpdatedBy int    
      ,@Comments varchar(2000)  
             
As        
begin          
if @HasCitrix = 'Y' and @CitrixUserName <> ''      
  begin      
Update HD_AthenaUsers set        
AthenaUserName = @AthenaUserName,AthenaUNUpdatedBy = @UpdatedBy,AthenaUNUpdDt = GETDATE(),      
CitrixUserName = @CitrixUserName,CitrixUNUpdatedBy = @UpdatedBy,CitrixUNUpdatedDt = GETDATE(),Comments = @Comments, 
[Status] = 3, -- processed status  
CitrixReqId = @CitrixReqId  
where Issue_ReqId = @ReqId  and UserId = @UserId       
end      
else if @HasCitrix = 'Y' and @CitrixUserName = ''      
begin      
Update HD_AthenaUsers set        
AthenaUserName = @AthenaUserName,AthenaUNUpdatedBy = @UpdatedBy,AthenaUNUpdDt = GETDATE(),Comments = @Comments
where Issue_ReqId = @ReqId  and UserId = @UserId       
end      
else      
begin      
Update HD_AthenaUsers set        
AthenaUserName = @AthenaUserName,AthenaUNUpdatedBy = @UpdatedBy,AthenaUNUpdDt = GETDATE(),Comments = @Comments,
[Status] = 3 -- processed status       
where Issue_ReqId = @ReqId  and UserId = @UserId       
end      
end 


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_UpdUserName] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_UpdUserName] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_UpdUserName] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_UpdUserName] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_UpdUserName] TO [DB_DMLSupport]
    AS [dbo];

