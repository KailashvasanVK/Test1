﻿ --ARC_Me_RequestedLeavesStatus 7    
 CREATE procedure ARC_Me_RequestedLeavesStatus    
        @UserId int,    
        @SearchStr varchar(100) = '',                   
        @SearchPattern varchar(4) = '=' /** = or % **/      
 AS    
 begin    
 Declare @OrderStr varchar(100)        
           declare @CurDate as date      
 declare @Pay_MaxDate as date      
 select @CurDate = convert(date ,GETDATE())      
 select @Pay_MaxDate = MAX(PAY_ROLL_DATE) from ARC_ME_PAYROLL   
 
  SELECT  CASE WHEN (LR.LEAVE_STATUS = 0) and ((@CurDate <= CONVERT(date ,LR.FROMDATE) and @CurDate <= CONVERT(date ,LR.TODATE)) or (@Pay_MaxDate <= CONVERT(date ,LR.FROMDATE) and @Pay_MaxDate <= CONVERT(date ,LR.TODATE))) Then  
 '<button onclick="return LeaveDeactivate(''' + convert(varchar,ISNULL(LR.LEAVE_REQID,0)) + ''',''' + LT.TYPE_TEXT + ''');"  class=  "Action ui-button ui-widget ui-state-default ui-    corner-all ui-button-icon-only" id="btnDeactivation" role=      
" button" aria-disabled="false" title="Leave Deactivation">                 
  <span class="ui-button-icon-primary ui-icon ui-icon-pencil"></span>                 
  <span class="ui-button-text">&nbsp;</span></button>' ELSE 'N/A' END as [ACTION] ,
 CONVERT(VARCHAR(11),LR.CREATED_DT,113) [APPLIED ON],LT.TYPE_TEXT AS [LEAVE TYPE]                       
 ,CASE WHEN LR.TYPEID = 5 THEN CONVERT(VARCHAR(11),LR.FROMDATE,113) + SUBSTRING(CONVERT(VARCHAR,LR.FROMDATE,100),12,10) ELSE CONVERT(VARCHAR(11),LR.FROMDATE,113) END AS FROMDATE                                    
 ,CASE WHEN LR.TYPEID = 5 THEN CONVERT(VARCHAR(11),LR.TODATE,113) + SUBSTRING(CONVERT(VARCHAR,LR.TODATE,100),12,10) ELSE CONVERT(VARCHAR(11),LR.TODATE,113) END AS TODATE                                    
 ,LR.LEAVE_DAYS AS LEAVES                                    
 ,LR.REASON                                    
 ,APP.FIRSTNAME + ' ' + APP.LASTNAME AS APPLIED_TO                                    
 ,CASE LEAVE_STATUS WHEN 0 THEN 'Waiting For Approval' + CASE WHEN APPLIED_TO <> FORWARD_TO THEN ' Forwarded to ' + FOW.FIRSTNAME + ' ' + FOW.LASTNAME ELSE '' END                                    
 WHEN 1 THEN 'Approved' + CASE WHEN APPLIED_TO <> FORWARD_TO THEN ' by ' + FOW.FIRSTNAME + ' ' + FOW.LASTNAME ELSE '' END                                    
 WHEN 2 THEN 'Rejected' + CASE WHEN APPLIED_TO <> FORWARD_TO THEN ' by ' + FOW.FIRSTNAME + ' ' + FOW.LASTNAME ELSE '' END                                    
 WHEN 3 THEN 'Forward To ' + FOW.FIRSTNAME + ' ' + FOW.LASTNAME                                    
 END [STATUS]                                    
 ,LR.RESPONSE_REMARK AS COMMENTS into #LeaveRequestView                                    
 FROM ARC_REC_LEAVE_REQUEST AS LR                                    
 INNER JOIN ARC_REC_LEAVE_TYPES AS LT ON LT.TYPEID = LR.TYPEID                                    
 INNER JOIN ARC_REC_USER_INFO AS APP ON APP.USERID = LR.APPLIED_TO                                   
 INNER JOIN ARC_REC_USER_INFO AS FOW ON FOW.USERID = LR.FORWARD_TO                                    
 WHERE LR.CREATED_BY = @UserId   and LR.ACTIVE = 'Y'                                   
 order by LR.CREATED_DT DESC       
     
                          
SET @OrderStr  = ''                              
Exec FilterTable                    
@DbName = 'tempdb'                    
,@TblName = '#LeaveRequestView'                    
,@SearchStr = @SearchStr                    
,@SearchPattern = @SearchPattern                    
,@OrderStr = @OrderStr                    
if OBJECT_ID('tempdb..#LeaveRequestView') is not null drop table #LeaveRequestView     
    
 End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Me_RequestedLeavesStatus] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Me_RequestedLeavesStatus] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Me_RequestedLeavesStatus] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Me_RequestedLeavesStatus] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Me_RequestedLeavesStatus] TO [DB_DMLSupport]
    AS [dbo];

