﻿CREATE PROCEDURE ARC_Lounge_Messages_Insert                
(                
@msgContent varchar(500),                
@createdby VARCHAR(75))                 
/*                
exec ARC_Lounge_Messages_Insert @msgContent=N'123123123vsdf1',@createdby=N'Administrator '                
exec ARC_Lounge_Messages_Insert @msgContent=N'342423423423erter12123cvxcveertwe',@createdby=N'Administrator '              
  
ARC_Lounge_Messages_Insert 'Happy Birthday','Udhayaganesh.p'      
  
*/                
AS                          
BEGIN          
 Declare @id int                 
 if not exists (select 'x' from ARC_Forum_Lounge_Messages where convert(date,CreatedOn)=convert(date,GETDATE())                  
 and MsgContent =@msgContent and  CreatedBy=@createdby and Status=1  )                            
 Begin       
  if @MsgContent not like '%happy birthday%' and  @MsgContent not like '%Many More Happy returns of the day%'    
   Begin                 
   INSERT INTO ARC_Forum_Lounge_Messages(MsgContent,CreatedBy,CreatedOn)                           
   VALUES (@msgContent,@createdby,GETDATE())          
   set @id=IDENT_CURRENT('ARC_Forum_Lounge_Messages')             
   --update ARC_Forum_Lounge_Messages set Priority =0,CreatedOn=GETDATE() where ID=4695         
   /*   R and R Purpose */        
   if  exists (select COUNT(CreatedBy) from ARC_Forum_Lounge_Messages where                
   CreatedBy=@createdby and CONVERT(date,CreatedOn)=CONVERT(date,getdate()) group by CreatedBy having COUNT(*)<2  )                
   Begin                
    insert into RR_SCOREBOARD(Userid,CID,Points,Status,CreatedOn,ReferenceInfo,ReferenceId)                
    select ui.USERID,cm.CID,cm.POINTS,1,GETDATE(),'ARC_Forum_Lounge_Messages',@id from RR_CRITERA_MASTER CM                
    inner join ARC_REC_USER_INFO_VY  UI on ui.NT_USERNAME=@createdby                
    where CID=16 and ui.NT_USERNAME=@createdby               
   End   
   Select 1 As 'OP'   
    End       
   Else     
   begin    
    insert into ARC_Forum_Lounge_Message_Comments    
    select top 1 id,1,@createdby,GETDATE(),@msgContent,null,null from ARC_Forum_Lounge_Messages where Priority=1 and MsgContent like '%Dear%'    
    Select 1 As 'OP'       
   end                  
  End   /* Second IF */                
 Else                  
  Begin                  
  Select 0 As 'OP'                    
  End                     
 END -- /* First IF */  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Messages_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Messages_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Messages_Insert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Messages_Insert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Messages_Insert] TO [DB_DMLSupport]
    AS [dbo];

