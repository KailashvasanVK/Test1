﻿CREATE PROCEDURE  [dbo].[HR_DynamicReports_Get](@Userid int=null)          
as        
/*                
########################################################################                
Created By     :   Ramji D          
Created Date   :   18/12/2008          
Description    :   Get the ReportName and ReportSP from HR_DynamicReports           
                
########################################################################               
sample:HR_DynamicReports_Get                
*/                       
begin            
            
SELECT '--Select--' as ReportName, '0' as SPNAME            
union all            
SELECT ReportName, ReportSP + '|' + isnull(Remarks,'') + '|' + isnull(Selection,'') FROM dbo.HR_DynamicReports where status = 1                      
end 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_DynamicReports_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_DynamicReports_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_DynamicReports_Get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_DynamicReports_Get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_DynamicReports_Get] TO [DB_DMLSupport]
    AS [dbo];

