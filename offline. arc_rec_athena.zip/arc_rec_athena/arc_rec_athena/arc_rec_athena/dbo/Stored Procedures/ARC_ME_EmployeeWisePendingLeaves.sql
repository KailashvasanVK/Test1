﻿CREATE Procedure ARC_ME_EmployeeWisePendingLeaves
(
@Functionality int = 0 /** Optional **/
,@ClientId int = 0 /** Optional **/
,@SupervisorId int = 0 /** Optional **/
,@UserId int = 0 /** Optional **/
,@Active int = 1 /** Mandatory **/
,@Month int = 1 /** Mandatory **/
,@Year int = 2014 /** Mandatory **/
,@SearchStr varchar(100) = ''  
,@SearchPattern varchar(4) = '=' /** = or % **/ 
)
As
Begin

--Declare @Functionality int = 0 /** Optional **/
--Declare @ClientId int = 0 /** Optional **/
--Declare @SupervisorId int = 1 /** Optional **/
--Declare @UserId int = 0 /** Optional **/
--Declare @Active int = 1 /** Mandatory **/
--Declare @Month int = 1 /** Mandatory **/
--Declare @Year int = 2014 /** Mandatory **/


Declare @RptLastDate date = DateAdd(DD,-1,dateadd(mm,1, Convert(date,Convert(varchar,@Year) + '-' + Convert(varchar,@Month) + '-01')))
Declare @Qry varchar(max)
if isnull(@Active,0) = 0 Set @Active = 1
if OBJECT_ID('tempdb..#users') is not null drop table #users
Create Table #users (UserId int)
Set @Qry = '
Insert into #Users(UserId)
Select UserId from ARC_REC_USER_INFO
Where AHS_PRL = ''Y'' and Active = '+CONVERT(varchar,@Active)+'
'
if @Active = 2 Set @Qry += ' And UserId in (Select UserId from ARC_REC_AssociateDOLView Where DOL <= '''+CONVERT(varchar,@RptLastDate)+''')'
if ISNULL(@UserId,0) <> 0 Set @Qry += ' And UserId = '+CONVERT(varchar,@UserId)
if isnull(@Functionality,0) <> 0 Set @Qry += ' And Functionality_Id = '+CONVERT(varchar,@Functionality)
if isnull(@ClientId,0) <> 0 Set @Qry += ' And Client_Id = '+CONVERT(varchar,@ClientId)
if isnull(@SupervisorId,0) <> 0 Set @Qry += ' And Reporting_To = (Select NT_UserName from arc_Rec_user_info where userid = '+CONVERT(varchar,@SupervisorId)+ ')'
print (@Qry)
Exec (@Qry)
if OBJECT_ID('tempdb..#usersPendigLeaves') is not null drop table #usersPendigLeaves
Create table #usersPendigLeaves(UserId int,TypeId int,Short_Text varchar(20),Availed Decimal(9,2),Leaves Decimal(9,2))
Declare @curUserId int
Declare Cur Cursor for select UserId from #users
open cur
while 1=1
	begin
	fetch next from cur into @curUserId
	if @@FETCH_STATUS = -1 break
	Insert into #usersPendigLeaves(UserId,TypeId,Short_Text,Availed,Leaves)
	Exec ARC_ME_PendingLeaves	
	@UserId = @curUserId
	,@Month = @Month
	,@Year = @Year	
	,@RptType = 'PendingLeavesWithLastAvailed'
	end
close cur
deallocate cur

if OBJECT_ID('tempdb..#PendingLeaveWithAvailedResult') is not null drop table #PendingLeaveWithAvailedResult
	Create Table #PendingLeaveWithAvailedResult([UserId~Hide] int,[EmpCode] varchar(20),[Name] varchar(200),Functionality varchar(75),Designation varchar(75),Client varchar(100))
	Insert into #PendingLeaveWithAvailedResult([UserId~Hide],EmpCode,[Name],Functionality,Designation,Client) 
	Select us.UserId,ui.EMPCODE,dbo.ConcatenateName(ui.FirstName,ui.MiddleName,ui.LastName) as [Name], func.FunctionName,desig.Designation,ci.Client_Name from #users as us 
	inner join ARC_REC_USER_INFO as ui on ui.USERID = us.UserId
	left join HR_Functionality as func on func.FunctionalityId = ui.FUNCTIONALITY_ID
	left join HR_Designation as desig on desig.DesigId = ui.DESIGNATION_ID
	left join ARC_FIN_CLIENT_INFO as ci on ci.Client_Id = ui.CLIENT_ID
	Declare @tShort_Text varchar(10)
	Declare @tUserId int
	Declare curPendingLeaves Cursor for Select Short_Text from #usersPendigLeaves Group by Short_Text 
	Open curPendingLeaves
	While 1=1
		Begin
		Fetch next from curPendingLeaves into @tShort_Text
		if @@FETCH_STATUS = -1 break
		Set @Qry = ' Alter Table #PendingLeaveWithAvailedResult Add [' + @tShort_Text + ' Availed] Decimal(9,2)
				     Alter Table #PendingLeaveWithAvailedResult Add [' + @tShort_Text + ' Closing] Decimal(9,2)				   
				     '				     
		Exec (@Qry)
		Set @Qry = ' Update #PendingLeaveWithAvailedResult Set [' + @tShort_Text + ' Availed] = (Select Availed from #usersPendigLeaves Where UserId = PR.[UserId~Hide] and SHORT_TEXT = '''+@tShort_Text+''')
		from #PendingLeaveWithAvailedResult as PR
		Update #PendingLeaveWithAvailedResult Set [' + @tShort_Text + ' Closing] = (Select Leaves from #usersPendigLeaves Where UserId = PR.[UserId~Hide] and SHORT_TEXT = '''+@tShort_Text+''')
		from #PendingLeaveWithAvailedResult as PR
		'
		Exec (@Qry)
		End
	Close curPendingLeaves
	DeAllocate curPendingLeaves	
 --Select * from #PendingLeaveWithAvailedResult
Exec FilterTable 
@DbName = 'tempdb',
@TblName = '#PendingLeaveWithAvailedResult',
@SearchStr = @SearchStr ,
@SearchPattern =  @SearchPattern ,
@OrderStr = ''
if OBJECT_ID('tempdb..#PendingLeaveWithAvailedResult') is not null drop table #PendingLeaveWithAvailedResult
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_EmployeeWisePendingLeaves] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_EmployeeWisePendingLeaves] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_EmployeeWisePendingLeaves] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_EmployeeWisePendingLeaves] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_EmployeeWisePendingLeaves] TO [DB_DMLSupport]
    AS [dbo];

