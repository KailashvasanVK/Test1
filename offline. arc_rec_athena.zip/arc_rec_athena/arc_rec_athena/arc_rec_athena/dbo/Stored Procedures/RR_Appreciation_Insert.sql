﻿CREATE PROCEDURE [dbo].[RR_Appreciation_Insert]                                                                  
 @UserId int                                                        
,@Awardid int                                
,@comments varchar(1000)                                                        
,@AppDetails as xml                                                          
AS                                                        
                                                      
/*                                                          
Created By : Kar                                                     
Created on : 29 dec 2009                                                      
Description: This SP is used to insert the course chapter details                                                      
sample     : Leap_CourseSyllabus_Insert 3,302,'chapter','Description','10','Remarks'                          
                          
declare @Awardid int,@userId int,@comments varchar(1000),@AppDetails as xml                                        
  set @Awardid =1                                 
  set @comments='this is test'                                        
  set @userId=807                           
  select  @AppDetails =                                                       
  '<ROOT>                             
  <appform  users ="arvind.perumbal" ></appform>                            
        <appform  users ="udhayaganesh.p" ></appform>                         
                                           
           </ROOT>'                                
                                  
  exec RR_Appreciation_Insert @userId,@Awardid ,@comments,@AppDetails                              
                            
                            
                            
  select * from RR_Appreciation AP                            
inner Join RR_Appreciation_Users AU on Au.AppId=ap.AppId                            
where ap.CreatedBy=3 and DATEPART(MONTH,ap.CreatedOn)=DATEPART(MONTH,ap.CreatedOn)                            
and DATEPART(YEAR,ap.CreatedOn)=DATEPART(YEAR,ap.CreatedOn) and ap.Awardid=7           
          
  select * from RR_Appreciation AP                            
inner Join RR_Appreciation_Users AU on Au.AppId=ap.AppId where au.nt_username='leoprabhu.rayap'        
      
declare @p4 xml      
set @p4=convert(xml,N'<ROOT><appform users="mohamed.ahmedmo"/></ROOT>')      
exec RR_Appreciation_Insert @UserId=807,@Awardid=33,@comments=N'test',@AppDetails=@p4                               
                                              
                                
                                                 
*/                                                      
BEGIN                                                            
                                    
  Declare @AppId int,@handle INT,@points int ,@Tomailid varchar(100)    
                            
  select @points = points from RR_CRITERA_MASTER where CID=@Awardid           
                                              
  create table #tblAppreciation(Users varchar(max))           
                                                                         
  EXEC sp_xml_preparedocument @handle OUTPUT, @AppDetails                                                                                        
  INSERT INTO #tblAppreciation(Users)                                                                                        
  SELECT * FROM OPENXML (@handle, '/ROOT/appform',1)                                                                                        
  WITH (users varchar(Max))                                                                                  
  EXEC sp_xml_removedocument @handle                                  
                              
--Peer Award--                           
if @Awardid=7                          
begin                            
 if not exists(select 'x' from RR_Appreciation AP        
 inner Join RR_Appreciation_Users AU on Au.AppId=ap.AppId                            
 where ap.CreatedBy=@UserId and DATEPART(MONTH,ap.CreatedOn)=DATEPART(MONTH,GETDATE())                            
 and DATEPART(YEAR,ap.CreatedOn)=DATEPART(YEAR,getdate()) and ap.Awardid=7)                            
 Begin                            
 insert into RR_Appreciation (Awardid,Comments,StatusId,CreatedBy,CreatedOn,ApprovedBy,ApprovedOn,ApprovedStatus)                                              
 select @Awardid,@Comments,1,@userId, dbo.fn_GetIndiaDate(),@userId, dbo.fn_GetIndiaDate(),1                                    
              
 set @AppId =IDENT_CURRENT('RR_Appreciation' )                      
              
 --For Insert  Appreciation users table                                        
 Insert into RR_Appreciation_Users (AppId,NT_USERNAME,StatusId,CreatedBy,CreatedOn)                                                  
 select @AppId,users,1,@UserId, dbo.fn_GetIndiaDate() from  #tblAppreciation                           
              
 insert into RR_SCOREBOARD(Userid,CID,Points,ReferenceId,ReferenceInfo)                          
 select Ui.USERID,@Awardid,@points,@AppId,'RR_Appreciation' from  #tblAppreciation Ap                          
 inner join ARC_REC_USER_INFO UI on Ui.NT_USERNAME=ap.Users                           
 where ACTIVE=1 and AHS_PRL='Y'                          
              
              
 select  '1' as Result                              
 End                           
 else                            
 begin                            
 select  '0' as Result                              
 end                       
end                          
else if @Awardid not in (7,24,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48)                          
begin                            
 insert into RR_Appreciation (Awardid,Comments,StatusId,CreatedBy,CreatedOn)                                              
 select @Awardid,@Comments,1,@userId, dbo.fn_GetIndiaDate()                                     
 set @AppId =IDENT_CURRENT('RR_Appreciation' )                                        
 Insert into RR_Appreciation_Users (AppId,NT_USERNAME,StatusId,CreatedBy,CreatedOn)                                                  
 select @AppId,users,1,@UserId, dbo.fn_GetIndiaDate() from  #tblAppreciation                            
     
 Exec RR_Appreciation_MailAlert @AppId,@UserId    
     
     
 select  '1' as Result     
     
     
     
                              
end                            
else if @Awardid=24               
Begin                           
insert into RR_Appreciation (Awardid,Comments,StatusId,CreatedBy,CreatedOn,ApprovedBy,ApprovedOn,ApprovedStatus)                                              
 select @Awardid,@Comments,1,@userId, dbo.fn_GetIndiaDate(),@userId, dbo.fn_GetIndiaDate(),1                                    
              
 set @AppId =IDENT_CURRENT('RR_Appreciation' )                                        
              
 --For Insert  Appreciation users table                                        
 Insert into RR_Appreciation_Users (AppId,NT_USERNAME,StatusId,CreatedBy,CreatedOn)                                                  
 select @AppId,users,1,@UserId, dbo.fn_GetIndiaDate() from  #tblAppreciation                           
              
 insert into RR_SCOREBOARD(Userid,CID,Points,ReferenceId,ReferenceInfo)                          
 select Ui.USERID,@Awardid,@points,@AppId,'RR_Appreciation' from  #tblAppreciation Ap                          
 inner join ARC_REC_USER_INFO UI on Ui.NT_USERNAME=ap.Users                           
 where ACTIVE=1 and AHS_PRL='Y'                          
              
              
 select  '1' as Result                              
 End             
 else if @Awardid>=33 and @Awardid<=48           
Begin         
      
print 'Quality'                        
insert into RR_Appreciation (Awardid,Comments,StatusId,CreatedBy,CreatedOn,ApprovedBy,ApprovedOn,ApprovedStatus)                                            
 select @Awardid,@Comments,1,@userId, dbo.fn_GetIndiaDate(),@userId, dbo.fn_GetIndiaDate(),1                                    
              
 set @AppId =IDENT_CURRENT('RR_Appreciation' )          
              
 --For Insert  Appreciation users table                                        
 Insert into RR_Appreciation_Users (AppId,NT_USERNAME,StatusId,CreatedBy,CreatedOn)                                                  
 select @AppId,users,1,@UserId, dbo.fn_GetIndiaDate() from  #tblAppreciation        
              
 insert into RR_SCOREBOARD(Userid,CID,Points,ReferenceId,ReferenceInfo)                          
 select Ui.USERID,@Awardid,@points,@AppId,'RR_Appreciation' from  #tblAppreciation Ap                          
 inner join ARC_REC_USER_INFO UI on Ui.NT_USERNAME=ap.Users                           
 where ACTIVE=1 and AHS_PRL='Y'                          
              
              
 select  '1' as Result                              
 End                           
 else                    
 begin                            
 select  '0' as Result                              
 end               
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Appreciation_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Appreciation_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Appreciation_Insert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Appreciation_Insert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Appreciation_Insert] TO [DB_DMLSupport]
    AS [dbo];

