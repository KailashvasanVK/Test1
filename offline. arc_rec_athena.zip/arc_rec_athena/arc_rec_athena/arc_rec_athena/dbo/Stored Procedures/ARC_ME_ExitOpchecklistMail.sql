﻿CREATE proc ARC_ME_ExitOpchecklistMail  
AS  
BEgin  
IF OBJECT_ID('TEMPDB..#checklistUsers') IS NOT NULL DROP TABLE #checklistUsers     
create table #checklistUsers(EMPCODE varchar(20))  
insert into #checklistUsers(EMPCODE)        
select EMPCODE from ARC_ME_EXIT ex        
inner join ARC_ME_EXIT_STATUS_TRAN ext on ex.REG_ID = ext.REG_ID        
INNER JOIN (SELECT MAX(S_ID) as S_ID FROM ARC_ME_EXIT_STATUS_TRAN                       
GROUP BY REG_ID)T ON T.S_ID = ext.S_ID        
where ext.STATUS_ID = 4 and ex.RELDATE_HR = convert(date,GETDATE()) and ex.ACTIVE = 'Y'    
  
if(select COUNT(*) from #checklistUsers) > 0
begin
  
IF OBJECT_ID('TEMPDB..#checklist') IS NOT NULL DROP TABLE #checklist  
create table #checklist(EMPCODE varchar(20),[SUBJECT] varchar(100),BODY_MSG varchar(max),[FROM] varchar(100),[TO] varchar(100),[CC] varchar(100),[ISHTML] char(1))  
  
insert into #checklist(EMPCODE,[SUBJECT],BODY_MSG,[FROM],[TO],CC,ISHTML)  
select op.EMPCODE,'Exit OP NOC - initiator',' <p>  Hi, <br /><br /> '+ui.FIRSTNAME+' '+ui.LASTNAME+'('+ui.EMPCODE+') is due relieving from the company.        
 Kindly ensure that OP NOC is duly obtained from your department.         
 <br /> <br /> Thanks,<br />         
 <img src="https://arc.accesshealthcare.co/arc_me/Images/arc_me.png" /> <br/>         
 ** This is a system generated mail. Please do not respond to this mail.**</p>',  
 'mail.recruit@accesshealthcare.co',  
 ui.REPORTING_TO+'@accesshealthcare.co',  
 case when isnull((select REPORTING_TO from ARC_REC_USER_INFO where NT_USERNAME = ui.REPORTING_TO and REPORTING_TO <> 'shaji.ravi'),'') <> ''  
 then (select REPORTING_TO from ARC_REC_USER_INFO where NT_USERNAME = ui.REPORTING_TO) +'@accesshealthcare.co'       
 else '' end,    
 'Y'  
from #checklistUsers op        
inner join ARC_REC_USER_INFO ui on op.EMPCODE = ui.EMPCODE    
 
--Declare @toNetworkMail varchar(max)          
--Set  @toNetworkMail  = STUFF(( Select ','+(NT_USERNAME+'@accesshealthcare.co')  from ARC_REC_USER_INFO  ARUI          
--Inner join  ARC_ME_EXIT_CHKLIST_ACCESS AMAE  on AMAE.USERID = ARUI.USERID and AMAE.CHKLIST_TYPE = 'NW' and WRITE = 1 and IS_ACTIVE  =1          
--Where ARUI.ACTIVE = 1  for xml path('')),1,1,'')   
  
--insert into #checklist(EMPCODE,[SUBJECT],BODY_MSG,[FROM],[TO],CC,ISHTML)  
--select op.EMPCODE,'Exit Network NOC - initiator',' <p>  Hi, <br /><br /> '+ui.FIRSTNAME+' '+ui.LASTNAME+'('+ui.EMPCODE+') is due relieving from the company.        
-- Kindly ensure that Network NOC is duly obtained from your department.         
-- <br /> <br /> Thanks,<br />         
-- <img src="https://arc.accesshealthcare.co/arc_me/Images/arc_me.png" /> <br/>         
-- ** This is a system generated mail. Please do not respond to this mail.**</p>',  
-- 'mail.recruit@accesshealthcare.co',  
-- @toNetworkMail,  
-- '',    
-- 'Y'  
--from #checklistUsers op        
--inner join ARC_REC_USER_INFO ui on op.EMPCODE = ui.EMPCODE    
  
  
--Declare @toadminMail varchar(max)          
--Set  @toadminMail  = STUFF(( Select ','+(NT_USERNAME+'@accesshealthcare.co')  from ARC_REC_USER_INFO  ARUI          
--Inner join  ARC_ME_EXIT_CHKLIST_ACCESS AMAE  on AMAE.USERID = ARUI.USERID and AMAE.CHKLIST_TYPE = 'AD' and WRITE = 1 and IS_ACTIVE  =1          
--Where ARUI.ACTIVE = 1  for xml path('')),1,1,'')       

--insert into #checklist(EMPCODE,[SUBJECT],BODY_MSG,[FROM],[TO],CC,ISHTML)  
--select op.EMPCODE,'Exit Admin NOC - initiator',' <p>  Hi, <br /><br /> '+ui.FIRSTNAME+' '+ui.LASTNAME+'('+ui.EMPCODE+') is due relieving from the company.        
-- Kindly ensure that Admin NOC is duly obtained from your department.         
-- <br /> <br /> Thanks,<br />         
-- <img src="https://arc.accesshealthcare.co/arc_me/Images/arc_me.png" /> <br/>         
-- ** This is a system generated mail. Please do not respond to this mail.**</p>',  
-- 'mail.recruit@accesshealthcare.co',  
-- @toadminMail,  
-- '',    
-- 'Y'  
--from #checklistUsers op        
--inner join ARC_REC_USER_INFO ui on op.EMPCODE = ui.EMPCODE    
  

insert into ARC_REC_MAIL_TRAN(FROM_MAILID,RECIPIENTS,SUBJECT_TEXT,BODY,ISHTML,MAIL_STATUS,CC,CREATED_DT)        
         select [FROM],[TO],[SUBJECT],BODY_MSG,[ISHTML],0 As MAIL_STATUS,[CC],GETDATE() as CREATED_DT from #checklist    
         
         
  end

END  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_ExitOpchecklistMail] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_ExitOpchecklistMail] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_ExitOpchecklistMail] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_ExitOpchecklistMail] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_ExitOpchecklistMail] TO [DB_DMLSupport]
    AS [dbo];

