﻿CREATE Proc ARC_REC_CAPMAN_Insert                                   
(                                    
@FacilityId int,                                  
@clinetid int=0,                                  
@BayStatus int,                                  
@Bayno varchar(max),                                  
@NT_UserName varchar(70),                
@ShiftId tinyint,      
@FunctionalityId int                                   
)                                    
As                                    
/*                                   
                                  
  ARC_REC_CAPMAN_GET 2                                     
                                  
ARC_REC_CAPMAN_Insert @FacilityId=2,@clinetid=1,@BayStatus=1,@Bayno='147,148,149',@NT_UserName='udhayaganesh.p'                                  
              
exec ARC_REC_CAPMAN_Insert @FacilityId=N'3',@clinetid=N'1',@BayStatus=N'1',@Bayno=N'54,53',@NT_UserName=N'seena.ambaturu ',@ShiftId=N'1'              
              
exec ARC_REC_CAPMAN_Insert @FacilityId=N'3',@clinetid=N'1',@BayStatus=N'1',@Bayno=N'197,198',@NT_UserName=N'seena.ambaturu ',@ShiftId=N'1'                               
                                  
*/                                    
                                    
Begin             
        
Declare @TemShift varchar(10)               
        
if @ShiftId in(1,4,11)        
SET @TemShift='1,4,11'                   
ELSE         
SET @TemShift ='2,3,5'                         
                            
If @BayStatus=1                            
begin                          
print 'block'                                
                                  
If exists (select 'x' from ARC_REC_CAPMAN A                                    
inner join Eye_IPDetails B on b.Id =a.BayId and a.Facilityid =b.Facilityid                                     
where a.Facilityid=@FacilityId and b.bayno in (select value from dbo.Split(@BayNo,',')))                                
                                  
Begin                                  
--print 'update block'                                    
--update A set a.status=0,a.modifiedby=@NT_UserName,modifiedon=GETDATE() from  ARC_REC_CAPMAN A                                    
--inner join Eye_IPDetails B on b.Id =a.BayId and a.Facilityid =b.Facilityid                                     
--where a.Facilityid=@FacilityId and b.bayno in (select value from dbo.Split(@BayNo,',')) and a.shiftid=@ShiftId                                 
              
--print 'insert block'                                    
                                  
--insert into ARC_REC_CAPMAN(BayId,BayIP,FacilityId,ClientID,BayStatus,Status,CreatedBy,Createdon,ShiftId)                                  
--select b.id,b.bayip,a.Facilityid,@clinetid,@BayStatus,1,@NT_UserName,GETDATE(),a.shiftid from ARC_REC_CAPMAN A                                    
--inner join Eye_IPDetails B on b.Id =a.BayId and a.Facilityid =b.Facilityid                                     
--where a.Facilityid=@FacilityId and a.shiftid=@ShiftId and b.bayno in (select value from dbo.Split(@BayNo,','))           
         
        
print 'update block'                                  
update A set a.status=0,a.modifiedby=@NT_UserName,modifiedon=GETDATE() from  ARC_REC_CAPMAN A                                  
inner join Eye_IPDetails B on b.Id =a.BayId and a.Facilityid =b.Facilityid                                   
where a.Facilityid=@FacilityId and b.bayno in (select value from dbo.Split(@BayNo,',')) and a.shiftid        
IN(select value from dbo.Split(@TemShift,','))                       
            
print 'insert block'                                  
                                
insert into ARC_REC_CAPMAN(BayId,BayIP,FacilityId,ClientID,BayStatus,Status,CreatedBy,Createdon,ShiftId,FunctionalityId)                                
select DISTINCT b.id,b.bayip,a.Facilityid,@clinetid,@BayStatus,1,@NT_UserName,GETDATE(),@ShiftId,@FunctionalityId  from ARC_REC_CAPMAN A                
LEFT join Eye_IPDetails B on b.Id =a.BayId and a.Facilityid =b.Facilityid                                   
where a.Facilityid=@FacilityId  and b.bayno in (select value from dbo.Split(@BayNo,','))                                
                            
select 1 output                           
                                  
end                             
                            
end                            
else                            
begin                           
--print 'Unblock'                         
                            
update A set a.baystatus=0,a.modifiedby=@NT_UserName,modifiedon=GETDATE(),ClientID=0 from  ARC_REC_CAPMAN A                                    
inner join Eye_IPDetails B on b.Id =a.BayId and a.Facilityid =b.Facilityid                                     
where a.Facilityid=@FacilityId and b.bayno in (select value from dbo.Split(@BayNo,','))                        
and a.Status =1  and a.shiftid        
IN(select value from dbo.Split(@TemShift,','))                                          
                            
select 2 output                              
                            
End                            
                                 
                                    
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_Insert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_Insert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_Insert] TO [DB_DMLSupport]
    AS [dbo];

