﻿Create Procedure ARC_REC_UserRole_Move
@UserId int,
@RoleId int
As
/*
To Remove the user's Rights and move to log -- Karthik
*/
Begin
Insert into ARC_REC_UserRoleLog (UserId,RoleId,CREATED_BY,CREATED_DT,FUNCTIONALITY_ID,AccessLevel)
Select UserId,RoleId,CREATED_BY,CREATED_DT,FUNCTIONALITY_ID,AccessLevel from ARC_REC_UserRole
Where UserId = @UserId  and RoleId =@RoleId
Delete  from ARC_REC_UserRole Where UserId = @UserId  and RoleId =@RoleId
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_UserRole_Move] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UserRole_Move] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UserRole_Move] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_UserRole_Move] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UserRole_Move] TO [DB_DMLSupport]
    AS [dbo];

