﻿CREATE proc ARC_REC_UpdNewImage      
    @NewRecId int,      
    @OldRecId int,
    @Empcode varchar(100)='',  
    @UpdatedBy int      
As      
Begin 
if(@Empcode <> '')
		select @OldRecId = REC_ID from ARC_REC_USER_INFO where EMPCODE = @Empcode
     
   insert into ARC_REC_CANDIDATEIMG_LOG(RecId,OldImage,NewImage,UpdatedBy,UpdatedDt)  
 select @OldRecId,PROFILE_IMAGE_NAME,convert(varchar,@NewRecId)+'.jpg',@UpdatedBy,GETDATE() from ARC_REC_CANDIDATE where REC_ID = @OldRecId  
    if (Select COUNT(*) from ARC_REC_IDCard as id  
    inner join ARC_REC_USER_INFO as ui on ui.EMPCODE = id.Emp_Code and ui.REC_ID = @OldRecId  
    ) > 0  
  Begin  
  /** Exists in ID card **/  
      
    update ARC_REC_IDCard set    
    Dept = convert(varchar,@NewRecId)+'.jpg' ,  
    SourceFile =   convert(varchar,@NewRecId)+'.jpg'     
    where Emp_Code = (select EMPCODE from ARC_REC_USER_INFO where REC_ID = @OldRecId)        
  End  
 Else  
  Begin  
  update ARC_REC_CANDIDATE set      
   PROFILE_IMAGE_NAME = convert(varchar,@NewRecId)+'.jpg'      
   where REC_ID = @OldRecId      
  End  
 ----if((select COUNT(*) from ARC_REC_CANDIDATE where REC_ID = @NewRecId) > 0    
 ----and (select COUNT(*) from ARC_REC_USER_INFO where REC_ID = @NewRecId) = 0)    
 ---- begin    
 ----  if(select COUNT(*) from ARC_REC_USER_INFO where REC_ID = @OldRecId) > 0    
 ----  begin      
 ----   insert into ARC_REC_CANDIDATEIMG_LOG(RecId,OldImage,NewImage,UpdatedBy,UpdatedDt)  
 ----   select @OldRecId,PROFILE_IMAGE_NAME,convert(varchar,@NewRecId)+'.jpg',@UpdatedBy,GETDATE() from ARC_REC_CANDIDATE where REC_ID = @OldRecId  
      
 ----   update ARC_REC_IDCard set    
 ----   Dept = convert(varchar,@NewRecId)+'.jpg' ,  
 ----   SourceFile =   convert(varchar,@NewRecId)+'.jpg'     
 ----   where Emp_Code = (select EMPCODE from ARC_REC_USER_INFO where REC_ID = @OldRecId)     
 ----   -- a trigger will fire to update candidate table    
      
      
 ----  end    
 ---- else    
 ----  begin    
     
 ----  insert into ARC_REC_CANDIDATEIMG_LOG(RecId,OldImage,NewImage,UpdatedBy,UpdatedDt)  
 ----  select @OldRecId,PROFILE_IMAGE_NAME,convert(varchar,@NewRecId)+'.jpg',@UpdatedBy,GETDATE() from ARC_REC_CANDIDATE where REC_ID = @OldRecId  
      
 ----  update ARC_REC_CANDIDATE set      
 ----  PROFILE_IMAGE_NAME = convert(varchar,@NewRecId)+'.jpg'      
 ----  where REC_ID = @OldRecId      
 ----  end      
     
--end    
End   
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_UpdNewImage] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UpdNewImage] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UpdNewImage] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_UpdNewImage] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UpdNewImage] TO [DB_DMLSupport]
    AS [dbo];

