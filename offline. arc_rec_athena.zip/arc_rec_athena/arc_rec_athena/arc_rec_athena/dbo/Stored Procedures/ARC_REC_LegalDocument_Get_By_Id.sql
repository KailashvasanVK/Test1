﻿CREATE Proc ARC_REC_LegalDocument_Get_By_Id        
 @DocId int=0        
AS        
/*      
      
ARC_REC_LegalDocument_Get_By_Id @DocId=1      
      
*/      
Begin            
select Docid,DocumentName,PathName,Publish,Status,CreatedBy, CONVERT(varchar(20),createdon,110) CreatedOn          
from ARC_REC_LegalDocument  where DocID=@DocId         
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_LegalDocument_Get_By_Id] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_LegalDocument_Get_By_Id] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_LegalDocument_Get_By_Id] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_LegalDocument_Get_By_Id] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_LegalDocument_Get_By_Id] TO [DB_DMLSupport]
    AS [dbo];

