﻿CREATE Proc ARC_Lounge_Message_ReportAbuse_Ins              
 @MsgId int,              
 @NT_Username Varchar(100)              
 /*               
 CreatedBy : Udhayaganesh.p              
 Purpose   : Associate Report the messages to be accounted              
               
 Execution : Exec ARC_Lounge_Message_ReportAbuse_Ins 6,'varunnair.m'             
             
 Exec ARC_Lounge_Message_ReportAbuse_Ins 7,'varunnair.m'            
               
 */              
 As              
 Begin              
 if not Exists(select top 1 'x' from ARC_Forum_Lounge_Message_Flags where ReportedBy =@NT_Username        
 and MsgId =@MsgId and Status=1)              
 Begin              
 Insert into ARC_Forum_Lounge_Message_Flags(MsgId,ReportedBy,ReportedOn,Status)              
 Values(@MsgId,@NT_Username,GETDATE(),1)              
 Select COUNT(*) ReportCount,1 'ReportAbuse',MsgId  from ARC_Forum_Lounge_Message_Flags         
 where Msgid=@MsgId and Status=1 group by MsgId             
 End            
 End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Message_ReportAbuse_Ins] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_ReportAbuse_Ins] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_ReportAbuse_Ins] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Message_ReportAbuse_Ins] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_ReportAbuse_Ins] TO [DB_DMLSupport]
    AS [dbo];

