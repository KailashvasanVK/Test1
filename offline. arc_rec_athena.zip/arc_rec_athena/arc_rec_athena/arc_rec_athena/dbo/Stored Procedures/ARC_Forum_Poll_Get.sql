﻿CREATE procedure ARC_Forum_Poll_Get    
@year  varchar(10),@month varchar(10)=NULL            
As            
/*            
To get the message details from forum             
Created by karthik ic            
Created on 12 March 2013            
ARC_Forum_MessageBoard_Get 2013, 3           
*/            
Begin       
      
IF @month IS NOT NULL           
 Select  POLL_ID,substring(POLL,0,15)Headline, POLL as tooltip,    
 CONVERT(VARCHAR(12),CREATED_ON,107)CreatedOn,month(CREATED_ON) as MsgMonth,          
Year(CREATED_ON) as MsgYear,status,Convert(varchar(10),month(CREATED_ON)) +'~'+Convert(varchar(10),Year(CREATED_ON)) as MonthYear    
from ARC_Forum_Polls             
where month(CREATED_ON) = @month  and Status not in (0)        
order by CREATED_ON   desc         
ELSE      
Select  POLL_ID,substring(POLL,0,15)Headline, POLL as tooltip,    
 CONVERT(VARCHAR(12),CREATED_ON,107)CreatedOn,month(CREATED_ON) as MsgMonth,          
Year(CREATED_ON) as MsgYear,status,Convert(varchar(10),month(CREATED_ON)) +'~'+Convert(varchar(10),Year(CREATED_ON)) as MonthYear    
from ARC_Forum_Polls      
where Year(CREATED_ON) = @year and Status not in (0)        
order by CREATED_ON   desc         
       
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Forum_Poll_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_Poll_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_Poll_Get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Forum_Poll_Get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_Poll_Get] TO [DB_DMLSupport]
    AS [dbo];

