﻿CREATE Procedure ARC_REC_ITREQUEST_GET                                  
(                                  
@UserId int=0,                                  
@RequestStatus tinyint=1,                              
@RequestId int =0                                 
)                                  
As                                  
/*                                  

ARC_REC_ITREQUEST_GET @UserId=807,@RequestStatus=1, @RequestId=2  
                          
*/                                  
Begin                                  
if @RequestId = 0                              
Begin                              
 select ROW_NUMBER() over (order by arr.requestId) as 'Sl_No',  ARR.RequestId,                                  
 RequestType=(case when RequestType=1 then 'New request' when RequestType=2 then 'Change request' end),                                  
 FunctionId,FunctionName,                                  
 RequestFrom=(case when RequestFrom=1 then 'Client' when RequestFrom=2 then 'Internal' end),                                    
 (Case when LEN(Description)>50 then SUBSTRING(Description,1,50) + '...' else Description end) As Description,                                
 (case when LEN(reason) >50 then substring(Reason,1,50) + '...' else Reason end )As Reason,                                
 (case when len(Benifit)> 50 then Substring(Benifit,1,50) + '...' else benifit end) As Benifit,           
 (case when len(ApprovedComments)> 50 then Substring(ApprovedComments,1,50) + '...' else ApprovedComments end) As ApprovedComments,                               
 Supervisor,FIRSTNAME + ' ' + LASTNAME as SupervisorName,                                 
 RS.STATUSNAME,isnull(sh.scheduleName,'') AS SCHEDULENAME,      
 AttachFileName=(SELECT STUFF((select  distinct '~' +convert(varchar(500),AF.AFileName   )                          
 from ARC_REC_ITREQUEST_ATTACHMENT AF where AF.Requestid=ARR.requestid                              
 FOR XML PATH('')), 1, 1, '')),ARR.CreatedOn,ARR.ApprovedOn                               
 from ARC_REC_ITREQUEST ARR                       
 inner join HR_Functionality HRF on arr.FunctionId=hrf.FunctionalityId                       
 inner join ARC_REC_USER_INFO UI on ui.USERID=arr.Supervisor                    
 inner join ARC_REC_ITREQUEST_STATUS RS on RS.RequestStatus=ARR.RequestStatus      
 left join ARC_REC_ITREQUEST_schedule sh on sh.schid=ARR.schid    
 where arr.CreatedBy=@UserId  and arr.StatusId=1                   
 and   ARR.RequestStatus <= (              
 case when @RequestStatus =6 and ARR.RequestStatus=6 then  (6) when @RequestStatus in (1)  then (5)  end)                       
 order by ARR.RequestId                        
                             
End                              
Else                              
Begin                        
                            
 select ARR.RequestId,                                  
 RequestType=(case when RequestType=1 then 'New request' when RequestType=2 then 'Change request' end),                                  
 FunctionId,FunctionName,                                  
 RequestFrom=(case when RequestFrom=1 then 'Client' when RequestFrom=2 then 'Internal' end),                                    
 (Case when LEN(Description)>50 then SUBSTRING(Description,1,50) else Description end) As Description,                                
 (case when LEN(reason) >50 then substring(Reason,1,50)  else Reason end )As Reason,                                
 (case when len(Benifit)> 50 then Substring(Benifit,1,50) else benifit end) As Benifit,          
 (case when len(ApprovedComments)> 50 then Substring(ApprovedComments,1,50) + '...' else ApprovedComments end) As ApprovedComments,                                
 Description As 'Desc',Reason As 'Res',Benifit As 'Ben',ApprovedComments As 'AppComments',                              
 Supervisor,FIRSTNAME + ' ' + LASTNAME as SupervisorName,                                  
 RS.STATUSNAME,isnull(sh.scheduleName,'') AS SCHEDULENAME,                      
 AttachFileName=(SELECT STUFF((select  distinct '~' +convert(varchar(500),AF.AFileName   )                          
  from ARC_REC_ITREQUEST_ATTACHMENT AF where AF.Requestid=ARR.requestid                              
    FOR XML PATH('')), 1, 1, '')), ARR.CreatedOn,ARR.ApprovedOn                                   
 from ARC_REC_ITREQUEST ARR                       
 inner join HR_Functionality HRF  on arr.FunctionId=hrf.FunctionalityId                       
 inner join ARC_REC_USER_INFO UI  on ui.USERID=arr.Supervisor                   
 inner join ARC_REC_ITREQUEST_STATUS RS on RS.RequestStatus=ARR.RequestStatus       
 left join ARC_REC_ITREQUEST_schedule sh on sh.schid=ARR.schid      
                   
 where  ARR.RequestId=@RequestId and arr.StatusId=1 --and arr.CreatedBy=@UserId                   
  -- and   ARR.RequestStatus <= (case when @RequestStatus =6 and ARR.RequestStatus=6 then  (6) when @RequestStatus in (1)  then (5)  end)               
 UNION all                      
 select ARR.RequestId,                                  
 RequestType=(case when RequestType=1 then 'New request' when RequestType=2 then 'Change request' end),                                  
 FunctionId,FunctionName,                     
 RequestFrom=(case when RequestFrom=1 then 'Client' when RequestFrom=2 then 'Internal' end),                                    
 (Case when LEN(Description)>50 then SUBSTRING(Description,1,50) else Description end) As Description,                                
 (case when LEN(reason) >50 then substring(Reason,1,50)  else Reason end )As Reason,                                
 (case when len(Benifit)> 50 then Substring(Benifit,1,50) else benifit end) As Benifit,          
 (case when len(ApprovedComments)> 50 then Substring(ApprovedComments,1,50) + '...' else ApprovedComments end) As ApprovedComments,                                
 Description As 'Desc',Reason As 'Res',Benifit As 'Ben',ApprovedComments As 'AppComments',                              
 Supervisor,FIRSTNAME + ' ' + LASTNAME as SupervisorName,                                 
 RS.STATUSNAME,isnull(sh.scheduleName,'') AS SCHEDULENAME,                     
 AttachFileName=(SELECT STUFF((select  distinct '~' +convert(varchar(500),AF.AFileName   )                          
  from ARC_REC_ITREQUEST_ATTACHMENT AF where AF.Requestid=ARR.requestid                              
    FOR XML PATH('')), 1, 1, '')), ARR.CreatedOn,ARR.ApprovedOn                                    
 from ARC_REC_ITREQUEST_HISTORY ARR                       
 inner join HR_Functionality HRF  on arr.FunctionId=hrf.FunctionalityId                       
 inner join ARC_REC_USER_INFO UI  on ui.USERID=arr.Supervisor                      
 inner join ARC_REC_ITREQUEST_STATUS RS on RS.RequestStatus=ARR.RequestStatus      
 left join ARC_REC_ITREQUEST_schedule sh on sh.schid=ARR.schid      
                    
 where  ARR.RequestId=@RequestId and arr.StatusId=1 --and arr.CreatedBy=@UserId                   
  --and   ARR.RequestStatus <= ( case when @RequestStatus =6 and ARR.RequestStatus=6 then  (6) when @RequestStatus in (1)  then (5)  end)               
 order by ARR.CreatedOn DESC                         
                            
End                              
                               
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_GET] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_GET] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_GET] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_GET] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_GET] TO [DB_DMLSupport]
    AS [dbo];

