﻿CREATE Proc ARC_FORUM_LOUNGE_HIGHlIGHT_GET              
(              
@Hid int =0              
)                
as                 
/*              
ARC_FORUM_LOUNGE_HIGHlIGHT_GET @Hid=0              
ARC_FORUM_LOUNGE_HIGHlIGHT_GET @Hid=2              
*/               
begin                  
if @Hid=0              
Begin              
select  ROW_NUMBER() over (order by Hid) as 'Sl_No' ,content , Hid from ARC_FORUM_LOUNGE_HIGHlIGHT where status=1 ORDER by CreatedOn DESC               
End              
Else              
Begin              
select  ROW_NUMBER() over (order by Hid)as 'Sl_No',content, hid from ARC_FORUM_LOUNGE_HIGHlIGHT where Hid=@Hid and status=1                  
              
End                
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FORUM_LOUNGE_HIGHlIGHT_GET] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_LOUNGE_HIGHlIGHT_GET] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_LOUNGE_HIGHlIGHT_GET] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FORUM_LOUNGE_HIGHlIGHT_GET] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_LOUNGE_HIGHlIGHT_GET] TO [DB_DMLSupport]
    AS [dbo];

