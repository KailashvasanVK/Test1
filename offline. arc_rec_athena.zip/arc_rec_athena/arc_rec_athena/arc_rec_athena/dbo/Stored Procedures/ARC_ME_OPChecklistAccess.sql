﻿CREATE procedure ARC_ME_OPChecklistAccess      
      @UserId int      
As      
Begin      
    
declare @DesigId as int    
select @DesigId = DESIGNATION_ID from ARC_REC_USER_INFO where USERID = @UserId    
    
if( select COUNT(*) from HR_Designation where DesigId = @DesigId and ISNULL(OP_READ,'') = 'Y' and ISNULL(OP_EDIT,'') = 'Y'  ) > 0      
  select 'Yes' as [Read],'Yes' as Write     
else if(select COUNT(*) from HR_Designation where DesigId = @DesigId and ISNULL(OP_READ,'') = 'Y' ) > 0  
  select 'Yes' as [Read],'No' as Write  
else if(@UserId = 361 or @UserId = 637) -- Training & Development(Richard, Rekha op checklist access as per the mail req from Bhuvaneswari Neelam)
  select 'Yes' as [Read],'Yes' as Write     
else      
  select 'No' as [Read],'No' as Write  
      
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_OPChecklistAccess] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_OPChecklistAccess] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_OPChecklistAccess] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_OPChecklistAccess] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_OPChecklistAccess] TO [DB_DMLSupport]
    AS [dbo];

