﻿  
create Proc Attendance_Report_anlaysis  
as  
select dbo.Fn_DayOfWeek([date]) WeekDay,DATE,UI.NT_Username,FIRSTNAME+' '+lastname Emp,SI.SHIFT_NAME,Logon,logout,TotalHrs,WorkHours,Lockhrs,AttendanceAsPerWorked=(  
case when workhours>=8 then 'Full day Present'   
when workhours >4 and workhours<8 then 'Half day Present'  
when Workhours <4 then 'Absent' end) 
,AttendanceAsPerFirstLoginandLastLogout=(  
case when TotalHrs>=8 then 'Full day Present'   
when TotalHrs >4 and TotalHrs<8 then 'Half day Present'  
when TotalHrs <4 then 'Absent' end) ,b.Designation,f.FunctionName  
 from ARC_REC_Attendance A  
inner join HR_Designation B on A.designid=b.DesigId   
inner join HR_Functionality F on f.FunctionalityId =a.FunctionalityId  
inner join ARC_REC_SHIFT_INFO SI on A.shiftid=Si.SHIFT_ID   
inner join ARC_REC_USER_INFO UI on a.userid=UI.USERID   
where ui.NT_Username='abdulrahman.sha'
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Attendance_Report_anlaysis] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Attendance_Report_anlaysis] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Attendance_Report_anlaysis] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Attendance_Report_anlaysis] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Attendance_Report_anlaysis] TO [DB_DMLSupport]
    AS [dbo];

