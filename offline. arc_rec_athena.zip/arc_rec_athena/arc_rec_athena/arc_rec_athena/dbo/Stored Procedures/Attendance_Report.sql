﻿CREATE Proc Attendance_Report    
@from date,  
@to date              
as         
/*   
Attendance_Report '2013-10-01','2013-10-31'  
           */  
BEGIN         
select dbo.Fn_DayOfWeek([date]) WeekDay,DATE,UI.NT_Username,FIRSTNAME+' '+lastname Emp,SI.SHIFT_NAME,          
Logon,logout,latein,LATEOUT EarlerOut,Attendance=(                
case when latein<=0.15 and LateOut<=0.15 and LogOn IS not null  then 'Full day Present'           
when LogOn IS null and LogOut IS null then 'To be verify'                 
else 'TL Verification'               
 end)               
 ,b.Designation,f.FunctionName,CI.CLIENT_NAME                
 from ARC_REC_Attendance A                
inner join HR_Designation B on A.designid=b.DesigId                 
inner join HR_Functionality F on f.FunctionalityId =a.FunctionalityId                
inner join ARC_REC_SHIFT_INFO SI on A.shiftid=Si.SHIFT_ID                 
inner join ARC_REC_USER_INFO UI on a.userid=UI.USERID            
inner join ARC_REC_CustomerView CI on UI.CLIENT_ID =CI.CLIENT_ID             
where [DATE] is not NULL         
and DATE>=@from AND DATE<=@to  and ui.NT_Username <> ''     
order by  NT_USERNAME ,[DATE]  
eND
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Attendance_Report] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Attendance_Report] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Attendance_Report] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Attendance_Report] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Attendance_Report] TO [DB_DMLSupport]
    AS [dbo];

