﻿CREATE proc ARC_REC_Capman_Verify      
@Clientid int=0    
/*        
      
ARC_REC_Capman_Verify 2      
      
      
*/      
As      
Begin      
Select CLIENT_ID,CLIENT_NAME,OnRoll,OpenPotion,(OnRoll+OpenPotion) Total,blocked,TobeBlock=((OnRoll+OpenPotion)-blocked) from  (      
select ci.CLIENT_ID,CLIENT_NAME ,      
OnRoll=(select COUNT(*) from ARC_REC_User_info UI where UI.CLIENT_ID=Ci.CLIENT_ID and UI.ACTIVE =1 ),      
OpenPotion=(select isnull(SUM(pending),0) from ARMS_Status where clientid=ci.client_id ) ,      
blocked=(select COUNT(*) from ARC_REC_CAPMAN where  clientid=ci.client_id  and Status =1 and BayStatus =1 )      
from ARC_FIN_CLIENT_INFO CI where CLIENT_ID =(case when @Clientid=0 then client_id else @Clientid end) ) as Udhaya       
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_Capman_Verify] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Capman_Verify] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Capman_Verify] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_Capman_Verify] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Capman_Verify] TO [DB_DMLSupport]
    AS [dbo];

