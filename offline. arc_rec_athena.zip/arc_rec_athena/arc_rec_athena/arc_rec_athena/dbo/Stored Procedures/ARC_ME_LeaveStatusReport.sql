﻿     --ARC_ME_LeaveStatusReport '2013-03-01','2013-03-01',0,0,0,'1'      
CREATE PROCEDURE ARC_ME_LeaveStatusReport 
( 
 @Fromdate date 
,@Todate date 
,@Functionality_Id int 
,@Client_Id int 
,@UserId varchar(20) 
,@Leave_Status varchar(1)
,@SearchStr varchar(100) = ''
,@SearchPattern varchar(4) = '=' /** = or % **/
) 
AS 
BEGIN 
--ARC_ME_LeaveStatusReport NULL,NULL,null,null,null,null 
--Declare @Fromdate date 
--Declare @Todate date 
--declare @Functionality_Id int 
--declare @Client_Id int 
--declare @Empcode varchar(20) 
--declare @Leave_Status varchar(1) 
--set @Fromdate = '2013-02-01' 
--set @Todate = '2013-02-28' 
--set @Functionality_Id = null 
--set @Client_Id = null 
--set @UserId = null 
--set @Leave_Status = null 
 

if OBJECT_ID('tempdb..#tempLeaveReport') is not null drop table #tempLeaveReport
Create  table #tempLeaveReport 
(
[AppliedFrom]  varchar(100),
[AppliedTo]   varchar(100),
[No of Leave] Decimal(4,1),
[Leave Type] varchar(50),
[RequestedOn] varchar(100),
ReqEmpCode  varchar(10),
RequestedBy varchar(100),
RequestedTo  varchar(100),
[Request Status] varchar(50),
[Reason] varchar(1000),
[Functionality] varchar(100),
[Client] varchar(100)
)
 
Declare @qry varchar(max) 
set @qry = ' 
insert into #tempLeaveReport  (
[AppliedFrom]
,[AppliedTo]
,[No of Leave]
,[Leave Type]
,[RequestedOn]
,ReqEmpCode
,RequestedBy
,RequestedTo
,[Request Status]
,[Reason]
,[Functionality]
,[Client]
)
select  
convert(varchar,LR.FROMDATE,100) [AppliedFrom] 
,convert(varchar,LR.TODATE,100) [AppliedTo] 
,LR.LEAVE_DAYS AS [No of Leave] 
,LT.TYPE_TEXT AS [Leave Type] 
,convert(varchar,LR.CREATED_DT,100) AS [RequestedOn]  
,UI.EMPCODE as ReqEmpCode 
,ui.FIRSTNAME + '' '' + ui.LASTNAME as RequestedBy 
,AP.FIRSTNAME + '' '' + AP.LASTNAME as RequestedTo 
,case when lr.LEAVE_STATUS = 1 then ''Approved'' when lr.LEAVE_STATUS = 2 then ''Rejected'' else ''Approval Pending'' end AS [Request Status] 
,lr.REASON as [Reason] 
,func.functionname [Functionality] 
,CI.CLIENT_NAME [Client] 
from ARC_REC_LEAVE_REQUEST AS LR 
INNER JOIN ARC_REC_LEAVE_TYPES AS LT ON LT.TYPEID = LR.TYPEID 
INNER JOIN ARC_REC_USER_INFO AS UI ON UI.USERID = LR.CREATED_BY' 
if isnull(@Functionality_Id,0) <> 0 
 set @qry += ' AND UI.Functionality_Id = ' + CONVERT(VARCHAR,@Functionality_Id) 
if ISNULL(@Client_Id,0) <> 0 
 set @qry += ' AND UI.CLIENT_ID = ' + CONVERT(VARCHAR,@Client_Id) 
if ISNULL(@UserId,0) <> 0 
 set @qry += ' AND UI.USERID = '+ CONVERT(VARCHAR,@UserId)  
set @qry += '  
INNER JOIN HR_Functionality AS FUNC ON FUNC.FunctionalityId = UI.Functionality_Id 
LEFT JOIN ARC_FIN_CLIENT_INFO AS CI ON CI.CLIENT_ID = UI.CLIENT_ID 
INNER JOIN ARC_REC_USER_INFO AS AP ON AP.USERID = LR.FORWARD_TO 
WHERE CONVERT(DATE,LR.FROMDATE) BETWEEN ''' + convert(varchar,@Fromdate) + ''' AND ''' + convert(varchar,@Todate) + '''  
AND CONVERT(DATE,LR.TODATE) BETWEEN ''' + convert(varchar,@Fromdate) + ''' AND ''' + convert(varchar,@Todate) + '''' 
if isnull(@Leave_Status,0) <> 0 
set @qry += ' and lr.LEAVE_STATUS = ' + CONVERT(varchar,@Leave_Status) 
set @qry += ' AND LR.ACTIVE = ''Y''
ORDER BY LR.FROMDATE'
 PRINT (@QRY)
EXEC (@QRY)

Declare @OrderStr varchar(100)
SET @OrderStr  = ' order by AppliedFrom '
Exec FilterTable
@DbName = 'tempdb'
,@TblName = '#tempLeaveReport'
,@SearchStr = @SearchStr
,@SearchPattern = @SearchPattern
,@OrderStr = @OrderStr
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_LeaveStatusReport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_LeaveStatusReport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_LeaveStatusReport] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_LeaveStatusReport] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_LeaveStatusReport] TO [DB_DMLSupport]
    AS [dbo];

