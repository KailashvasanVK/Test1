﻿
create Procedure ARC_Me_CheckEmpPayslipRights
								@UserId int
As
Begin
select Acc_Type,CreatedBy,CreatedDt from ARC_ME_EmployeePayslip_Access where UserId  =@UserId
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Me_CheckEmpPayslipRights] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Me_CheckEmpPayslipRights] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Me_CheckEmpPayslipRights] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Me_CheckEmpPayslipRights] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Me_CheckEmpPayslipRights] TO [DB_DMLSupport]
    AS [dbo];

