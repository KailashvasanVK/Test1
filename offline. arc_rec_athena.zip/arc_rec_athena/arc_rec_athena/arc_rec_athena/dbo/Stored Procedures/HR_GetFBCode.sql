﻿    
CREATE procedure HR_GetFBCode      
(      
@Trackid int=0,      
@Tcid int=0,      
@SessionId varchar(max)=null,      
@FBCode nvarchar(max)=null      
)      
/*      
  
exec HR_GetFBCode @Trackid=1,@SessionId='bmhcavsx4hctjsl0rzitryvj',  
@FBCode='AQCed8GV34dYChLjnYIoSnBylk418HU1snXFp_2vZWCFSOS7HnPpFYfJD-aJFRTvSwWc4KZZbyWBRuEgClPegH5clTttVtxtqLtMZGrj9kSCwrAnggdHN01-CsKpfeTW2ziJ54G3u7RJE0dm6VWbODNyIOQoB5ngbAUknHGXDDKUT1nXLUaX4Ew085HMjZsiNeAPSJuf8iiLNptxG1uWFVbE'     
  
  
*/      
As      
Begin      
if @Trackid =1      
 Begin      
 if not exists(select top 1 * from AHC_FaceBookCode where SessionId=@SessionId)    
 Begin  
   
 Insert into AHC_FaceBookCode(SessionId,FBCode) values(@SessionId,@FBCode)   
 select 1 output  
   
 End  
 else  
 select 0 output  
 End      
else if @Trackid =2      
 Begin      
 Delete from AHC_FaceBookCode where SessionId =@SessionId       
 End      
else if @Trackid =3      
 Begin      
 Select fbcode from AHC_FaceBookCode where SessionId=@SessionId       
 End      
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_GetFBCode] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_GetFBCode] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_GetFBCode] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_GetFBCode] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_GetFBCode] TO [DB_DMLSupport]
    AS [dbo];

