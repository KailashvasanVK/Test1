﻿CREATE procedure [dbo].[ARC_REC_TeamMovementUpdate]    
      @TRAINEE_IDS varchar(Max),            
      @SUPERVISOR_ID INT,            
      @CUSTOMER_ID INT,            
      @CREATED_BY INT,            
      @SHIFT_ID INT         
As    
Begin    
Declare @Reporting varchar(200)            
    
select @Reporting = NT_USERNAME from ARC_REC_USER_INFO where USERID = @SUPERVISOR_ID         
if OBJECT_ID('tempdb..#trainees') is not null drop table #trainees                
create table #trainees(USERID Int)              
Insert into #trainees(USERID)            
Select items from dbo.fnSplitString(@TRAINEE_IDS,',')      
    
insert into ARC_REC_Superviosrlog(UserId,SupervisorId,CreatedBy,CreatedDt)      
select USERID,@SUPERVISOR_ID,@CREATED_BY,GETDATE() from #trainees           
--select ia.USERID,uir.USERID,ui.CREATED_BY,ui.CREATED_DT,@CREATED_BY,GETDATE() from ARC_REC_USER_INFO ui        
--inner join #IndexAssociates ia on ui.USERID = ia.USERID               
--inner join ARC_REC_USER_INFO uir on ui.REPORTING_TO = uir.NT_USERNAME     
    
   
    
insert into ARC_REC_SHIFT_TRAN(USERID,SHIFT_ID,Effect_DATE,CREATED_BY,CREATED_DT)            
select USERID,@SHIFT_ID,GETDATE(),@CREATED_BY,GETDATE() from #trainees    

insert into ARC_REC_UserCustomerLog(UCid,UserId,CustomerID,CREATED_BY,CREATED_DT)              
select UCid,UserId,CustomerID,CREATED_BY,CREATED_DT from ARC_REC_UserCustomer where UserId in (select USERID from #trainees)  
  
delete from ARC_REC_UserCustomer where UserId in (select USERID from #trainees)  
              
insert into ARC_REC_UserCustomer(UserId,CustomerId,CREATED_BY,CREATED_DT)              
select USERID,@CUSTOMER_ID,@CREATED_BY,GETDATE() from #trainees   


update ARC_REC_USER_INFO set            
REPORTING_TO = @Reporting,            
CLIENT_ID = @CUSTOMER_ID,           
LastCustomerId = @CUSTOMER_ID       
where USERID in (select USERID from #trainees)  
   
    
--insert into ARC_REC_CustomerLog(UserId,CustomerId,CreatedBy,CreatedDt)    
--select USERID,@CUSTOMER_ID,@CREATED_BY,GETDATE() from #trainees   
  
  
update ARC_REC_InductionMaster set Trainee='N',TrainingCompleted=GETDATE(),  
TrainingCompletedBy=@CREATED_BY where  UserId in (select USERID  from #trainees )  
--select * from ARC_REC_Athena..ARC_REC_InductionMaster  
End 


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_TeamMovementUpdate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_TeamMovementUpdate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_TeamMovementUpdate] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_TeamMovementUpdate] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_TeamMovementUpdate] TO [DB_DMLSupport]
    AS [dbo];

