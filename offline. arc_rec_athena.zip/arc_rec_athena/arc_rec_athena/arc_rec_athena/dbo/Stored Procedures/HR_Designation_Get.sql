﻿CREATE PROCEDURE  [dbo].[HR_Designation_Get]          
as          
begin          
 /*          
  Created By : UdhayaGanesh.p         
  Created Date : 30/08/2011          
  Purpose  : To fetch the active designations    
  Sample   :  HR_Designation_Get           
 */       
      
 if exists(select 1 from dbo.HR_Designation where status  = 1)           
 begin        
  select 0 as 'DesigId', '-Select-' as 'Designation'          
  union all          
  select DesigId, Designation from dbo.HR_Designation where status  = 1           
  order by Designation           
 end        
 else        
 begin        
  select 0 as 'DesigId', '-No records-' as 'Designation'          
 end        
         
end 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_Designation_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_Designation_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_Designation_Get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_Designation_Get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_Designation_Get] TO [DB_DMLSupport]
    AS [dbo];

