﻿CREATE PROCEDURE [dbo].[ARC_APPLYONLINERESUME_INSERT]
(@POSITIONID INT
,@Name VARCHAR(150)
,@Address VARCHAR(300)
,@Phone VARCHAR(20)
,@Email VARCHAR(50)
,@FileName VARCHAR(100)
,@Comments varchar(8000)
,@CreatedIP varchar(50)
)
AS
SET NOCOUNT ON
BEGIN
		DECLARE @FILEID INT
		DECLARE @FilePath VARCHAR(150)
		SET @FilePath='D:\ARC_HR_ApplyOnline\Upload\'+CONVERT(VARCHAR,GETDATE())+'\'+@FileName
		BEGIN
			INSERT INTO ARC_ResumeFilesDtls(FileName,FilePath,Status)
			SELECT @FileName,@FilePath,1
			SET @FILEID = IDENT_CURRENT ('ARC_ResumeFilesDtls') 
			INSERT INTO ARC_ApplyOnlineDtls(POSITIONID,Name,Address,Phone,Email,FileID,Comments,CreatedIP,Status,CreatedDt)
			SELECT @POSITIONID,@Name,@Address,@Phone,@Email,@FILEID,@Comments,@CreatedIP,1,GETDATE()
		END
END




GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_APPLYONLINERESUME_INSERT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_APPLYONLINERESUME_INSERT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_APPLYONLINERESUME_INSERT] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_APPLYONLINERESUME_INSERT] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_APPLYONLINERESUME_INSERT] TO [DB_DMLSupport]
    AS [dbo];

