﻿ CREATE Proc ARC_Lounge_Message_Like_Ins      
 @Msgid int,      
 @NT_Username Varchar(100)      
 /*       
 CreatedBy : Udhayaganesh.p      
 Purpose   : Associate Like Comments to be accounted      
       
 Execution : Exec ARC_Lounge_Message_Like_Ins 2455,'gggffff.m'     
     
 exec ARC_Lounge_Message_Like_Ins @Msgid=2453,@NT_Username=N'varunnair.m '     
       
 */      
 As      
 Begin      
 if not Exists(select top 1 'x' from ARC_Forum_Lounge_Message_Likes where LikedBy=@NT_Username and MsgId=@Msgid and Status=1)      
 Begin      
 Insert into ARC_Forum_Lounge_Message_Likes(MsgId,LikedBy,LikedOn,Status)      
 Values(@Msgid,@NT_Username,GETDATE(),1)      
 Select COUNT(*) LikeCount,1'likes',MsgId from ARC_Forum_Lounge_Message_Likes where MsgId=@Msgid and Status=1 group by MsgId     
 End    
 End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Message_Like_Ins] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Like_Ins] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Like_Ins] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Message_Like_Ins] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Like_Ins] TO [DB_DMLSupport]
    AS [dbo];

