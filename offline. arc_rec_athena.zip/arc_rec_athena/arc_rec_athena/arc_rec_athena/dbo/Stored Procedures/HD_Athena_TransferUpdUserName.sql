﻿CREATE procedure [dbo].[HD_Athena_TransferUpdUserName]          
      @ReqId int          
      ,@UserId int             
      ,@CitrixUserName varchar(300)          
      ,@CitrixReqId varchar(50)    
      ,@HasCitrix char(1)        
      ,@UpdatedBy int      
      ,@Comments varchar(2000)  
As          
begin            
if @HasCitrix = 'Y' and @CitrixUserName <> ''        
  begin        
Update HD_Athena_Transfer set    
CitrixReqId = @CitrixReqId,  
CitrixUserName = @CitrixUserName,  
Comments = @Comments,        
Status = 3, -- processed status  
UpdatedBy = @UpdatedBy,UpdatedDt = GETDATE()   
where ReqId = @ReqId  and UserId = @UserId         
end        
else if @HasCitrix = 'N'       
begin        
Update HD_Athena_Transfer set    
Comments = @Comments,Status = 3,-- processed status  
UpdatedBy = @UpdatedBy,UpdatedDt = GETDATE()         
where ReqId = @ReqId  and UserId = @UserId           
end        
else
begin
    Update HD_Athena_Transfer set    
Comments = @Comments,Status = 3,-- processed status  
UpdatedBy = @UpdatedBy,UpdatedDt = GETDATE()         
where ReqId = @ReqId  and UserId = @UserId    
    end  
end

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_TransferUpdUserName] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_TransferUpdUserName] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_TransferUpdUserName] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_TransferUpdUserName] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_TransferUpdUserName] TO [DB_DMLSupport]
    AS [dbo];

