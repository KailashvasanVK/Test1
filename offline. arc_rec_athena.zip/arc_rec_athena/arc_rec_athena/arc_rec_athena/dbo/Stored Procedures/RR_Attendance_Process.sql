﻿CREATE Proc RR_Attendance_Process      
as      
;with AssociatePresent(Date,Day,Userid,NT_USername,P_days,IsDeclaredOff,PresentDays,Noofdays)      
As      
(      
select DATE,DATENAME(WEEKDAY,DATE) Day,UV.Userid,uv.Nt_Username,P_days,IsDeclaredOff,      
PresentDays=(Case when (isnull(P_days,0)+isnull(IsDeclaredOff,0))>1 
then 1 when isnull(P_days,0) = 0.5 and UA.LateIn <= 2 and UA.LateOut <= 2 and isnull(lr.ACTIVE,'') = 'Y' 
then 1  else (isnull(P_days,0)+isnull(IsDeclaredOff,0)) end),      
datediff(day,'2014-01-01','2014-04-01') Noofdays       
 from ARC_REC_Attendance  UA       
Inner JOIN ARC_REC_USER_INFO_VY UV on UV.userid=UA.userid  
left join ARC_REC_LEAVE_REQUEST LR on LR.CREATED_BY =uv.Userid 
and Convert(date,LR.FROMDATE) = UA.Date and lr.TYPEID = 5 and lr.LEAVE_STATUS = 1 and lr.ACTIVE = 'Y'      
where DATE>='2014-01-01'  and DATE<'2014-04-01'  
),      
AssociatePresent1 as      
(select Userid,NT_USername,SUM(PresentDays) Present,Noofdays from AssociatePresent Group by Userid,NT_USername,Noofdays )      
select Uv.Userid,Associate,Empcode,Designation,FunctionName,Reporting_to,Client_Name,Noofdays,Present 
from AssociatePresent1 AP       
inner join ARC_REC_USER_INFO_VY UV on Ap.Userid=UV.Userid      
where Present=Noofdays -- and uv.Userid =1656 
order by Associate


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Attendance_Process] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Attendance_Process] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Attendance_Process] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Attendance_Process] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Attendance_Process] TO [DB_DMLSupport]
    AS [dbo];

