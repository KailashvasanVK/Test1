﻿CREATE procedure ARC_REC_ProximityValidate
      @Proximity VARCHAR(MAX)  
As  
/*
 *  Purpose : To validate the proximity no is exists or not and  ui.ACTIVE not in [1,2]
 */
BEGIN  
 -- Declare @Proximity varchar(max)=N'1234567890-1234567891-123-2312123-1231231232-445446'
 Select Proxy.ProximityNo from ARC_REC_Proximity Proxy
 inner join ARC_REC_USER_INFO  UI on UI.EMPCODE = Proxy.EmpCode and ui.ACTIVE<>2 and ui.AHS_PRL='Y' 
 Where Proxy.ProximityNo in(Select items from dbo.fnSplitString(@Proximity,'-'))
END
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ProximityValidate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ProximityValidate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ProximityValidate] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ProximityValidate] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ProximityValidate] TO [DB_DMLSupport]
    AS [dbo];

