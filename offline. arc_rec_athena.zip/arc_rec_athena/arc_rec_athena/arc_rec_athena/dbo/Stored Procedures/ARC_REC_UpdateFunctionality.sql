﻿CREATE procedure ARC_REC_UpdateFunctionality  
     @Empcode varchar(100),  
     @NewFunctionalityId int,  
     @CreatedBy int  
As  
Begin  
INSERT INTO [ARC_REC].[dbo].[ARC_REC_USER_INFO_LOG] 
 
           (USERID,[FIRSTNAME]  
           ,[LASTNAME]  
           ,[NT_USERNAME]  
           ,[DESIGNATION_ID]  
           ,[FUNCTIONALITY_ID]  
           ,[REC_ID]  
           ,[CREATED_BY]  
           ,[CREATED_DT]  
           ,[REPORTING_TO]  
           ,[EMPCODE]  
           ,[ACTIVE]  
           ,[CLIENT_ID]  
           ,[DOJ]  
           --,[AHS_PRL]  
           ,[PreDoj]  
           ,[LastCustomerId]  
           ,[Password]  
           ,[EmailId]  
           ,[AccountType]  
           ,[ExtUser]  
           ,[UserName]  
           ,[FirstTrnDt])  
     select   
           USERID,FIRSTNAME,LASTNAME,NT_USERNAME,DESIGNATION_ID,FUNCTIONALITY_ID,  
           REC_ID,CREATED_BY,CREATED_DT,REPORTING_TO,EMPCODE,ACTIVE,CLIENT_ID,  
           DOJ,--AHS_PRL,  
           PreDoj,LastCustomerId,[Password],EmailId,AccountType  
           ,ExtUser,UserName,FirstTrnDt from ARC_REC_USER_INFO where EMPCODE = @Empcode  
             
             
    update ARC_REC_USER_INFO set  
    FUNCTIONALITY_ID = @NewFunctionalityId,  
    CREATED_BY = @CreatedBy  
    where EMPCODE = @Empcode  
End  
  
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_UpdateFunctionality] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UpdateFunctionality] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UpdateFunctionality] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_UpdateFunctionality] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UpdateFunctionality] TO [DB_DMLSupport]
    AS [dbo];

