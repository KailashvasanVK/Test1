﻿CREATE proc ARC_REC_LAshift_Insert                 
as                    
begin                  
declare @From datetime=convert(date,getdate()-1)                    
                      
select @From                    
              
insert into ARC_REC_Attendance(userid,nt_username,date,shiftid,Logon,Logout,TotalHrs,WorkHours,LockHrs,Designid,Functionalityid,Createdby,Createdon,CLIENT_ID)                    
select * from (                    
select distinct ui.userid,UI.NT_USERNAME,@From date,AI.Shiftid ,Ai.LoginDate,AI.Logout,isnull(Whours ,0) WorkHrs,isnull(Fhours,0)                 
TotalHrs,isnull(Hhours,0) LockHrs,UI.DESIGNATION_ID,UI.FUNCTIONALITY_ID,1 CBy,GETDATE() CON,CLIENT_ID                    
from ARC_REC_USER_INFO  UI                    
left join UL_Attendance AI on UI.NT_USERNAME =AI.UserAccount and   date=@From         
where AI.Shiftid =3 )  as udhaya                     
where USERID is not null and USERID not in (select USERID from ARC_REC_Attendance where date=@From)                     
                      
end 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_LAshift_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_LAshift_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_LAshift_Insert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_LAshift_Insert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_LAshift_Insert] TO [DB_DMLSupport]
    AS [dbo];

