﻿CREATE procedure dbo.HR_MD_MailId(@Userid int, @Mprid int)                  
as                
/*                
   
 udhayaganesh.p  
   
 select * from Mrplogin  
   
 select * from HR_Mpr  
   
 HR_MD_MailId 1,262  
               
                
*/                  
begin                  
 Declare @FromMailid varchar(256), @ToMailid varchar(256), @MPRBy int, @Appby int                  
 Declare @RaisedEmpid int, @RaisedNAaid int, @RaisedAssessorid int              
 Declare @ApprovedEmpid int, @ApprovedNAaid int, @ApprovedAssessorid int              
 Declare @RaisedBy varchar(256), @ApprovedBy varchar(256)              
              
 SELECT @FromMailid = Mailid from Mrplogin WHERE UserId = @Userid              
              
 IF @FromMailid IS NULL                  
 SET @FromMailid = 'Udhayaganesh.p@laurusedutech.com'                  
                  
 SELECT @MPRBy = CreatedBy , @Appby = MDApprovedBy from HR_Mpr where mprid = @Mprid                  
 SELECT @ToMailid = mailid from Mrplogin WHERE UserId = @MPRBy    
   
 SELECT @ApprovedBy = username from Mrplogin WHERE UserId = @Appby      
   
 SELECT @RaisedBy = username from Mrplogin WHERE UserId = @MPRBy              
               
                  
 select @FromMailid as fromid, @ToMailid as toid, @ApprovedBy as ApprovedBy, @RaisedBy as MPRBy                 
              
end 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_MD_MailId] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MD_MailId] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MD_MailId] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_MD_MailId] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MD_MailId] TO [DB_DMLSupport]
    AS [dbo];

