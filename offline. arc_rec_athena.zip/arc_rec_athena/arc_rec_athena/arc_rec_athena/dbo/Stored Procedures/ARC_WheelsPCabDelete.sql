﻿Create proc ARC_WheelsPCabDelete
(
@Action varchar(10)
)
As
Begin
if @Action = 'Pickup'
	DELETE FROM ARC_WheelsCabPickup;      
else 
	DELETE FROM ARC_WheelsCabDrop;  
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_WheelsPCabDelete] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_WheelsPCabDelete] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_WheelsPCabDelete] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_WheelsPCabDelete] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_WheelsPCabDelete] TO [DB_DMLSupport]
    AS [dbo];

