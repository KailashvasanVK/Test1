﻿CREATE Procedure [dbo].[ARC_REC_RoleTranInsert_Test]  
@RoleId int,    
@MenuId varchar(max) ,    
@CREATED_BY int,    
@RoleRead tinyint = 0,    
@RoleWrite tinyint = 0    
As    
/*    
Purpose    : To store the user role and menu details in to ARC_REC_RoleTran       
Impact to  : RoleCreation.aspx        
Created by : Karthik Ic            
Created on : 09 april 2013    
*/    
/*  
-- for New RoleConfig form details   
*/         
Begin  
if exists(Select COUNT(MenuId) from ARC_REC_RoleTran where RoleId = @RoleId )  
 begin  
  INSERT INTO  ARC_REC_RoleTranLog (  RoleId,MenuId,RoleRead,RoleWrite,CREATED_BY,CREATED_DT )  
  Select RoleId,MenuId,RoleRead,RoleWrite,CREATED_BY,CREATED_DT from ARC_REC_RoleTran  WHERE RoleId = @Roleid   
  Delete  from ARC_REC_RoleTran  WHERE RoleId = @Roleid   
 End  
 Insert into ARC_REC_RoleTran(RoleId,MenuId,RoleRead,RoleWrite,CREATED_BY)  
 Select @RoleId,items,1,0,@CREATED_BY  from dbo.fnSplitString(@MenuId,',')   
 /*  
--------------- Insert new data into ARC_REC_RoleTran table  ------------           
--Insert into ARC_REC_RoleTran(RoleId,MenuId,RoleRead,RoleWrite,CREATED_BY)    
--Select  @RoleId,@MenuId,@RoleRead,@RoleWrite,@CREATED_BY    
 */   
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_RoleTranInsert_Test] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_RoleTranInsert_Test] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_RoleTranInsert_Test] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_RoleTranInsert_Test] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_RoleTranInsert_Test] TO [DB_DMLSupport]
    AS [dbo];

