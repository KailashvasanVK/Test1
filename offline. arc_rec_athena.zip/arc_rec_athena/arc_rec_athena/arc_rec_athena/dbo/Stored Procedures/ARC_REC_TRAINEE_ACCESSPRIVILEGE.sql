﻿CREATE Proc ARC_REC_TRAINEE_ACCESSPRIVILEGE            
@NT_USERNAME Varchar(100)='udhayaganesh.p'            
as            
Begin            
Set Nocount on            
Select * from (            
select UI.Userid,UI.Associate ,UI.NT_username from ARC_REC_InductionMaster  IM            
Inner join ARC_REC_USER_INFO_VY UI on UI.Userid=IM.userid            
where Trainee='Y'            
Union            
select UI.Userid,UI.Associate ,UI.NT_username from  ARC_REC_USER_INFO_VY UI             
--where ( UI.FunctionalityId=9 or Ui.userid in (807,847,1448,1449)  )     
--union    
--select dISTINCT b.Userid,b.Associate ,b.NT_username from ARC_CBT a    
--iNNER jOIN ARC_REC_USER_INFO_VY b ON B.NT_UserName =A.data         
) as Trainee where NT_username=@NT_username -- and USERID in (807,847,1448)          
Set Nocount Off            
End       
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_TRAINEE_ACCESSPRIVILEGE] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_TRAINEE_ACCESSPRIVILEGE] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_TRAINEE_ACCESSPRIVILEGE] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_TRAINEE_ACCESSPRIVILEGE] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_TRAINEE_ACCESSPRIVILEGE] TO [DB_DMLSupport]
    AS [dbo];

