﻿--ARC_REC_ListReportingAssociates 495,'N'  
CREATE Procedure ARC_REC_ListReportingAssociates    
(    
@UserId int     
,@ListAllAssociates varchar(1)  
)    
As    
Begin    
if OBJECT_ID('Tempdb..#users') is not null drop table #users    
Create Table #users(UserId int,NtUserName varchar(75),ReportingTo varchar(75),Emp_Detail varchar(100),TeamCnt int,TeamInserted varchar(1) default 'N',Result int default 0)   
 if(@ListAllAssociates = 'Y')  
begin  
  
Insert into #users(UserId,NtUserName,ReportingTo,Emp_Detail,TeamCnt)    
Select UserId,NT_USERNAME,REPORTING_TO ,(ui.FIRSTNAME+' '+ui.LASTNAME+' > '+ DE.Designation+' > '+FU.FunctionName) AS EMP_DETAIL        
,(select COUNT(*) from ARC_REC_USER_INFO where REPORTING_TO = ui.NT_USERNAME) as TeamCnt    
from ARC_REC_USER_INFO as ui   
LEFT JOIN HR_DESIGNATION AS DE ON DE.DESIGID = UI.DESIGNATION_ID     
LEFT JOIN HR_FUNCTIONALITY AS FU ON FU.FunctionalityId = UI.FUNCTIONALITY_ID    
where REPORTING_TO = (select NT_USERNAME from ARC_REC_USER_INFO where USERID = @UserId )    
and ISNULL(AHS_PRL,'N') = 'Y' and ACTIVE = 1  
  
  
Declare @NtUserName varchar(75)    
while 1=1    
Begin    
if (Select COUNT(*) from #users where TeamCnt <> 0 and TeamInserted = 'N') = 0    
 Begin    
 break    
 End    
else    
 Select top 1 @NtUserName = NtUserName from #users where TeamCnt <> 0 and TeamInserted = 'N'     
 Insert into #users(UserId,NtUserName,ReportingTo,Emp_Detail,TeamCnt)    
 Select UserId,NT_USERNAME,REPORTING_TO,   
 (ui.FIRSTNAME+' '+ui.LASTNAME+' > '+ DE.Designation+' > '+FU.FunctionName) AS EMP_DETAIL    
 ,(select COUNT(*) from ARC_REC_USER_INFO where REPORTING_TO = ui.NT_USERNAME) as TeamCnt    
 from ARC_REC_USER_INFO as ui   
 LEFT JOIN HR_DESIGNATION AS DE ON DE.DESIGID = UI.DESIGNATION_ID     
LEFT JOIN HR_FUNCTIONALITY AS FU ON FU.FunctionalityId = UI.FUNCTIONALITY_ID    
 where ui.REPORTING_TO = @NtUserName    
 and ISNULL(AHS_PRL,'N') = 'Y' and ACTIVE = 1  
 Update #users set TeamInserted = 'Y' where NtUserName = @NtUserName    
End    
  
end  
    
  
Insert into #users(UserId,NtUserName,ReportingTo,Emp_Detail,TeamCnt,Result)    
Select UserId,NT_USERNAME,REPORTING_TO ,(ui.FIRSTNAME+' '+ui.LASTNAME+' > '+ DE.Designation+' > '+FU.FunctionName) AS EMP_DETAIL        
,(select COUNT(*) from ARC_REC_USER_INFO where REPORTING_TO = ui.NT_USERNAME) as TeamCnt,1    
from ARC_REC_USER_INFO as ui   
LEFT JOIN HR_DESIGNATION AS DE ON DE.DESIGID = UI.DESIGNATION_ID     
LEFT JOIN HR_FUNCTIONALITY AS FU ON FU.FunctionalityId = UI.FUNCTIONALITY_ID    
where USERID = @UserId and ISNULL(AHS_PRL,'N') = 'Y' and ACTIVE = 1  
  
Select * from #users  order by Result desc  
End  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ListReportingAssociates] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ListReportingAssociates] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ListReportingAssociates] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ListReportingAssociates] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ListReportingAssociates] TO [DB_DMLSupport]
    AS [dbo];

