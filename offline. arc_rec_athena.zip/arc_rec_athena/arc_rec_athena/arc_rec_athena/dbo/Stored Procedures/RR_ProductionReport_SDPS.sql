﻿CREATE Proc RR_ProductionReport_SDPS      
@NT_UserName varchar(75)=NULL,      
@Eventdate varchar(40)=NULL,
@UserId int=0,
@Acheived float=0,
@Resultype tinyint=0,      
@AppType tinyint=0      
as      
Begin      

Declare @IdentityVal int     
    
Insert into RR_Production_Quality_Associate_Wise(EventDate,Customerid,Userid,Achived,Resulttype,Status,CreatedOn,AppType)       
values(@Eventdate,0,@UserId,@Acheived,@Resultype,      
1,GETDATE(),@AppType)     
    
set @IdentityVal=IDENT_CURRENT('RR_Production_Quality_Associate_Wise')     
    
/*  Logic of SDPS Points Upload */    
    
if @Resultype=1    
begin    
   
Insert into RR_SCOREBOARD(Userid,CID,Points,Status,CreatedOn,ReferenceInfo,ReferenceId,ModifiedOn)    
select uI.USERID,CID,Cm.POINTS,1,pqw.EventDate,'RR_Production_Quality_Associate_Wise',pqw.Id,GETDATE()    
FROM ARC_REC_Athena..ARC_REC_USER_INFO ui    
JOIN RR_Production_Quality_Associate_Wise PQW ON ui.USERID=PQW.Userid    
inner join RR_CRITERA_MASTER CM on CM.cid in (28,29)    
where PQW.Achived>=CM.startrange and PQW.Achived<=CM.endrange    
and PQW.Id=@IdentityVal    
end    
Else if @Resultype =2    
begin    
  
Insert into RR_SCOREBOARD(Userid,CID,Points,Status,CreatedOn,ReferenceInfo,ReferenceId,ModifiedOn)    
select uI.USERID,CID,Cm.POINTS,1,pqw.EventDate,'RR_Production_Quality_Associate_Wise',pqw.Id,GETDATE()    
FROM ARC_REC_Athena..ARC_REC_USER_INFO ui    
JOIN RR_Production_Quality_Associate_Wise PQW ON ui.USERID=PQW.Userid    
inner join RR_CRITERA_MASTER CM on CM.cid in (31,32)    
where PQW.Achived>=CM.startrange and PQW.Achived<=CM.endrange    
and PQW.Id=@IdentityVal    
  
end    
    
    
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_ProductionReport_SDPS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_ProductionReport_SDPS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_ProductionReport_SDPS] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_ProductionReport_SDPS] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_ProductionReport_SDPS] TO [DB_DMLSupport]
    AS [dbo];

