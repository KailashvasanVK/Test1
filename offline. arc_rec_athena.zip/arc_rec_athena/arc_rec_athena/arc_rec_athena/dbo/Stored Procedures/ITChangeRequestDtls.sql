﻿CREATE PROCEDURE dbo.ITChangeRequestDtls
AS
SET NOCOUNT ON
BEGIN
	Select  ROW_NUMBER() OVER (ORDER BY AITR.RequestId DESC) AS 'Sl_No',                    
	AITR.RequestId,RequestType=(case when RequestType=1 then 'New request' when RequestType=2 then 'Change request' end),                    
	FunctionName, RequestFrom=(case when RequestFrom=1 then 'Client' when RequestFrom=2 then 'Internal' end),                     
	AITR.CreatedBy,Priority,ApproveStatus,Supervisor,Description,    
	FIRSTNAME +' '+ LASTNAME as CreateName,ApprovedComments
	from                     
	ARC_REC_ITREQUEST AITR             
	inner join HR_Functionality HRF on AITR.FunctionId=hrf.FunctionalityId                    
	left join ARC_REC_USER_INFO ui on ui.userId=AITR.CreatedBy     
	LEFT join ARC_REC_ITREQUEST_SCHEDULE Sh ON SH.SCHID=AITR.SCHID                 
	where AITR.statusId=1 and AITR.ApprovedBy is not null
	and (Aitr.ApproveStatus <>'DisApprove' or  Aitr.ApproveStatus <>null)  

	union all            
	Select  ROW_NUMBER() OVER (ORDER BY AITR.RequestId DESC) AS 'Sl_No',                    
	AITR.RequestId,RequestType=(case when RequestType=1 then 'New request' when RequestType=2 then 'Change request' end),                    
	FunctionName, RequestFrom=(case when RequestFrom=1 then 'Client' when RequestFrom=2 then 'Internal' end),                     
	AITR.CreatedBy,Priority,ApproveStatus,Supervisor,Description,   
	FIRSTNAME +' '+ LASTNAME as CreateName,ApprovedComments
	from                     
	ARC_REC_ITREQUEST_history AITR             
	inner join HR_Functionality HRF on AITR.FunctionId=hrf.FunctionalityId                    
	left join ARC_REC_USER_INFO ui on ui.userId=AITR.CreatedBy    
	LEFT join ARC_REC_ITREQUEST_SCHEDULE Sh ON SH.SCHID=AITR.SCHID    
	where   AITR.statusId=1    and AITR.ApprovedBy is not null                  
	and (Aitr.ApproveStatus <>'DisApprove' or  Aitr.ApproveStatus <>null)  
	order by AITR.RequestId,AITR.ApproveStatus  
END	

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ITChangeRequestDtls] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ITChangeRequestDtls] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ITChangeRequestDtls] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ITChangeRequestDtls] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ITChangeRequestDtls] TO [DB_DMLSupport]
    AS [dbo];

