﻿CREATE PROCEDURE [dbo].[S1_TEST_INS]            
(            
 @AHS_RECID INT            
,@TEST_TYPE VARCHAR(1)    
,@CREATED_DT DATETIME    
,@RESULT INT    
,@SCOURE INT    
,@HAS_COMPLETED INT    
,@COMMENTS VARCHAR(MAX)         
,@TEST_ID INT OUTPUT            
)            
AS            
BEGIN  
if @AHS_RECID<>0  
begin            
INSERT INTO ARC_REC_TEST(REC_ID,TEST_TYPE,CREATED_DT,RESULT,SCORE,HAS_COMPLETED,COMMENTS)    
VALUES(@AHS_RECID,@TEST_TYPE,@CREATED_DT,@RESULT,@SCOURE,@HAS_COMPLETED,@COMMENTS)            
SELECT @TEST_ID = IDENT_CURRENT('ARC_REC_TEST')     
end    
else   
begin  
set @TEST_ID=0  
end  
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[S1_TEST_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[S1_TEST_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[S1_TEST_INS] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[S1_TEST_INS] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[S1_TEST_INS] TO [DB_DMLSupport]
    AS [dbo];

