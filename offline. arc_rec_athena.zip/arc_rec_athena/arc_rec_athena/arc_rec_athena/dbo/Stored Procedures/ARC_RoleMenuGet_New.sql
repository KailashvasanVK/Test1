﻿CREATE Procedure ARC_RoleMenuGet_New
@UserId int ,
@Action varchar(50) = '',
@FileName Varchar(50) = ''
As
/*
Created by : Karthik Ic
Created on : 13 june 2014
Impact to  : FlowIndex.aspx
Purpose    : To get the role based menu for the user and application 

exec ARC_RoleMenuGet_New @UserId=15,@Action=N'FlowIndex.aspx'
exec ARC_RoleMenuGet_New @UserId=15,@Action=N'FlowIndex.aspx',@FileName ='CustomerCreation.aspx'
exec ARC_RoleMenuGet_New @UserId=7,@Action=N'FlowIndex.aspx',@FileName ='ProfileSetUpTest.aspx'
exec ARC_RoleMenuGet_New @UserId=874,@Action=N'FlowIndex.aspx',@FileName=N'ProfileSetUpTest.aspx'
*/
Begin


--dECLARE @UserId int = 13 ,
--@Action varchar(50) = 'report.aspx',
--@FileName Varchar(50) = ''
/*************************    Get the Role id  *****************************************/	
if OBJECT_ID('tempdb..#GetRoleDetails') is not null drop table #GetRoleDetails
Create table #GetRoleDetails (RoleId int)
Begin
	  insert into #GetRoleDetails (RoleId)	 
	  Select RoleId from ARC_REC_UserRole Where UserId in( @userid)
 End  
/*************************    Get the Menu Based on Roleid   *****************************************/
if OBJECT_ID('tempdb..#AccessMenus') is not null drop table #AccessMenus

Select MenuDisplayText,case when Isnull(OutputPath,'') = '' then MenuFileName else OutputPath end as OutputPath,
LogoFilePath,MenuFileName,Boxno,MenuParentId,isnull(MenuDescription,'') as Description,asm.MenuId
INTO #AccessMenus
From ARC_Setup_Menu  ASM
inner join ARC_REC_RoleTran  ART on ASM.MenuId =  ART.MenuId and ART.RoleId in(select  distinct(RoleId ) from #GetRoleDetails)
inner join ARC_REC_USER_INFO as ui on ui.USERID in( @UserId)
Where MenuParentId in (Select MenuId from ARC_Setup_Menu Where MenuFileName = @Action)
and MenuFileName = (case when isnull(@FileName,'')='' then  MenuFileName else @FileName end)
group by MenuDisplayText,OutputPath,LogoFilePath,MenuFileName,Boxno,MenuParentId,MenuDescription,asm.MenuId
 
 
 

declare @boxno int
declare @inc int
Set @inc = 1
Declare cur cursor
for Select boxno from #AccessMenus where boxno = 0
open cur
while 1=1
begin
fetch next from cur into @boxno
if @@FETCH_STATUS = -1 break
while 1=1
 begin
 print @inc
 if (select COUNT(*) from #AccessMenus where Boxno = @inc)>0
 set @inc += 1
 else
 break
 end
Update #AccessMenus set Boxno = @inc where current of cur
end
close cur
deallocate cur
--Select * from #AccessMenus  
Select * from #AccessMenus    where MenuFileName not in( @Action)
Drop table #AccessMenus 
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_RoleMenuGet_New] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_RoleMenuGet_New] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_RoleMenuGet_New] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_RoleMenuGet_New] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_RoleMenuGet_New] TO [DB_DMLSupport]
    AS [dbo];

