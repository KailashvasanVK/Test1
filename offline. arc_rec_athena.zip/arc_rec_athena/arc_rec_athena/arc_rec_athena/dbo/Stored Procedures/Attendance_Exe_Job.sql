﻿CREATE proc Attendance_Exe_Job   
as        
Begin        
declare @From datetime=convert(date,getdate()-1),@to datetime=convert(date,getdate())          
          
select @From,@to           
          
insert into UL_Attendance(UserAccount,Shiftid,UserFullName,LoginDate,Logout,WMin,Whours,HMin,Hhours,FMin,Fhours,Date)          
exec UserTrackingReport_new_job @from,@to          
          
end 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Attendance_Exe_Job] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Attendance_Exe_Job] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Attendance_Exe_Job] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Attendance_Exe_Job] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Attendance_Exe_Job] TO [DB_DMLSupport]
    AS [dbo];

