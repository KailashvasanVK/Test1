﻿CREATE procedure ARC_REC_AssociatesView        
  @SessionUserId int     
  ,@FunctionalityId int = 0        
  ,@DesignationId int = 0        
  ,@ClientId int = 0        
  ,@SearchStr varchar(max) =''        
  ,@SearchPattern varchar(5)='%'        
AS  
Begin        
--Declare  @SessionUserId int = 1    
--Declare  @FunctionalityId int = 0        
--Declare  @DesignationId int = 0        
--Declare  @ClientId int = 0        
--Declare  @SearchStr varchar(max) =''        
--Declare  @SearchPattern varchar(5)='%'        
Declare @sql as varchar(max)      
declare @IsHr as int    
select @IsHr = isnull((select COUNT(*) from ARC_REC_USER_INFO where USERID = @SessionUserId and FUNCTIONALITY_ID = 6),0)  --- check whether hr or not    
set @sql = '   SELECT         
    
/*CASE WHEN ISNULL(CA.PROFILE_IMAGE_NAME,'''') = '''' THEN         
''<img src="https://arc.accesshealthcare.co/arc_rec/Images/UserImg.jpg" height="60" width="60" />''                     
  ELSE ''<img src="https://arc.accesshealthcare.co/arc_rec/Images/Candidate/'' + CA.PROFILE_IMAGE_NAME+''" height="60" width="60" />'' END AS Associate                    
  */  
  ''''  as Associate  
  ,UI.REC_ID as [Recruitment Id],'  
    
      
  if convert(varchar,@IsHr) = 1    
 Set @sql += '''<div style="text-decoration:underline; cursor:pointer; color:#2A7FFF" onclick="LoadCandidateInfo(''+Convert(varchar,UI.REC_ID)+'');">View</div>'' as [Profile],'    
  else    
Set @sql += ''''' as [Profile~Hide],'    
  
  Set @sql += ' ISNULL(EMPCODE,'''') AS Empcode        
  ,UI.FIRSTNAME as Firstname,UI.LASTNAME as Lastname        
  ,UI.NT_USERNAME as [NT Username],UI.REPORTING_TO As [Reporting To]        
  ,DE.DESIGNATION AS Designation,FU.FunctionName AS Functionality        
  ,ISNULL(C.CLIENT_NAME,'''') AS Client                   
  ,CASE WHEN ISNULL(UI.DOJ,'''') = '''' THEN ''''                    
  ELSE CONVERT(VARCHAR,UI.DOJ,113) END AS Doj                    
 ,ISNULL(( SELECT TOP 1 SI.SHIFT_ID  FROM ARC_REC_SHIFT_TRAN T                    
  LEFT JOIN ARC_REC_SHIFT_INFO SI ON T.SHIFT_ID = SI.SHIFT_ID                     
  WHERE T.USERID = UI.USERID ORDER BY T.CREATED_DT DESC),'''') AS [SHIFT_ID~Hide]                   
  ,ISNULL(( SELECT TOP 1 SI.SHIFT_NAME FROM ARC_REC_SHIFT_TRAN T                  
  LEFT JOIN ARC_REC_SHIFT_INFO SI ON T.SHIFT_ID = SI.SHIFT_ID                  
  WHERE T.USERID = UI.USERID ORDER BY T.CREATED_DT DESC  ),'''') AS Shift        
   ,CASE WHEN UI.ACTIVE = 1 THEN ''Yes'' ELSE ''No'' END AS [Active Status]     
   ,isnull(case when CAN.GENDER = ''M'' then ''Male'' when CAN.GENDER = ''F'' then ''Female'' else '''' end,'''') as Gender   
  into #Associates            
  FROM ARC_REC_USER_INFO AS UI                  
  LEFT JOIN ARC_REC_CANDIDATE AS CA ON CA.REC_ID = UI.REC_ID       
  LEFT JOIN ARC_REC_CANDIATE_PROFILE AS CAN ON CAN.REC_ID = UI.REC_ID             
  LEFT JOIN HR_DESIGNATION AS DE ON DE.DESIGID = UI.DESIGNATION_ID                    
  LEFT JOIN HR_FUNCTIONALITY AS FU ON FU.FunctionalityId = UI.FUNCTIONALITY_ID                     
  LEFT JOIN ARC_REC_CustomerView C ON C.CLIENT_ID = UI.CLIENT_ID                    
  WHERE ISNULL(UI.AHS_PRL,''Y'') = ''Y''         
 '  if(@FunctionalityId > 0)        
 Set @sql = @sql + ' and UI.FUNCTIONALITY_ID ='+convert(varchar,@FunctionalityId)        
         
 if(@ClientId > 0)        
 Set @sql = @sql + ' and UI.CLIENT_ID ='+convert(varchar,@ClientId)        
         
 if(@DesignationId > 0)        
 Set @sql = @sql + ' and UI.DESIGNATION_ID ='+convert(varchar,@DesignationId)      
 
 print @sql  
 Set @sql = @sql + '        
 Exec FilterTable          
 @DbName = ''tempdb''          
 ,@TblName = ''#Associates''          
 ,@SearchStr = '''+@SearchStr+'''         
 ,@SearchPattern ='''+ @SearchPattern  +'''        
 ,@OrderStr = ''''        
 if OBJECT_ID(''tempdb..#Associates'') is not null drop table #Associates            
  '          
  print @sql  
 exec(@sql)           
     
End   
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_AssociatesView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AssociatesView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AssociatesView] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_AssociatesView] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AssociatesView] TO [DB_DMLSupport]
    AS [dbo];

