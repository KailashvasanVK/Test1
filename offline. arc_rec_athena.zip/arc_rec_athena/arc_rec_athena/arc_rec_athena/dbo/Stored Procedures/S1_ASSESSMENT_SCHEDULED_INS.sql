﻿CREATE PROCEDURE S1_ASSESSMENT_SCHEDULED_INS                                  
(                                  
@AHS_RECID INT                                  
,@INTERVIEWER_ID INT                                  
,@SC_DATE DATE                                  
,@SC_FROMTIME TIME                                  
,@SC_TOTIME TIME                                  
,@STATUS_ID INT                                  
,@CREATED_BY INT                                  
,@BATCH_NO INT            
,@AHS_SCHEDULEDID varchar(10) OUTPUT                               
)                                  
AS                                  
BEGIN                                 
                      
if not exists (select top 1 'x' from ARC_REC_ASSESSMENT_SCHEDULED where rec_id =@AHS_RECID and INTERVIEWER_ID =1666 )              
Begin              
              
INSERT INTO ARC_REC_ASSESSMENT_SCHEDULED                            
(REC_ID,INTERVIEWER_ID,SC_DATE,SC_FROMTIME,SC_TOTIME,STATUS_ID,BATCH_NO,CREATED_BY)                            
VALUES(@AHS_RECID,@INTERVIEWER_ID,@SC_DATE,@SC_FROMTIME,@SC_TOTIME,@STATUS_ID,@BATCH_NO,1666 )              
          
SET @AHS_SCHEDULEDID =CONVERT(varchar(10), IDENT_CURRENT('ARC_REC_ASSESSMENT_SCHEDULED')      )    
                  
End 
else
begin
select  @AHS_SCHEDULEDID =SCHEDULE_ID  from ARC_REC_ASSESSMENT_SCHEDULED  where REC_ID =@AHS_RECID and SC_DATE =@SC_DATE and BATCH_NO =@BATCH_NO and CREATED_BY =@CREATED_BY

end                
                     
END   
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[S1_ASSESSMENT_SCHEDULED_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[S1_ASSESSMENT_SCHEDULED_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[S1_ASSESSMENT_SCHEDULED_INS] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[S1_ASSESSMENT_SCHEDULED_INS] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[S1_ASSESSMENT_SCHEDULED_INS] TO [DB_DMLSupport]
    AS [dbo];

