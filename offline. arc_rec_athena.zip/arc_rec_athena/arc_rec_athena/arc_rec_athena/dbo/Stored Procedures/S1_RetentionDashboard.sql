﻿Create Procedure S1_RetentionDashboard    
(      
@MYStart date=null,      
@MYEnd date=null    
)      
As      
/*      
      
Exec S1_RetentionDashboard @MYStart='2012/01/01',@MYEnd='2013/12/30'      
      
*/      
Begin    

Declare @3Month date,@6month date
  
if @MYStart is null and @MYEnd is null  
begin  
set @MYStart=convert(varchar(20),DATEPART(year,getdate()))+'-'+'01-01'    
set @MYEnd=convert(varchar(20),DATEPART(year,getdate()))+'-'+'12-31'    
end  

set @3Month=DATEADD(month,4,@MYStart)
set @6month=DATEADD(month,7,@MYStart)

print @3Month
print @6month
print @MYStart   
print @MYEnd   

Create Table #Retension
(
id int identity(1,1) Constraint PKY_ID_Ren Primary Key ,
YMonth  Varchar(20),
[Number of candidates joined AHS] int default(0),   
[Attrition within 3 months] int default(0),   
[Attrition within 6 months] int default(0),   
[Total attrition] int default(0),
[Continuing beyond 6 months] int default(0),
[DMonth] int
)
  
 insert into #Retension(YMonth,[Number of candidates joined AHS],[Attrition within 3 months],[Attrition within 6 months],[Total attrition],[Continuing beyond 6 months],DMonth)
Select YMonth,    
sum(isnull([Number of candidates joined AHS],0)) [Number of candidates joined AHS] ,    
sum(isnull([Attrition within 3 months],0)) [Attrition within 3 months],
sum(isnull([Attrition within 6 months],0)) [Attrition within 6 months],
[Total attrition]=sum(isnull([Attrition within 3 months],0))+sum(isnull([Attrition within 6 months],0)),
[Continuing beyond 6 months]=sum(isnull([Number of candidates joined AHS],0))-sum(isnull([Attrition within 3 months],0))-sum(isnull([Attrition within 6 months],0)),
DMonth
 from (              
              
SELECT  'YMonth'= DATENAME(MONTH,arc.CREATED_DT),   
'DMonth'= datepart(MONTH,arc.CREATED_DT),            
[Number of candidates joined AHS] = SUM(CASE WHEN (ARA.ASSESS_MODE = 'S' and ARA.APPLICANT_STATUS='S')     
OR (ARA.ASSESS_MODE='S' and ARA.APPLICANT_STATUS='H') THEN 1 ELSE 0 END), 
'Attrition within 3 months'=(select count(*) from ARC_REC_RESIGN R where R.REC_ID  =ARC.rec_id
and RESIGN_DATE>=@MYStart and RESIGN_DATE<@3Month),
'Attrition within 6 months'=(select count(*) from ARC_REC_RESIGN R where R.REC_ID  =ARC.rec_id
and RESIGN_DATE>=@MYStart and RESIGN_DATE<@3Month and RESIGN_DATE<@6Month),
'Continuing beyond 6 months'=0
FROM Arc_Rec_Candidate ARC              
left join Arc_Rec_Assessment ARA on ARC.REC_ID=ARA.REC_ID             
where convert(date,ARC.CREATED_DT) between @MYStart and @MYEnd             
group by MONTH(arc.CREATED_DT),DATENAME(MONTH,arc.CREATED_DT),ARC.REC_ID    
) as Subquery       
group by YMonth,DMonth
order by DMonth  

select * from #Retension

drop table #Retension
      
End   
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[S1_RetentionDashboard] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[S1_RetentionDashboard] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[S1_RetentionDashboard] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[S1_RetentionDashboard] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[S1_RetentionDashboard] TO [DB_DMLSupport]
    AS [dbo];

