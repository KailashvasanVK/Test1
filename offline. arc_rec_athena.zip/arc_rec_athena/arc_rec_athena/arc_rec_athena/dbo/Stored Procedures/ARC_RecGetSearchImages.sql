﻿
Create Proc ARC_RecGetSearchImages 
(  
@Name varchar(30)=NULL,@ContactNo varchar(15)=NULL,@RecId varchar(15)=NULL  
)  
--exec ARC_RecGetSearchImages '','9841348',''
as  
Begin  
Declare @Qry varchar(max)  
Set @Qry=''  
Set @Qry='Select * from ARC_REC_CANDIDATE where 1=1 '   
  
if @Name <> ''  
Set @Qry+= ' and Name like '''+@Name + '%'''  
  
if @ContactNo <> ''  
Set @Qry+=' and ContactNo like '''+@ContactNo + '%'''  
  
if @RecId <> ''  
Set @Qry +=' and Rec_Id like '''+ @RecId + '%'''  

Set @Qry +=' order by Name asc'  
Exec (@Qry)   
End  

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_RecGetSearchImages] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_RecGetSearchImages] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_RecGetSearchImages] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_RecGetSearchImages] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_RecGetSearchImages] TO [DB_DMLSupport]
    AS [dbo];

