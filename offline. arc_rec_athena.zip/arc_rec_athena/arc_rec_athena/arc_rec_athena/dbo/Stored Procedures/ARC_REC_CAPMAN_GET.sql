﻿CREATE Proc ARC_REC_CAPMAN_GET                          
(                          
@FacilityId int,                  
@Shiftid tinyint=1                        
)                          
As                          
/*   ARC_REC_CAPMAN_GET 1 ,3                     
                  
exec ARC_REC_CAPMAN_GET @FacilityId=2,@Shiftid=3  


select * from ARC_REC_SHIFT_INFO           

exec ARC_REC_CAPMAN_GET @FacilityId=2,@Shiftid=5   

BayNo	BayIP	CLIENT_NAME	BayStatus	CreatedBy	ColorCode	Functionality	SHIFT_NAME
145	172.19.6.21	Los Angeles	1	prince.jesudoss 	#36648b	Revenue Cycle	Shift 3
145	172.19.6.21	Pacific	1	sanjeev.britto 	#cd1076	Billing					Shift 1
146	172.19.6.22	Los Angeles	1	prince.jesudoss 	#36648b	Revenue Cycle	Shift 3
                  
              */                          
                          
Begin                          
if @Shiftid in(1,4,11)            
begin                  
select distinct a.BayId,b.BayNo,a.BayIP,c.CLIENT_NAME,a.BayStatus,a.CreatedBy,isnull(lower(cc.ColorCode),'#ff8c00') ColorCode,          
F.JobTitle Functionality,SI.SHIFT_NAME          
from ARC_REC_CAPMAN A inner join Eye_IPDetails B on b.Id =a.BayId and a.Facilityid =b.Facilityid                           
Left join ARC_FIN_CLIENT_INFO C on c.CLIENT_ID =a.ClientID                          
left join ARC_CLIENT_COLORCODE cc on cc.clientId=c.CLIENT_ID          
left join HR_Functionality F on f.FunctionalityId = a.FunctionalityId           
INNER JOIN ARC_REC_SHIFT_INFO SI on SI.SHIFT_ID=A.Shiftid                  
where b.Facilityid =@FacilityId and b.Status =1 and a.Status=1             
and a.ShiftId in(1,4,11)            
order by a.BayId ,b.BayNo                
End             
Else if @Shiftid in(2,3,5)            
begin                  
select distinct a.BayId,b.BayNo,a.BayIP,c.CLIENT_NAME,a.BayStatus,a.CreatedBy,isnull(lower(cc.ColorCode),'#ff8c00') ColorCode,          
F.JobTitle Functionality,SI.SHIFT_NAME            
from ARC_REC_CAPMAN A inner join Eye_IPDetails B on b.Id =a.BayId and a.Facilityid =b.Facilityid                           
Left join ARC_FIN_CLIENT_INFO C on c.CLIENT_ID =a.ClientID                          
left join ARC_CLIENT_COLORCODE cc on cc.clientId=c.CLIENT_ID          
left join HR_Functionality F on f.FunctionalityId = a.FunctionalityId                     
INNER JOIN ARC_REC_SHIFT_INFO SI on SI.SHIFT_ID=A.Shiftid                  
where b.Facilityid =@FacilityId and b.Status =1 and a.Status=1             
and a.ShiftId in(2,3,5)            
order by a.BayId ,b.BayNo                
End                     
                          
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_GET] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_GET] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_GET] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_GET] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_GET] TO [DB_DMLSupport]
    AS [dbo];

