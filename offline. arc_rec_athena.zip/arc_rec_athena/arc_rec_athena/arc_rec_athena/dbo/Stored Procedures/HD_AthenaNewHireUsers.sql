﻿CREATE proc HD_AthenaNewHireUsers  
    @ReportingTo int  
AS  
Begin  
WITH DirectReports (UserId, Name, UserName, [Level])  
AS  
(  
-- Anchor member definition  
  
select USERID as UserId,NT_USERNAME as Name,NT_USERNAME as UserName,0 AS [Level] from ARC_REC_USER_INFO         
where ACTIVE = 1 and AHS_PRL = 'Y' and       
REPORTING_TO = (select NT_USERNAME from ARC_REC_USER_INFO where USERID = @ReportingTo) -- if any condition, will add in future.          
and isnull(NT_USERNAME,'') <> ''
and USERID not in (select UserId from HD_AthenaUsers where [Status] = 3)      
     
    UNION ALL  
-- Recursive member definition  
select ui.USERID  as UserId,ui.NT_USERNAME as Name,ui.NT_USERNAME as UserName,  
Level + 1  
from ARC_REC_USER_INFO ui    
INNER JOIN DirectReports d on d.UserName = ui.REPORTING_TO  
where ui.ACTIVE = 1 and ui.AHS_PRL = 'Y' and isnull(ui.NT_USERNAME,'') <> ''  
and ui.USERID not in (select UserId from HD_AthenaUsers where [Status] = 3)     
)  
-- Statement that executes the CTE  
SELECT UserId, Name, UserName,  [Level]  
FROM DirectReports  
order by Level  
--WHERE  Level = 0;  
  
End 


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_AthenaNewHireUsers] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_AthenaNewHireUsers] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_AthenaNewHireUsers] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_AthenaNewHireUsers] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_AthenaNewHireUsers] TO [DB_DMLSupport]
    AS [dbo];

