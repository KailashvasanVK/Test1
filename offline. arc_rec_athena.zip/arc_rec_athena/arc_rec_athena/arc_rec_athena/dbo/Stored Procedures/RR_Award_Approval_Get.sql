﻿CREATE Proc [dbo].[RR_Award_Approval_Get]      
@userid int=847      
as      
Begin      
Declare @Reporintto varchar(100)      
      
select @Reporintto=NT_username from ARC_REC_USER_INFO where USERID=@userid      
    
   
 select Appid,Award,    
  Nominate =(case when len(Nominate)>20 then convert(varchar,SUBSTRING(Nominate,1,20))+'...' else Nominate end),Nominee    
 ,Comments=(case when len(Comments)>5 then SUBSTRING(Comments,1,5)+'...' else Comments end),Comment    
 ,NominateBy  into #temp from     
 (     
      
select RA.AppId,rcm.NAME Award,    
Nominate=(SELECT STUFF(( select distinct                            
','  +convert(varchar(100), UI.FIRSTNAME+' '+UI.LASTNAME )                                            
from  ARC_REC_USER_Info UI       
inner join RR_Appreciation_Users AU on UI.NT_USERNAME=au.NT_USERNAME      
where Au.AppId=ra.AppId      
FOR XML PATH('')), 1, 1, '')),    
Nominee=(SELECT STUFF(( select distinct                            
','  +convert(varchar(100), UI.FIRSTNAME+' '+UI.LASTNAME )                                            
from  ARC_REC_USER_Info UI       
inner join RR_Appreciation_Users AU on UI.NT_USERNAME=au.NT_USERNAME      
where Au.AppId=ra.AppId      
FOR XML PATH('')), 1, 1, '')),    
Ra.Comments ,Ra.Comments as Comment,NominateBy= ACUI.FIRSTNAME+' '+ACUI.LASTNAME from RR_Appreciation RA      
inner join RR_CRITERA_MASTER RCM on RCM.CID=Ra.Awardid      
inner join ARC_REC_USER_INFO ACUI on Acui.USERID=ra.CreatedBy      
where RA.ApprovedStatus=0 and Ra.Approvedby is null and Ra.Awardid in(1,2,3,4) and ACUI.REPORTING_TO=(case when @userid=807 then ACUI.REPORTING_TO else @Reporintto  end)  
    
) as seena    
    
select Appid,Award,Nominate,Nominee,Comments,Comment,NominateBy from #temp 
where nominate is not null and nominee is not null   
    
    
    
      
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Award_Approval_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Award_Approval_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Award_Approval_Get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Award_Approval_Get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Award_Approval_Get] TO [DB_DMLSupport]
    AS [dbo];

