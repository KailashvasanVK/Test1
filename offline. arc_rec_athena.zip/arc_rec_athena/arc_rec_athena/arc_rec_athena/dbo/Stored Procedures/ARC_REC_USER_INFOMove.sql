﻿CREATE Procedure  [dbo].[ARC_REC_USER_INFOMove]  
 @USERID int  
,@FIRSTNAME varchar(50)              
,@LASTNAME varchar(50)              
,@Password varchar(15)              
,@EmailId varchar(75)  
,@CLIENT_ID int   
,@LastCustomerId int  
,@AccountType varchar(1)              
,@UserName varchar(100)              
	,@CREATED_BY int            
,@REC_ID int = 0            
,@NT_USERNAME varchar(1) = ' '
,@ACTIVE int =1
,@FirstTrnDt date = null
as         
/*        
 Purpose      : To move the user exists details to log table        
 Created By   : Karthik IC    
 Created Date : 18 June 2013    
 Impact to    : UserCreation.aspx    
*/        
Begin  
    Select @CREATED_BY = Created_By from ARC_REC_USER_INFO where USERID = @USERID
	Insert into ARC_REC_USER_INFO_Log (USERID,FIRSTNAME,LASTNAME,NT_USERNAME,DESIGNATION_ID,FUNCTIONALITY_ID,REC_ID,ACTIVE,CREATED_BY,CREATED_DT,  
	REPORTING_TO,EMPCODE,CLIENT_ID,DOJ,userName,Password,EmailId,AccountType,ExtUser,FirstTrnDt)  
	  
	Select USERID,FIRSTNAME,LASTNAME,NT_USERNAME,DESIGNATION_ID,FUNCTIONALITY_ID,REC_ID,ACTIVE,CREATED_BY,CREATED_DT,  
	REPORTING_TO,EMPCODE,CLIENT_ID,DOJ,userName,Password,EmailId,AccountType,ExtUser,FirstTrnDt
	From ARC_REC_USER_INFO where USERID = @USERID  
	--Delete From ARC_REC_USER_INFO where USERID = @USERID  

	update ARC_REC_USER_INFO set FIRSTNAME=@FIRSTNAME,LASTNAME=@LASTNAME,Password=@Password,EmailId=@EmailId,CLIENT_ID=@CLIENT_ID,
	LastCustomerId=@LastCustomerId,AccountType=@AccountType,UserName=@UserName,CREATED_BY=@CREATED_BY,REC_ID=@REC_ID,NT_USERNAME=@NT_USERNAME,ACTIVE=@ACTIVE,FirstTrnDt=@FirstTrnDt
	where USERID=@USERID and UserName=@UserName
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_USER_INFOMove] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_USER_INFOMove] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_USER_INFOMove] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_USER_INFOMove] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_USER_INFOMove] TO [DB_DMLSupport]
    AS [dbo];

