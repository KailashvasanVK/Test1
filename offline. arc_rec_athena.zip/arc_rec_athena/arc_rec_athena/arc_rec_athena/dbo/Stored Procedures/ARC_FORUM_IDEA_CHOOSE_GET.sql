﻿CREATE Proc ARC_FORUM_IDEA_CHOOSE_GET               
@FromDate Date=null,               
@ToDate Date=null               
As              
/*            
            
ARC_FORUM_IDEA_CHOOSE_GET @FromDate='2013-02-20' ,@ToDate='2013-12-12'            
            
*/             
Begin               
                
if @FromDate is null and @ToDate is null               
begin               
                
                
set @FromDate =CONVERT(VARCHAR(25),DATEADD(dd,-(DAY(GETDATE())-1),GETDATE() ),120)/* Current MONTH FIRSTDATE */                 
set @ToDate =dateadd(day,-1,DATEADD(MONTH,1,@FromDate))/* Current MONTH Lastdate */               
                
End             
                
select ROW_NUMBER() over(order by Id.IDEA_ID) as 'Sl_No', Id.IDEA_ID,IDEA_TEXT=case when len(IDEA_TEXT)>150 then SUBSTRING(IDEA_TEXT,1,150)+'...' else IDEA_TEXT end ,
IDEA_TEXT as IdeaText,UI.firstname+' '+Ui.lastname PostedBy,cI.Client_Name Client,      
Convert(varchar(11),ID.CREATED_ON,113) PostedOn    
from ARC_Forum_User_Ideas ID               
inner join ARC_REC_USER_info UI on UI.NT_username=ID.created_by 
inner join ARC_FIN_CLIENT_INFO CI on ci.CLIENT_ID=ui.CLIENT_ID               
where Convert(date,ID.CREATED_ON)>=@FromDate and Convert(date,ID.CREATED_ON)<=@ToDate               
and ID.status=0            
End   
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FORUM_IDEA_CHOOSE_GET] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_IDEA_CHOOSE_GET] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_IDEA_CHOOSE_GET] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FORUM_IDEA_CHOOSE_GET] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_IDEA_CHOOSE_GET] TO [DB_DMLSupport]
    AS [dbo];

