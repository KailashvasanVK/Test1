﻿CREATE procedure ARC_ME_NightShiftAllowanceView(  
@FromDate date  
,@ToDate date  
,@SessionUserId int  
,@FunctionalityID int/* Optional by default 0 if session user is normal or supervisor */  
,@ClientID int/* Optional by default 0 if session user is normal */  
,@UserId int /* Optional by default 1 if session user is normal */  
,@Active int  
,@SearchStr varchar(100) = ''  
,@SearchPattern varchar(4) = '=' /** = or % **/  
)  
As  
Begin  
Declare @Qry varchar(max)  
Declare @localdbserver varchar(25) = (Select CTL_VALUE from ARC_REC_SOFTCONTROL where CTL_ID = 'localdbserver')  
if OBJECT_ID ('tempdb..#attni8') is not null drop table #attni8  
Create Table #attni8 (Aid int,UserId int,[Date] date,Attendance varchar(100),CompOffEligible int,IsDeclaredOff int,OTEligible int,Present varchar(25),NotPresent varchar(25),LeaveType varchar(25))  
Set @Qry = '  
Insert into #attni8(Aid,UserId,[Date],Attendance,CompOffEligible,IsDeclaredOff,OTEligible,Present,NotPresent,LeaveType)  
SELECT Aid,UserId,[Date],Attendance,CompOffEligible,IsDeclaredOff,OTEligible,Present,NotPresent,LeaveType   
FROM  OPENROWSET(  
''sqloledb'',  
''Server='+@localdbserver+';Trusted_Connection=yes;''  
,''exec ARC_REC_Athena..ARC_ME_MonthlyAttendanceView  
 @FromDate = '''''+CONVERT(varchar,@FromDate)+'''''  
,@ToDate = '''''+CONVERT(varchar,@ToDate)+'''''  
,@SessionUserId = 19
,@FunctionalityID = '+CONVERT(varchar,@FunctionalityID)+'  
,@ClientID = '+CONVERT(varchar,@ClientID)+'  
,@Active = '+CONVERT(varchar,@Active) +'  
,@SupListAll=''''N''''  
,@UserId = '+CONVERT(varchar,@UserId)+'  
,@View = ''''DateWise'''''')  
'  
 print (@Qry)  
Exec (@Qry)  
  

if OBJECT_ID ('tempdb..#tempNightShiftAllowance') is not null drop table #tempNightShiftAllowance  
Select ui.EMPCODE as [EmpCode]  
,dbo.ConcatenateName(ui.firstname,ui.middlename,ui.lastname) as [Name]  
,func.FunctionName [Functionality],desig.Designation,ci.Client_Name [Client]   
,(select Shift_name from Arc_rec_shift_info where shift_id = (Select top 1 SHIFT_ID from ARC_REC_SHIFT_TRAN where USERID = attview.userid order by TID desc)) as CurrentShift  
,sum(att.P_days) as [Days]  
into #tempNightShiftAllowance
from #attni8  as attview  
inner join ARC_REC_Attendance as att on att.Aid = attview.aid  
inner join ARC_REC_SHIFT_INFO as shift on shift.SHIFT_ID = att.Shiftid and shift.NightShiftAllowance = 'Y'  
inner join ARC_REC_USER_INFO as ui on ui.USERID = att.Userid  
inner join HR_Functionality as func on func.FunctionalityId = ui.FUNCTIONALITY_ID  
inner join HR_Designation as desig on desig.DesigId = ui.DESIGNATION_ID  
inner join ARC_FIN_CLIENT_INFO as ci on ci.Client_Id = ui.CLIENT_ID  
where attview.present in ('full present')  /**,'half present'** removed half day not eligible**/
and attview.isDeclaredOff = 0  
group by attview.userid  
,func.FunctionName,desig.Designation,ci.Client_Name  
,ui.empcode,ui.firstname,ui.middlename,ui.lastname

Exec FilterTable
	@DbName = 'tempdb'
  ,@TblName = '#tempNightShiftAllowance'
  ,@SearchStr = @SearchStr
  ,@SearchPattern = @SearchPattern
  ,@OrderStr = ''
  if OBJECT_ID('tempdb..#tempNightShiftAllowance') is not null drop table #tempNightShiftAllowance
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_NightShiftAllowanceView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_NightShiftAllowanceView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_NightShiftAllowanceView] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_NightShiftAllowanceView] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_NightShiftAllowanceView] TO [DB_DMLSupport]
    AS [dbo];

