﻿CREATE Procedure RR_Reedem_Giftbag_get              
(              
@PID int,              
@LLID int,          
@userid int=0             
)              
As              
/*              

exec RR_Reedem_Giftbag_get @PID=14,@LLID=2,@userid=807 
        
*/              
Begin          
--set @userid = 807          
if exists (select 'x' from RR_Product_Details PD  where LLID=@LLID and pid in (select  Pid from RR_SCOREBOARD_PURCHASE where userid=@userid) )        
begin  
print 'first'      
if exists (select 'x' from RR_Product_Details PD  where LLID=@LLID and ImageType=1 and pid =@PID)        
begin        
print 'hi'        
select ROW_NUMBER() over(order by pid) Button ,* from (        
select top 2 Pid,LLID,ProductName,AboutProduct,Path='images/Reward/BG'+CONVERT(varchar(10),pid) +'.jpg',ImageType       
from RR_Product_Details where PurchasePoint>=(select PurchasePoint from RR_Product_Details where Pid=@PID and LLID=@LLID )      
 and ImageType =1 and LLID=@LLID  and  Pid not in (select Pid from RR_SCOREBOARD_PURCHASE where Userid =@userid) ) as Varun       
End        
else        
begin      
    
print 'hidefd'      
select ROW_NUMBER() over(order by pid) Button ,* from (        
select top 2 Pid,LLID,ProductName,AboutProduct,Path='images/Reward/BG'+CONVERT(varchar(10),pid) +'.jpg',ImageType from RR_Product_Details where PurchasePoint>(            
select PurchasePoint from RR_Product_Details where Pid=@PID and LLID=@LLID  ) and ImageType =1  and LLID=@LLID            
 and Pid not in (select Pid from RR_SCOREBOARD_PURCHASE where Userid =@userid)  ) as Varun        
        
        
end        
end        
        
Else         
begin       
if exists (select 'x' from RR_Product_Details PD  where LLID=@LLID and ImageType=1 and pid =@PID)        
begin     
select * from (           
select top 2 ROW_NUMBER() over(order by pid) Button,Pid,LLID,ProductName,AboutProduct,Path='images/Reward/BG'+CONVERT(varchar(10),pid) +'.jpg',ImageType from RR_Product_Details where PurchasePoint>=(            
select PurchasePoint from RR_Product_Details where Pid=@PID and LLID=@LLID  ) and ImageType =1  and LLID=@LLID            
union            
select  3,Pid,LLID,ProductName,AboutProduct,Path='images/Reward/BG'+CONVERT(varchar(10),pid) +'.jpg',ImageType from RR_Product_Details where LLID= @LLID and ImageType =2            
) as Varun where Pid not in (select Pid from RR_SCOREBOARD_PURCHASE where Userid =@userid)          
End    
else    
begin    
 print 'final'  
select * from (           
select top 2 ROW_NUMBER() over(order by pid) Button,Pid,LLID,ProductName,AboutProduct,Path='images/Reward/BG'+CONVERT(varchar(10),pid) +'.jpg',ImageType from RR_Product_Details where PurchasePoint>(            
select PurchasePoint from RR_Product_Details where Pid=@PID and LLID=@LLID and Status =1  ) and ImageType =1  and LLID=@LLID            
union            
select  3,Pid,LLID,ProductName,AboutProduct,Path='images/Reward/BG'+CONVERT(varchar(10),pid) +'.jpg',ImageType from RR_Product_Details where LLID= @LLID and ImageType =2            
) as Varun where Pid not in (select Pid from RR_SCOREBOARD_PURCHASE where Userid =@userid)    
end     
end       
end 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Reedem_Giftbag_get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Reedem_Giftbag_get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Reedem_Giftbag_get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Reedem_Giftbag_get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Reedem_Giftbag_get] TO [DB_DMLSupport]
    AS [dbo];

