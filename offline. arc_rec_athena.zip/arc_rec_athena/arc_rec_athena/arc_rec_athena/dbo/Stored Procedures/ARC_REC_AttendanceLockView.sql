﻿Create Procedure ARC_REC_AttendanceLockView
@SearchStr  varchar(20) = '',	
@SearchPattern  varchar(4) = '=' 
as 
Begin
if OBJECT_ID('tempdb..#tblAttendanceLock') is not null drop table #tblAttendanceLock
Select convert (varchar(20),PAY_ROLL_DATE,101)as [Closed Date], ui.NT_USERNAME as [Closed By] 
into #tblAttendanceLock
from ARC_ME_PAYROLL as PayRol
inner join ARC_REC_USER_INFO as ui on ui.USERID = PayRol.CREATED_BY

Declare @OrderStr varchar(100)
set @OrderStr=' Order by [Closed Date] desc'
Exec FilterTable 
@DbName = 'tempdb' 
,@TblName = '#tblAttendanceLock' 
,@SearchStr = @SearchStr 
,@SearchPattern = @SearchPattern 
,@OrderStr = @OrderStr 	
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_AttendanceLockView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AttendanceLockView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AttendanceLockView] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_AttendanceLockView] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AttendanceLockView] TO [DB_DMLSupport]
    AS [dbo];

