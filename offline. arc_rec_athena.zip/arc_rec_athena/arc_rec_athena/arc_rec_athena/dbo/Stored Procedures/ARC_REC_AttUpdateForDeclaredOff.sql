﻿
CREATE Proc ARC_REC_AttUpdateForDeclaredOff
(
@AttDate date = null
)
As
Begin
/**
Created By : Mohamed Safiyullah
Purpose : To mark declaredOff at the time of attendance generation
**/
if @AttDate is null and SYSTEM_USER = 'ACCESSHEALTHCAR\mohamedsafiyu.a'
	Begin	
	/** Need to mark for all days **/
	Update ARC_REC_Attendance Set IsDeclaredOff = 1 Where DATENAME(WEEKDAY,date) = 'Sunday'	
	Update ARC_REC_Attendance Set IsDeclaredOff = 
		case when DATENAME(WEEKDAY,att.date) = 'Saturday' and ui.FUNCTIONALITY_ID = 3 then 1 /** By default saturday is declared off for this functionality **/
			when DATENAME(WEEKDAY,att.date) = 'Saturday' and Shift.HOLIDAY_SAT = 'Y' then 1 /** By default saturday is declared off for this shift **/
			when DATENAME(WEEKDAY,att.date) = 'Saturday' and Shift.HOLIDAY_SAT = 'N' and Holiday.HOLIDAY_DATE IS NOT NULL then 1 /** Saturday is declared off for this shift **/
			when Holiday.HOLIDAY_DATE IS not null then 1
		else 0 end 
	from ARC_REC_Attendance as Att
	inner join ARC_REC_SHIFT_INFO as Shift on Shift.SHIFT_ID = isnull(att.Shiftid,1)
	inner join ARC_REC_USER_INFO as Ui on Ui.USERID = att.Userid
	left join ARC_REC_LEAVE_HOLIDAYLIST as Holiday on Holiday.HOLIDAY_DATE = Att.Date and Holiday.LISTTYPE = case when att.Functionalityid = 3 then 1 else Shift.HOLIDAY_LISTTYPE end
--	Where DATENAME(WEEKDAY,Att.date) = 'Saturday'	
	End
Else if @AttDate is not null
	Begin
	/** Need to mark for param day **/
	Update ARC_REC_Attendance Set IsDeclaredOff = 1 Where date = @AttDate and DATENAME(WEEKDAY,date) = 'Sunday'	
	Update ARC_REC_Attendance Set IsDeclaredOff = 
		case when DATENAME(WEEKDAY,att.date) = 'Saturday' and ui.FUNCTIONALITY_ID = 3 then 1 /** By default saturday is declared off for this functionality **/
			when DATENAME(WEEKDAY,att.date) = 'Saturday' and Shift.HOLIDAY_SAT = 'Y' then 1 /** By default saturday is declared off for this shift **/
			when DATENAME(WEEKDAY,att.date) = 'Saturday' and Shift.HOLIDAY_SAT = 'N' and Holiday.HOLIDAY_DATE IS NOT NULL then 1 /** Saturday is declared off for this shift **/
			when Holiday.HOLIDAY_DATE IS not null then 1
		else 0 end 
	from ARC_REC_Attendance as Att
	inner join ARC_REC_SHIFT_INFO as Shift on Shift.SHIFT_ID = isnull(att.Shiftid,1)
	inner join ARC_REC_USER_INFO as Ui on Ui.USERID = att.Userid
	left join ARC_REC_LEAVE_HOLIDAYLIST as Holiday on Holiday.HOLIDAY_DATE = Att.Date and Holiday.LISTTYPE = case when att.Functionalityid = 3 then 1 else Shift.HOLIDAY_LISTTYPE end
	Where Att.Date = @AttDate and DATENAME(WEEKDAY,date) <> 'Sunday'		
	End
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_AttUpdateForDeclaredOff] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AttUpdateForDeclaredOff] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AttUpdateForDeclaredOff] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_AttUpdateForDeclaredOff] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AttUpdateForDeclaredOff] TO [DB_DMLSupport]
    AS [dbo];

