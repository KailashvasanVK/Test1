﻿--HD_Stationery_Reports @ReportType='Delivered',@fromDate='2014-01-01',@toDate='2014-04-30'  
CREATE proc HD_Stationery_Reports      
    @ReportType varchar(15),  
    @fromDate date,  
    @toDate date  
    ,@SearchStr varchar(100) = '',                         
     @SearchPattern varchar(4) = '=' /** = or % **/       
As  
Begin  
declare @OrderStr varchar(100)   
--declare @Type char(1)='S'  
--declare @ReportType varchar(15)='Approved'  
--Declare @fromDate date = '2014-01-01'  
--Declare @toDate date = '2014-04-30'  
  
if OBJECT_ID('tempdb..#Support_StationeryTicketView') is not null drop table #Support_StationeryTicketView    
create table #Support_StationeryTicketView(ItemName varchar(100),Qty int,Quantity varchar(50) )  
/** Approved Items which is needs to Purchase **/  
if(@ReportType = 'Approved')  
Begin  
insert into #Support_StationeryTicketView(ItemName,Qty,Quantity)  
Select SItem.ItemName,Sum(SReq.Quantity) Qty,Sitem.Quantity   
from HD_StationeryRequest as SReq  
inner join HD_StatineryItemmaster SItem on SItem.ItemId = SReq.ItemId  
inner join HD_ISSUE_REQUEST as IReq on IReq.ISS_REQID = SReq.ISS_REQID and IReq.ACTIVE = 'Y'  
Where SReq.Status = 1 and Convert(date,SReq.ApprovedDt) between @fromDate and @toDate  
Group by SItem.ItemName, Sitem.Quantity   
 End  
  
/** Approved Items which is delivered **/  
else if (@ReportType = 'Delivered')  
begin  
insert into #Support_StationeryTicketView(ItemName,Qty,Quantity)  
Select SItem.ItemName,Sum(SReq.Quantity) Qty,Sitem.Quantity   
from HD_StationeryRequest as SReq  
inner join HD_StatineryItemmaster SItem on SItem.ItemId = SReq.ItemId  
inner join HD_ISSUE_REQUEST as IReq on IReq.ISS_REQID = SReq.ISS_REQID and IReq.ACTIVE = 'Y'  
Where SReq.Status in (3,5) and Convert(date,SReq.ApprovedDt) between @fromDate and @toDate  
Group by SItem.ItemName, Sitem.Quantity   
end  
SET @OrderStr  = ''              
Exec FilterTable         
@DbName = 'tempdb'                          
,@TblName = '#Support_StationeryTicketView'                          
,@SearchStr = @SearchStr                          
,@SearchPattern = @SearchPattern                          
,@OrderStr = @OrderStr                 
if OBJECT_ID('tempdb..#Support_StationeryTicketView') is not null drop table #Support_StationeryTicketView    
  
End  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Stationery_Reports] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Stationery_Reports] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Stationery_Reports] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Stationery_Reports] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Stationery_Reports] TO [DB_DMLSupport]
    AS [dbo];

