﻿Create Procedure ARC_REC_HeldNotJoinedReleased
       @REC_IDS varchar(Max),    
       @ReleasedBy int
       As
Begin
if OBJECT_ID('tempdb..#HeldAssociates') is not null drop table #HeldAssociates
create table #HeldAssociates(REC_ID int)      
Insert into #HeldAssociates(REC_ID)    
Select Convert(int,items) from dbo.fnSplitString(@REC_IDS,',')    
Where items <> ''

Update ARC_REC_HeldNotJoined Set ReleasedBy  =@ReleasedBy,ReleasedDt = GETDATE()
from ARC_REC_HeldNotJoined as held
inner join ARC_REC_USER_INFO as ui on ui.USERID = held.UserId
inner join #HeldAssociates as rec on rec.REC_ID = ui.REC_ID
End       
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_HeldNotJoinedReleased] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_HeldNotJoinedReleased] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_HeldNotJoinedReleased] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_HeldNotJoinedReleased] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_HeldNotJoinedReleased] TO [DB_DMLSupport]
    AS [dbo];

