﻿--HD_Facility_Reports @Type='S',@ReportType='Delivered',@fromDate='2014-01-01',@toDate='2014-04-30'
Create proc HD_Facility_Reports
				@Type char(1),
				@ReportType varchar(15),
				@fromDate date,
				@toDate date
As
Begin
--declare @Type char(1)='S'
--declare @ReportType varchar(15)='Approved'
--Declare @fromDate date = '2014-01-01'
--Declare @toDate date = '2014-04-30'
if @Type = 'S'
Begin
/** Approved Items which is needs to Purchase **/
if(@ReportType = 'Approved')
Begin
Select SItem.ItemName,Sum(SReq.Quantity) Qty,Sitem.Quantity 

from HD_StationeryRequest as SReq

inner join HD_StatineryItemmaster SItem on SItem.ItemId = SReq.ItemId

inner join HD_ISSUE_REQUEST as IReq on IReq.ISS_REQID = SReq.ISS_REQID and IReq.ACTIVE = 'Y'

Where SReq.Status = 1 and Convert(date,SReq.ApprovedDt) between @fromDate and @toDate

Group by SItem.ItemName, Sitem.Quantity 

 End

/** Approved Items which is delivered **/
else if (@ReportType = 'Delivered')
begin
Select SItem.ItemName,Sum(SReq.Quantity) Qty,Sitem.Quantity 
from HD_StationeryRequest as SReq
inner join HD_StatineryItemmaster SItem on SItem.ItemId = SReq.ItemId
inner join HD_ISSUE_REQUEST as IReq on IReq.ISS_REQID = SReq.ISS_REQID and IReq.ACTIVE = 'Y'
Where SReq.Status in (3,5) and Convert(date,SReq.ApprovedDt) between @fromDate and @toDate
Group by SItem.ItemName, Sitem.Quantity 
end
End
else if @Type = 'C'
Begin
Select dbo.ConcatenateName(ui.firstname,ui.middlename,ui.lastname) as [Name],cp.MOBILE_NO [MobileNo],case ISNULL(cp.GENDER,'') when 'M' then 'Male' when 'F' then 'Female' else '' end as Gender
,CReq.Place,Creq.LandMark,ci.Client_Name [Client],CReq.TravelTime
from HD_CabRequests as CReq
inner join HD_ISSUE_REQUEST as IReq on IReq.ISS_REQID = CReq.ReqId and IReq.ACTIVE = 'Y'
inner join ARC_REC_USER_INFO as Ui on ui.USERID = CReq.AssociateId
inner join ARC_FIN_CLIENT_INFO as ci on ci.Client_Id = ui.CLIENT_ID
left join ARC_REC_CANDIATE_PROFILE as cp on cp.REC_ID = ui.REC_ID
Where Convert(date,TravelDt) between @fromDate and @toDate and CReq.Status = 1

End
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Facility_Reports] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Facility_Reports] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Facility_Reports] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Facility_Reports] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Facility_Reports] TO [DB_DMLSupport]
    AS [dbo];

