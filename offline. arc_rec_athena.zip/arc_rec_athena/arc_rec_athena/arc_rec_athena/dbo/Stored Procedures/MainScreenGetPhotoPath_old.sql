﻿CREATE PROCEDURE dbo.MainScreenGetPhotoPath_old(@NTUsername VARCHAR(100))              
AS              
SET NOCOUNT ON              
/*=======================================================================================  
 Created By  : Mohan.G  
 Purpose   : it is fetch user details as well as get the photo details should be appear  
      in L1 Screen  
 Project   : Applogin Project  
 Page   : Index.aspx pagin in Page load event call  
============================================================================================*/  
BEGIN              
DECLARE @PATH VARCHAR(200)              
DECLARE @Firstname VARCHAR(MAX)                        
Declare @LastName VARCHAR(MAX)                        
DECLARE @IsSupervisor int     
Declare @CountryFlagPath varchar(200)               
DECLARE @USERID INT      
DECLARE @CLIENT_ID INT       
SELECT @PATH = 'https://arc.accesshealthcare.co/arc_rec/images/candidate/'+t2.PROFILE_IMAGE_NAME,                        
  @Firstname=FIRSTNAME,                        
  @LastName=LASTNAME,                 
  @USERID = T1.USERID,                    
  @IsSupervisor = ISNULL((SELECT COUNT(*) FROM ARC_REC_USER_INFO WHERE REPORTING_TO = @NTUsername),0),       
  @CLIENT_ID  = ISNULL(CLIENT_ID ,0),  
  @CountryFlagPath = case when ISNULL(FCount.CountryId,0) <> 0 and FCount.status = 1 then 'https://arc.accesshealthcare.co/applogin/images/CountryFlag/' + Convert(varchar,FCount.CountryId) + '.png' else '' end  
  FROM ARC_REC_USER_INFO t1              
  LEFT  JOIN ARC_REC_CANDIDATE t2 ON t1.REC_ID = t2.REC_ID                
  left join ARC_REC_FootballTeams as FTeam on FTeam.UserId = t1.USERID  
  left join ARC_REC_FootballCountries as FCount on FCount.CountryId = FTeam.CountryId  
  WHERE t1.NT_USERNAME = @NTUsername              
                      
                     
SELECT ISNULL(@PATH,'https://arc.accesshealthcare.co/arc_rec/images/userimg.jpg') AS ProfileImageName,    
Isnull(@Firstname,'First') AS Firstname,    
Isnull(@LastName,'Last') AS LastName,    
ISNULL(@USERID,0) AS USERID,    
isnull(@IsSupervisor,0) AS IsSupervisor    
,isnull(@CountryFlagPath,'') as CountryFlagPath  
END     
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[MainScreenGetPhotoPath_old] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MainScreenGetPhotoPath_old] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MainScreenGetPhotoPath_old] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[MainScreenGetPhotoPath_old] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MainScreenGetPhotoPath_old] TO [DB_DMLSupport]
    AS [dbo];

