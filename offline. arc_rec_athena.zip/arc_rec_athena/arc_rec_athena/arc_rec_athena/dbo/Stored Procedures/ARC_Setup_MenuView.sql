﻿CREATE procedure  [dbo].[ARC_Setup_MenuView]  
@USERID int = 21
as        
/*        
 Purpose    : To get the user menu details    
 Created by : Karthik Ic        
 Created on : 02 April 2013        
 Impact to : RoleTranConfig.aspx    
 Exec ARC_Setup_MenuView 20        
*/        
Begin        
Select MenuParentId,MenuDisplayText,MenuDescription, OutputPath,LogoFilePath,BaseFuntionality_Id,        
DisplayOrder,MenuFileName,Boxno,MenuId  From  ARC_Setup_Menu ASM         
inner join ARC_REC_USER_INFO ARUI on ASM.BaseFuntionality_Id  in(0,ARUI.FUNCTIONALITY_ID )  and  ARUI.USERID = @USERID        
order by DisplayOrder      
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Setup_MenuView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Setup_MenuView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Setup_MenuView] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Setup_MenuView] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Setup_MenuView] TO [DB_DMLSupport]
    AS [dbo];

