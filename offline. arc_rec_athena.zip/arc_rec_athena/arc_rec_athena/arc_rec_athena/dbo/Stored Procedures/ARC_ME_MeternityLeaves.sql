﻿CREATE PROCEDURE ARC_ME_MeternityLeaves
						@Location Char(1),	
						@FROM_DATE DATE
As
BEGIN
if @LOCATION = 'A' -- AHS
begin
	SELECT REPLACE(CONVERT(VARCHAR, @FROM_DATE, 106), ' ', '-') AS FROM_DATE
	,  REPLACE(CONVERT(VARCHAR, DATEADD(day,83,CONVERT(DATE,@FROM_DATE,101)), 106), ' ', '-') AS TO_DATE 
	 ,'84' AS METERNITY_LEAVE 
	 end
else
begin
	--Manila @LOCATION = 'M'
 SELECT REPLACE(CONVERT(VARCHAR, @FROM_DATE, 106), ' ', '-') AS FROM_DATE,REPLACE(CONVERT(VARCHAR, DATEADD(day,59,CONVERT(DATE,@FROM_DATE,101)), 106), ' ', '-') AS TO_DATE,
 '60' AS METERNITY_LEAVE           
  -- decide later whether its caesarien delivery or normal. if Ceasarien means it will be 78 calander days.   
end
	 
END

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_MeternityLeaves] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_MeternityLeaves] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_MeternityLeaves] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_MeternityLeaves] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_MeternityLeaves] TO [DB_DMLSupport]
    AS [dbo];

