﻿CREATE procedure ARC_FACILITY_GET
@NTUserName Varchar(75)=NULL     
         
AS          
Begin          
         
select Facilityid Tcid,EF.FacilityName+' - '+EF.LevelName TrainingCentre from Eye_Facility EF      
order by Facilityid    
    
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FACILITY_GET] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FACILITY_GET] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FACILITY_GET] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FACILITY_GET] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FACILITY_GET] TO [DB_DMLSupport]
    AS [dbo];

