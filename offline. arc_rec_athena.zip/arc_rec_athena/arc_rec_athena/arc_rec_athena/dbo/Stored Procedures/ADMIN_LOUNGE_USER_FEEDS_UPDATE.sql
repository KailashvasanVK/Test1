﻿CREATE PROCEDURE ADMIN_LOUNGE_USER_FEEDS_UPDATE             
@Id int=1,            
@Type tinyint=0,            
@Status tinyint=0,            
@Nt_username Varchar(30)=null            
As            
BEGIN               
            
/* @tpype 1= Message 2= Comments  @status =1 Release @status=2 Delete 

exec ADMIN_LOUNGE_USER_FEEDS_UPDATE @Id=4577,@Type=1,@Status=2,@Nt_username=N'udhayaganesh.p'

*/            
            
If @Type=1 and @status=1             
Begin            
Update ARC_Forum_Lounge_Message_Flags set Status =0,ModifiedOn=GETDATE(),ModifiedBy=@Nt_username where MsgId=@id             
Select 'Message Released Successfully' as output            
End            
Else IF @Type=1 and @status=2            
Begin            
Update ARC_Forum_Lounge_Messages set Status =3,ModifiedOn=GETDATE(),ModifiedBy=@Nt_username where id=@id             
Select 'Message Deleted Successfully' as output  
update RR_Scoreboard set Points =0,ReferenceInfo = ReferenceInfo +' - Deleted'+@Nt_username where referenceid=@id  and CID=16
          
End            
Else IF @Type=2 and @status=1            
Begin            
Update ARC_Forum_Lounge_Comment_Flags set Status =0,ModifiedOn=GETDATE(),ModifiedBy=@Nt_username where CmtId=@id             
Select 'Comment Released Successfully' as output            
End            
Else IF @Type=2 and @status=2            
Begin            
Update ARC_Forum_Lounge_Message_Comments set Status =3,ModifiedOn=GETDATE(),ModifiedBy=@Nt_username where id=@id             
Select 'Comment Deleted Successfully' as output            
End            
            
END  
  
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADMIN_LOUNGE_USER_FEEDS_UPDATE] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADMIN_LOUNGE_USER_FEEDS_UPDATE] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADMIN_LOUNGE_USER_FEEDS_UPDATE] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADMIN_LOUNGE_USER_FEEDS_UPDATE] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADMIN_LOUNGE_USER_FEEDS_UPDATE] TO [DB_DMLSupport]
    AS [dbo];

