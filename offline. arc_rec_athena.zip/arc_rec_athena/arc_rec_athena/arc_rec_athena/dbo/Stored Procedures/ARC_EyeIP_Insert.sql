﻿-- exec ARC_EyeIP_Insert @Id = 470,@BayNo ='1',@BayIP ='172.19.5.22',@Status = 1,@Facilityid =2,@ExtNo  ='189',@CreatedBy =1,@ErrMsg = ''
CREATE Proc ARC_EyeIP_Insert
(
@Id	int
,@BayNo	varchar(20)
,@BayIP	varchar(20) = null
,@Status	tinyint
,@Facilityid	int
,@ExtNo	varchar(10)  = null
,@CreatedBy	int
,@ErrMsg varchar(100) = '' OUTPUT
)
As
Begin
if @BayIP = ''
set @BayIP = null
if @ExtNo = ''
set @ExtNo = null


set  @ErrMsg = ''
if (Select COUNT(*) from Eye_IPDetails Where Facilityid = @Facilityid and BayNo = @BayNo) > 0
	Begin
	if (Select COUNT(*) from Eye_IPDetails Where Facilityid = @Facilityid and BayIP = @BayIP and BayNo <> @BayNo  and isnull(BayIP ,'') != '') > 0
		Begin		
			set @ErrMsg = 'BayIp ' + @BayIP + ' already assigned in BayNo : ' + (Select Top 1 BayNo from Eye_IPDetails Where Facilityid = @Facilityid and BayIP = @BayIP and BayNo <> @BayNo)		
		End
	Else if (Select COUNT(*) from Eye_IPDetails Where Facilityid = @Facilityid and ExtNo = @ExtNo and BayNo <> @BayNo and isnull(ExtNo,'') != '' ) > 0
		Begin
			set @ErrMsg = 'ExtNo ' + @ExtNo + ' already assigned in BayNo : ' + (Select Top 1 BayNo from Eye_IPDetails Where Facilityid = @Facilityid and ExtNo = @ExtNo and BayNo <> @BayNo)
		End
	Else
		Begin
			Insert into Eye_IPDetailsLog(Id,BayNo,BayIP,Status,Facilityid,CreatedBy,CreatedDt,ExtNo)
			Select Id,BayNo,BayIP,Status,Facilityid,CreatedBy,CreatedDt,ExtNo from Eye_IPDetails Where Facilityid = @Facilityid and BayNo = @BayNo
			Update Eye_IPDetails Set BayIP = @BayIP,ExtNo = @ExtNo,Status = @Status,CreatedBy = @CreatedBy,CreatedDt = GETDATE() Where Facilityid = @Facilityid and BayNo = @BayNo
		End
	End
Else
	Begin
		Insert into Eye_IPDetails(BayNo,BayIP,Status,Facilityid,CreatedBy,CreatedDt,ExtNo)
		Select @BayNo,@BayIP,@Status,@Facilityid,@CreatedBy,GETDATE(),@ExtNo 
	End
-- 	select isnull(@ErrMsg,'') 	 as Result
End



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_EyeIP_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_EyeIP_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_EyeIP_Insert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_EyeIP_Insert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_EyeIP_Insert] TO [DB_DMLSupport]
    AS [dbo];

