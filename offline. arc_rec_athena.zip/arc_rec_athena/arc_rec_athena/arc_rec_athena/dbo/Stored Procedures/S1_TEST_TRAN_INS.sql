﻿Create PROCEDURE S1_TEST_TRAN_INS         
(          
@AHS_TESTID INT          
,@QID INT          
,@RESULT VARCHAR(1)
,@CREATED_DT Datetime          
)          
AS          
BEGIN         
IF NOT EXISTS(SELECT top 1 'x' FROM ARC_REC_TEST_TRAN WHERE TEST_ID = @AHS_TESTID AND QID = @QID)       
 INSERT INTO ARC_REC_TEST_TRAN (TEST_ID,QID,RESULT,CREATED_DT)VALUES(@AHS_TESTID,@QID,@RESULT,@CREATED_DT)          
END   
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[S1_TEST_TRAN_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[S1_TEST_TRAN_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[S1_TEST_TRAN_INS] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[S1_TEST_TRAN_INS] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[S1_TEST_TRAN_INS] TO [DB_DMLSupport]
    AS [dbo];

