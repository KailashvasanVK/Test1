﻿CREATE Procedure [dbo].[RR_Award_Get]                             
(                            
@Userid int =353                            
)                          
/*                        
                        
Created By : Udhaya Ganesh                        
                        
Purpose : Based on Associate desination award will be load                        
                    
RR_Award_Get 489
                        
                        
*/                          
as                             
Begin                             
                          
Declare @desination int,@FunctionalityId int                           
                          
select @desination=DesigId,@FunctionalityId=FunctionalityId from ARC_REC_USER_INFO_VY where USERID=@Userid                    
if  @Userid in(807,5,489)                  
begin                  
select CID AwardId, Name AwardName from RR_CRITERA_MASTER where CID in(1,2,3,4,7,21,24)  and STATUS=1                        
end                  
else if @desination in(4,21,33,15,21)                       
begin                          
select CID AwardId, Name AwardName from RR_CRITERA_MASTER where CID in(1,2,3,4,7)  and STATUS=1                        
end                          
else if @desination in(11,14,12,9)  and @FunctionalityId not in (13)                         
begin                          
select CID AwardId, Name AwardName from RR_CRITERA_MASTER where CID in (7,21,24)    and STATUS=1                       
end                     
else if @FunctionalityId in(4,6)and @desination in(3,10)                     
begin                          
select CID AwardId, Name AwardName from RR_CRITERA_MASTER where CID in(1,2,3,4,7)  and STATUS=1                         
end               
else if @desination in(9)  and @FunctionalityId in (13)                        
begin                          
select CID AwardId, Name AwardName from RR_CRITERA_MASTER where (CID in (7,21,24) or StartRange in(1,2) )  and STATUS=1                       
end                       
else                          
begin                          
select CID AwardId, Name AwardName from RR_CRITERA_MASTER where CID in (7)     and STATUS=1                     
end                          
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Award_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Award_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Award_Get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Award_Get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Award_Get] TO [DB_DMLSupport]
    AS [dbo];

