﻿Create Proc ARC_WheelsPCabSelect
(
@Action varchar(10)
)
As
Begin
if @Action = 'Pickup'
Select * from ARC_WheelsCabPickup
else 
Select * from ARC_WheelsCabDrop
end

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_WheelsPCabSelect] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_WheelsPCabSelect] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_WheelsPCabSelect] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_WheelsPCabSelect] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_WheelsPCabSelect] TO [DB_DMLSupport]
    AS [dbo];

