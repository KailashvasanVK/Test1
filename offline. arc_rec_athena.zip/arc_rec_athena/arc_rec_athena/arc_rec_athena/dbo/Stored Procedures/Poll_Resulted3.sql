﻿CREATE Proc Poll_Resulted3(@year VARCHAR(4)=NULL,@month VARCHAR(2)=NULL)            
As       
BEGIN      
      
 IF @month IS NOT NULL    
 
 begin    
       
       
 IF EXISTS (SELECT TOP 1'x' FROM (           
select distinct  a.poll_id,Poll,Opt1,Opt2,Opt3,Opt4,OP1P=dbo.PollCount(a.poll_id,1),                            
OP2P=dbo.PollCount(a.poll_id,2),OP3P=dbo.PollCount(a.poll_id,3),          
OP4P=dbo.PollCount(a.poll_id,4),OPA1=dbo.Pollresult(a.poll_id,1),OPA2=dbo.Pollresult(a.poll_id,2),           
OPA3=dbo.Pollresult(a.poll_id,3),OPA4=dbo.Pollresult(a.poll_id,4),CONVERT(VARCHAR(12),a.SCHEDULED_ON,107) as CREATED_ON           
from ARC_Forum_Polls a                             
left join ARC_Forum_Polls_Results b on b.poll_id=A.poll_id                
where a.status=1 AND month(a.SCHEDULED_ON) = @month AND a.poll_id NOT IN (select TOP 1 a.poll_id                         
from ARC_Forum_Polls a                          
                    
where  CONVERT(VARCHAR(12),a.SCHEDULED_ON,107) <= CONVERT(VARCHAR(12),GETDATE(),107)--<= convert(date,GETDATE())--  and a.status=1               
                   
order by CONVERT(VARCHAR(12),a.SCHEDULED_ON,107) desc  )  )   as Udhaya)     

          
select *,[No.Of.Polled]=(OP1P+OP2P+OP3P+OP4P) from (           
select distinct  a.poll_id,Poll,Opt1,Opt2,Opt3,Opt4,OP1P=dbo.PollCount(a.poll_id,1),                            
OP2P=dbo.PollCount(a.poll_id,2),OP3P=dbo.PollCount(a.poll_id,3),          
OP4P=dbo.PollCount(a.poll_id,4),OPA1=dbo.Pollresult(a.poll_id,1),OPA2=dbo.Pollresult(a.poll_id,2),           
OPA3=dbo.Pollresult(a.poll_id,3),OPA4=dbo.Pollresult(a.poll_id,4),CONVERT(VARCHAR(12),a.SCHEDULED_ON,107) as CREATED_ON           
from ARC_Forum_Polls a                             
left join ARC_Forum_Polls_Results b on b.poll_id=A.poll_id                
where a.status=1 AND month(a.SCHEDULED_ON) = @month AND a.poll_id NOT IN (select TOP 1 a.poll_id                         
from ARC_Forum_Polls a                          
                    
where CONVERT(VARCHAR(12),a.SCHEDULED_ON,107) <= CONVERT(VARCHAR(12),GETDATE(),107)--<= convert(date,GETDATE())--  and a.status=1                  
                   
order by CONVERT(VARCHAR(12),a.SCHEDULED_ON,107) desc  )    )    as Udhaya                      
order by Udhaya.CREATED_ON desc    


      
ELSE   

 
 select *,[No.Of.Polled]=(OP1P+OP2P+OP3P+OP4P) from (           
select distinct  a.poll_id,Poll,Opt1,Opt2,Opt3,Opt4,OP1P=dbo.PollCount(a.poll_id,1),                            
OP2P=dbo.PollCount(a.poll_id,2),OP3P=dbo.PollCount(a.poll_id,3),          
OP4P=dbo.PollCount(a.poll_id,4),OPA1=dbo.Pollresult(a.poll_id,1),OPA2=dbo.Pollresult(a.poll_id,2),           
OPA3=dbo.Pollresult(a.poll_id,3),OPA4=dbo.Pollresult(a.poll_id,4),CONVERT(VARCHAR(12),a.SCHEDULED_ON,107) as CREATED_ON           
from ARC_Forum_Polls a                             
left join ARC_Forum_Polls_Results b on b.poll_id=A.poll_id                
where a.status=1 AND month(a.SCHEDULED_ON) = month(a.SCHEDULED_ON)-1 AND a.poll_id NOT IN (select TOP 1 a.poll_id                         
from ARC_Forum_Polls a                          
                    
WHERE CONVERT(VARCHAR(12),a.SCHEDULED_ON,107) <= CONVERT(VARCHAR(12),GETDATE(),107)--<= convert(date,GETDATE())--  and a.status=1                
                   
order by a.SCHEDULED_ON desc  )    )    as Udhaya                      
order by Udhaya.CREATED_ON desc   
  
end
      
ELSE


Begin 
      
IF EXISTS (SELECT TOP 1 'x' FROM (           
select distinct  a.poll_id,Poll,Opt1,Opt2,Opt3,Opt4,OP1P=dbo.PollCount(a.poll_id,1),                            
OP2P=dbo.PollCount(a.poll_id,2),OP3P=dbo.PollCount(a.poll_id,3),          
OP4P=dbo.PollCount(a.poll_id,4),OPA1=dbo.Pollresult(a.poll_id,1),OPA2=dbo.Pollresult(a.poll_id,2),           
OPA3=dbo.Pollresult(a.poll_id,3),OPA4=dbo.Pollresult(a.poll_id,4),CONVERT(VARCHAR(12),a.SCHEDULED_ON,107) as CREATED_ON           
from ARC_Forum_Polls a                             
left join ARC_Forum_Polls_Results b on b.poll_id=A.poll_id                
where a.status=1 AND month(a.SCHEDULED_ON) = datepart(mm,getdate()) AND a.poll_id NOT IN (select TOP 1 a.poll_id                         
from ARC_Forum_Polls a                          
    
where CONVERT(VARCHAR(12),a.SCHEDULED_ON,107) <= CONVERT(VARCHAR(12),GETDATE(),107)--<= convert(date,GETDATE())--  and a.status=1                 
                   
order by a.SCHEDULED_ON desc  )    )    as Udhaya      
order by Udhaya.CREATED_ON desc   )      
      
select *,[No.Of.Polled]=(OP1P+OP2P+OP3P+OP4P),CREATED_ON   FROM (           
select distinct  a.poll_id,Poll,Opt1,Opt2,Opt3,Opt4,OP1P=dbo.PollCount(a.poll_id,1),       
OP2P=dbo.PollCount(a.poll_id,2),OP3P=dbo.PollCount(a.poll_id,3),          
OP4P=dbo.PollCount(a.poll_id,4),OPA1=dbo.Pollresult(a.poll_id,1),OPA2=dbo.Pollresult(a.poll_id,2),           
OPA3=dbo.Pollresult(a.poll_id,3),OPA4=dbo.Pollresult(a.poll_id,4),CONVERT(VARCHAR(12),a.SCHEDULED_ON,107) as CREATED_ON           
from ARC_Forum_Polls a                             
left join ARC_Forum_Polls_Results b on b.poll_id=A.poll_id                
where a.status=1 AND month(a.SCHEDULED_ON) = datepart(mm,getdate())  AND a.poll_id NOT IN (select TOP 1 a.poll_id                         
from ARC_Forum_Polls a                          
                    
where CONVERT(VARCHAR(12),a.SCHEDULED_ON,107) <= CONVERT(VARCHAR(12),GETDATE(),107)--<= convert(date,GETDATE())--  and a.status=1                  
                   
order by a.SCHEDULED_ON desc  )   )    as Udhaya      
order by Udhaya.CREATED_ON desc       
      
ELSE      
         
select *,[No.Of.Polled]=(OP1P+OP2P+OP3P+OP4P),CREATED_ON  FROM (       
select distinct  a.poll_id,Poll,Opt1,Opt2,Opt3,Opt4,OP1P=dbo.PollCount(a.poll_id,1),                            
OP2P=dbo.PollCount(a.poll_id,2),OP3P=dbo.PollCount(a.poll_id,3),          
OP4P=dbo.PollCount(a.poll_id,4),OPA1=dbo.Pollresult(a.poll_id,1),OPA2=dbo.Pollresult(a.poll_id,2),           
OPA3=dbo.Pollresult(a.poll_id,3),OPA4=dbo.Pollresult(a.poll_id,4),CONVERT(VARCHAR(12),a.SCHEDULED_ON,107)as CREATED_ON           
from ARC_Forum_Polls a                             
left join ARC_Forum_Polls_Results b on b.poll_id=A.poll_id                
where a.status=1 AND month(a.SCHEDULED_ON) = datepart(mm,getdate())-1 AND a.poll_id NOT IN (select TOP 1 a.poll_id                         
from ARC_Forum_Polls a                          
                    
where CONVERT(VARCHAR(12),a.SCHEDULED_ON,107) <= CONVERT(VARCHAR(12),GETDATE(),107) --<= convert(date,GETDATE())--  and a.status=1                 
                   
order by a.SCHEDULED_ON desc  )    )  as Udhaya      
order by Udhaya.CREATED_ON desc       
      
end  
      
END
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Poll_Resulted3] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Poll_Resulted3] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Poll_Resulted3] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Poll_Resulted3] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Poll_Resulted3] TO [DB_DMLSupport]
    AS [dbo];

