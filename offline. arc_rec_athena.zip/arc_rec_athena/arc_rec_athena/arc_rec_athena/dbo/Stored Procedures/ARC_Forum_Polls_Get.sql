﻿CREATE Proc ARC_Forum_Polls_Get                 
@NT_username varchar(75)=NULL                  
/*  ARC_Forum_Polls_Get  @NT_username='udhayaganesh.p'                    */                  
as                  
Begin                  
    
    
if exists (select 'x' from ARC_Forum_Polls where SCHEDULED_ON <=convert(date,GETDATE()) and STATUS=1)                  
begin                  
select TOP 1 a.poll_id,Poll,Opt1,Opt2,isnull(Opt3,'') Opt3,isnull(Opt4,'')Opt4 ,isnull(b.opt,0) Poll_In,OPA1=dbo.Pollresult(a.poll_id,1),                  
OPA2=dbo.Pollresult(a.poll_id,2),OPA3=dbo.Pollresult(a.poll_id,3),OPA4=dbo.Pollresult(a.poll_id,4),isnull(b.OPT,0) ans,  
OP1P=dbo.PollCount(a.poll_id,1),                      
OP2P=dbo.PollCount(a.poll_id,2),OP3P=dbo.PollCount(a.poll_id,3),    
OP4P=dbo.PollCount(a.poll_id,4)                 
from ARC_Forum_Polls a  with (nolock)                
left join ARC_Forum_Polls_Results b with (nolock) on A.poll_id=b.poll_id and b.NT_USERNAME=@NT_username  and b.STATUS =1                
where SCHEDULED_ON <= convert(date,GETDATE()) and a.status=1       
group by a.poll_id,Poll,Opt1,Opt2,Opt3,Opt4 ,isnull(b.opt,0),SCHEDULED_ON                   
order by scheduled_on desc                  
end                  
else                  
begin          
print 'hi'              
select top 1 a.poll_id,Poll,Opt1,Opt2,Opt3,Opt4,isnull(b.opt,0) Poll_In,OPA1=dbo.Pollresult(a.poll_id,1),                  
OPA2=dbo.Pollresult(a.poll_id,2),OPA3=dbo.Pollresult(a.poll_id,3),OPA4=dbo.Pollresult(a.poll_id,4),isnull(b.OPT,0) ans,  
OP1P=dbo.PollCount(a.poll_id,1),                      
OP2P=dbo.PollCount(a.poll_id,2),OP3P=dbo.PollCount(a.poll_id,3),    
OP4P=dbo.PollCount(a.poll_id,4) from ARC_Forum_Polls a  with (nolock)                  
left join ARC_Forum_Polls_Results b with (nolock) on b.poll_id=A.poll_id and b.NT_USERNAME=@NT_username and  SCHEDULED_ON < convert(date,GETDATE())      
where a.status=1                   
order by scheduled_on desc                  
end                  
END 

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Forum_Polls_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_Polls_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_Polls_Get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Forum_Polls_Get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_Polls_Get] TO [DB_DMLSupport]
    AS [dbo];

