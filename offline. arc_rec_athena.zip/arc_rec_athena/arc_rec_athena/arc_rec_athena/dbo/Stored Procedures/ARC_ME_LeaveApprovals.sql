﻿ --ARC_ME_LeaveApprovals 1,'SUPERVISOR_LEAVE_VIEW'        
 CREATE procedure ARC_ME_LeaveApprovals        
      @SupervisorId int,        
      @Action varchar(50),        
      @SearchStr varchar(100) = '',                   
      @SearchPattern varchar(4) = '=' /** = or % **/                    
 As        
 Begin         
          
 Declare @OrderStr varchar(100)   
           declare @CurDate as date        
declare @Pay_MaxDate as date        
select @CurDate = convert(date ,GETDATE())        
select @Pay_MaxDate = MAX(PAY_ROLL_DATE) from ARC_ME_PAYROLL             
 if( @Action = 'LEAVE_APPROVAL_HISTORY')        
 begin        
         
SELECT 
CASE WHEN (LR.LEAVE_STATUS = 1) and ((@CurDate <= CONVERT(date,LR.FROMDATE) and @CurDate <= CONVERT(date,LR.TODATE)) or (@Pay_MaxDate <= CONVERT(date,LR.FROMDATE))) Then        
 '<button onclick="return LeaveCancellation(''' + convert(varchar,ISNULL(LR.LEAVE_REQID,0)) + ''',''' + LT.TYPE_TEXT + ''');" class="Action ui-button ui-widget ui-state-default ui-corner-all ui-button-icon-only" id="btnCancellation" role="button" aria-dis
abled="false" title="Leave Cancellation">                   
 <span class="ui-button-icon-primary ui-icon ui-icon-pencil"></span>                   
 <span class="ui-button-text">&nbsp;</span></button>' ELSE 'N/A' END as [ACTION],
LR.LEAVE_REQID AS [REQ ID~Hide],CONVERT(VARCHAR(11),LR.CREATED_DT,113) AS [REQUESTED ON]                                        
,REQ.FIRSTNAME + ' ' + REQ.LASTNAME AS [REQUESTED BY]                                         
,LT.TYPE_TEXT AS [LEAVE TYPE]                                        
,CASE WHEN LR.TYPEID = 5 THEN CONVERT(VARCHAR(11),LR.FROMDATE,113) + SUBSTRING(CONVERT(VARCHAR,LR.FROMDATE,100),12,10) ELSE CONVERT(VARCHAR(11),LR.FROMDATE,113) END AS [FROM DATE]                                        
,CASE WHEN LR.TYPEID = 5 THEN CONVERT(VARCHAR(11),LR.TODATE,113) + SUBSTRING(CONVERT(VARCHAR,LR.TODATE,100),12,10) ELSE CONVERT(VARCHAR(11),LR.TODATE,113) END AS [TO DATE]                                        
,LR.LEAVE_DAYS AS [LEAVES~Hide],LR.REASON                                                      
,CASE LR.LEAVE_STATUS WHEN 0 THEN 'Waiting For Approval' + CASE WHEN APPLIED_TO <> FORWARD_TO THEN ' Forwarded to ' + FOW.FIRSTNAME + ' ' + FOW.LASTNAME ELSE '' END                                          
WHEN 1 THEN 'Approved' + CASE WHEN APPLIED_TO <> FORWARD_TO THEN ' by ' + FOW.FIRSTNAME + ' ' + FOW.LASTNAME ELSE '' END                                          
WHEN 2 THEN 'Rejected' + CASE WHEN APPLIED_TO <> FORWARD_TO THEN ' by ' + FOW.FIRSTNAME + ' ' + FOW.LASTNAME ELSE '' END                                          
WHEN 3 THEN 'Forward To ' + FOW.FIRSTNAME + ' ' + FOW.LASTNAME                                          
END [STATUS~Hide]    
into #LeaveHistoryView FROM ARC_REC_LEAVE_REQUEST AS LR                                        
INNER JOIN ARC_REC_LEAVE_TYPES AS LT ON LT.TYPEID = LR.TYPEID                                
INNER JOIN ARC_REC_USER_INFO AS REQ ON REQ.USERID = LR.CREATED_BY                                                        
INNER JOIN ARC_REC_USER_INFO AS APP ON APP.USERID = LR.APPLIED_TO                                          
INNER JOIN ARC_REC_USER_INFO AS FOW ON FOW.USERID = LR.FORWARD_TO                                            
WHERE LR.FORWARD_TO = @SupervisorId AND LR.ACTIVE = 'Y'         
                          
SET @OrderStr  = ' order by [REQ ID~Hide] desc'                              
        
Exec FilterTable                    
@DbName = 'tempdb'                    
,@TblName = '#LeaveHistoryView'                    
,@SearchStr = @SearchStr                    
,@SearchPattern = @SearchPattern                    
,@OrderStr = @OrderStr                    
if OBJECT_ID('tempdb..#LeaveHistoryView') is not null drop table #LeaveHistoryView        
         
 end        
 else if (@Action = 'SUPERVISOR_LEAVE_VIEW')        
 begin        
SELECT LR.LEAVE_REQID AS [REQ ID~Hide],CONVERT(VARCHAR(11),LR.CREATED_DT,113) AS [REQUESTED ON]                                       
,REQ.FIRSTNAME + ' ' + REQ.LASTNAME AS [REQUESTED BY]                                       
,LT.TYPE_TEXT AS [LEAVE TYPE]                                        
,CASE WHEN LR.TYPEID = 5 THEN CONVERT(VARCHAR(11),LR.FROMDATE,113) + SUBSTRING(CONVERT(VARCHAR,LR.FROMDATE,100),12,10) ELSE CONVERT(VARCHAR(11),LR.FROMDATE,113) END AS [FROM DATE]                                        
,CASE WHEN LR.TYPEID = 5 THEN CONVERT(VARCHAR(11),LR.TODATE,113) + SUBSTRING(CONVERT(VARCHAR,LR.TODATE,100),12,10) ELSE CONVERT(VARCHAR(11),LR.TODATE,113) END AS [TO DATE]                                        
,LR.LEAVE_DAYS AS [LEAVES~Hide],LR.REASON                                                      
,CASE LR.LEAVE_STATUS WHEN 0 THEN 'Waiting For Approval' + CASE WHEN APPLIED_TO <> FORWARD_TO THEN ' Forwarded to ' + FOW.FIRSTNAME + ' ' + FOW.LASTNAME ELSE '' END                                          
WHEN 1 THEN 'Approved' + CASE WHEN APPLIED_TO <> FORWARD_TO THEN ' by ' + FOW.FIRSTNAME + ' ' + FOW.LASTNAME ELSE '' END                                
WHEN 2 THEN 'Rejected' + CASE WHEN APPLIED_TO <> FORWARD_TO THEN ' by ' + FOW.FIRSTNAME + ' ' + FOW.LASTNAME ELSE '' END                                          
WHEN 3 THEN 'Forward To ' + FOW.FIRSTNAME + ' ' + FOW.LASTNAME                                          
END [STATUS],ISNULL(LR.RESPONSE_REMARK,'') AS COMMENTS,      
'<button onclick="return OpenDialog('+convert(varchar,ISNULL(LR.LEAVE_REQID,0))+','''+LT.TYPE_TEXT+''','''+convert(varchar,REPLACE(REQ.FIRSTNAME,'''','') + ' ' + REPLACE(REQ.LASTNAME,'''','') )+''');"             
class="Action ui-button ui-widget ui-state-default ui-corner-all ui-button-icon-only" id="btnAckAction" role="button" aria-disabled="false" title="Update Attendance">                            
<span class="ui-button-icon-primary ui-icon ui-icon-copy"></span><span class="ui-button-text">Leave Approval</span></button>' as [ACTION]                                                                                                                      
  
                  
into #LeaveApprovalView FROM ARC_REC_LEAVE_REQUEST AS LR                                        
INNER JOIN ARC_REC_LEAVE_TYPES AS LT ON LT.TYPEID = LR.TYPEID                                        
INNER JOIN ARC_REC_USER_INFO AS REQ ON REQ.USERID = LR.CREATED_BY                                                        
INNER JOIN ARC_REC_USER_INFO AS APP ON APP.USERID = LR.APPLIED_TO                                          
INNER JOIN ARC_REC_USER_INFO AS FOW ON FOW.USERID = LR.FORWARD_TO                                            
WHERE LR.FORWARD_TO = @SupervisorId AND LR.LEAVE_STATUS in(0,3) AND LR.ACTIVE = 'Y'           
                         
SET @OrderStr  = ' order by [REQ ID~Hide] desc'                              
Exec FilterTable                    
@DbName = 'tempdb'                    
,@TblName = '#LeaveApprovalView'                    
,@SearchStr = @SearchStr                    
,@SearchPattern = @SearchPattern                    
,@OrderStr = @OrderStr                    
if OBJECT_ID('tempdb..#LeaveApprovalView') is not null drop table #LeaveApprovalView        
 end        
 end        
         
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_LeaveApprovals] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_LeaveApprovals] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_LeaveApprovals] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_LeaveApprovals] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_LeaveApprovals] TO [DB_DMLSupport]
    AS [dbo];

