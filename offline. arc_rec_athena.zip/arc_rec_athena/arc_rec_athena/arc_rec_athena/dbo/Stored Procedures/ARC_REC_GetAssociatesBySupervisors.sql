﻿CREATE procedure [dbo].[ARC_REC_GetAssociatesBySupervisors]  
       @UID int  
As  
Begin  
 declare @reporting as varchar(75)  
 select @reporting = NT_USERNAME from ARC_REC_USER_INFO where USERID=@UID  
 SELECT UI.USERID,UI.FIRSTNAME+' '+UI.LASTNAME+' -('+isnull(Ui.EMPCODE,'')+')'   AS NAME   
 FROM ARC_REC_USER_INFO AS UI     
 where ui.REPORTING_TO=@reporting and ui.ACTIVE = 1 and ui.AHS_PRL = 'Y'  
End 

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_GetAssociatesBySupervisors] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_GetAssociatesBySupervisors] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_GetAssociatesBySupervisors] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_GetAssociatesBySupervisors] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_GetAssociatesBySupervisors] TO [DB_DMLSupport]
    AS [dbo];

