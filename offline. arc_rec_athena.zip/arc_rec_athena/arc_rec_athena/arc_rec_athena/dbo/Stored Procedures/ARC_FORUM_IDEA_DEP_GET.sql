﻿
Create Proc ARC_FORUM_IDEA_DEP_GET  
AS  
Begin  
select FunctionalityId,FunctionName from ARC_REC_DEPT_HEAD_VY  
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FORUM_IDEA_DEP_GET] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_IDEA_DEP_GET] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_IDEA_DEP_GET] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FORUM_IDEA_DEP_GET] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_IDEA_DEP_GET] TO [DB_DMLSupport]
    AS [dbo];

