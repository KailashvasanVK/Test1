﻿CREATE procedure ARC_Rec_RoleConfigAction
@Action varchar(50),
@ApplicationId int =0,
@SearchStr varchar(75)='',
@RoleName varchar(50)='',
@RoleId int = 0,
@FunctionalityId int = 0,
@UserId int = 0 ,
@SearchPattern varchar(5)='%'
As
/*
ARC_Rec_RoleConfigAction 'getRoleDetails',7
ARC_Rec_RoleConfigAction 'getRoleDetails',105
ARC_Rec_RoleConfigAction 'getRoleDetails',105
ARC_Rec_RoleConfigAction 'LoadUserInfo',3
*/
Begin
If (@Action = 'getRoleDetails')
/* To fill Role Master datagridview */
Begin
	Select  ARR.RoleName,ASM.MenuDisplayText as[Module Name],ARUI.NT_USERNAME as [Created By] ,
	case when ARR.Status = 1 then 'Active' else 'InActive' end as Status ,
	
	'<div> <div style="float: left;padding-top:6px; cursor:pointer" title ="Click here to edit the '+ ARR.RoleName +' details">    
   <a id="Edit" onclick="OpenDialog(this);" RoleId = "'+ cast(ARr.RoleId as varchar)+'" RoleName ="'+CAST(ARR.RoleName as varchar) +'"
   Status = "'+cast(ARR.Status as varchar)+'"  ApplicationType ="'+ CAST(ASM.MenuId AS VARCHAR) +'">  
   <span  class="ui-icon ui-icon-pencil IconBackGround" ></span></a></div><div style="float: left;">&nbsp;</div></div>' as [Action]
   
	from ARC_REC_Role  ARR
	inner join ARC_REC_USER_INFO  ARUI on ARUI.USERID =ARR.CREATED_BY
	inner join ARC_Setup_Menu ASM on ASM.MenuId = ARR.ModuleMenuId 
	Where ASM.MenuId = @ApplicationId 
End
Else If (@Action = 'getBaseApplication')
/* To fill the  application Dropdown list*/
Begin
	Select MenuDisplayText,MenuParentId from ARC_Setup_Menu  Where BaseFuntionality_Id = 0 and MenuId=MenuParentId
End
Else If (@Action = 'getRoleCreationFunctionality')
/* To fill the  application Dropdown list for RoleCreation */
Begin
	Select ASM.MenuDisplayText,ASM.MenuParentId from ARC_Setup_Menu ASM
	inner join ARC_REC_RoleAccess  ARRA on ARRA.ModuleMenuId = ASM.MenuId
	Where ASM.BaseFuntionality_Id = 0 and ASM.MenuId=ASM.MenuParentId and ARRA.userid = @userid 
	order by ASM.MenuId	
End
Else If (@Action = 'getTabRights')
Begin	
	Declare @UserRights varchar(5) = 'L' ---- 'L' then 'Limited Rights'  
	If ((Select COUNT(UserID ) from ARC_REC_RoleAccess  Where userid = @userid	) > 0 )
	Begin	
		Set @UserRights  ='S' ---- 'S' then 'Super User' To load Role Create,Assign Tab and Role Config Tab in RoleConfigSetup 
	End
	Else If ((Select COUNT (RoleId) from  ARC_REC_UserRole Where AccessLevel = 'F' and UserId = @userid) > 0 ) 
	Begin		
		Set @UserRights  = 'F'---- 'F'  then 'Full Rights' To load Role Assign Tab and Role Config Tab in RoleConfigSetup 
	End
	Else if((Select COUNT (RoleId) from  ARC_REC_UserRole Where AccessLevel = 'P' and UserId = @userid) > 0 )
	Begin		
		Set @UserRights  ='P'	---- 'P'  then 'Particle Rights' To load Role Assign Tab in RoleConfigSetup 
	End
	Select @UserRights as UserRghts
End
Else if (@Action = 'getRoleMenuItem')
/*  To fill Datagrid  */
Begin	
	Select MenuParentId,MenuDisplayText,MenuDescription, OutputPath,LogoFilePath,BaseFuntionality_Id,
	DisplayOrder,MenuFileName,Boxno,MenuId   from ARC_Setup_Menu   
	Where  MenuParentId in ((select MenuId from ARC_Setup_Menu where MenuParentId=  @ApplicationId) union Select @ApplicationId  )
	order by DisplayOrder
End
Else if (@Action = 'getActiveRole')
/* To fill the Role Config Dropdown list [ Full Rights Roles only ] */
Begin
	Select ARR.RoleName,ARR.RoleId from  ARC_REC_Role  ARR
	Inner join  ARC_REC_UserRole  ARUR on ARUR.RoleId = ARR.RoleId  and arur.AccessLevel = 'F'
	Where ARR.ModuleMenuId = @ApplicationId 	and ARR.Status = 1 	and ARUR.UserId = @userid
End
Else if (@Action = 'getAllActiveRole')
/* To fill the Role Config Dropdown list all active Rolwes  */
Begin
	Select ARR.RoleName,ARR.RoleId from  ARC_REC_Role  ARR
	Inner join  ARC_REC_UserRole  ARUR on ARUR.RoleId = ARR.RoleId  
	Where ARR.ModuleMenuId = @ApplicationId 	and ARR.Status = 1 	and ARUR.UserId = @userid
End
Else if (@Action = 'getRoleWiseMenu')
/* To fill the Dropdown list*/
Begin
	Select MenuId from  ARC_REC_RoleTran where RoleId  =   @RoleId 	
End
Else if (@Action = 'getRoleWiseUser')
/* To fill the DataGrid in Role Transaction Page*/
Begin
	Select ARUI.NT_USERNAME+' [' + arUI.EMPCODE + ']' as Name,
	case when isnull(AccessLevel,'')  ='F'  then 'Full Rights' 
		When isnull(AccessLevel,'')  = 'P'  then 'Particle Rights'
		When isnull(AccessLevel,'')  = 'L' then 'Limited Rights' 
		else  '' end  as AccessLevel  
	from  ARC_REC_UserRole ARUR
	inner join   ARC_REC_USER_INFO ARUI on ARUI.USERID = ARUR.UserId
	Where RoleId  = @RoleId 
End
Else If(@Action = 'GetRoleToDisplay')
/* To load the  DataGridview in User's Role Config */
Begin
	Select ASM.MenuParentId,ASM.MenuId,MenuDisplayText,DisplayOrder from ARC_REC_RoleTran ARRT
	Inner join ARC_Setup_Menu ASM on ASM.MenuId = ARRT.MenuId
	Where ARRT.RoleId = @RoleId
	Order by DisplayOrder
End
Else If (@Action  ='GetDgUserDetails')
Begin
if object_id('tempdb..#tempTest') is not null drop table #tempTest 
begin
	WITH DirectReports (UserId, Name, ReportingTo,UserName )  
		AS  
		(  
		-- Anchor member definition  
		Select USERID as UserId,NT_USERNAME as Name,REPORTING_TO as ReportingTo,NT_USERNAME +' ['+ EMPCODE +']' as UserName   
		from ARC_REC_USER_INFO  Where ACTIVE = 1 and AHS_PRL = 'Y' and  
		REPORTING_TO = (select NT_USERNAME from ARC_REC_USER_INFO where USERID = @UserId)  
		and isnull(NT_USERNAME,'') <> ''  
		UNION ALL  		
		Select ui.USERID  as UserId,ui.NT_USERNAME as Name,REPORTING_TO as ReportingTo,NT_USERNAME +' ['+ EMPCODE +']' as UserName   
		from ARC_REC_USER_INFO ui  
		INNER JOIN DirectReports d on d.Name= ui.REPORTING_TO  
		Where ui.ACTIVE = 1 and ui.AHS_PRL = 'Y' and isnull(ui.NT_USERNAME,'') <> ''  
		)  		
		SELECT UserId, UserName  into #tempTest  FROM DirectReports 
End		
Select distinct(ARUI.NT_USERNAME)+' [' + arUI.EMPCODE + ']' as Name,
case When isnull(AccessLevel,'')  ='F'  then 'Full Rights' 
	 When isnull(AccessLevel,'')  = 'P'  then 'Particle Rights'
	 When isnull(AccessLevel,'')  = 'L' then 'Limited Rights' 
	 else  '' end  as AccessLevel , case when isnull(Temp.UserId,'') !='' then  
'<div> <div style="float: left;padding-top:6px; cursor:pointer" title ="Click here to Remove the rights for '+ ARUI.NT_USERNAME +'">
<a id="Remove" onclick="RemoveUserRights(this);" UserId='+ CAST(ARUR.UserId  as varchar) +' RoleId='+CAST(ARUR.RoleId as varchar) + ' >
<span  class="ui-icon ui-icon-closethick" ></span></a></div><div style="float: left;">&nbsp;</div></div>' else '' end   [Action]
from  ARC_REC_UserRole ARUR
inner join   ARC_REC_USER_INFO ARUI on ARUI.USERID = ARUR.UserId
left JOIN #tempTest  Temp on Temp.UserId = ARUR.UserId 
Where RoleId  = @RoleId

End
Else If (@Action = 'LoadUserInfo')
/*  To load the user not Assign for the Role */
Begin
	WITH DirectReports (UserId, Name, ReportingTo,UserName )  
			AS  
			(  
			-- Anchor member definition  
			Select USERID as UserId,NT_USERNAME as Name,REPORTING_TO as ReportingTo,NT_USERNAME +' ['+ EMPCODE +']' as UserName   
			from ARC_REC_USER_INFO  Where ACTIVE = 1 and AHS_PRL = 'Y' and  
			REPORTING_TO = (select NT_USERNAME from ARC_REC_USER_INFO where USERID = @UserId)  
			and isnull(NT_USERNAME,'') <> ''  
			UNION ALL  		
			Select ui.USERID  as UserId,ui.NT_USERNAME as Name,REPORTING_TO as ReportingTo,NT_USERNAME +' ['+ EMPCODE +']' as UserName   
			from ARC_REC_USER_INFO ui  
			INNER JOIN DirectReports d on d.Name= ui.REPORTING_TO  
			Where ui.ACTIVE = 1 and ui.AHS_PRL = 'Y' and isnull(ui.NT_USERNAME,'') <> ''  
			)  		
			SELECT UserId, UserName  FROM DirectReports where UserId not in (Select  userid from  ARC_REC_UserRole where RoleId = @Roleid)
	
	--Select ARUI.NT_USERNAME +' ['+ ARUI.EMPCODE +']' as UserName,ARUI.USERID from ARC_REC_USER_INFO ARUI 
	--Where ARUI.ACTIVE = 1 and AHS_PRL ='Y' and 
	--ARUI.USERID not in (Select USERID from ARC_REC_UserRole where RoleId = @RoleId )
	--and ARUI.FUNCTIONALITY_ID = @FunctionalityId
End
Else If(@Action ='GetFunctionality')
Begin
	Select FunctionName,FunctionalityId from hr_functionality where  status = 1
End
Else If (@Action ='getCheckRoleExists')
Begin
	Declare @Result varchar(5) = 'False'
	if (Select  COUNT(Roleid )  from ARC_REC_Role where RoleId != @RoleId and RoleName = @RoleName )> 0 
	Begin
	set @Result  = 'True'  -- exists then true else false
	End
	Select @Result as Result
End
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Rec_RoleConfigAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Rec_RoleConfigAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Rec_RoleConfigAction] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Rec_RoleConfigAction] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Rec_RoleConfigAction] TO [DB_DMLSupport]
    AS [dbo];

