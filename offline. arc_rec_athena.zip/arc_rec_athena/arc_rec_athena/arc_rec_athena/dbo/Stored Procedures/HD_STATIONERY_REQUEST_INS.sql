﻿   
CREATE PROCEDURE HD_STATIONERY_REQUEST_INS                      
@ISS_REQID INT,                      
@ItemId INT=0,                      
@Quantity INT=0,                      
@ItemType VARCHAR(30)=NULL,                    
@Status TINYINT=0,                      
@USERID INT=0                     
AS                      
BEGIN                      
  INSERT INTO HD_StationeryRequest (ISS_REQID,ItemId,RequestDt,Quantity,Status,CreatedBy,CreatedDt)                      
  VALUES (@ISS_REQID,@ItemId,GETDATE(),@Quantity,@Status,@USERID,GETDATE())                      
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_STATIONERY_REQUEST_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_STATIONERY_REQUEST_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_STATIONERY_REQUEST_INS] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_STATIONERY_REQUEST_INS] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_STATIONERY_REQUEST_INS] TO [DB_DMLSupport]
    AS [dbo];

