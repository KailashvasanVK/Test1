﻿CREATE PROCEDURE [dbo].[ARC_FACILITY_Display](@Type TINYINT)      
AS      
SET NOCOUNT ON      
BEGIN      
/*Route Master Details Display*/      
IF @Type=1       
BEGIN       
  SELECT PID=RM.RouteID ,Name=RM.Routename,Addedby=UI.NT_USERNAME,AddedDt=CONVERT(VARCHAR,RM.CreatedDt,101)  
  ,SI.SHIFT_NAME AS Name1,'' as DriverContactNo       
  FROM ARC_Facility_RouteMaster RM    
  INNER JOIN ARC_REC_USER_INFO UI ON RM.CreatedBy=UI.USERID  
  INNER JOIN ARC_REC_SHIFT_INFO SI ON SI.SHIFT_ID=RM.ShiftId      
  WHERE  RM.Status=1      
      
END      
/*Cab Master Details Display*/      
ELSE IF @Type=2      
BEGIN      
  SELECT PID=CM.CabID, Name=CM.CabNo,Addedby=UI.NT_USERNAME,AddedDt=CONVERT(VARCHAR,CM.CreatedDt,101)  
  ,DriverName as Name1,DriverContactNo    
  FROM ARC_Facility_CABMaster CM     
  INNER JOIN ARC_REC_USER_INFO UI ON CM.CreatedBy=UI.USERID    
  WHERE  CM.Status=1      
      
END      
/*Driver Master Details Display*/      
ELSE IF @Type=3      
BEGIN      
  SELECT PID=DM.DriverID,Name=DM.Drivername,Addedby=UI.NT_USERNAME,AddedDt=CONVERT(VARCHAR,DM.CreatedDt,101)      
  FROM ARC_Facility_DriverMaster DM    
  INNER JOIN ARC_REC_USER_INFO UI ON DM.CreatedBy=UI.USERID    
  WHERE  DM.Status=1       
END       
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FACILITY_Display] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FACILITY_Display] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FACILITY_Display] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FACILITY_Display] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FACILITY_Display] TO [DB_DMLSupport]
    AS [dbo];

