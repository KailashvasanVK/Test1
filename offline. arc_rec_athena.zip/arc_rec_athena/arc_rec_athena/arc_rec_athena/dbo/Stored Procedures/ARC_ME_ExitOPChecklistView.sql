﻿CREATE procedure ARC_ME_ExitOPChecklistView    
     @SupervisorId int, --          
     @SearchStr varchar(100) = '',        
     @SearchPattern varchar(4) = '=' /** = or % **/      
As    
Begin    
      
    if exists (select * from HR_Designation where OP_EDIT = 'Y' and DesigId = (select DESIGNATION_ID from ARC_REC_USER_INFO where USERID =@SupervisorId ))  
    begin  
  SELECT E.REG_ID,E.EMPCODE,(C.FIRSTNAME+' '+C.LASTNAME) AS REQUESTED_BY,  
  CI.CLIENT_NAME as CLIENT,   
  E.REASON_ID as [REASON_ID~Hide],R.REASON as [REASON~Hide],E.FEEDBACK as [FEEDBACK~Hide],  
  SU.USERID AS [SUPERVISOR_ID~Hide],                                  
  (SU.FIRSTNAME+' '+SU.LASTNAME) aS [SUPERVISOR~Hide],                    
  (MAN.FIRSTNAME+' '+MAN.LASTNAME) AS [MANAGER~Hide],  
  convert(varchar,E.NOTICE_PERIOD)+' ( '+ convert(varchar,D.NoticePeriod)+' ) ' AS [NOTICE_PERIOD~Hide],        
  E.OTHER_REASON as [OTHER_REASON~Hide],          
  CONVERT(VARCHAR,E.CREATED_DT,106) AS [REQUEST ON],
  '<button onclick="return OpenDialog('+convert(varchar,E.REG_ID)+');" class="Action ui-button ui-widget ui-state-default ui-corner-all ui-button-icon-only" id="btnAckAction" role="button" aria-disabled="false" title="Exit Ack">  
  <span class="ui-button-icon-primary ui-icon ui-icon-copy"></span><span class="ui-button-text">Exit Acceptance</span></button>' as [ACTION]   
  into #OPChecklistView FROM ARC_ME_EXIT E         
  INNER JOIN ARC_ME_EXIT_REASON_INFO R        
  ON R.REASON_ID= E.REASON_ID        
  INNER JOIN ARC_REC_USER_INFO MAN        
  ON E.SUPERVISOR_ID = MAN.USERID                                        
  INNER JOIN ARC_REC_USER_INFO C          
  ON E.CREATED_BY = C.USERID                                       
  LEFT JOIN HR_Designation D ON C.DESIGNATION_ID = D.DesigId                                 
  INNER JOIN ARC_REC_USER_INFO SU        
  ON C.REPORTING_TO = SU.NT_USERNAME                                  
  LEFT JOIN ARC_REC_CustomerView CI                         
  ON C.CLIENT_ID = CI.CLIENT_ID        
  WHERE E.ACTIVE = 'Y' and E.REG_ID IN ( SELECT REG_ID FROM ARC_ME_EXIT_STATUS_TRAN         
  GROUP BY REG_ID HAVING MAX(STATUS_ID) = 4 )  AND ISNULL(E.EMPCODE,'') <> ''                                 
  and (SU.USERID = @SupervisorId OR MAN.USERID = @SupervisorId)  
  
  Exec FilterTable        
  @DbName = 'tempdb'        
  ,@TblName = '#OPChecklistView'    
  ,@SearchStr = @SearchStr    
  ,@SearchPattern = @SearchPattern    
  ,@OrderStr = ''      
  if OBJECT_ID('tempdb..#OPChecklistView') is not null drop table #OPChecklistView      
     end  
      
  End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_ExitOPChecklistView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_ExitOPChecklistView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_ExitOPChecklistView] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_ExitOPChecklistView] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_ExitOPChecklistView] TO [DB_DMLSupport]
    AS [dbo];

