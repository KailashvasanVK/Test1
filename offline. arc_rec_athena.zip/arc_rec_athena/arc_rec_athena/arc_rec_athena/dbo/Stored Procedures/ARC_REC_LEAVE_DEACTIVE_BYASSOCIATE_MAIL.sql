﻿CREATE Procedure ARC_REC_LEAVE_DEACTIVE_BYASSOCIATE_MAIL      
       @SENDER_UID INT,             
       @LEAVE_REQID INT        
As      
Begin          
DECLARE @SENDER_NAME AS VARCHAR(200)        
DECLARE @LEAVE_TYPEID as INT              
DECLARE @RECEIVER_UID as INT              
DECLARE @LEAVE_TYPE AS VARCHAR(30)              
DECLARE @LEAVE_FROM AS DATETIME              
DECLARE @LEAVE_TO AS DATETIME              
DECLARE @FROM AS VARCHAR(200)=''                                          
DECLARE @TO AS VARCHAR(200)=''                                          
DECLARE @CC AS VARCHAR(MAX)=''                                          
DECLARE @SUBJECT AS VARCHAR(500)=''                                          
DECLARE @BODY_MSG AS VARCHAR(MAX)=''                                          
DECLARE @ISBODYHTML AS BIT                                          
SELECT @ISBODYHTML = 1       
      
 SELECT @RECEIVER_UID = APPLIED_TO ,@LEAVE_FROM = FROMDATE,@LEAVE_TO = TODATE      
 FROM ARC_REC_LEAVE_REQUEST where LEAVE_REQID = @LEAVE_REQID        
      
 SELECT @LEAVE_TYPE =  TYPE_TEXT,@LEAVE_TYPEID = TYPEID from ARC_REC_LEAVE_TYPES where TYPEID = (select TYPEID from      ARC_REC_LEAVE_REQUEST where LEAVE_REQID = @LEAVE_REQID)       
      
 SELECT @FROM  = (NT_USERNAME+'@accesshealthcare.co'),@SENDER_NAME = FIRSTNAME+' '+LASTNAME        
 FROM ARC_REC_USER_INFO where USERID = @SENDER_UID              
 SELECT @TO  = (NT_USERNAME+'@accesshealthcare.co') FROM ARC_REC_USER_INFO where USERID = @RECEIVER_UID        
       
IF @LEAVE_TYPEID <> 5      
Begin      
 SELECT @SUBJECT = 'Leave Application Cancelled'      
 SELECT @BODY_MSG = '<p>  Hi, <br /><br /> ' +@SENDER_NAME+' has cancelled '+ @LEAVE_TYPE+ ' from '+ CONVERT(varchar,@LEAVE_FROM,107)+' to '+          
 CONVERT(varchar,@LEAVE_TO,107)+'. <br /><br /><img src="https://arc.accesshealthcare.co/arc_me/Images/arc_me.png"/><br/> ** This is a system generated mail. Please do not respond to        
 this mail.**</p>'        
End      
      
ELSE      
Begin      
 SELECT @SUBJECT = 'Permission Cancelled'      
 SELECT @BODY_MSG = '<p>  Hi, <br /><br /> ' +@SENDER_NAME+' has cancelled '+ @LEAVE_TYPE+ ' from '+ CONVERT(varchar,@LEAVE_FROM,107) +' '+right(convert(varchar,@LEAVE_FROM,100),8)+' to '+          
  +right(convert(varchar,@LEAVE_TO,100),8)+'. <br /><br /><img src="https://arc.accesshealthcare.co/arc_me/Images/arc_me.png"/><br/> ** This is a system generated mail. Please do not respond to        
 this mail.**</p>'        
End      
      
   SELECT @SUBJECT AS [SUBJECT],@BODY_MSG AS [BODY_MSG],@FROM AS [FROM],@TO AS [TO],@CC AS [CC],@ISBODYHTML AS [ISHTML]       
         
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_LEAVE_DEACTIVE_BYASSOCIATE_MAIL] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_LEAVE_DEACTIVE_BYASSOCIATE_MAIL] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_LEAVE_DEACTIVE_BYASSOCIATE_MAIL] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_LEAVE_DEACTIVE_BYASSOCIATE_MAIL] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_LEAVE_DEACTIVE_BYASSOCIATE_MAIL] TO [DB_DMLSupport]
    AS [dbo];

