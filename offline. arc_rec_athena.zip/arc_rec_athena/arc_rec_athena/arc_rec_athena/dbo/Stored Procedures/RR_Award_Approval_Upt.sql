﻿CREATE Proc [dbo].[RR_Award_Approval_Upt]        
@Userid int=847,        
@Appid int,        
@ApprovedStatus tinyint =0,        
@ApprovedComments nvarchar(500)=''        
/*               
        
Created By : udhayaganesh p        
Puprose : Approve the Award        
@ApprovedStatus =2 has approved and 3 has disapproved.        
        
select * from RR_Appreciation        
        
Exec RR_Award_Approval_Upt 847,3,3        
        
        
*/        
as        
Begin        
        
Declare @tc int =0,@RewardUserid int,@cid int,@points int,@ReferenceInfo varchar(100)        
        
Create Table #RewardUser        
(        
id int identity(1,1),        
Userid int,        
Cid int,        
Points int,        
APPID int,        
ReferenceInfo Varchar(50)        
)        
        
If @ApprovedStatus=2 /* Approved*/        
begin        
        
update RR_Appreciation set approvedby=@userid,Approvedon= dbo.fn_GetIndiaDate(),        
ApprovedStatus=@ApprovedStatus,ApprovedComments=@ApprovedComments where AppId=@Appid        
        
insert into #RewardUser(Userid,CID,Points,APPID,ReferenceInfo)        
select ui.USERID,Ra.Awardid,rcm.POINTS,ra.AppId,'RR_Appreciation' from  RR_Appreciation RA        
inner join RR_Appreciation_Users RAU on RAu.AppId=RA.AppId        
inner join RR_CRITERA_MASTER RCM on RCM.CID=Ra.Awardid         
inner join ARC_REC_USER_INFO UI on UI.NT_USERNAME=RAU.NT_USERNAME         
where  Ra.AppId =@Appid and RA.ApprovedStatus=@ApprovedStatus  and ui.ACTIVE ='1' and ui.AHS_PRL ='Y'      
        
set @tc=(select COUNT(*) from #RewardUser)        
while @tc!=0        
begin        
        
select top 1 @RewardUserid=Userid,@cid=CID,@points=Points,@Appid=APPID,@ReferenceInfo=ReferenceInfo from #RewardUser        
        
        
insert into RR_SCOREBOARD(Userid,CID,Points,ReferenceId,ReferenceInfo)        
select @RewardUserid,@cid,@points,@Appid,@ReferenceInfo        
        
        
/*        Mail Part configure here            */        
        
delete from #RewardUser where Userid=@RewardUserid        
        
set @tc=@tc-1         
        
end        
end        
else if @ApprovedStatus=3 /* Disapprove*/        
begin        
        
update RR_Appreciation set approvedby=@userid,Approvedon= dbo.fn_GetIndiaDate(),        
ApprovedStatus=@ApprovedStatus,ApprovedComments=@ApprovedComments where AppId=@Appid        
        
End        
        
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Award_Approval_Upt] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Award_Approval_Upt] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Award_Approval_Upt] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Award_Approval_Upt] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Award_Approval_Upt] TO [DB_DMLSupport]
    AS [dbo];

