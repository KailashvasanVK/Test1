﻿CREATE PROC ARC_REC_CAPMAN_FACILITYWISE      
@type int=0       
AS        
Begin        
SELECT *,CAST((CapacityUtilized*1.0/TotalCapacity) *100 AS NUMERIC(18,2)) [UT%]         
INTO #tempcaput FROM (        
SELECT FacilityName,        
TotalCapacity=(SELECT COUNT(*) FROM dbo.ARC_REC_CAPMAN CM         
WHERE CM.FacilityId=EP.FacilityId and STATUS=1),        
CapacityUtilized=(SELECT COUNT(*) FROM dbo.ARC_REC_CAPMAN CM         
WHERE CM.FacilityId=EP.FacilityId and STATUS=1 AND BayStatus=1),        
CapacityAvaliable=(SELECT COUNT(*) FROM dbo.ARC_REC_CAPMAN CM         
WHERE CM.FacilityId=EP.FacilityId and STATUS=1 AND BayStatus=0)        
FROM dbo.Eye_Facility EP        
GROUP BY FacilityId,FacilityName        
) AS Udhaya     
    
SELECT FacilityName,SUM(TotalCapacity) TotalCapacity,SUM(CapacityUtilized) CapacityUtilized,SUM(CapacityAvaliable) CapacityAvaliable,    
 CAST((SUM(CapacityUtilized)*1.0/SUM(TotalCapacity)) *100 AS NUMERIC(18,2)) [UT%] FROM #tempcaput     
GROUP BY FacilityName    
    
DROP table #tempcaput        
END        
        
        
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_FACILITYWISE] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_FACILITYWISE] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_FACILITYWISE] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_FACILITYWISE] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_FACILITYWISE] TO [DB_DMLSupport]
    AS [dbo];

