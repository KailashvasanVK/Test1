﻿CREATE Proc DatabaseLogInsert    
As    
Begin    
insert into DatabaseLogInfo(DatabaseName,Datafile_KB,Logfile_KB,Totalfile_KB)    
select Dname, [Data],[Logs],SUM([Data]+[Logs])     
from    
(    
select DB_NAME(database_id) Dname,dType=(Case when type=1then 'Logs' else 'Data' end ) ,    
SUM(cast(size as bigint)*8) DBsize from sys.master_files    
group by DB_NAME(database_id),type     
) as a    
pivot    
(    
Sum(DBsize)    
FOR dType IN ([Logs], [Data])    
) AS PivotTable group by  Dname, [Data],[Logs];    
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[DatabaseLogInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[DatabaseLogInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[DatabaseLogInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[DatabaseLogInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[DatabaseLogInsert] TO [DB_DMLSupport]
    AS [dbo];

