﻿CREATE PROCEDURE [dbo].[AHS_HR_ASSESSMENT_Get]                
(                  
@REC_ID INT,      
@ASSESS_MODE varchar(10)                
)             
/*            
Created By : Udhayaganesh P            
Created On : Sep 07 2013            
Purpose    : To get the Candidate Assessment details             
Execution  :       
      
AHS_HR_ASSESSMENT_Get @REC_ID=13091150 ,@ASSESS_MODE='s'          
        
select * from ARC_REC_CANDIDATE where regbyahs=0          
select * from ARC_REC_ASSESSMENT where rec_id in (13091139,13091150,13091260 )  
select * from ARC_REC_CANDIDATE WHERE REC_ID=13091150  
        
13091139        
13091150        
13091260        
        
*/                
AS                
BEGIN                     
                
if EXISTS (select top 1 'x' from ARC_REC_ASSESSMENT where rec_id =@REC_ID  )              
Begin          
                  
 --SELECT  C.REC_ID,ASSESS_MODE,PRESENTATION,COMMUNICATION,INITIATIVE,SELF_CONFIDENCE,ADAPTABILITY,EXP_QUALITY,                  
 --TECHNICAL_SKILLS,SUPERVISORY_SKILLS,GROWTH_POTENTIAL,OTHER_SKILLS,OVERALL_PERFORMANCE,REMARKS,                  
 --APPLICANT_STATUS,ca.CREATED_BY,RESULT,CTC,JOINDATE,JOIN_DAYS,csi.SCHEDULE_ID,JOIN_TIME                 
 --FROM  ARC_REC_ASSESSMENT CA            
 --inner join ARC_REC_ASSESSMENT_SCHEDULED CSI on CSI.SCHEDULE_ID =ca.SCHEDULE_ID           
 --Inner Join ARC_REC_CANDIDATE C on C.REC_ID =CA.REC_ID             
 --where c.REC_ID =@REC_ID and ASSESS_MODE=@ASSESS_MODE  and c.RegByAHS =0 and CA.ASSESS_MODE not in('H')        
      
SELECT  C.REC_ID,ASSESS_MODE,PRESENTATION,COMMUNICATION,INITIATIVE,SELF_CONFIDENCE,ADAPTABILITY,EXP_QUALITY,                  
TECHNICAL_SKILLS,SUPERVISORY_SKILLS,GROWTH_POTENTIAL,OTHER_SKILLS,OVERALL_PERFORMANCE,REMARKS,                  
APPLICANT_STATUS,ca.CREATED_BY,RESULT,convert(varchar(20),CTC) CTC,Convert(varchar(20),JOINDATE,120) JOINDATE,JOIN_DAYS,csi.SCHEDULE_ID,  
Convert(varchar(20),JOIN_TIME) JOIN_TIME  
FROM  ARC_REC_ASSESSMENT CA            
inner join ARC_REC_ASSESSMENT_SCHEDULED CSI on CSI.SCHEDULE_ID =ca.SCHEDULE_ID           
Inner Join ARC_REC_CANDIDATE C on C.REC_ID =CA.REC_ID             
where c.REC_ID =@REC_ID and ASSESS_MODE=@ASSESS_MODE  and c.RegByAHS =0 and CA.ASSESS_MODE not in('H')      
              
End                 
                    
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AHS_HR_ASSESSMENT_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHS_HR_ASSESSMENT_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHS_HR_ASSESSMENT_Get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AHS_HR_ASSESSMENT_Get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHS_HR_ASSESSMENT_Get] TO [DB_DMLSupport]
    AS [dbo];

