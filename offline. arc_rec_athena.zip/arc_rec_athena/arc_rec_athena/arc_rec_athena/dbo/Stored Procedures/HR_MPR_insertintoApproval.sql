﻿CREATE Procedure dbo.HR_MPR_insertintoApproval(@userid int,@approved int, @Mprid int,@Arc int,@Comments varchar(5000))                                  
as                                  
/*                                  
    Created By    : udhayaganesh.p    
    Purpose       : To insert the approved Mpr                                  
    Date          : Aug 05 2008                              
        
*/                                 
                                
--Exec  BenchMPR_insertintoApproval 7558,1,879,1,'Approved'                                
Declare @Empid1 int                      
Declare @status tinyint                        
            
Begin     
if exists(select * from hr_mpr where mprid = @mprid and ApprovedBy is null)    
begin                                       
Update HR_MPR set         
Approvalstatus= @approved,          
ApprovedBy = @userid ,          
ApprovedDate = dbo.fn_GetIndiaDate(),          
Mprstatusdate=dbo.fn_GetIndiaDate(),      
approvalcomments  = @Comments      
where mprid=@Mprid             
end    
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_MPR_insertintoApproval] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_insertintoApproval] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_insertintoApproval] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_MPR_insertintoApproval] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_insertintoApproval] TO [DB_DMLSupport]
    AS [dbo];

