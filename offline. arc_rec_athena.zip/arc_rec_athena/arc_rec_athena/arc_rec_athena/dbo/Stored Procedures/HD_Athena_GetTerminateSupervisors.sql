﻿CREATE proc HD_Athena_GetTerminateSupervisors
as
Begin
select ui.USERID as UserId, FIRSTNAME+' '+LASTNAME as Name  
from ARC_REC_USER_INFO  as ui
inner join HD_Athena_ApprovalUsers as apu on apu.UserId = Ui.USERID
where ui.AHS_PRL = 'Y' and ui.ACTIVE = 1
Union 
select ui.USERID as UserId, FIRSTNAME+' '+LASTNAME as Name  
from ARC_REC_USER_INFO  as ui
inner join HR_Designation as de on de.DesigId = ui.DESIGNATION_ID and de.Supervisor = 'Y'
where ui.AHS_PRL = 'Y' and ui.ACTIVE = 1 and FUNCTIONALITY_ID = 6 
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_GetTerminateSupervisors] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetTerminateSupervisors] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetTerminateSupervisors] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Athena_GetTerminateSupervisors] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Athena_GetTerminateSupervisors] TO [DB_DMLSupport]
    AS [dbo];

