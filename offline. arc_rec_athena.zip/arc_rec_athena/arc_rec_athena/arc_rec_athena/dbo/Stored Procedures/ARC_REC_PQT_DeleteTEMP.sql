﻿CREATE PROCEDURE ARC_REC_PQT_DeleteTEMP    
(      
@SESSIONID VARCHAR(250),  
@TragetDate datetime      
)      
/*      
ARC_REC_PQT_DeleteTEMP @SESSIONID='',@TragetDate=''  
*/      
AS      
BEGIN      
DELETE FROM ARC_Rec_ProductionQT_Temp WHERE SESSIONID=@SESSIONID and TragetDate=@TragetDate  
END    
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_PQT_DeleteTEMP] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_PQT_DeleteTEMP] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_PQT_DeleteTEMP] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_PQT_DeleteTEMP] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_PQT_DeleteTEMP] TO [DB_DMLSupport]
    AS [dbo];

