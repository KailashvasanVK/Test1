﻿CREATE Proc AHC_AppLikeUsers_Insert      
(      
@Userid varchar(100)=null,      
@UserName varchar(100),      
@UserEmailId varchar(50),      
@Stauts tinyint=1      
)      
As      
Begin      
if not exists(select 'x' from AHC_AppLikeUsers where Userid=@Userid and status=1 and @Userid is not null)      
begin   
   
Insert into AHC_AppLikeUsers     
(UserId,UserName,UserEmailId,Status)       
values (@Userid,@UserName,@UserEmailId,@Stauts)    
  
select 1  as output  
end    
else  
Begin  
select 0  as output  
End    
end    
    
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AHC_AppLikeUsers_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHC_AppLikeUsers_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHC_AppLikeUsers_Insert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AHC_AppLikeUsers_Insert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHC_AppLikeUsers_Insert] TO [DB_DMLSupport]
    AS [dbo];

