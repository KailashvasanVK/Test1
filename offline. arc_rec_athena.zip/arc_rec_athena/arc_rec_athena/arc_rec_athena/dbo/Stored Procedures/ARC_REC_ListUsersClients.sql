﻿CREATE Proc ARC_REC_ListUsersClients
As
begin
SET FMTONLY OFF; SET NOCOUNT ON;
if OBJECT_ID('tempdb..#UsersClient') is not null drop table #UsersClient
Create Table #UsersClient(UserId int,ClientId int,ReportingTo Varchar(75),PrimaryCustomer bit default 1)
Insert into #UsersClient(UserId,ClientId,ReportingTo,PrimaryCustomer)
Select USERID,Client_Id,REPORTING_TO,0 from ARC_REC_USER_INFO
where isnull(nt_username,'') <> '' and ACTIVE = 1 and AHS_PRL = 'Y'
	While 1=1
	Begin
	Insert into #UsersClient(UserId,ClientId,ReportingTo)
	Select ui.USERID,uc.ClientId,ui.REPORTING_TO from #UsersClient as Uc
	inner join ARC_REC_USER_INFO as ui on uc.ReportingTo = ui.NT_USERNAME and ui.ACTIVE = 1 and ui.AHS_PRL = 'Y' and isnull(ui.nt_username,'') <> ''
	Where Not Exists (Select 1 from #UsersClient v Where v.UserId = ui.USERID and v.CLIENTID = uc.CLIENTID) and uc.ClientId is not null
	if @@ROWCOUNT = 0 break
	End
if OBJECT_ID('tempdb..#UsersCustomer') is not null drop table #UsersCustomer
Create Table #UsersCustomer(UserId int,ClientId int,Priority int)
Insert into #UsersCustomer(UserId,ClientId,Priority)Select UserId,CustomerId as ClientId,UCid from ARC_REC_UserCustomer

Insert into #UsersCustomer(UserId,ClientId,Priority)
Select UserId,ClientId,PrimaryCustomer from #UsersClient as ucl
Where not exists (Select 1 from #UsersCustomer Where UserId = ucl.UserId and ClientId = ucl.ClientId)
Group by UserId,ClientId,PrimaryCustomer


Select uc.UserId,uc.ClientId as Client_Id,uc.Priority from #UsersCustomer as uc
inner join ARC_REC_USER_INFO as ui on ui.USERID = uc.USERID and ACTIVE = 1 and AHS_PRL = 'Y'
Order by uc.UserId,uc.Priority
end


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ListUsersClients] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ListUsersClients] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ListUsersClients] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ListUsersClients] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ListUsersClients] TO [DB_DMLSupport]
    AS [dbo];

