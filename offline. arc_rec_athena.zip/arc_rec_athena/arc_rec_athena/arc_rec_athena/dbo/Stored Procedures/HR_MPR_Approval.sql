﻿CREATE Procedure HR_MPR_Approval (@Empid int)                                          
as                                 
/*                              
 Created By : Udhaya Ganesh P                             
 Created On : 30/Aug/2011                              
 Purpose  : To list out list of MPR to be approved           
         
 HR_MPR_Approval 1                           
*/                                       
begin                                          
    select                          
  d.CreatedBy,                              
  d.MPRId as mid,                               
--  hd.Designation as [JobTitle],                               
hd.designation as [Designation],                            
'<a title="ARMS Details" href="#" url="/HR/MPR/MPRDisplay.aspx?MPRID='+ cast(d.MPRid as varchar) + '" class=Link_Edit onclick="GB_show(this,550,650);" style="cursor:hand"><u>'+ hd.Designation  +'</u></a>' as [JobTitle],                            
                            
  d.FunctionalityId,                              
  d.TotalPositions as noofpos ,                               
  d.Reason as RecruitmentReason,                              
  'Rs. ' + dbo.RupeeFormat_Rounded(cast(d.SalaryMin as varchar)) + ' - Rs. ' + dbo.RupeeFormat_Rounded(cast(d.SalaryMax as varchar))  as SalRange,                              
  f.FunctionName as [Dept],                              
  ff.FunctionName as [Functionname],                                  
  (select e.username from MRPLogin e where d.CreatedBy = e.userid) as MPRBy,                                                      
  convert(varchar(10), d.CreatedDate, 103) as CreatedDate, G.Facility as [centername]                              
 from                               
  hr_MPR d inner join hr_Functionality f on d.FunctionalityId=f.FunctionalityId                                                       
  inner join hr_functionality ff on  ff.FunctionalityId  = f.FuncParentId                              
  inner join hr_designation hd on d.DesigId = hd.DesigId                              
  inner join HR_FacilityMaster G on G.TCId=D.TCId                              
 where d.MPRStatus = 0 and d.ApprovalStatus = 0                                  
 order by d.mprid                              
end 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_MPR_Approval] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_Approval] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_Approval] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_MPR_Approval] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_Approval] TO [DB_DMLSupport]
    AS [dbo];

