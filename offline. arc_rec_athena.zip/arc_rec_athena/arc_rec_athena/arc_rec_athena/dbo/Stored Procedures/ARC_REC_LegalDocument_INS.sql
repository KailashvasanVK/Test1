﻿CREATE Proc ARC_REC_LegalDocument_INS                
@DocumentName varchar(50),                
@Status tinyint,                
@userid int,                
@Extension nvarchar(6)='pdf',              
@Publish tinyint,        
@FileName varchar(500)              
As                
Begin                
 if not exists(select 'x' from ARC_REC_LegalDocument where DocumentName=@DocumentName)                
 Begin                 
 insert into ARC_REC_LegalDocument(DocumentName,PathName,Status,Publish,CreatedBy)                
 select @DocumentName,'https://arc.accesshealthcare.co/ARC_me/LegalDoc/'+@FileName+'.'+@Extension+'',@Status,@Publish,@userid                
 select 'Inserted Successfully' as Output                
end                
Else                
begin                
 select 'Document Name already exists' as Output                
end                
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_LegalDocument_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_LegalDocument_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_LegalDocument_INS] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_LegalDocument_INS] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_LegalDocument_INS] TO [DB_DMLSupport]
    AS [dbo];

