﻿CREATE procedure [dbo].[ARC_RoleTranView]
@RoleId int 
As
/*
Purpose    : To get the Menu,Read,Write details for the Role using role id.
Impact to  : RoleCreation.aspx
Created by : Karthik Ic
Created on : 10 april 2013
*/
Begin
Select MenuId,RoleRead,RoleWrite  from ARC_REC_RoleTran  where RoleId = @RoleId 
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_RoleTranView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_RoleTranView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_RoleTranView] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_RoleTranView] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_RoleTranView] TO [DB_DMLSupport]
    AS [dbo];

