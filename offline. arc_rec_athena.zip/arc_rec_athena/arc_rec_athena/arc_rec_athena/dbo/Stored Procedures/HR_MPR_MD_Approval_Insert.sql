﻿CREATE Procedure dbo.HR_MPR_MD_Approval_Insert    
(    
@userid int,    
@approved int,     
@Mprid int,    
@Arc int,    
@Comments varchar(5000)    
)                                                
as                                                
/*                                                
    Created By    : Udhayaganesh.p                     
    Purpose       : To insert the MD approved                                                 
    Date          : Aug 27 2008                    
                    
    exec HR_MPR_MD_Approval_Insert @userid=2184,@approved=1,@Mprid=333,@arc=0,@comments='Approved'                
                                        
                      
*/                                               
                                              
Declare @Empid1 int                                    
Declare @status tinyint                                      
                          
Begin                   
if exists(select * from hr_mpr where mprid = @mprid and MDApprovedBy is null)                  
begin        
print 'Exists'                                                 
Update HR_MPR set                       
MDApprovalstatus= @approved,                        
MDApprovedBy = @userid ,                        
MDApprovedDate = dbo.fn_GetIndiaDate(),                        
MDapprovalcomments  = @Comments,        
Approvalstatus= @approved,                
ApprovedBy = @userid ,                
ApprovedDate = dbo.fn_GetIndiaDate(),                
Mprstatusdate=dbo.fn_GetIndiaDate(),            
approvalcomments  = @Comments                      
where mprid=@Mprid                
              
              
SELECT                      
convert(varchar(25), mpr.CreatedDate, 107) as 'Raisedon',      
um.UserName,cl.CLIENT_NAME As ClientName,    
 tm.Facility TrainingCentre, f.FunctionName, d.Designation,                    
convert(varchar(25), mpr.ExpDate, 107) as 'ExpDate',        
    
(case when tm.TCId =3 then 'PHP.' else  'Rs.'  end )+ dbo.RupeeFormat_Rounded(cast(mpr.SalaryMin as varchar)) as 'SalaryMin',                  
(case when tm.TCId =3 then 'PHP.' else  'Rs.'  end ) + dbo.RupeeFormat_Rounded(cast(mpr.SalaryMax as varchar)) as 'SalaryMax',               
UMA.UserName MDApproved,    
convert(varchar(25),mpr.MDApprovedDate, 107) as 'MDApprovedon',                 
 mpr.* FROM                       
HR_MPR mpr INNER JOIN HR_functionality f on f.FunctionalityId = mpr.FunctionalityId                      
INNER JOIN HR_designation d on d.desigId = mpr.desigID                      
INNER JOIN HR_FacilityMaster tm on tm.Tcid = mpr.Tcid                      
INNER JOIN mrplogin um on um.UserId = mpr.CreatedBy              
inner join mrplogin UMA on UMA.UserId =mpr.MDApprovedBy      
inner join  ARC_FIN_CLIENT_INFO Cl on cl.CLIENT_ID =mpr.clientid                      
where mpr.MPRId = @MPRId                
                         
end                  
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_MPR_MD_Approval_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_MD_Approval_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_MD_Approval_Insert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_MPR_MD_Approval_Insert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_MD_Approval_Insert] TO [DB_DMLSupport]
    AS [dbo];

