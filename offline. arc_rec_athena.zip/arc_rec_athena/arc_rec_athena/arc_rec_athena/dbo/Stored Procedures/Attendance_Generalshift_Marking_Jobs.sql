﻿        
CREATE Proc Attendance_Generalshift_Marking_Jobs        
as        
Begin     
    
Declare @from Date=(getdate())       
    
                           
Create table #Users                            
(                            
Id int identity(1,1),                            
UserAccount Varchar(100),                   
Shiftid int,                   
FromT datetime,                  
Status tinyint default(1)                            
)                            
            
         
select Distinct NT_USERNAME,St.SHIFT_ID,st.CREATED_DT,@from  FromT           
into #temp12 from ARC_REC_USER_INFO UI                  
inner join ARC_REC_SHIFT_TRAN ST on UI.USERID =ST.USERID                            
inner join ARC_REC_SHIFT_INFO SI on ST.SHIFT_ID =SI.SHIFT_ID             
where Effect_DATE <=@from          
order by NT_USERNAME           
   
 select * from #temp12  
          
insert into #Users(UserAccount,Shiftid,FromT )            
select NT_USERNAME,SHIFT_ID,FromT from #temp12 a           
where CREATED_DT in (select MAX(CREATED_DT) from #temp12 b where a.NT_USERNAME =b.NT_USERNAME )          
order by NT_USERNAME   
  
select * from #Users where UserAccount in ('lokhochalai.man','sanjeev.britto')         
        
select a.FromT,a.Shiftid,a.UserAccount,b.Shiftid   from #Users a        
inner join ARC_REC_Attendance b on a.UserAccount=b.NT_UserName  and a.FromT =b.[Date]         
--where b.Shiftid is null        
        
update b set b.Shiftid =a.Shiftid  from #Users a        
inner join ARC_REC_Attendance b on a.UserAccount=b.NT_UserName  and a.FromT =b.[Date]         
where b.Shiftid is null        
        
drop table #Users        
drop table #temp12        
        
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Attendance_Generalshift_Marking_Jobs] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Attendance_Generalshift_Marking_Jobs] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Attendance_Generalshift_Marking_Jobs] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Attendance_Generalshift_Marking_Jobs] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Attendance_Generalshift_Marking_Jobs] TO [DB_DMLSupport]
    AS [dbo];

