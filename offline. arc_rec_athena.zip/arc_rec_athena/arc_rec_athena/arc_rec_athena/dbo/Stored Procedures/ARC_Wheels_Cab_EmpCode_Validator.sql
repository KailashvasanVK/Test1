﻿CREATE PROCEDURE ARC_Wheels_Cab_EmpCode_Validator    
 @EmpCodeCollection VARCHAR(MAX)  
 AS    
 BEGIN    
 SELECT items as 'EMPLOYEE ID' FROM [dbo].[fnSplitString](@EmpCodeCollection,',')    
 EXCEPT SELECT EMPCODE FROM ARC_REC_USER_INFO   
 UNION   
 SELECT items FROM [dbo].[fnSplitString](@EmpCodeCollection,',') GROUP BY items HAVING COUNT(items) > 1  
END 

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Wheels_Cab_EmpCode_Validator] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Wheels_Cab_EmpCode_Validator] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Wheels_Cab_EmpCode_Validator] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Wheels_Cab_EmpCode_Validator] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Wheels_Cab_EmpCode_Validator] TO [DB_DMLSupport]
    AS [dbo];

