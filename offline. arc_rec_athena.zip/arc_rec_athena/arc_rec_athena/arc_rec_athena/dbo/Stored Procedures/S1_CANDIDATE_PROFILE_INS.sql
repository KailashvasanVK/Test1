﻿                          
CREATE PROCEDURE [dbo].[S1_CANDIDATE_PROFILE_INS]                    
(                    
  @AHS_RECID int                     
  ,@PROCESS_ID int                    
  ,@FUNCTIONID int=0                             
  ,@FIRSTNAME varchar (50)                    
  ,@LASTNAME varchar (50)                    
  ,@DOB date                        
  ,@GENDER char(1)                     
  ,@MARITAL_STATUS varchar (1)                    
  ,@FATHER_NAME varchar (50)                    
  ,@SPOUSE_NAME varchar (50)                    
  ,@PER_ADDRESS1 varchar (50)                    
  ,@PER_ADDRESS2 varchar (50)                    
  ,@PER_LOCATION varchar (30)                    
  ,@PER_STATE_ID int                     
  ,@PER_CITY varchar (30)                    
  ,@PER_PINCODE varchar (6)                    
  ,@PRE_ADDRESS1 varchar (50)                    
  ,@PRE_ADDRESS2 varchar (50)                    
  ,@PRE_LOCATION varchar (30)                    
  ,@PRE_STATE_ID int                     
  ,@PRE_CITY varchar (30)                    
  ,@PRE_PINCODE varchar (6)                    
  ,@TELEPHONE_NO varchar (15)                    
  ,@MOBILE_NO varchar (10)                    
  ,@EMAIL_ID varchar (50)                    
  ,@REL_EXP int                     
  ,@CTC decimal                     
  ,@E_CTC decimal                     
  ,@SHIFTS int                     
  ,@KNOW_ABOUT_US varchar(2)                
  ,@EMPLOYEE_ID varchar (12)                    
  ,@EMER_CONTACT_NAME varchar (30)                    
  ,@EMER_CONTACT_NO varchar (10)                    
  ,@BLOODGROUP varchar (4)                    
  ,@JOIN_DAYS int                     
  ,@PRE_APPLIED int          
  ,@STATUS_ID INT              
)                    
AS                    
BEGIN 

/*

exec S1_CANDIDATE_PROFILE_INS @AHS_RECID=13111206,@PROCESS_ID=2,@FUNCTIONID=0,@FIRSTNAME='Dina',@LASTNAME='Karan',
@DOB='1986-05-12',@GENDER='M',@MARITAL_STATUS=1,@FATHER_NAME='chinnaraju',@SPOUSE_NAME='',@PER_ADDRESS1='no.157 eswaran koil street,',
@PER_ADDRESS2='melolakkur,gingee tk,villupuram dt.',@PER_LOCATION='melolakkur',@PER_STATE_ID=25,@PER_CITY='gingee',@PER_PINCODE='604203',
@PRE_ADDRESS1='no.3/238,nakkeeran street,jj nagar,',@PRE_ADDRESS2='mugapair east,chennai.',@PRE_LOCATION='chennai',@PRE_STATE_ID='25',
@PRE_CITY='chennai',@PRE_PINCODE='600037',@TELEPHONE_NO='9551674441',@MOBILE_NO='9094128661',@EMAIL_ID='kcdinakaran1947@gmail.com',@REL_EXP='1',
@CTC='0.00',@E_CTC='180000.00',@SHIFTS='1',@KNOW_ABOUT_US='13',@EMPLOYEE_ID='0',@EMER_CONTACT_NAME='9500876476',@EMER_CONTACT_NO='9500876476',@BLOODGROUP=4,
@JOIN_DAYS=2,@PRE_APPLIED=2,@STATUS_ID=5


select * from ARC_REC_CANDIDATE_STATUS where rec_id=13111206



select * from ARC_REC_CANDIATE_PROFILE where rec_id= 13111206

*/                       
          
if NOT EXISTS ( SELECT TOP 1 'X' FROM ARC_REC_CANDIATE_PROFILE WHERE REC_ID =@AHS_RECID)          
BEGIN          
                         
INSERT INTO ARC_REC_CANDIATE_PROFILE(                    
REC_ID,PROCESS_ID,FIRSTNAME,LASTNAME,DOB,GENDER,MARITAL_STATUS,FATHER_NAME,SPOUSE_NAME,PER_ADDRESS1,PER_ADDRESS2,PER_LOCATION                    
,PER_STATE_ID,PER_CITY,PER_PINCODE,PRE_ADDRESS1,PRE_ADDRESS2,PRE_LOCATION,PRE_STATE_ID,PRE_CITY,PRE_PINCODE,TELEPHONE_NO                    
,MOBILE_NO,EMAIL_ID,REL_EXP,CTC,E_CTC,SHIFTS,KNOW_ABOUT_US,EMPLOYEE_ID,EMER_CONTACT_NAME,EMER_CONTACT_NO,BLOODGROUP,JOIN_DAYS,PRE_APPLIED,FBLIKE,FUNCTIONALITY_ID                             
)                    
VALUES                    
(                    
@AHS_RECID,@PROCESS_ID,@FIRSTNAME,@LASTNAME,@DOB,@GENDER,@MARITAL_STATUS,@FATHER_NAME,@SPOUSE_NAME,@PER_ADDRESS1,@PER_ADDRESS2,@PER_LOCATION                    
,@PER_STATE_ID,@PER_CITY,@PER_PINCODE,@PRE_ADDRESS1,@PRE_ADDRESS2,@PRE_LOCATION,@PRE_STATE_ID,@PRE_CITY,@PRE_PINCODE,@TELEPHONE_NO,@MOBILE_NO                    
,@EMAIL_ID,@REL_EXP,@CTC,@E_CTC,@SHIFTS,13,@EMPLOYEE_ID,@EMER_CONTACT_NAME,@EMER_CONTACT_NO,@BLOODGROUP,@JOIN_DAYS,@PRE_APPLIED,0,@FUNCTIONID                            
)        
               
                         
 INSERT INTO ARC_REC_CANDIDATE_STATUS (REC_ID,CREATED_DT,STATUS_ID,SCHEDULE_ID)                            
 SELECT @AHS_RECID,GETDATE(),@STATUS_ID,0        
       
 select 1            
          
END          
                    
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[S1_CANDIDATE_PROFILE_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[S1_CANDIDATE_PROFILE_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[S1_CANDIDATE_PROFILE_INS] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[S1_CANDIDATE_PROFILE_INS] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[S1_CANDIDATE_PROFILE_INS] TO [DB_DMLSupport]
    AS [dbo];

