﻿CREATE Proc ARC_REC_LegalDocument_Get      
@userid int =0    
As      
Begin      
select Docid,DocumentName,PathName,Publish, CONVERT(varchar(20),createdon,110) CreatedOn,  
UI.FIRSTNAME+''+UI.Lastname CreatedBy,Status,NT_Username,UI.Userid  
from ARC_REC_LegalDocument LD  
inner join ARC_REC_USER_INFO UI on UI.Userid=LD.createdby  
End  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_LegalDocument_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_LegalDocument_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_LegalDocument_Get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_LegalDocument_Get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_LegalDocument_Get] TO [DB_DMLSupport]
    AS [dbo];

