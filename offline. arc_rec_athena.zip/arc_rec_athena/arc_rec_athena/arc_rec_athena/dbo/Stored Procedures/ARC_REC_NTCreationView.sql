﻿CREATE procedure ARC_REC_NTCreationView            
  @SessionUserId int,                 
     @FunctionalityId int = 0                    
     ,@DesignationId int = 0                    
     ,@ClientId int = 0         
     ,@CreatedBy int = 0       
     ,@TicketId int = 0       
     ,@CreatedDateFrom date        
     ,@CreatedDateTo date                        
     ,@SearchStr varchar(max) =''                    
     ,@SearchPattern varchar(5)='%'      
                        
AS              
Begin        
         
Declare @sql as varchar(max)                  
declare @IsHr as int                
select @IsHr = isnull((select COUNT(*) from ARC_REC_USER_INFO where USERID = @SessionUserId and FUNCTIONALITY_ID = 6),0)  --- check whether hr or not                
set @sql = 'SELECT              
  CASE WHEN ISNULL(CA.PROFILE_IMAGE_NAME,'''') = '''' THEN                     
  ''<img src="https://arc.accesshealthcare.co/arc_rec/Images/UserImg.jpg" height="60" width="60" />''                                 
  ELSE ''<img src="https://arc.accesshealthcare.co/arc_rec/Images/Candidate/'' + CA.PROFILE_IMAGE_NAME+''" height="60" width="60" />'' END AS Associate                                    
  ,HDIS.TICKET_ID As [TICKET ID]              
  ,ISNULL(UI.EMPCODE,'''') AS Empcode 
  ,ISNULL(fac.FacilityName,'''') as Facility                      
  ,DBO.ConcatenateName(ui.FIRSTNAME,ui.MiddleName,ui.LASTNAME) as FullName                    
  ,UI.NT_USERNAME as [NT Username],UI.REPORTING_TO As [Reporting To]                    
  ,DE.DESIGNATION AS Designation,FU.FunctionName AS Functionality                    
  ,ISNULL(C.CLIENT_NAME,'''') AS Client                               
  ,CASE WHEN ISNULL(UI.DOJ,'''') = '''' THEN ''''                                
  ELSE CONVERT(VARCHAR,UI.DOJ,113) END AS Doj                                
  ,ISNULL(( SELECT TOP 1 SI.SHIFT_ID  FROM ARC_REC_SHIFT_TRAN T                                
  LEFT JOIN ARC_REC_SHIFT_INFO SI ON T.SHIFT_ID = SI.SHIFT_ID                                 
  WHERE T.USERID = UI.USERID ORDER BY T.CREATED_DT DESC),'''') AS [SHIFT_ID~Hide]                               
  ,ISNULL(( SELECT TOP 1 SI.SHIFT_NAME FROM ARC_REC_SHIFT_TRAN T                              
  LEFT JOIN ARC_REC_SHIFT_INFO SI ON T.SHIFT_ID = SI.SHIFT_ID                              
  WHERE T.USERID = UI.USERID ORDER BY T.CREATED_DT DESC  ),'''') AS Shift,              
       emailAccess.Description as [Email Access]                 
  ,distList.Description as [Dist List]                 
  ,folderAccess.Description as [Folder Access]               
  ,NtUpdateUi.Nt_UserName [NT CreatedBy]  
  ,Convert(varchar,NTL.Created_Dt,103) + Substring(Convert(varchar,NTL.Created_Dt),13,20)  [Nt CreatedOn]  
  ,CASE WHEN UI.ACTIVE = 1 THEN ''Yes'' ELSE ''No'' END AS [Active Status]                 
  into #NTCreationView                       
  FROM ARC_REC_USER_INFO AS UI                              
  LEFT JOIN ARC_REC_CANDIDATE AS CA ON CA.REC_ID = UI.REC_ID                              
  inner JOIN HR_DESIGNATION AS DE ON DE.DESIGID = UI.DESIGNATION_ID                                
  inner JOIN HR_FUNCTIONALITY AS FU ON FU.FunctionalityId = UI.FUNCTIONALITY_ID                                 
  inner JOIN ARC_REC_CustomerView C ON C.CLIENT_ID = UI.CLIENT_ID                
  left join ARC_REC_InductionMaster im on ui.USERID = im.UserId   
  left join ARC_REC_FacilityMaster fac on im.FacilityId = fac.FacilityId ' 
 if(@TicketId > 0)                    
 Set @sql = @sql + ' inner join HD_ISSUE_REQUEST HDIS on HDIS.ISS_REQID = im.NTReqId and HDIS.TICKET_ID ='+convert(varchar,@TicketId)   
 else  
 Set @sql = @sql + ' left join HD_ISSUE_REQUEST HDIS on HDIS.ISS_REQID = im.NTReqId'  
   
 Set @sql += ' left join ARC_REC_NtRequirementFields as emailAccess on emailAccess.RqId = im.EmailAccessId                 
left join ARC_REC_NtRequirementFields as distList on distList.RqId = im.DistributionAccessId                 
left join ARC_REC_NtRequirementFields as folderAccess on folderAccess.RqId = im.FolderAccessId  '  
if (@CreatedDateFrom is not null and @CreatedDateFrom <> '1900-01-01') or @CreatedBy > 0  
 Set @sql += ' inner join '  
else  
 Set @sql += ' left join '   
Set @sql +=  ' ARC_REC_NTlogin as NTL on NTL.EMPCODE = UI.EMPCODE '  
if @CreatedDateFrom is not null and @CreatedDateFrom <> '1900-01-01'  
 Set @sql += ' and CONVERT(date, NTL.CREATED_DT) Between ''' + CONVERT(varchar,@CreatedDateFrom)+'''  and '''+CONVERT(varchar,@CreatedDateTo)+''''    
if(@CreatedBy > 0)                    
 Set @sql += ' and NTL.CREATED_BY ='+convert(varchar,@CreatedBy)       
   
  Set @sql += '   
  left join ARC_REC_USER_INFO as NtUpdateUi on NtUpdateUi.UserId = NTL.Created_By  
  WHERE ISNULL(UI.AHS_PRL,''Y'') = ''Y'' and ISNULL(UI.NT_USERNAME,'''') <> ''''                     
 '              
 if(@FunctionalityId > 0)                    
 Set @sql = @sql + ' and UI.FUNCTIONALITY_ID ='+convert(varchar,@FunctionalityId)                    
                     
 if(@ClientId > 0)                    
 Set @sql = @sql + ' and UI.CLIENT_ID ='+convert(varchar,@ClientId)                    
                     
 if(@DesignationId > 0)                    
 Set @sql = @sql + ' and UI.DESIGNATION_ID ='+convert(varchar,@DesignationId)        
                    
 Set @sql = @sql + '                      
 Exec FilterTable                        
 @DbName = ''tempdb''                        
 ,@TblName = ''#NTCreationView''                        
 ,@SearchStr = '''+@SearchStr+'''                       
 ,@SearchPattern ='''+ @SearchPattern  +'''                      
 ,@OrderStr = ''''                      
 if OBJECT_ID(''tempdb..#NTCreationView'') is not null drop table #NTCreationView                          
  '  
  print @sql              
 exec(@sql)              
End     
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_NTCreationView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_NTCreationView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_NTCreationView] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_NTCreationView] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_NTCreationView] TO [DB_DMLSupport]
    AS [dbo];

