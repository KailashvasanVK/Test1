﻿CREATE PROCEDURE HD_CAB_REQUEST_INS      
  @ReqId int ,        
  @AssociateId int,        
  @TravelDt date,   
  @TravelTime time,       
  @Mode char(1),        
  @Place varchar(1000),        
  @Landmark varchar(500),        
  @CreatedBy int        
AS              
Begin        
 insert into HD_CabRequests(ReqId,AssociateId,TravelDt,TravelTime,Mode,Place,LandMark,Status,CreatedBy,CreatedDt)              
 select @ReqId,@AssociateId,@TravelDt,@TravelTime,@Mode,@Place,@Landmark,0,@CreatedBy,GETDATE()      
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_CAB_REQUEST_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_CAB_REQUEST_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_CAB_REQUEST_INS] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_CAB_REQUEST_INS] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_CAB_REQUEST_INS] TO [DB_DMLSupport]
    AS [dbo];

