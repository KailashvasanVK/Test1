﻿CREATE PROCEDURE HD_FACILITY_INS          
  @ISS_REQID INT = 0          
 ,@CREATED_BY INT = 0          
 ,@ACTION VARCHAR(50)          
 ,@DetailsId VARCHAR(MAX) = NULL         
AS      
 --Status 0 - Request; 1 - 'Pending - Resolution'; 2 - 'Reject by Supervisor'; 3 - 'Provide and Waiting - Acknowledge' ;4 - 'Reject by Facility'; 5 - 'Completed'    
BEGIN          
IF @ACTION = 'ARC_Stationery_Approvel'                              
  BEGIN                              
  UPDATE HD_StationeryRequest SET [Status] = 1,ApprovedBy = @CREATED_BY,ApprovedDt=GETDATE()            
  WHERE ISS_REQID = @ISS_REQID AND ItemId IN (SELECT items FROM fnSplitString(@DetailsId,',')) AND [Status]  = 0;          
  UPDATE HD_StationeryRequest SET [Status] = 2,ApprovedBy = @CREATED_BY,ApprovedDt=GETDATE()            
  WHERE ISS_REQID = @ISS_REQID AND ItemId NOT IN (SELECT items FROM fnSplitString(@DetailsId,',')) AND [Status]  = 0;       
  END            
IF @ACTION = 'ARC_Stationery_Process'            
 BEGIN            
  UPDATE HD_StationeryRequest SET [Status] = 3 ,ProcessedBy = @CREATED_BY,ProcessedDt=GETDATE()            
  WHERE ISS_REQID = @ISS_REQID AND ItemId IN (SELECT items FROM fnSplitString(@DetailsId,',')) AND [Status]  = 1;
  UPDATE HD_StationeryRequest SET [Status] = 4 ,ProcessedBy = @CREATED_BY,ProcessedDt=GETDATE()            
  WHERE ISS_REQID = @ISS_REQID AND ItemId NOT IN (SELECT items FROM fnSplitString(@DetailsId,',')) AND [Status] = 1;      
 END            
IF @ACTION = 'ARC_Cab_Approvel'            
 BEGIN            
  UPDATE HD_CabRequests SET [Status] = 1,ApprovedBy = @CREATED_BY,ApprovedDt=GETDATE()            
  WHERE ReqId = @ISS_REQID AND AssociateId IN (SELECT items FROM fnSplitString(@DetailsId,',')) AND [Status]  = 0;      
  UPDATE HD_CabRequests SET [Status] = 2,ApprovedBy = @CREATED_BY,ApprovedDt=GETDATE()            
  WHERE ReqId = @ISS_REQID AND AssociateId NOT IN (SELECT items FROM fnSplitString(@DetailsId,',')) AND [Status]  = 0;      
 END            
IF @ACTION = 'ARC_Cab_Process'            
 BEGIN            
  UPDATE HD_CabRequests SET [Status] = 3,ProcessedBy = @CREATED_BY,ProcessedDt=GETDATE()            
  WHERE ReqId = @ISS_REQID AND AssociateId IN (SELECT items FROM fnSplitString(@DetailsId,',')) AND [Status] = 1;          
  UPDATE HD_CabRequests SET [Status] = 4,ProcessedBy = @CREATED_BY,ProcessedDt=GETDATE()            
  WHERE ReqId = @ISS_REQID AND AssociateId NOT IN (SELECT items FROM fnSplitString(@DetailsId,',')) AND [Status] = 1;      
 END
 IF @ACTION = 'ARC_Stationery_Complete'            
 BEGIN            
  UPDATE HD_StationeryRequest SET [Status] = 5 WHERE ISS_REQID = @ISS_REQID AND [Status] = 3
 END  
IF @ACTION = 'ARC_Cab_Complete'            
 BEGIN            
  UPDATE HD_CabRequests SET [Status] = 5 WHERE ReqId = @ISS_REQID AND [Status] = 3
 END  
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_FACILITY_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_FACILITY_INS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_FACILITY_INS] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_FACILITY_INS] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_FACILITY_INS] TO [DB_DMLSupport]
    AS [dbo];

