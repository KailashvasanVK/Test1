﻿CREATE procedure ARC_REC_ITREQUEST_ITLIST_GET              
(              
@SupervisorID int =0             
)              
AS              
/*              
ARC_REC_ITREQUEST_ITLIST_GET @SupervisorID=807              
*/              
BEGIN              
Select  ROW_NUMBER() OVER (ORDER BY AITR.RequestId DESC) AS 'Sl_No',              
AITR.RequestId,RequestType=(case when RequestType=1 then 'New request' when RequestType=2 then 'Change request' end),              
FunctionId,FunctionName, RequestFrom=(case when RequestFrom=1 then 'Client' when RequestFrom=2 then 'Internal' end),               
(Case when LEN(Description)>50 then SUBSTRING(Description,1,50) + '...' else Description end) As Description,                  
(case when LEN(reason) >50 then substring(Reason,1,50) + '...' else Reason end )As Reason,                  
(case when len(Benifit)> 50 then Substring(Benifit,1,50) + '...' else benifit end) As Benifit,              
Description as 'Desc',Reason as 'Res',Benifit as 'Ben',              
AITR.CreatedBy,Priority,ApproveStatus,Supervisor,              
FIRSTNAME +' '+ LASTNAME as CreateName,ApprovedComments,RequestStatus,      
ITPRIORITY,replace(convert(varchar(20),ITEXPECTEDDATE,106),' ','-') ITEXPECTEDDATE,ITREQUESTSTATUS             
from               
ARC_REC_ITREQUEST AITR inner join HR_Functionality HRF on AITR.FunctionId=hrf.FunctionalityId              
left join ARC_REC_USER_INFO ui on ui.userId=AITR.CreatedBy       
LEFT JOIN ARC_REC_ITREQUEST_ITLIST IT ON IT.REQUESTID= AITR.RequestId      
where AITR.statusId=1              
order by AITR.RequestId desc              
              
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_ITLIST_GET] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_ITLIST_GET] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_ITLIST_GET] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_ITLIST_GET] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_ITLIST_GET] TO [DB_DMLSupport]
    AS [dbo];

