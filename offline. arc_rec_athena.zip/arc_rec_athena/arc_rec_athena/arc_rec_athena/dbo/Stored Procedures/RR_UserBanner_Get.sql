﻿CREATE Proc RR_UserBanner_Get                  
@userid int=1                  
as                  
/*              
RR_UserBanner_Get @userid=807              
*/              
begin                  
Declare @llid int,@prchpoint int,@sdpoint int                  
select LLId,USERID,Name,photo,SDpoint,PrchPoint,League+' League' League,LeaguePath,Client from  RR_UserBanner where userid=@userid                  
                  
select @llid=llid,@prchpoint=prchpoint,@sdpoint=SDpoint from RR_UserBanner where userid=@userid                  
select ROW_NUMBER() over( order by pd.PID  asc)sno, pd.PID,LLID,Productname,PPath,Purchasepoint,                  
Active=(case when purchasepoint <=@sdpoint then 1 else 0 end),                  
                  
purchase=(case when p.PId Is not null then 1 else 0 end) ,      
Purchasestatus =(Case when p.PurchaseStatus IS  null then ' Waiting !' when p.PurchaseStatus =1 then 'Reedemed the Gift' when  p.PurchaseStatus =2 then 'Waiting for Next Gift'      
 when  p.PurchaseStatus =3 then 'Waiting for Big Gift' end)      
 from RR_Product_Details PD             
 left join RR_SCOREBOARD_PURCHASE P on p.PId=pd.Pid and p.Userid=@userid            
where status=1                  
                   
end 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_UserBanner_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_UserBanner_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_UserBanner_Get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_UserBanner_Get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_UserBanner_Get] TO [DB_DMLSupport]
    AS [dbo];

