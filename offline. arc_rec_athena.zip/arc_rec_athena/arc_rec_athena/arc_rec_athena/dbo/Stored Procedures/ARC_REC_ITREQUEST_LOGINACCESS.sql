﻿CREATE Procedure ARC_REC_ITREQUEST_LOGINACCESS                  
(                  
@USERID INT =0                 
)                  
AS                  
/*                  
ARC_REC_ITREQUEST_LOGINACCESS @USERID=1                  
ARC_REC_ITREQUEST_LOGINACCESS @USERID=20         
    
--1452    
    
exec ARC_REC_ITREQUEST_LOGINACCESS @USERID=807    
    
select Userid,Associate Name from arc_rec_user_info_VY where USERID in(13,19,18,4,910,829,535)     
and Nt_username in (select REPORTING_TO from arc_rec_user_info_VY where userid=807)    
             
*/                  
BEGIN          
      
select Userid,Associate Name from arc_rec_user_info_VY where USERID in(13,19,18,4,910,829,535,1452,2351,847)     
--and Nt_username in (select REPORTING_TO from arc_rec_user_info_VY where userid=@USERID)    
order by Associate               
--Select USERID,FIRSTNAME +' '+ LASTNAME As NAME from ARC_REC_USER_INFO UI               
--inner join HR_Designation HD on                  
--ui.DESIGNATION_ID=hd.DesigId where hd.Supervisor='Y'                   
--and ui.USERID in(13,19,18,4,910,829)                
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_LOGINACCESS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_LOGINACCESS] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_LOGINACCESS] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_LOGINACCESS] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ITREQUEST_LOGINACCESS] TO [DB_DMLSupport]
    AS [dbo];

