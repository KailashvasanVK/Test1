﻿      --ARC_REC_MANUAL_ATTENDANCE_VIEW 19   
CREATE PROCEDURE ARC_REC_MANUAL_ATTENDANCE_VIEW 
      @USER_ID INT, 
      @MONTH_INDEX INT=0  
AS 
BEGIN   
   
DECLARE @month TINYINT   
--DECLARE @USER_ID  INT 
--SET @USER_ID = 19     
IF @MONTH_INDEX > 0 
 SET @month = @MONTH_INDEX 
ELSE 
 SET @month = DATEPART(MONTH,GETDATE());    

IF OBJECT_ID('TEMPDB..#MANUALATT','U') IS NOT NULL DROP TABLE #MANUALATT 
 
CREATE TABLE #MANUALATT (AID INT,USERID INT,ATTENDANCE_DATE DATE,ATT_TYPE VARCHAR(2000),TOTAL_HRS NUMERIC(8,2)  
,LATEIN NUMERIC(8,2),ADVANCEOUT NUMERIC(8,2)  
,CREATED_BY INT,CREATED_DT DATETIME,APPLIED_LEAVE INT,LEAVE_TYPE VARCHAR(50),LEAVE_MODE VARCHAR(50),REASON VARCHAR(MAX),ATT_DESC VARCHAR(MAX),LOGON DATETIME ,LOGOUT DATETIME) 
 
  
INSERT INTO #MANUALATT(AID,USERID,ATTENDANCE_DATE,ATT_TYPE,TOTAL_HRS,APPLIED_LEAVE,LEAVE_TYPE,LEAVE_MODE,REASON,ATT_DESC,LATEIN,ADVANCEOUT,LOGON,LOGOUT)    
SELECT Aid,@USER_ID,[DATE]  
,(CASE WHEN ISNULL(Verified_By,0) <> 0 THEN   
    CASE WHEN Verified_Present = 'F' THEN 'Full Present' WHEN Verified_Present = 'H' THEN 'Half Present'  ELSE  'Absent' END  
WHEN TOTALHRS >= dbo.ShiftDurationInMinutes(att.Shift_From,att.Shift_To,15) THEN 'Full Present' WHEN TotalHrs >= (dbo.ShiftDurationInMinutes(att.Shift_From,att.Shift_To,0)/2) THEN 'Half Present' ELSE 'Absent' 
   end)  
 ,TOTALHRS,0,'','','','',LateIn,LateOut,LogOn,LogOut   
FROM ARC_REC_Attendance att where Userid = @USER_ID  
and DATEPART(YEAR,[DATE]) = DATEPART(YEAR,GETDATE()) and DATEPART(MONTH,[DATE]) = @month  
and [DATE] >= (select DOJ from ARC_REC_USER_INFO where USERID = @USER_ID)    
  
  
/** updating requested leaves */ 
UPDATE #MANUALATT SET  
ATT_TYPE = CASE WHEN LR.TYPEID = 6 THEN case when lr.LEAVE_MODE = 'F' then 'Full LOP' else 'Half LOP' end     
  ELSE case when lr.LEAVE_MODE = 'F' then 'Full LWP' else 'Half Present' end end,  
LEAVE_TYPE = LTP.SHORT_TEXT,   
LEAVE_MODE = case when lr.LEAVE_MODE = 'F' then 'Full ' else 'Half ' end + case when LR.TYPEID = 6 THEN 'LOP' ELSE 'LWP' END,    
APPLIED_LEAVE = 1,      
REASON = LR.REASON      
FROM #MANUALATT SA   
INNER JOIN ARC_REC_LEAVE_TRAN AS LT ON LT.LEAVE_DATE = SA.ATTENDANCE_DATE 
INNER JOIN ARC_REC_LEAVE_REQUEST LR ON LR.LEAVE_REQID = LT.LEAVE_REQID AND LR.LEAVE_STATUS = 1 AND LR.CREATED_BY = SA.USERID and lr.TYPEID <> 5 and lr.ACTIVE = 'Y'      
INNER JOIN ARC_REC_LEAVE_TYPES AS LTP ON LTP.TYPEID = LR.TYPEID

/** updating requested permission */  
update #MANUALATT set ATT_TYPE = 'Full Present', LEAVE_TYPE = ltp.short_Text 
 from #MANUALATT  as av 
 inner join ARC_REC_LEAVE_REQUEST as lr on lr.CREATED_BY = av.Userid  and lr.ACTIVE = 'Y'    
 inner join ARC_REC_LEAVE_TYPES as ltp on ltp.TYPEID = lr.TYPEID     
 and CONVERT(CHAR(10),LR.FROMDATE,20) = CONVERT(CHAR(10), AV.ATTENDANCE_DATE,20) 
 and lr.TYPEID = 5 and LEAVE_STATUS = 1 and
 Convert(datetime,convert(char(16), av.Logon, 121)) between lr.FROMDATE and lr.TODATE
 where AV.LATEIN > 0 and av.ATT_TYPE = 'Half Present'    

 update #MANUALATT set ATT_TYPE = 'Full Present', Leave_Type = ltp.short_Text 
 from #MANUALATT as av 
 inner join ARC_REC_LEAVE_REQUEST as lr on lr.CREATED_BY = av.Userid and lr.ACTIVE = 'Y'
 inner join ARC_REC_LEAVE_TYPES as ltp on ltp.TYPEID = lr.TYPEID     
 and lr.TYPEID = 5 and LEAVE_STATUS = 1 
 and Convert(datetime,convert(char(16), av.Logout, 121)) between lr.FROMDATE and lr.TODATE
 where AV.ADVANCEOUT > 0 and av.ATT_TYPE = 'Half Present'  
  
 /** updating holiday for tp and ar */  
--UPDATE #MANUALATT SET   
--LEAVE_TYPE = CASE WHEN AV.ATT_TYPE = 'Half Present' THEN '' ELSE 'Holiday' END ,
--ATT_TYPE = CASE WHEN AV.ATT_TYPE = 'Half Present' THEN AV.ATT_TYPE    
--    ELSE 'Holiday' END 
--FROM #MANUALATT  AS AV 
--INNER JOIN ARC_REC_USER_INFO AS UI ON UI.USERID = AV.USERID    
--INNER JOIN (   
--   SELECT DATE FROM     
--    (     
--    SELECT ATT.Date,ATT.Shiftid,ATT.Userid     
--    ,CASE WHEN HL.HOLIDAY_DATE IS NOT NULL THEN HL.HOLIDAY_DATE    
-- WHEN ATT.Shiftid IN (2,3) AND DATENAME(WEEKDAY,ATT.Date) IN ('Saturday','Sunday') THEN ATT.Date    
--WHEN ATT.Shiftid = 1 AND DATENAME(WEEKDAY,ATT.Date) = 'Sunday' THEN ATT.Date    
--ELSE NULL END AS HOLIDAY     
--    ,HL.* FROM ARC_REC_Attendance AS ATT     
--    LEFT JOIN ARC_REC_LEAVE_HOLIDAYLIST AS HL ON HL.HOLIDAY_DATE = ATT.Date
--     AND HL.LISTTYPE = CASE WHEN ATT.Shiftid = 1 THEN 2 ELSE 1 END     
--    WHERE ATT.Date > '2012-12-31' and ATT.Userid = @USER_ID and   
--    DATEPART(YEAR,[DATE]) = DATEPART(YEAR,GETDATE()) and DATEPART(MONTH,[DATE]) = @month   
--    and [DATE] >= (select DOJ from ARC_REC_USER_INFO where USERID = @USER_ID)      
--    )X WHERE X.HOLIDAY IS NOT NULL
--   )Y ON Y.Date = AV.ATTENDANCE_DATE      
--where (av.ATT_TYPE = 'Absent' OR av.ATT_TYPE = 'Half Present')     
   
UPDATE #MANUALATT SET   
LEAVE_TYPE = CASE WHEN AV.ATT_TYPE = 'Half Present' THEN '' ELSE 'Holiday' END ,
ATT_TYPE = CASE WHEN AV.ATT_TYPE = 'Half Present' THEN AV.ATT_TYPE    
    ELSE 'Holiday' END 
FROM #MANUALATT  AS AV 
INNER JOIN ARC_REC_USER_INFO AS UI ON UI.USERID = AV.USERID    
INNER JOIN (   
   SELECT DATE FROM     
    (     
    SELECT ATT.Date,ATT.Shiftid,ATT.Userid     
    ,CASE WHEN DATENAME(WEEKDAY,ATT.Date) = 'Sunday' then ATT.DATE 
    WHEN DATENAME(WEEKDAY,ATT.Date) = 'Saturday' AND ISNULL(SI.SatOffEligible,'N') = 'N' THEN null    
    WHEN UI.FUNCTIONALITY_ID = 3 AND DATENAME(WEEKDAY,ATT.Date) = 'Saturday' THEN ATT.DATE     
    WHEN DATENAME(WEEKDAY,ATT.Date) = 'Saturday' AND ISNULL(SI.HOLIDAY_SAT,'Y') = 'Y' THEN ATT.DATE   
    WHEN HL.HOLIDAY_DATE IS NOT NULL THEN HL.HOLIDAY_DATE 
    ELSE NULL END AS HOLIDAY    
    ,HL.* FROM ARC_REC_Attendance AS ATT     
    INNER JOIN ARC_REC_USER_INFO AS UI (NOLOCK) ON UI.USERID = ATT.Userid      
    INNER JOIN ARC_REC_SHIFT_INFO AS SI ON SI.SHIFT_ID = ATT.Shiftid   
    LEFT JOIN ARC_REC_LEAVE_HOLIDAYLIST AS HL ON HL.HOLIDAY_DATE = ATT.Date AND HL.LISTTYPE = SI.HOLIDAY_LISTTYPE
    WHERE ATT.Date > '2012-12-31' and ATT.Userid = @USER_ID and   
    DATEPART(YEAR,[DATE]) = DATEPART(YEAR,GETDATE()) and DATEPART(MONTH,[DATE]) = @month   
    and [DATE] >= (select DOJ from ARC_REC_USER_INFO where USERID = @USER_ID)      
    )X WHERE X.HOLIDAY IS NOT NULL
   )Y ON Y.Date = AV.ATTENDANCE_DATE      
where (av.ATT_TYPE = 'Absent' OR av.ATT_TYPE = 'Half Present')   
   
    
UPDATE A1  SET    
A1.ATT_DESC = CASE WHEN A2.ATT_TYPE = 'Absent' THEN 'Full LOP - Total Hrs : '+ CONVERT(VARCHAR,A2.TOTAL_HRS) + case when A2.LATEIN > 0 then ' - Late In : ' +     
 CONVERT(VARCHAR,A2.LATEIN) else '' end + case when A2.ADVANCEOUT> 0 then ' - Advance out : ' +      
 CONVERT(VARCHAR,A2.ADVANCEOUT) else '' END 
WHEN A2.ATT_TYPE = 'Half Present' AND A2.LEAVE_TYPE = 'Holiday' THEN 'Half Present - Half LWP (Holiday)'   
      WHEN A2.ATT_TYPE = 'Half Present' AND A2.APPLIED_LEAVE = 1 THEN 'Half Present - Half LWP'+' (Leave Applied - '+A2.REASON+') '  
 ELSE A2.ATT_TYPE END +( 
 CASE WHEN A2.ATT_TYPE = 'Holiday' AND A2.TOTAL_HRS > 0 THEN ' - Total Hrs : '+ CONVERT(VARCHAR,A2.TOTAL_HRS) + case when A2.LATEIN > 0 then ' - Late In : ' +      
 CONVERT(VARCHAR,A2.LATEIN) else '' end + case when A2.ADVANCEOUT> 0 then ' - Advance out : ' + CONVERT(VARCHAR,A2.ADVANCEOUT) else '' end  
   WHEN A2.ATT_TYPE = 'Holiday' THEN ''   
   WHEN A2.TOTAL_HRS > 0 THEN ' - Total Hrs : '+ CONVERT(VARCHAR,A2.TOTAL_HRS) + case when A2.LATEIN > 0 then ' - Late In : ' + CONVERT(VARCHAR,A2.LATEIN) else '' end + case when A2.ADVANCEOUT> 0 then ' - Advance out : '      
   + CONVERT(VARCHAR,A2.ADVANCEOUT) else '' end  
   WHEN A2.APPLIED_LEAVE > 0 THEN ' (Leave Applied - '+A2.REASON+') '   
   ELSE '' END)  

FROM #MANUALATT A1 JOIN #MANUALATT A2 ON A1.ATTENDANCE_DATE = A2.ATTENDANCE_DATE   
    
SELECT AID,CONVERT(VARCHAR,ATTENDANCE_DATE,113) AS ATTENDANCE_DATE,ATT_TYPE,TOTAL_HRS,APPLIED_LEAVE,LEAVE_TYPE,LEAVE_MODE,REASON,ATT_DESC,    
LOGON AS LOGIN_TIME,LOGOUT AS LOGOUT_TIME FROM #MANUALATT 
  
END 



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_MANUAL_ATTENDANCE_VIEW] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_MANUAL_ATTENDANCE_VIEW] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_MANUAL_ATTENDANCE_VIEW] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_MANUAL_ATTENDANCE_VIEW] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_MANUAL_ATTENDANCE_VIEW] TO [DB_DMLSupport]
    AS [dbo];

