﻿CREATE Procedure ARC_REC_SHIFTINFO_GET 
@NTUserName Varchar(75)=NULL     
As    
Begin    
Select SHIFT_ID,SHIFT_NAME  from ARC_REC_SHIFT_INFO     
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_SHIFTINFO_GET] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_SHIFTINFO_GET] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_SHIFTINFO_GET] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_SHIFTINFO_GET] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_SHIFTINFO_GET] TO [DB_DMLSupport]
    AS [dbo];

