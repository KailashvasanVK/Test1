﻿CREATE Procedure dbo.HR_MPR_Display(@Mprid int)                        
as                       
/*                    
                   
 HR_MPR_Display 395                    
                    
                       
*/                      
                      
SELECT                        
 convert(varchar(25), mpr.CreatedDate, 107) as 'Raisedon',                       
convert(varchar(25), mpr.ExpDate, 107) as [ExpectedDate],                  
 um.UserName,                       
 tm.Facility TrainingCentre,                       
 f.FunctionName,                       
 d.Designation,                       
(case when Tm.TCId  IN (3) then 'PHP.' else 'Rs.'  end)+ dbo.RupeeFormat_Rounded(cast(mpr.SalaryMin as varchar)) as [Salmin],                    
(case when Tm.TCId  IN (3) then 'PHP.' else 'Rs.'  end)+ dbo.RupeeFormat_Rounded(cast(mpr.SalaryMax as varchar)) as [SalMax],                    
 mpr.*,cl.CLIENT_NAME Client, convert(varchar(5),mpr.expfromyears)+' To '+Convert(varchar(5),exptoyears) +' Years' EXPyear FROM                         
HR_MPR mpr INNER JOIN HR_functionality f on f.FunctionalityId = mpr.FunctionalityId                        
INNER JOIN HR_designation d on d.desigId = mpr.desigID                        
INNER JOIN HR_FacilityMaster tm on tm.Tcid = mpr.Tcid                        
INNER JOIN mrplogin um on um.UserId = mpr.CreatedBy               
left join  ARC_FIN_CLIENT_INFO Cl on cl.CLIENT_ID =mpr.clientid                         
where mpr.MPRId = @MPRId 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_MPR_Display] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_Display] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_Display] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_MPR_Display] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_Display] TO [DB_DMLSupport]
    AS [dbo];

