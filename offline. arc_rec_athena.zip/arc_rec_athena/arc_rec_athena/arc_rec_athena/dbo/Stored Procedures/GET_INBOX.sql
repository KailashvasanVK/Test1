﻿--GET_INBOX '','','','','979053'    
CREATE PROCEDURE GET_INBOX                
 @FromDt Date,                
 @ToDt Date,                
 @REC_ID VARCHAR(50),                
 @Name Varchar(500),    
 @ContactNo Varchar(20)                
AS                
BEGIN                
            
--GET_INBOX '2013-08-01','2013-08-08',null,null                   
 --EXEC GET_INBOX                  
 -- declare @FromDt date                   
 --declare @ToDt date                   
 --declare @REC_ID varchar(50)                   
 --declare @Name varchar(500)   
 --declare @ContactNo Varchar(20)   
 --set @FromDt = '2014-01-10'                   
 --set @ToDt = '2014-01-26'                   
                  
SET NOCOUNT ON                  
SET @FromDt = CONVERT(VARCHAR,CONVERT(DATE,ISNULL(@FromDt,'1900-01-01')),101)                  
SET @ToDt = CONVERT(VARCHAR,CONVERT(DATE,CASE WHEN @ToDt = '1900-01-01' THEN GETDATE() ELSE ISNULL(@ToDt,GETDATE()) END ),101)                  
                    
--select @FromDt,@ToDt                    
SELECT @Name = CASE WHEN ISNULL(@NAME,'') = '' THEN '' ELSE '%' + @Name + '%' END                  
                  
IF OBJECT_ID('TEMPDB..#INBOX','U') IS NOT NULL DROP TABLE #INBOX                  
CREATE TABLE #INBOX (CREATED_DT DATE,REC_ID VARCHAR(10),CNAME VARCHAR(200),PROCESS_NAME VARCHAR(100),CODING_SPECIALIZATION                    
VARCHAR(1000),[CURRENT COMPANY] VARCHAR(500),REXP VARCHAR(50)                  
,STATUS_TYPING VARCHAR(50),STATUS_APS VARCHAR(50),STATUS_ENG VARCHAR(50),STATUS_COD VARCHAR(50),STATUS_HR VARCHAR(50),STATUS_OPS VARCHAR(20),STATUS_FD VARCHAR(20)                  
,HAS_TYPING VARCHAR(1),HAS_APS VARCHAR(1),HAS_ENG VARCHAR(1),HAS_COD VARCHAR(1)                  
,TYPING_SCORE VARCHAR(50),APS_SCORE VARCHAR(50)                  
,ENG_SCORE VARCHAR(50),CODING_SCORE VARCHAR(50),CONTACT_NO VARCHAR(100),EMAIL_ID VARCHAR(100),NO_OF_APPEARANCE INT)                  
                  
DECLARE @QRY VARCHAR(MAX)                  
SET @QRY = '                  
INSERT INTO #INBOX (                  
CREATED_DT,REC_ID,CNAME,PROCESS_NAME,CODING_SPECIALIZATION,[CURRENT COMPANY],REXP,CONTACT_NO,EMAIL_ID,NO_OF_APPEARANCE                  
,STATUS_TYPING,STATUS_APS,STATUS_ENG,STATUS_COD,STATUS_HR,STATUS_OPS,STATUS_FD                  
,HAS_TYPING,HAS_APS,HAS_ENG,HAS_COD,TYPING_SCORE,APS_SCORE,ENG_SCORE,CODING_SCORE                  
)                  
SELECT Convert(DATE,P.CREATED_DT) AS CREATED_DT,P.REC_ID,P.FIRSTNAME + CASE WHEN ISNULL(P.LASTNAME,'''') <> '''' THEN'' '' + P.LASTNAME ELSE '''' END AS CNAME                  
,CASE WHEN P.PROCESS_ID = 4 then PRO.PROCESS_NAME+'' (''+OTF.FunctionName+'')'' ELSE PRO.PROCESS_NAME end as PROCESS_NAME,'''',ISNULL(WO.COMPANY_NAME,'''') AS PREV_COMPANY,EX.REL_EXP_TEXT AS REXP                  
,case when P.MOBILE_NO = '''' then P.TELEPHONE_NO when P.MOBILE_NO = '''' and P.TELEPHONE_NO = '''' then P.EMER_CONTACT_NO else P.MOBILE_NO end  
,P.EMAIL_ID 
,(select dbo.ARC_REC_CandidateAppearance (P.REC_ID)) as NO_OF_APPREARANCE  
,CONVERT(VARCHAR(20),'''')STATUS_TYPING                  
,CONVERT(VARCHAR(20),'''')STATUS_APS                  
,CONVERT(VARCHAR(20),'''')STATUS_ENG                  
,CONVERT(VARCHAR(20),'''')STATUS_COD                  
,CONVERT(VARCHAR(20),'''')STATUS_HR                  
,CONVERT(VARCHAR(20),'''')STATUS_OPS                  
,CONVERT(VARCHAR(20),'''')STATUS_FD                    
,CASE WHEN P.PROCESS_ID = 1 AND P.REL_EXP = 1 THEN ''Y'' ELSE ''N'' END AS HAS_TYPING                    
,CASE WHEN P.CREATED_DT < convert(date,''2013-10-31'') and P.PROCESS_ID = 1 AND P.REL_EXP = 1 THEN ''Y''       
   WHEN P.CREATED_DT >= convert(date,''2013-10-31'') and P.PROCESS_ID = 1 AND P.REL_EXP = 1 THEN ''N''      
      WHEN (P.CREATED_DT < convert(date,''2013-10-31'') and  P.PROCESS_ID = 5 AND P.REL_EXP = 1) AND ((SELECT TOP 1 TEST_TYPE FROM ARC_REC_TEST WHERE REC_ID = P.REC_ID ORDER BY TEST_ID DESC) = ''A'') THEN ''Y''       
      WHEN (P.CREATED_DT >= convert(date,''2013-10-31'') and  P.PROCESS_ID = 5 AND P.REL_EXP = 1) AND ((SELECT TOP 1 TEST_TYPE FROM ARC_REC_TEST WHERE REC_ID = P.REC_ID ORDER BY TEST_ID DESC) = ''A'') THEN ''N''       
      ELSE ''N'' END AS HAS_APS                    
,CASE WHEN P.PROCESS_ID = 2 AND P.REL_EXP = 1 THEN ''Y'' ELSE ''N'' END AS HAS_ENG                    
,CASE WHEN P.PROCESS_ID = 3 THEN ''Y''                  
 WHEN P.PROCESS_ID = 5 AND P.REL_EXP = 1 AND ((SELECT TOP 1 TEST_TYPE FROM ARC_REC_TEST WHERE REC_ID = P.REC_ID ORDER BY TEST_ID DESC) = ''A'') THEN ''N''                  
WHEN P.PROCESS_ID = 5 AND P.REL_EXP = 1 THEN ''Y''                    
 ELSE ''N'' END AS HAS_COD                   
,'''','''','''',''''                  
FROM ARC_REC_CANDIATE_PROFILE AS P                  
INNER JOIN ARC_REC_CANDIDATE AS CAN ON P.REC_ID= CAN.REC_ID                   
INNER JOIN ARC_REC_PROCESS_INFO AS PRO ON PRO.PROCESS_ID = P.PROCESS_ID                  
LEFT JOIN HR_Functionality AS OTF ON P.FUNCTIONALITY_ID = OTF.FunctionalityId              
INNER JOIN ARC_REC_EXPERIENCE_INFO AS EX ON EX.REL_EXP = P.REL_EXP                  
 LEFT JOIN (                  
select W.REC_ID,W.COMPANY_NAME,W.DOJ from ARC_REC_CANDIDATE_WORKEXP W                   
 inner join (select MAX(DOJ) AS DOJ,REC_ID from ARC_REC_CANDIDATE_WORKEXP group by REC_ID)X                   
 on X.REC_ID = W.REC_ID and X.DOJ = W.DOJ  )WO ON  P.REC_ID = WO.REC_ID                    
WHERE EXISTS                  
(                  
 SELECT 1 FROM                  
 (                   
 SELECT DISTINCT REC_ID FROM ARC_REC_TYPING_TEST WHERE CONVERT(DATE,CREATED_DT) BETWEEN '''+CONVERT(VARCHAR,@FromDt,101)+''' AND'''+CONVERT(VARCHAR,@ToDt,101)+'''                  
 UNION                  
 SELECT DISTINCT REC_ID FROM ARC_REC_TEST WHERE CONVERT(DATE,CREATED_DT) BETWEEN '''+CONVERT(VARCHAR,@FromDt,101)+''' AND'''+CONVERT(VARCHAR,@ToDt,101)+'''                  
 UNION                  
 SELECT DISTINCT REC_ID FROM ARC_REC_CANDIDATE_STATUS WHERE CONVERT(DATE,CREATED_DT) BETWEEN '''+CONVERT(VARCHAR,@FromDt,101)+''' AND'''+CONVERT(VARCHAR,@ToDt,101)+'''                  
 UNION                  
 SELECT DISTINCT REC_ID FROM ARC_REC_CANDIATE_PROFILE WHERE CONVERT(DATE,CREATED_DT) BETWEEN '''+CONVERT(VARCHAR,@FromDt,101)+''' AND '''+CONVERT(VARCHAR,@ToDt,101)+'''                  
 )X                  
 WHERE X.REC_ID = P.REC_ID AND X.REC_ID NOT IN (SELECT REC_ID FROM ARC_REC_USER_INFO WHERE DOJ < ''2012-09-28'')                  
AND CAN.CREATED_DT between '''+CONVERT(VARCHAR,@FromDt,101)+''' and '''+CONVERT(VARCHAR,convert(date,DATEADD(DAY, 1, @ToDt)),101)+'''                   
                    
)'                  
                  
IF @REC_ID <> '0' AND @REC_ID <> ''                  
 SET @QRY += ' AND P.REC_ID = '+@REC_ID                  
IF ISNULL(@Name,'') <> ''                  
 SET @QRY += ' AND (P.FIRSTNAME LIKE '''+@NAME+''' OR P.LASTNAME LIKE '''+@NAME+''')'                  
IF ISNULL(@ContactNo,'') <> ''                  
 SET @QRY += ' AND (P.MOBILE_NO LIKE ''%'+@ContactNo+'%'' OR P.TELEPHONE_NO LIKE ''%'+@ContactNo+'%'' OR P.EMER_CONTACT_NO LIKE ''%'+@ContactNo+'%'')'        
    print(@QRY)              
EXEC(@QRY)                  
                
-- typing score 25 and acc 95 before 2013-06-26                
UPDATE #INBOX SET STATUS_TYPING =  ISNULL(CASE WHEN TE.GROSS_WPM >= 25 AND TE.ACCURACY >= 95 THEN 'Pass'                  
when TE.HAS_COMPLETED = 1 then 'Fail' WHEN ABS(DATEDIFF(SS,CONVERT(TIME,GETDATE()),CONVERT(TIME,TE.CREATED_DT))/60) >= 10 THEN 'Fail' ELSE 'InProgress'end,'Pending')                  
FROM #INBOX AS INB                  
INNER JOIN                  
(                  
 SELECT TE.* FROM ARC_REC_TYPING_TEST AS TE                  
 INNER JOIN                  
 (                  
 SELECT MAX(TEST_ID) TEST_ID,REC_ID FROM ARC_REC_TYPING_TEST AS TE                  
 WHERE EXISTS (SELECT 1 FROM #INBOX WHERE REC_ID = TE.REC_ID)                  
 GROUP BY REC_ID                  
 )X ON X.REC_ID = TE.REC_ID AND X.TEST_ID = TE.TEST_ID                  
)TE ON TE.REC_ID = INB.REC_ID                  
INNER JOIN ARC_REC_CANDIATE_PROFILE P ON INB.REC_ID = P.REC_ID                
INNER JOIN ARC_REC_PROCESS_INFO PR ON P.PROCESS_ID = PR.PROCESS_ID                
WHERE INB.HAS_TYPING = 'Y' AND INB.CREATED_DT < convert(date,'2013-06-26')                  
                
                
-- typing score 20 and acc 95 after 2013-06-26                
UPDATE #INBOX SET STATUS_TYPING =  ISNULL(CASE WHEN TE.GROSS_WPM >= PR.TYPING_GPM AND TE.ACCURACY >= PR.TYPING_ACCURACY THEN 'Pass'                  
when TE.HAS_COMPLETED = 1 then 'Fail' WHEN ABS(DATEDIFF(SS,CONVERT(TIME,GETDATE()),CONVERT(TIME,TE.CREATED_DT))/60) >= 10 THEN 'Fail' ELSE 'InProgress'end,'Pending')                  
FROM #INBOX AS INB                  
INNER JOIN                  
(                  
 SELECT TE.* FROM ARC_REC_TYPING_TEST AS TE                  
 INNER JOIN                  
 (                  
 SELECT MAX(TEST_ID) TEST_ID,REC_ID FROM ARC_REC_TYPING_TEST AS TE                  
 WHERE EXISTS (SELECT 1 FROM #INBOX WHERE REC_ID = TE.REC_ID)           
 GROUP BY REC_ID                  
 )X ON X.REC_ID = TE.REC_ID AND X.TEST_ID = TE.TEST_ID                  
)TE ON TE.REC_ID = INB.REC_ID                  
INNER JOIN ARC_REC_CANDIATE_PROFILE P ON INB.REC_ID = P.REC_ID                
INNER JOIN ARC_REC_PROCESS_INFO PR ON P.PROCESS_ID = PR.PROCESS_ID                
WHERE INB.HAS_TYPING = 'Y' AND INB.CREATED_DT >= convert(date,'2013-06-26')                
                
IF OBJECT_ID('TEMPDB..#INBOX_TEST') IS NOT NULL DROP TABLE #INBOX_TEST                  
SELECT TE.* INTO #INBOX_TEST FROM ARC_REC_TEST AS TE                  
 INNER JOIN                  
 ( SELECT MAX(TEST_ID) TEST_ID,REC_ID,TEST_TYPE FROM ARC_REC_TEST AS TE         
 WHERE EXISTS (SELECT 1 FROM #INBOX WHERE REC_ID = TE.REC_ID)                  
 GROUP BY REC_ID,TEST_TYPE                  
 )X ON X.REC_ID = TE.REC_ID AND X.TEST_ID = TE.TEST_ID                  
                  
UPDATE #INBOX SET STATUS_APS = ISNULL(CASE WHEN TE.RESULT = 1 THEN 'Pass'                
WHEN te.HAS_COMPLETED = 1 and te.result = 0 THEN 'Fail' WHEN ABS(DATEDIFF(SS,CONVERT(TIME,GETDATE()),CONVERT(TIME,TE.CREATED_DT))/60) >= 30 AND te.RESULT = 0 THEN 'Fail' ELSE 'InProgress' END,'Pending')                  
FROM #INBOX AS INB                  
INNER JOIN #INBOX_TEST TE ON TE.REC_ID = INB.REC_ID AND TE.TEST_TYPE = 'A'                  
WHERE INB.HAS_APS = 'Y'                  
                  
UPDATE #INBOX SET STATUS_ENG = ISNULL(CASE WHEN TE.RESULT = 1 THEN 'Pass' WHEN te.HAS_COMPLETED = 1 and te.result = 0 THEN 'Fail' WHEN ABS(DATEDIFF(SS,CONVERT(TIME,GETDATE()),CONVERT(TIME,TE.CREATED_DT))/60) >= 30 AND te.RESULT = 0                   
THEN 'Fail' ELSE 'InProgress' END,'Pending')                  
FROM #INBOX AS INB                  
INNER JOIN #INBOX_TEST TE ON TE.REC_ID = INB.REC_ID AND TE.TEST_TYPE = 'E'                  
WHERE INB.HAS_ENG = 'Y'                  
                  
UPDATE #INBOX SET STATUS_COD = ISNULL(CASE WHEN TE.RESULT = 1 THEN 'Pass' WHEN te.HAS_COMPLETED = 1 and te.result = 0                   
THEN 'Fail' WHEN ABS(DATEDIFF(SS,CONVERT(TIME,GETDATE()),CONVERT(TIME,TE.CREATED_DT))/60) >= 30 AND te.RESULT = 0 THEN 'Fail' ELSE 'InProgress' END,'Pending')                  
FROM #INBOX AS INB                  
INNER JOIN #INBOX_TEST TE ON TE.REC_ID = INB.REC_ID AND TE.TEST_TYPE = 'C'                  
WHERE INB.HAS_COD = 'Y'                  
                  
                  
UPDATE #INBOX SET STATUS_HR =                  
CASE WHEN  ASS.RESULT  = 'S' THEN 'Selected' WHEN ASS.RESULT  = 'R' THEN 'Rejected' WHEN ASS.RESULT  = 'H' THEN 'Hold'                  
  WHEN ISNULL(CS.STATUS_ID,0) = 1 AND ISNULL(CS.SCHEDULE_ID,0) <> 0 THEN 'Scheduled' ELSE 'Pending' END                  
FROM #INBOX AS INB                  
Left JOIN ARC_REC_ASSESSMENT AS ASS ON ASS.REC_ID = INB.REC_ID AND ASS.ASSESS_MODE = 'H'                  
left join ARC_REC_CANDIDATE_STATUS AS CS ON CS.REC_ID = INB.REC_ID                  
                  
UPDATE #INBOX SET STATUS_OPS =          
CASE WHEN  ASS.RESULT  = 'S' THEN 'Selected' WHEN ASS.RESULT  = 'R' THEN 'Rejected' WHEN ASS.RESULT  = 'H' THEN 'Hold'                  
WHEN ISNULL(CS.STATUS_ID,0) = 2 AND ISNULL(CS.SCHEDULE_ID,0) <> 0 THEN 'Scheduled' ELSE 'Pending' END                  
FROM #INBOX AS INB                  
Left JOIN ARC_REC_ASSESSMENT AS ASS ON ASS.REC_ID = INB.REC_ID AND ASS.ASSESS_MODE = 'O'                  
left join ARC_REC_CANDIDATE_STATUS AS CS ON CS.REC_ID = INB.REC_ID                  
                  
UPDATE #INBOX SET STATUS_FD =                  
CASE  WHEN  ASS.APPLICANT_STATUS = 'S' THEN 'Selected' WHEN ASS.APPLICANT_STATUS = 'R' THEN 'Rejected' WHEN ASS.APPLICANT_STATUS = 'H' THEN 'Hold'                  
WHEN ISNULL(CS.STATUS_ID,0) = 3 AND ISNULL(CS.SCHEDULE_ID,0) <> 0 THEN 'Scheduled' ELSE 'Pending' END                  
FROM #INBOX AS INB                  
Left JOIN ARC_REC_ASSESSMENT AS ASS ON ASS.REC_ID = INB.REC_ID AND ASS.ASSESS_MODE = 'S'                  
left join ARC_REC_CANDIDATE_STATUS AS CS ON CS.REC_ID = INB.REC_ID                  
                  
UPDATE #INBOX SET STATUS_TYPING = CASE WHEN HAS_TYPING = 'Y' AND STATUS_TYPING = '' THEN 'Pending' ELSE STATUS_TYPING END       
 ,STATUS_APS = CASE WHEN HAS_APS = 'Y' AND STATUS_APS = '' THEN 'Pending' ELSE STATUS_APS END                  
 ,STATUS_ENG = CASE WHEN HAS_ENG = 'Y' AND STATUS_ENG = '' THEN 'Pending' ELSE STATUS_ENG END                  
 ,STATUS_COD = CASE WHEN HAS_COD = 'Y' AND STATUS_COD = '' THEN 'Pending' ELSE STATUS_COD END                  
 ,STATUS_HR = CASE WHEN STATUS_HR = '' THEN 'Pending' ELSE STATUS_HR END                  
 ,STATUS_OPS = CASE WHEN STATUS_OPS = '' THEN 'Pending' ELSE STATUS_OPS END                  
 ,STATUS_FD = CASE WHEN STATUS_FD = '' THEN 'Pending' ELSE STATUS_FD END                  
                  
UPDATE #INBOX SET STATUS_APS = CASE WHEN STATUS_TYPING = 'Fail' AND HAS_APS = 'Y' AND STATUS_APS = 'Pending' THEN 'NR' ELSE STATUS_APS END                  
,STATUS_ENG = CASE WHEN STATUS_TYPING = 'Fail' AND HAS_ENG = 'Y' AND STATUS_ENG = 'Pending' THEN 'NR' ELSE STATUS_ENG END                  
,STATUS_COD = CASE WHEN STATUS_TYPING = 'Fail' AND HAS_COD = 'Y' AND STATUS_COD = 'Pending' THEN 'NR' ELSE STATUS_COD END                  
,STATUS_HR = CASE WHEN (STATUS_TYPING = 'Fail' OR STATUS_APS = 'Fail' OR STATUS_ENG = 'Fail' OR STATUS_COD = 'Fail') AND STATUS_HR = 'Pending' THEN 'NR' ELSE STATUS_HR END                  
,STATUS_OPS = CASE WHEN (STATUS_TYPING = 'Fail' OR STATUS_APS = 'Fail' OR STATUS_ENG = 'Fail' OR STATUS_COD = 'Fail') AND STATUS_OPS = 'Pending' THEN 'NR' ELSE STATUS_OPS END                  
,STATUS_FD = CASE WHEN (STATUS_TYPING = 'Fail' OR STATUS_APS = 'Fail' OR STATUS_ENG = 'Fail' OR STATUS_COD = 'Fail') AND STATUS_FD = 'Pending' THEN 'NR' ELSE STATUS_FD END                  
                  
UPDATE #INBOX SET STATUS_OPS = CASE WHEN STATUS_HR = 'Rejected' AND STATUS_OPS = 'Pending' THEN 'NR' ELSE STATUS_OPS END                  
,STATUS_FD = CASE WHEN STATUS_OPS = 'Rejected' AND STATUS_FD = 'Pending' THEN 'NR' ELSE STATUS_FD END                  
                  
                  
  UPDATE #INBOX  SET CODING_SPECIALIZATION = QB.GROUPNAME                  
  FROM #INBOX AS INB                   
  inner join ARC_REC_EXPERIENCE_INFO as expi on expi.REL_EXP_TEXT = inb.REXP and expi.REL_EXP <> 1                  
  INNER JOIN                  
  (                  
  select REC_ID,max(TE.TEST_ID)test_id,max(TET.QID) AS QID from ARC_REC_TEST as te                   
  INNER JOIN ARC_REC_TEST_TRAN AS TET ON TET.TEST_ID = TE.TEST_ID                   
  where te.TEST_TYPE = 'C'                  
  group by REC_ID                  
  )X ON X.REC_ID = INB.REC_ID                  
  INNER JOIN ARC_REC_QBANK AS QB ON QB.QID = X.QID                  
                   
-- typing score 25 and acc 95 before 2013-06-26                
  update #INBOX set                    
  TYPING_SCORE = (SELECT TOP 1 'WPM : ' + convert(varchar,GROSS_WPM) + '/25 & ACC : ' + convert(varchar,ACCURACY)+' /95 ' FROM ARC_REC_TYPING_TEST WHERE REC_ID = I.REC_ID ORDER BY CREATED_DT DESC)                    
  from #INBOX I                    
  where I.STATUS_TYPING IN ('Pass','Fail')  AND I.CREATED_DT < '2013-06-26'                 
                
  -- typing score 20 and acc 95 after 2013-06-26               
  update #INBOX set                    
  TYPING_SCORE = (SELECT TOP 1 'WPM : ' + convert(varchar,GROSS_WPM) + '/'+convert(varchar,P.TYPING_GPM)+' & ACC : ' + convert(varchar,ACCURACY)+' /'+convert(varchar,P.TYPING_ACCURACY) +' ' FROM ARC_REC_TYPING_TEST WHERE REC_ID = I.REC_ID             
  ORDER BY CREATED_DT DESC)                    
  from #INBOX I               
  INNER JOIN ARC_REC_PROCESS_INFO P ON I.PROCESS_NAME = P.PROCESS_NAME                   
  where I.STATUS_TYPING IN ('Pass','Fail') AND I.CREATED_DT >= '2013-06-26'                  
                   
  update #INBOX set                    
  APS_SCORE = 'Score : ' + (select TOP 1 convert(varchar,SCORE)+'/15' from ARC_REC_TEST where REC_ID = I.REC_ID and TEST_TYPE = 'A' ORDER BY CREATED_DT DESC)                    
  from #INBOX I                    
  where I.STATUS_APS IN ('Pass','Fail')                    
                   
  update #INBOX set                    
  ENG_SCORE = 'Score : ' + (select TOP 1 convert(varchar,SCORE)+'/15' from ARC_REC_TEST where REC_ID = I.REC_ID and TEST_TYPE = 'E' ORDER BY CREATED_DT DESC)                    
  from #INBOX I                    
  where I.STATUS_ENG IN ('Pass','Fail')                    
                   
  update #INBOX set                    
  CODING_SCORE = 'Score : ' + (select TOP 1 convert(varchar,SCORE)+'/15' from ARC_REC_TEST where REC_ID = I.REC_ID and TEST_TYPE = 'C' ORDER BY CREATED_DT DESC)                    
  from #INBOX I                    
  where I.STATUS_COD IN ('Pass','Fail')                    
                  
  SELECT * FROM #INBOX              
                  
                  
------GET_INBOX '2013-08-01','2013-08-08',null,null                 
---- --EXEC GET_INBOX                
---- -- declare @FromDt date                 
---- --declare @ToDt date                 
---- --declare @REC_ID varchar(50)                 
---- --declare @Name varchar(500)                 
                 
---- --set @FromDt = '2013-06-10'                 
---- --set @ToDt = '2013-06-26'                 
                
----SET NOCOUNT ON                
----SET @FromDt = CONVERT(VARCHAR,CONVERT(DATE,ISNULL(@FromDt,'1900-01-01')),101)                
----SET @ToDt = CONVERT(VARCHAR,CONVERT(DATE,CASE WHEN @ToDt = '1900-01-01' THEN GETDATE() ELSE ISNULL(@ToDt,GETDATE()) END ),101)                
                  
------select @FromDt,@ToDt                  
----SELECT @Name = CASE WHEN ISNULL(@NAME,'') = '' THEN '' ELSE '%' + @Name + '%' END                
                
----IF OBJECT_ID('TEMPDB..#INBOX','U') IS NOT NULL DROP TABLE #INBOX                
----CREATE TABLE #INBOX (CREATED_DT DATE,REC_ID VARCHAR(10),CNAME VARCHAR(200),PROCESS_NAME VARCHAR(100),CODING_SPECIALIZATION                  
----VARCHAR(1000),[CURRENT COMPANY] VARCHAR(500),REXP VARCHAR(50)                
----,STATUS_TYPING VARCHAR(50),STATUS_APS VARCHAR(50),STATUS_ENG VARCHAR(50),STATUS_COD VARCHAR(50),STATUS_HR VARCHAR(50),STATUS_OPS VARCHAR(20),STATUS_FD VARCHAR(20)                
----,HAS_TYPING VARCHAR(1),HAS_APS VARCHAR(1),HAS_ENG VARCHAR(1),HAS_COD VARCHAR(1)                
----,TYPING_SCORE VARCHAR(50),APS_SCORE VARCHAR(50)                
----,ENG_SCORE VARCHAR(50),CODING_SCORE VARCHAR(50))                
                
----DECLARE @QRY VARCHAR(MAX)                
----SET @QRY = '                
----INSERT INTO #INBOX (                
----CREATED_DT,REC_ID,CNAME,PROCESS_NAME,CODING_SPECIALIZATION,[CURRENT COMPANY],REXP                
----,STATUS_TYPING,STATUS_APS,STATUS_ENG,STATUS_COD,STATUS_HR,STATUS_OPS,STATUS_FD                
----,HAS_TYPING,HAS_APS,HAS_ENG,HAS_COD,TYPING_SCORE,APS_SCORE,ENG_SCORE,CODING_SCORE                
----)                
----SELECT Convert(DATE,P.CREATED_DT) AS CREATED_DT,P.REC_ID,P.FIRSTNAME + CASE WHEN ISNULL(P.LASTNAME,'''') <> '''' THEN'' '' + P.LASTNAME ELSE '''' END AS CNAME                
----,CASE WHEN P.PROCESS_ID = 4 then PRO.PROCESS_NAME+'' (''+OTF.FunctionName+'')'' ELSE PRO.PROCESS_NAME end as PROCESS_NAME,'''',ISNULL(WO.COMPANY_NAME,'''') AS PREV_COMPANY,EX.REL_EXP_TEXT AS REXP                
----,CONVERT(VARCHAR(20),'''')STATUS_TYPING                
----,CONVERT(VARCHAR(20),'''')STATUS_APS                
----,CONVERT(VARCHAR(20),'''')STATUS_ENG                
----,CONVERT(VARCHAR(20),'''')STATUS_COD                
----,CONVERT(VARCHAR(20),'''')STATUS_HR                
----,CONVERT(VARCHAR(20),'''')STATUS_OPS                
----,CONVERT(VARCHAR(20),'''')STATUS_FD                  
----,CASE WHEN P.PROCESS_ID = 1 AND P.REL_EXP = 1 THEN ''Y'' ELSE ''N'' END AS HAS_TYPING                  
----,CASE WHEN P.PROCESS_ID = 1 AND P.REL_EXP = 1 THEN ''Y'' WHEN (P.PROCESS_ID = 5 AND P.REL_EXP = 1) AND ((SELECT TOP 1 TEST_TYPE FROM ARC_REC_TEST WHERE REC_ID = P.REC_ID ORDER BY TEST_ID DESC) = ''A'') THEN ''Y'' ELSE ''N'' END AS HAS_APS            
  
    
      
----,CASE WHEN P.PROCESS_ID = 2 AND P.REL_EXP = 1 THEN ''Y'' ELSE ''N'' END AS HAS_ENG                  
----,CASE WHEN P.PROCESS_ID = 3 THEN ''Y''                
---- WHEN P.PROCESS_ID = 5 AND P.REL_EXP = 1 AND ((SELECT TOP 1 TEST_TYPE FROM ARC_REC_TEST WHERE REC_ID = P.REC_ID ORDER BY TEST_ID DESC) = ''A'') THEN ''N''                
---- WHEN P.PROCESS_ID = 5 AND P.REL_EXP = 1 THEN ''Y''                  
---- ELSE ''N'' END AS HAS_COD         
----,'''','''','''',''''                
----FROM ARC_REC_CANDIATE_PROFILE AS P                
----INNER JOIN ARC_REC_CANDIDATE AS CAN ON P.REC_ID= CAN.REC_ID                 
----INNER JOIN ARC_REC_PROCESS_INFO AS PRO ON PRO.PROCESS_ID = P.PROCESS_ID                
----LEFT JOIN HR_Functionality AS OTF ON P.FUNCTIONALITY_ID = OTF.FunctionalityId            
----INNER JOIN ARC_REC_EXPERIENCE_INFO AS EX ON EX.REL_EXP = P.REL_EXP                
---- LEFT JOIN (                
----select W.REC_ID,W.COMPANY_NAME,W.DOJ from ARC_REC_CANDIDATE_WORKEXP W                 
---- inner join (select MAX(DOJ) AS DOJ,REC_ID from ARC_REC_CANDIDATE_WORKEXP group by REC_ID)X                 
---- on X.REC_ID = W.REC_ID and X.DOJ = W.DOJ  )WO ON  P.REC_ID = WO.REC_ID                  
----WHERE EXISTS                
----(                
---- SELECT 1 FROM                
---- (                 
---- SELECT DISTINCT REC_ID FROM ARC_REC_TYPING_TEST WHERE CONVERT(DATE,CREATED_DT) BETWEEN '''+CONVERT(VARCHAR,@FromDt,101)+''' AND'''+CONVERT(VARCHAR,@ToDt,101)+'''                
---- UNION                
---- SELECT DISTINCT REC_ID FROM ARC_REC_TEST WHERE CONVERT(DATE,CREATED_DT) BETWEEN '''+CONVERT(VARCHAR,@FromDt,101)+''' AND'''+CONVERT(VARCHAR,@ToDt,101)+'''                
---- UNION                
---- SELECT DISTINCT REC_ID FROM ARC_REC_CANDIDATE_STATUS WHERE CONVERT(DATE,CREATED_DT) BETWEEN '''+CONVERT(VARCHAR,@FromDt,101)+''' AND'''+CONVERT(VARCHAR,@ToDt,101)+'''                
---- UNION                
---- SELECT DISTINCT REC_ID FROM ARC_REC_CANDIATE_PROFILE WHERE CONVERT(DATE,CREATED_DT) BETWEEN '''+CONVERT(VARCHAR,@FromDt,101)+''' AND '''+CONVERT(VARCHAR,@ToDt,101)+'''                
---- )X                
---- WHERE X.REC_ID = P.REC_ID AND X.REC_ID NOT IN (SELECT REC_ID FROM ARC_REC_USER_INFO WHERE DOJ < ''2012-09-28'')                
----AND CAN.CREATED_DT between '''+CONVERT(VARCHAR,@FromDt,101)+''' and '''+CONVERT(VARCHAR,convert(date,DATEADD(DAY, 1, @ToDt)),101)+'''                 
                  
----)'                
                
----IF @REC_ID <> '0' AND @REC_ID <> ''                
---- SET @QRY += ' AND P.REC_ID = '+@REC_ID                
----IF ISNULL(@Name,'') <> ''                
---- SET @QRY += ' AND (P.FIRSTNAME LIKE '''+@NAME+''' OR P.LASTNAME LIKE '''+@NAME+''')'                
                
----EXEC(@QRY)                
              
------ typing score 25 and acc 95 before 2013-06-26              
----UPDATE #INBOX SET STATUS_TYPING =  ISNULL(CASE WHEN TE.GROSS_WPM >= 25 AND TE.ACCURACY >= 95 THEN 'Pass'                
----when TE.HAS_COMPLETED = 1 then 'Fail' WHEN ABS(DATEDIFF(SS,CONVERT(TIME,GETDATE()),CONVERT(TIME,TE.CREATED_DT))/60) >= 10 THEN 'Fail' ELSE 'InProgress'end,'Pending')                
----FROM #INBOX AS INB                
----INNER JOIN                
----(                
---- SELECT TE.* FROM ARC_REC_TYPING_TEST AS TE                
---- INNER JOIN                
---- (                
---- SELECT MAX(TEST_ID) TEST_ID,REC_ID FROM ARC_REC_TYPING_TEST AS TE                
---- WHERE EXISTS (SELECT 1 FROM #INBOX WHERE REC_ID = TE.REC_ID)                
---- GROUP BY REC_ID                
---- )X ON X.REC_ID = TE.REC_ID AND X.TEST_ID = TE.TEST_ID                
----)TE ON TE.REC_ID = INB.REC_ID                
----INNER JOIN ARC_REC_CANDIATE_PROFILE P ON INB.REC_ID = P.REC_ID              
----INNER JOIN ARC_REC_PROCESS_INFO PR ON P.PROCESS_ID = PR.PROCESS_ID              
----WHERE INB.HAS_TYPING = 'Y' AND INB.CREATED_DT < convert(date,'2013-06-26')                
              
              
------ typing score 20 and acc 95 after 2013-06-26              
----UPDATE #INBOX SET STATUS_TYPING =  ISNULL(CASE WHEN TE.GROSS_WPM >= PR.TYPING_GPM AND TE.ACCURACY >= PR.TYPING_ACCURACY THEN 'Pass'                
----when TE.HAS_COMPLETED = 1 then 'Fail' WHEN ABS(DATEDIFF(SS,CONVERT(TIME,GETDATE()),CONVERT(TIME,TE.CREATED_DT))/60) >= 10 THEN 'Fail' ELSE 'InProgress'end,'Pending')                
----FROM #INBOX AS INB                
----INNER JOIN                
----(                
---- SELECT TE.* FROM ARC_REC_TYPING_TEST AS TE                
---- INNER JOIN                
---- (                
---- SELECT MAX(TEST_ID) TEST_ID,REC_ID FROM ARC_REC_TYPING_TEST AS TE                
---- WHERE EXISTS (SELECT 1 FROM #INBOX WHERE REC_ID = TE.REC_ID)                
---- GROUP BY REC_ID                
---- )X ON X.REC_ID = TE.REC_ID AND X.TEST_ID = TE.TEST_ID                
----)TE ON TE.REC_ID = INB.REC_ID                
----INNER JOIN ARC_REC_CANDIATE_PROFILE P ON INB.REC_ID = P.REC_ID              
----INNER JOIN ARC_REC_PROCESS_INFO PR ON P.PROCESS_ID = PR.PROCESS_ID              
----WHERE INB.HAS_TYPING = 'Y' AND INB.CREATED_DT >= convert(date,'2013-06-26')              
              
----IF OBJECT_ID('TEMPDB..#INBOX_TEST') IS NOT NULL DROP TABLE #INBOX_TEST                
----SELECT TE.* INTO #INBOX_TEST FROM ARC_REC_TEST AS TE                
---- INNER JOIN                
---- ( SELECT MAX(TEST_ID) TEST_ID,REC_ID,TEST_TYPE FROM ARC_REC_TEST AS TE       
---- WHERE EXISTS (SELECT 1 FROM #INBOX WHERE REC_ID = TE.REC_ID)                
---- GROUP BY REC_ID,TEST_TYPE                
---- )X ON X.REC_ID = TE.REC_ID AND X.TEST_ID = TE.TEST_ID                
                
----UPDATE #INBOX SET STATUS_APS = ISNULL(CASE WHEN TE.RESULT = 1 THEN 'Pass'              
----WHEN te.HAS_COMPLETED = 1 and te.result = 0 THEN 'Fail' WHEN ABS(DATEDIFF(SS,CONVERT(TIME,GETDATE()),CONVERT(TIME,TE.CREATED_DT))/60) >= 30 AND te.RESULT = 0 THEN 'Fail' ELSE 'InProgress' END,'Pending')                
----FROM #INBOX AS INB                
----INNER JOIN #INBOX_TEST TE ON TE.REC_ID = INB.REC_ID AND TE.TEST_TYPE = 'A'                
----WHERE INB.HAS_APS = 'Y'                
                
----UPDATE #INBOX SET STATUS_ENG = ISNULL(CASE WHEN TE.RESULT = 1 THEN 'Pass' WHEN te.HAS_COMPLETED = 1 and te.result = 0 THEN 'Fail' WHEN ABS(DATEDIFF(SS,CONVERT(TIME,GETDATE()),CONVERT(TIME,TE.CREATED_DT))/60) >= 30 AND te.RESULT = 0                 
----THEN 'Fail' ELSE 'InProgress' END,'Pending')                
----FROM #INBOX AS INB                
----INNER JOIN #INBOX_TEST TE ON TE.REC_ID = INB.REC_ID AND TE.TEST_TYPE = 'E'                
----WHERE INB.HAS_ENG = 'Y'                
                
----UPDATE #INBOX SET STATUS_COD = ISNULL(CASE WHEN TE.RESULT = 1 THEN 'Pass' WHEN te.HAS_COMPLETED = 1 and te.result = 0                 
----THEN 'Fail' WHEN ABS(DATEDIFF(SS,CONVERT(TIME,GETDATE()),CONVERT(TIME,TE.CREATED_DT))/60) >= 30 AND te.RESULT = 0 THEN 'Fail' ELSE 'InProgress' END,'Pending')                
----FROM #INBOX AS INB                
----INNER JOIN #INBOX_TEST TE ON TE.REC_ID = INB.REC_ID AND TE.TEST_TYPE = 'C'                
----WHERE INB.HAS_COD = 'Y'                
                
                
----UPDATE #INBOX SET STATUS_HR =                
----CASE WHEN  ASS.RESULT  = 'S' THEN 'Selected' WHEN ASS.RESULT  = 'R' THEN 'Rejected' WHEN ASS.RESULT  = 'H' THEN 'Hold'                
----  WHEN ISNULL(CS.STATUS_ID,0) = 1 AND ISNULL(CS.SCHEDULE_ID,0) <> 0 THEN 'Scheduled' ELSE 'Pending' END                
----FROM #INBOX AS INB                
----Left JOIN ARC_REC_ASSESSMENT AS ASS ON ASS.REC_ID = INB.REC_ID AND ASS.ASSESS_MODE = 'H'                
----left join ARC_REC_CANDIDATE_STATUS AS CS ON CS.REC_ID = INB.REC_ID                
                
----UPDATE #INBOX SET STATUS_OPS =                
----CASE WHEN  ASS.RESULT  = 'S' THEN 'Selected' WHEN ASS.RESULT  = 'R' THEN 'Rejected' WHEN ASS.RESULT  = 'H' THEN 'Hold'                
----WHEN ISNULL(CS.STATUS_ID,0) = 2 AND ISNULL(CS.SCHEDULE_ID,0) <> 0 THEN 'Scheduled' ELSE 'Pending' END                
----FROM #INBOX AS INB                
----Left JOIN ARC_REC_ASSESSMENT AS ASS ON ASS.REC_ID = INB.REC_ID AND ASS.ASSESS_MODE = 'O'                
----left join ARC_REC_CANDIDATE_STATUS AS CS ON CS.REC_ID = INB.REC_ID                
                
----UPDATE #INBOX SET STATUS_FD =                
----CASE  WHEN  ASS.APPLICANT_STATUS = 'S' THEN 'Selected' WHEN ASS.APPLICANT_STATUS = 'R' THEN 'Rejected' WHEN ASS.APPLICANT_STATUS = 'H' THEN 'Hold'                
----WHEN ISNULL(CS.STATUS_ID,0) = 3 AND ISNULL(CS.SCHEDULE_ID,0) <> 0 THEN 'Scheduled' ELSE 'Pending' END                
----FROM #INBOX AS INB                
----Left JOIN ARC_REC_ASSESSMENT AS ASS ON ASS.REC_ID = INB.REC_ID AND ASS.ASSESS_MODE = 'S'                
----left join ARC_REC_CANDIDATE_STATUS AS CS ON CS.REC_ID = INB.REC_ID                
                
----UPDATE #INBOX SET STATUS_TYPING = CASE WHEN HAS_TYPING = 'Y' AND STATUS_TYPING = '' THEN 'Pending' ELSE STATUS_TYPING END                
---- ,STATUS_APS = CASE WHEN HAS_APS = 'Y' AND STATUS_APS = '' THEN 'Pending' ELSE STATUS_APS END                
---- ,STATUS_ENG = CASE WHEN HAS_ENG = 'Y' AND STATUS_ENG = '' THEN 'Pending' ELSE STATUS_ENG END                
---- ,STATUS_COD = CASE WHEN HAS_COD = 'Y' AND STATUS_COD = '' THEN 'Pending' ELSE STATUS_COD END                
---- ,STATUS_HR = CASE WHEN STATUS_HR = '' THEN 'Pending' ELSE STATUS_HR END                
---- ,STATUS_OPS = CASE WHEN STATUS_OPS = '' THEN 'Pending' ELSE STATUS_OPS END                
---- ,STATUS_FD = CASE WHEN STATUS_FD = '' THEN 'Pending' ELSE STATUS_FD END                
                
----UPDATE #INBOX SET STATUS_APS = CASE WHEN STATUS_TYPING = 'Fail' AND HAS_APS = 'Y' AND STATUS_APS = 'Pending' THEN 'NR' ELSE STATUS_APS END                
----,STATUS_ENG = CASE WHEN STATUS_TYPING = 'Fail' AND HAS_ENG = 'Y' AND STATUS_ENG = 'Pending' THEN 'NR' ELSE STATUS_ENG END                
----,STATUS_COD = CASE WHEN STATUS_TYPING = 'Fail' AND HAS_COD = 'Y' AND STATUS_COD = 'Pending' THEN 'NR' ELSE STATUS_COD END                
----,STATUS_HR = CASE WHEN (STATUS_TYPING = 'Fail' OR STATUS_APS = 'Fail' OR STATUS_ENG = 'Fail' OR STATUS_COD = 'Fail') AND STATUS_HR = 'Pending' THEN 'NR' ELSE STATUS_HR END                
----,STATUS_OPS = CASE WHEN (STATUS_TYPING = 'Fail' OR STATUS_APS = 'Fail' OR STATUS_ENG = 'Fail' OR STATUS_COD = 'Fail') AND STATUS_OPS = 'Pending' THEN 'NR' ELSE STATUS_OPS END                
----,STATUS_FD = CASE WHEN (STATUS_TYPING = 'Fail' OR STATUS_APS = 'Fail' OR STATUS_ENG = 'Fail' OR STATUS_COD = 'Fail') AND STATUS_FD = 'Pending' THEN 'NR' ELSE STATUS_FD END                
                
----UPDATE #INBOX SET STATUS_OPS = CASE WHEN STATUS_HR = 'Rejected' AND STATUS_OPS = 'Pending' THEN 'NR' ELSE STATUS_OPS END                
----,STATUS_FD = CASE WHEN STATUS_OPS = 'Rejected' AND STATUS_FD = 'Pending' THEN 'NR' ELSE STATUS_FD END                
                
                
----  UPDATE #INBOX  SET CODING_SPECIALIZATION = QB.GROUPNAME                
----FROM #INBOX AS INB                 
----  inner join ARC_REC_EXPERIENCE_INFO as expi on expi.REL_EXP_TEXT = inb.REXP and expi.REL_EXP <> 1                
----  INNER JOIN                
----  (                
----  select REC_ID,max(TE.TEST_ID)test_id,max(TET.QID) AS QID from ARC_REC_TEST as te                 
----  INNER JOIN ARC_REC_TEST_TRAN AS TET ON TET.TEST_ID = TE.TEST_ID                 
----  where te.TEST_TYPE = 'C'                
----  group by REC_ID                
----  )X ON X.REC_ID = INB.REC_ID                
----  INNER JOIN ARC_REC_QBANK AS QB ON QB.QID = X.QID                
                 
------ typing score 25 and acc 95 before 2013-06-26              
----  update #INBOX set                  
----  TYPING_SCORE = (SELECT TOP 1 'WPM : ' + convert(varchar,GROSS_WPM) + '/25 & ACC : ' + convert(varchar,ACCURACY)+' /95 ' FROM ARC_REC_TYPING_TEST WHERE REC_ID = I.REC_ID ORDER BY CREATED_DT DESC)                  
----  from #INBOX I                  
----  where I.STATUS_TYPING IN ('Pass','Fail')  AND I.CREATED_DT < '2013-06-26'               
              
----  -- typing score 20 and acc 95 after 2013-06-26             
----  update #INBOX set                  
----  TYPING_SCORE = (SELECT TOP 1 'WPM : ' + convert(varchar,GROSS_WPM) + '/'+convert(varchar,P.TYPING_GPM)+' & ACC : ' + convert(varchar,ACCURACY)+' /'+convert(varchar,P.TYPING_ACCURACY) +' ' FROM ARC_REC_TYPING_TEST WHERE REC_ID = I.REC_ID           
----  ORDER BY CREATED_DT DESC)                  
----  from #INBOX I             
----  INNER JOIN ARC_REC_PROCESS_INFO P ON I.PROCESS_NAME = P.PROCESS_NAME                 
----  where I.STATUS_TYPING IN ('Pass','Fail') AND I.CREATED_DT >= '2013-06-26'                
                 
----  update #INBOX set                  
----  APS_SCORE = 'Score : ' + (select TOP 1 convert(varchar,SCORE)+'/15' from ARC_REC_TEST where REC_ID = I.REC_ID and TEST_TYPE = 'A' ORDER BY CREATED_DT DESC)                  
----  from #INBOX I                  
----  where I.STATUS_APS IN ('Pass','Fail')                  
                 
----  update #INBOX set                  
----  ENG_SCORE = 'Score : ' + (select TOP 1 convert(varchar,SCORE)+'/15' from ARC_REC_TEST where REC_ID = I.REC_ID and TEST_TYPE = 'E' ORDER BY CREATED_DT DESC)                  
----  from #INBOX I                  
----  where I.STATUS_ENG IN ('Pass','Fail')                  
                 
----  update #INBOX set                  
----  CODING_SCORE = 'Score : ' + (select TOP 1 convert(varchar,SCORE)+'/15' from ARC_REC_TEST where REC_ID = I.REC_ID and TEST_TYPE = 'C' ORDER BY CREATED_DT DESC)                  
----  from #INBOX I                  
----  where I.STATUS_COD IN ('Pass','Fail')                  
                
----  SELECT * FROM #INBOX             
                
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[GET_INBOX] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[GET_INBOX] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[GET_INBOX] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[GET_INBOX] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[GET_INBOX] TO [DB_DMLSupport]
    AS [dbo];

