﻿CREATE Procedure dbo.HR_MPR_CloseSummary(@empid int)          
/*          
 Created By : udhayaganesh p    
       
          
          
*/          
as            
          
BEGIN          
          
  SELECT    --mpr.CreatedBy, *          
          
 mpr.MPRId as [ARMS ID],          
 '<a title="ARMS details" id='+ cast(mpr.MPRid as varchar) +'           
      href="#" url="/HR/MPR/MPRClose.aspx?MPRID='+ cast(mpr.MPRid as varchar) + '"           
  class=Link_Edit onclick="GB_show(this,570,800);" style="cursor:hand"><u>'+           
 de.Designation  +'</u></a>' as [Job title],              
          
 mpr.TotalPositions as  [Requested(count)],          
          
 (select isnull(sum(PositionsClosed), 0) from HR_MPRClosedetails where mprid = mpr.mprid)  as [Selected(count)],          
          
          
 ((mpr.TotalPositions) -          
          
 (select isnull(sum(PositionsClosed),0) from HR_MPRClosedetails where mprid = mpr.mprid)) as [Pending(count)],          
          
          
 isnull(ff.FunctionName,'')  + '-' + isnull(f.FunctionName,'') as [Functionality],           
 um.UserName as [Raised by],          
 convert(varchar(25), mpr.CreatedDate, 107) as [Raised date],          
 convert(varchar(25), mpr.ExpDate, 107) as [Target date],           
 tcm.Facility as [Facility],          
 mpr.CreatedDate as [Raised date_Sort],          
 mpr.ExpDate as [Target date_Sort]           
          
          
 from               
  hr_MPR mpr inner join hr_Functionality f on mpr.FunctionalityId=f.FunctionalityId                                       
  inner join hr_functionality ff on  ff.FunctionalityId  = f.FuncParentId              
  inner join hr_designation de on mpr.DesigId = de.DesigId              
  inner join HR_FacilityMaster tcm on tcm.TCId=mpr.TCId              
 inner join mrplogin um on um.Userid = mpr.CreatedBy           
 where mpr.ApprovalStatus =1 and mpr.MPRStatus = 0          
          
and           
          
 ((mpr.TotalPositions) -          
          
 (select isnull(sum(PositionsClosed),0) from HR_MPRClosedetails where mprid = mpr.mprid)) > 0           
          
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_MPR_CloseSummary] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_CloseSummary] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_CloseSummary] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_MPR_CloseSummary] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_CloseSummary] TO [DB_DMLSupport]
    AS [dbo];

