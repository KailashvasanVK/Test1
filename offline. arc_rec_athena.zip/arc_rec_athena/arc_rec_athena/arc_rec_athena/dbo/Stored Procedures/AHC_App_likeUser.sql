﻿CREATE Proc AHC_App_likeUser    
 @FromDate datetime=null,          
 @ToDate datetime=null,                   
 @CountryId int=null,                    
 @ZoneId int =null,                    
 @hubId int =null,                    
 @TCId int =null            
as            
Begin    
    
select UserName,UserEmailId,LikedOn  from ARC_REC_Athena..AHC_AppLikeUsers     
--where LikedOn >=@FromDate and LikedOn <=@ToDate  
 order by LikedOn     
    
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AHC_App_likeUser] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHC_App_likeUser] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHC_App_likeUser] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AHC_App_likeUser] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHC_App_likeUser] TO [DB_DMLSupport]
    AS [dbo];

