﻿CREATE procedure ARC_Forum_MessageBoard_Get_Article                
@year  varchar(10),@month varchar(10)=NULL                    
As                    
/*                    
To get the message details from forum                     
Created by karthik ic                    
Created on 12 March 2013                    
 ARC_Forum_MessageBoard_Get 2013                 
*/                    
Begin               
              
IF @month IS NOT NULL                   
 Select  mb.MsgId,substring(Headline,0,15)Headline, headline as tooltip,            
  CONVERT(VARCHAR(11),mb.CreatedOn) CreatedOn,month(mb.CreatedOn) as MsgMonth,                  
Year(mb.CreatedOn) as MsgYear,mb.status,Convert(varchar(10),month(mb.CreatedOn)) +'~'+Convert(varchar(10),Year(mb.CreatedOn)) as MonthYear,    
mb.CreatedON CDate,  
lm.priority,      
  ISNULL(lm.ID,0) as artid               
from ARC_Forum_MessageBoard mb  
left join ARC_Forum_Lounge_Messages lm on lm.MsgId=mb.MsgId             
where month(mb.CreatedOn) = @month  and mb.Status not in (3)                
order by CDate   desc                 
ELSE              
Select  mb.MsgId,substring(Headline,0,15)Headline, headline as tooltip,        
  CONVERT(VARCHAR(11),mb.CreatedOn) CreatedOn,month(mb.CreatedOn) as MsgMonth,                  
Year(mb.CreatedOn) as MsgYear,mb.status,Convert(varchar(20),month(mb.CreatedOn)) +'~'+Convert(varchar(10),Year(mb.CreatedOn)) as MonthYear ,    
mb.CreatedON CDate,  
lm.priority,      
ISNULL(lm.ID,0) as artid              
from ARC_Forum_MessageBoard mb  
left join ARC_Forum_Lounge_Messages lm on lm.MsgId=mb.MsgId                    
where Year(mb.CreatedOn) = @year and mb.Status not in (3)                
order by CDate   desc                 
               
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_Get_Article] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_Get_Article] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_Get_Article] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_Get_Article] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_Get_Article] TO [DB_DMLSupport]
    AS [dbo];

