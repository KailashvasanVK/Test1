﻿CREATE proc HD_ReportingAssociates    
      @USERID int    
AS    
Begin    
    
select DBO.ConcatenateName(FIRSTNAME,MiddleName,LASTNAME)+' ( '+EMPCODE+' )' as Name ,EMPCODE  ,USERID from ARC_REC_USER_INFO where REPORTING_TO = ( select NT_USERNAME from ARC_REC_USER_INFO where USERID = @USERID)    
    
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_ReportingAssociates] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_ReportingAssociates] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_ReportingAssociates] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_ReportingAssociates] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_ReportingAssociates] TO [DB_DMLSupport]
    AS [dbo];

