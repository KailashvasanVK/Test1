﻿CREATE procedure [dbo].[ARC_REC_Ntlogin_update]          
  @EmpCodeCollection varchar(Max),       
        @Created_By int                  
AS          
Begin          
--declare @EmpCodeCollection varchar(max)      
--Set @EmpCodeCollection  = 'B07131~kavitha.m,B08165~davidjohn.mahen,B07131~kavith.m'        
if OBJECT_ID('tempdb..#NtInformation') is not null drop table #NtInformation        
Create Table #NtInformation(EmpCodeCollection varchar(max)        
,EmpCode varchar(max),NtUserName varchar(max)        
,AssociateName varchar(500)        
,ReportingTo varchar(500),Functionality varchar(200),Designation varchar(200),Client varchar(200),Doj varchar(15),EmailId varchar(300))        
        
Insert into #NtInformation(EmpCodeCollection)        
Select items from dbo.fnSplitString(@EmpCodeCollection,',')          
where items not like 'txtTblSearch%'

Update #NtInformation Set EmpCode = rtrim(ltrim(substring(EmpCodeCollection,0, CHARINDEX('~',EmpCodeCollection,0))))        
,NtUserName = rtrim(ltrim(substring(EmpCodeCollection,CHARINDEX('~',EmpCodeCollection,0)+1, 100)))        

insert into ARC_REC_NTLogin(EMPCODE,NT_USERNAME,CREATED_BY,CREATED_DT)        
select EMPCODE,NtUserName,@Created_By,GETDATE() from #NtInformation       

--insert into ARC_REC_NTLogin(EMPCODE,NT_USERNAME,CREATED_BY,CREATED_DT)        
--select EMPCODE,NtUserName,@Created_By,GETDATE() from #NtInformation       
        
update ARC_REC_USER_INFO set        
NT_USERNAME = nnl.NtUserName      
from ARC_REC_USER_INFO ui      
join #NtInformation nnl on ui.EMPCODE = nnl.EmpCode      
        
Update #NtInformation Set AssociateName = rtrim(ui.FIRSTNAME + ' ' + ui.LASTNAME),ReportingTo = ui.REPORTING_TO,Functionality = func.FunctionName        
,Designation = desig.Designation     
,Client = fi.Client_Name     
,Doj = CONVERT(varchar,ui.DOJ,106)        
,EmailId = ui.NT_USERNAME + '@accesshealthcare.co'        
from #NtInformation as n        
inner join ARC_REC_USER_INFO as ui on ui.EMPCODE = n.EmpCode        
inner join HR_Functionality as func on func.FunctionalityId = ui.FUNCTIONALITY_ID        
inner join HR_Designation as desig on desig.DesigId = ui.DESIGNATION_ID      
inner join ARC_FIN_CLIENT_INFO fi on ui.CLIENT_ID = fi.Client_Id    
  
  
Declare @BODY varchar(max)        
Set @BODY = '<p>Hi All, <br /><br />        
Please find the NT login & Mail ID for the new joiners below. <br /><br /> <table  border="1" cellpadding="0" cellspacing="0">        
<tr><td style="background:#E9F246;padding-left:4px;">Employee Code</td><td style="background:#E9F246;padding-left:4px;">Associate</td><td style="background:#E9F246;padding-left:4px;">Department</td>  
<td style="background:#E9F246;padding-left:4px;">  
Designation</td><td style="background:#E9F246;padding-left:4px;">Client</td><td style="background:#E9F246;padding-left:4px;">DOJ</td><td style="background:#E9F246;padding-left:4px;">NT Login</td><td style="background:#E9F246;">EmailId</td></tr>'          



--select * from #NtInformation      
Declare @EmpCode varchar(10),@NtUserName varchar(75)        
,@AssociateName varchar(500)        
,@ReportingTo varchar(500),@Functionality varchar(200),@Designation varchar(200),@Client varchar(200),@Doj varchar(15),@EmailId varchar(300)        
Declare Cur cursor         
for select EmpCode,NtUserName,AssociateName,ReportingTo,Functionality,Designation,Client,Doj,EmailId         
from #NtInformation        
Open Cur        
While 1=1        
 Begin        
 Fetch Next from Cur into @EmpCode,@NtUserName,@AssociateName,@ReportingTo,@Functionality,@Designation,@Client,@Doj,@EmailId         
 if @@FETCH_STATUS = -1 break        
 --Select @EmpCode,@NtUserName,@AssociateName,@ReportingTo,@Functionality,@Designation,@Doj,@EmailId         
 SET @BODY = @BODY + '<tr><td style="padding-left:4px;">'+ISNULL(@EMPCODE,'')+'</td><td style="padding-left:4px;">'+Isnull(@AssociateName,'')+'</td><td style="padding-left:4px;">'+isnull(@functionality,'')+  
 '</td><td style="padding-left:4px;">'+isnull(@Designation,'')+'</td><td style="padding-left:4px;">'+isnull(@Client,'')+'</td><td style="padding-left:4px;">'+convert(varchar,@Doj,102)+'</td><td style="padding-left:4px;">'+isnull(@NtUserName,'')+'</td
><td style="padding-left:4px;">'+isnull(@EmailId,'')+'</td></tr>'                
 End        
Close Cur        
DeAllocate Cur          
SET @BODY += ' </table><br /><br /><img src="https://arc.accesshealthcare.co/arc_me/Images/arc_recruit.png"/>                        
<br/> ** This is a system generated mail. Please do not respond to this mail.**</p>'''           
Declare @Supervisors varchar(max)        
set  @Supervisors = 'hr@accesshealthcare.co,it@accesshealthcare.co,ithelpdesk@accesshealthcare.co,support@accesshealthcare.co'        
Set @Supervisors += (Select ',' + ReportingTo+'@accesshealthcare.co' from #NtInformation Group by ReportingTo for xml path(''))        
Select @Supervisors        
Select @Body       
      
INSERT INTO ARC_REC_MAIL_TRAN(FROM_MAILID,RECIPIENTS,SUBJECT_TEXT,BODY,ISHTML,CC)                           
select 'ithelpdesk@accesshealthcare.co',@Supervisors,'NTLogin Created',@Body,'Y','hr@accesshealthcare.co,ithelpdesk@accesshealthcare.co'      
          
End 





GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_Ntlogin_update] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Ntlogin_update] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Ntlogin_update] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_Ntlogin_update] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Ntlogin_update] TO [DB_DMLSupport]
    AS [dbo];

