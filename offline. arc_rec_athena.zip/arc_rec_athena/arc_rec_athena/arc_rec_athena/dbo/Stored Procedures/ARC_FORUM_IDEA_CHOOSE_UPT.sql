﻿CREATE Proc ARC_FORUM_IDEA_CHOOSE_UPT    
@IDEA_ID int,    
@Comments varchar(500)='',    
@Statusid tinyint,    
@REVIEWED_BY varchar(100)='' /* NT_userName  */    
As    
Begin    
     
if @Statusid=1 /* selected */    
begin    
     
update ARC_Forum_User_Ideas set comments=@Comments , status=@Statusid,REVIEWED_BY=@REVIEWED_BY,REVIEWED_ON=GETDATE() where IDEA_ID=@IDEA_ID    
 
insert into RR_SCOREBOARD(Userid,CID,Points,Status,CreatedOn,ReferenceInfo,ReferenceId)
select uv.Userid,C.CID,c.POINTS,1,GETDATE(),'ARC_Forum_User_Ideas',@IDEA_ID from ARC_Forum_User_Ideas UI 
inner join ARC_REC_USER_INFO_VY UV on UI.CREATED_BY=uv.NT_UserName   
inner join RR_CRITERA_MASTER C on Cid=cid where c.CID=14 and IDEA_ID=@IDEA_ID    
 
     
/* mail part */    
     
end    
else if @Statusid=2 /* Rejected */    
begin    
     
update ARC_Forum_User_Ideas set comments=@Comments , status=@Statusid,REVIEWED_BY=@REVIEWED_BY,REVIEWED_ON=GETDATE() where IDEA_ID=@IDEA_ID    

Update RR_SCOREBOARD set Points =0  where CID=13 and ReferenceId=@IDEA_ID 
     
/* mail part */    
     
end     
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FORUM_IDEA_CHOOSE_UPT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_IDEA_CHOOSE_UPT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_IDEA_CHOOSE_UPT] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FORUM_IDEA_CHOOSE_UPT] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_IDEA_CHOOSE_UPT] TO [DB_DMLSupport]
    AS [dbo];

