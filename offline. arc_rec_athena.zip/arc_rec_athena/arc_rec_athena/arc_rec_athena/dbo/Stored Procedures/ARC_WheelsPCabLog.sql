﻿CREATE PROCEDURE ARC_WheelsPCabLog      
 @Action VARCHAR(10) = ''          
AS      
    IF @Action = 'Pickup'            
     BEGIN      
       INSERT INTO ARC_WheelsCabPickupLog(FieldId,NAME,EMPCODE,PickupType,PickupPoint  ,PickupTime,CabNumber,DriverNumber,DriverName,Shift,FileName,CREATED_BY,   CREATED_DT)    
       SELECT FieldId,NAME,EMPCODE,PickupType,PickupPoint,PickupTime,CabNumber,    DriverNumber,DriverName,Shift,FileName,CREATED_BY,CREATED_DT    
        FROM ARC_WheelsCabPickup;      
     END      
 ELSE IF @Action = 'Drop'      
     BEGIN      
      INSERT INTO ARC_WheelsCabDropLog(FieldId,NAME,EMPCODE,DropType,DropPoint,    CabNumber,Shift,DriverName,DriverNumber,FileName,CREATED_BY,CREATED_DT)     
      SELECT FieldId,NAME,EMPCODE,DropType,DropPoint,CabNumber,Shift,DriverName,   DriverNumber,FileName,CREATED_BY,CREATED_DT   
       FROM ARC_WheelsCabDrop;    
     END           

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_WheelsPCabLog] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_WheelsPCabLog] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_WheelsPCabLog] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_WheelsPCabLog] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_WheelsPCabLog] TO [DB_DMLSupport]
    AS [dbo];

