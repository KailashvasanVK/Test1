﻿Create Proc GetRecIdForApp  
     @UserName nvarchar(50),  
     @ContactNo nvarchar(25)  
     as  
     Begin  
     declare @recid varchar(10)  
        exec  [SP_INS_ARC_REC_CANDIDATE] @UserName,@ContactNo,0,@recid output  
        select @recid as Recid  
 End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[GetRecIdForApp] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[GetRecIdForApp] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[GetRecIdForApp] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[GetRecIdForApp] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[GetRecIdForApp] TO [DB_DMLSupport]
    AS [dbo];

