﻿CREATE procedure ARC_ME_Attendance     
   @UserId int,     
   @frmDate date,     
   @toDate date,     
   @SearchStr varchar(100) = '',    
   @SearchPattern varchar(4) = '=' /** = or % **/      
As     
Begin     
     
     
--Declare @UserId int = 1451    
--Declare @frmDate date = '3-Jan-2014'     
----Declare @toDate date = getdate()     
--Declare @toDate date = '3-Jan-2014'    
--Declare @SearchStr varchar(100) = ''
--Declare @SearchPattern varchar(4) = '=' /** = or % **/    

/**     
Should not allow to mark attendance if IsDeclaredOff = 1 and CompOffEligible = 0      
Not allow to mark attendance if HasAttenanceClosed = 1; HR can mark closed date attendance with confirmation dialog     
**/     

Declare @Qry varchar(max)        
Declare @localdbserver varchar(25) = (Select CTL_VALUE from ARC_REC_SOFTCONTROL where CTL_ID = 'localdbserver')        
if OBJECT_ID('tempdb..#DateWiseAttendance') is not null drop table #DateWiseAttendance        
Create Table #DateWiseAttendance(Aid int,UserId int,[Date] date,Attendance varchar(100),CompOffEligible int,IsDeclaredOff int,OTEligible int,Present varchar(25),NotPresent varchar(25),LeaveType varchar(25))        
Set @Qry = '        
Insert into #DateWiseAttendance(Aid,UserId,[Date],Attendance,CompOffEligible,IsDeclaredOff,OTEligible,Present,NotPresent,LeaveType)        
SELECT Aid,UserId,[Date],Attendance,CompOffEligible,IsDeclaredOff,OTEligible,Present,NotPresent,LeaveType FROM  OPENROWSET(        
''sqloledb''        
,''Server='+@localdbserver+';Trusted_Connection=yes;''        
,''exec ARC_REC_Athena..ARC_ME_MonthlyAttendanceView        
@FromDate = '''''+CONVERT(varchar,@frmDate)+'''''        
,@ToDate = '''''+CONVERT(varchar,@toDate)+'''''        
,@SessionUserId = '+CONVERT(varchar,@UserId)+'        
,@FunctionalityID = 0
,@ClientID = 0
,@Active = 1
,@SupListAll=''''N''''
,@UserId = '+CONVERT(varchar,@UserId)+'        
,@View = ''''DateWise'''''')        
'        
Exec (@Qry)       
 
create index hash_DateWiseAttendance_userid on #DateWiseAttendance(Aid,[date],UserId)     

Declare @AttClosedDate date = (select MAX(PAY_ROLL_DATE) from ARC_ME_PAYROLL)   
--select @AttClosedDate  
select [Aid] as [Aid~Hide],[AttDate] as [AttDate~Hide],[Day],[Description],AttType as [AttType~Hide],[IsDeclaredOff] as [IsDeclaredOff~Hide],     
[CompOffEligible] as [CompOffEligible~Hide],     
[OTEligible] as [OTEligible~Hide],[TotalHrs] as [TotalHrs~Hide],[LoggedOn] as [LoggedOn~Hide],[LoggedOut] as [LoggedOut~Hide],     
[HasSelfAttendance] as [HasSelfAttendance~Hide],[HasAttendanceClosed] as [HasAttendanceClosed~Hide],     
[IsSingleDayShift] as [IsSingleDayShift~Hide],[AppliedLeave] as [AppliedLeave~Hide],     
[Shift_Hrs] as [Shift_Hrs~Hide],      
--OpenDialog(AttId, AttDate, IsSingleDayShift, IsDeclaredOff, IsAttendanceClosed, IsSelfAttendance, IsLeaveApplied,IsCompOffEligible,IsOTEligible)      
'<button onclick="return OpenDialog('+convert(varchar,ISNULL([Aid],0))+','''+CONVERT(varchar,[AttDate],101)+''','''+CONVERT(varchar,isnull(AttType,''''))+''','+CONVERT(varchar,[IsSingleDayShift])+','     
+CONVERT(varchar,isnull(IsDeclaredOff,'0'))+','+CONVERT(varchar,HasAttendanceClosed)+','+isnull(CONVERT(varchar,HasSelfAttendance),'0')+','+  
convert(varchar,case when AppliedLeave = 'F' then 1 when AppliedLeave = 'H' then 0.5 else 0 end)+','+  
isnull(CONVERT(varchar,CompOffEligible),'0')+','+    
CONVERT(varchar,case when TotalHrs > Shift_Hrs and OTEligible = 1 then 1 else 0 end)+',''' +   
isnull(convert( varchar,SUBSTRING(CONVERT(VARCHAR, LoggedOn, 100),13,7) ),'')+''','''+  
isnull(convert( varchar,SUBSTRING(CONVERT(VARCHAR, LoggedOut, 100),13,7)),'')+''');"       
class="Action ui-button ui-widget ui-state-default ui-corner-all ui-button-icon-only" id="btnAckAction" role="button" aria-disabled="false" title="Update Attendance">      
<span class="ui-button-icon-primary ui-icon ui-icon-copy"></span><span class="ui-button-text">Update Attendance</span></button>' as [ACTION]     
into #SelfAttendanceView from (     
Select att.Aid [Aid]     
,dbo.ShiftDurationInMinutes(att.Shift_from,att.Shift_to,0) as [Shift_Hrs]      
,Att.Date [AttDate]     
,Convert(varchar,Att.Date,106) + ' ( ' + DATENAME(WEEKDAY,att.Date)+' )' as [Day]     
,LTRIM(case when P_days = 0 and att.IsDeclaredOff = 1 then 'Holiday'      
 when dailyAtt.Attendance = 'Full Present' then 'F'      
 when dailyAtt.Attendance = 'Half Present' then 'H' else '' end )  as AttType  
,Ltrim(dailyAtt.Attendance
 + ' ' + isnull((Select top 1 case when LR.LEAVE_MODE = 'F' then 'Full LWP'  when LR.LEAVE_MODE = 'H' then 'Half LWP' else '' end + case when LR.LEAVE_MODE <> '' then ' ('+LP.TYPE_TEXT + ' - ' + LR.REASON + ')' else '' end
from ARC_REC_LEAVE_TRAN as LT     
inner join ARC_REC_LEAVE_REQUEST as LR on LR.LEAVE_REQID = LT.LEAVE_REQID and LR.ACTIVE = 'Y' and LR.LEAVE_STATUS = 1     
inner join ARC_REC_LEAVE_TYPES as LP on LP.TYPEID = LR.TYPEID and LP.TYPEID <> 5     
Where LT.LEAVE_DATE = att.Date and LT.CREATED_BY = @UserId     
),''))      
+ case when P_days > 0 then case when isnull(selfAtt.WORKED_HRS,att.TotalHrs) > 0 then ' ' + Convert(varchar,isnull(selfAtt.WORKED_HRS,att.TotalHrs)) + ' Hrs' else '' end  else '' end   
+ isnull((Select Top 1  ' (' + typeinfo.[Type] + ':' + Verified_Comments + ')' from ARC_ME_DISCRIPENCY_TRAN as Disc   
inner join ARC_ME_DISCRIPENCY_TYPEINFO as  typeinfo on typeinfo.[Type_Id] = Disc.Dis_type  
where aid = att.Aid order by Tran_ID desc),'')  
as [Description]      
,isnull(att.IsDeclaredOff,0)as [IsDeclaredOff]     
,isnull(att.CompOffEligible,0)as [CompOffEligible]     
,isnull(att.OTEligible,0)as [OTEligible]     
,isnull(selfAtt.WORKED_HRS,att.TotalHrs) as [TotalHrs]     
,isnull(selfatt.LOGIN_TIME,att.LogOn) as [LoggedOn]     
,isnull(selfatt.LOGOUT_TIME,att.LogOut) as [LoggedOut]     
,case when selfAttAcc.ATT_TYPE = 'S' then 1 else 0 end as [HasSelfAttendance]     
,case when att.Date <= @AttClosedDate then 1 else 0 end as [HasAttendanceClosed]     
,case when SHIFT_TO < CONVERT(time,'12:00:00') then 0 else 1 end [IsSingleDayShift]     
,(Select Top 1 LR.LEAVE_MODE from ARC_REC_LEAVE_TRAN as LT inner join ARC_REC_LEAVE_REQUEST as LR on LR.LEAVE_REQID = LT.LEAVE_REQID And LR.ACTIVE = 'Y' and LR.LEAVE_STATUS in (0,1) Where LT.LEAVE_DATE = Att.Date and LT.CREATED_BY = att.Userid) [AppliedLe
ave]  
      
 from ARC_REC_Attendance as att     
 inner join #DateWiseAttendance as dailyAtt on dailyAtt.Aid = att.Aid
left join ARC_REC_SELF_ATTENDANCE as selfAtt on selfAtt.USERID = att.Userid and selfAtt.ATTENDANCE_DATE = att.Date      
left join ARC_REC_ATTENDANCE_ACCESS as selfAttAcc on selfAttAcc.USERID = att.Userid and selfAttAcc.ATT_TYPE = 'S' and selfAttAcc.Active = 1    
Where att.Date between @frmDate and @toDate     
and att.Userid = @UserId     
  )x      
     
Declare @OrderStr varchar(100)     
SET @OrderStr  = ' order by [AttDate~Hide] desc'      
Exec FilterTable     
@DbName = 'tempdb'     
,@TblName = '#SelfAttendanceView'     
,@SearchStr = @SearchStr     
,@SearchPattern = @SearchPattern     
,@OrderStr = @OrderStr     
if OBJECT_ID('tempdb..#SelfAttendanceView') is not null drop table #SelfAttendanceView     
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_Attendance] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_Attendance] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_Attendance] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_Attendance] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_Attendance] TO [DB_DMLSupport]
    AS [dbo];

