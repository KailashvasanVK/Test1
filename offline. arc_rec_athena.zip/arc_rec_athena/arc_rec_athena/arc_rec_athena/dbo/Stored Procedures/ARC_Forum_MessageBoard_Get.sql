﻿CREATE procedure ARC_Forum_MessageBoard_Get            
@year  varchar(10),@month varchar(10)=NULL                
As                
/*                
To get the message details from forum                 
Created by karthik ic                
Created on 12 March 2013                
 ARC_Forum_MessageBoard_Get 2013             
*/                
Begin           
          
IF @month IS NOT NULL               
 Select  MsgId,substring(Headline,0,15)Headline, headline as tooltip,        
  CONVERT(VARCHAR(11),CreatedOn) CreatedOn,month(CreatedOn) as MsgMonth,              
Year(CreatedOn) as MsgYear,status,Convert(varchar(10),month(CreatedOn)) +'~'+Convert(varchar(10),Year(CreatedOn)) as MonthYear,
CreatedON CDate      
from ARC_Forum_MessageBoard                 
where month(CreatedOn) = @month  and Status not in (3)            
order by CDate   desc             
ELSE          
Select  MsgId,substring(Headline,0,15)Headline, headline as tooltip,    
  CONVERT(VARCHAR(11),CreatedOn) CreatedOn,month(CreatedOn) as MsgMonth,              
Year(CreatedOn) as MsgYear,status,Convert(varchar(20),month(CreatedOn)) +'~'+Convert(varchar(10),Year(CreatedOn)) as MonthYear ,
CreatedON CDate      
from ARC_Forum_MessageBoard                 
where Year(CreatedOn) = @year and Status not in (3)            
order by CDate   desc             
           
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_Get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_Get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_Get] TO [DB_DMLSupport]
    AS [dbo];

