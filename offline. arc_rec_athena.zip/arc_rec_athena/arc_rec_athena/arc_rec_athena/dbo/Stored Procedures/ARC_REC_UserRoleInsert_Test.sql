﻿CREATE Procedure ARC_REC_UserRoleInsert_Test
@RoleId int ,
 @CREATED_BY  int,
 @AccessLevel varchar(5) ,
 @UserId varchar(max)  
 As
 /*   To Insert the User's Role Details */
 Begin
	Insert into ARC_REC_UserRole(UserId,RoleId,CREATED_BY,AccessLevel,FUNCTIONALITY_ID)
	Select items,@RoleId ,@CREATED_BY,@AccessLevel,0  from dbo.fnSplitString (@UserId,',')
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_UserRoleInsert_Test] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UserRoleInsert_Test] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UserRoleInsert_Test] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_UserRoleInsert_Test] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UserRoleInsert_Test] TO [DB_DMLSupport]
    AS [dbo];

