﻿CREATE procedure [dbo].[ARC_REC_InductionSupervisors]            
   As            
   Begin            
   -- Supervisors list except Human Resource ---               
   select x.USERID,x.NAME,x.Designation,x.FunctionName from(          
 SELECT UI.USERID,D.DESIGNATION,F.FUNCTIONNAME,UI.FIRSTNAME+' '+UI.LASTNAME+'-('+UI.EMPCODE+')' AS NAME                                                
FROM ARC_REC_USER_INFO UI                                                
INNER JOIN HR_FUNCTIONALITY F ON UI.FUNCTIONALITY_ID = F.FUNCTIONALITYID                                                
INNER JOIN HR_DESIGNATION D ON UI.DESIGNATION_ID = D.DESIGID                                                
WHERE UI.ACTIVE = 1 AND UI.AHS_PRL = 'Y' AND D.SUPERVISOR  = 'Y' AND F.FUNCTIONALITYID <> 6                                               
UNION   -- Shared Services - Human Resource ---                                             
SELECT UI.USERID,D.DESIGNATION,F.FUNCTIONNAME,UI.FIRSTNAME+' '+UI.LASTNAME+'-('+UI.EMPCODE+')' AS NAME                                                
FROM ARC_REC_USER_INFO UI                                                
INNER JOIN HR_FUNCTIONALITY F ON UI.FUNCTIONALITY_ID = F.FUNCTIONALITYID                                                
INNER JOIN HR_DESIGNATION D ON UI.DESIGNATION_ID = D.DESIGID                                                
WHERE UI.ACTIVE = 1 AND UI.AHS_PRL = 'Y' AND F.FUNCTIONALITYID = 6                                         
UNION   -- Training and Development  
SELECT UI.USERID,D.DESIGNATION,F.FUNCTIONNAME,UI.FIRSTNAME+' '+UI.LASTNAME+'-('+UI.EMPCODE+')' AS NAME                                                
FROM ARC_REC_USER_INFO UI                                                
INNER JOIN HR_FUNCTIONALITY F ON UI.FUNCTIONALITY_ID = F.FUNCTIONALITYID                                                
INNER JOIN HR_DESIGNATION D ON UI.DESIGNATION_ID = D.DESIGID                                                
WHERE UI.ACTIVE = 1 AND UI.AHS_PRL = 'Y' AND F.FUNCTIONALITYID = 9  
UNION   -- Finanace  
SELECT UI.USERID,D.DESIGNATION,F.FUNCTIONNAME,UI.FIRSTNAME+' '+UI.LASTNAME+'-('+UI.EMPCODE+')' AS NAME                                                
FROM ARC_REC_USER_INFO UI                                                
INNER JOIN HR_FUNCTIONALITY F ON UI.FUNCTIONALITY_ID = F.FUNCTIONALITYID                                                
INNER JOIN HR_DESIGNATION D ON UI.DESIGNATION_ID = D.DESIGID                                                
WHERE UI.ACTIVE = 1 AND UI.AHS_PRL = 'Y' AND F.FUNCTIONALITYID = 7 AND D.DesigId = 3                                              
    )x  ORDER BY FunctionName,NAME          
End  




GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_InductionSupervisors] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_InductionSupervisors] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_InductionSupervisors] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_InductionSupervisors] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_InductionSupervisors] TO [DB_DMLSupport]
    AS [dbo];

