﻿CREATE procedure dbo.HR_MailId(@Userid int, @Mprid int)              
as            
/*            
 Created By :UdhayaGanesh p       
 Created On : 10th Aug 2009            
 Purpose : To send mail            
            
*/              
begin              
 Declare @FromMailid varchar(256), @ToMailid varchar(256), @MPRBy int, @Appby int              
 Declare @RaisedEmpid int, @RaisedNAaid int, @RaisedAssessorid int          
 Declare @ApprovedEmpid int, @ApprovedNAaid int, @ApprovedAssessorid int          
 Declare @RaisedBy varchar(256), @ApprovedBy varchar(256)          
          
 SELECT @FromMailid = mailid from MRPLogin  WHERE UserId = @Userid          
          
 IF @FromMailid IS NULL              
 SET @FromMailid = 'Udhayaganesh.p@laurusedutech.com'              
              
 SELECT @MPRBy = CreatedBy , @Appby = ApprovedBy from HR_Mpr where mprid = @Mprid              
 SELECT @ToMailid = mailid from MRPLogin  WHERE UserId = @MPRBy              
  /* For employee */           
 IF EXISTS(SELECT UserId  FROM  MRPLogin  WHERE UserId =  @MPRBy)          
 begin           
    select @RaisedEmpid = UserId  FROM  MRPLogin WHERE UserId = @MPRBy          
 SELECT @RaisedBy = UserName  from MRPLogin WHERE UserId = @MPRBy           
 end          
          
 IF EXISTS(SELECT UserId  FROM  MRPLogin WHERE UserId = @Appby )          
 begin           
    SELECT @ApprovedBy = UserName  from MRPLogin WHERE UserId = @Appby          
 end               
          
 IF @ToMailid IS NULL              
 SET @ToMailid = 'udhayaganesh.p@laurusedutech.com'              
              
 select @FromMailid as fromid, @ToMailid as toid, @ApprovedBy as ApprovedBy, @RaisedBy as MPRBy             
          
end 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_MailId] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MailId] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MailId] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_MailId] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MailId] TO [DB_DMLSupport]
    AS [dbo];

