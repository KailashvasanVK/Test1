﻿CREATE Procedure ARC_REC_AttUpdateForPresent
(
@AttDate date
,@UserId int = 0
)
As
Begin
Declare @Qry varchar(max)
Set @Qry = '
Update ARC_REC_Attendance Set P_days = V.P_Days
from ARC_REC_Attendance as Att
inner join
(
select              
case when ISNULL(att.verified_present,'''') = ''F'' then 1 when ISNULL(att.verified_present,'''') = ''H'' then 0.5              
     when ISNULL(att.verified_present,'''') = ''NP'' then 0            
     when att.Date < ''2013-11-01'' and att.TotalHrs >= 7.45 then 1
     when att.Date < ''2013-11-01'' and att.TotalHrs >= 4.5 then 0.5
     When att.TotalHrs >= dbo.ShiftDurationInMinutes(att.Shift_From,att.Shift_To,15) then 1 
     when att.TotalHrs >= 4.3 then 0.5 
     /* when att.TotalHrs >= (dbo.ShiftDurationInMinutes(att.Shift_From,att.Shift_To,0)/2) then 0.5 */
     else 0 end AS P_Days
,att.Userid
,att.Date
from arc_rec_attendance as att
Where Convert(varchar,Att.Date) = '''+Convert(varchar,@AttDate)+'''
'
if ISNULL(@UserId,0) <> 0
	Set @Qry += ' And Att.UserId = ' + CONVERT(varchar,@UserId)

Set @Qry += '
 )V on V.Date = Att.Date and v.Userid = att.Userid
Where Convert(varchar,Att.Date) = '''+Convert(varchar,@AttDate)+'''
'
if ISNULL(@UserId,0) <> 0
	Set @Qry += ' And Att.UserId = ' + CONVERT(varchar,@UserId)
	
Exec (@Qry)
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_AttUpdateForPresent] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AttUpdateForPresent] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AttUpdateForPresent] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_AttUpdateForPresent] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AttUpdateForPresent] TO [DB_DMLSupport]
    AS [dbo];

