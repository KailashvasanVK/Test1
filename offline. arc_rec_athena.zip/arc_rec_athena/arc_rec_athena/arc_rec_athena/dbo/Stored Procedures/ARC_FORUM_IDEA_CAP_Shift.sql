﻿CREATE PROC ARC_FORUM_IDEA_CAP_Shift      
@NT_Username Varchar(100)='Udhayaganesh.p'  
/*   
  
ARC_FORUM_IDEA_CAP 'krishnan.mariap'   
  
  
*/      
AS      
Begin    
  
Declare @shiftId int  
  
;With AssociateShift(CREATED_DT,SHIFT_ID,Userid,NT_UserName)  
AS  
(  
select Max(si.CREATED_DT) CREATED_DT,SHIFT_ID,uv.Userid,NT_UserName  from ARC_REC_USER_INFO_VY UV  
inner join ARC_REC_SHIFT_TRAN  SI on SI.Userid=uv.Userid   
where convert(date,Effect_DATE)<=convert(date,GETDATE())  
Group by SHIFT_ID,Uv.Userid,NT_UserName   
) Select @shiftId=SHIFT_ID   from AssociateShift SI  
where CREATED_DT =(select MAX(CREATED_DT)   
from ARC_REC_SHIFT_TRAN ST where ST.userid=SI.Userid)  
and NT_UserName =@NT_Username  
Print @shiftId  
If Not Exists (select * from ARC_REC_SHIFT_INFO where SHIFT_ID =@shiftId and SHIFT_TO <='09:00')  
Begin  
 Print @shiftid  
 If exists (Select Top 1 'x'from ARC_Forum_USER_IDEAS where Created_BY=@NT_Username and        
 CONVERT(date,created_on)>=CONVERT(date,getdate()))        
 Begin        
 Select 'Your Idea Post Quota Exceed Today !..' Message        
 End    
End  
Else  
Begin     
 Print @shiftid  
If exists (Select Top 1 'x'from ARC_Forum_USER_IDEAS where Created_BY=@NT_Username and        
 CONVERT(date,created_on)>=CONVERT(date,getdate()-1))        
 Begin     
 Print 'Days Clube'     
 Select 'Your Idea Post Quota Exceed Today !..' Message        
 End    
End  
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FORUM_IDEA_CAP_Shift] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_IDEA_CAP_Shift] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_IDEA_CAP_Shift] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FORUM_IDEA_CAP_Shift] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_IDEA_CAP_Shift] TO [DB_DMLSupport]
    AS [dbo];

