﻿CREATE procedure ARC_REC_GetWalkinSource    
      @RecId int  
As    
Begin    
Declare @IsAhsCandidate bit  
select @IsAhsCandidate = RegByAHS from ARC_REC_CANDIDATE where REC_ID = @RecId  
if(@IsAhsCandidate = 1)  
 Select SourceId,[Description] from ARC_REC_WalkinSource where SourceId <> 13 and Active = 1   
 else  
 Select SourceId,[Description] from ARC_REC_WalkinSource where SourceId = 13 and Active = 1 
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_GetWalkinSource] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_GetWalkinSource] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_GetWalkinSource] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_GetWalkinSource] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_GetWalkinSource] TO [DB_DMLSupport]
    AS [dbo];

