﻿CREATE procedure ARC_RoleMenuGet  
@UserId int ,  
@Action varchar(50) = '',  
@FileName Varchar(50) = ''  
As  
/*  
Created by : Karthik Ic  
Created on : 03 june 2013  
Impact to  : FlowIndex.aspx  
Purpose    : To get the role based menu for the user.  
exec ARC_RoleMenuGet @UserId=15,@Action=N'FlowIndex.aspx'  
exec ARC_RoleMenuGet @UserId=15,@Action=N'FlowIndex.aspx',@FileName ='CustomerCreation.aspx'  
exec ARC_RoleMenuGet @UserId=7,@Action=N'FlowIndex.aspx',@FileName ='ProfileSetUpTest.aspx'  
exec ARC_RoleMenuGet @UserId=874,@Action=N'FlowIndex.aspx',@FileName=N'ProfileSetUpTest.aspx'  
*/  
Begin  
Set Transaction Isolation Level Read uncommitted;
----dECLARE @UserId int = 491,  
----@Action varchar(50) = 'FLOWINDEX.ASPX',  
----@FileName Varchar(50) = ''  
  
/************************* Backup user to load the forms and Roles    *****************************************/  
Declare @ReportingTo  int   
if (select COUNT(Functionality) from ARC_Flow_Athena..ADM_AccessFunctionality where UserId = @userid and Functionality ='B' )>0  
Begin  
          Select @ReportingTo =  userid from ARC_REC_Athena..ARC_REC_USER_INFO   
            Where  NT_USERNAME =  (select REPORTING_TO from ARC_REC_Athena..ARC_REC_USER_INFO where USERID = @userid )  
End  
/*************************    Get the Role id  *****************************************/        
if OBJECT_ID('tempdb..#GetRoleDetails') is not null drop table #GetRoleDetails  
Create table #GetRoleDetails (RoleId int)  
Begin  
        insert into #GetRoleDetails (RoleId)  
        select ARdR.RoleId from ARC_REC_designationRole  ARDR  
        inner join ARC_REC_USER_INFO  ARUI on  arUI.DESIGNATION_ID = ARDR.DesigId --and ARui.CLIENT_ID <> 16   
        where ARUI.USERID in( @userid)  
  union  
  Select RoleId from ARC_REC_UserRole Where UserId in( @userid)  
End  
/*************************    Get the Menu Based on Roleid   *****************************************/  
if OBJECT_ID('tempdb..#AccessMenus') is not null drop table #AccessMenus  
  
Select MenuDisplayText,case when Isnull(OutputPath,'') = '' then MenuFileName else OutputPath end as OutputPath,  
LogoFilePath,MenuFileName,Boxno,MenuParentId,isnull(MenuDescription,'') as Description,asm.MenuId  
INTO #AccessMenus  
From ARC_Setup_Menu  ASM  
inner join ARC_REC_RoleTran  ART on ASM.MenuId =  ART.MenuId and ART.RoleId in(select  distinct(RoleId ) from #GetRoleDetails)  
inner join ARC_REC_USER_INFO as ui on ui.USERID in( @UserId,@ReportingTo)  
Where MenuParentId in (Select MenuId from ARC_Setup_Menu Where MenuFileName = @Action)  
and MenuFileName = (case when isnull(@FileName,'')='' then  MenuFileName else @FileName end)  
group by MenuDisplayText,OutputPath,LogoFilePath,MenuFileName,Boxno,MenuParentId,MenuDescription,asm.MenuId  
  
declare @boxno int  
declare @inc int  
Set @inc = 1  
Declare cur cursor  
for Select boxno from #AccessMenus where boxno = 0  
open cur  
while 1=1  
begin  
fetch next from cur into @boxno  
if @@FETCH_STATUS = -1 break  
while 1=1  
begin  
print @inc  
if (select COUNT(*) from #AccessMenus where Boxno = @inc)>0  
set @inc += 1  
else  
break  
end  
Update #AccessMenus set Boxno = @inc where current of cur  
end  
close cur  
deallocate cur  
Select * from #AccessMenus    where MenuFileName not in( @Action)  
Drop table #AccessMenus   
End 



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_RoleMenuGet] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_RoleMenuGet] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_RoleMenuGet] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_RoleMenuGet] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_RoleMenuGet] TO [DB_DMLSupport]
    AS [dbo];

