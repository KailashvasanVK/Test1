﻿CREATE procedure [dbo].[ARC_REC_ShiftConfig]      
      @USER_IDS varchar(Max),              
      @SHIFT_ID INT,              
      @DATE_FROM date,              
      @CREATED_BY INT  
As      
Begin      
         
if OBJECT_ID('tempdb..#shiftconfigusers') is not null drop table #shiftconfigusers                  
create table #shiftconfigusers(USERID Int)                
Insert into #shiftconfigusers(USERID)              
Select items from dbo.fnSplitString(@USER_IDS,',')        
insert into ARC_REC_SHIFT_TRAN (USERID,SHIFT_ID,Effect_DATE,CREATED_BY,CREATED_DT)
select USERID,@SHIFT_ID,@DATE_FROM,@CREATED_BY,GETDATE() from #shiftconfigusers
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ShiftConfig] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ShiftConfig] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ShiftConfig] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ShiftConfig] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ShiftConfig] TO [DB_DMLSupport]
    AS [dbo];

