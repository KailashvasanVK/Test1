﻿CREATE PROCEDURE [dbo].[HD_Facility_AccessCheck]
(
@USERID INT
)
AS
/*
HD_Athena_AccessCheck @USERID=20
*/
BEGIN
if (Select COUNT(*) from ARC_REC_USER_INFO Where USERID = @USERID and AHS_PRL = 'Y' and ACTIVE = 1 and FUNCTIONALITY_ID = 6)>0 /* HR */  
 Select 1
else
 SELECT COUNT(*) FROM HD_PROCESS_ACCESS AS aa 
 inner join ARC_REC_USER_INFO as ui on ui.USERID = aa.UserId and ui.AHS_PRL = 'Y' and ui.ACTIVE = 1 
 Where aa.USERID = @USERID  and aa.DEPT_ID = 1 
--SELECT COUNT(*) FROM ARC_REC_USER_INFO AS UI    Where USERID = @USERID and CLIENT_ID = 15    
--SELECT COUNT(*) FROM ARC_REC_USER_INFO AS UI        
--INNER JOIN HD_Athena_Access AS PA ON PA.UserId = UI.USERID -- AND PA.DEPT_ID = TD.DEPT_ID        
----INNER JOIN HD_TICKET_DEPARTMENT AS TD ON         
----TD.FUNCTIONALITY_ID = CASE WHEN UI.FUNCTIONALITY_ID = 11 THEN 8 ELSE UI.FUNCTIONALITY_ID  END        
--WHERE PA.USERID = @USERID        
END
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Facility_AccessCheck] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Facility_AccessCheck] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Facility_AccessCheck] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_Facility_AccessCheck] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_Facility_AccessCheck] TO [DB_DMLSupport]
    AS [dbo];

