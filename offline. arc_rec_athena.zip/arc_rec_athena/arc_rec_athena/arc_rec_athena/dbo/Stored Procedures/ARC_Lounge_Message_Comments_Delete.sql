﻿CREATE procedure ARC_Lounge_Message_Comments_Delete       
(        
@CommtId int ,              
@NT_UserName varchar(100),      
@CommentText  Varchar(500)      
)         
as          
/*        
         
 CreatedBy : Udhayaganesh.p              
         
 Purpose   : Delete the Respective message Comments for Owner of the Post      
       
 ARC_Lounge_Message_Comments_Edit 43,'Udhayaganesh.p','This is test Post temp'      
       
         
*/          
begin        
iF Exists(Select 'x' from ARC_Forum_Lounge_Message_Comments where  (CommentedBy=@NT_UserName or @NT_UserName in (select NTUsername from ARC_Lounge_Admin)) and Id =@CommtId and Status=1)      
Begin      
      
Update ARC_Forum_Lounge_Message_Comments set Status=0,ModifiedBy=@NT_UserName,ModifiedOn=GETDATE()    
where Id =@CommtId      
      
      
End        
                   
            
end 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comments_Delete] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comments_Delete] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comments_Delete] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comments_Delete] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comments_Delete] TO [DB_DMLSupport]
    AS [dbo];

