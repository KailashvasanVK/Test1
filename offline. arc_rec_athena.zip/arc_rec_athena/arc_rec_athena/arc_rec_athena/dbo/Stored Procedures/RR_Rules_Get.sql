﻿CREATE Proc RR_Rules_Get         
(      
@RuleId int=0      
)       
as          
begin          
if @RuleId =0      
Begin      
select ROW_NUMBER() over (order by Ruleid) as 'Sl_No', Ruleid,Rules from RR_Rules where status=1 ORDER by CreatedOn DESC          
End      
Else      
Begin      
select ROW_NUMBER() over (order by Ruleid) as 'Sl_No', Ruleid,Rules from RR_Rules where Ruleid = @RuleId and status=1        
End      
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Rules_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Rules_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Rules_Get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Rules_Get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Rules_Get] TO [DB_DMLSupport]
    AS [dbo];

