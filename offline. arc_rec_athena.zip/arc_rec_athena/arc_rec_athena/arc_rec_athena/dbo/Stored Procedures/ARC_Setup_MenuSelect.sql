﻿CREATE PROCEDURE ARC_Setup_MenuSelect      
as      
begin      
select MenuId,MenuParentId,MenuDisplayText,MenuDescription,OutputPath    
,LogoFilePath    
,isnull((select functionname from Hr_Functionality where functionalityId = sm.BaseFuntionality_Id),'')as Functionality    
,DisplayOrder,Boxno,MenuFileName  
from ARC_Setup_Menu as SM    
end      
    
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Setup_MenuSelect] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Setup_MenuSelect] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Setup_MenuSelect] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Setup_MenuSelect] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Setup_MenuSelect] TO [DB_DMLSupport]
    AS [dbo];

