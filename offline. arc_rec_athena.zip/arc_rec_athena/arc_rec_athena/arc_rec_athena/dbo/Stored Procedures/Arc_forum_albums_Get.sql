﻿CREATE procedure Arc_forum_albums_Get                
@StartIndex int=0,              
@EndIndex int=12                 
as                   
/*            
exec Arc_forum_albums_Get @StartIndex=0,@EndIndex=12            
exec Arc_forum_albums_Get @StartIndex=13,@EndIndex=24            
*/             
Begin                  
 --select * from (select a.alb_id,b.photo_id, a.alb_name,substring(b.photo_name,1,16) photoname,b.photo_name                   
 --,b.photo_path,ROW_NUMBER() over(order by alb_id desc) Row from ARC_FORUM_ALBUMS a                    
 --inner join ARC_FORUM_PHOTO_GALLERY b on a.alb_id=b.is_albumed                     
 --where b.photo_id=(select min(c.photo_id) from ARC_FORUM_PHOTO_GALLERY c                   
 --where b.is_albumed=c.is_albumed) and b.photo_status=1 and a.alb_status=1                  
 -- ) as Seena where Row>=@StartIndex and Row<=@EndIndex       
       
--select * from (select a.AlbumId,b.PhotoId, a.Name,substring(b.PhotoName,1,16) pname,b.PhotoName                   
-- ,b.PhototPath,ROW_NUMBER() over(order by a.albumId desc) Row from ARC_FORUM_ALBUM a                    
-- inner join ARC_FORUM_ALBUM_gallery b on a.AlbumId=b.AlbumId       
-- where b.PhotoId =(select min(c.PhotoId) from ARC_FORUM_ALBUM_gallery c                   
-- where b.AlbumId=c.AlbumId) and b.Status=1 and a.Status=1                  
--  ) as Seena where Row>=@StartIndex and Row<=@EndIndex           
    
 select ROW_NUMBER() OVER(ORDER BY AlbumId) AS rowIndex,* into #TempTable from(         
SELECT a.AlbumId,g.PhotoId,a.Name,substring(a.Name,1,16) pname,a.AlbALias,            
   CONVERT(VARCHAR(10),a.PubDate,105) PubDate,g.PhotoName,g.PhototPath AS PhotoPath ,            
   ROW_NUMBER() OVER(partition by a.AlbumId ORDER BY g.PhotoIndex) PhotoIndex        
 FROM ARC_Forum_Album a            
  JOIN           
   ARC_Forum_Album_Gallery g           
  ON g.AlbumId=a.AlbumId             
        
  WHERE a.Status=1 AND g.Status=1  ) as varun where  PhotoIndex=1    
    
            
 select * from #TempTable where rowIndex>=@StartIndex and rowIndex<=@EndIndex     

                
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Arc_forum_albums_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Arc_forum_albums_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Arc_forum_albums_Get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Arc_forum_albums_Get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Arc_forum_albums_Get] TO [DB_DMLSupport]
    AS [dbo];

