﻿CREATE Procedure [dbo].[ARC_REC_USER_INFOInsert]              
 @FIRSTNAME varchar(50)              
,@LASTNAME varchar(50)              
,@Password varchar(15)              
,@EmailId varchar(75)  
,@CLIENT_ID int   
,@LastCustomerId int  
,@AccountType varchar(1)              
,@UserName varchar(100)              
,@CREATED_BY int            
,@REC_ID int = 0            
,@NT_USERNAME varchar(1) = ' '         
,@Userid int OUTPUT    
,@ACTIVE int =1
,@FirstTrnDt date = null
As              
/*                  
    Purpose   : Insert the external user details               
    Created By   : Karthik IC                  
    Created Date : 18 June 2013                  
    Impact to    : UserCreation.aspx                  
*/                  
Begin              
Insert into  ARC_REC_USER_INFO (FIRSTNAME,LASTNAME,NT_USERNAME,REC_ID,ACTIVE,AHS_PRL,Password,EmailId,AccountType,ExtUser,UserName,CREATED_BY,CLIENT_ID,LastCustomerId,FirstTrnDt)  
Select @FIRSTNAME,@LASTNAME,@NT_USERNAME,@REC_ID,@ACTIVE,'N',@Password,@EmailId,@AccountType,'Y',@UserName,@CREATED_BY,@CLIENT_ID ,@LastCustomerId,@FirstTrnDt  
set @Userid = IDENT_CURRENT( 'ARC_REC_USER_INFO')  
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_USER_INFOInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_USER_INFOInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_USER_INFOInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_USER_INFOInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_USER_INFOInsert] TO [DB_DMLSupport]
    AS [dbo];

