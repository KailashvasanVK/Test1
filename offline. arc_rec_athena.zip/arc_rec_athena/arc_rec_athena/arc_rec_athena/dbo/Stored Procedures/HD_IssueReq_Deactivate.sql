﻿CREATE proc HD_IssueReq_Deactivate    
                    @ReqId int    
As    
Begin    
update HD_ISSUE_REQUEST set    
ACTIVE = 'N'    
where ISS_REQID = @ReqId    
  
declare @CreatedBy int   
select @CreatedBy = CREATED_BY from HD_ISSUE_REQUEST where ISS_REQID  =  @ReqId  
insert into HD_ISSUE_TRAN(ISS_REQID,ISSUE_STATUS,CREATED_BY,CREATED_DT)  
select @ReqId,9,@CreatedBy,GETDATE()  
End 







GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_IssueReq_Deactivate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_IssueReq_Deactivate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_IssueReq_Deactivate] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_IssueReq_Deactivate] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_IssueReq_Deactivate] TO [DB_DMLSupport]
    AS [dbo];

