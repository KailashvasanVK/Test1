﻿--select * from ARC_REC_LEAVE_TYPES    
--select top 1 * from ARC_REC_LEAVE_REQUEST where CREATED_BY = 846 order by CREATED_DT desc  
CREATE PROCEDURE ARC_Me_LeaveRequestIns    
(          
 @LeaveTypeId int          
,@FromDt DATETIME          
,@ToDt DATETIME          
,@LeaveDays DECIMAL(4,1)          
,@LeaveMode varchar(1)          
,@AppliedTo int          
,@Reason varchar(1000)          
,@CreatedBy int          
,@SelectedLeaves decimal(4,1)          
,@LeaveReqId INT OUT          
)          
AS          
BEGIN   
  
 --declare @LeaveTypeId int = 2         
 --declare @FromDt DATETIME = '2014-01-28'          
 --declare @ToDt DATETIME   =  '2014-02-13'       
 --declare @LeaveDays DECIMAL(4,1) = 13          
 --declare @LeaveMode varchar(1) = 'F'          
 --declare @AppliedTo int = 19          
 --declare @Reason varchar(1000)=''          
 --declare @CreatedBy int=846          
 --declare @SelectedLeaves decimal(4,1)='17'      
 --declare @LeaveReqId int        
IF @AppliedTo > 0      
begin       
IF OBJECT_ID('TEMPDB..#DATE_INTERVALS_RESULT') IS NOT NULL DROP TABLE #DATE_INTERVALS_RESULT          
CREATE TABLE #DATE_INTERVALS_RESULT(DATE_SELECTED DATE,DATE_DAY          
VARCHAR(20),APPLICABLE_STATE VARCHAR(20))          
IF @LeaveTypeId <> 5          
 BEGIN          
 DECLARE @T_FROMDATE DATE          
 DECLARE @T_TODATE DATE          
 SET @T_FROMDATE = CONVERT(DATE,@FromDt)          
 SET @T_TODATE = CONVERT(DATE,@ToDt)          
 INSERT INTO #DATE_INTERVALS_RESULT   EXEC SP_ARC_REC_EMP_APPLICABLE_LEAVES @CreatedBy,@T_FROMDATE,@T_TODATE          
 END          
    --select * from     #DATE_INTERVALS_RESULT  
INSERT INTO ARC_REC_LEAVE_REQUEST(TYPEID,FROMDATE,TODATE,LEAVE_DAYS,LEAVE_MODE,APPLIED_TO,REASON,CREATED_BY,FORWARD_TO,SELECTED_LEAVES)          
SELECT @LeaveTypeId,@FromDt,@ToDt,@LeaveDays,@LeaveMode,@AppliedTo,@REASON,@CreatedBy,@AppliedTo,@SelectedLeaves          
SELECT @LeaveReqId = IDENT_CURRENT('ARC_REC_LEAVE_REQUEST')       
         
IF @LeaveTypeId = 7 or @LeaveTypeId = 16 or @LeaveTypeId = 17 or @LeaveTypeId = 18   -- for ahs meternity/manila maternity,paternity,emergency leaves          
 BEGIN          
 INSERT INTO ARC_REC_LEAVE_TRAN(LEAVE_REQID,LEAVE_DATE,CREATED_BY)          
 SELECT @LeaveReqId AS LEAVE_REQID,DATE_SELECTED AS LEAVE_DATE,@CreatedBy AS CREATED_BY FROM #DATE_INTERVALS_RESULT            
 END         
ELSE IF @LeaveTypeId <> 5  --leaves other than maternity or permission        
 BEGIN          
 INSERT INTO ARC_REC_LEAVE_TRAN(LEAVE_REQID,LEAVE_DATE,CREATED_BY)          
 SELECT @LeaveReqId AS LEAVE_REQID,DATE_SELECTED AS LEAVE_DATE,@CreatedBy AS CREATED_BY FROM #DATE_INTERVALS_RESULT           
 WHERE APPLICABLE_STATE = ''          
 END    
      
 end      
 else                
    RAISERROR('Applied To should not be empty',16,1)         
END   
  
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Me_LeaveRequestIns] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Me_LeaveRequestIns] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Me_LeaveRequestIns] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Me_LeaveRequestIns] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Me_LeaveRequestIns] TO [DB_DMLSupport]
    AS [dbo];

