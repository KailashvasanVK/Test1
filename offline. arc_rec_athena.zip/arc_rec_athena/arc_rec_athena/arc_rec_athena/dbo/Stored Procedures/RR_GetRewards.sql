﻿create PROCEDURE [dbo].[RR_GetRewards]    
      @PageIndex INT = 1    
      ,@PageSize INT = 20    
      ,@PageCount INT OUTPUT    
AS    
/*  
  
GetCustomersPageWise 1,10  
declare @p3 int  
set @p3=142  
exec [GetCustomersPageWise] @PageIndex=1,@PageSize=25,@PageCount=@p3 output  
select @p3  
  
*/  
BEGIN    
      SET NOCOUNT ON;    
      SELECT ROW_NUMBER() OVER    
            (    
                  ORDER BY [USERID] ASC    
            )AS RowNumber    
       ,USERID  
      ,' received '+ CONVERT(VARCHAR, USERID) +' points for pool of the week' As Ponints  
      ,'https://arc.accesshealthcare.co/arc_rec/images/candidate/'+CONVERT(varchar, REC_ID) +'.jpg' as REC_ID  
      ,FIRSTNAME +' '+ LASTNAME As Name       
      ,NT_USERNAME    
      ,EMPCODE    
      ,REPORTING_TO  
      ,'2 minutes before' [Time]
      ,FIRSTNAME 
    INTO #Results    
      FROM ARC_REC_USER_INFO    
         
      DECLARE @RecordCount INT    
      SELECT @RecordCount = COUNT(*) FROM #Results    
     
      SET @PageCount = CEILING(CAST(@RecordCount AS DECIMAL(10, 2)) / CAST(@PageSize AS DECIMAL(10, 2)))    
      PRINT       @PageCount    
               
      SELECT * FROM #Results    
      WHERE RowNumber BETWEEN(@PageIndex -1) * @PageSize + 1 AND(((@PageIndex -1) * @PageSize + 1) + @PageSize) - 1    
         
      DROP TABLE #Results    
END

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_GetRewards] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_GetRewards] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_GetRewards] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_GetRewards] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_GetRewards] TO [DB_DMLSupport]
    AS [dbo];

