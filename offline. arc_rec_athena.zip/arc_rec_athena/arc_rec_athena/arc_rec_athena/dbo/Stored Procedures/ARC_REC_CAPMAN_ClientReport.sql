﻿CREATE Procedure ARC_REC_CAPMAN_ClientReport                  
(                  
@ClientId int=0                  
)                  
As                  
/*                  
ARC_REC_CAPMAN_ClientReport @ClientId=0                  
*/                  
Begin                  
                  
--Select CLIENT_ID 'SL.No',CLIENT_NAME Client,OnRoll 'On Rolls (A)',OpenPotion 'ARMS Open (B)',(OnRoll+OpenPotion) 'Total (A+B)' ,Blocked ' Blocked (C)','Tobe Block (A+B)-C'=((OnRoll+OpenPotion)-blocked)                  
--,'Utilized %'=Cast((case when (OnRoll+OpenPotion)!=0 then ((blocked*1.0/(OnRoll+OpenPotion))*100) else 0 end) as numeric(18,0))                  
----,'Tobe Utilized %'=Cast((case when (OnRoll+OpenPotion)!=0 then ((((OnRoll+OpenPotion)-blocked)*1.0/(OnRoll+OpenPotion))*100) else 0 end) as numeric(18,0))                  
                  
-- from  (                        
--select ci.CLIENT_ID,CLIENT_NAME ,                        
--OnRoll=(select COUNT(*) from ARC_REC_User_info UI where UI.CLIENT_ID=Ci.CLIENT_ID and UI.ACTIVE =1 ),                        
--OpenPotion=(select isnull(SUM(pending),0) from ARMS_Status where clientid=ci.client_id ) ,                        
--blocked=(select COUNT(*) from ARC_REC_CAPMAN where  clientid=ci.client_id  and Status =1 and BayStatus =1 )                        
--from ARC_FIN_CLIENT_INFO CI where CLIENT_ID =(case when @Clientid=0 then client_id else @Clientid end) ) as Udhaya            
        
Create table #temp1        
(        
SlNo int,        
Client varchar(250),        
OnRoll int,        
ArmsOpen int,        
TotalAB int,        
Blocked int,        
TobeBlocked int,        
Util int,        
Priority int        
)        
        
        
        
insert into #temp1        
Select CLIENT_ID 'SL.No',CLIENT_NAME Client,OnRoll 'On Rolls (A)',OpenPotion 'ARMS Open (B)',        
(OnRoll+OpenPotion) 'Total (A+B)' ,Blocked ' Blocked (C)','Tobe Block (A+B)-C'=((OnRoll+OpenPotion)-blocked)                  
,'Utilized %'=Cast((case when (OnRoll+OpenPotion)!=0 then ((blocked*1.0/(OnRoll+OpenPotion))*100) else 0 end)     
 as numeric(18,0))                  
,Priority=1                
 from  (                        
select ci.CLIENT_ID,CLIENT_NAME ,                        
OnRoll=(select COUNT(*) from ARC_REC_User_info UI where UI.CLIENT_ID=Ci.CLIENT_ID and UI.ACTIVE =1 and AHS_prl='Y'   ),                        
OpenPotion=(select isnull(SUM(pending),0) from ARMS_Status where clientid=ci.client_id ) ,                        
blocked=(select COUNT(*) from ARC_REC_CAPMAN where  clientid=ci.client_id  and Status =1 and BayStatus =1 )                        
from ARC_FIN_CLIENT_INFO CI where CLIENT_ID =(case when 0=0 then client_id else 0 end) ) as Udhaya         
        
Create table #temp2        
(        
SlNo int,        
Client varchar(250),        
OnRoll int,        
ArmsOpen int,        
TotalAB int,        
Blocked int,        
TobeBlocked int,        
Util int,        
Priority int        
)        
        
insert into #temp2 select  SlNo=' ',Client='Total',        
 sum(OnRoll),sum(ArmsOpen),sum(TotalAB),sum(Blocked),sum(TobeBlocked),sum(Util),Priority=2 from #temp1        
         
--select * from #temp1 union select * from  #temp2 order by 9 asc        
        
Create table #temp3        
(        
SlNo varchar(30),        
Client varchar(250),        
OnRoll int,        
ArmsOpen int,        
TotalAB int,        
Blocked int,        
TobeBlocked int,        
Util int,        
Priority int        
)        
        
insert into #temp3 select * from #temp1 union select * from  #temp2 order by 9 asc        
        
      
      
      
select (case when SlNo = 0 then ' ' else SlNo end) as 'SI.No',Client,OnRoll 'On Rolls (A)',ArmsOpen 'ARMS Open (B)',        
TotalAB 'Total (A+B)',Blocked ' Blocked (C)',TobeBlocked 'Tobe Block (A+B)-C',    
    
'Utilized %' =Cast((case when (OnRoll+ArmsOpen)!=0 then ((blocked*1.0/(OnRoll+ArmsOpen))*100) else 0 end) as numeric(18,0)) from #temp3        
        
drop table #temp1, #temp2, #temp3        
        
    
                  
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_ClientReport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_ClientReport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_ClientReport] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_ClientReport] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_ClientReport] TO [DB_DMLSupport]
    AS [dbo];

