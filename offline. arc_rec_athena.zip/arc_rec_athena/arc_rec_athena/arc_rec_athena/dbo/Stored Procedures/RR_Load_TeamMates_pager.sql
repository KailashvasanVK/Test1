﻿create procedure [dbo].[RR_Load_TeamMates_pager]
@start int =0,
 @end int=20
 as
 begin
select  * FROM (SELECT USERID,UI.FIRSTNAME+' '+ui.LASTNAME Associate,NT_USERNAME,ROW_NUMBER() over (order by NT_USERNAME) as rownumber  from ARC_REC_USER_INFO UI  
inner Join ARC_FIN_CLIENT_INFO CI on CI.CLIENT_ID=Ui.CLIENT_ID   
where UI.ACTIVE=1 and AHS_PRL='Y' and USERID  <> 535 and NT_USERNAME<>'' 
) tab1 where tab1.rownumber >@start and tab1.rownumber < @end 

end

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Load_TeamMates_pager] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Load_TeamMates_pager] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Load_TeamMates_pager] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Load_TeamMates_pager] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Load_TeamMates_pager] TO [DB_DMLSupport]
    AS [dbo];

