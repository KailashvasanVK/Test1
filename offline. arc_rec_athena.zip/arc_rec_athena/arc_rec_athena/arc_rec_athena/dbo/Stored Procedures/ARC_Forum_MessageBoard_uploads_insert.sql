﻿CREATE PROCEDURE ARC_Forum_MessageBoard_uploads_insert          
(      
@msgID INT,          
@attch VARCHAR(500),          
@attch_index INT,          
@createdby VARCHAR(75),    
@FacilityType tinyint=1          
)          
 AS                
 BEGIN       
 IF @FacilityType=1    
     
 Begin    
 INSERT INTO ARC_Forum_MessageBoard_Uploads          
     (MsgId,Attch_File,Attch_Index,CreatedBy,CreatedOn,Status)          
 VALUES (@msgId,@attch,@attch_index,@createdby,GETDATE(),1)    
 End    
     
 Else if @FacilityType=2    
     
 Begin    
  INSERT INTO [172.25.4.66].manila_rec.dbo.ARC_Forum_MessageBoard_Uploads          
     (MsgId,Attch_File,Attch_Index,CreatedBy,CreatedOn,Status)          
  VALUES (@msgId,@attch,@attch_index,@createdby,GETDATE(),1)    
 End    
   
  Else if @FacilityType=3   
     
 Begin    
  INSERT INTO ARC_Forum_MessageBoard_Uploads          
     (MsgId,Attch_File,Attch_Index,CreatedBy,CreatedOn,Status)          
  VALUES (@msgId,@attch,@attch_index,@createdby,GETDATE(),1)    
    
  INSERT INTO [172.25.4.66].manila_rec.dbo.ARC_Forum_MessageBoard_Uploads          
     (MsgId,Attch_File,Attch_Index,CreatedBy,CreatedOn,Status)          
  VALUES (@msgId,@attch,@attch_index,@createdby,GETDATE(),1)  
    
 End           
              
 END
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_uploads_insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_uploads_insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_uploads_insert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_uploads_insert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_uploads_insert] TO [DB_DMLSupport]
    AS [dbo];

