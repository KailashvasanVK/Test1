﻿
CREATE procedure ARC_REC_IdentifyAHSCandidate
							@REC_ID INT
As
begin
select RegByAHS from ARC_REC_CANDIDATE where REC_ID = @REC_ID
end
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_IdentifyAHSCandidate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_IdentifyAHSCandidate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_IdentifyAHSCandidate] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_IdentifyAHSCandidate] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_IdentifyAHSCandidate] TO [DB_DMLSupport]
    AS [dbo];

