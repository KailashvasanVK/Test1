﻿CREATE proc ARC_Me_AssociatePersonalMailId  
      @Nt_Username varchar(100)        
As  
begin  
select p.EMAIL_ID,USERID from ARC_REC_CANDIATE_PROFILE p   
inner join ARC_REC_USER_INFO ui on p.REC_ID = ui.REC_ID  
where ui.NT_USERNAME = @Nt_Username  
end
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Me_AssociatePersonalMailId] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Me_AssociatePersonalMailId] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Me_AssociatePersonalMailId] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Me_AssociatePersonalMailId] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Me_AssociatePersonalMailId] TO [DB_DMLSupport]
    AS [dbo];

