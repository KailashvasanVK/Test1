﻿--ARC_REC_FunctionalityConfigAssociates @FunctionalityID=3,@ClientID=0,@AssociateID=308
CREATE procedure ARC_REC_FunctionalityConfigAssociates  
 @FunctionalityID int=0,   
 @ClientID int=0,    
 @AssociateID int=0,   
 @SearchStr varchar(100) = '',   
 @SearchPattern varchar(4) = '=' /** = or % **/  
As   
Begin   
if OBJECT_ID('tempdb..#AssociatesView') is not null drop table #AssociatesView   
Create Table #AssociatesView([CheckAll] varchar(max),EMPCODE varchar(20),NAME varchar(100),  
FunctionName varchar(100) ,REPORTING_TO varchar(100),CLIENT_NAME  varchar(100)  
)    
declare @qry as varchar(max)  
  
set @qry = 'insert into #AssociatesView([CheckAll],EMPCODE,NAME,FunctionName,REPORTING_TO,CLIENT_NAME)  
Select x.[CheckAll],x.EMPCODE,x.NAME,x.FunctionName,x.REPORTING_TO,x.CLIENT_NAME    
From (   
Select ''<input type="checkbox" style="margin-left: 20px;" class="CheckAll" id="''+convert(varchar,isnull(ui.REC_ID,''''))+''" >'' as [CheckAll],   
ui.EMPCODE,ui.FIRSTNAME +'' ''+ ui.LASTNAME as NAME,f.FunctionName,ui.REPORTING_TO,cl.CLIENT_NAME  
From ARC_REC_USER_INFO ui   
left join HR_Functionality f on ui.FUNCTIONALITY_ID = f.FunctionalityId  
left join ARC_FIN_CLIENT_INFO cl on ui.CLIENT_ID = cl.CLIENT_ID   
Where ui.AHS_PRL = ''Y'' and ui.ACTIVE = 1'  
  
if @AssociateID  > 0   
 set @qry += ' and ui.USERID = '+CONVERT(varchar,@AssociateID)+')x order by x.NAME'   
else  
begin   
if @FunctionalityID > 0  
 set @qry += ' and ui.FUNCTIONALITY_ID = '+CONVERT(varchar,@FunctionalityID)  
if @ClientID > 0   
 set @qry += ' and ui.CLIENT_ID = '+CONVERT(varchar,@ClientID)  
 SET @qry  += ' )x order by x.NAME'  
end   
  
print(@qry)  
exec(@qry)  
Declare @OrderStr varchar(100)  
set @OrderStr=''  
Exec FilterTable   
@DbName = 'tempdb'   
,@TblName = '#AssociatesView'   
,@SearchStr = @SearchStr   
,@SearchPattern = @SearchPattern   
,@OrderStr = @OrderStr   
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_FunctionalityConfigAssociates] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_FunctionalityConfigAssociates] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_FunctionalityConfigAssociates] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_FunctionalityConfigAssociates] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_FunctionalityConfigAssociates] TO [DB_DMLSupport]
    AS [dbo];

