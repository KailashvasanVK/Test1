﻿
CREATE PROCEDURE ARC_Wheels_Check_Cab_Facility  
@UserId INT  
AS  
BEGIN  
 SELECT ISNULL(COUNT(*),0) AS IS_FACILITY FROM ARC_REC_USER_INFO UI,HR_Functionality HF WHERE UI.USERID = @UserId and UI.FUNCTIONALITY_ID = 5  
 and UI.FUNCTIONALITY_ID = HF.FunctionalityId  
END

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Wheels_Check_Cab_Facility] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Wheels_Check_Cab_Facility] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Wheels_Check_Cab_Facility] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Wheels_Check_Cab_Facility] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Wheels_Check_Cab_Facility] TO [DB_DMLSupport]
    AS [dbo];

