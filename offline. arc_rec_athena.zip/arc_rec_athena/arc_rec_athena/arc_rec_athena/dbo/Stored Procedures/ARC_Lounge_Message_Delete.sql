﻿CREATE procedure ARC_Lounge_Message_Delete            
(              
@MsgId int ,                    
@NT_UserName varchar(100)            
)               
as                
/*              
               
 CreatedBy : Udhayaganesh.p                    
               
 Purpose   : Edit the Respective Message for Owner of the Post            
             
 ARC_Lounge_Message_Delete 7,'Udhayaganesh.p','This is test Post'            
             
               
*/                
begin              
iF Exists(Select 'x' from ARC_Forum_Lounge_Messages         
where (CreatedBy=@NT_UserName or @NT_UserName in (select NTUsername from ARC_Lounge_Admin)) and Id =@MsgId and Status=1)            
Begin            
            
if exists(select NTUsername from ARC_Lounge_Admin where NTUsername =@NT_UserName)  
begin  
Update ARC_Forum_Lounge_Messages set Status=0,ModifiedBy=@NT_UserName,ModifiedOn=GETDATE() where Id =@MsgId    
update RR_Scoreboard set Points =0,ReferenceInfo = ReferenceInfo +' - Deleted'+@Nt_username where referenceid=@MsgId  and CID=16    
End 
else
begin
Update ARC_Forum_Lounge_Messages set Status=0,ModifiedBy=@NT_UserName,ModifiedOn=GETDATE() where Id =@MsgId    
update RR_Scoreboard set Points =0,ReferenceInfo = ReferenceInfo +' - Deleted'+@Nt_username where referenceid=@MsgId  and CID=16    
end   
Select 1 'Output'      
            
End   
Else   
Begin             
select 0  'Output'                       
End                   
end 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Message_Delete] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Delete] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Delete] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Message_Delete] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Delete] TO [DB_DMLSupport]
    AS [dbo];

