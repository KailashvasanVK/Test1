﻿            
--ARC_REC_TIMELINE_SELECT 975,'2014-05-01'                    
CREATE PROCEDURE ARC_REC_TIMELINE_SELECT                      
    @USER_ID INT,                      
    @TIMELINE_MONTH DATE                          
AS                      
BEGIN                      
                      
DECLARE @REC_ID AS INT                      
DECLARE @NT_USERNAME AS VARCHAR(500)                      
SELECT @REC_ID = REC_ID,@NT_USERNAME = NT_USERNAME FROM ARC_REC_USER_INFO WHERE USERID = @USER_ID                               
                       
IF OBJECT_ID('TEMPDB..#TIMELINE','U') IS NOT NULL DROP TABLE #TIMELINE                       
CREATE TABLE #TIMELINE (FEED VARCHAR(500),[SOURCE] VARCHAR(200),SCRIPT VARCHAR(MAX),CREATED_DT DATETIME)                      
                      
  BEGIN                      
  /* are.rec Timelines */                      
                      
  -- Here AHC_JobRefer ReferNo is being referenced as REC_ID in ARC_REC_CANDIDATE.                      
  -- we can find job reffered by Person FB Name in AHC_JobRefer table by the reference of ReferNo                       
INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)                      
(SELECT 'Referred by' As FEED,'arc.recruit' as [SOURCE],(CONVERT(VARCHAR,C.CREATED_DT,106)+' referred by '+R.FBName) AS SCRIPT,c.CREATED_DT FROM ARC_REC_CANDIDATE C                      
INNER JOIN AHC_JobRefer R ON C.REC_ID = R.ReferNo                      
WHERE DATEPART(MONTH,CREATED_DT) = DATEPART(MONTH,@TIMELINE_MONTH)                       
AND DATEPART(YEAR,CREATED_DT) = DATEPART(YEAR,@TIMELINE_MONTH) AND REC_ID = @REC_ID AND APPLY_FB = 1)                      
                      
INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)                      
(SELECT 'Walk-in' As FEED,'arc.recruit' as [SOURCE],(CONVERT(VARCHAR,CREATED_DT,106)+' Came to accesshealthcare for interview') AS SCRIPT,CREATED_DT                             
FROM ARC_REC_CANDIDATE WHERE DATEPART(MONTH,CREATED_DT) = DATEPART(MONTH,@TIMELINE_MONTH)                       
AND DATEPART(YEAR,CREATED_DT) = DATEPART(YEAR,@TIMELINE_MONTH) AND REC_ID = @REC_ID AND APPLY_FB = 0 )                      
                      
INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)                      
(SELECT 'Walk-in Facebook' As FEED,'arc.recruit' as [SOURCE],(CONVERT(VARCHAR,CREATED_DT,106)+' Came to accesshealthcare through Facebook') AS SCRIPT,CREATED_DT                             
 FROM ARC_REC_CANDIDATE WHERE DATEPART(MONTH,CREATED_DT) = DATEPART(MONTH,@TIMELINE_MONTH)                       
AND DATEPART(YEAR,CREATED_DT) = DATEPART(YEAR,@TIMELINE_MONTH) AND REC_ID = @REC_ID AND APPLY_FB = 1 )                      
                      
INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)                      
(SELECT 'Typing Test' As FEED,'arc.recruit' as [SOURCE],(CONVERT(VARCHAR,CREATED_DT,106)+' Scored '+ CONVERT(VARCHAR,NET_WPM) +' in typing test') AS SCRIPT,CREATED_DT                              
FROM ARC_REC_TYPING_TEST WHERE DATEPART(MONTH,CREATED_DT) = DATEPART(MONTH,@TIMELINE_MONTH)                                   
AND DATEPART(YEAR,CREATED_DT) = DATEPART(YEAR,@TIMELINE_MONTH) AND REC_ID = @REC_ID )                      
                      
INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)                      
(SELECT 'Speciality Test' As FEED,'arc.recruit' as [SOURCE],                      
(CONVERT(VARCHAR,CREATED_DT,106)+' Scored '+ CONVERT(VARCHAR,(SCORE * 100) / 15 )+'% in '+CASE TEST_TYPE WHEN 'A' THEN 'Apptitude' WHEN 'E' THEN 'English' WHEN 'C' THEN 'Coding' ELSE '' END ) AS                       
SCRIPT,CREATED_DT  FROM ARC_REC_TEST WHERE DATEPART(MONTH,CREATED_DT) = DATEPART(MONTH,@TIMELINE_MONTH)                       
AND DATEPART(YEAR,CREATED_DT) = DATEPART(YEAR,@TIMELINE_MONTH) AND REC_ID = @REC_ID )                      
                      
INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)                      
(SELECT 'Interview' As FEED,'arc.recruit' as [SOURCE],(CONVERT(VARCHAR,A.CREATED_DT,106)+' Interviewed by '+ UI.FIRSTNAME+ ' '+UI.LASTNAME) AS SCRIPT,A.CREATED_DT                              
FROM ARC_REC_ASSESSMENT A INNER JOIN ARC_REC_USER_INFO UI ON UI.USERID = A.CREATED_BY                       
WHERE DATEPART(MONTH,A.CREATED_DT) = DATEPART(MONTH,@TIMELINE_MONTH) AND                      
DATEPART(YEAR,A.CREATED_DT) = DATEPART(YEAR,@TIMELINE_MONTH) AND A.REC_ID = @REC_ID AND ASSESS_MODE = 'O' )                      
                      
INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)                      
(SELECT 'Offer Letter' As FEED,'arc.recruit' as [SOURCE],(CONVERT(VARCHAR,CREATED_DT,106)+' Offer letter sent on ') AS SCRIPT,CREATED_DT                            
FROM ARC_REC_CANDIDATE_DOC_STATUS WHERE DATEPART(MONTH,CREATED_DT) = DATEPART(MONTH,@TIMELINE_MONTH)                                 
AND DATEPART(YEAR,CREATED_DT) = DATEPART(YEAR,@TIMELINE_MONTH) AND REC_ID = @REC_ID AND DOC_TYPE  = 'OFFER_LETTER' )                      
                      
INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)                       
(SELECT 'Joining' As FEED,'arc.recruit' as [SOURCE],(CONVERT(VARCHAR,CREATED_DT,106)+' Joined accesshealthcare') AS SCRIPT,CREATED_DT FROM ARC_REC_CANDIDATE_DOC_STATUS WHERE DATEPART(MONTH,CREATED_DT) = DATEPART(MONTH,@TIMELINE_MONTH)                     
  
AND DATEPART(YEAR,CREATED_DT) = DATEPART(YEAR,@TIMELINE_MONTH) AND REC_ID = @REC_ID AND DOC_TYPE  = 'APPOINMENT_LETTER' )                      
                      
INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)(                      
SELECT 'Referred a friend' As FEED,'arc.recruit' as [SOURCE],                                  
(CONVERT(VARCHAR,CREATED_DT,106)+' Referred '+ FIRSTNAME+' '+LASTNAME+' for a job' ) AS SCRIPT,CREATED_DT                                 
FROM ARC_REC_CANDIATE_PROFILE WHERE DATEPART(MONTH,CREATED_DT) = DATEPART(MONTH,@TIMELINE_MONTH)                       
AND DATEPART(YEAR,CREATED_DT) = DATEPART(YEAR,@TIMELINE_MONTH) AND EMPLOYEE_ID = @REC_ID                                  
)                      
                                  
                      
                      
  -- Here AHC_JobRefer ReferNo is being referenced as REC_ID in ARC_REC_CANDIDATE.                      
  -- We didnt't store employee fb name in any table or Empcode in AHC_JobRefer table. so we couldn't get refered list .                      
                              
                      
--INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)                      
--(SELECT 'Referral amount' As FEED,'arc.recruit' as [SOURCE],'[Date] Won referral cash award' AS SCRIPT,CREATED_DT )                      
                      
 /* End of are.rec Timelines */                      
 END                      
                       
 BEGIN                      
 /* are.learn Timelines */                      
-- INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT)                       
-- (SELECT 'Training' As FEED,'arc.learn' as [SOURCE],'[Date] Joined training class' AS SCRIPT )                      
                       
-- INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT)                      
-- (SELECT 'Induction Test' AS FEED,'arc.learn' AS [SOURCE],'[Date] Scored [%] in Induction test')                      
                       
-- INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT)                       
-- (SELECT 'Weekly refresher' AS FEED,'arc.learn' AS [SOURCE],'[Date] Attended training [topic]')                      
                       
INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)                             
 SELECT 'Weekly Test' As FEED,'arc.learn' as [SOURCE],                            
(CONVERT(VARCHAR,TR.CREATED_DT,106)+' Scored '+ CONVERT(VARCHAR,(SCORE * 100) / 15 )+'% in Weekly Test') AS                       
SCRIPT,TR.CREATED_DT FROM ARC_Knol..ARC_KNOL_TRANS_RESULT TR WHERE DATEPART(MONTH,TR.CREATED_DT) = DATEPART(MONTH,@TIMELINE_MONTH)                       
AND DATEPART(YEAR,TR.CREATED_DT) = DATEPART(YEAR,@TIMELINE_MONTH) AND [UID] =( select top 1 UID from ARC_Knol..User_Master where Ntusername = @NT_USERNAME and [type] = 1  )                            
                        
                                  
                      
/* End of are.learn Timelines */                      
END                      
                      
--  BEGIN                      
--    /* are.flow Timelines */                     
-- INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT)                       
-- (SELECT 'Client' AS FEED,'arc.flow' AS [SOURCE],'[Date] Joined [client name]')                      
                       
-- INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT)                      
-- (SELECT 'Client system skills' AS FEED,'arc.flow' AS [SOURCE],'[Date] Added client system skillsets [skillset]')                      
                        
-- INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT)                       
-- (SELECT 'Process skillset' AS FEED,'arc.flow' AS [SOURCE],'[Date] Added process skillsets [skillset]')                              
                       
-- INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT)                  
-- (SELECT 'Production - First day' AS FEED,'arc.flow' AS [SOURCE],'[Date] First day at Production')                      
                      
--/*end of are.flow Timelines */                      
--END                      
                      
BEGIN                      
 /* are.knol Timelines */                      
INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)                             
SELECT 'Article - Favorite' As FEED,'arc.knol' as [SOURCE],                      
(CONVERT(VARCHAR,F.CreatedDt,106)+' Tagged "'+ A.ArticleTitle+'" as favorite') AS                  
SCRIPT,F.CreatedDt  FROM ARC_Knol..Knol_Favs F                      
INNER JOIN ARC_Knol..Knol_Articles A ON A.ArticleID = F.ArticleID                      
WHERE DATEPART(MONTH,F.CreatedDt) = DATEPART(MONTH,@TIMELINE_MONTH)                      
AND DATEPART(YEAR,F.CreatedDt) = DATEPART(YEAR,@TIMELINE_MONTH) AND                       
[UID] = ( select top 1 [UID] from ARC_Knol..User_Master where [TYPE] = 1 and Ntusername = (select NT_USERNAME  from ARC_REC_USER_INFO WHERE USERID = @USER_ID))                      
                            
/*end of are.knol Timelines */                       
END                      
                      
  BEGIN                      
 /* are.me Timelines */                      
--INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)                      
--(SELECT 'Performance Management' AS FEED,'arc.me' AS [SOURCE],'[Date] Scored [score] in [month] performance score')                      
                      
INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)                      
SELECT 'Leave Request' AS FEED,'arc.me' AS [SOURCE],(CONVERT(VARCHAR,LT.LEAVE_DATE,106)+' Availed '+ TY.TYPE_TEXT ) AS SCRIPT,LT.LEAVE_DATE                       
FROM ARC_REC_LEAVE_REQUEST LR                      
inner join ARC_REC_LEAVE_TRAN as LT ON LT.LEAVE_REQID = LR.LEAVE_REQID                         
INNER JOIN ARC_REC_LEAVE_TYPES TY ON LR.TYPEID = TY.TYPEID                      
WHERE LR.CREATED_BY = @USER_ID AND DATEPART(MONTH,LT.LEAVE_DATE) = DATEPART(MONTH,@TIMELINE_MONTH)                       
AND DATEPART(YEAR,LT.LEAVE_DATE) = DATEPART(YEAR,@TIMELINE_MONTH) AND LR.LEAVE_STATUS = 1                        
                      
INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)                      
SELECT CASE WHEN LF.LEAVE_STATUS = 1 THEN 'Leave approval' WHEN LF.LEAVE_STATUS = 2 THEN 'Leave reject' WHEN LF.LEAVE_STATUS = 3 THEN 'Leave forward' ELSE '' END AS FEED                      
,'arc.me' AS [SOURCE],(CONVERT(VARCHAR,LF.CREATED_DT,106)+case when lf.LEAVE_STATUS = 1 THEN ' Approved ' when lf.LEAVE_STATUS = 2 then ' Rejected ' WHEN LF.LEAVE_STATUS = 3 THEN ' Forward ' ELSE ' ' end + TY.TYPE_TEXT ) AS SCRIPT,LF.CREATED_DT                                                   
FROM ARC_REC_LEAVE_FORWARD LF                      
INNER JOIN ARC_REC_LEAVE_REQUEST AS LR ON LR.LEAVE_REQID = LF.LEAVE_REQID                      
INNER JOIN ARC_REC_LEAVE_TYPES TY ON LR.TYPEID = TY.TYPEID                      
WHERE LF.CREATED_BY = @USER_ID AND DATEPART(MONTH,LF.CREATED_DT) = DATEPART(MONTH,@TIMELINE_MONTH)     
AND DATEPART(YEAR,LF.CREATED_DT) = DATEPART(YEAR,@TIMELINE_MONTH)                       
                      
                      
--INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)                      
--(SELECT 'Annual appraisal' AS FEED,'arc.me' AS [SOURCE],'[Date] Scored [score] in Annual appraisal and was ranked [grade]')                       
                      
--INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)                      
--(SELECT 'Promotion' AS FEED,'arc.me' AS [SOURCE],'[Date] Was promoted to [new title]')                       
                      
INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)                      
SELECT 'Exit Initiation' AS FEED,'arc.me' AS [SOURCE],(CONVERT(VARCHAR,CREATED_DT,106)+' Initiated Exit') AS SCRIPT,CREATED_DT FROM ARC_ME_EXIT WHERE CREATED_BY = @USER_ID                       
AND DATEPART(MONTH,CREATED_DT) = DATEPART(MONTH,@TIMELINE_MONTH)                       
AND DATEPART(YEAR,CREATED_DT) = DATEPART(YEAR,@TIMELINE_MONTH)                      
           
--INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)                      
--(SELECT 'Leaving accesshealthcare' AS FEED,'arc.me' AS [SOURCE],'[Date] Left accesshealthcare')                      
                      
    /*End of are.me Timelines */                      
    END                      
                      
BEGIN                      
  /* are.forum Timelines */                      
--INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)  -- Not yet started                      
--(SELECT 'Employee of the month' AS FEED,'arc.forum' AS [SOURCE],'[Date] Was employee of the month')                      
                      
INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)                                        
SELECT 'Tagged in article' AS FEED,'arc.forum' AS [SOURCE],CONVERT(varchar,CreatedOn,106)+' Was tagged in an article' AS SCRIPT,CreatedOn                              
FROM ARC_Forum_MessageBoard_Taggedusers T                              
INNER JOIN ARC_Forum_MessageBoard M ON M.MsgId = T.MsgId                              
where T.NT_userid = @NT_USERNAME  and M.Status = 1 and DATEPART(YEAR,M.CreatedOn) = DATEPART(YEAR,@TIMELINE_MONTH) and                               
DATEPART(MONTH,M.CreatedOn) = DATEPART(MONTH,@TIMELINE_MONTH)                                   
                      
--INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT) -- Not yet Started . may be photo gallery                       
--(SELECT 'Tagged in photo' AS FEED,'arc.forum' AS [SOURCE],'[Date] Was tagged in a photo')                      
                      
INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)             
SELECT 'Like post in Lounge' AS FEED,'arc.forum' AS [SOURCE],CONVERT(varchar,L.LikedOn,106)+' Liked a post in Lounge' AS SCRIPT,LikedOn                              
FROM ARC_Forum_Lounge_Message_Likes L      
inner join ARC_Forum_Lounge_Messages M ON l.MsgId = m.ID      
where L.LikedBy = @NT_USERNAME and M.Status = 1 and L.Status = 1              
and DATEPART(YEAR,L.LikedOn) = DATEPART(YEAR,@TIMELINE_MONTH) and                               
DATEPART(MONTH,L.LikedOn) = DATEPART(MONTH,@TIMELINE_MONTH)             
            
            
INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)            
SELECT 'Flagged Message' AS FEED,'arc.forum' AS [SOURCE],CONVERT(varchar,R.ReportedOn,106)+' You reported a message for abuse' AS SCRIPT,R.ReportedOn                              
FROM ARC_Forum_Lounge_Message_Flags R      
inner join ARC_Forum_Lounge_Messages M ON R.id = M.ID      
where R.ReportedBy = @NT_USERNAME and r.Status = 1 and M.Status = 1            
and DATEPART(YEAR,R.ReportedOn) = DATEPART(YEAR,@TIMELINE_MONTH) and                               
DATEPART(MONTH,R.ReportedOn) = DATEPART(MONTH,@TIMELINE_MONTH)       
             
            
INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)            
SELECT 'Flagged Message' AS FEED,'arc.forum' AS [SOURCE],CONVERT(varchar,F.ReportedOn,106)+' Your message was reported for abuse' AS SCRIPT,F.ReportedOn                              
from ARC_Forum_Lounge_Messages M            
inner join ARC_Forum_Lounge_Message_Flags F ON M.ID = F.MsgId            
where M.CreatedBy = @NT_USERNAME and M.Status = 1           
and DATEPART(YEAR,F.ReportedOn) = DATEPART(YEAR,@TIMELINE_MONTH) and                               
DATEPART(MONTH,F.ReportedOn) = DATEPART(MONTH,@TIMELINE_MONTH) and F.Status = 1            
            
                      
INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)                                      
SELECT 'Comment on post in Lounge' AS FEED,'arc.forum' AS [SOURCE],CONVERT(varchar,C.CommentedOn,106)+' Commented on a post in Lounge' AS SCRIPT,CommentedOn                              
FROM ARC_Forum_Lounge_Message_Comments C       
inner join ARC_Forum_Lounge_Messages M ON C.MsgId = M.ID      
where C.CommentedBy = @NT_USERNAME and M.Status = 1 and C.Status = 1                               
and DATEPART(YEAR,C.CommentedOn) = DATEPART(YEAR,@TIMELINE_MONTH) and                               
DATEPART(MONTH,C.CommentedOn) = DATEPART(MONTH,@TIMELINE_MONTH)                               
                      
--INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)                      
--(SELECT 'Mod Warning - Lounge' AS FEED,'arc.forum' AS [SOURCE],'[Date] Was given Level [1/2/3] warning by Mod')                      
                      
--SELECT 'Mod Warning - Lounge' AS FEED,'arc.forum' AS [SOURCE],CONVERT(varchar,C.ReportedOn,106)+' Was given Level [1/2/3] warning by Mod ' AS SCRIPT,C.ReportedOn                              
--FROM ARC_Forum_Lounge_Message_Flags C                              
--INNER JOIN ARC_Forum_Lounge_Messages M ON C.MsgId = M.id                              
--where C.ReportedBy = @NT_USERNAME                              
--and DATEPART(YEAR,C.ReportedOn) = DATEPART(YEAR,@TIMELINE_MONTH) and                               
--DATEPART(MONTH,C.ReportedOn) = DATEPART(MONTH,@TIMELINE_MONTH)                              
                              
--INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)                      
--(SELECT 'Poll of the week' AS FEED,'arc.forum' AS [SOURCE],'[Date] Answered with choice [a/b/c] in Poll of the week')                      
            --SELECT 'Poll of the week' AS FEED,'arc.forum' AS [SOURCE],                              
--CONVERT(varchar,R.CREATED_ON,106)+' Answered with choice '+CONVERT(VARCHAR,                              
--(case r.OPT when 1 then '"'+P.OPT1+'"'  when 2 then '"'+P.OPT2+'"' when 3 then '"'+P.OPT3+'"' else '"'+P.OPT4+'"' end )) +' in Poll of the week [ '+ CONVERT(VARCHAR,P.POLL)+' ]' AS SCRIPT,R.CREATED_ON                              
--FROM ARC_Forum_Polls_Results R                              
--INNER JOIN ARC_Forum_Polls P ON R.POLL_ID = P.POLL_ID                              
--WHERE R.NT_USERNAME = @NT_USERNAME and  DATEPART(YEAR,R.CREATED_ON) = DATEPART(YEAR,@TIMELINE_MONTH) and                               
--DATEPART(MONTH,R.CREATED_ON) = DATEPART(MONTH,@TIMELINE_MONTH)                               
                                 
                              
INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)                                        
SELECT 'Submitted an idea' AS FEED,'arc.forum' AS [SOURCE],                              
CONVERT(varchar,CREATED_ON,106)+' Submitted an idea' AS SCRIPT,CREATED_ON from ARC_Forum_User_Ideas                               
where DATEPART(YEAR,CREATED_ON) = DATEPART(YEAR,@TIMELINE_MONTH) and                               
DATEPART(MONTH,CREATED_ON) = DATEPART(MONTH,@TIMELINE_MONTH)                               
and CREATED_BY = @NT_USERNAME                                   
                   
INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)                                        
(SELECT 'Birthday' AS FEED,'arc.forum' AS [SOURCE],
CONVERT(varchar(7),C.DOB,106)+CONVERT(VARCHAR,(DATEPART(YEAR,@TIMELINE_MONTH)))+' Today is your birthday!' AS SCRIPT,
convert(varchar,Datepart(YEAR,GETDATE()))+'-'+convert(varchar,Datepart(MONTH,DOB))+'-'+convert(varchar,DATEPART(DAY,DOB))                    
FROM ARC_REC_CANDIATE_PROFILE C                              
INNER JOIN ARC_REC_USER_INFO UI  ON C.REC_ID = UI.REC_ID      
WHERE DATEPART(MONTH,C.DOB) = DATEPART(MONTH,@TIMELINE_MONTH) and UI.USERID =@USER_ID )     
    
    
--if @USER_ID in(807,847) and @NT_USERNAME in('udhayaganesh.p','arvind.perumbal')    
--begin    
/* From R and R            */    
INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)     
select 'Received '+ CONVERT(VARCHAR, SB.Points) +' SDPs '+CM.Feeds   Feed,    
'arc.rewards' AS [SOURCE],CONVERT(varchar,sb.CreatedOn,106)+ ' Received '+ CONVERT(VARCHAR, SB.Points) +' SDPs '+CM.Feeds   AS SCRIPT,    
sb.CreatedOn from RR_Scoreboard SB    
inner Join RR_Critera_master CM on CM.cid=sb.cid    
inner join ARC_REC_USER_INFO Ui on ui.USERID =sb.Userid and NT_USERNAME =@NT_USERNAME    
where DATEPART(YEAR,sb.CreatedOn) = DATEPART(YEAR,@TIMELINE_MONTH) and                               
DATEPART(MONTH,sb.CreatedOn) = DATEPART(MONTH,@TIMELINE_MONTH)                               
and sb.Userid  = @USER_ID             
--end                      
                      
--INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT) -- Not yet started                       
--(SELECT 'Anniversary' AS FEED,'arc.forum' AS [SOURCE],'[Date] Completed a year with accesshealthcare')                      
                      
--INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT) -- Not yet started                       
--(SELECT 'Anniversary' AS FEED,'arc.forum' AS [SOURCE],'[Date] Completed [2-100] years with accesshealthcare')                      
                     
--INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT) -- Not yet started                       
--(SELECT 'Client Appreciation' AS FEED,'arc.forum' AS [SOURCE],'[Date] Tagged in client appreciation columns')                      
    /*End of are.forum Timelines */                                  
 END                      
                       
--  BEGIN                      
-- /* are.quality Timelines */                      
--INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)                      
--(SELECT 'Customer complaint' AS FEED,'arc.quality' AS [SOURCE],'[Date] Was tagged under customer complaint [link to complaint]')                      
--/*End of are.quality Timelines */                      
-- END                       
                       
  BEGIN                      
 /* are.support Timelines */                                   
 INSERT INTO #TIMELINE(FEED,[SOURCE],SCRIPT,CREATED_DT)                      
 SELECT                       
CASE WHEN F.ISSUE_STATUS = 0 THEN                      
  CASE WHEN TKT = 1 THEN  'Raised a ticket [' + CONVERT(VARCHAR,F.TICKET_ID) + ']' ELSE 'Raised a recurring issue ticket [' + CONVERT(VARCHAR,F.TICKET_ID) + ']' END                       
  WHEN F.ISSUE_STATUS = 1 THEN 'Ticket Approval'                       
  WHEN F.ISSUE_STATUS = 2 THEN 'Ticket Reject'                       
  WHEN F.ISSUE_STATUS = 3 THEN 'Ticket Assigned'                 
  WHEN F.ISSUE_STATUS = 4 THEN 'Ticket Releasing'                      
  WHEN F.ISSUE_STATUS in (5,6) THEN 'Ticket Fixed'   
  WHEN F.ISSUE_STATUS = 7 THEN 'Ticket Rejected' 
  WHEN F.ISSUE_STATUS = 8 THEN 'Ticket Acknowledged'    
  WHEN F.ISSUE_STATUS = 9 THEN 'Ticket Deactivated'                  
  END                      
 As FEED                          
,'arc.support' as [SOURCE],                      
CASE WHEN F.ISSUE_STATUS = 0 THEN                      
   CASE WHEN TKT = 1 THEN (CONVERT(VARCHAR,F.CREATED_DT,106)+' Raised a ticket "'+ A.ISSUE_NAME+'" with '+' "'+D.DEPT_NAME+'" ')                           
   ELSE (CONVERT(VARCHAR,F.CREATED_DT,106)+' Raised a Level ' + CONVERT(VARCHAR,TKT) + ' for "'+ A.ISSUE_NAME+'" with '+' "'+D.DEPT_NAME+'" ') END                 
  WHEN F.ISSUE_STATUS = 1 THEN CONVERT(VARCHAR,F.CREATED_DT,106)+ ' Ticket ['+ CONVERT(VARCHAR,F.TICKET_ID) +'] Approved'                       
  WHEN F.ISSUE_STATUS = 2 THEN CONVERT(VARCHAR,F.CREATED_DT,106)+ ' Ticket ['+ CONVERT(VARCHAR,F.TICKET_ID) +'] Rejected'                       
  WHEN F.ISSUE_STATUS = 3 THEN CONVERT(VARCHAR,F.CREATED_DT,106)+ ' Ticket ['+ CONVERT(VARCHAR,F.TICKET_ID) +'] Assigned'                       
  WHEN F.ISSUE_STATUS = 4 THEN CONVERT(VARCHAR,F.CREATED_DT,106)+ ' Ticket ['+ CONVERT(VARCHAR,F.TICKET_ID) +'] Released'                       
  WHEN F.ISSUE_STATUS in (5,6) THEN CONVERT(VARCHAR,F.CREATED_DT,106) +' Ticket ['+ CONVERT(VARCHAR,F.TICKET_ID) +'] Fixed'  
  WHEN F.ISSUE_STATUS = 7  THEN CONVERT(VARCHAR,F.CREATED_DT,106) +' Ticket ['+ CONVERT(VARCHAR,F.TICKET_ID) +'] Rejected' 
  WHEN F.ISSUE_STATUS = 8  THEN CONVERT(VARCHAR,F.CREATED_DT,106) +' Ticket ['+ CONVERT(VARCHAR,F.TICKET_ID) +'] Acknowledged'                     
  WHEN F.ISSUE_STATUS = 9  THEN CONVERT(VARCHAR,F.CREATED_DT,106) +' Ticket ['+ CONVERT(VARCHAR,F.TICKET_ID) +'] Deactivated'                     
                    
  END                      
AS SCRIPT                          
,F.CREATED_DT                          
FROM                          
(                          
SELECT HT.*                           
       ,(SELECT COUNT(*) FROM HD_ISSUE_REQUEST WHERE TICKET_ID = HR.TICKET_ID AND ISS_REQID < HR.ISS_REQID) +1 AS TKT                          
       ,HR.ISSUE_ID,HR.TICKET_ID                      
       FROM HD_ISSUE_TRAN AS HT                      
       INNER JOIN HD_ISSUE_REQUEST AS HR ON HR.ISS_REQID = HT.ISS_REQID                      
       WHERE DATEPART(MONTH,HT.CREATED_DT) = DATEPART(MONTH,@TIMELINE_MONTH)                      
AND DATEPART(YEAR,HT.CREATED_DT) = DATEPART(YEAR,@TIMELINE_MONTH)                           
AND HT.CREATED_BY = @USER_ID                          
--ORDER BY HR.TICKET_ID                      
) AS F                                
INNER JOIN HD_ISSUE_INFO A ON F.ISSUE_ID = A.ISSUE_ID                      
INNER JOIN HD_TICKET_DEPARTMENT D ON A.DEPT_ID = D.DEPT_ID                      
ORDER BY F.CREATED_DT                          
                      
--SELECT CASE WHEN TKT = 1 THEN  'Raised a ticket' ELSE 'Raised a recurring issue ticket' END As FEED                          
--,'arc.support' as [SOURCE],                      
--CASE WHEN TKT = 1 THEN (CONVERT(VARCHAR,F.CREATED_DT,106)+' Raised a ticket "'+ A.ISSUE_NAME+'" with '+' "'+D.DEPT_NAME+'" ')                           
--ELSE (CONVERT(VARCHAR,F.CREATED_DT,106)+' Raised a Level ' + CONVERT(VARCHAR,TKT) + ' for "'+ A.ISSUE_NAME+'" with '+' "'+D.DEPT_NAME+'" ') END                          
--AS SCRIPT                          
--,F.CREATED_DT                          
--FROM                          
--(                          
--SELECT *                           
--       ,(SELECT COUNT(*) FROM HD_ISSUE_REQUEST WHERE TICKET_ID = HR.TICKET_ID AND ISS_REQID < HR.ISS_REQID) +1 AS TKT                          
--       FROM HD_ISSUE_REQUEST AS HR                          
--       WHERE DATEPART(MONTH,HR.CREATED_DT) = DATEPART(MONTH,@TIMELINE_MONTH)                      
--AND DATEPART(YEAR,HR.CREATED_DT) = DATEPART(YEAR,@TIMELINE_MONTH)                           
--AND HR.CREATED_BY = @USER_ID                          
--) AS F                                
--INNER JOIN HD_ISSUE_INFO A ON F.ISSUE_ID = A.ISSUE_ID                      
--INNER JOIN HD_TICKET_DEPARTMENT D ON A.DEPT_ID = D.DEPT_ID                      
--ORDER BY F.CREATED_DT                          
                      
-- /*End of are.support Timelines */                       
  END                       
                       
  SELECT FEED,[SOURCE], CASE WHEN CONVERT(INT,(LEN(SCRIPT))) > 97 THEN  SUBSTRING(SCRIPT, 0, 97) ELSE SCRIPT END As SCRIPT ,CREATED_DT FROM #TIMELINE order by CREATED_DT asc                        
          
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_TIMELINE_SELECT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_TIMELINE_SELECT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_TIMELINE_SELECT] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_TIMELINE_SELECT] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_TIMELINE_SELECT] TO [DB_DMLSupport]
    AS [dbo];

