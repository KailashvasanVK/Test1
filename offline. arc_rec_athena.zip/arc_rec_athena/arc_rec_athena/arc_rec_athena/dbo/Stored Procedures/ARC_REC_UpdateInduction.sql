﻿create procedure ARC_REC_UpdateInduction  
       @REC_IDS varchar(Max),    
       @InductionBy int  
         
As  
Begin  
if OBJECT_ID('tempdb..#IndexAssociates') is not null drop table #IndexAssociates        
create table #IndexAssociates(REC_ID int,USERID Int)      
Insert into #IndexAssociates(REC_ID)    
Select items from dbo.fnSplitString(@REC_IDS,',')    
  
update #IndexAssociates set  
USERID = ui.USERID  
from #IndexAssociates ia  
join ARC_REC_USER_INFO ui on ui.REC_ID = ia.REC_ID  
  
update ARC_REC_InductionMaster set  
InductionTaken = 1,InductionBy = @InductionBy,InductionDate = GETDATE()  
where UserId in  (select UserId from #IndexAssociates)  
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_UpdateInduction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UpdateInduction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UpdateInduction] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_UpdateInduction] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_UpdateInduction] TO [DB_DMLSupport]
    AS [dbo];

