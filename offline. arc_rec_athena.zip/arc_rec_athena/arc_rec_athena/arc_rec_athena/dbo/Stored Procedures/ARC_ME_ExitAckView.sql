﻿CREATE procedure ARC_ME_ExitAckView  
     @SupervisorId int,  
     @SearchStr varchar(100) = '',      
     @SearchPattern varchar(4) = '=' /** = or % **/    
  As  
  Begin  
    
  SELECT E.REG_ID as [REG_ID~Hide],E.EMPCODE,E.REASON_ID as [REASON_ID~Hide],(C.FIRSTNAME+' '+C.LASTNAME) AS NAME,  
   CI.CLIENT_NAME as CLIENT,R.REASON AS [REASON TYPE],E.FEEDBACK AS REASON,  
   convert(varchar,E.NOTICE_PERIOD)+' ( '+ convert(varchar,D.NoticePeriod)+' ) ' AS NOTICE,  
   CONVERT(VARCHAR,E.CREATED_DT,106) AS [REQUEST ON],  
   E.OTHER_REASON as [OTHER_REASON~Hide],  
   E.SUPERVISOR_ID AS [APPLIED_TO~Hide],RP.USERID AS [REPORTING_TO~Hide],(U.FIRSTNAME+' '+U.LASTNAME) AS [SUPERVISOR~Hide],  
   '<button onclick="return OpenDialog('+convert(varchar,E.REG_ID)+');" class="Action ui-button ui-widget ui-state-default ui-corner-all ui-button-icon-only" id="btnAckAction" role="button" aria-disabled="false" title="Exit Ack"><span class="ui-button-ico

n-primary ui-icon ui-icon-copy"></span><span class="ui-button-text">Exit Ack</span></button>' as [ACTION]        
   --<button onclick="return OpenDialog('+convert(varchar,E.REG_ID)+');" class="Action ui-button ui-widget ui-state-default ui-corner-all ui-button-icon-only"></button>  
    into #ActView        
   FROM ARC_ME_EXIT E         
   INNER JOIN ARC_ME_EXIT_REASON_INFO R ON R.REASON_ID= E.REASON_ID        
   INNER JOIN ARC_REC_USER_INFO U ON E.SUPERVISOR_ID = U.USERID        
   INNER JOIN ARC_REC_USER_INFO C ON E.CREATED_BY = C.USERID                                    
   LEFT JOIN HR_Designation D ON C.DESIGNATION_ID = D.DesigId                                                             
   LEFT JOIN ARC_REC_CustomerView CI ON C.CLIENT_ID = CI.CLIENT_ID        
   LEFT JOIN ARC_REC_USER_INFO RP ON RP.USERID = (SELECT USERID FROM ARC_REC_USER_INFO R WHERE NT_USERNAME = (SELECT REPORTING_TO FROM ARC_REC_USER_INFO UE WHERE UE.EMPCODE = E.EMPCODE))                                              
   WHERE E.ACTIVE = 'Y' AND E.REG_ID IN ( SELECT REG_ID FROM ARC_ME_EXIT_STATUS_TRAN                                             
   GROUP BY REG_ID HAVING MAX(STATUS_ID) = 0 ) AND ISNULL(E.EMPCODE,'') <> '' AND (E.SUPERVISOR_ID = @SupervisorId OR RP.USERID = @SupervisorId)        
        
  Exec FilterTable      
  @DbName = 'tempdb'      
  ,@TblName = '#ActView'  
  ,@SearchStr = @SearchStr  
  ,@SearchPattern = @SearchPattern  
  ,@OrderStr = ''    
  if OBJECT_ID('tempdb..#ActView') is not null drop table #ActView    
    
  End  


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_ExitAckView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_ExitAckView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_ExitAckView] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_ExitAckView] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_ExitAckView] TO [DB_DMLSupport]
    AS [dbo];

