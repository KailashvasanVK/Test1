﻿CREATE Proc RR_Feedback_Ins        
@Feedback varchar(1000),        
@Userid int        
As        
Begin        
Declare @Associate varchar(60), @msgtext varchar(max)='',@subject varchar(500),
@msgnew varchar(Max),@id int ,@emailid varchar(100),@team varchar(50),@reportingto varchar(100)       
      
if not exists (select top 1 'x' from RR_Feedback where Feedback =@Feedback and Userid=@Userid)        
Begin        
insert into RR_Feedback(Feedback,Userid,CreatedOn)        
select @Feedback,@Userid,GETDATE()        
      
select @Associate=FIRSTNAME+' '+isnull(LASTNAME,''),@emailid=NT_USERNAME+'@accesshealthcare.co',
@reportingto=REPORTING_TO+'@accesshealthcare.co', @team = Client_Name                      
from ARC_REC_USER_INFO UI
inner join ARC_FIN_CLIENT_INFO C on C.CLIENT_ID =UI.Client_Id                     
where USERID =@Userid       
      
      
set @msgtext = '<html xmlns="http://www.w3.org/1999/xhtml" ><head><title>Report</title><style type=text/css><!-- .tableHeader{  font-                       
family: Arial, Verdana, Helvetica, sans-serif; font-size: 12px; font-weight: normal; font-style: normal ;color:#FFF                        
}.tableTxt{  font-family:  Arial, Verdana, Helvetica, sans-serif; font-size: 12px; font-weight: normal; font-style: normal                         
}--></style></head><body><table width="50%"  border=-1 align=center cellpadding=0 cellspacing=1 ><tr class=tableHeader                        
bgcolor=#336799  align=center color=#FFFFFF >                      
 <td colspan="2"><b><font color=#FFFFFF>Reward Feedback</b> </tr></tr>                      
<tr><td width=20%>FeedBack</td><td>'+@Feedback+' </td></tr>                      
<tr><td width=20%>Posted by</td> <td>'+@Associate+'</td> </tr>    
<tr><td width=20%>Email ID</td> <td>'+@emailid+'</td> </tr>    
<tr><td width=20%>Reporting Email ID</td> <td>'+@reportingto+'</td> </tr>  
<tr><td width=20%>Client Name</td> <td>'+@team +'</td> </tr>        
                
</table><table>              
<tr><TD></td></tr>                                     
<tr><TD></td></tr>              
<tr><td>This is a system generated mail. Please do not respond to this mail.</td></tr>            
<tr><TD></td></tr>                                     
<tr><TD></td></tr>            
<TR><B>Legal Disclaimer:</B></TR>            
<tr>The information contained in this message (including all attachments) may be privileged and confidential.             
It is intended to be read only by the individual or entity to whom it is addressed or by their designee.             
If the reader of this message is not the intended recipient, please destroy this message immediately and also please note that you are on notice that any distribution of this message, in any form, is strictly prohibited.            
If you have received this message in error, please immediately notify the sender and delete or destroy any copy of this message!            
</td></tr>                   
</table>'       
      
set @subject='Reward and Recognition Feedback' + ' - ' + @Associate                      
                       
EXEC msdb.dbo.sp_send_dbmail                                                                                                                                    
@profile_name = 'reward',                                                                                                                                                  
@recipients='hepsiba.raj@accesshealthcare.co' ,                          
@blind_copy_recipients ='udhayaganesh.p@accesshealthcare.co',                          
@subject= @subject,                                                                                                                       
@body = @msgtext,                                                                            
@body_format  = 'HTML'        
      
      
Select 'Thank you for your Feedback' as Output        
end        
else        
begin        
Select 'Feedback already exists' as Output        
end        
end
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Feedback_Ins] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Feedback_Ins] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Feedback_Ins] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Feedback_Ins] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Feedback_Ins] TO [DB_DMLSupport]
    AS [dbo];

