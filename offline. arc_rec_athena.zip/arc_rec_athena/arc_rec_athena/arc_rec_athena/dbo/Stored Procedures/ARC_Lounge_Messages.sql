﻿CREATE Procedure ARC_Lounge_Messages                                      
@NT_Username NVarchar(100)=Null ,                                  
@PageIndex int=1,                                                                                       
@PageSize int=5                                  
--@PageCount INT OUTPUT                                     
/*                                      
                                  
 CreatedBy : Udhayaganesh.p                                  
 Purpose   : Get the Respective Comments                                   
                                    
exec ARC_Lounge_Messages @NT_username='varunnair.m',@PageIndex=1,@PageSize=5                          
                      
exec ARC_Lounge_Messages @NT_Username=N'udhayaganesh.p ',@PageIndex=1,@PageSize=10                          
                               
                                      
*/                                                                                       
AS                                    
BEGIN                                  
Declare @RecordCount int ,@maxid int                         
                          
                          
Declare @PageCount int                                  
                                                                                  
Select RowNumber,ID,MsgContent,CreatedBy,Creator,LikeCount,CommentCount,ReportCount,CreatedOn,PROFILE_IMAGE_NAME,                                      
ISNULL(CLIENT_NAME,'') Client,priority,type,msgid,likes,ReportAbuse,CountryFlag into #temp                                      
 from                                       
 ( select ROW_NUMBER() over (order by id desc) RowNumber,* from (                                    
 Select  msg.id,msg.MsgContent,                                      
 msg.CreatedBy,isnull(Ci.FIRSTNAME+' '+ci.LASTNAME,'') +' | ' Creator,                                      
 (select COUNT(distinct ML.LikedBy)  from ARC_Forum_Lounge_Message_Likes_VY ml where ml.MsgId=msg.ID and ml.status=1)'LikeCount',                                        
 (select COUNT(distinct mc.CommentedBy) from ARC_Forum_Lounge_Message_Comments_VY mc where mc.MsgId=msg.ID and mc.Status=1) 'CommentCount',                                    
 (select COUNT(distinct mc.ReportedBy) from ARC_Forum_Lounge_Message_Flags_VY mc where mc.MsgId=msg.ID and mc.Status=1) 'ReportCount',                                                     
 CONVERT(VARCHAR(19),CreatedOn) as CreatedOn ,                                      
 PROFILE_IMAGE_NAME=(case when PROFILE_IMAGE_NAME is not null                                       
 then'../arc_rec/images/candidate/'+PROFILE_IMAGE_NAME else                                      
 '../arc_rec/images/userimg.jpg' end),                                      
 msg.priority,Replace(d.CLIENT_NAME,'Newyork','New York')  CLIENT_NAME,Msg.Type,MSg.Msgid ,                                    
 Likes=isnull((select  COUNT(distinct Ml.LikedBy) from ARC_Forum_Lounge_Message_Likes_VY ML where Ml.MsgId=msg.Id and LikedBy=@NT_username and ml.status=1  ),0),                            
 ReportAbuse= isnull((select COUNT(distinct MF.ReportedBy) from ARC_Forum_Lounge_Message_Flags_VY MF where MF.MsgId=msg.Id and MF.ReportedBy=@NT_username and MF.status=1  ),0),  
 CountryFlag=isnull('../ARC_Lounge/Flag/'+convert(varchar(10),fc.CountryId)+'.png','')  
 from ARC_Forum_Lounge_Messages MSg                                      
 inner join ARC_REC_USER_INFO CI on CI.NT_USERNAME =msg.CreatedBy                                      
 inner join ARC_REC_CANDIDATE CD on CD.REC_ID =ci.REC_ID                                      
 inner join arc_fin_client_info d on  d.CLIENT_ID =ci.CLIENT_ID   
 left join ARC_REC_FootballTeams FT on FT.UserId = CI.USERID    
 left join ARC_REC_FootballCountries FC on FC.CountryId = FT.CountryId and FC.Status=1  
 where MSG.Status=1 and msg.priority=0                                      
union all                                      
 select msg.id,msg.MsgContent  ,'accesshealthcare','accesshealthcare' Creator,                                      
 (select COUNT(distinct ML.LikedBy) from ARC_Forum_Lounge_Message_Likes ml where ml.MsgId=Msg.ID and ml.status=1)'LikeCount',                              
 (select COUNT(distinct mc.CommentedBy) from ARC_Forum_Lounge_Message_Comments mc where mc.MsgId=msg.ID and mc.Status=1) 'CommentCount',                                      
 (select COUNT(distinct mc.ReportedBy) from ARC_Forum_Lounge_Message_Flags mc where mc.MsgId=msg.ID and mc.Status=1) 'ReportCount',                                      
 CONVERT(VARCHAR(19),CreatedOn) as CreatedOn,                                      
 PROFILE_IMAGE_NAME= case when msg.MsgId=0 then  '../arc_forum/ashp.jpg'                 
 else '../arc_forum/ND.jpg' end,                                      
 msg.priority,'',Msg.Type,MSg.Msgid,            
 Likes=isnull((select COUNT(distinct Ml.LikedBy) from ARC_Forum_Lounge_Message_Likes_VY ML             
 where Ml.MsgId=msg.Id and LikedBy=@NT_username and ml.status=1 ),0)                                      
 ,0 ReportAbuse,CountryFlag='' from ARC_Forum_Lounge_Messages msg where  msg.Status =1 and CreatedBy='accesshealthcare'                                                                                
)as udhai ) as ganesh                                                                              
                                      
 --update #temp set CreatedBy='accesshealthcare',Creator='accesshealthcare',                                      
 --PROFILE_IMAGE_NAME = case when MsgId=0 then  '../ARC_REWARDS/images/livefeeds/user1.jpg'                                       
 --else '../ARC_REWARDS/images/livefeeds/user1.jpg'  end where CreatedBy='accesshealthcare'                        
                       
 update #temp set CreatedBy='accesshealthcare',Creator='accesshealthcare',RowNumber =1,                      
 PROFILE_IMAGE_NAME = case when MsgId=0 then  '../arc_forum/ashp.jpg'                       
 else '../arc_forum/ND.jpg' end where CreatedBy='accesshealthcare'          
 and ( priority>=1 or ID=18602)                                      
                                    
  --select * from #temp order by id desc                      
                    
  --select * from #temp where ID=2450                  
                                     
 alter table #temp alter column MsgContent varchar(max)                  
                 
   select @Maxid =isnull(MAX(priority),0)+1 from ARC_Forum_Lounge_Messages                         
                          
 update  #temp set Priority=@Maxid where ID=18602                                    
                                   
                                   
 SELECT @RecordCount = COUNT(*) FROM #temp                                                                     
                                                                             
SET @PageCount = CEILING(CAST(@RecordCount AS DECIMAL(10, 2)) / CAST(@PageSize AS DECIMAL(10, 2)))                                     
                                        
 select RowNumber ,ID, MsgContent, CreatedBy,                                       
 Creator, CreatedOn,LikeCount,CommentCount,ReportCount,PROFILE_IMAGE_NAME, Client, priority,Type,msgid,likes=(case when likes >0 then 1 else 0 end ),                                  
 PostOwner=(case when CreatedBy IN (@NT_username) or @NT_username in (select NTUsername  from ARC_Lounge_Admin) then 1 else 0 end),ReportAbuse,CountryFlag                                    
 from #temp   where  RowNumber BETWEEN(@PageIndex -1) * @PageSize + 1 AND(((@PageIndex -1) * @PageSize + 1) + @PageSize) - 1                                        
 order by priority desc,id desc                                
                                 
 select @PageCount 'PageCount'                                      
                                       
 Drop table #temp                                                   
                             
  End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Messages] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Messages] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Messages] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Messages] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Messages] TO [DB_DMLSupport]
    AS [dbo];

