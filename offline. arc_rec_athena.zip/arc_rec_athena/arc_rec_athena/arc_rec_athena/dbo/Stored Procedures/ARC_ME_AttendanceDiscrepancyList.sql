﻿--ARC_ME_AttendanceDiscrepancyList 828   
CREATE Proc ARC_ME_AttendanceDiscrepancyList            
(            
 @SessionUserId int,          
 @SearchStr varchar(100) = '',                         
 @SearchPattern varchar(4) = '=' /** = or % **/                       
)            
As            
Begin            
--Declare @SessionUserId int = 972            
-- Declare @SearchStr varchar(100) = ''
-- Declare @SearchPattern varchar(4) = '=' /** = or % **/                       
if OBJECT_ID('tempdb..#AttendanceCheckList') is not null drop table #AttendanceCheckList     
--OpenDialog(Attid,OTEligible)      

Declare @TotalHrsChk varchar(25) = (Select CTL_VALUE from ARC_REC_SOFTCONTROL where CTL_ID = 'DISCREPENCY_TOTALHRS_CHK')        
Select '<button onclick="return OpenDialog('+convert(varchar,att.Aid)+','+ CONVERT(varchar,case when TotalHrs > dbo.ShiftDurationInMinutes(att.shift_from,att.shift_to,0) then 1 else 0 end) +');"     
class="Action ui-button ui-widget ui-state-default ui-corner-all ui-button-icon-only" id="btnAckAction" role="button" aria-disabled="false" title="Attendance Mark">          
<span class="ui-button-icon-primary ui-icon ui-icon-copy"></span><span class="ui-button-text">Exit Ack</span></button>' as [ACTION],att.Aid as [Aid~Hide],          
Convert(varchar,att.Date,106) as [Date],ui.EMPCODE [EmpCode],Dbo.ConcatenateName(ui.FIRSTNAME,ui.MIDDLENAME,ui.LASTNAME) as Name            
,att.TotalHrs,att.WorkHours [Worked Hrs],att.LateIn,att.LateOut as AdvanceOut            
,convert(varchar,att.LogOn,100) as [Logged On]            
,convert(varchar,att.LogOut,100) as [Logged Out]            
,desig.Designation            
,shift.SHIFT_NAME as [Shift]            
,att.Userid as [UserId~Hide]            
,dbo.ShiftDurationInMinutes(att.shift_from,att.shift_to,0) as [ShiftHrs~Hide]            
into #AttendanceCheckList            
from ARC_REC_Attendance as att            
inner join ARC_REC_USER_INFO as ui on ui.USERID =att.Userid and ui.ACTIVE = 1 and ui.AHS_PRL = 'Y'             
inner join ARC_REC_USER_INFO as sup on sup.NT_USERNAME = ui.REPORTING_TO and sup.USERID = @SessionUserId            
inner join ARC_REC_SHIFT_INFO as shift on shift.SHIFT_ID = att.Shiftid            
inner join HR_Designation as desig on desig.DesigId = ui.DESIGNATION_ID            
Where att.Date > (select MAX(PAY_ROLL_DATE) from ARC_ME_PAYROLL)            
AND ISNULL(att.Verified_By,0) = 0 and isnull(att.IsDeclaredOff,0) = 0           
AND not exists (Select 1 from ARC_REC_ATTENDANCE_ACCESS where USERID = att.Userid and ATT_TYPE = 'S' and Active = 1)            
and            
(             
isnull(Att.LateIn,0) > 0.15            
or isnull(Att.LateOut,0) > 0.15   
or ( isnull(@TotalHrsChk,'N') = 'Y' and (TotalHrs > dbo.ShiftDurationInMinutes(att.shift_from,att.shift_to,0)))
         
--or TotalHrs > dbo.ShiftDurationInMinutes(att.shift_from,att.shift_to,0)            
)            
and not exists (select 1 from arc_Rec_leave_tran as lt              
  inner join ARC_REC_LEAVE_REQUEST as lr on lr.LEAVE_REQID = lt.LEAVE_REQID and lr.LEAVE_STATUS = 1  and lr.ACTIVE = 'Y'  and (lr.LEAVE_MODE = 'F' or             
  (lr.LEAVE_MODE = 'H' and att.TotalHrs >= (dbo.ShiftDurationInMinutes(att.Shift_from,att.Shift_to,0)/2)))             
  where lt.CREATED_BY = att.Userid and att.Date = lt.LEAVE_DATE                            
  )            
            
--/** Remove permission discrepancies **/            
Delete chk             
from #AttendanceCheckList as chk            
inner join ARC_REC_LEAVE_REQUEST as lr on lr.CREATED_BY = chk.[Userid~Hide] and lr.ACTIVE = 'Y'                                      
   and CONVERT(date,LR.FROMDATE) = chk.[Date] and lr.TYPEID = 5 and LEAVE_STATUS = 1            
Where chk.LateIn <= 2 and chk.AdvanceOut <= 2            
            
Select * into #attchecklistview from #AttendanceCheckList            
Declare @OrderStr varchar(100)                                 
SET @OrderStr  = ' order by [Date] desc'                
                                
Exec FilterTable                          
@DbName = 'tempdb'                          
,@TblName = '#attchecklistview'                          
,@SearchStr = @SearchStr                          
,@SearchPattern = @SearchPattern                          
,@OrderStr = @OrderStr                          
if OBJECT_ID('tempdb..#attchecklistview') is not null drop table #attchecklistview                   
End        
        


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_AttendanceDiscrepancyList] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_AttendanceDiscrepancyList] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_AttendanceDiscrepancyList] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_AttendanceDiscrepancyList] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_AttendanceDiscrepancyList] TO [DB_DMLSupport]
    AS [dbo];

