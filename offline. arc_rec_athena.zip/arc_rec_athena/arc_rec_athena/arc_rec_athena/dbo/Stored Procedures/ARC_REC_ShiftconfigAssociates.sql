﻿--ARC_REC_ShiftconfigAssociates  @CLIENT_ID=0,@SHIFT_ID=1,@ASSOCIATE_ID=0  ,@SUPERVISOR_ID = 972
CREATE procedure ARC_REC_ShiftconfigAssociates              
       @CLIENT_ID int=0,          
       @SHIFT_ID int=0,  
       @SUPERVISOR_ID int = 0,          
       @ASSOCIATE_ID int=0,        
       @SearchStr varchar(100) = '',        
       @SearchPattern varchar(4) = '=' /** = or % **/                       
As              
Begin              
Declare @Qry varchar(max)
if OBJECT_ID('tempdb..#UserprofileAssociatesView') is not null drop table #UserprofileAssociatesView        
Create Table #UserprofileAssociatesView([CheckAll] varchar(max),EMPCODE varchar(20),NAME varchar(100),FunctionName varchar(100) ,REPORTING_TO varchar(100),Designation varchar(100),CLIENT_NAME  varchar(100),SHIFT_NAME varchar(50))Set @Qry =
'
insert into #UserprofileAssociatesView([CheckAll],EMPCODE,NAME,FunctionName,REPORTING_TO,Designation,CLIENT_NAME,SHIFT_NAME)
Select ''<input type="checkbox" style="margin-left: 20px;" class="CheckAll" id="''+convert(varchar,ui.USERID)+''">'' as [CheckAll]
,ui.EMPCODE,ui.FIRSTNAME+'' ''+ui.LASTNAME as NAME,f.FunctionName,ui.REPORTING_TO
,d.Designation,cl.CLIENT_NAME,shiftInfo.Shift_Name
from arc_rec_user_info as ui
left join 
(
Select UserId,Max(TID) TID from ARC_REC_SHIFT_TRAN as shiftTran Group by UserId
) as LastShift on LastShift.UserId = ui.UserId
inner join ARC_REC_SHIFT_TRAN as shiftTran on shiftTran.TID = LastShift.TID
inner join ARC_REC_SHIFT_INFO as shiftInfo on shiftInfo.Shift_Id = shiftTran.Shift_Id ' + Case when ISNULL(@SHIFT_ID,0)  <> 0 then ' and shiftInfo.Shift_Id = ' + CONVERT(varchar,@SHIFT_ID) else '' end + '
inner join HR_Functionality f on ui.FUNCTIONALITY_ID = f.FunctionalityId              
inner join HR_Designation d on ui.DESIGNATION_ID = d.DesigId              
inner join ARC_REC_CustomerView cl on ui.CLIENT_ID = cl.CLIENT_ID
where ui.ACTIVE = 1 and ui.AHS_PRL = ''Y'''
if isnull(@SUPERVISOR_ID,0) <> 0 Set @Qry += ' and ui.REPORTING_TO = (select NT_USERNAME from ARC_REC_USER_INFO where USERID = '+CONVERT(varchar,@SUPERVISOR_ID)+')'
if isnull(@ASSOCIATE_ID,0) <> 0 Set @Qry += ' and ui.USERID = '+CONVERT(varchar,@ASSOCIATE_ID)+''
if isnull(@CLIENT_ID,0) <> 0 Set @Qry += ' and ui.CLIENT_ID = '+Convert(varchar,@CLIENT_ID)+''            
print @qry
Exec (@Qry)
Exec FilterTable        
@DbName = 'tempdb'        
,@TblName = '#UserprofileAssociatesView'        
,@SearchStr = @SearchStr        
,@SearchPattern = @SearchPattern        
,@OrderStr = ' order by NAME'
if OBJECT_ID('tempdb..#UserprofileAssociatesView') is not null drop table #UserprofileAssociatesView        
End 


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ShiftconfigAssociates] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ShiftconfigAssociates] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ShiftconfigAssociates] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_ShiftconfigAssociates] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_ShiftconfigAssociates] TO [DB_DMLSupport]
    AS [dbo];

