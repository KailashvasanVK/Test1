﻿CREATE procedure ARC_Forum_MessageBoard_taggers_INDIA_insert      
(      
@msgId int,      
@ntUserId varchar(75),      
@FacilityType tinyint=1      
)            
as            
begin       
IF @FacilityType=1      
      
Begin      
 insert into Arc_Forum_MessageBoard_Taggedusers(MsgId,NT_userid) values (@msgId,@ntUserId)      
End      
      

          
end
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_taggers_INDIA_insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_taggers_INDIA_insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_taggers_INDIA_insert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_taggers_INDIA_insert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_taggers_INDIA_insert] TO [DB_DMLSupport]
    AS [dbo];

