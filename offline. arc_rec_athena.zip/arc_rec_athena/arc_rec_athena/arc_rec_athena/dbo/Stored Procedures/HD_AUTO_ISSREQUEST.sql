﻿CREATE procedure HD_AUTO_ISSREQUEST              
      @ISSUE_ID INT,              
      @COMMENTS VARCHAR(MAX),              
      @CREATED_BY INT,
      @IRID_RETURN INT=1               
AS              
Begin              
              
              
declare @ISS_REQID int              
declare @CRITICLA_ID int               
declare @DUR_CLOSE int               
declare @DUR_MODE char(1)              
select @CRITICLA_ID = CRITICAL_ID,@DUR_CLOSE = DUR_CLOSE,@DUR_MODE = DUR_MODE from HD_ISSUE_INFO where ISSUE_ID = @ISSUE_ID              
declare @TICKET_ID int              
declare @TICKET_ID_NEW int               
declare @ForwardTo int               
select @ForwardTo =  USERID from ARC_REC_USER_INFO where NT_USERNAME = (select REPORTING_TO from ARC_REC_USER_INFO where USERID  = @CREATED_BY)              
--select @ForwardTo = USERID from ARC_REC_USER_INFO where NT_USERNAME = (select CTL_VALUE from ARC_REC_SOFTCONTROL where CTL_ID = 'Induction_AutoApprovedBy')              
              
IF ISNULL(@TICKET_ID,0) = 0                      
 SELECT @TICKET_ID = ISNULL(MAX(TICKET_ID),0) + 1 FROM HD_ISSUE_REQUEST                      
SET @TICKET_ID_NEW = @TICKET_ID                 
                   
INSERT INTO HD_ISSUE_REQUEST(ISSUE_ID,TICKET_ID,CRITICAL_ID,DUR_CLOSE,DUR_MODE,COMMENTS,CREATED_BY,FORWARD_TO)                      
SELECT @ISSUE_ID,@TICKET_ID,@CRITICLA_ID,@DUR_CLOSE,@DUR_MODE,@COMMENTS              
,@CREATED_BY,@ForwardTo                      
SELECT @ISS_REQID = IDENT_CURRENT('HD_ISSUE_REQUEST')                      
                      
INSERT INTO HD_ISSUE_TRAN(ISS_REQID,ISSUE_STATUS,REMARKS,CREATED_BY)                      
SELECT @ISS_REQID,0,@COMMENTS,@CREATED_BY   -- Iss req raised              
              
INSERT INTO HD_ISSUE_TRAN(ISS_REQID,ISSUE_STATUS,REMARKS,CREATED_BY)                      
SELECT @ISS_REQID,1,'Auto Approved',@ForwardTo  -- Req auto approved              
            
            
 IF OBJECT_ID('TEMPDB..#SupportMailerContent') IS NOT NULL DROP TABLE #SupportMailerContent                      
 CREATE TABLE #SupportMailerContent (IssReqId int,TicketId int,SubjectText varchar(100),BodyMsg varchar(max),CreatedByMailId varchar(200),ForwardMailId varchar(200),DeptMailId varchar(200)              
 ,DeptHeadMailId varchar(200),DeptHeadSupervisorMailId varchar(200),UserName varchar(200),EmpCode varchar(20),              
 RDate date,RedCount int)              
             
insert into #SupportMailerContent(IssReqId,TicketId,SubjectText,BodyMsg,CreatedByMailId,ForwardMailId,DeptMailId,DeptHeadMailId,DeptHeadSupervisorMailId,UserName,              
EmpCode,RDate,RedCount)              
EXEC SP_HD_SELECT_GetMailInfo @ISS_REQID=@ISS_REQID,@Action='TicketRaised'            
            
insert into #SupportMailerContent(IssReqId,TicketId,SubjectText,BodyMsg,CreatedByMailId,ForwardMailId,DeptMailId,DeptHeadMailId,DeptHeadSupervisorMailId,UserName,              
EmpCode,RDate,RedCount)              
EXEC SP_HD_SELECT_GetMailInfo @ISS_REQID=@ISS_REQID,@Action='TicketConfirmation_Approve'            
            
declare @SubjectText as  varchar(200)            
declare @BodyMsg as varchar(max)            
declare @CreatedByMailId varchar(100)            
declare @ForwardMailId varchar(200)            
declare @DeptMailId varchar(200)            
declare @DeptHeadMailId varchar(200)            
declare @DeptHeadSupervisorMailId varchar(200)            
            
Declare SUPPORTMAIL_CURSOR cursor                 
for          
Select SubjectText,BodyMsg,CreatedByMailId,ForwardMailId,DeptMailId,DeptHeadMailId,DeptHeadSupervisorMailId from #SupportMailerContent             
OPEN SUPPORTMAIL_CURSOR               
FETCH NEXT FROM SUPPORTMAIL_CURSOR INTO @SubjectText,@BodyMsg,@CreatedByMailId,@ForwardMailId,@DeptMailId,@DeptHeadMailId,@DeptHeadSupervisorMailId                              
WHILE @@FETCH_STATUS = 0        
BEGIN        
  declare @ToAddress varchar(200)            
  declare @CC varchar(300)          
  set @ToAddress = @CreatedByMailId    
  if(@SubjectText = 'Ticket acknowled in arc.support')            
  set @ToAddress = @CreatedByMailId     
 if(@SubjectText = 'Ticket acknowledged in arc.support') -- KARTHIK ADDED    
 set @ToAddress = @CreatedByMailId                   
 if(@SubjectText = 'Ticket raised in arc.support')            
  set @ToAddress = @ForwardMailId            
  if(@SubjectText = 'Ticket confirmation')       -- KARTHIK ADDED    
  set @ToAddress = @CreatedByMailId    
 if(@SubjectText = 'Ticket Escalation – Level 3')            
 begin    
  set @ToAddress = @DeptHeadMailId            
  set @CC = @DeptHeadSupervisorMailId            
 end                  
              
 INSERT INTO ARC_REC_MAIL_TRAN(FROM_MAILID,RECIPIENTS,SUBJECT_TEXT,BODY,ISHTML,CC)                    
 select 'mail.support@accesshealthcare.co',@ToAddress,@SubjectText,@BodyMsg,'Y',@CC            
           
 FETCH NEXT FROM SUPPORTMAIL_CURSOR INTO @SubjectText,@BodyMsg,@CreatedByMailId,@ForwardMailId,@DeptMailId,@DeptHeadMailId,@DeptHeadSupervisorMailId                
        
        
END        
        
DEALLOCATE SUPPORTMAIL_CURSOR       
           if(@IRID_RETURN = 1)        
				select @ISS_REQID as IssReqId             
              
END
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_AUTO_ISSREQUEST] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_AUTO_ISSREQUEST] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_AUTO_ISSREQUEST] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HD_AUTO_ISSREQUEST] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HD_AUTO_ISSREQUEST] TO [DB_DMLSupport]
    AS [dbo];

