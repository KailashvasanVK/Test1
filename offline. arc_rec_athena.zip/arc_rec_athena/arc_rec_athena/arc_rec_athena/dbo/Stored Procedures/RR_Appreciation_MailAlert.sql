﻿CREATE Proc RR_Appreciation_MailAlert    
@Appid int,    
@userid int    
As    
Begin    
DECLARE @xml VARCHAR(MAX)                      
DECLARE @body VARCHAR(MAX)     
    
declare @Tomailid varchar(100),@FromName varchar(100),@toName varchar(100)    
    
set @Tomailid =(select top 1 REPORTING_TO+'@accesshealthcare.co' from ARC_REC_USER_INFO_VY where Userid=@userid)    
    
set @FromName =(select Associate   from ARC_REC_USER_INFO_VY where Userid=@userid)    
    
set @toName =(select Associate from  ARC_REC_USER_INFO_VY where Nt_username= (select top 1 REPORTING_TO from ARC_REC_USER_INFO_VY where Userid=@userid))    
        
SET @xml = CAST((select ROW_NUMBER() over (order by Empcode) AS 'td',''      
,Associate AS 'td',''      
,Designation  AS 'td',''       
,FunctionName  AS 'td',''       
,client_name  AS 'td'     
      
from RR_Appreciation_Users AU    
inner join ARC_REC_USER_INFO_VY V on v.NT_UserName=AU.NT_USERNAME      
where appid=@Appid       
FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))     
    
    
SET @body ='<html><body>                      
<style type=text/css>                                                                                                                                     
<!-- .tableHeader{  font-family: Calibri(bold); font-size: 12px; font-weight: normal; font-style: normal ;color:#FFF }                                                                                                             
                        
.tableTxt{  font-family: Calibri(bold); font-size: 16px; font-weight: normal; font-style: normal  }-->                      
</style>                       
                     
<table>                       
<tr><td   class=tableTxt>Dear '+@toName +',</td> </tr> </br>                              
<tr >                      
<td  class=tableTxt>The following associate(s) have been nominated in arc.rewards. Please <a href="https://arc.accesshealthcare.co/ARC_REWARD/RewardApprove.aspx">click here</a> to process this request.<td></tr>                      
<tr><TD></td></tr></table></br>      
    
<table width="70%"  border=-1 align=center cellpadding=0 cellspacing=1 >                      
<tr class=tableHeader bgcolor=#2567aa  align=center color=#FFFFFF><td style="padding:5px"><b>Sl.No</b></font></td>                       
<td style="padding:5px"><b> Associate </b></td><td style="padding:5px"><b> Designation</b> </td><td style="padding:5px"><b> Department</b> </td><td style="padding:5px"><b> Client</b></td>                      
'    
    
SET @body = @body + @xml +'</table width="100%" ></br>                      
<table>              
<tr><td>&nbsp;</td> </tr>                    
<tr><td>Warm Regards,</td> </tr>        
<tr><td>'+@FromName+'</td> </tr>         
<tr><TD></td></tr>                                   
<tr><TD></td></tr>            
<tr><td>This is a system generated mail. Please do not respond to this mail.</td></tr>          
<tr><TD></td></tr>                                   
<tr><TD></td></tr>          
<TR><B>Legal Disclaimer:</B></TR>          
<tr>The information contained in this message (including all attachments) may be privileged and confidential.           
It is intended to be read only by the individual or entity to whom it is addressed or by their designee.           
If the reader of this message is not the intended recipient, please destroy this message immediately and also please note that you are on notice that any distribution of this message, in any form, is strictly prohibited.          
If you have received this message in error, please immediately notify the sender and delete or destroy any copy of this message!          
</td></tr>'                  
if len(@body)>50  
begin             
EXEC msdb.dbo.sp_send_dbmail                                                                                                                                                                                                     
@profile_name = 'Reward',                                                     
@recipients=@Tomailid ,        
@blind_copy_recipients ='udhayaganesh.p@accesshealthcare.co' ,                                                     
@subject='arc.reward',                                                 
@body = @body,                                                     
@body_format  = 'HTML'      
End   
End    
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Appreciation_MailAlert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Appreciation_MailAlert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Appreciation_MailAlert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_Appreciation_MailAlert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_Appreciation_MailAlert] TO [DB_DMLSupport]
    AS [dbo];

