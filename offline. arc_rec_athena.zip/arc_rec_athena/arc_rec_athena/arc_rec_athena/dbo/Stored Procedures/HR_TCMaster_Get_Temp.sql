﻿    
    
CREATE PROCEDURE  [dbo].[HR_TCMaster_Get_Temp]     
as      
begin      
 SELECT  TCId, facility TrainingCentre from HR_FacilityMaster where status=1  
   
      
end      
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_TCMaster_Get_Temp] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_TCMaster_Get_Temp] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_TCMaster_Get_Temp] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_TCMaster_Get_Temp] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_TCMaster_Get_Temp] TO [DB_DMLSupport]
    AS [dbo];

