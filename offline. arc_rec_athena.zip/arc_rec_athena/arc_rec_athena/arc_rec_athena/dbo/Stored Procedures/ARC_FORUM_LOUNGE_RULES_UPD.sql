﻿CREATE Proc ARC_FORUM_LOUNGE_RULES_UPD      
(      
@HID INT,      
@CONTENT VARCHAR(1000),      
@STATUS TINYINT=1,    
@ERROR varchar(50) OUT     
)      
as        
/*      
ARC_FORUM_LOUNGE_RULES_UPD @CONTENT='test78',@STATUS=1,@HID=1      
*/      
begin      
SET NOCOUNT ON;    
IF NOT EXISTS(select * from ARC_FORUM_LOUNGE_HIGHlIGHT WHERE Content = @CONTENT AND Hid != @HID)     
BEGIN    
UPDATE ARC_FORUM_LOUNGE_HIGHlIGHT SET Content=@CONTENT,Status=@STATUS,UpdatedOn=GETDATE() WHERE Hid=@HID      
SET @ERROR='Rules Updated Successfully'    
End    
ELSE    
BEGIN    
SET @ERROR='Rules already Exists'    
END    
END 

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FORUM_LOUNGE_RULES_UPD] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_LOUNGE_RULES_UPD] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_LOUNGE_RULES_UPD] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_FORUM_LOUNGE_RULES_UPD] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_FORUM_LOUNGE_RULES_UPD] TO [DB_DMLSupport]
    AS [dbo];

