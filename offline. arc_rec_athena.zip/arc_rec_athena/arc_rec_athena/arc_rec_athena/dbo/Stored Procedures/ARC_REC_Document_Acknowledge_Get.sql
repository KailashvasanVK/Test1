﻿CREATE Proc ARC_REC_Document_Acknowledge_Get        
@userid int=807,            
@type int=2           
As          
/*        
        
ARC_REC_Document_Acknowledge_Get @userid=977,@type=1      
    
        
*/            
Begin        
            
select ld.DocID,ld.DocumentName,isnull(ui.FIRSTNAME,'') +' '+isnull(ui.LASTNAME,'') DocCreatedBy,         
ld.CreatedBy,da.AcknowledgeBy,CONVERT(varchar(10),da.AcknowledgeOn,103)        
Acknowledged,[Type]=(case when AcknowledgeBy IS null then 0 else 1 end),convert(varchar(10),ld.CreatedOn,103)CreatedOn    
from ARC_REC_LegalDocument ld         
left join ARC_REC_Document_Acknowledge da on ld.DocID=da.Docid and AcknowledgeBy=@userid        
inner join ARC_REC_USER_INFO ui on ui.USERID=ld.CreatedBy        
             
end   
  
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_Document_Acknowledge_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Document_Acknowledge_Get] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Document_Acknowledge_Get] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_Document_Acknowledge_Get] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Document_Acknowledge_Get] TO [DB_DMLSupport]
    AS [dbo];

