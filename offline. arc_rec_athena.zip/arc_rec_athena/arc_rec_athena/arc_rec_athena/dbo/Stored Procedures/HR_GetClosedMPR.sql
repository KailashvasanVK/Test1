﻿   CREATE procedure [dbo].[HR_GetClosedMPR]          
---------------------------------------------------------------------------------------          
--Created By : udhayaganesh          
       
---------------------------------------------------------------------------------------           
 @MPRId INT          
          
AS          
          
BEGIN          
          
SELECT            
 mpr.MPRId as [OPAL Id],          
 convert(varchar(25), mpr.CreatedDate, 107) as 'Raisedon',          
 um.UserName, tm.Facility TrainingCentre, f.FunctionName, d.Designation,           
 convert(varchar(25), mpr.ExpDate, 107) as 'ExpDate',          
 (select isnull(sum(PositionsClosed), 0) from HR_MPRClosedetails where mprid = mpr.mprid)  as [Selected],          
 ((mpr.TotalPositions) -          
 (select isnull(sum(PositionsClosed),0) from HR_MPRClosedetails where mprid = mpr.mprid)) as [Pending],          
-- em.MailId, em.MailDomain,           
 mpr.MPRId, mpr.TCId, mpr.DesigId, mpr.FunctionalityId, mpr.TotalPositions, mpr.SalaryMax, mpr.SalaryMin, mpr.ExpDate, mpr.Skillset        
, mpr.Qualification, mpr.NatureofWork, mpr.TargetIndustry, mpr.Reason, mpr.CreatedBy, mpr.CreatedDate, mpr.ApprovalStatus        
, mpr.ApprovedBy, mpr.ApprovedDate, mpr.MPRStatus, mpr.PositionsClosed, mpr.ClosedBy, mpr.ClosedDate, mpr.MPRStatusDate        
, mpr.experience, mpr.approvalcomments        
FROM           
 HR_MPR mpr INNER JOIN HR_functionality f on f.FunctionalityId = mpr.FunctionalityId          
 INNER JOIN HR_designation d on d.desigId = mpr.desigID          
 INNER JOIN HR_FacilityMaster tm on tm.Tcid = mpr.Tcid          
 INNER JOIN mrplogin um on um.UserId = mpr.CreatedBy           
-- INNER JOIN HR_EmpMaster em on em.Empid = um.EmpId           
 where mpr.MPRId = @MPRId          
          
          
 SELECT           
          
  mpr.PositionsClosed as [Closed],          
 CASE           
   WHEN len(mpr.Comments) > 50 THEN (left(mpr.Comments, 50) + '...' )          
   WHEN len(mpr.Comments) <= 50 THEN mpr.Comments           
 END AS [Comments],          
          
          
  um.Username as [Closed by] ,          
  convert(varchar(25), mpr.CreatedDate, 107) as [Closed on]  ,        
  mpr.CreatedDate as [Closed_sort]          
          
 FROM           
  HR_MPRCloseDetails mpr LEFT JOIN mrplogin um on um.UserId = mpr.CreatedBy          
 WHERE           
  mpr.MPRId = @MPRId          
          
 GROUP BY           
          
  mpr.mprid,          
  mpr.PositionsClosed,          
  mpr.Comments,          
  um.Username,          
  mpr.CreatedDate,          
  mpr.PositionsClosed          
          
order by           
          
   mpr.CreatedDate          
          
END          
        
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_GetClosedMPR] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_GetClosedMPR] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_GetClosedMPR] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_GetClosedMPR] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_GetClosedMPR] TO [DB_DMLSupport]
    AS [dbo];

