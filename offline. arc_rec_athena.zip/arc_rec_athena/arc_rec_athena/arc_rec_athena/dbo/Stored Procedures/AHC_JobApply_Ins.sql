﻿CREATE Proc AHC_JobApply_Ins                                           
@Name Varchar(30)=Null,                                              
@EmailId Varchar(50) =Null,                                              
@Mobile Varchar(50) =Null,                                              
@VANIP Varchar(20) =Null,                                              
@HostIP Varchar(20) =Null,                                              
@FBName Varchar(100)=Null ,                                              
@Position varchar(50)=null,                                          
@FBUserId varchar(100)=null,                                          
@FBEmailId varchar(250)=null,                                          
@FBLike int=1                                          
AS                                              
/*                                              
                                              
Created By : UdhayaGanesh P                                              
Created On : 11th Sep 2012                                              
Purpose    : Apply job in FaceBook Application                                              
                                              
AHC_JobApply_Ins @Name='udhayaganeshp',@EmailId='vigoudhaya@gmail.com',                                              
             @Mobile='9884722558',@VANIP='172.17.4.240',@HostIP='172.17.3.100',@FBName='Udhayaganesh Pachiyappan',@Position='A1',                                          
             @FBUserId='100000073922681',@FBEmailId='vigoudhaya@gmail.com',                                              
              @FBLike=1                                            
                                                         
Truncate table AHC_JobApply                               
truncate table AHC_jobrefer                              
                              
select * from AHC_jobrefer                                    
truncate table AHC_AppLikeUsers                               
                              
select * from  AHC_AppLikeUsers order by alid                                       
                                              
*/                                              
                                              
Begin                                              
                                              
Declare @Applyno Varchar(20)='',@temp Varchar(20)='',@Applyid int=0,@msgnew varchar(max)='',                                    
@header varchar(1000)='Job Apply' ,@designation varchar(100),@tomailid varchar(200) ='',@msgnew1 varchar(max)=''                                        
                                    
set  @tomailid=@EmailId+';'+@FBEmailId                            
                      
                      
if not exists(select 'x' from AHC_AppLikeUsers where Userid=@FBUserId and status=1 and @FBUserId is not null)                            
begin                            
Insert into AHC_AppLikeUsers                           
(UserId,UserName,UserEmailId,Status)                             
values (@FBUserId,@FBName,@FBEmailId,1)                          
                        
end                                 
                                              
                                             
If not exists(select 'x' from AHC_JobApply where EmailId =@EmailId and Position =@Position and CONVERT(date,CreatedOn)>=GETDATE()-90)                                              
begin                                    
                              
exec SP_INS_ARC_REC_CANDIDATE @Name,@Mobile,1,@Applyno output                                 
                            
if @Position is null                            
set @Position ='imgApply4'                            
                                 
                                           
Insert into  AHC_JobApply(Name,ApplyNo,EmailId,Mobile,VANIP,HostIP,FBName,Position,FBUserId,FBEmaiId,FBLike)                                               
select @Name,@Applyno,@EmailId,@Mobile,@VANIP,@HostIP,@FBName,@Position,@FBUserId,@FBEmailId,@FBLike                     
                    
                  
insert into ARC_REC_APPLICANT_STATUS_FB(REC_ID,CREATED_DT,STATUS_ID)                    
select @Applyno,GETDATE(),11                                       
                                                    
                                              
select 'Thank you for apply, Your Apply Number : '+ @Applyno  as Output                                               
select @Applyno as 'FileName'                                  
                                    
if @Position ='imgApply1'                                    
begin                                    
set @designation ='Billing Executive'                                    
end                                    
else if @Position ='imgApply2'                                    
Begin                                   
set @designation ='Revenue Cycle Executive'                                    
                                    
end                                    
else if @Position ='imgApply3'                                    
                                    
begin                                    
set @designation ='Coding Executive (Specialized in Radiology / ER / Hospital coding)'                                    
                                    
end                              
else if @Position ='imgApply4'                            
                                    
begin                                    
set @designation ='General'                                    
                              
end                                   
                                    
If @Applyno !='' and @Position is not null                                    
begin                                    
set @msgnew = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">'                                                                               
SET @msgnew = @msgnew + '<html xmlns="http://www.w3.org/1999/xhtml" >'                                                                                                                      
SET @msgnew = @msgnew + '<head>'                                                                                                                                                                        
SET @msgnew = @msgnew + '<title>Report</title>'                                                                                                                              
SET @msgnew = @msgnew + '<style type=text/css>'                                                                                                                                                                    
SET @msgnew = @msgnew + '<!-- .tableHeader{  font-family: Arial, Verdana, Helvetica, sans-serif; font-size: 12px; font-weight: normal; font-style: normal ;color:#FFF }'                                                                                       
  
    
     
        
           
           
              
                 
                  
SET @msgnew = @msgnew + '.tableTxt{ font-family:  Arial, Verdana, Helvetica, sans-serif; font-size: 12px; font-weight: normal; font-style: normal  }-->'                                              
SET @msgnew = @msgnew + '</style>'                                                                                                                                      
SET @msgnew = @msgnew + '</head>'                                                                                                                                                
SET @msgnew = @msgnew + '<body>'                                                                
SET @msgnew = @msgnew + '<table>'                                                                                                       
SET @msgnew = @msgnew + '<tr> Hi,'                   
SET @msgnew = @msgnew + '<tr><td>&nbsp;</td> </tr>'                                                                                                                                                              SET @msgnew = @msgnew + '<tr>                
   
                   
                                    
Thank you for your interest in the [ '+@designation+' ] position at Access Healthcare. We appreciate you taking the                   
time to apply for this position.                                    
Your recruitment ID is [ '+@Applyno+' ].</tr>                                    
 <tr> Should your application be shortlisted for this position, please use this recruitment ID  [ '+@Applyno+' ].                                    
  for the recruitment process. </tr>                                    
  <tr><tr><td>&nbsp;</td> </tr>                                     
  <tr><td>&nbsp;</td> </tr>                
To know more about our company, please visit http://www.accesshealthcare.co/ .</tr>'                                    
                                                                                                                   
                    
                                        
                                             
SET @msgnew = @msgnew + '</tr>'                                           
SET @msgnew = @msgnew + '<tr><td>&nbsp;</td> </tr>'                                           
SET @msgnew = @msgnew + '<tr><td>Warm Regards,</td> </tr>'                                           
SET @msgnew = @msgnew + '<tr><td>Access Healthcare</td> </tr>   
<tr><TD></td></tr>                           
<tr><TD></td></tr>    
<tr><td>This is a system generated mail. Please do not respond to this mail.</td></tr>  
<tr><TD></td></tr>                           
<tr><TD></td></tr>  
<TR><B>Legal Disclaimer:</B></TR>  
<tr>The information contained in this message (including all attachments) may be privileged and confidential.   
It is intended to be read only by the individual or entity to whom it is addressed or by their designee.   
If the reader of this message is not the intended recipient, please destroy this message immediately and also please note that you are on notice that any distribution of this message, in any form, is strictly prohibited.  
If you have received this message in error, please immediately notify the sender and delete or destroy any copy of this message!  
</td></tr>'                                           
set @msgnew=@msgnew+'</table></body></html>'                       
                  
                  
set @msgnew1 = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">'                                                                               
SET @msgnew1 = @msgnew1 + '<html xmlns="http://www.w3.org/1999/xhtml" >'                                                                                               
SET @msgnew1 = @msgnew1 + '<head>'                                                                                                                                                                        
SET @msgnew1 = @msgnew1 + '<title>Report</title>'                                                                                                                              
SET @msgnew1 = @msgnew1 + '<style type=text/css>'                                                                                                                                                                    
SET @msgnew1 = @msgnew1 + '<!-- .tableHeader{  font-family: Arial, Verdana, Helvetica, sans-serif; font-size: 12px; font-weight: normal; font-style: normal ;color:#FFF }'                                                                                     
  
   
       
       
           
            
              
               
                     
SET @msgnew1 = @msgnew1 + '.tableTxt{ font-family:  Arial, Verdana, Helvetica, sans-serif; font-size: 12px; font-weight: normal; font-style: normal  }-->'                                              
SET @msgnew1 = @msgnew1 + '</style>'                                                                                                                                      
SET @msgnew1 = @msgnew1 + '</head>'                                                                                                                                                
SET @msgnew1 = @msgnew1 + '<body>'                                                                
SET @msgnew1 = @msgnew1 + '<table>'                                                                                                       
SET @msgnew1 = @msgnew1 + '<tr> Hi,'                                     
SET @msgnew1 = @msgnew1 + '<tr><td></td> </tr>'                                                                                                                                                                
SET @msgnew1 = @msgnew1 + '<tr>                                    
 '+@FBName+' has applied for '+@designation +' at Accesshealthcare. The details are as below: </tr>                                    
  <tr><tr><td></td> </tr>                      
    <tr><tr><td>Name : '+ @Name   +'</td> </tr>                                     
  <tr><tr><td></td> </tr>                                     
  <tr><tr><td>Mobile Number : '+ @Mobile  +'</td> </tr>                   
  <tr><td></td> </tr>                  
  <tr><tr><td>Email ID : '+ @EmailId   +'</td> </tr>                   
  <tr><td></td> </tr>                  
  '                                             
                                             
SET @msgnew1 = @msgnew1 + '</tr>'                                           
SET @msgnew1 = @msgnew1 + '<tr><td></td> </tr>'                                           
SET @msgnew1 = @msgnew1 + '<tr><td>Regards,</td> </tr>'                                           
SET @msgnew1 = @msgnew1 + '<tr><td>Refer and Win</td> </tr>       
<tr><TD></td></tr>                           
<tr><TD></td></tr>    
<tr><td>This is a system generated mail. Please do not respond to this mail.</td></tr>  
<tr><TD></td></tr>                           
<tr><TD></td></tr>  
<TR><B>Legal Disclaimer:</B></TR>  
<tr>The information contained in this message (including all attachments) may be privileged and confidential.   
It is intended to be read only by the individual or entity to whom it is addressed or by their designee.   
If the reader of this message is not the intended recipient, please destroy this message immediately and also please note that you are on notice that any distribution of this message, in any form, is strictly prohibited.  
If you have received this message in error, please immediately notify the sender and delete or destroy any copy of this message!  
</td></tr>'                                        
set @msgnew1=@msgnew1+'</table></body></html>'                                 
                       
                                    
EXEC msdb.dbo.sp_send_dbmail                                                                                                                                                                                           
@profile_name = 'ARC_DBmail',                                           
@recipients=@tomailid,                                           
@subject=@header ,                                       
@body = @msgnew,                                           
@body_format  = 'HTML'                      
                  
EXEC msdb.dbo.sp_send_dbmail                                                                                                                                                                                           
@profile_name = 'ARC_DBmail',                                           
@recipients='hr@accesshealthcare.co',                                           
@copy_recipients='hepsiba.raj@accesshealthcare.co',        
@blind_copy_recipients='udhayaganesh.p@accesshealthcare.co',                                  
@subject=@header ,                                       
@body = @msgnew1 ,                                           
@body_format  = 'HTML'                                   
                                    
end                                          
                                      
End                                              
else                                              
Begin                                           
                                              
select 'You applied as on : ' + convert(varchar(15),CreatedOn,110) +'. Same position you can apply after 3 month.' as Output from AHC_JobApply where EmailId =@EmailId                                              
 and Position =@Position                                          
                                         
 Select 0 as 'FileName'                                            
                                              
End                                              
                                              
end 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AHC_JobApply_Ins] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHC_JobApply_Ins] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHC_JobApply_Ins] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AHC_JobApply_Ins] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHC_JobApply_Ins] TO [DB_DMLSupport]
    AS [dbo];

