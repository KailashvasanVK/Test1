﻿CREATE Procedure ARC_UserCustomerAction
@Userid  int,
@Action   varchar(75)
as
/*  
Created by : Karthik Ic
Created on : 03 May 2013.
Impact to  : UserCustomer.aspx
*/
Begin
if @Action  = 'ARC_UserWiseCustomerGet'
-- Purpose : To get Customer details based on user id  --
Begin
Select CustomerID,UserId From ARC_REC_UserCustomer Where UserId = @Userid
order by UCId
End
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_UserCustomerAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_UserCustomerAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_UserCustomerAction] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_UserCustomerAction] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_UserCustomerAction] TO [DB_DMLSupport]
    AS [dbo];

