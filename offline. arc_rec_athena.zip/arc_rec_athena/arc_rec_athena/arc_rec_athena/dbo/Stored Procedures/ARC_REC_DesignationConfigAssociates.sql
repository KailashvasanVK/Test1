﻿--ARC_REC_DesignationConfigAssociates @FunctionalityID=16,@ClientID=15,@DesignationID=0,@AssociateID=638
CREATE procedure ARC_REC_DesignationConfigAssociates            
	@FunctionalityID int=0,        
	@ClientID int=0,        
	@DesignationID int=0,        
	@AssociateID int=0,      
	@SearchStr varchar(100) = '',      
	@SearchPattern varchar(4) = '=' /** = or % **/
As            
Begin            

if OBJECT_ID('tempdb..#AssociatesView') is not null drop table #AssociatesView      
Create Table #AssociatesView([CheckAll] varchar(max),EMPCODE varchar(20),NAME varchar(100),
FunctionName varchar(100) ,REPORTING_TO varchar(100),Designation varchar(100),CLIENT_NAME  varchar(100)
)                     
declare @qry as varchar(max)

set @qry = 'insert into #AssociatesView([CheckAll],EMPCODE,NAME,FunctionName,REPORTING_TO,Designation,CLIENT_NAME)
select x.[CheckAll],x.EMPCODE,x.NAME,x.FunctionName,x.REPORTING_TO,x.Designation,x.CLIENT_NAME       
from (        
select ''<input type="checkbox" style="margin-left: 20px;" class="CheckAll" id="''+convert(varchar,ui.REC_ID)+''" >'' as [CheckAll],        
ui.EMPCODE,ui.FIRSTNAME +'' ''+ ui.LASTNAME as NAME,f.FunctionName,ui.REPORTING_TO,          
d.Designation,cl.CLIENT_NAME
from ARC_REC_USER_INFO ui            
left join HR_Functionality f on ui.FUNCTIONALITY_ID = f.FunctionalityId            
left join HR_Designation d on ui.DESIGNATION_ID = d.DesigId            
left join ARC_FIN_CLIENT_INFO cl on ui.CLIENT_ID = cl.CLIENT_ID            
where ui.AHS_PRL = ''Y'' and ui.ACTIVE = 1'

if @AssociateID  > 0 
	set @qry += ' and ui.USERID = '+CONVERT(varchar,@AssociateID)+')x order by x.NAME'     
else
begin	
if @FunctionalityID > 0
 set @qry += ' and ui.FUNCTIONALITY_ID = '+CONVERT(varchar,@FunctionalityID)           
if @ClientID > 0      
 set @qry += ' and ui.CLIENT_ID = '+CONVERT(varchar,@ClientID)                      
if @DesignationID > 0
 set @qry = @qry + 'and ui.DESIGNATION_ID = '+CONVERT(varchar,@DesignationID)  
 SET @qry  += ' )x order by x.NAME' 
end 
            
print(@qry)                
exec(@qry)        
Declare @OrderStr varchar(100)        
set @OrderStr=''
Exec FilterTable      
@DbName = 'tempdb'      
,@TblName = '#AssociatesView'      
,@SearchStr = @SearchStr      
,@SearchPattern = @SearchPattern      
,@OrderStr = @OrderStr      
if OBJECT_ID('tempdb..#AssociatesView') is not null drop table #AssociatesView      
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_DesignationConfigAssociates] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_DesignationConfigAssociates] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_DesignationConfigAssociates] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_DesignationConfigAssociates] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_DesignationConfigAssociates] TO [DB_DMLSupport]
    AS [dbo];

