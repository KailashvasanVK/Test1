﻿--ARC_ME_Manila_PeternityLeaves 846,'12/12/2013'  
CREATE PROCEDURE ARC_ME_PeternityLeaves          
      @UserId int,@FROM_DATE DATE     -- We have using only for manila source         
As              
BEGIN           
Declare @ShiftId int    
select @ShiftId = ISNULL(( SELECT TOP 1 SI.SHIFT_ID FROM ARC_REC_SHIFT_TRAN T                                  
LEFT JOIN ARC_REC_SHIFT_INFO SI ON T.SHIFT_ID = SI.SHIFT_ID                                   
WHERE T.USERID = @UserId ORDER BY T.CREATED_DT DESC),'')    
    
declare @IsSaturdayOff as char(1)    
Select @IsSaturdayOff = SatOffEligible from ARC_REC_SHIFT_INFO where SHIFT_ID = @ShiftId        
  
   
 --select @IsSaturdayOff  
   
DECLARE @toDate date    
DECLARE @daysAdded integer    
declare @daysToAdd int      
set @daysToAdd = 6 -- 7 working days for Paternity   
-- add the days, ignoring weekends (i.e. add working days)  -- to get working days  
set @daysAdded = 1    
set @toDate = @FROM_DATE  
--select @IsSaturdayOff  
if(@IsSaturdayOff = 'Y')  
begin  
while @daysAdded <= @daysToAdd    
begin    
    -- add a day to the to date    
    set @toDate = DateAdd(day, 1, @toDate)    
    -- only move on a day if we've hit a week day    
    if (DatePart(dw, @toDate) != 1) and (DatePart(dw, @toDate) != 7)    
    begin    
        set @daysAdded = @daysAdded + 1    
    end    
     
end   
end  
else  
begin  
while @daysAdded <= @daysToAdd    
begin    
    -- add a day to the to date    
    set @toDate = DateAdd(day, 1, @toDate)    
    -- only move on a day if we've hit a week day    
     
    if(DatePart(dw, @toDate) != 1)  
    begin  
  set @daysAdded = @daysAdded + 1    
    end  
end   
end  
  
SELECT REPLACE(CONVERT(VARCHAR, @FROM_DATE,106), ' ', '-') AS FROM_DATE,REPLACE(CONVERT(VARCHAR, @toDate, 106), ' ', '-') AS TO_DATE,'5' AS EMERGENCY_LEAVE            
  -- decide later whether its caesarien delivery or normal. if Ceasarien means it will be 78 calander days.        
END   
  
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_PeternityLeaves] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_PeternityLeaves] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_PeternityLeaves] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_ME_PeternityLeaves] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_ME_PeternityLeaves] TO [DB_DMLSupport]
    AS [dbo];

