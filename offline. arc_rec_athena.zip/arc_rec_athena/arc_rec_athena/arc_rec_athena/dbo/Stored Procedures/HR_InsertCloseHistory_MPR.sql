﻿    
CREATE Procedure [dbo].[HR_InsertCloseHistory_MPR]      
---------------------------------------------------------------------------------------      
--Created By : udhayaganesh      
---------------------------------------------------------------------------------------       
      
@MPRId INT,      
@PositionsClosed  INT,      
@Comments varchar(200),      
@CreatedBy  INT    
    
AS       
BEGIN      
    
BEGIN TRANSACTION    
    
 DECLARE @Toclose INT    
    
 BEGIN TRY    
    
  SELECT @Toclose = (a.TotalPositions -  isnull(sum(b.PositionsClosed),0))  from       
        
  HR_MPR a left join HR_MPRClosedetails b on b.mprid = a.mprid where a.mprid = @MPRId      
        
  group by a.mprid, a.TotalPositions      
    
    
  IF @Toclose >= @PositionsClosed    
  BEGIN      
    
  INSERT INTO HR_MPRCloseDetails       
    
  (      
   MPRId,      
   PositionsClosed,      
   Comments,      
   CreatedBy,      
   CreatedDate      
  )      
    
  VALUES      
  (      
   @MPRId,      
   @PositionsClosed,      
   @Comments,      
   @CreatedBy,      
   getdate()  
  )      
    
  Declare @Pending INT, @Status INT      
      
  select @Pending = (a.TotalPositions -  sum(b.PositionsClosed)) from       
      
  HR_MPR a inner join HR_MPRClosedetails b on b.mprid = a.mprid where a.mprid = @MPRId      
      
  group by a.mprid, a.TotalPositions      
      
  IF @Pending <= 0       
  BEGIN      
   Update HR_MPR set MPRStatus = 1, MPRStatusDate =  getdate() where MPRId = @MPRId      
  END      
  SELECT 'Saved successfully!'    
      
  END    
 ELSE    
  BEGIN    
   SELECT 'Insert failed! Number of positions free :' +  convert(varchar(10), @Toclose)    
  END    
    
    
COMMIT TRANSACTION    
END TRY    
BEGIN CATCH    
    
    
 if @@TRANCOUNT > 0    
    begin    
     rollback transaction    
       DECLARE     
        @ErrorMessage    NVARCHAR(4000),    
        @ErrorNumber     INT,    
        @ErrorSeverity   INT,    
        @ErrorState      INT,    
        @ErrorLine       INT,    
        @ErrorProcedure  NVARCHAR(200);    
    
       -- Assign variables to error-handling functions that     
       -- capture information for RAISERROR.    
       SELECT     
         @ErrorNumber = ERROR_NUMBER(),    
         @ErrorSeverity = ERROR_SEVERITY(),    
         @ErrorState = ERROR_STATE(),    
         @ErrorLine = ERROR_LINE(),    
         @ErrorProcedure = ISNULL(ERROR_PROCEDURE(), '-');    
    
      SELECT @ErrorMessage =     
          N'Error %d, Level %d, State %d, Procedure %s, Line %d, ' +     
          'Message: '+ ERROR_MESSAGE();    
    
       -- Raise an error: msg_str parameter of RAISERROR will contain    
       -- the original error information.    
      RAISERROR     
          (    
          @ErrorMessage,     
          @ErrorSeverity,     
          1,                   
          @ErrorNumber,    -- parameter: original error number.    
          @ErrorSeverity,  -- parameter: original error severity.    
          @ErrorState,     -- parameter: original error state.    
          @ErrorProcedure, -- parameter: original error procedure name.    
          @ErrorLine       -- parameter: original error line number.    
          );    
    
    end    
    
END CATCH    
    
    
      
      
 END      
    
    
    
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_InsertCloseHistory_MPR] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_InsertCloseHistory_MPR] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_InsertCloseHistory_MPR] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_InsertCloseHistory_MPR] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_InsertCloseHistory_MPR] TO [DB_DMLSupport]
    AS [dbo];

