﻿CREATE PROCEDURE ARC_Lounge_Message_Comment_Insert          
(@MsgId INT,          
@CommentText varchar(500),          
@CommentedBy VARCHAR(75)          
) AS             
/*               
 CreatedBy : Udhayaganesh.p              
 Purpose   : Insert comments for messages and retrive the recent comments for particular Message.               
               
 Execution : Exec ARC_Lounge_Message_Comment_Insert 1,'Test artical','balaji.kumar'              
               
              
 */                        
BEGIN                      
if @CommentText !='Write your comment'                  
begin                  
 if not exists                  
 (select top 1 'x' from ARC_Forum_Lounge_Message_Comments where MsgId =@MsgId and            
  CommentedBy =@CommentedBy and CommentText =@CommentText  and CONVERT(date,CommentedOn)=CONVERT(date,getdate()) )                  
 begin                  
                   
 INSERT INTO ARC_Forum_Lounge_Message_Comments (MsgId,CommentText,CommentedBy,CommentedOn )                        
 VALUES (@MsgId,@CommentText,@CommentedBy,GETDATE())              
            
 Exec ARC_Lounge_Message_Comments @MsgId,@CommentedBy,1,5              
END 
Else            
Begin            
 Exec ARC_Lounge_Message_Comments @MsgId,@CommentedBy,1,5              
End            
End             
Else            
Begin            
 Exec ARC_Lounge_Message_Comments @MsgId,@CommentedBy,1,5              
End            
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comment_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comment_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comment_Insert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comment_Insert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comment_Insert] TO [DB_DMLSupport]
    AS [dbo];

