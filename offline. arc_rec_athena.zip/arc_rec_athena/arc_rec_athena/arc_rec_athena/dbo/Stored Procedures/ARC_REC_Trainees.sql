﻿--ARC_REC_Trainees 16,'',''  
CREATE procedure ARC_REC_Trainees        
      @SUPERVISOR_ID INT,  
      @SearchStr varchar(100) = '',  
   @SearchPattern varchar(4) = '=' /** = or % **/           
As        
BEGIN       
    if OBJECT_ID('tempdb..#TraineesView') is not null drop table #TraineesView  
    Create Table #TraineesView([CheckAll] varchar(max),EMPCODE varchar(10),NAME varchar(100),Designation varchar(100) ,FunctionName varchar(100))   
   
 declare @reporting varchar(75)        
 select @reporting = NT_USERNAME from ARC_REC_USER_INFO where USERID = @SUPERVISOR_ID   
  insert into #TraineesView([CheckAll],EMPCODE,NAME,Designation,FunctionName)  
 select '<input type="checkbox" class="CheckAll" id="'+convert(varchar,ui.USERID)+'">' as [CheckAll],      
 ui.EMPCODE,ui.FIRSTNAME+' '+ui.LASTNAME AS NAME,        
 --ui.NT_USERNAME,    
 d.Designation,f.FunctionName      
 from ARC_REC_InductionMaster im    
 inner join ARC_REC_USER_INFO ui on ui.USERID = im.UserId        
 left join HR_Designation d on ui.DESIGNATION_ID = d.DesigId        
 left join HR_Functionality f on ui.FUNCTIONALITY_ID = f.FunctionalityId  
 left join ARC_FIN_CLIENT_INFO cl on ui.CLIENT_ID = cl.CLIENT_ID         
 where REPORTING_TO = @reporting and isnull(im.Trainee,'') = 'Y'     
   
 Declare @OrderStr varchar(100)         
 SET @OrderStr  = ' '   
 Exec FilterTable  
 @DbName = 'tempdb'  
 ,@TblName = '#TraineesView'  
 ,@SearchStr = @SearchStr  
 ,@SearchPattern = @SearchPattern  
 ,@OrderStr = @OrderStr  
 if OBJECT_ID('tempdb..#TraineesView') is not null drop table #TraineesView      
    
END   
  
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_Trainees] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Trainees] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Trainees] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_Trainees] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Trainees] TO [DB_DMLSupport]
    AS [dbo];

