﻿CREATE procedure ARC_Setup_MenuInsert        
(      
@MenuId int        
,@MenuParentId int        
,@MenuDisplayText varchar(100)        
,@MenuDescription varchar(500)        
,@OutputPath varchar(max)        
,@LogoFilePath varchar(max)          
,@Functionality varchar(100)    
,@NtUserName varchar(100)  
,@Boxno int  
,@MenuFileName varchar(75)  
)        
as        
begin        
insert into ARC_Setup_Menu(MenuId,MenuParentId,MenuDisplayText      
,MenuDescription,OutputPath,LogoFilePath,CreatedBy      
,BaseFuntionality_Id,Boxno,MenuFileName)        
select @MenuId,@MenuParentId,@MenuDisplayText      
,@MenuDescription      
,@OutputPath,@LogoFilePath       
,(select userid from ARC_REC_USER_INFO where NT_USERNAME = @NtUserName)     
,isnull((select FunctionalityId from HR_Functionality where FunctionName = @Functionality),0)  
,@Boxno,@MenuFileName  
end  
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Setup_MenuInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Setup_MenuInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Setup_MenuInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Setup_MenuInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Setup_MenuInsert] TO [DB_DMLSupport]
    AS [dbo];

