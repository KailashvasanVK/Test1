﻿CREATE PROC ARC_REC_CAPMAN_FACILITYWISE_LEVEL
@type VARCHAR(10)=NULL,
@Facility VARCHAR(30)='HQ' 
AS  
Begin  
SELECT *,CAST((CapacityUtilized*1.0/TotalCapacity) *100 AS NUMERIC(18,2)) [UT%]   
FROM (  
SELECT FacilityId,FacilityName +' - '+ LevelName FacilityName,  
TotalCapacity=(SELECT COUNT(*) FROM dbo.ARC_REC_CAPMAN CM   
WHERE CM.FacilityId=EP.FacilityId and STATUS=1),  
CapacityUtilized=(SELECT COUNT(*) FROM dbo.ARC_REC_CAPMAN CM   
WHERE CM.FacilityId=EP.FacilityId and STATUS=1 AND BayStatus=1),  
CapacityAvaliable=(SELECT COUNT(*) FROM dbo.ARC_REC_CAPMAN CM   
WHERE CM.FacilityId=EP.FacilityId and STATUS=1 AND BayStatus=0)  
FROM dbo.Eye_Facility EP  
WHERE FacilityName =@Facility
GROUP BY FacilityId,FacilityName,LevelName  
) AS Udhaya   
END  
  
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_FACILITYWISE_LEVEL] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_FACILITYWISE_LEVEL] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_FACILITYWISE_LEVEL] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_FACILITYWISE_LEVEL] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_CAPMAN_FACILITYWISE_LEVEL] TO [DB_DMLSupport]
    AS [dbo];

