﻿CREATE Procedure ARC_REC_RoleTranMove  
@RoleId int 
As      
/*      
Purpose    : To move and delete the role and menu details from  ARC_REC_RoleTran into ARC_REC_RoleTranLog.
Impact to  : RoleCreation.aspx
Created by : Karthik Ic
Created on : 09 april 2013
*/
Begin
if exists(select  top 1 'x' from ARC_REC_RoleTran  where RoleId = @RoleId)
begin
------------ insert the data into log table  ------------       
Insert into ARC_REC_RoleTranlog(RoleId,MenuId,RoleRead,RoleWrite,CREATED_BY,CREATED_DT)
Select RoleId,MenuId,RoleRead,RoleWrite,CREATED_BY,CREATED_DT from ARC_REC_RoleTran Where RoleId = @RoleId
------------ Delete the data from ARC_REC_RoleTran table  ------------       
delete from ARC_REC_RoleTran Where RoleId = @RoleId
End      
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_RoleTranMove] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_RoleTranMove] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_RoleTranMove] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_RoleTranMove] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_RoleTranMove] TO [DB_DMLSupport]
    AS [dbo];

