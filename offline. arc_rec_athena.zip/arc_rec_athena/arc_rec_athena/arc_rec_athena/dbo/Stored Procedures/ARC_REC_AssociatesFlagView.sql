﻿CREATE procedure ARC_REC_AssociatesFlagView      
  @CountryId int = 0      
  ,@SearchStr varchar(max) =''      
  ,@SearchPattern varchar(5)='%'      
AS
Begin      
--Declare  @SessionUserId int = 1  
--Declare  @FunctionalityId int = 0      
--Declare  @DesignationId int = 0      
--Declare  @ClientId int = 0      
--Declare  @SearchStr varchar(max) ='1209024'      
--Declare  @SearchPattern varchar(5)='%'      
Declare @sql as varchar(max)    
set @sql = '   SELECT       
  
CASE WHEN ISNULL(CA.PROFILE_IMAGE_NAME,'''') = '''' THEN       
''<img src="https://arc.accesshealthcare.co/arc_rec/Images/UserImg.jpg" height="60" width="60" />''                   
  ELSE ''<img src="https://arc.accesshealthcare.co/arc_rec/Images/Candidate/'' + CA.PROFILE_IMAGE_NAME+''" height="60" width="60" />'' END AS Associate                  
    
  ,UI.REC_ID as [Recruitment Id],'      

  Set @sql += ' ISNULL(EMPCODE,'''') AS Empcode      
  ,UI.FIRSTNAME as Firstname,UI.LASTNAME as Lastname      
  ,UI.NT_USERNAME as [NT Username],UI.REPORTING_TO As [Reporting To]      
  ,DE.DESIGNATION AS Designation,FU.FunctionName AS Functionality      
  ,ISNULL(C.CLIENT_NAME,'''') AS Client                 
  ,FC.CountryName
   ,CASE WHEN UI.ACTIVE = 1 THEN ''Yes'' ELSE ''No'' END AS [Active Status]   
  into #Associates          
  FROM ARC_REC_USER_INFO AS UI     
    LEFT JOIN ARC_REC_CANDIDATE AS CA ON CA.REC_ID = UI.REC_ID                
  LEFT JOIN HR_DESIGNATION AS DE ON DE.DESIGID = UI.DESIGNATION_ID                  
  LEFT JOIN HR_FUNCTIONALITY AS FU ON FU.FunctionalityId = UI.FUNCTIONALITY_ID                   
  LEFT JOIN ARC_REC_CustomerView C ON C.CLIENT_ID = UI.CLIENT_ID                  
  inner join ARC_REC_FootballTeams as FTeams on FTeams.UserId = UI.UserId
  inner join ARC_REC_FootballCountries as FC on FC.CountryId = FTeams.CountryId
  WHERE Active = 1 and ISNULL(UI.AHS_PRL,''Y'') = ''Y''       
 '  if(@CountryId > 0)      
 Set @sql = @sql + ' and FC.CountryId ='+convert(varchar,@CountryId)      
       
 Set @sql = @sql + '      
 Exec FilterTable        
 @DbName = ''tempdb''        
 ,@TblName = ''#Associates''        
 ,@SearchStr = '''+@SearchStr+'''       
 ,@SearchPattern ='''+ @SearchPattern  +'''      
 ,@OrderStr = ''''      
 if OBJECT_ID(''tempdb..#Associates'') is not null drop table #Associates          
  '        
 exec(@sql)         
   
End 


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_AssociatesFlagView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AssociatesFlagView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AssociatesFlagView] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_AssociatesFlagView] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_AssociatesFlagView] TO [DB_DMLSupport]
    AS [dbo];

