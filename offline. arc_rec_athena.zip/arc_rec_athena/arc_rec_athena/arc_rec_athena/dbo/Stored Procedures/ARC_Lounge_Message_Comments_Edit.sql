﻿CREATE procedure ARC_Lounge_Message_Comments_Edit     
(      
@CommtId int ,            
@NT_UserName varchar(100),    
@CommentText  Varchar(500)    
)       
as        
/*      
       
 CreatedBy : Udhayaganesh.p            
       
 Purpose   : Edit the Respective Message for Owner of the Post    
     
 ARC_Lounge_Message_Comments_Edit 43,'Udhayaganesh.p','This is test Post temp'    
     
       
*/        
begin      
iF Exists(Select 'x' from ARC_Forum_Lounge_Message_Comments where CommentedBy=@NT_UserName and Id =@CommtId)    
Begin    
    
Update ARC_Forum_Lounge_Message_Comments set CommentText=@CommentText,ModifiedBy=@NT_UserName,ModifiedOn=GETDATE() where Id =@CommtId    
    
select ID,CommentText from ARC_Forum_Lounge_Message_Comments  where Id =@CommtId    
    
End      
                 
          
end    
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comments_Edit] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comments_Edit] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comments_Edit] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comments_Edit] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Comments_Edit] TO [DB_DMLSupport]
    AS [dbo];

