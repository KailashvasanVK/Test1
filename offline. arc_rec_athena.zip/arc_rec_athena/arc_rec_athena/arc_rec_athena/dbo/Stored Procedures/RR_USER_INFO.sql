﻿CREATE Proc RR_USER_INFO
@NTUsername VARCHAR(100)='Udhayaganesh.p'
AS
Begin
select ProfileImageName=isnull('..arc_rec/images/'+PROFILE_IMAGE_NAME,'
..arc_rec/images/userimg.jpg'),Firstname,LastName,USERID  from ARC_REC_USER_INFO_VY where NT_UserName =@NTUsername
End   

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_USER_INFO] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_USER_INFO] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_USER_INFO] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RR_USER_INFO] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RR_USER_INFO] TO [DB_DMLSupport]
    AS [dbo];

