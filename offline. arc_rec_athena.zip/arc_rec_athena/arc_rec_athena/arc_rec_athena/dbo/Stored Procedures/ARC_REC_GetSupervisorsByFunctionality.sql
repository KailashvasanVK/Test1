﻿--ARC_REC_GetSupervisorsByFunctionality 9
CREATE procedure [dbo].[ARC_REC_GetSupervisorsByFunctionality]  
       @FunctionalityID int  
As  
Begin  
if(@FunctionalityID  = 9)
begin
 SELECT UI.USERID,D.DESIGNATION,F.FUNCTIONNAME,UI.FIRSTNAME+' '+UI.LASTNAME+'-('+UI.EMPCODE+')' AS NAME                                                  
FROM ARC_REC_USER_INFO UI                                                  
INNER JOIN HR_FUNCTIONALITY F ON UI.FUNCTIONALITY_ID = F.FUNCTIONALITYID                                                  
INNER JOIN HR_DESIGNATION D ON UI.DESIGNATION_ID = D.DESIGID                                                  
WHERE UI.ACTIVE = 1 AND UI.AHS_PRL = 'Y' AND D.SUPERVISOR  = 'Y' AND F.FUNCTIONALITYID = @FunctionalityID 
union all
SELECT UI.USERID,D.DESIGNATION,F.FUNCTIONNAME,UI.FIRSTNAME+' '+UI.LASTNAME+'-('+UI.EMPCODE+')' AS NAME                                                  
FROM ARC_REC_USER_INFO UI                                                  
INNER JOIN HR_FUNCTIONALITY F ON UI.FUNCTIONALITY_ID = F.FUNCTIONALITYID                                                  
INNER JOIN HR_DESIGNATION D ON UI.DESIGNATION_ID = D.DESIGID                                                  
WHERE UI.ACTIVE = 1 AND UI.AHS_PRL = 'Y' AND F.FUNCTIONALITYID = @FunctionalityID AND D.SUPERVISOR  <> 'Y'
end
else
begin
 SELECT UI.USERID,D.DESIGNATION,F.FUNCTIONNAME,UI.FIRSTNAME+' '+UI.LASTNAME+'-('+UI.EMPCODE+')' AS NAME                                                  
FROM ARC_REC_USER_INFO UI                                                  
INNER JOIN HR_FUNCTIONALITY F ON UI.FUNCTIONALITY_ID = F.FUNCTIONALITYID                                                  
INNER JOIN HR_DESIGNATION D ON UI.DESIGNATION_ID = D.DESIGID                                                  
WHERE UI.ACTIVE = 1 AND UI.AHS_PRL = 'Y' AND D.SUPERVISOR  = 'Y' AND F.FUNCTIONALITYID = @FunctionalityID 
end
End  



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_GetSupervisorsByFunctionality] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_GetSupervisorsByFunctionality] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_GetSupervisorsByFunctionality] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_GetSupervisorsByFunctionality] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_GetSupervisorsByFunctionality] TO [DB_DMLSupport]
    AS [dbo];

