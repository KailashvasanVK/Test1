﻿CREATE procedure AHC_GetClient    
As    
Begin    
select Client_ID,Client_Name from  ARC_FIN_CLIENT_INFO   
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AHC_GetClient] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHC_GetClient] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHC_GetClient] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AHC_GetClient] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AHC_GetClient] TO [DB_DMLSupport]
    AS [dbo];

