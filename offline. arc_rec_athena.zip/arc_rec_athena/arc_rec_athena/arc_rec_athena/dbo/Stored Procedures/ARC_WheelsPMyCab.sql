﻿CREATE PROCEDURE ARC_WheelsPMyCab  
@UserId int  
AS  
BEGIN  
Declare @EmpCode varchar(10) = (Select EmpCode from ARC_REC_USER_INFO where USERID = @UserId)
SELECT Top 1 ISNULL(WCP.PickupPoint,'') PickupPoint, ISNULL(WCP.PickupType,'') PickupType,ISNULL(CONVERT(VARCHAR(5), WCP.PickupTime, 108),'') PickupTime,ISNULL(WCP.CabNumber,'') PCabNumber,  
  ISNULL(WCP.DriverName,'') PDriverName,ISNULL(WCP.DriverNumber,'') PDriverNumber,ISNULL(WCD.DropPoint,'') DropPoint,ISNULL(WCD.DropType, '') DropType,ISNULL(WCD.CabNumber,'') DCabNumber,  
  ISNULL(WCD.DriverName,'') DDriverName,ISNULL(WCD.DriverNumber,'') DDriverNumber  
  FROM  ARC_REC_USER_INFO UI   
  LEFT JOIN 
  (
  Select Top 1 * from ARC_WheelsCabPickupLog Where EMPCODE = @EmpCode Order by RowId Desc
  ) WCP ON UI.EMPCODE = WCP.EMPCODE  
  LEFT JOIN 
  (Select Top 1 * from ARC_WheelsCabDropLog Where EMPCODE = @EmpCode Order by RowId desc
  ) WCD ON UI.EMPCODE = WCD.EMPCODE  
WHERE UI.USERID = @UserId  
END

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_WheelsPMyCab] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_WheelsPMyCab] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_WheelsPMyCab] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_WheelsPMyCab] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_WheelsPMyCab] TO [DB_DMLSupport]
    AS [dbo];

