﻿CREATE proc ARC_REC_Imgupdateprofile
@REC_ID int,
@EMPCODE varchar(150)
as 
begin
if(@REC_ID <> '')
begin
Select CASE WHEN ISNULL(C.PROFILE_IMAGE_NAME,'') <> '' THEN 'https://arc.accesshealthcare.co/arc_rec/Images/Candidate/' + C.PROFILE_IMAGE_NAME ELSE '' END AS PROFILE_IMAGE_NAME,
ui.FIRSTNAME,ui.LASTNAME,ui.EMPCODE,ui.NT_USERNAME  
from ARC_REC_Candidate as C 
left join ARC_REC_CANDIATE_PROFILE canp on c.REC_ID = canp.REC_ID
left join ARC_REC_USER_INFO ui on c.REC_ID = ui.REC_ID
Where c.REC_ID = @REC_ID  
end
else if (@EMPCODE <> '')
begin
Select CASE WHEN ISNULL(C.PROFILE_IMAGE_NAME,'') <> '' THEN 'https://arc.accesshealthcare.co/arc_rec/Images/Candidate/' + C.PROFILE_IMAGE_NAME ELSE '' END AS PROFILE_IMAGE_NAME  
,ui.FIRSTNAME,ui.LASTNAME,ui.EMPCODE,ui.NT_USERNAME
from ARC_REC_USER_INFO as ui 
left join ARC_REC_CANDIATE_PROFILE canp on ui.REC_ID = canp.REC_ID
left join ARC_REC_Candidate c on ui.REC_ID = c.REC_ID
Where ui.EMPCODE = @EMPCODE
end
end

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_Imgupdateprofile] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Imgupdateprofile] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Imgupdateprofile] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_Imgupdateprofile] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_Imgupdateprofile] TO [DB_DMLSupport]
    AS [dbo];

