﻿--ARC_REC_SELF_ATTENDANCE_VIEW 19                   
CREATE PROCEDURE ARC_REC_SELF_ATTENDANCE_VIEW                    
      @USER_ID INT,        
      @MONTH_INDEX INT=0                    
AS                    
BEGIN                    
IF OBJECT_ID('TEMPDB..#SELFATT','U') IS NOT NULL DROP TABLE #SELFATT                    
                    
CREATE TABLE #SELFATT (AID INT,USERID INT,ATTENDANCE_DATE DATE,ATT_TYPE VARCHAR(100),TOTAL_HRS NUMERIC(8,2),CREATED_BY INT,CREATED_DT DATETIME,APPLIED_LEAVE INT,REASON VARCHAR(MAX),    
ATT_DESC VARCHAR(MAX),LOGIN_TIME DATETIME,LOGOUT_TIME DATETIME)                    
                    
DECLARE @month TINYINT          
--DECLARE @USER_ID  INT        
--SET @USER_ID = 19                  
IF @MONTH_INDEX > 0        
 SET @month = @MONTH_INDEX        
ELSE        
 SET @month = DATEPART(MONTH,GETDATE());                    
        
--WITH                    
--MonthDays AS                    
--(                    
-- SELECT DATEADD(month, @month, DATEADD(month, -MONTH(GETDATE()), DATEADD(day, -DAY(GETDATE()) + 1, CAST(FLOOR(CAST(GETDATE() AS FLOAT)) AS DATETIME)))) D                    
-- UNION ALL                    
-- SELECT DATEADD(day, 1, D)                    
-- FROM MonthDays                    
-- WHERE D < (GETDATE()-1)                    
-- --DATEADD(day, -1, DATEADD(month, 1, DATEADD(month, @month, DATEADD(month, -MONTH(GETDATE()), DATEADD(day, -DAY(GETDATE()) + 1, CAST(FLOOR(CAST(GETDATE() AS FLOAT)) AS DATETIME))))))                    
--)                    
         
declare @tdate date        
set @tdate = convert(varchar,DATEPART(yyyy,getdate())) + '-' + convert(varchar,@month) + '-' + '01'                    
        
while (datepart(mm,@tdate) = @month)        
begin        
INSERT INTO #SELFATT(USERID,ATTENDANCE_DATE,ATT_TYPE,TOTAL_HRS,APPLIED_LEAVE,REASON,ATT_DESC)                                
SELECT @USER_ID,@tdate AS ATTENDANCE_DATE,'' AS ATT_TYPE,'0' AS TOTAL_HRS,0 AS APPLIED_LEAVE,''  AS REASON,'' where @tdate <= CONVERT(DATE,getdate())                 
set @tdate = DATEADD(DAY,1,@tdate)        
end        
        
        
                    
UPDATE #SELFATT set                    
AID = SF.AID,                    
ATT_TYPE = CASE WHEN SF.ATT_TYPE = 'F' THEN 'Full Present' WHEN SF.ATT_TYPE = 'H' THEN 'Half Present' END,                    
TOTAL_HRS = SF.WORKED_HRS,                    
CREATED_BY = SF.CREATED_BY,                    
CREATED_DT = SF.CREATED_DT,    
LOGIN_TIME = SF.LOGIN_TIME,      
LOGOUT_TIME = SF.LOGOUT_TIME    
FROM #SELFATT SA JOIN ARC_REC_SELF_ATTENDANCE SF                    
ON SA.USERID = SF.USERID AND SA.ATTENDANCE_DATE = SF.ATTENDANCE_DATE                 
                
                
UPDATE #SELFATT SET             
ATT_TYPE = case when lr.LEAVE_MODE = 'F' then 'Full LWP' else 'Half Present' end,             
APPLIED_LEAVE = 1,                
REASON = LR.REASON                
FROM #SELFATT SA JOIN ARC_REC_LEAVE_REQUEST LR                
ON SA.USERID = LR.CREATED_BY AND ((SA.ATTENDANCE_DATE BETWEEN LR.FROMDATE AND LR.TODATE) OR (SA.ATTENDANCE_DATE = LR.FROMDATE) OR (SA.ATTENDANCE_DATE =  LR.TODATE))                
AND LR.LEAVE_STATUS IN (1,3) AND LR.ACTIVE = 'Y' AND LR.TYPEID <> 5              
                
                
UPDATE A1  SET            
A1.ATT_DESC = A2.ATT_TYPE           
+(CASE WHEN A2.TOTAL_HRS > 0 THEN ' - '+CONVERT(VARCHAR,A2.TOTAL_HRS)+' Hrs' ELSE '' END)+(CASE WHEN A2.APPLIED_LEAVE > 0 THEN ' (Leave Applied - '+A2.REASON+') ' ELSE '' END)            
FROM #SELFATT A1 JOIN #SELFATT A2 ON A1.ATTENDANCE_DATE = A2.ATTENDANCE_DATE            
            
SELECT ISNULL(AID,0) AS AID,CONVERT(VARCHAR,ATTENDANCE_DATE,113) AS ATTENDANCE_DATE,ATT_TYPE,TOTAL_HRS,APPLIED_LEAVE,REASON,ATT_DESC,    
convert(varchar(50),LOGIN_TIME,106)+' '+RIGHT(CONVERT(VARCHAR, LOGIN_TIME, 100),7)  as LOGIN_TIME,  
convert(varchar(50),LOGOUT_TIME,106)+' '+RIGHT(CONVERT(VARCHAR, LOGOUT_TIME, 100),7)  as LOGOUT_TIME,  
DATENAME(DW, ATTENDANCE_DATE) as Day_Of_Week,LOGIN_TIME as LogOn,LOGOUT_TIME as Logout    
FROM #SELFATT               
where ATTENDANCE_DATE >= (select DOJ from ARC_REC_USER_INFO where USERID = @USER_ID)                  
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_SELF_ATTENDANCE_VIEW] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_SELF_ATTENDANCE_VIEW] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_SELF_ATTENDANCE_VIEW] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_SELF_ATTENDANCE_VIEW] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_SELF_ATTENDANCE_VIEW] TO [DB_DMLSupport]
    AS [dbo];

