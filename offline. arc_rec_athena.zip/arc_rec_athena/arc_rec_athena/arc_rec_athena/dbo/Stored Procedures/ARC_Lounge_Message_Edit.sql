﻿CREATE procedure ARC_Lounge_Message_Edit             
(              
@MsgId int ,                    
@NT_UserName varchar(100),            
@MsgContent  Varchar(500)            
)               
as                
/*              
               
 CreatedBy : Udhayaganesh.p                    
               
 Purpose   : Edit the Respective Message for Owner of the Post            
             
 ARC_Lounge_Message_Edit 7,'Udhayaganesh.p','This is test Post'            
             
               
*/                
begin              
iF Exists(Select 'x' from ARC_Forum_Lounge_Messages where Id =@MsgId      
 and CreatedBy=@NT_Username)            
Begin            

insert into ARC_Forum_Lounge_Messages_Archive(LMid,MsgContent,Status,CreatedBy,CreatedOn,ModifiedBy,ModifiedOn,Priority,Type,MsgId)
select ID,MsgContent,Status,CreatedBy,CreatedOn,ModifiedBy,ModifiedOn,Priority,Type,MsgId from ARC_Forum_Lounge_Messages where Id =@MsgId 
          
Update ARC_Forum_Lounge_Messages set MsgContent=@MsgContent,ModifiedBy=@NT_UserName,ModifiedOn=GETDATE() where Id =@MsgId            
            
select ID,MsgContent from ARC_Forum_Lounge_Messages  where Id =@MsgId            
            
End              
Else      
begin      
      
select ID,MsgContent from ARC_Forum_Lounge_Messages  where Id =@MsgId            
      
End                     
                  
end 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Message_Edit] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Edit] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Edit] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Lounge_Message_Edit] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Lounge_Message_Edit] TO [DB_DMLSupport]
    AS [dbo];

