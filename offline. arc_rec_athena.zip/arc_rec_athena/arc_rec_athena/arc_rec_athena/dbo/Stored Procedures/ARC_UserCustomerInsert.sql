﻿CREATE procedure  [dbo].[ARC_UserCustomerInsert]     
@CustomerID int ,    
@UserId int ,
@LastCustomer int = 1,
@CREATED_BY int     
As    
/*    
Created by : Karthik Ic              
Created on : 03 May 2013              
Impact to  : UserCustomer.aspx          
Purpose    : To save the user and customer details      
*/    
Begin    
Insert into ARC_REC_UserCustomer (CustomerID,UserId,CREATED_BY)     
Select @CustomerID,@UserId,@CREATED_BY    
--declare @NewCustomerID int  
--set @NewCustomerID = IDENT_CURRENT( 'ARC_REC_USER_INFO')      
if (@LastCustomer = 0 )
begin
update ARC_REC_Athena..ARC_REC_USER_INFO  set  LastCustomerId = @CustomerID  where USERID = @UserId   
End
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_UserCustomerInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_UserCustomerInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_UserCustomerInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_UserCustomerInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_UserCustomerInsert] TO [DB_DMLSupport]
    AS [dbo];

