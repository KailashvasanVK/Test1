﻿CREATE Proc LongRunningQuery  
as  
SELECT TOP 10   
   ObjecName = OBJECT_NAME(sc.id),  
   ProcedureName    = t.text,   
   ExecutionCount   = s.execution_count,   
   AvgExecutionTime = isnull( s.total_elapsed_time / s.execution_count, 0 ),  
   AvgWorkerTime    = s.total_worker_time / s.execution_count,  
   TotalWorkerTime  = s.total_worker_time,  
   MaxLogicalReads  = s.max_logical_reads,   
   MaxLogicalWrites = s.max_logical_writes,   
   CreationDateTime = s.creation_time,  
   CallsPerSecond   = isnull( s.execution_count / datediff( second, s.creation_time, getdate()), 0 )  
FROM sys.dm_exec_query_stats s  
   CROSS APPLY sys.dm_exec_sql_text( s.sql_handle )  t  
   inner join syscomments sc on t.text =sc.text  
   where OBJECT_NAME(sc.id) not like '%LongRunningQuery%'
ORDER BY   
   s.total_elapsed_time DESC
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[LongRunningQuery] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[LongRunningQuery] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[LongRunningQuery] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[LongRunningQuery] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[LongRunningQuery] TO [DB_DMLSupport]
    AS [dbo];

