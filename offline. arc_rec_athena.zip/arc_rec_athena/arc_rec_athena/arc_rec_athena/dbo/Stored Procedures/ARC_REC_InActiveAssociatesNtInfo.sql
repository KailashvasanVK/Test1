﻿CREATE Procedure ARC_REC_InActiveAssociatesNtInfo  
(  
@frmDate date = null  
,@toDate date = null  
,@RptType varchar(1) = 'D' /* (D)etailed (S)ummary */  
,@MonthWise varchar(1) = 'Y' /* (y)es (n)o */  
,@SearchStr varchar(100) = ''    
,@SearchPattern varchar(4) = '=' /** = or % **/  
)  
As  
Begin  
/** Req Param   
--Declare @frmDate date  
--Declare @toDate date  
--Declare @RptType varchar(1) /* (D)etailed (S)ummary */  
--Declare @MonthWise varchar(1) /* (y)es (n)o */  
--Set @RptType = 'D'  
--Set @MonthWise = 'Y'  
--Set @frmDate = '2013-08-01'   
--Set @toDate = '2013-10-30'  
**/  
  
Declare @TblName varchar(25)=''    
Declare @Orderby varchar(100) =''    
  
  
if isnull(@frmDate,'')  = '' begin Set @frmDate = '1900-01-01' Set @toDate = CONVERT(date,getdate()) end  
if OBJECT_ID('tempdb..#InActiveAss') is not null drop table #InActiveAss  
Select Convert(varchar(50),ui.EMPCODE) AS [EmpCode]  
,Convert(varchar,ui.NT_USERNAME) as [Associate NtId]  
,Convert(varchar,ui.FIRSTNAME) as [First Name]  
,Convert(varchar,ui.LASTNAME) as [Last Name]  
,Convert(varchar, cus.Client_Name) as [Client]  
,Convert(varchar,func.FunctionName) [Functionality]  
--,Convert(date,ui.DOJ) as DOJ  
,Convert(varchar,ui.DOJ,101)  as DOJ  
,Convert(varchar,uiDoL.DOR,101)as DOR  
,Convert(varchar,uiDoL.DOL,101)as DOL  
,Convert(varchar,uiDoL.ModeOfLeave) as ModeOfLeave  
,Convert(varchar,uiDoL.Remarks)Remarks  
,Convert(varchar,DolRemBy.NT_USERNAME) [RemarksBy]  
,CONVERT(varchar(3),'')  as [ColHead]  
,Convert(int,DATENAME(YEAR,uiDoL.DOL) + RIGHT('00' + Convert(varchar,DATEPart(MM,uiDoL.DOL)),2))  as [Month~Hide]  
,CONVERT(int,1)  as [Result~Hide]  
into #InActiveAss  
from ARC_REC_USER_INFO as ui  
inner join ARC_REC_CustomerView as cus on cus.Client_Id = ui.CLIENT_ID  
inner join HR_Functionality as func on func.FunctionalityId = ui.FUNCTIONALITY_ID  
inner join ARC_REC_AssociateDOLView as uiDoL on uiDol.USERID = ui.USERID and uiDoL.DOL between @frmDate and @toDate  
inner join ARC_REC_USER_INFO as DolRemBy on DolRemBy.USERID = uiDoL.RemarksBy  
Where ui.ACTIVE = 2 and ui.AHS_PRL = 'Y'   
  
if @RptType = 'D'  
 Begin     
 set @TblName = '#InActiveAss'    
 if ISNULL(@MonthWise,'') = 'Y'  
 Begin  
  Insert into #InActiveAss([Associate NtId],[Month~Hide],[Result~Hide],ColHead)  
  Select DATENAME(MONTH,DOL) + ', ' +  DATENAME(YEAR,DOL) + ' (' +  Convert(varchar,COUNT(*)) + ')'  
  ,Convert(int,DATENAME(YEAR,DOL) + RIGHT('00' + Convert(varchar,DATEPart(MM,DOL)),2))  
  ,0,'T'  
   from #InActiveAss Group by DATENAME(MONTH,DOL) + ', ' +  DATENAME(YEAR,DOL),Convert(int,DATENAME(YEAR,DOL) + RIGHT('00' + Convert(varchar,DATEPart(MM,DOL)),2))  
   set @Orderby = ' Order by [Month~Hide],[Result~Hide]'    
  End    
 --Select * from #InActiveAss  
 --Order by [Month~Hide],[Result~Hide]  
End  
Else if @RptType = 'S' /* Summary */  
Begin  
 if OBJECT_ID('tempdb..#InActiveGAss') is not null drop table #InActiveGAss  
 set @TblName = '#InActiveGAss'    
 Select [Month],[Count],ColHead    
 into #InActiveGAss  
 from     
 (      
  Select DATENAME(MONTH,DOL) + ', ' +  DATENAME(YEAR,DOL) as [Month]  
  ,COUNT(*) as [Count],CONVERT(varchar(3),'') as ColHead  
  from #InActiveAss Group by DATENAME(MONTH,DOL) + ', ' +  DATENAME(YEAR,DOL),Convert(int,DATENAME(YEAR,DOL) + RIGHT('00' + Convert(varchar,DATEPart(MM,DOL)),2))    
  Union all  
  Select 'Grand Total' as [Month]  
  ,COUNT(*) as [Count],'G' as ColHead  
  from #InActiveAss   
 )  as tSummary    
End  
Exec FilterTable        
 @DbName = 'tempdb'        
,@TblName = @TblName    
,@SearchStr = @SearchStr    
,@SearchPattern = @SearchPattern    
,@OrderStr = @Orderby     
  
if OBJECT_ID('tempdb..#InActiveAss') is not null drop table #InActiveAss  
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_InActiveAssociatesNtInfo] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_InActiveAssociatesNtInfo] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_InActiveAssociatesNtInfo] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_REC_InActiveAssociatesNtInfo] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_REC_InActiveAssociatesNtInfo] TO [DB_DMLSupport]
    AS [dbo];

