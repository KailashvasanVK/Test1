﻿CREATE Procedure HR_MPR_MD_Approval (@Userid int)                                                
as                                       
/*                                    
 Created By : Udhayaganesh.p                                    
 Created On : 27/08/2013                                    
 Purpose  : To list out list of MPR to be for MD approved               
             
 HR_MPR_MD_Approval 1            
   
 select * from MRPLOGIN  
                                
*/                                             
begin             
               
                                            
    select                                
  d.CreatedBy,                                    
  d.MPRId as mid,                                     
--  hd.Designation as [JobTitle],                                     
hd.designation as [Designation],                                  
'<a title="MPR Details" href="#" url="/HR/MPR/MDMPRDisplay.aspx?MPRID='+ cast(d.MPRid as varchar) + '" class=Link_Edit onclick="GB_show(this,550,650);" style="cursor:hand"><u>'+ hd.Designation  +'</u></a>' as [JobTitle],                                  
                                  
  d.FunctionalityId,                                    
  d.TotalPositions as noofpos ,                                     
  d.Reason as RecruitmentReason,                                    
  'Rs. ' + dbo.RupeeFormat_Rounded(cast(d.SalaryMin as varchar)) + ' - Rs. ' + dbo.RupeeFormat_Rounded(cast(d.SalaryMax as varchar))  as SalRange,                                    
  f.FunctionName as [Dept],                                    
  ff.FunctionName as [Functionname],                                        
  (select e.username from MRPLOGIN e where d.CreatedBy = e.userid) as MPRBy,                                                            
  convert(varchar(10), d.CreatedDate, 103) as CreatedDate, G.Facility as [centername]                                    
 from                                     
  hr_MPR d inner join hr_Functionality f on d.FunctionalityId=f.FunctionalityId                                                             
  inner join hr_functionality ff on  ff.FunctionalityId  = f.FuncParentId                                    
  inner join hr_designation hd on d.DesigId = hd.DesigId                                    
  inner join HR_FacilityMaster G on G.TCId=D.TCId                                    
 where d.MPRStatus = 0 and d.MDApprovalStatus = 0                                       
 order by d.mprid               
            
                                   
end 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_MPR_MD_Approval] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_MD_Approval] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_MD_Approval] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[HR_MPR_MD_Approval] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[HR_MPR_MD_Approval] TO [DB_DMLSupport]
    AS [dbo];

