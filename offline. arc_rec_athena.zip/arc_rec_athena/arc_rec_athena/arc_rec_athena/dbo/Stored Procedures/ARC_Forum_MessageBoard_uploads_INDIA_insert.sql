﻿CREATE PROCEDURE ARC_Forum_MessageBoard_uploads_INDIA_insert            
(        
@msgID INT,            
@attch VARCHAR(500),            
@attch_index INT,            
@createdby VARCHAR(75),      
@FacilityType tinyint=1            
)            
 AS                  
 BEGIN         
       
 INSERT INTO ARC_Forum_MessageBoard_Uploads            
     (MsgId,Attch_File,Attch_Index,CreatedBy,CreatedOn,Status)            
 VALUES (@msgId,@attch,@attch_index,@createdby,GETDATE(),1)      
 
 End      
 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_uploads_INDIA_insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_uploads_INDIA_insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_uploads_INDIA_insert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_uploads_INDIA_insert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Forum_MessageBoard_uploads_INDIA_insert] TO [DB_DMLSupport]
    AS [dbo];

