﻿
CREATE TRIGGER [NON_DB_OWNER_ALTER_TABLE]
ON DATABASE
FOR ALTER_TABLE
AS
-- If User executing Command is not in db_owner command, rollback the transaction
IF ISNULL((SELECT IS_MEMBER('db_owner')), 0) < 1
BEGIN
   DECLARE @Tablename NVARCHAR(256)
   -- Capture Table Name
   SELECT @Tablename = EVENTDATA().value('(/EVENT_INSTANCE/ObjectName)[1]', 'varchar(256)')

   RAISERROR('Cannot alter the table ''%s'', because you do not have permission.', 14, 20, @Tablename)
   ROLLBACK
END


