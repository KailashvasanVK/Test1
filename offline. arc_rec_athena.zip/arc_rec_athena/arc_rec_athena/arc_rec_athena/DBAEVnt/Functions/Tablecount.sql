﻿
Create function dbaevnt.Tablecount(@TablenName varchar(100))
Returns @tableRetrun table
( 
dpages int,reserved int,rows int,rowcnt int
)
as
begin
insert into @tableRetrun
select top 1 dpages,reserved,rows,rowcnt from sysindexes 
where rows<>0 and id=OBJECT_ID( @TablenName )
return
end
