﻿create Procedure dbaevnt.Table_Record_More_then_1000_StatUpdate
as
begin
Set Nocount on;
Declare @SQL varchar(max),@tableName Varchar(500),@tc int

select distinct a.name,b.rowcnt into #table from sys.tables a
inner join sysindexes b on a.object_id=b.id
where rowcnt<>0 and rowcnt>1000 and a.schema_id=1

Set @tc=(select count(*) from #table)

While @tc!=0
begin
select top 1 @tableName =Name From #table order by rowcnt desc
set @SQL ='UPDATE STATISTICS ['+ @tableName+']' 
--print @SQL
exec(@SQL)

Set @tc=@tc-1
Delete from #table where Name =@tableName
End

End