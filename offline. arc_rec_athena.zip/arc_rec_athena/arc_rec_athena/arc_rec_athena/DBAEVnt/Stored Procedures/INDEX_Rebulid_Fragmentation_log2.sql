﻿CREATE Proc DBAEvnt.INDEX_Rebulid_Fragmentation_log2          
AS          
Begin         
        
Set Nocount on;         
          
Declare @TC int,@indexName nvarchar(500),@TableName Nvarchar(100),@idint int,@index_id int          
,@avg_fragmentation_in_percent numeric(18,2),@DBLog numeric(18,2),@qry nvarchar(500)          
          
  
select * into #temptable  from (  
select OBJECT_NAME(a.object_id) TableName,avg(avg_fragmentation_in_percent) AVGFRM,avg(page_count) PGCNT  
FROM sys.dm_db_index_physical_stats (DB_ID(), NULL, NULL, NULL, NULL) AS a        
JOIN sys.indexes AS b ON a.object_id = b.object_id AND a.index_id = b.index_id         
where  name is not null   
group by OBJECT_NAME(a.object_id)   
) as u where PGCNT >100 and AVGFRM>3  
       
          
Set @TC=(select COUNT(*) from #temptable)          
          
          
while @tc!=0                  
begin                  
                  
select @TableName =TableName,@avg_fragmentation_in_percent=AVGFRM from #temptable   
  
insert into [DBAEvents].dbo.IndexRebulidDetails(DBNAME,TableName,IndexName,REBulidStart,BFIndexFra,BLogs)            
select DB_NAME(),@TableName,'All',GETDATE(),@avg_fragmentation_in_percent,size from sys.database_files where type =1            
  
set @idint=SCOPE_IDENTITY()            
          
        
DBCC DBReindex(@TableName,'',70)   
  
select @avg_fragmentation_in_percent=avg(avg_fragmentation_in_percent)   
FROM sys.dm_db_index_physical_stats (DB_ID(), NULL, NULL, NULL, NULL) AS a        
JOIN sys.indexes AS b ON a.object_id = b.object_id AND a.index_id = b.index_id         
where  name is not null and OBJECT_NAME(a.object_id)=@TableName  
group by OBJECT_NAME(a.object_id)   
  
update [DBAEvents].dbo.IndexRebulidDetails set RebulidEnd=GETDATE(),AFIndexFra=@avg_fragmentation_in_percent  
 where  id=@idint              
         
                  
set @tc=@tc-1                  
delete from #temptable where TableName  =@TableName                  
end         
        
        
Set Nocount OFF;         
            
Drop table #temptable;         
End 