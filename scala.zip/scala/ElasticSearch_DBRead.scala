import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.cassandra._
import org.apache.spark.sql.SaveMode


object ElasticSearch_DBRead extends App {
  val conf = new SparkConf()

  //Elastic Search
  conf.set("es.index.auto.create", "true")
  conf.set("spark.es.nodes", "localhost")
  conf.set("spark.es.port", "9200")
  conf.set("spark.es.nodes.wan.only", "true")

 /* //Cassandra
  conf.set("spark.cassandra.connection.host", "localhost")
  conf.set("spark.cassandra.auth.username", "")
  conf.set("spark.cassandra.auth.password", "")*/


  val spark = SparkSession.builder.config(conf).master("local").appName("KafkaSparkStreaming").getOrCreate()
  val rootLogger = Logger.getRootLogger()
  rootLogger.setLevel(Level.ERROR)

  val reader = spark.read
    .format("org.elasticsearch.spark.sql")
    .option("spark.es.nodes.wan.only","true")
    .option("spark.es.port","9200")
    .option("spark.es.net.ssl","true")
    .option("spark.es.nodes", "localhost")

  val df = reader.load("products/salesdata")
  df.show()

  df.createOrReplaceTempView("temp_table")
  val dfaggregate = spark.sql("select count(Id) as count,Id, firstName from temp_table group by Id, firstName")
  dfaggregate.show()




}
