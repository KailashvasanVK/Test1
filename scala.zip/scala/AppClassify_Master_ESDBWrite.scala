import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.sql.{SaveMode, SparkSession}

object AppClassify_Master_ESDBWrite extends App {
  val conf = new SparkConf()
  conf.set("es.index.auto.create", "true")
  conf.set("spark.es.nodes", "localhost")
  conf.set("spark.es.port", "9200")
  conf.set("spark.es.nodes.wan.only", "true")


  val spark = SparkSession.builder.config(conf).master("local").appName("AppClassificationMaster").getOrCreate()
  val rootLogger = Logger.getRootLogger()
  rootLogger.setLevel(Level.ERROR)

  val appcls_df = spark.read.option("header",true).csv("src/main/resource/AppPackageClassification_Master.csv")
  val usrpackage_df = spark.read.option("header",true).csv("src/main/resource/UserPackageMapping_Master.csv")
  val users_df = spark.read.option("header",true).csv("src/main/resource/Users_Master.csv")

  appcls_df.write.format("org.elasticsearch.spark.sql")
    .mode(SaveMode.Append)
    .save("apppackageclassification/masterdocs")

  usrpackage_df.write.format("org.elasticsearch.spark.sql")
    .mode(SaveMode.Append)
    .save("userpackagemapping/masterdocs")

  users_df.write.format("org.elasticsearch.spark.sql")
    .mode(SaveMode.Append)
    .save("usersmaster/masterdocs")

}
