import org.apache.hadoop.hdfs.protocol.proto.ClientNamenodeProtocolProtos.SaveNamespaceRequestProto
import org.apache.spark.SparkConf
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.log4j.{Level, Logger}

object ElasticSearch_DBWrite_Normal extends App{

  val conf = new SparkConf()
  conf.set("es.index.auto.create", "true")
  conf.set("spark.es.nodes", "localhost")
  conf.set("spark.es.port", "9200")
  conf.set("spark.es.nodes.wan.only", "true")


  val spark = SparkSession.builder.config(conf).master("local").appName("AppWatchMaster1").getOrCreate()
  val rootLogger = Logger.getRootLogger()
  rootLogger.setLevel(Level.ERROR)

  val cls_df = spark.read.option("header",true).csv("src/main/resource/Classification.csv")
  val user_df = spark.read.option("header",true).csv("src/main/resource/User.csv")

  user_df.show()
  //cls_df.write.format("org.elasticsearch.spark.sql").mode(SaveMode.Append).save("classification/docs")
  user_df.write.format("org.elasticsearch.spark.sql").mode(SaveMode.Append).save("user_details/docs")

}
