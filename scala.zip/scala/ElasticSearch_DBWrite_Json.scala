import org.apache.spark.sql.SparkSession
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.streaming.StreamingQuery
import org.apache.spark.sql.types
import org.apache.spark.SparkConf
import cassandra._
import model.ProductSale
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.{UserDefinedFunction, Window}

//case class ProductSale(Id: String, firstName: String, lastName: String, house: String, street: String, city: String, state: String, zip: String, prod: String, tag: String) extends Serializable

object ElasticSearch_DBWrite_Json {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()

    //Elastic Search
       conf.set("es.index.auto.create", "true")
       conf.set("spark.es.nodes", "localhost")
       conf.set("spark.es.port", "9200")
       conf.set("spark.es.nodes.wan.only", "true")

 /*   //Cassandra
    conf.set("spark.cassandra.connection.host", "localhost")
    conf.set("spark.cassandra.auth.username", "")
    conf.set("spark.cassandra.auth.password", "")*/


    val spark = SparkSession.builder.config(conf).master("local").appName("KafkaSparkStreaming").getOrCreate()
    val rootLogger = Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)

    import spark.implicits._
    //Read from kafka

    val input = spark.readStream.format("kafka")
      .option("kafka.bootstrap.servers", "localhost:9092")
      .option("subscribe", "products")
      .option("failOnDataLoss", false)
      .option("startingOffsets", "latest").load()

    val df = input.selectExpr("CAST(value AS STRING)")

    /*val ds = df.map(x =>
    { val c = x.split(",")
      ProductSale(c(0), c(1), c(2), c(3), c(4), c(5), c(6),c(7), c(8), c(9))

    })*/

    val struct = new StructType()
      .add("UserAccount", DataTypes.StringType)
      .add("UserDomain", DataTypes.StringType)
      .add( name = "AppName", DataTypes.StringType)
      .add( name = "WindowTitle", DataTypes.StringType)
      .add( name = "BrowserUrl", DataTypes.StringType)
      .add( name = "StartTime", DataTypes.StringType)
      .add( name = "EndTime", DataTypes.StringType)
      .add( name = "TimeSpent", DataTypes.StringType)
      .add( name = "VersionId", DataTypes.StringType)
      .add( name = "CreatedOn", DataTypes.StringType)
      .add( name = "OperatingSystem", DataTypes.StringType)

    val personNestedDf = df.select(from_json($"value", struct).as("AppWatcher"))
    var personFlattenedDf = personNestedDf.selectExpr("AppWatcher.UserAccount", "AppWatcher.UserDomain",
      "AppWatcher.AppName", "AppWatcher.WindowTitle", "AppWatcher.BrowserUrl", "AppWatcher.StartTime",
      "AppWatcher.EndTime", "AppWatcher.TimeSpent", "AppWatcher.VersionId",
      "AppWatcher.CreatedOn", "AppWatcher.OperatingSystem")
   /* personFlattenedDf = personFlattenedDf.withColumn("stime", to_timestamp($"StartTime", "yyyy-MM-ddTHH:mm:ss.SSSZ"))
    personFlattenedDf = personFlattenedDf.withColumn("etime", to_timestamp($"EndTime", "yyyy-MM-ddTHH:mm:ss.SSSZ"))
    personFlattenedDf = personFlattenedDf.withColumn("timediff", unix_timestamp($"etime") - unix_timestamp($"stime"))
   */
    //Scala functions - Normal functions/variables
    val secFunc: String => Float = TimeSpent => {
      val time = TimeSpent.split(":")
      val hour = time(0).toInt *3600
      val min = time(1).toInt * 60
      val sec = time(2).toDouble
      (hour + min + sec).toFloat
    }
    //spark-sql functions - UDF etc
    val secUdf: UserDefinedFunction = udf(secFunc, DataTypes.FloatType)
    personFlattenedDf = personFlattenedDf.withColumn("timeSec", secUdf.apply($"TimeSpent"))
    //withColumn will accept only spark sql function and not scala function

    /* Write to Console
    personFlattenedDf.writeStream.format("console").start().awaitTermination()*/

    //Save to ElasticSearch DB
         val queryes = personFlattenedDf.writeStream.format("es")
          .option("checkpointLocation", "src/main/resource/")
          //.outputMode(OutputMode.Append())
          //.start("appwatch/userAppDetails")
          .start("appwatchnew/userAppDetails")
          queryes.awaitTermination()

    //Save to Cassandra DB
  /*  import org.apache.spark.sql.ForeachWriter
    val connector = Statement.getConnector(spark)
    val writer = new ForeachWriter[ProductSale] {
      override def open(partitionId: Long, version: Long) = true
      override def process(value: ProductSale): Unit = {
        Statement.updateProvinceSale(connector, value)
      }
      override def close(errorOrNull: Throwable): Unit = {}
    }
    val query: StreamingQuery = personFlattenedDf.writeStream
      .queryName("ProductDetails")
      .foreach(writer)
      .start()
    query.awaitTermination()*/

  }
}
