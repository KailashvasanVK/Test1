package model
import java.sql.Timestamp
case class ProductSale(Id: String, firstName: String, lastName: String, house: String, street: String, city: String, state: String, zip: String, prod: String, tag: String) extends Serializable

case class AppWatcher (UserAccount: String, UserDomain: String, ComputerName: String, AppName: String,
                         WindowTitle: String, BrowserUrl: String, StartTime: Timestamp,
                         EndTime: Timestamp, TimeSpent: String, VersionId: String,
                         CreatedOn: String, OperatingSystem: String)

