import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.cassandra._
import org.apache.spark.sql.SaveMode


object Cassandra_DBRead extends App {
  val conf = new SparkConf()

  //Elastic Search
  conf.set("es.index.auto.create", "true")
  conf.set("spark.es.nodes", "localhost")
  conf.set("spark.es.port", "9200")
  conf.set("spark.es.nodes.wan.only", "true")

  //Cassandra
  conf.set("spark.cassandra.connection.host", "localhost")
  conf.set("spark.cassandra.auth.username", "")
  conf.set("spark.cassandra.auth.password", "")


  val spark = SparkSession.builder.config(conf).master("local").appName("KafkaSparkStreaming").getOrCreate()
  val rootLogger = Logger.getRootLogger()
  rootLogger.setLevel(Level.ERROR)

/*
  spark.read.cassandraFormat("productdetails", "demo").load().createOrReplaceTempView("productdetails")

  val df = spark.sql("select * from productdetails where id in ('9', '10', '4')")
  df.show()
  print(df.count())
  val dfaggregate = spark.sql("select count(state) as count,state from productdetails group by state")
  dfaggregate.show()

  dfaggregate.write.format("org.apache.spark.sql.cassandra").mode(SaveMode.Append).options(Map("table" -> "", "keyspace" -> "demo")).save()
*/
  import spark.implicits._

val df = Seq(("Raj","chrome"),("jhon","firefox")).toDF("UserAccount","AppName")
  df.show()
  df.createOrReplaceTempView("temp")
  spark.read.option("header",true).csv("src/main/resource/Classification.csv").createOrReplaceTempView("classification")
  spark.read.option("header",true).csv("src/main/resource/User.csv").createOrReplaceTempView("user")


  val resultDF = spark.sql("select temp.*,classification.Classification from temp join" +
    " user on user.User = temp.UserAccount" +
    " join classification on user.PackageID = classification.PackageID ")

  resultDF.show()
}
