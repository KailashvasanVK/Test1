import org.apache.spark.sql.SparkSession
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.streaming.StreamingQuery
import org.apache.spark.sql.types
import org.apache.spark.SparkConf
import cassandra._
import model.ProductSale


//case class ProductSale(Id: String, firstName: String, lastName: String, house: String, street: String, city: String, state: String, zip: String, prod: String, tag: String) extends Serializable



object Kafka_Stream {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()

    //Elastic Search
 /*   conf.set("es.index.auto.create", "true")
    conf.set("spark.es.nodes", "localhost")
    conf.set("spark.es.port", "9200")
    conf.set("spark.es.nodes.wan.only", "true")*/

    //Cassandra
    conf.set("spark.cassandra.connection.host", "localhost")
    conf.set("spark.cassandra.auth.username", "")
    conf.set("spark.cassandra.auth.password", "")


    val spark = SparkSession.builder.config(conf).master("local").appName("KafkaSparkStreaming").getOrCreate()
    val rootLogger = Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)

    import spark.implicits._
    //Read from kafka

    val input = spark.readStream.format("kafka")
      .option("kafka.bootstrap.servers", "localhost:9092")
      .option("subscribe", "products")
      .option("failOnDataLoss", false)
      .option("startingOffsets", "latest").load()

    val df = input.selectExpr("CAST(value AS STRING)").as[String]

    val ds = df.map(x =>
      { val c = x.split(",")
        ProductSale(c(0), c(1), c(2), c(3), c(4), c(5), c(6),c(7), c(8), c(9))

      })

    /* Write to Console
     ds.writeStream.format("console").start().awaitTermination()*/

    //Save to ElasticSearch DB
/*     val queryes = ds.writeStream.format("es")
      .option("checkpointLocation", "src/main/resource/")
      //.outputMode(OutputMode.Append())
      .start("products/salesdata")
      queryes.awaitTermination()*/

    //Save to Cassandra DB
    import org.apache.spark.sql.ForeachWriter
    val connector = Statement.getConnector(spark)
    val writer = new ForeachWriter[ProductSale] {
      override def open(partitionId: Long, version: Long) = true
      override def process(value: ProductSale): Unit = {
        Statement.updateProvinceSale(connector, value)
      }
      override def close(errorOrNull: Throwable): Unit = {}
    }
    val query: StreamingQuery = ds.writeStream //StreamingQuery inbuild type in Spark
      .queryName("ProductDetails")
      .foreach(writer)
      .start()

    //Save to File system (Normal file system/hdfs file system/amazon file system (S3)
    val filesSystemQuery = ds.writeStream.outputMode("append")
      .format("parquet") //Or CSV, TXT, ORC, JSON
      .option("checkpointLocation", "src/main/resource/")
      .option("path", "src/main/Products").start()
    filesSystemQuery.awaitTermination()
    query.awaitTermination()

    val newDF = spark.read.parquet("src/main/Products");
    newDF.show()

    newDF.createOrReplaceTempView("temp_table")
    //val dfaggregate = spark.sql("select count(Id) as count,Id, firstName from temp_table group by Id, firstName")
    //dfaggregate.show()


  }
}
