import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.{from_json, udf}
import org.apache.spark.sql.types.{DataTypes, StructType}

object TestCSVJoinPerformance {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()

    //Elastic Search
    conf.set("es.index.auto.create", "true")
    conf.set("spark.es.nodes", "localhost")
    conf.set("spark.es.port", "9200")
    conf.set("spark.es.nodes.wan.only", "true")

    val spark = SparkSession.builder.config(conf).master("local").appName("KafkaSparkStreaming").getOrCreate()
    val rootLogger = Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)


    spark.read.option("header", true).csv("src/main/resource/Classification.csv").createOrReplaceTempView("classification")
    //spark.read.option("header", true).csv("src/main/resource/Classification.csv").show()
    spark.read.option("header", true).csv("src/main/resource/User.csv").createOrReplaceTempView("user")

    import spark.implicits._
    //Read from kafka

    val input = spark.readStream.format("kafka")
      .option("kafka.bootstrap.servers", "localhost:9092")
      .option("subscribe", "products")
      .option("failOnDataLoss", false)
      .option("startingOffsets", "latest").load()

    val df = input.selectExpr("CAST(value AS STRING)")

    val struct = new StructType()
      .add("UserAccount", DataTypes.StringType)
      .add("UserDomain", DataTypes.StringType)
      .add(name = "AppName", DataTypes.StringType)
      .add(name = "WindowTitle", DataTypes.StringType)
      .add(name = "BrowserUrl", DataTypes.StringType)
      .add(name = "StartTime", DataTypes.StringType)
      .add(name = "EndTime", DataTypes.StringType)
      .add(name = "TimeSpent", DataTypes.StringType)
      .add(name = "VersionId", DataTypes.StringType)
      .add(name = "CreatedOn", DataTypes.StringType)
      .add(name = "OperatingSystem", DataTypes.StringType)

    val personNestedDf = df.select(from_json($"value", struct).as("AppWatcher"))
    var personFlattenedDf = personNestedDf.selectExpr("AppWatcher.UserAccount", "AppWatcher.UserDomain",
      "AppWatcher.AppName", "AppWatcher.WindowTitle", "AppWatcher.BrowserUrl", "AppWatcher.StartTime",
      "AppWatcher.EndTime", "AppWatcher.TimeSpent", "AppWatcher.VersionId",
      "AppWatcher.CreatedOn", "AppWatcher.OperatingSystem")

    //Scala functions - Normal functions/variables
    val secFunc: String => Float = TimeSpent => {
      val time = TimeSpent.split(":")
      val hour = time(0).toInt * 3600
      val min = time(1).toInt * 60
      val sec = time(2).toDouble
      (hour + min + sec).toFloat
    }
    //spark-sql functions - UDF etc
    val secUdf: UserDefinedFunction = udf(secFunc, DataTypes.FloatType)
    personFlattenedDf = personFlattenedDf.withColumn("timeSec", secUdf.apply($"TimeSpent"))
    //withColumn will accept only spark sql function and not scala function


    personFlattenedDf.createOrReplaceTempView("temp")

    val resultDF = spark.sql("select temp.*,classification.Classification from temp join" +
      " user on user.User = temp.UserAccount" +
      " join classification on user.PackageID = classification.PackageID ")
    // Write to Console
    personFlattenedDf.writeStream.format("console").start()

    //Save to ElasticSearch DB
    personFlattenedDf.writeStream.format("es")
      .option("checkpointLocation", "src/main/resource/")
      //.outputMode(OutputMode.Append())
      .start("testcsv/testscvinsert")

   spark.streams.awaitAnyTermination()
  }
}