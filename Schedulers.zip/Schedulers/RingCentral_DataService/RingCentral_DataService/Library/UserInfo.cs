﻿using RingCentral_DataService.Entity;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RingCentral_DataService.Library
{
    public class UserInfo
    {
        public List<ARC_AR_Callrecoding> GetIncompleteUsers(string[] excludeUsers)
        {
            List<ARC_AR_Callrecoding> users = new List<ARC_AR_Callrecoding>();
            DateTime fromdt = DateTime.Now.AddDays(-7);

            using (var entity = new AhsPlatformEntities())
            {
                users = (from a in entity.ARC_AR_Callrecoding
                         where a.RecordingID == null || a.RecordingURL == null || a.Duration == null || (a.Duration.HasValue && a.Duration.Value<0)
                         && a.CreatedBy!=null 
                         && a.Createddate > fromdt
                         && !excludeUsers.Contains(a.CreatedBy) 
                         select a).ToList();
            }

            return users;
        }

        public void UpdateIncompleteUsers(List<ARC_AR_Callrecoding> users)
        {
            ARC_AR_Callrecoding user = null;
            using (var entity = new AhsPlatformEntities())
            {
                foreach (var item in users)
                {
                    user = entity.ARC_AR_Callrecoding.Where(x => x.Uniqueid == item.Uniqueid).FirstOrDefault();

                    if (user != null)
                    {
                        user.CallEndTime = user.CallEndTime ?? item.CallEndTime;
                        user.Duration = user.Duration ?? item.Duration;
                        user.RecordingID = user.RecordingID ?? item.RecordingID;
                        user.RecordingURL = user.RecordingURL ?? item.RecordingURL;
                    }

                    entity.SaveChanges();
                }
            }
        }

        public void UpdateIncompleteUser(ARC_AR_Callrecoding user)
        {
            using (var entity = new AhsPlatformEntities())
            {
                var tempUser = entity.ARC_AR_Callrecoding.Where(x => x.Uniqueid == user.Uniqueid).FirstOrDefault();
                var c3Temp = entity.C3_VoiceCallInfo.Where(x => x.Uniqueid == user.Uniqueid).FirstOrDefault();
                if (tempUser != null)
                {
                    tempUser.CallEndTime = tempUser.CallEndTime ?? user.CallEndTime;
                    tempUser.Duration = tempUser.Duration ?? user.Duration;
                    tempUser.RecordingID = tempUser.RecordingID ?? user.RecordingID;
                    tempUser.RecordingURL = tempUser.RecordingURL ?? user.RecordingURL;
                }
                if(c3Temp!=null)
                {
                    c3Temp.CallEndTime = c3Temp.CallEndTime ?? user.CallEndTime;
                    c3Temp.Duration = c3Temp.Duration < 0 ? user.Duration??0 : c3Temp.Duration;
                    c3Temp.RecordingID = c3Temp.RecordingID ?? user.RecordingID;
                    c3Temp.RecordingURL = c3Temp.RecordingURL ?? user.RecordingURL;
                }

                entity.SaveChanges();
            }
        }
    }
}
