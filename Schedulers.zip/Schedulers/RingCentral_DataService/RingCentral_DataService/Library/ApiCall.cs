﻿using RingCentral;
using RingCentral_DataService.Entity;
using RingCentral_DataService.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RingCentral_DataService.Library
{
    public class ApiCall
    {
        //const string RINGCENTRAL_CLIENTID = "sIB1fdhkSXi2DJ6IuKns9w";
        //const string RINGCENTRAL_CLIENTSECRET = "n_wDqKWcRLeR12Q5EvSGXAtwr67ivgTla7-U8W1rUEQg";

        //const string RINGCENTRAL_USERNAME = "+14697084011";
        //const string RINGCENTRAL_PASSWORD = "15091987RCSSO5";
        //const string RINGCENTRAL_EXTENSION = "143";
        //const string RINGCENTRAL_PRODUCTION = "https://platform.ringcentral.com";

        public async Task<List<string>> UpdateInformation(List<ARC_AR_Callrecoding> users)
        {
            List<string> unmodifiedUnique = new List<string>();
            for (int i = 0; i < users.Count; i++)
            {
                users[i] =await GetInfoFromApi(users[i]);
                if(!string.IsNullOrEmpty(users[i].RecordingID))
                {
                    new UserInfo().UpdateIncompleteUser(users[i]);
                }
                else
                {
                    unmodifiedUnique.Add(users[i].Uniqueid);
                }
                System.Threading.Thread.Sleep(500);
            }

            return unmodifiedUnique;
        }

        private static async Task<ARC_AR_Callrecoding> GetInfoFromApi(ARC_AR_Callrecoding user)
        {
            string accountId = "~";
            ReadCompanyCallLogParameters readCompanyCallLogParameters = new ReadCompanyCallLogParameters
            {
                //extensionNumber = "<ENTER VALUE>",
                //phoneNumber = "<ENTER VALUE>",
                //direction = new[] { "Inbound", "Outbound" },
                //type = new[] { "Voice", "Fax" },
                view = "Detailed",
                //withRecording = true,
                //recordingType = 'Automatic',
                //dateFrom = "<ENTER VALUE>",
                //dateTo = "<ENTER VALUE>",
                //page = 1,
                //perPage = 100,
                sessionId = user.Uniqueid
            };

            RestClient rc = new RestClient(
                Config.RINGCENTRAL_CLIENTID,
                Config.RINGCENTRAL_CLIENTSECRET,
                Config.RINGCENTRAL_PRODUCTION
            );
            await rc.Authorize(
                Config.RINGCENTRAL_USERNAME,
                Config.RINGCENTRAL_EXTENSION,
                Config.RINGCENTRAL_PASSWORD
            );
            var r = await rc.Restapi().Account(accountId).CallLog().List(readCompanyCallLogParameters);

            if(r!=null && r.records!=null && r.records.Any())
            {
                var callRecord = r.records.FirstOrDefault();
                var callDuration = Convert.ToDouble(callRecord.duration ?? 0);
                user.CallEndTime = user.CallInitiatedTime.HasValue ? user.CallInitiatedTime.Value.AddSeconds(callDuration) : user.CallEndTime;
                user.Duration = Convert.ToInt32(callDuration);
                user.RecordingID = callRecord.recording?.id;
                user.RecordingURL = callRecord.recording?.uri;
            }

            return user;
        }
    }
}
