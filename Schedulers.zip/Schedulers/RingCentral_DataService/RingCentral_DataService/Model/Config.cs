﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RingCentral_DataService.Model
{
    class Config
    {
        public static string RINGCENTRAL_CLIENTID
        {
            get
            {
                return ConfigurationManager.AppSettings["RINGCENTRAL_CLIENTID"];
            }
        }
        public static string RINGCENTRAL_CLIENTSECRET
        {
            get
            {
                return ConfigurationManager.AppSettings["RINGCENTRAL_CLIENTSECRET"];
            }
        }
        public static string RINGCENTRAL_USERNAME
        {
            get
            {
                return ConfigurationManager.AppSettings["RINGCENTRAL_USERNAME"];
            }
        }
        public static string RINGCENTRAL_EXTENSION
        {
            get
            {
                return ConfigurationManager.AppSettings["RINGCENTRAL_EXTENSION"];
            }
        }
        public static string RINGCENTRAL_PASSWORD
        {
            get
            {
                return ConfigurationManager.AppSettings["RINGCENTRAL_PASSWORD"];
            }
        }
        public static string RINGCENTRAL_PRODUCTION
        {
            get
            {
                return ConfigurationManager.AppSettings["RINGCENTRAL_PRODUCTION"];
            }
        }
    }
}
