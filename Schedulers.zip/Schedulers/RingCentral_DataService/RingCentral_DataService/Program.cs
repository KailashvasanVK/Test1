﻿using RingCentral_DataService.Entity;
using RingCentral_DataService.Library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RingCentral_DataService
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] excludeUsers = new string[] { "Amos Gnanaraj", "Balakumar M", "Balamudhan R", "kailashvasan vk", "kailashvasan.vk", "Vignesh J" };

            try
            {
                RunTask(excludeUsers).Wait();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            Console.ReadKey();
        }

        static async Task RunTask(string[] excludeUsers)
        {
            var data = new UserInfo().GetIncompleteUsers(excludeUsers);
            //List<ARC_AR_Callrecoding> data = new List<ARC_AR_Callrecoding>()
            //{
            //    new ARC_AR_Callrecoding()
            //    {
            //        Uniqueid="347083975020"
            //    }
            //};
            var uniqueIds = await new ApiCall().UpdateInformation(data);
            //new UserInfo().UpdateIncompleteUsers(data);
        }
    }
}
