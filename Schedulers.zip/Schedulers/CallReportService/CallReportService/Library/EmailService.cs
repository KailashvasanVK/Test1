﻿using CallReportService.Model;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Net;
using System.Text;
using System.Web.Script.Serialization;

namespace CallReportService.Library
{
    public class EmailService
    {
        public void SendEmailService(string body)
        {
            try
            {
                UserAuth dataUser = new UserAuth()
                {
                    ID = "1",
                    FirstName = string.Empty,
                    LastName = string.Empty,
                    Username = Configuration.UserName,
                    Password = Configuration.UserPassword,
                    Token = string.Empty,
                    Role = "ADMIN"
                };

                using (WebClient client = new WebClient())
                {
                    client.Headers["Content-type"] = "application/json";
                    client.Encoding = Encoding.UTF8;
                    var responseToken = client.UploadString(Configuration.userAuthUrl, new JavaScriptSerializer().Serialize(dataUser));

                    if (null != responseToken)
                    {
                        UserAuth objToken = new JavaScriptSerializer().Deserialize<UserAuth>(responseToken);

                        SendEmail dataEmail = new SendEmail()
                        {
                            RequestId = 1234,
                            From = Configuration.UserEmail,
                            To = Configuration.ToEmail,
                            Cc = "",
                            Subject = "Ring central softphone - AR Call usage details",
                            IsHTML = 'Y',
                            Body = body,
                            MailStatus = 1,
                            CreatedDate = Convert.ToString(DateTime.Now.Date),
                            CreatedBy = Environment.UserName,
                            Filecontent = string.Empty,
                            FilePath = string.Empty,
                            Exception = string.Empty,
                            AppId = 123
                        };

                        using (WebClient clientEmail = new WebClient())
                        {
                            clientEmail.Headers["Content-type"] = "application/json";
                            clientEmail.Headers["Token"] = objToken.Token;
                            clientEmail.Headers["UserName"] = Configuration.UserName;
                            clientEmail.Encoding = Encoding.UTF8;

                            var response = clientEmail.UploadString(Configuration.EmailUrl, new JavaScriptSerializer().Serialize(dataEmail));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public string ComposeEmail(List<CallDataReportModel> callDataReports)
        {
            string bodyContent = string.Empty;

            bodyContent = "<p>Hi Team,</p>"
                                + "<p> Please find the call data. </p><br/>"
                                + "<table border='1'>"
                                + "    <thead>"
                                + "        <tr>"
                                + "            <th>SNo.</th>"
                                + "            <th>Date</th>"
                                + "            <th>Client Partner</th>"
                                + "            <th>Last Call Time</th>"
                                + "            <th>Last Call Status</th>"
                                + "            <th>Total Calls</th>"
                                + "        </tr>"
                                + "    </thead>"
                                + "    <tbody>";
            if(callDataReports.Count>0)
            {
                for (int i = 0; i < callDataReports.Count; i++)
                {
                    bodyContent += $"<tr>            <td>{i + 1}</td>"
                 + $"            <td>{callDataReports[i].Date.ToString("dd/MM/yyyy")}</td>"
                 + $"            <td>{callDataReports[i].Username}</td>"
                 + $"            <td>{(callDataReports[i].LastCallTime.HasValue ? callDataReports[i].LastCallTime.Value.ToString() : "-")}</td>"
                 + $"            <td>{callDataReports[i].LastCallStatus}</td>"
                 + $"            <td>{callDataReports[i].TotalCalls}</td> </tr>";
                }
            }
            else
            {
                bodyContent += $"<td colspan='6'>No call records found</td>";
            }
            

            bodyContent +="    </tbody>"
              + "</table><br/>"
              + "Regards,<br/> Team Innovation - AHS <br/><br/>"
              + "<b> ******This is an auto generated mail.Please do not reply. ****** </b>";

            return bodyContent;
        }

        public void SendMail(string mailBody, string mailSubject, string to, string cc)
        {
            string stDate = Convert.ToString(DateTime.Now.Date.ToString("dd/MMM/yyyy"));

            //From
            string From = "mail.support@accesshealthcare.co";
            mailBody = mailBody.Replace("'", "\"");
            //Isthml
            string isthml = "Y";

            using (SqlConnection conn = new SqlConnection("Data source=SQL-Listner; Persist Security Info=false; Initial Catalog=ARC_REC; UID=Docmenttooluser; PWD=D@cum@ntt@@lu5@r;pooling=false;multisubnetfailover=true;"))
            {
                using (SqlCommand cmd = new SqlCommand("Exec SP_INS_ARC_REC_MAIL_TRAN '" + From + "','" + to + "','" + cc + "','" + mailSubject + "','" + mailBody + "','" + isthml + "',''", conn))
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
        }
    }
}
