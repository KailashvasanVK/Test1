﻿using CallReportService.Entity;
using CallReportService.Model;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CallReportService.Library
{
    public class CallReport
    {
        public List<CallDataReportModel> GetCallReport(string[] agents, DateTime fromDate, DateTime toDate)
        {
            List<CallDataReportModel> callDataReports = new List<CallDataReportModel>();
            //DateTime fromTime = DateTime.Now.Date.AddHours(18);
            //DateTime toTime = DateTime.Now.AddDays(1).Date.AddHours(3);
            using (var entity = new AhsPlatformEntities())
            {
                callDataReports = (from a in entity.C3_VoiceCallInfo
                                   where a.Createddate >= fromDate && a.Createddate <= toDate && !agents.Contains(a.CreatedBy) && a.CreatedBy!=null && a.CreatedBy != string.Empty
                                   group a by a.CreatedBy
                                  into grpCreatedBy
                                   select new CallDataReportModel
                                   {
                                       Date = fromDate,
                                       LastCallStatus = grpCreatedBy.OrderByDescending(x => x.Createddate).Select(x => x.CallEndTime == null ? "In Progress" : "Completed").FirstOrDefault(),
                                       LastCallTime = grpCreatedBy.OrderByDescending(x=>x.Createddate).FirstOrDefault().Createddate,
                                       TotalCalls = grpCreatedBy.Count(),
                                       Username = grpCreatedBy.Key
                                   }).ToList();

                //foreach (var item in agents)
                //{
                //    if(!callDataReports.Any(x=>x.Username == item))
                //    {
                //        callDataReports.Add(new CallDataReportModel()
                //        {
                //            Date = fromDate,
                //            LastCallStatus = "-",
                //            LastCallTime = null,
                //            TotalCalls = 0,
                //            Username = item
                //        });
                //    }
                //}
            }

            return callDataReports;
        }
    }
}
