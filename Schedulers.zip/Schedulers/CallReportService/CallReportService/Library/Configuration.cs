﻿using System;
using System.Configuration;
using System.IO;

namespace CallReportService.Library
{
    public class Configuration
    {
        public static string userAuthUrl
        {
            get
            {
                return ConfigurationManager.AppSettings["userAuthUrl"];
            }
        }

        public static string EmailUrl
        {
            get
            {
                return ConfigurationManager.AppSettings["emailUrl"];
            }
        }

        public static string UserName
        {
            get
            {
                return ConfigurationManager.AppSettings["userName"];
            }
        }

        public static string UserEmail
        {
            get
            {
                return ConfigurationManager.AppSettings["userEmail"];
            }
        }

        public static string UserPassword
        {
            get
            {
                return ConfigurationManager.AppSettings["userPassword"];
            }
        }

        public static string ToEmail
        {
            get
            {
                return ConfigurationManager.AppSettings["toEmail"];
            }
        }

        public static string CCEmail
        {
            get
            {
                return ConfigurationManager.AppSettings["ccEmail"];
            }
        }

        public string[] GetConfiguredUsers()
        {
            string[] users = null;

            string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", "Agents.txt");

            if (!File.Exists(filePath))
            {
                throw new ArgumentException("Agent file path does not exists");
            }

            var data = File.ReadAllText(filePath);

            users = data != null && data.Length > 0 ? data.Split(',') : null;

            //for (int i = 0; i < users.Length; i++)
            //{
            //    users[i] = users[i].Replace('.', ' ');
            //}

            return users;
        }
    }
}
