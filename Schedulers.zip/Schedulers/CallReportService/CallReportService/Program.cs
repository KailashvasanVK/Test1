﻿using CallReportService.Library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CallReportService
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                var data = new Configuration().GetConfiguredUsers();
                DateTime from = DateTime.Now.Hour <= 3 ? DateTime.Now.AddDays(-1).Date.AddHours(18) : DateTime.Now.Date.AddHours(18);
                //DateTime from = DateTime.Now.AddDays(-1).Date.AddHours(18);
                DateTime to = DateTime.Now.Hour <= 3 ? DateTime.Now.Date.AddHours(3) : DateTime.Now.AddDays(1).Date.AddHours(3);
                var userReport = new CallReport().GetCallReport(data, from, to);
                var emailService = new EmailService();
                var messageBody = emailService.ComposeEmail(userReport);
                emailService.SendMail(messageBody, "Ring central softphone - AR Call usage details", Configuration.ToEmail, Configuration.CCEmail);
            }
            catch (Exception ex)
            {
            }
        }
    }
}
