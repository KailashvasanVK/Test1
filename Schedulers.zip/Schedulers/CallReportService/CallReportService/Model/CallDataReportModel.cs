﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CallReportService.Model
{
    public class CallDataReportModel
    {
        public DateTime Date { get; set; }
        public string Username { get; set; }
        public DateTime? LastCallTime { get; set; }
        public string LastCallStatus { get; set; }
        public int TotalCalls { get; set; }
    }
}
