import { Component, OnInit } from '@angular/core';
import {AthenaTransactDataService} from '../../Services/athena-transact-data.service'
import {DatePipe} from '@angular/common'
import {athenaTransactData} from "../../../shared/athena-transact-model"
//import * as Highcharts  from 'angular-highcharts';
import * as Highcharts from 'highcharts';
import { analyzeAndValidateNgModules } from '@angular/compiler';

declare var require: any;
let Boost = require('highcharts/modules/boost');
let noData = require('highcharts/modules/no-data-to-display');
let More = require('highcharts/highcharts-more');

Boost(Highcharts);
noData(Highcharts);
More(Highcharts);
noData(Highcharts);


@Component({
  selector: 'app-athena',
  templateUrl: './athena.component.html',
  styleUrls: ['./athena.component.css']
})
export class AthenaComponent implements OnInit {
  constructor(private service: AthenaTransactDataService, datePipe:DatePipe) {
    this.startdate = new Date();
    this.enddate =  new Date();
    this.procesnames =  [];
    this.totaltransactioncount = [];
    this.eligibletransactioncount = [];    
  }

  startdate: Date;
  enddate: Date;
  resultobj: any;
  procesnames:  string[];
  totaltransactioncount: number[];
  eligibletransactioncount: number[];
  transcount: test[];
  a: string;
  b: string;
  c: string;
  ClusterTrans: number;
  CategoryWiseTransactionCount: any
  num: any
  total:any  
  clusterPercentage: any;
  automationPercentage:any;
  insurancePercentage:any;
  precallPercentage: any;
  preliminaryPercentage: any;
  DateList: any;
  ChartData: any;

  ngOnInit() {
    this.getAthenaTransactData();   
  }

  highcharts = Highcharts ;
  chartOptions:any = {   
     chart: {
        type: 'column',
        //renderTo: 'PayerData'
     },
      title: {
          text: 'Athena Bot Process'
      },
      subtitle: {
          text: 'Source: WorldClimate.com'
      },
      xAxis: {
          //categories: this.procesnames,
          categories:[],
          //categories: [this.a],
          //categories: [
        //     'Jan',
        //     'Feb'     
        // ],
          crosshair: true
      },
      yAxis: {
          min: 0,
          title: {
              text: 'Transaction (count)'
          }
      },
      tooltip: {
          headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
          pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
              '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
          footerFormat: '</table>',
          shared: true,
          useHTML: true
      },
      plotOptions: {
          column: {
              pointPadding: 0.2,
              borderWidth: 0
          }
      },
      series: []
      // [{
      //     name: 'Total Transactions',
      //     //data: this.totaltransactioncount 
      //     data: [this.b]
      // }, {
      //     name: 'Eligible Transactions',
      //     //data: [this.eligibletransactioncount]
      //     data: [this.c]
      // }]     
      
    //   [{
    //     name: 'Tokyo',
    //     data: [49.9, 71.5, 106.4, 129.2, 144.0, 176.0, 135.6, 148.5, 216.4, 194.1, 95.6, 54.4,
    //       49.9, 71.5, 106.4, 129.2, 144.0, 176.0, 135.6, 148.5, 216.4, 194.1, 95.6, 54.4,
    //         49.9, 71.5]

    // }, {
    //     name: 'New York',
    //     data: [49.9, 71.5, 106.4, 129.2, 144.0, 176.0, 135.6, 148.5, 216.4, 194.1, 95.6, 54.4,
    //       49.9, 71.5, 106.4, 129.2, 144.0, 176.0, 135.6, 148.5, 216.4, 194.1, 95.6, 54.4,
    //         49.9, 71.5]

    // }]
  } 

    chartOptionsPie:any = {   
      chart : {
        //  plotBorderWidth: null,
        //  plotShadow: false
         plotBackgroundColor: null,
         plotBorderWidth: 0,
         plotShadow: false,
         margin: [20, 20, 20, 20],
         spacingTop: 15,
         spacingBottom: 15,
         spacingLeft: 15,
         spacingRight: 15
      },
      title : {
        text: '<span style="font-family: "proxima_nova_rgregular", arial !important; font-weight: bold;">' + 100 + 
        '</span> <br/> <span style="font-size: 10px;">Total Trans</span>',
        align: 'center',
        verticalAlign: 'middle',
        y: 15,
        style: {
            color: '#000',
            fontWeight: 'bold',
            fontSize: '21px',
        }
      },
      tooltip : {
         //pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
      },
      plotOptions : {
         pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            innerSize: '80%',      
            dataLabels: {
               enabled: false           
            },
            startAngle: -90,
            endAngle: 270,
            center: ['50%', '50%'],
            size: '130%',
      
            showInLegend: false
         }
      },
      series : [
        {
          type: 'pie',
          name: 'Category wise transation count',
          data: [
             ['Firefox',   45.0],
             ['IE',       26.8],
             {
                name: 'Chrome',
                y: 12.8,
                sliced: true,
                selected: true
             },
             ['Safari',    8.5],
             ['Opera',     6.2],
             ['Others',      0.7]
          ]
       }
      ]
   };
   //Line Charts - Highcharts
   chartOptionsLine:any = {   
    chart: {
       type: "spline"
    },
    title: {
       text: "Daywise Transaction Trends"
    },
   //  subtitle: {
   //     text: "Source: WorldClimate.com"
   //  },
    xAxis:{
       categories:["Jan", "Feb", "Mar", "Apr", "May", "Jun",
          "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    },
    yAxis: {          
       title:{
          text:"Total Transactions"
       } 
    },
    tooltip: {
       valueSuffix:" °C"
    },
    series: [{
       name: 'Tokyo',
       data: [7.0, 6.9, 9.5, 14.5, 18.2, 21.5, 25.2,26.5, 23.3, 18.3, 13.9, 9.6]
    },
    {
       name: 'New York',
       data: [-0.2, 0.8, 5.7, 11.3, 17.0, 22.0, 24.8,24.1, 20.1, 14.1, 8.6, 2.5]
    },
    {
       name: 'Berlin',
       data: [-0.9, 0.6, 3.5, 8.4, 13.5, 17.0, 18.6, 17.9, 14.3, 9.0, 3.9, 1.0]
    },
    {
       name: 'London',
       data: [3.9, 4.2, 5.7, 8.5, 11.9, 15.2, 17.0, 16.6, 14.2, 10.3, 6.6, 4.8]
    }]
 };

   percentage(num, Total) {
    return ((parseInt(num) / parseInt(Total)) * 100).toFixed(1);
}
 
  
  getAthenaTransactData(){
    this.service.getdaywisetransactcount("http://localhost:60182/AthenaTransactions/GetAthenaTransactData")
    .subscribe(
       res => {
         setTimeout(() => {
          this.resultobj = res;
          this.ChartData = this.resultobj.ChartData;
          this.DateList = this.resultobj.DateList;
          this.CategoryWiseTransactionCount = this.resultobj.CategoryWiseTransactionCounts;
          this.transcount = this.resultobj.OverallTransactionCounts;
          this.resultobj = this.resultobj.OverallDataTrendsCloned;
          if (this.transcount.length > 0) {
            for (let j = 0; j < this.transcount.length; j++) {
              this.procesnames.push(this.transcount[j].ProcessName);
              this.totaltransactioncount.push(+this.transcount[j].TotalTransactionCount);
              this.eligibletransactioncount.push(+this.transcount[j].EligibleTransactionCount);             
            }
            this.chartOptions.xAxis.categories = this.procesnames;
            this.chartOptions.series.push({ name: 'Bot Running Count', data:  this.totaltransactioncount });
            this.chartOptions.series.push({ name: 'Bot Running Count12', data: this.eligibletransactioncount });
            this.chartOptionsPie.series.data = []
            for (let k=0; k< this.CategoryWiseTransactionCount.length; k++){
              this.chartOptionsPie.series.data.push(this.CategoryWiseTransactionCount[k].Category, 
                this.CategoryWiseTransactionCount[k].TotalTransactionCount);
            }            
            Highcharts.chart('PayerData', this.chartOptions); 
            Highcharts.chart('pieCategoryTransCount', this.chartOptionsPie);

            this.clusterPercentage = this.percentage(this.CategoryWiseTransactionCount[0].EligibleTransactionCount, this.CategoryWiseTransactionCount[0].TotalTransactionCount)
            this.automationPercentage = this.percentage(this.CategoryWiseTransactionCount[1].EligibleTransactionCount, this.CategoryWiseTransactionCount[1].TotalTransactionCount)
            this.insurancePercentage = this.percentage(this.CategoryWiseTransactionCount[2].EligibleTransactionCount, this.CategoryWiseTransactionCount[2].TotalTransactionCount)
            this.precallPercentage = this.percentage(this.CategoryWiseTransactionCount[3].EligibleTransactionCount, this.CategoryWiseTransactionCount[3].TotalTransactionCount)
            this.preliminaryPercentage = this.percentage(this.CategoryWiseTransactionCount[4].EligibleTransactionCount, this.CategoryWiseTransactionCount[4].TotalTransactionCount)

            this.chartOptionsLine.xAxis.categories = [];
            this.chartOptionsLine.series = [];
            this.chartOptionsLine.xAxis.categories = this.DateList;    
            for (let l=0; l< this.ChartData.length; l++){        
            this.chartOptionsLine.series.push({ name:this.ChartData[l].name , data:  this.ChartData[l].data });
            }
            Highcharts.chart('lineCategoryTransCount', this.chartOptionsLine);                     
          }     
         }, 10000);               
       },       
       err => {
         console.log(err.message);    
         }          
     );
  }
}

export class test{
  id: any;
  ProcessName: string;
  Category: string;
  TotalTransactionCount: string;
  EligibleTransactionCount: string;
}



       
 