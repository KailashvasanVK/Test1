import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AthenaComponent } from './Athena/athena/athena.component';
import {DxDataGridModule, DxTemplateModule, DxBulletModule} from 'devextreme-angular'
import {DatePipe} from '@angular/common' 
import {AthenaTransactDataService} from "../../src/app/Services/athena-transact-data.service"
//import { ChartModule } from 'angular-highcharts';
import { HighchartsChartComponent } from 'highcharts-angular';

@NgModule({
  //Declarations: Components, pipes, directives
  declarations: [
    AppComponent,
    AthenaComponent,
    HighchartsChartComponent    
    //DatePipe
  ],
  //Imports: other modules
  imports: [
    BrowserModule,
    AppRoutingModule,
    DxDataGridModule,
    DxTemplateModule,
    DxBulletModule,
    HttpClientModule,
    //ChartModule 
  ],
  //Providers: services
  providers: [AthenaTransactDataService,DatePipe],
  bootstrap: [AppComponent],
  //exports: [DatePipe]
})
export class AppModule { }
