import { TestBed } from '@angular/core/testing';

import { AthenaTransactDataService } from './athena-transact-data.service';

describe('AthenaTransactDataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AthenaTransactDataService = TestBed.get(AthenaTransactDataService);
    expect(service).toBeTruthy();
  });
});
