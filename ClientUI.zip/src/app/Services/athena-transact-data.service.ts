import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders, HttpParams} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AthenaTransactDataService {

  constructor(private http: HttpClient) { }
   
  getdaywisetransactcount(url: any){
    // let parameter = new HttpParams();
    // parameter = parameter.append('startdate', startdate.toString());
    // parameter = parameter.append('enddate', enddate.toString());  
   //return this.http.get(url, {params: parameter, withCredentials: true});
   return this.http.get(url);
  }
}
