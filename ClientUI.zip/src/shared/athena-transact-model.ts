export class athenaTransactData{   
    ProcessName: string;
    Category: string;
    Date1: string;
    Date2: string;
    Date3: string; 
}