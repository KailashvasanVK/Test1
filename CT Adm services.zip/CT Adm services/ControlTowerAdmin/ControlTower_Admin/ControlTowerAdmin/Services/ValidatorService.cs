﻿using ControlTowerAdmin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading.Tasks;

namespace ControlTowerAdmin.Services
{
    public static class ValidatorService
    {
        public static async Task<string> ValidateLicenseAsync(AhsPlatformEntities db, Guid? processId, Guid? clientId)
        {
            var process = await db.echobot_lic_process.FindAsync(processId);
            var client = await db.echobot_lic_botClient.FindAsync(clientId);
            var company = await db.echobot_lic_companyDetails.FindAsync(process?.company_id);
            int compare = DateTime.Compare(company.validTo, DateTime.Now);
            if (process == null)
            {
                return ("Invalid Service key");
            }
            if (client == null)
            {
                return ("Invalid Bot client id");
            }
            if (company == null)
            {
                return ("License not found");
            }
            if (compare < 0)
            {
                return ("License expired! Kindly renew.");
            }
            return "1";
        }
    }
}