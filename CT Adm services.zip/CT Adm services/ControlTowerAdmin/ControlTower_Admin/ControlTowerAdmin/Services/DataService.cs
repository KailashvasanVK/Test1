﻿using ControlTowerAdmin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ControlTowerAdmin.Services
{
    public class DataService
    {
        public AhsPlatformEntities context;
        public DataService(AhsPlatformEntities db)
        {
            context = db;
        }

        public echobot_lic_companyDetails GetCompanyByClientKey(string publicKey)
        {
            var record = context.echobot_lic_companyDetails.FirstOrDefault(p => p.PublicLicenseKey == publicKey);
            return record;
        }
        public echobot_lic_companyDetails GetCompanyById(Guid id)
        {
            var record = context.echobot_lic_companyDetails.FirstOrDefault(p => p.id == id);
            return record;
        }
    }
}