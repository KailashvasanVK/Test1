﻿using ControlTowerAdmin.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web.Http;

namespace ControlTowerAdmin.Controllers
{
    [RoutePrefix("Dashboard")]
    public class DashboardController : ApiController
    {
        private static readonly AhsPlatformEntities db = new AhsPlatformEntities();
        private static readonly LABEntities dbLab = new LABEntities();
        private static readonly string connStr_ILAthena = "Data source=AHS-HQ-DEVDB,30786; Initial Catalog=IL_Athena;UId=ILautomation; PWD=!L@ut03@t!0n;pooling=false;";
        private static readonly string connStr_Lab_Test = "Data source=172.19.7.26,30786; Persist Security Info=false; Initial Catalog=LAB_183; UID=AppMLUser; PWD=App@#mlU$#r!2@16;pooling=false;";
        private static readonly string connstr_BrightTree = "Data source=dotflowlistner.accesshealthcare.co,30786; Persist Security Info = false; Initial Catalog=ARC_AR_V1; UID=arcflowdt; PWD=8S48A510sfersona3df996!@14$76A56B;pooling=false;";
        private static readonly string connstr_Athena_Live = "Data source=SQL-Listner; Persist Security Info = false; Initial Catalog=ARC_AR_Athena; UID=Docmenttooluser; PWD=D@cum@ntt@@lu5@r;pooling=false;multisubnetfailover=true;";
        private static readonly string connstr_EchoPay = "Data Source=SQL-Listner;Initial catalog=ARC_ATHENA;User id=offlineAppuser;PWD=offline@app$2@16; multisubnetfailover=true;application name=echoPay;pooling = true;Network Library=dbmssocn;";
        private static int Servers = 0;
        private static DataTable dt = new DataTable();
        private static DataTable dtEchoRev = new DataTable();
        private static DataTable dtAthenaDocEngineUsage = new DataTable();
        private static DataTable dtBrightTreeDocEngineUsage = new DataTable();
        private static DataTable dtEchoPayUsage = new DataTable();
        private static DataTable dtTpxUsage = new DataTable();
        private static DataTable dtEchoLockUsage = new DataTable();
        private static DataTable dtDecisionTreeUsage = new DataTable();

        [HttpGet]
        [Route("GetAthenaBots")]
        public IHttpActionResult getInitialInformation()
        {
            dt = new DataTable(); Servers = 0;

            Servers = db.CT_Servers.Count(_ => _.Status == "Active");

            using (SqlConnection con = new SqlConnection(connStr_ILAthena))
            {
                using (SqlCommand cmd = new SqlCommand("SP_GetBotTransactions", con))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        cmd.CommandTimeout = 180;
                        da.Fill(dt);
                    }
                }
            }

            var result = new DashboardCount()
            {
                Server = Servers,
                Bots = dt.Rows.Count,
                Instances = Convert.ToInt32(dt.Compute("Sum(BotInstances)", string.Empty)),
                Transactions = Convert.ToInt32(dt.Compute("Sum(Transactions)", string.Empty)),
                EchoRevBots = 0,
                EchoRevInstances = 0,
                EchoRevUsage = 0,
                EchoLockUsers = 0,
                EchoLockProd = "0",
                EchoLockNonProd = "0",
                EchoPayExpectation = 0,
                EchoPayADP = 0,
                EchoPay = 0,
                EchoPaySDE = 0,
                DTBots = 0,
                DTInstances = 0,
                DTTransactions = 0
            };

            return Ok(result);
        }

        [HttpGet]
        [Route("GetNonathenaBots")]
        public IHttpActionResult getNonAthenaBotsInformation()
        {
            DataTable dtTemp = new DataTable();

            using (SqlConnection conn = new SqlConnection(connStr_Lab_Test))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT PROJECT_NAME AS [Process] , COUNT(DISTINCT(UserName)) AS BotInstances, COUNT(UserName) AS [Transactions] FROM ECHOBOT_TRANSACTIONLOG_INFO WHERE [STATUS] BETWEEN 1 AND 10 AND END_TIME >= CONVERT(DATE,GETDATE()-15) GROUP BY PROJECT_NAME,PROCESS_TYPE,PROCESS_NAME", conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dtTemp);
                    }
                }
            }

            foreach (DataRow dr in dtTemp.Rows)
            {
                DataRow d = dt.NewRow();
                d["LOB"] = "Non-Athena";
                d["Process"] = dr["Process"];
                d["BotInstances"] = dr["BotInstances"];
                d["Transactions"] = dr["Transactions"];
                d["Exceptions"] = 0;
                d["SearchName"] = string.Empty;
                dt.Rows.Add(d);
            }

            var result = new DashboardCount()
            {
                Server = Servers,
                Bots = dt.Rows.Count,
                Instances = Convert.ToInt32(dt.Compute("Sum(BotInstances)", string.Empty)),
                Transactions = Convert.ToInt32(dt.Compute("Sum(Transactions)", string.Empty)),
                EchoRevBots = 0,
                EchoRevInstances = 0,
                EchoRevUsage = 0,
                EchoLockUsers = 0,
                EchoLockProd = "0",
                EchoLockNonProd = "0",
                EchoPayExpectation = 0,
                EchoPayADP = 0,
                EchoPay = 0,
                EchoPaySDE = 0,
                DTBots = 0,
                DTInstances = 0,
                DTTransactions = 0
            };

            return Ok(result);
        }

        [HttpGet]
        [Route("GetNonAthenaLive")]
        public IHttpActionResult getNonAthenaLiveBots()
        {
            DateTime toDate = DateTime.Now.Date.AddDays(-15);
            var dtLab = dbLab.ECHOBOT_TRANSACTIONLOG_INFO.Where(x => x.STATUS >= 0 && x.STATUS <= 10 && x.END_TIME >= toDate).GroupBy(x => new { x.PROJECT_NAME, x.PROCESS_TYPE, x.PROCESS_NAME });

            foreach (var drLab in dtLab)
            {
                bool isExist = false;
                DataRow dr;
                if (dt.AsEnumerable().Any(x => Convert.ToString(x["Process"]).Equals(drLab.Key.PROJECT_NAME)))
                {
                    dr = dt.AsEnumerable().FirstOrDefault(x => Convert.ToString(x["Process"]).Equals(drLab.Key.PROJECT_NAME));
                    isExist = true;
                }
                else
                {
                    dr = dt.NewRow();
                    isExist = false;
                }
                dr["LOB"] = "Non-Athena";
                dr["Process"] = drLab.Key.PROJECT_NAME;
                dr["BotInstances"] = isExist ? Convert.ToInt32(dr["BotInstances"]) + drLab.GroupBy(x => x.UserName).Count() : drLab.GroupBy(x => x.UserName).Count();
                dr["Transactions"] = isExist ? Convert.ToInt32(dr["Transactions"]) + drLab.Count() : drLab.Count();
                dr["Exceptions"] = 0;
                dr["SearchName"] = string.Empty;

                if (!isExist)
                {
                    dt.Rows.Add(dr);
                }
            }

            fetchAthenaDTUsage();
            fetchBrightTreeDTUsage();
            fetchTPXUsage();
            fetchEchoLockUsage();
            fetchDesionTree();

            var result = new DashboardCount()
            {
                Server = Servers,
                Bots = dt.Rows.Count,
                Instances = Convert.ToInt32(dt.Compute("Sum(BotInstances)", string.Empty)),
                Transactions = Convert.ToInt32(dt.Compute("Sum(Transactions)", string.Empty)),
                EchoRevBots = dtEchoRev.AsEnumerable().Select(x => x["TeamName"]).Distinct().Count(),
                EchoRevInstances = dtEchoRev.Rows.Count,
                EchoRevUsage = Convert.ToInt32(dtEchoRev.Compute("Sum(Usage)", string.Empty)),
                EchoLockUsers = dtEchoLockUsage.Rows.Count,
                EchoLockProd = TimeSpan.FromSeconds(Convert.ToInt32(dtEchoLockUsage.Compute("AVG([Production])", ""))).ToString(@"hh\:mm\:ss"),
                EchoLockNonProd = TimeSpan.FromSeconds(Convert.ToInt32(dtEchoLockUsage.Compute("AVG([BreakHour])", ""))).ToString(@"hh\:mm\:ss"),
                EchoPayExpectation = 0,//Convert.ToInt32(dtEchoPayUsage.Compute("AVG(Expectation)", string.Empty)),
                EchoPayADP = 0,// Convert.ToInt32(dtEchoPayUsage.Compute("AVG(Automation_DE)", string.Empty)),
                EchoPay = 0,//Convert.ToInt32(dtEchoPayUsage.Compute("AVG(Automation_Zerotouch)", string.Empty)),
                EchoPaySDE = 0,//Convert.ToInt32(dtEchoPayUsage.Compute("AVG(Automation_SmartDE)", string.Empty))
                DTBots = 0,//dtDecisionTreeUsage.AsEnumerable().Select(x => x["TeamName"]).Distinct().Count(),
                DTInstances = 0,//dtDecisionTreeUsage.Rows.Count,
                DTTransactions = 0,//Convert.ToInt32(dtDecisionTreeUsage.Compute("Sum(Usage)", string.Empty))
            };

            return Ok(result);
        }

        [HttpGet]
        [Route("GetServers")]
        public IHttpActionResult getServers()
        {
            var result = db.CT_Servers.Where(_ => _.Status == "Active").Select(x => new ServersDetails()
            {
                IP = x.IpAddress,
                MachineName = x.MachineName
            });

            return Ok(result);
        }

        [HttpGet]
        [Route("GetProcess")]
        public IHttpActionResult getProcessInfo()
        {
            var result = dt.AsEnumerable().Select(x => new ProcessDetails()
            {
                LOB = Convert.ToString(x["LOB"]),
                ProcessName = Convert.ToString(x["Process"]),
                BotInstances = Convert.ToInt32(x["BotInstances"]),
                BotTransactions = Convert.ToInt32(x["Transactions"]),
                BotExceptions = Convert.ToInt32(x["Exceptions"]),
                BotProcessName = Convert.ToString(x["SearchName"])
            });

            return Ok(result);
        }

        [HttpGet]
        [Route("GetAthenaDTUsage")]
        public IHttpActionResult getAthenaDTUsage()
        {
            fetchAthenaDTUsage();
            return Ok(dtAthenaDocEngineUsage.ToJson());
        }

        private static void fetchAthenaDTUsage()
        {
            dtAthenaDocEngineUsage = new DataTable();
            string query = "SELECT 'Athena' AS [LOB], TM.TeamName, TR.Username, COUNT(TR.Username) AS [Usage] FROM DOC_Athena_Tracking TR "
                            + "INNER JOIN Doc_Athena_TeamMaster TM ON TR.TeamID = TM.ID "
                            + "WHERE CONVERT(DATE, TR.ProcessDate) >= CONVERT(DATE, GETDATE()-1) "
                            + "GROUP BY TM.TeamName, TR.Username "
                            + "ORDER BY TeamName, Username";
            using (SqlConnection conn = new SqlConnection(connstr_Athena_Live))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.CommandTimeout = 180;
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dtAthenaDocEngineUsage);
                    }
                }
            }

            dtEchoRev = dtAthenaDocEngineUsage.Copy();
        }

        [HttpGet]
        [Route("GetBrightTreeUsage")]
        public IHttpActionResult getBrightTreeDTUsage()
        {
            fetchBrightTreeDTUsage();
            return Ok(dtBrightTreeDocEngineUsage.ToJson());
        }

        private static void fetchBrightTreeDTUsage()
        {
            dtBrightTreeDocEngineUsage = new DataTable();
            string query = "EXEC DOC_BTAutoUsageReport_new";
            using (SqlConnection conn = new SqlConnection(connstr_BrightTree))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dtBrightTreeDocEngineUsage);
                    }
                }
            }

            foreach (DataRow dr in dtBrightTreeDocEngineUsage.Rows)
            {
                DataRow d = dtEchoRev.NewRow();
                d["LOB"] = "BrightTree";
                d["TeamName"] = dr["TeamName"];
                d["UserName"] = dr["UserName"];
                d["Usage"] = dr["Usage"];

                dtEchoRev.Rows.Add(d);
            }
        }

        [HttpGet]
        [Route("GetEchoPayUsage")]
        public IHttpActionResult getEchoPayUsage()
        {
            fetchEchoPayUsage();
            return Ok(dtEchoPayUsage.ToJson());
        }

        private static void fetchEchoPayUsage()
        {
            dtEchoPayUsage = new DataTable();
            string query = "Select UploadDate, SUM(manual) Expectation, SUM(ADP) Automation_DE, SUM(echopay) Automation_Zerotouch, SUM(echoSDE) Automation_SmartDE From echoDashboard_tOverAllTransaction(nolock) GROUP BY UploadDate ORDER BY UploadDate";
            using (SqlConnection conn = new SqlConnection(connstr_EchoPay))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dtEchoPayUsage);
                    }
                }
            }
        }

        [HttpGet]
        [Route("GetTPXUsage")]
        public IHttpActionResult getTpxUsage()
        {
            fetchEchoPayUsage();
            return Ok(dtTpxUsage.ToJson());
        }

        private static void fetchTPXUsage()
        {
            dtTpxUsage = new DataTable();
            string query = "SELECT 'TPX' AS TeamName,UserName AS UserName,DTProductionCount AS [Usage] FROM TPX_TRANSACTION_INFO WHERE DTProductionCount > 0";
            using (SqlConnection conn = new SqlConnection(connStr_Lab_Test))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dtTpxUsage);
                    }
                }
            }

            foreach (DataRow dr in dtTpxUsage.Rows)
            {
                DataRow d = dtEchoRev.NewRow();
                d["LOB"] = "TPX";
                d["TeamName"] = dr["TeamName"];
                d["UserName"] = dr["UserName"];
                d["Usage"] = dr["Usage"];

                dtEchoRev.Rows.Add(d);
            }
        }

        [HttpGet]
        [Route("GetEchoRevUsage")]
        public IHttpActionResult getEchoRevUsage()
        {
            fetchAthenaDTUsage();
            fetchBrightTreeDTUsage();
            fetchTPXUsage();
            fetchDesionTree();
            return Ok(dtEchoRev.ToJson());
        }

        [HttpGet]
        [Route("GetEchoLockUsage")]
        public IHttpActionResult getEchoLockUsage()
        {
            fetchEchoLockUsage();
            return Ok(dtEchoLockUsage.ToJson());
        }

        private static void fetchEchoLockUsage()
        {
            dtEchoLockUsage = new DataTable();
            string query = "SELECT UserAccount, MAX(LOB) LOB, MAX(Client) Client, MAX([Location]) [Location], MAX(Process) Process, Supervisor, AVG(TotalHrs) TotalHrs, AVG(Production) Production, AVG(BreakHour) BreakHour, AVG(Discussion) Discussion, AVG([Fire Drill]) [FireDrill], AVG([Fun Event]) [FunEvent], AVG([Health Issue]) [HealthIssue], AVG([Lunch Break]) [LunchBreak], AVG(Meeting) Meeting, AVG([NoReason Update]) [NoReasonUpdate], AVG([One on One]) [OneonOne], AVG([QA Feedback]) [QAFeedback], AVG([System Downtime]) [SystemDowntime], AVG([Training]) [Training] FROM echolockBreakSplitup GROUP BY UserAccount,Supervisor";
            using (SqlConnection conn = new SqlConnection(db.Database.Connection.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dtEchoLockUsage);
                    }
                }
            }
        }

        [HttpGet]
        [Route("GetDecisionTreeUsage")]
        public IHttpActionResult getDecisionTree()
        {
            fetchDesionTree();
            return Ok(dtDecisionTreeUsage.ToJson());
        }

        private static void fetchDesionTree()
        {
            dtDecisionTreeUsage = new DataTable();
            string query = "SELECT MAX(Project) AS [LOB], UserName, Process AS [TeamName], SUM(UsageCount) AS [Usage] FROM CT_ProjectUsage WHERE Project = 'decision tree' AND CONVERT(DATE,[Date]) >= CONVERT(DATE,GETDATE()-7) GROUP BY UserName,Process";
            using (SqlConnection conn = new SqlConnection(db.Database.Connection.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dtDecisionTreeUsage);
                    }
                }
            }

            foreach (DataRow dr in dtDecisionTreeUsage.Rows)
            {
                DataRow d = dtEchoRev.NewRow();
                d["LOB"] = "Decision Tree";
                d["TeamName"] = dr["TeamName"];
                d["UserName"] = dr["UserName"];
                d["Usage"] = dr["Usage"];

                dtEchoRev.Rows.Add(d);
            }
        }

        [HttpGet]
        [Route("GetEchoLockDashboard")]
        public IHttpActionResult getechoLockDashboard()
        {
            DataTable dtEchoLockDashboard = new DataTable();
            string query = "SELECT AVG(TotalHrs) TotalHrs, AVG(Production) Production, AVG(BreakHour) BreakHour, AVG(Discussion) Discussion, AVG([Fire Drill]) [FireDrill], AVG([Fun Event]) [FunEvent], AVG([Health Issue]) [HealthIssue], AVG([Lunch Break]) [LunchBreak], AVG(Meeting) Meeting, AVG([NoReason Update]) [NoReasonUpdate], AVG([One on One]) [OneonOne], AVG([QA Feedback]) [QAFeedback], AVG([System Downtime]) [SystemDowntime], AVG([Training]) [Training] FROM echolockBreakSplitup";
            using (SqlConnection conn = new SqlConnection(db.Database.Connection.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dtEchoLockDashboard);
                    }
                }
            }

            var result = new EchoLockDashboard
            {
                ProductiveHours = Convert.ToDouble(TimeSpan.FromSeconds(Convert.ToInt32(dtEchoLockDashboard.Compute("AVG([Production])", ""))).ToString(@"hh\:mm").Replace(":", ".")),
                NonProductiveHours = Convert.ToDouble(TimeSpan.FromSeconds(Convert.ToInt32(dtEchoLockDashboard.Compute("AVG([BreakHour])", ""))).ToString(@"hh\:mm").Replace(":", ".")),
                Discussion = Convert.ToDouble(TimeSpan.FromSeconds(Convert.ToInt32(dtEchoLockDashboard.Compute("AVG([Discussion])", ""))).ToString(@"hh\:mm").Replace(":", ".")),
                FireDrill = Convert.ToDouble(TimeSpan.FromSeconds(Convert.ToInt32(dtEchoLockDashboard.Compute("AVG([FireDrill])", ""))).ToString(@"hh\:mm").Replace(":", ".")),
                FunEvent = Convert.ToDouble(TimeSpan.FromSeconds(Convert.ToInt32(dtEchoLockDashboard.Compute("AVG([FunEvent])", ""))).ToString(@"hh\:mm").Replace(":", ".")),
                HealthIssue = Convert.ToDouble(TimeSpan.FromSeconds(Convert.ToInt32(dtEchoLockDashboard.Compute("AVG([HealthIssue])", ""))).ToString(@"hh\:mm").Replace(":", ".")),
                LunchBreak = Convert.ToDouble(TimeSpan.FromSeconds(Convert.ToInt32(dtEchoLockDashboard.Compute("AVG([LunchBreak])", ""))).ToString(@"hh\:mm").Replace(":", ".")),
                Meeting = Convert.ToDouble(TimeSpan.FromSeconds(Convert.ToInt32(dtEchoLockDashboard.Compute("AVG([Meeting])", ""))).ToString(@"hh\:mm").Replace(":", ".")),
                NoReasonUpdate = Convert.ToDouble(TimeSpan.FromSeconds(Convert.ToInt32(dtEchoLockDashboard.Compute("AVG([NoReasonUpdate])", ""))).ToString(@"hh\:mm").Replace(":", ".")),
                OneonOne = Convert.ToDouble(TimeSpan.FromSeconds(Convert.ToInt32(dtEchoLockDashboard.Compute("AVG([OneonOne])", ""))).ToString(@"hh\:mm").Replace(":", ".")),
                QAFeedback = Convert.ToDouble(TimeSpan.FromSeconds(Convert.ToInt32(dtEchoLockDashboard.Compute("AVG([QAFeedback])", ""))).ToString(@"hh\:mm").Replace(":", ".")),
                SystemDowntime = Convert.ToDouble(TimeSpan.FromSeconds(Convert.ToInt32(dtEchoLockDashboard.Compute("AVG([SystemDowntime])", ""))).ToString(@"hh\:mm").Replace(":", ".")),
                Training = Convert.ToDouble(TimeSpan.FromSeconds(Convert.ToInt32(dtEchoLockDashboard.Compute("AVG([Training])", ""))).ToString(@"hh\:mm").Replace(":", "."))
            };

            return Ok(result);
        }

        [HttpPost]
        [Route("GetExceptions")]
        public IHttpActionResult getechoBotExceptions([FromBody]ExceptionInputs e)
        {
            DataTable dtEchoBotExceptions = new DataTable();
            string query = "SELECT TOP (" + e.count + ") Created_By,Exception,Activity FROM [IL_Athena].[dbo].[Exception_Logger]  WHERE Process LIKE '%" + e.processName + "%' ";
            using (SqlConnection conn = new SqlConnection(connStr_ILAthena))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dtEchoBotExceptions);
                    }
                }
            }

            return Ok(dtEchoBotExceptions.ToJson());
        }

        [HttpGet]
        [Route("GetEchoRevDashboard")]
        public IHttpActionResult getechoRevDashboard()
        {
            //fetchAthenaDTUsage();
            //fetchBrightTreeDTUsage();
            //fetchTPXUsage();
            //fetchDesionTree();

            int[] barChartData = new int[] { dtAthenaDocEngineUsage.AsEnumerable().Select(x => x["TeamName"]).Distinct().Count(), dtBrightTreeDocEngineUsage.AsEnumerable().Select(x => x["TeamName"]).Distinct().Count(), dtTpxUsage.AsEnumerable().Select(x => x["TeamName"]).Distinct().Count(), dtDecisionTreeUsage.AsEnumerable().Select(x => x["TeamName"]).Distinct().Count() };
            int[] pieChartData = new int[] { dtAthenaDocEngineUsage.Rows.Count, dtBrightTreeDocEngineUsage.Rows.Count, dtTpxUsage.Rows.Count, dtDecisionTreeUsage.Rows.Count };

            return Ok(new EchoRevModel()
            {
                BarChartInfo = barChartData,
                PieChartInfo = pieChartData
            });
        }

        [HttpPost]
        [Route("GetEchoRevTeamDashboard")]
        public IHttpActionResult getechoRevTeamDashboard([FromBody]EchoRevTeamDashboardInputs inp)
        {
            switch (inp.GroupName)
            {
                case "Athena Documentation Engine":

                    var result = dtAthenaDocEngineUsage.AsEnumerable().GroupBy(x => x["TeamName"]).Select(x => new EchoRevTeamModel()
                    {
                        TeamName = x.FirstOrDefault()["TeamName"].ToString(),
                        UsageAverage = Convert.ToDouble(x.Average(_ => { return Convert.ToInt32(_["Usage"]); }))
                    });
                    return Ok(result);

                case "Brightree Documentation Engine":

                    return Ok(dtBrightTreeDocEngineUsage.AsEnumerable().GroupBy(x => x["TeamName"]).Select(x => new EchoRevTeamModel()
                    {
                        TeamName = x.FirstOrDefault()["TeamName"].ToString(),
                        UsageAverage = Convert.ToDouble(x.Average(_ => { return Convert.ToInt32(_["Usage"]); }))
                    }));

                case "TPX Documentation Engine":

                    return Ok(dtTpxUsage.AsEnumerable().GroupBy(x => x["TeamName"]).Select(x => new EchoRevTeamModel()
                    {
                        TeamName = x.FirstOrDefault()["TeamName"].ToString(),
                        UsageAverage = Convert.ToDouble(x.Average(_ => { return Convert.ToInt32(_["Usage"]); }))
                    }));

                case "Decision Tree":

                    return Ok(dtDecisionTreeUsage.AsEnumerable().GroupBy(x => x["TeamName"]).Select(x => new EchoRevTeamModel()
                    {
                        TeamName = x.FirstOrDefault()["TeamName"].ToString(),
                        UsageAverage = Convert.ToDouble(x.Average(_ => { return Convert.ToInt32(_["Usage"]); }))
                    }));

                default: return Ok();
            }
        }
    }
}