﻿using ControlTowerAdmin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace ControlTowerAdmin.Controllers
{
    [Authorize]
    [RoutePrefix("license")]
    public class LicenseCommandsController : ApiController
    {
        private readonly AhsPlatformEntities objDB = new AhsPlatformEntities();

        [HttpPost]
        [Route("register")]
        public async Task<IHttpActionResult> LicenseRegistration(RegisterLicense command)
        {
            try
            {
                var result = objDB.echobot_lic_companyDetails.FirstOrDefault(x => x.contactEmailId == command.ContactEmailId);

                if (result == null)
                {
                    objDB.echobot_lic_companyDetails.Add(new echobot_lic_companyDetails()
                    {
                        id = Guid.NewGuid(),
                        name = command.Name,
                        address = command.Address,
                        contactEmailId = command.ContactEmailId,
                        contactMobile = command.ContactMobile,
                        botInstances = command.BotInstances,
                        validFrom = DateTime.Now,
                        validTo = DateTime.Now.AddMonths(1),
                        status = command.Status,
                        LicenseType = command.LicenseType,
                        LicenseSlab = command.LicenseSlab,
                        createdBy = System.Security.Principal.WindowsIdentity.GetCurrent().Name,
                        createdOn = DateTime.Now
                    });

                    await objDB.SaveChangesAsync();

                    return Ok();
                }
                else
                {
                    return BadRequest("Email already registered!");
                }
            }
            catch
            {
                return BadRequest("Sorry something happened.Try again!");
            }
        }
    }
}
