﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using System.Windows.Forms;

namespace ControlTowerAdmin.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Title = "Home";

            return View();
        }

        public JsonResult ImportLicense()
        {
            string encryptedLicense = string.Empty;
            var t = new Thread((ThreadStart)(() =>
            {

                OpenFileDialog licenseDilaog = new OpenFileDialog()
                {
                    DefaultExt = "lic",
                    Title = "Browse License",
                    Filter = "lic files (*.lic)|*.lic",
                    CheckFileExists = true,
                    CheckPathExists = true
                };
                if (licenseDilaog.ShowDialog() == DialogResult.OK)
                {
                    encryptedLicense = System.IO.File.ReadAllText(licenseDilaog.FileName);
                }
            }));

            t.SetApartmentState(ApartmentState.STA);
            t.Start();
            t.Join();

            return Json(encryptedLicense, JsonRequestBehavior.AllowGet);
        }
    }
}
