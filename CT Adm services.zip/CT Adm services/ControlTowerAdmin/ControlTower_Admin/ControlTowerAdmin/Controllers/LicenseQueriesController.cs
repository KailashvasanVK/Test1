﻿using ControlTowerAdmin.Models;
using System;
using System.IO;
using System.Linq;
using System.Web.Http;
using System.Web.Script.Serialization;

namespace ControlTowerAdmin.Controllers
{
    [RoutePrefix("lquery")]
    public class LicenseQueriesController : ApiController
    {
        private AhsPlatformEntities objDB = new AhsPlatformEntities();

        [Route("key")]
        [HttpPost]
        public IHttpActionResult LicenseValidation([FromBody]Guid userKey)
        {
            var record = objDB.echobot_lic_companyDetails.FirstOrDefault(r => r.id == userKey);

            if (record != null)
            {
                var result = DateTime.Compare(DateTime.Now, record.validTo);
                if (record.status && result > 0)
                {
                    return Ok("License expired. Kindly renew!");
                }
                else if (!record.status && result < 0)
                {
                    return Ok("License revoked. Contact help center");
                }
                else
                {
                    return Ok("Valid key");
                }
            }
            return Ok("Invalid key");
        }

        [Route("licInfo")]
        [HttpPost]
        public IHttpActionResult GetLicenseInfo([FromBody]string emailId)
        {
            var record = objDB.echobot_lic_companyDetails.FirstOrDefault(p => p.contactEmailId == emailId);
            if (record != null)
                return Ok(new GenerateLicense() { LicenseSerialKey = record.id, ValidFrom = record.validFrom, ValidTo = record.validTo, UserName = record.name, EmailId = record.contactEmailId, BotInstances = record.botInstances });
            return BadRequest("Record not found");
        }

        [Route("ide/key")]
        [HttpPost]
        public IHttpActionResult IdeVerification([FromBody]string userKey)
        {
            var record = objDB.echobot_lic_clientSide.FirstOrDefault(r => r.SerialKey == userKey);
            if (record != null)
            {
                return Ok("Valid key");

            }
            return BadRequest("Invalid key");
        }

        [Route("generateLic")]
        [HttpPost]
        public IHttpActionResult LicenseFileGeneration(GenerateLicense lic)
        {
            string pathToLicense = @"\\10.20.0.185\it-ahs\EchoBot\License\" + lic.UserName + "_" + lic.EmailId.Split('@')[0] + "_EchoBotLicense.lic";
            File.WriteAllText(pathToLicense, Encryption.Encrypt(new JavaScriptSerializer().Serialize(lic), true, "ech0B0t@h$"));
            Mailer.sendMail(new MailInformation()
            {
                From = "mail.support@accesshealthcare.co",
                To = lic.EmailId,
                Subject = "Your Echobot License",
                CarbonCopy = "",
                Body = "Attachment contains your license.<br/>Kindly verify it in Control Tower.<br/><br/>",
                IsHtml = true,
                FilePath = pathToLicense
            });
            return Ok(true);
        }

        [Route("decryptLic")]
        [HttpPost]
        public IHttpActionResult LicenseFileDecryption([FromBody]string encryptedString)
        {
            GenerateLicense obj = new JavaScriptSerializer().Deserialize<GenerateLicense>(Decryption.Decrypt(encryptedString, true, "ech0B0t@h$"));
            return Ok(obj);
        }
    }
}
