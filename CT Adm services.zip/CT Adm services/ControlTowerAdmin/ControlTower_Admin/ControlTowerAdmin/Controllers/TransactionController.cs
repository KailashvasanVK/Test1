﻿using ControlTowerAdmin.Models;
using ControlTowerAdmin.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace ControlTowerAdmin.Controllers
{
    [Authorize]
    [RoutePrefix("Transaction")]
    public class TransactionController : ApiController
    {
        private readonly AhsPlatformEntities db = new AhsPlatformEntities();
        private DataService ds;
        public TransactionController()
        {
            ds = new DataService(db);
        }
        [HttpPost]
        [Route("Error")]
        public async Task<IHttpActionResult> LogError([FromBody]ErrorLog errModel)
        {
            try
            {
                string result = await ValidatorService.ValidateLicenseAsync(db, errModel?.ProcessId, errModel?.BotClientId);
                if (result == "1")
                {
                    db.echobot_lic_exceptions.Add(new echobot_lic_exceptions()
                    {
                        botClient_id = errModel.BotClientId,
                        process_id = errModel.ProcessId,
                        errorMessage = errModel.ErrorMessage,
                        errorEvent = errModel.ErrorEvent,
                        errorTime = errModel.ErrorTime
                    });
                    await db.SaveChangesAsync();
                    return Ok();
                }
                else
                {
                    return BadRequest(result);
                }
            }
            catch (Exception ex)
            {
                return BadRequest(message:"Sorry something happened.Try again!");
            }
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("Log")]
        public async Task<IHttpActionResult> LogTransactions([FromBody]CreateTransactionModel transaction)
        {
            try
            {
                string result = await ValidatorService.ValidateLicenseAsync(db, transaction.ProcessId, transaction.BotClientId);
                if (result == "1")
                {
                    db.echobot_lic_processTransaction.Add(new echobot_lic_processTransaction()
                    {
                        botClient_id = transaction.BotClientId,
                        process_id = transaction.ProcessId,
                        domainName = transaction.DomainName,
                        userName = transaction.UserName,
                        referenceId = transaction.ReferenceId,
                        eventStart = transaction.EventStart,
                        eventEnd = transaction.EventEnd,
                        status = transaction.Status,
                        exception = transaction.Exception,
                        MRN = transaction.MRN
                    });

                    await db.SaveChangesAsync();
                    return Ok();
                }
                else
                {
                    return BadRequest(message:result);
                }
            }
            catch (Exception)
            {
                return BadRequest(message:"Sorry something happened.Try again!");
            }
        }

        [HttpPost]
        [Route("LogTransaction")]
        public async Task<IHttpActionResult> LogTransactionsNew([FromBody]CreateTransactionModel transaction)
        {
            try
            {
                string result = await ValidatorService.ValidateLicenseAsync(db, transaction.ProcessId, transaction.BotClientId);
                if (result == "1")
                {
                    db.echobot_lic_processTransaction.Add(new echobot_lic_processTransaction()
                    {
                        botClient_id = transaction.BotClientId,
                        process_id = transaction.ProcessId,
                        domainName = transaction.DomainName,
                        userName = transaction.UserName,
                        referenceId = transaction.ReferenceId,
                        eventStart = transaction.EventStart,
                        eventEnd = transaction.EventEnd,
                        status = transaction.Status
                    });

                    await db.SaveChangesAsync();
                    return Ok();
                }
                else
                {
                    return BadRequest(message: result);
                }
            }
            catch (Exception)
            {
                return BadRequest(message: "Sorry something happened.Try again!");
            }
        }

        [HttpPost]
        [Route("CreateProcess")]
        public async Task<IHttpActionResult> ProcessCreation(CreateProcessModel process)
        {
            try
            {
                var company = await db.echobot_lic_companyDetails.FindAsync(process.CompanyId);
                int compare = DateTime.Compare(company.validTo, DateTime.Now);

                if (company == null)
                {
                    return BadRequest("License not found");
                }
                if (compare < 0)
                {
                    return BadRequest("License expired! Kindly renew.");
                }

                Guid processId = Guid.NewGuid();

                db.echobot_lic_process.Add(new echobot_lic_process()
                {
                    id = processId,
                    company_id = process.CompanyId,
                    name = process.ProcessName,
                    description = process.Description,
                    createdOn = DateTime.Now
                });
                await db.SaveChangesAsync();
                return Ok(processId);
            }
            catch (Exception)
            {
                return BadRequest("Sorry something happened.Try again!");
            }
        }

        [HttpPost]
        [Route("CreateBotClient")]
        public async Task<IHttpActionResult> BotClientCreation(CreateBotClient client)
        {
            try
            {
                var company = await db.echobot_lic_companyDetails.FindAsync(client.CompanyId);
                int compare = DateTime.Compare(company.validTo, DateTime.Now);
                int botClient = db.echobot_lic_botClient.Count(x => x.company_id == client.CompanyId);

                if (company == null)
                {
                    return BadRequest("License not found");
                }
                if (compare < 0)
                {
                    return BadRequest("License expired! Kindly renew.");
                }
                if (botClient > company.botInstances)
                {
                    return BadRequest("Limit exceeded! Kindly renew your license.");
                }

                Guid botClientId = Guid.NewGuid();

                db.echobot_lic_botClient.Add(new echobot_lic_botClient()
                {
                    Id = botClientId,
                    company_id = client.CompanyId,
                    machineId = client.MachineId,
                    machineName = client.MachineName,
                    status = true,
                    createdOn = DateTime.Now,
                    modifiedOn = DateTime.Now
                });
                await db.SaveChangesAsync();
                return Ok(botClientId);
            }
            catch
            {
                return BadRequest("Sorry something happened.Try again!");
            }
        }

        [AllowAnonymous]
        [Route("Token")]
        [HttpPost]
        public IHttpActionResult Token(InfoModel info)
        {
            try
            {
                var record = ds.GetCompanyByClientKey(info.HashToken);
                var decrypted = RSAEncryptionService.Decrypt(info.UserKey, record.PrivateLicenseKey);
                var _company = ds.GetCompanyById(Guid.Parse(decrypted));
                if (_company != null)
                {
                    var _tokenDetails = Providers.ApplicationOAuthProvider.GetUserAuthToken(_company);
                    return Ok(_tokenDetails);
                }
                else
                {
                    return BadRequest(message: "Invalid userkey or token");
                }
            }
            catch(Exception)
            {
                return BadRequest(message: "Invalid userkey or token");
            }
        }
    }
}
