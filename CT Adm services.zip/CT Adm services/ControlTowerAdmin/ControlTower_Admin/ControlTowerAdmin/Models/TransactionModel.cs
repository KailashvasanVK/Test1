﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ControlTowerAdmin.Models
{
    public class CreateTransactionModel
    {
        public Guid ProcessId { get; set; }
        public Guid BotClientId { get; set; }
        public string DomainName { get; set; }
        public string UserName { get; set; }
        public string ReferenceId { get; set; }
        public DateTime EventStart { get; set; }
        public DateTime EventEnd { get; set; }
        public int Status { get; set; }
        public string Exception { get; set; }
        public string MRN { get; set; }

    }

    public class CreateProcessModel
    {
        public Guid CompanyId { get; set; }
        public string ProcessName { get; set; }
        public string Description { get; set; }
    }
    public class CreateBotClient
    {
        public Guid CompanyId { get; set; }
        public int MachineId { get; set; }
        public string MachineName { get; set; }
    }

    public class ErrorLog
    {
        public Guid ProcessId { get; set; }
        public Guid BotClientId { get; set; }
        public string ErrorMessage { get; set; }
        public string ErrorEvent { get; set; }
        public DateTime ErrorTime { get; set; }
    }

    public class InfoModel
    {
        public string UserKey { get; set; }
        public string HashToken { get; set; }
    }
    public class ClientToken
    {
        public string AccessToken { get; set; }
        public DateTimeOffset? ExpiresOn { get; set; }
    }
}