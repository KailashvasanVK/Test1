﻿using System.Collections.Generic;

namespace ControlTowerAdmin.Models
{
    public class DashboardCount
    {
        public int Server { get; set; }
        public int Bots { get; set; }
        public int Instances { get; set; }
        public int Transactions { get; set; }
        public int EchoRevBots { get; set; }
        public int EchoRevInstances { get; set; }
        public int EchoRevUsage { get; set; }
        public int EchoLockUsers { get; set; }
        public string EchoLockProd { get; set; }
        public string EchoLockNonProd { get; set; }
        public int EchoPayExpectation { get; set; }
        public int EchoPayADP { get; set; }
        public int EchoPay { get; set; }
        public int EchoPaySDE { get; set; }
        public int DTBots { get; set; }
        public int DTInstances { get; set; }
        public int DTTransactions { get; set; }
    }

    public class ServersDetails
    {
        public string IP { get; set; }
        public string MachineName { get; set; }
    }

    public class ProcessDetails
    {
        public string LOB { get; set; }
        public string ProcessName { get; set; }
        public int BotInstances { get; set; }
        public int BotTransactions { get; set; }
        public int BotExceptions { get; set; }
        public string BotProcessName { get; set; }
    }

    public class EchoLockDashboard
    {
        public double ProductiveHours { get; set; }
        public double NonProductiveHours { get; set; }
        public double Discussion { get; set; }
        public double FireDrill { get; set; }
        public double FunEvent { get; set; }
        public double HealthIssue { get; set; }
        public double LunchBreak { get; set; }
        public double Meeting { get; set; }
        public double NoReasonUpdate { get; set; }
        public double OneonOne { get; set; }
        public double QAFeedback { get; set; }
        public double SystemDowntime { get; set; }
        public double Training { get; set; }
    }

    public class ExceptionInputs
    {
        public string processName { get; set; }
        public int count { get; set; }
    }

    public class EchoRevTeamDashboardInputs
    {
        public string GroupName { get; set; }
    }

    public class EchoRevModel
    {
        public int[] BarChartInfo { get; set; }
        public int[] PieChartInfo { get; set; }
    }

    public class EchoRevTeamModel
    {
        public string TeamName { get; set; }
        public double UsageAverage { get; set; }
    }
}