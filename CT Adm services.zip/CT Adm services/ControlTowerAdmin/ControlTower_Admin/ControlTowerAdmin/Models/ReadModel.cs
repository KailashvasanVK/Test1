﻿using System;

namespace ControlTowerAdmin.Models
{
    public class GenerateLicense
    {
        private Guid licenseSerialKey;
        private DateTime validFrom;
        private DateTime validTo;
        private string userName;
        private string emailID;
        private int botInstances;

        public Guid LicenseSerialKey { get { return licenseSerialKey; } set { if (licenseSerialKey != value) licenseSerialKey = value; } }
        public DateTime ValidFrom { get { return validFrom; } set { if (validFrom != value) validFrom = value; } }
        public DateTime ValidTo { get { return validTo; } set { if (validTo != value) validTo = value; } }
        public string UserName { get { return userName; } set { if (userName != value) userName = value; } }
        public string EmailId { get { return emailID; } set { if (emailID != value) emailID = value; } }
        public int BotInstances { get { return botInstances; } set { if (botInstances != value) botInstances = value; } }
    }

    public class MailInformation
    {

        private string from;
        private string to;
        private string carbonCopy;
        private string subject;
        private string body;
        private bool isHtml;
        private string filePath;

        public string From { get { return from; } set { if (from != value) from = value; } }
        public string To { get { return to; } set { if (to != value) to = value; } }
        public string CarbonCopy { get { return carbonCopy; } set { if (carbonCopy != value) carbonCopy = value; } }
        public string Subject { get { return subject; } set { if (subject != value) subject = value; } }
        public string Body { get { return body; } set { if (body != value) body = value; } }
        public bool IsHtml { get { return isHtml; } set { if (isHtml != value) isHtml = value; } }
        public string FilePath { get { return filePath; } set { if (filePath != value) filePath = value; } }
    }

    public class RegisterLicense
    {
        private string name;
        private string address;
        private string contactEmailId;
        private string contactMobile;
        private int botInstances;
        private bool status;
        private int licenseType;
        private int licenseSlab;

        public string Name { get { return name; } set { if (name != value) name = value; } }
        public string Address { get { return address; } set { if (address != value) address = value; } }
        public string ContactEmailId { get { return contactEmailId; } set { if (contactEmailId != value) contactEmailId = value; } }
        public string ContactMobile { get { return contactMobile; } set { if (contactMobile != value) contactMobile = value; } }
        public int BotInstances { get { return botInstances; } set { if (botInstances != value) botInstances = value; } }
        public bool Status { get { return status; } set { if (status != value) status = value; } }
        public int LicenseType { get { return licenseType; } set { if (licenseType != value) licenseType = value; } }
        public int LicenseSlab { get { return licenseSlab; } set { if (licenseSlab != value) licenseSlab = value; } }

    }
}