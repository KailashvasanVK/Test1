﻿'use strict';

var controlTowerApp = angular.module('controlTowerApp', ['ngRoute']);

//Function declarations
controlTowerApp
    .config(function ($qProvider) {

        $qProvider.errorOnUnhandledRejections(true); //Handles unhandled rejections             

        document.getElementById('overlay').style.display = "none";

    })
    .directive('numbersOnly', function () {
        return {
            require: 'ngModel',
            link: function (scope, element, attr, ngModelCtrl) {
                function fromUser(text) {
                    if (text) {
                        var transformedInput = text.replace(/[^0-9]/g, '');

                        if (transformedInput !== text) {
                            ngModelCtrl.$setViewValue(transformedInput);
                            ngModelCtrl.$render();
                        }
                        return transformedInput;
                    }
                    return undefined;
                }
                ngModelCtrl.$parsers.push(fromUser);
            }
        };
    })
    .filter('DateTimeFilter', ['$filter',
    function ($filter) {
        return function (input) {

            let d = Number(input);
            let h = Math.floor(d / 3600);
            let m = Math.floor(d % 3600 / 60);
            let s = Math.floor(d % 3600 % 60);

            let hDisplay = h > 0 ? h + (h == 1 ? ":" : ":") : "";
            let mDisplay = m > 0 ? m + (m == 1 ? ":" : ":") : "";
            let sDisplay = s > 0 ? s + (s == 1 ? "" : "") : "";
            return hDisplay + mDisplay + sDisplay;

        }
    }
    ])
    .filter('ThousandsFilter', ['$filter',
    function ($filter) {
        return function (input) {
            if (input != undefined && input != null) {
                input = input.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                input = input.replace(/\B(?=(\d{6})+(?!\d))/g, ",");
                return input;
            }
            else
                return 0;
        }
    }
    ])
    .filter('currentdate', ['$filter', function ($filter) {
        return function () {
            var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            return days[new Date().getDay()] + ' ' + $filter('date')(new Date(), 'dd-MMM-yyyy');
        };
    }])
    .factory('httpService', httpService)
    .service('globalService', globalService)
    .component('licenseComponent', {
        templateUrl: '/Content/html/license.html',
        controller: licenseController
    })
    .component('importlicenseComponent', {
        templateUrl: '/Content/html/importLicense.html',
        controller: importLicenseController
    })
    .component('dashboardComponent', {
        templateUrl: '/Content/html/dashboard.html',
        controller: dashboardController
    })
//.component('summaryComponent', {
//    templateUrl: '/Content/html/summary.html',
//    controller: summaryController
//});



//HTTP service
function httpService($http) {
    return {
        getData: function (url) {
            return $http.get(url);
        },
        postData: function (url, data) {
            return $http.post(url, data, {
                headers: {
                    'Content-Type': 'application/json; charset=utf-8'
                }
            });
        },
        postDatawithAuthorization: function (url, data, token) {
            return $http.post(url, data, {
                headers: {
                    'Content-Type': 'application/json; charset=utf-8',
                    'Authorization': 'bearer ' + token
                }
            });
        },
        generateToken: function (url, data) {
            return $http.post(url, data, {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            });
        },
        deleteData: function (url, data) {
            return $http.delete(url, { params: data });
        }
    };
};

//Global service
function globalService() {

};

function licenseController($scope, httpService) {

    $scope.licTypes = [
        { ID: '1', Value: 'Bot per Month' },
        { ID: '2', Value: 'Cummulative - Bot Month' },
        { ID: '3', Value: 'Multifunctional Bot - Bot Month' },
    ];

    $scope.licSlabs = [
        { ID: '2', Value: '0 - 180 Hours a Month' },
        { ID: '3', Value: '181 - 359 Hours a Month' },
        { ID: '4', Value: '>359 Hours upto 720 Hours a Month' },
    ];

    $scope.generateLicense = function (license) {
        document.getElementById('overlay').style.display = "block";
        var data = JSON.stringify({ 'Email': license.emailID, 'Password': license.password, 'ConfirmPassword': license.password });
        httpService.postData('api/Account/Register', data).then(function (accReg) {
            if (accReg.status == 200) {
                generateToken(license);
            }
        }).catch(function (errReg) {
            generateToken(license);
            var exceptionMsg = errReg.data.ModelState[""][0];
        });
        document.getElementById('overlay').style.display = "none";
    };

    function generateToken(license) {
        httpService.generateToken('Token', 'grant_type=password&username=' + license.emailID + '&password=' + license.password).then(function (token) {
            if (token.status == 200) {
                var accessToken = token.data.access_token;
                var dataRegisterLicense = JSON.stringify({ 'Name': license.companyName, 'Address': license.address, 'ContactEmailId': license.emailID, 'ContactMobile': license.mobile, 'BotInstances': license.bots, 'Status': true, 'LicenseType': license.licenseType, 'LicenseSlab': (license.licenseType == 1) ? 1 : license.licenseSlab.ID });
                httpService.postDatawithAuthorization('license/register', dataRegisterLicense, accessToken).then(function (licReg) {
                    if (licReg.status == 200) {
                        var dataLicenseInfo = JSON.stringify(license.emailID);
                        httpService.postData('lquery/licInfo', dataLicenseInfo).then(function (licInfo) {
                            if (licInfo.status == 200) {
                                var dataGenerateLicense = JSON.stringify(licInfo.data);
                                httpService.postData('lquery/generateLic', dataGenerateLicense).then(function (licGenInfo) {
                                    if (licGenInfo.status == 200) {
                                        bootbox.alert("License generated successfully.");
                                    }
                                    else {
                                        bootbox.alert('Unable to Generate License. Please try again.');
                                    }
                                }).catch(function (errLicGenInfo) {
                                    bootbox.alert('Unable to Generate License. Please try again.');
                                });
                            }
                            else {
                                bootbox.alert('Unable to Generate License. Please try again.');
                            }
                        }).catch(function (errLicInfo) {
                            bootbox.alert('Unable to Generate License. Please try again.');
                        });
                    }
                }).catch(function (errLicReg) {
                    if (errLicReg.data == 'Email already registered!') {
                        bootbox.alert(errLicReg.data);
                    } else {
                        bootbox.alert('Failed to Generate License. Please try again.');
                    }
                });
            }
            else {
                bootbox.alert('Authentication failed. Please try again.');
            }
        }).catch(function (errToken) { bootbox.alert('Authentication failed. Please try again.'); });
    }
};

function importLicenseController($scope, httpService) {

    $scope.encryptedLicense = '';
    $scope.LicenseValue;
    $scope.isValidLicense = false;

    $scope.validateLicense = function () {
        document.getElementById('overlay').style.display = "block";
        httpService.getData('/Home/ImportLicense').then(function (license) {
            if (license.status == 200) {
                $scope.encryptedLicense = license.data;
                httpService.postData('http://10.20.0.197:100/lquery/decryptLic', JSON.stringify($scope.encryptedLicense)).then(function (licInfo) {
                    if (licInfo.status == 200) {
                        var LicenseValue = licInfo.data;
                        httpService.postData('http://10.20.0.197:100/lquery/key', JSON.stringify(LicenseValue.LicenseSerialKey)).then(function (licenseValidation) {
                            if (licenseValidation.status == 200 && licenseValidation.data == 'Valid key') {
                                $scope.LicenseValue = LicenseValue; $scope.isValidLicense = true;
                                httpService.postData('http://10.20.0.197:100/license/client/register', JSON.stringify($scope.encryptedLicense)).then(function (licenseClientRegister) {
                                    if (licenseClientRegister.status == 200) {
                                        bootbox.alert("License registered successfully.");
                                    }
                                    else {
                                        bootbox.alert("License registration failed. Please try again.");
                                    }
                                }).catch(function (errLicenseClientRegister) {
                                    bootbox.alert("License registration failed. Please try again.");
                                });
                            }
                            else {
                                bootbox.alert("Invalid license. Please try again.");
                            }
                        }).catch(function (errLicValidation) { bootbox.alert("Invalid license. Please try again."); });
                    }
                }).catch(function (errLicInfo) { bootbox.alert("Unable to import license. Please try again."); });
            }
        }).catch(function (errLicense) { bootbox.alert("Unable to import license. Please try again."); });
        document.getElementById('overlay').style.display = "none";
    };

    function readTextFile(file) {
        var rawFile = new XMLHttpRequest(); var allText = '';
        rawFile.open("GET", file, false);
        rawFile.onreadystatechange = function () {
            if (rawFile.readyState === 4) {
                if (rawFile.status === 200 || rawFile.status == 0) {
                    allText = rawFile.responseText;
                }
            }
        }
        rawFile.send(null);
        return allText;
    };
}

//Dashboard Controller
function dashboardController($scope, $location, httpService) {

    $('#contentHolder').show(); $('#serversHolder').hide();
    $('#botsHolder').hide(); $('#echoRevHolder').hide();
    $('#echoPayHolder').hide(); $('#echoLockHolder').hide();
    $('#echoDTHolder').hide(); $('#echoLockDashboardHolder').hide();
    $('#botsExceptionHolder').hide(); $('#echoPayDashboardHolder').hide();

    $scope.InnerStatus = false;

    $scope.init = function () {

        document.getElementById('overlay').style.display = "block";
        httpService.getData('Dashboard/GetAthenaBots').then(function (dataDashboard) {
            if (dataDashboard.status == 200) {
                $scope.dashboardData = dataDashboard.data;
                httpService.getData('Dashboard/GetNonathenaBots').then(function (dataDashboard2) {
                    if (dataDashboard2.status == 200) {
                        $scope.dashboardData = dataDashboard2.data;
                        httpService.getData('Dashboard/GetNonAthenaLive').then(function (dataDashboard3) {
                            if (dataDashboard3.status == 200) {
                                $scope.dashboardData = dataDashboard3.data;
                                document.getElementById('overlay').style.display = "none";
                            }
                        }).catch(function (errDashboard3) {
                            bootbox.alert('Something happened wrong. Try again.');
                        });
                    }
                }).catch(function (errDashboard2) {
                    bootbox.alert('Something happened wrong. Try again.');
                });
                //$scope.loadCharts();
            }
        }).catch(function (errDashboard) {
            bootbox.alert('Something happened wrong. Try again.');
        });

    };

    $scope.showContent = function (modalName) {

        let url = '';
        $('#contentHolder').hide(); $('#serversHolder').hide();
        $('#botsHolder').hide(); $('#echoRevHolder').hide();
        $('#echoPayHolder').hide(); $('#echoLockHolder').hide();
        $('#echoDTHolder').hide(); $('#echoLockDashboardHolder').hide();
        $('#botsExceptionHolder').hide(); $('#echoPayDashboardHolder').hide();

        switch (modalName) {
            case 'serverModal': $scope.initServers(); break;
            case 'processModal': $scope.initBots(); break;
            case 'echoRevModal': $scope.getEchoRevDTUsage(); break;
            case 'echoPayModal': $scope.getEchoPayUsage(); break;
            case 'echoLockModal': $scope.getEchoLockUsage(); break;
            case 'echoDTModal': $scope.getEchoDTUsage(); break;
            case 'echoLockDashboardModal': $scope.getEchoLockDashboard(); break;
            case 'echoRevDashboardModal': $scope.getEchoRevDashboard(); break;
        };

    };

    $scope.resetVisibility = function () {

        if (!$scope.InnerStatus) {
            $('#contentHolder').show();
            $('#botsHolder').hide();
        } else {
            $('#contentHolder').hide();
            $('#botsHolder').show();
            $scope.InnerStatus = false;
        }

        $('#serversHolder').hide(); $('#echoPayDashboardHolder').hide();
        $('#botsExceptionHolder').hide(); $('#echoRevHolder').hide();
        $('#echoPayHolder').hide(); $('#echoLockHolder').hide();
        $('#echoDTHolder').hide(); $('#echoLockDashboardHolder').hide();
    };

    $scope.initServers = function () {

        document.getElementById('overlay').style.display = "block";
        httpService.getData('Dashboard/GetServers').then(function (dataBind) {
            if (dataBind.status == 200) {
                $scope.serversDetails = dataBind.data;
                $('#serverTable').DataTable().destroy();
                setTimeout(function () {
                    $('#serverTable').DataTable();
                }, 100);
                setTimeout(function () {
                    document.getElementById('overlay').style.display = "none";
                    $('#serversHolder').show();
                }, 1000);
            }
        }).catch(function (errServers) {
            bootbox.alert('Something happened wrong. Try again.')
        });

    };

    $scope.initBots = function () {

        document.getElementById('overlay').style.display = "block";
        httpService.getData('Dashboard/GetProcess').then(function (dataBind) {
            if (dataBind.status == 200) {
                $scope.processDetails = dataBind.data;
                $('#processTable').DataTable().destroy();
                setTimeout(function () {
                    $('#processTable').DataTable();
                }, 100);
                setTimeout(function () {
                    $('#botsHolder').show();
                    document.getElementById('overlay').style.display = "none";
                }, 3000);
            }
        }).catch(function (errBots) {
            bootbox.alert('Something happened wrong. Try again.')
        });

    };

    $scope.getEchoRevDTUsage = function () {

        document.getElementById('overlay').style.display = "block";
        httpService.getData('Dashboard/GetEchoRevUsage').then(function (dataEchoRevUsage) {
            if (dataEchoRevUsage.status == 200) {
                $scope.EchorevDTUsage = dataEchoRevUsage.data;
                $('#tblEchoRevDTUsage').DataTable().destroy();
                setTimeout(function () {
                    $('#tblEchoRevDTUsage').DataTable();
                }, 100);
                setTimeout(function () {
                    $('#echoRevHolder').show();
                    document.getElementById('overlay').style.display = "none";
                }, 5000);
            }
        }).catch(function (errAthenaUsage) {
            bootbox.alert('Something happened wrong. Try again.');
        });
    };

    $scope.getEchoPayUsage = function () {

        document.getElementById('overlay').style.display = "block";
        httpService.getData('Dashboard/GetEchoPayUsage').then(function (dataEchoPayUsage) {
            if (dataEchoPayUsage.status == 200) {
                $scope.EchoPayUsage = dataEchoPayUsage.data;
                $('#tblEchoPayUsage').DataTable().destroy();
                setTimeout(function () {
                    $('#tblEchoPayUsage').DataTable();
                }, 100);
                setTimeout(function () {
                    $('#echoPayHolder').show();
                    document.getElementById('overlay').style.display = "none";
                }, 5000);
            }
        }).catch(function (errEchoPayUsage) {
            bootbox.alert('Something happened wrong. Try again.');
        });
    };

    $scope.getEchoLockUsage = function () {

        document.getElementById('overlay').style.display = "block";
        httpService.getData('Dashboard/GetEchoLockUsage').then(function (dataEchoLockUsage) {
            if (dataEchoLockUsage.status == 200) {
                $scope.EchoLockUsage = dataEchoLockUsage.data;
                $('#tblEchoLockUsage').DataTable().destroy();
                setTimeout(function () {
                    $('#tblEchoLockUsage').DataTable();
                }, 100);
                setTimeout(function () {
                    $('#echoLockHolder').show();
                    document.getElementById('overlay').style.display = "none";
                }, 5000);
            }
        }).catch(function (errEchoLockUsage) {
            bootbox.alert('Something happened wrong. Try again.');
        });

    };

    $scope.getEchoLockDashboard = function () {

        document.getElementById('overlay').style.display = "block";
        httpService.getData('Dashboard/GetEchoLockDashboard').then(function (dataEchoLockDashboard) {
            if (dataEchoLockDashboard.status == 200) {

                let dashData = dataEchoLockDashboard.data;

                $('#echoLockDashboardHolder').show();

                let chart = c3.generate({
                    bindto: '#echoLockDashboard',
                    size: {
                        height: 400,
                        width: 400
                    },
                    data: {
                        columns: [
                            ['Productive', dashData.ProductiveHours],
                            ['NonProductive', dashData.NonProductiveHours],
                        ],
                        type: 'donut',
                        colors: {
                            Productive: '#15426c',
                            NonProductive: '#da2a26'
                        }
                    },
                    donut: {
                        title: "<div style='font-size:25px;font-weight:bold;'>echoLock</div>"
                    }
                });

                let chartSplitUp = c3.generate({
                    bindto: '#echoLockBreakSplit',
                    size: {
                        height: 400,
                        width: 400
                    },
                    data: {
                        columns: [
                            ['Discussion', dashData.Discussion],
                            ['FireDrill', dashData.FireDrill],
                            ['FunEvent', dashData.FunEvent],
                            ['HealthIssue', dashData.HealthIssue],
                            ['LunchBreak', dashData.LunchBreak],
                            ['Meeting', dashData.Meeting],
                            ['NoReasonUpdate', dashData.NoReasonUpdate],
                            ['OneonOne', dashData.OneonOne],
                            ['QAFeedback', dashData.QAFeedback],
                            ['SystemDowntime', dashData.SystemDowntime],
                            ['Training', dashData.Training],
                        ],
                        type: 'pie'
                    }
                });

                document.getElementById('overlay').style.display = "none";
            }
        }).catch(function (errEchoLockDashboard) {
            bootbox.alert('Something happened wrong. Try again.');
        });

    };

    $scope.getEchoRevDashboard = function () {

        document.getElementById('overlay').style.display = "block";
        httpService.getData('Dashboard/GetEchoRevDashboard').then(function (dataEchoPayDashboard) {
            if (dataEchoPayDashboard.status == 200) {

                let dashData = dataEchoPayDashboard.data;

                $('#echoPayDashboardHolder').show();

                let chartSummary = c3.generate({
                    bindto: '#echoPayDashboard',
                    size: {
                        height: 400,
                        width: 700
                    },
                    data: {
                        columns: [
                            ['Teams', dashData.BarChartInfo[0], dashData.BarChartInfo[1], dashData.BarChartInfo[2], dashData.BarChartInfo[3]]
                        ],
                        type: 'bar',
                        colors: {
                            Teams: '#15426c'
                        }
                    },
                    axis: {
                        x: {
                            type: 'category',
                            categories: ['Athena Documentation Engine', 'Brightree Documentation Engine', 'TPX Documentation Engine', 'Decision Tree']
                        }
                    },
                    bar: {
                        width: {
                            ratio: 0.25
                        }
                    }
                });

                $('#btnResetChart').hide();

                let chartTeamSummary = c3.generate({
                    bindto: '#echoPayTeamSplit',
                    size: {
                        height: 400,
                        width: 400
                    },
                    data: {
                        columns: [
                            ['Athena Documentation Engine', dashData.PieChartInfo[0]],
                            ['Brightree Documentation Engine', dashData.PieChartInfo[1]],
                            ['TPX Documentation Engine', dashData.PieChartInfo[2]],
                            ['Decision Tree', dashData.PieChartInfo[3]]
                        ],
                        type: 'pie',
                        onclick: function (d, i) {
                            httpService.postData('Dashboard/GetEchoRevTeamDashboard', JSON.stringify({ 'GroupName': d.name })).then(function (dataEchoTeamDashboard) {
                                if (dataEchoTeamDashboard.status == 200) {

                                    dataEchoTeamDashboard.data.forEach(function (e) {
                                        setTimeout(function () {
                                            chartTeamSummary.load({
                                                columns: [
                                                    ['' + e.TeamName + '', e.UsageAverage],
                                                ],
                                                type: 'pie'
                                            });
                                        }, 1000);
                                    });

                                    setTimeout(function () {
                                        chartTeamSummary.unload({
                                            ids: 'Athena Documentation Engine'
                                        });
                                    }, 1000);

                                    setTimeout(function () {
                                        chartTeamSummary.unload({
                                            ids: 'Brightree Documentation Engine'
                                        });
                                    }, 1000);

                                    setTimeout(function () {
                                        chartTeamSummary.unload({
                                            ids: 'TPX Documentation Engine'
                                        });
                                    }, 1000);

                                    setTimeout(function () {
                                        chartTeamSummary.unload({
                                            ids: 'Decision Tree'
                                        });
                                    }, 1000);

                                    $('#btnResetChart').show();
                                }
                            });
                        }
                    },
                    legend: {
                        show: false
                    }
                });

                $('#btnResetChart').on('click', function () {

                    chartTeamSummary.unload();

                    setTimeout(function () {
                        chartTeamSummary.load({
                            columns: [
                                ['Athena Documentation Engine', dashData.PieChartInfo[0]],
                                ['Brightree Documentation Engine', dashData.PieChartInfo[1]],
                                ['TPX Documentation Engine', dashData.PieChartInfo[2]],
                                ['Decision Tree', dashData.PieChartInfo[3]]
                            ]
                        });
                    }, 2000);

                    $('#btnResetChart').hide();

                });

                document.getElementById('overlay').style.display = "none";
            }
        }).catch(function (errEchoLockDashboard) {
            bootbox.alert('Something happened wrong. Try again.');
        });

    };

    $scope.showExceptions = function (exceptionName, count) {

        if (exceptionName.length > 0) {
            document.getElementById('overlay').style.display = "block";
            $('#contentHolder').hide(); $('#serversHolder').hide();
            $('#botsHolder').hide(); $('#echoRevHolder').hide();
            $('#echoPayHolder').hide(); $('#echoLockHolder').hide();
            $('#echoDTHolder').hide(); $('#echoLockDashboardHolder').hide();
            $('#botsExceptionHolder').hide();

            httpService.postData('Dashboard/GetExceptions', JSON.stringify({ 'processName': exceptionName, 'count': count })).then(function (dataBotsExceptions) {
                if (dataBotsExceptions.status == 200) {
                    $scope.exceptionDetails = dataBotsExceptions.data;
                    $('#processExceptionTable').DataTable().destroy();
                    setTimeout(function () {
                        $('#processExceptionTable').DataTable();
                    }, 100);
                    setTimeout(function () {
                        $('#botsExceptionHolder').show();
                        document.getElementById('overlay').style.display = "none";
                        $scope.InnerStatus = true;
                    }, 5000);
                }
            }).catch(function (errBotsExceptions) {
                bootbox.alert('Something happened wrong. Try again.');
            });
        }

    };

    $scope.getEchoDTUsage = function () {

        document.getElementById('overlay').style.display = "block";
        httpService.getData('Dashboard/GetDecisionTreeUsage').then(function (dataEchoDTUsage) {
            if (dataEchoDTUsage.status == 200) {
                $scope.EchoDTUsage = dataEchoDTUsage.data;
                $('#tblEchoDTUsage').DataTable().destroy();
                setTimeout(function () {
                    $('#tblEchoDTUsage').DataTable();
                }, 100);
                $('#echoDTHolder').show();
                document.getElementById('overlay').style.display = "none";
            }
        }).catch(function (errAthenaUsage) {
            bootbox.alert('Something happened wrong. Try again.');
        });
    };

};

//Summary Controller
function summaryController($scope, httpService) {

    $scope.projectDetails = [{ "Name": "Echolock", "Url": "http://10.20.79.116:1020" },
        { "Name": "ControlTower", "Url": "http://10.20.197:88" }
    ];
};
