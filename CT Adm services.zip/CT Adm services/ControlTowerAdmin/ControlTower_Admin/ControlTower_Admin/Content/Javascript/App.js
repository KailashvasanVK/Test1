﻿'use strict';

var controlTowerApp = angular.module('controlTowerApp', ['ngRoute']);

//Function declarations
controlTowerApp
    .config(['$qProvider', function ($qProvider) {

        $qProvider.errorOnUnhandledRejections(false); //Handles unhandled rejections       
        document.getElementById('overlay').style.display = "none";
    }])
    .directive('numbersOnly', function () {
        return {
            require: 'ngModel',
            link: function (scope, element, attr, ngModelCtrl) {
                function fromUser(text) {
                    if (text) {
                        var transformedInput = text.replace(/[^0-9]/g, '');

                        if (transformedInput !== text) {
                            ngModelCtrl.$setViewValue(transformedInput);
                            ngModelCtrl.$render();
                        }
                        return transformedInput;
                    }
                    return undefined;
                }
                ngModelCtrl.$parsers.push(fromUser);
            }
        };
    })
    .factory('httpService', httpService)
    .service('globalService', globalService)
    .component('licenseComponent', {
        templateUrl: '/Content/html/license.html',
        controller: licenseController
    })
    .component('importlicenseComponent', {
        templateUrl: '/Content/html/importLicense.html',
        controller: importLicenseController
    });

//HTTP service
function httpService($http) {
    return {
        getData: function (url) {
            return $http.get(url);
        },
        postData: function (url, data) {
            return $http.post(url, data, {
                headers: {
                    'Content-Type': 'application/json; charset=utf-8'
                }
            });
        },
        postDatawithAuthorization: function (url, data, token) {
            return $http.post(url, data, {
                headers: {
                    'Content-Type': 'application/json; charset=utf-8',
                    'Authorization': 'bearer ' + token
                }
            });
        },
        generateToken: function (url, data) {
            return $http.post(url, data, {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            });
        },
        deleteData: function (url, data) {
            return $http.delete(url, { params: data });
        }
    };
};

//Global service
function globalService() {

};

function licenseController($scope, httpService) {

    $scope.licTypes = [
        { ID: '1', Value: 'Bot per Month' },
        { ID: '2', Value: 'Cummulative - Bot Month' },
        { ID: '3', Value: 'Multifunctional Bot - Bot Month' },
    ];

    $scope.licSlabs = [
        { ID: '1', Value: '0 - 180 Hours a Month' },
        { ID: '2', Value: '181 - 359 Hours a Month' },
        { ID: '3', Value: '>359 Hours upto 720 Hours a Month' },
    ];

    $scope.generateLicense = function (license) {
        document.getElementById('overlay').style.display = "block";
        var data = JSON.stringify({ 'Email': license.emailID, 'Password': license.password, 'ConfirmPassword': license.password });
        httpService.postData('http://localhost:59421/api/Account/Register', data).then(function (accReg) {
            if (accReg.status == 200) {
                generateToken(license);
            }
        }).catch(function (errReg) {
            generateToken(license);
            var exceptionMsg = errReg.data.ModelState[""][0];
        });
        document.getElementById('overlay').style.display = "none";
    };

    function generateToken(license) {
        httpService.generateToken('http://localhost:59421/Token', 'grant_type=password&username=' + license.emailID + '&password=' + license.password).then(function (token) {
            if (token.status == 200) {
                var accessToken = token.data.access_token;
                var dataRegisterLicense = JSON.stringify({ 'Name': license.companyName, 'Address': license.address, 'ContactEmailId': license.emailID, 'ContactMobile': license.mobile, 'BotInstances': license.bots, 'Status': true });
                httpService.postDatawithAuthorization('http://localhost:59421/license/register', dataRegisterLicense, accessToken).then(function (licReg) {
                    if (licReg.status == 200) {
                        var dataLicenseInfo = JSON.stringify(license.emailID);
                        httpService.postData('http://localhost:59421/lquery/licInfo', dataLicenseInfo).then(function (licInfo) {
                            if (licInfo.status == 200) {
                                var dataGenerateLicense = JSON.stringify(licInfo.data);
                                httpService.postData('http://localhost:59421/lquery/generateLic', dataGenerateLicense).then(function (licGenInfo) {
                                    if (licGenInfo.status == 200) {
                                        bootbox.alert("License generated successfully.");
                                    }
                                    else {
                                        bootbox.alert('Unable to Generate License. Please try again.');
                                    }
                                }).catch(function (errLicGenInfo) {
                                    bootbox.alert('Unable to Generate License. Please try again.');
                                });
                            }
                            else {
                                bootbox.alert('Unable to Generate License. Please try again.');
                            }
                        }).catch(function (errLicInfo) {
                            bootbox.alert('Unable to Generate License. Please try again.');
                        });
                    }
                }).catch(function (errLicReg) {
                    bootbox.alert('Failed to Generate License. Please try again.');
                });
            }
            else {
                bootbox.alert('Authentication failed. Please try again.');
            }
        }).catch(function (errToken) { bootbox.alert('Authentication failed. Please try again.'); });
    }
};

function importLicenseController($scope, httpService) {

    $scope.encryptedLicense = '';
    $scope.LicenseValue;
    $scope.isValidLicense = false;

    $scope.validateLicense = function () {
        document.getElementById('overlay').style.display = "block";
        httpService.getData('/Home/ImportLicense').then(function (license) {
            if (license.status == 200) {
                $scope.encryptedLicense = license.data;
                httpService.postData('http://localhost:59421/lquery/decryptLic', JSON.stringify($scope.encryptedLicense)).then(function (licInfo) {
                    if (licInfo.status == 200) {
                        var LicenseValue = licInfo.data;
                        httpService.postData('http://localhost:59421/lquery/key', JSON.stringify(LicenseValue.LicenseSerialKey)).then(function (licenseValidation) {
                            if (licenseValidation.status == 200 && licenseValidation.data == 'Valid key') {
                                $scope.LicenseValue = LicenseValue; $scope.isValidLicense = true;
                                httpService.postData('http://localhost:59421/license/client/register', JSON.stringify($scope.encryptedLicense)).then(function (licenseClientRegister) {
                                    if (licenseClientRegister.status == 200) {
                                        bootbox.alert("License registered successfully.");
                                    }
                                    else {
                                        bootbox.alert("License registration failed. Please try again.");
                                    }
                                }).catch(function (errLicenseClientRegister) {
                                    bootbox.alert("License registration failed. Please try again.");
                                });
                            }
                            else {
                                bootbox.alert("Invalid license. Please try again.");
                            }
                        }).catch(function (errLicValidation) { bootbox.alert("Invalid license. Please try again."); });
                    }
                }).catch(function (errLicInfo) { bootbox.alert("Unable to import license. Please try again."); });
            }
        }).catch(function (errLicense) { bootbox.alert("Unable to import license. Please try again."); });
        document.getElementById('overlay').style.display = "none";
    };

    function readTextFile(file) {
        var rawFile = new XMLHttpRequest(); var allText = '';
        rawFile.open("GET", file, false);
        rawFile.onreadystatechange = function () {
            if (rawFile.readyState === 4) {
                if (rawFile.status === 200 || rawFile.status == 0) {
                    allText = rawFile.responseText;
                }
            }
        }
        rawFile.send(null);
        return allText;
    };
}