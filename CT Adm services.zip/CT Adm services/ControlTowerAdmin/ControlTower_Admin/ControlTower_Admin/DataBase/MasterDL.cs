﻿using System;
using System.Data.SqlClient;
using System.Data;

/// <summary>
/// Summary description for MasterDL
/// </summary>
public class MasterDL
{
    #region VARIABLE DECLARATION

    #region "SQL VARIABLE"

    SqlConnection con;
    SqlDataAdapter Ada;
    SqlCommand Sqlcmd;
    DataSet Dset;
    DataTable Dt;

    #endregion

    DBConnectionCls Objcon;
    string RetrunStr;
    #endregion

    /// <summary>
    /// Executes the Query and returns Integer
    /// </summary>
    /// <param name="Query"></param>
    /// <returns></returns>
    public int returnInt(string Query)
    {
        Int32 intData = 0;
        Objcon = new DBConnectionCls();
        try
        {
            con = Objcon.SqlConnectionDB();
            if (con.State == ConnectionState.Closed) con.Open();
            Sqlcmd = new SqlCommand(Query, con);
            intData = int.Parse(Sqlcmd.ExecuteScalar().ToString());
        }
        catch
        {
            return intData;
        }
        finally
        {
            con.Close();
        }
        return intData;
    }

    /// <summary>
    /// Executes the Query and returns Boolean
    /// </summary>
    /// <param name="Query"></param>
    /// <returns></returns>
    public Boolean returnBool(String Query)
    {
        Boolean Result = false;
        Objcon = new DBConnectionCls();
        try
        {
            con = Objcon.SqlConnectionDB();
            if (con.State == ConnectionState.Closed) con.Open();
            Sqlcmd = new SqlCommand(Query, con);
            Result = Convert.ToBoolean(Sqlcmd.ExecuteNonQuery());
        }
#pragma warning disable CS0168 // The variable 'ex' is declared but never used
        catch(Exception ex)
#pragma warning restore CS0168 // The variable 'ex' is declared but never used
        {
            return Result;
        }
        finally
        {
            con.Close();
        }
        return Result;
    }

    /// <summary>
    /// Executes the Query and returns DataTable
    /// </summary>
    /// <param name="Query"></param>
    /// <returns></returns>
    public DataTable returnDT(string Query)
    {
        Objcon = new DBConnectionCls();
        Dt = new DataTable();
        try
        {
            con = Objcon.SqlConnectionDB();
            if (con.State == ConnectionState.Closed) con.Open();
            Sqlcmd = new SqlCommand(Query, con);
            Ada = new SqlDataAdapter(Sqlcmd);
            Ada.Fill(Dt);
        }
        catch
        {
            return Dt;
        }
        finally
        {
            con.Close();
        }
        return Dt;
    }

    /// <summary>
    /// Executes the Query and returns DataSet
    /// </summary>
    /// <param name="Query"></param>
    /// <returns></returns>
    public DataSet returnDS(string Query)
    {
        Objcon = new DBConnectionCls();
        Dset = new DataSet();
        try
        {
            con = Objcon.SqlConnectionDB();
            if (con.State == ConnectionState.Closed) con.Open();
            Sqlcmd = new SqlCommand(Query, con);
            Ada = new SqlDataAdapter(Sqlcmd);
            Ada.Fill(Dset);
        }
        catch
        {
            return Dset;
        }
        finally
        {
            con.Close();
        }
        return Dset;
    }

    /// <summary>
    /// Executes the Query and returns String
    /// </summary>
    /// <param name="Query"></param>
    /// <returns></returns>
    public String returnString(string Query)
    {
        RetrunStr = string.Empty;
        Objcon = new DBConnectionCls();
        try
        {
            con = Objcon.SqlConnectionDB();
            if (con.State == ConnectionState.Closed) con.Open();
            Sqlcmd = new SqlCommand(Query, con);
            RetrunStr = Sqlcmd.ExecuteScalar().ToString();
        }
        catch
        {
            return RetrunStr;
        }
        finally
        {
            con.Close();
        }
        return RetrunStr;
    }

    /// <summary>
    /// Executes the Query and returns Date Time
    /// </summary>
    /// <param name="Query"></param>
    /// <returns></returns>
    public DateTime returnDateTime(string Query)
    {
        DateTime DateTimeVal = DateTime.Now;
        Objcon = new DBConnectionCls();
        try
        {
            con = Objcon.SqlConnectionDB();
            if (con.State == ConnectionState.Closed) con.Open();
            Sqlcmd = new SqlCommand(Query, con);
            DateTimeVal = Convert.ToDateTime(Sqlcmd.ExecuteScalar());
        }
        catch
        {
            return DateTimeVal;
        }
        finally
        {
            con.Close();
        }
        return DateTimeVal;
    }
}