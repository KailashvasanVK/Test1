﻿using System;
using System.Web.Mvc;

namespace ControlTower_Admin
{
    public class Err : HandleErrorAttribute
    {
        //public override void OnException(ExceptionContext filterContext)
        //{
        //    Exception ex = filterContext.Exception;
        //    filterContext.ExceptionHandled = true;
        //    var model = new HandleErrorInfo(filterContext.Exception, "Controller", "Action");

        //    filterContext.Result = new ViewResult()
        //    {
        //        ViewName = "Error1",
        //        ViewData = new ViewDataDictionary(model)
        //    };
        //}
    }
}