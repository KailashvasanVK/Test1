﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DBConnectionCls
/// </summary>
public class DBConnectionCls
{

    #region "DATA BASE VARIALBLE DECLARATION"

    public SqlConnection con;

    #endregion

    #region "DATA BASE CONNECTION CODING"

    public SqlConnection SqlConnectionDB()
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["connStr"].ConnectionString);
        return con;
    }

    #endregion
}