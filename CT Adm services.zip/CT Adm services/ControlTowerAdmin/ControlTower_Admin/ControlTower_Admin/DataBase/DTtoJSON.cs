﻿using System.Collections.Generic;
using System.Data;

namespace ControlTower_Admin
{
    public static class ConvertasJSON
    {
        public static List<Dictionary<string, object>> ToJson(this System.Data.DataTable dt)
        {
            List<Dictionary<string, object>> parentRow;
            Dictionary<string, object> childRow;
            parentRow = new List<Dictionary<string, object>>();

            foreach (DataRow row in dt.Rows)
            {
                childRow = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    childRow.Add(col.ColumnName, row[col]);
                }
                parentRow.Add(childRow);
            }
            return parentRow;
        }
        public static List<Dictionary<string, object>>[] ToJson(this System.Data.DataSet ds)
        {
            List<Dictionary<string, object>>[] parentRow1 = new List<Dictionary<string, object>>[ds.Tables.Count];
            foreach (DataTable dt in ds.Tables)
            {

                List<Dictionary<string, object>> parentRow;
                Dictionary<string, object> childRow;
                parentRow = new List<Dictionary<string, object>>();


                foreach (DataRow row in dt.Rows)
                {
                    childRow = new Dictionary<string, object>();
                    foreach (DataColumn col in dt.Columns)
                    {
                        childRow.Add(col.ColumnName, row[col]);
                    }
                    parentRow.Add(childRow);
                }
                parentRow1[ds.Tables.IndexOf(dt)] = new List<Dictionary<string, object>>();
                parentRow1[ds.Tables.IndexOf(dt)] = parentRow;
            }

            return parentRow1;
        }
    }

}