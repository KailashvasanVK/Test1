﻿using SimpleCqrs.Commanding;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Echobot.Contracts.Commands
{
    public class RegisterClientSideCommand : ICommand
    {
        public string SerialKey { get; set; }

        public RegisterClientSideCommand(string serialKey)
        {
            SerialKey = serialKey;
        }
    }
}
