﻿using SimpleCqrs.Commanding;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Echobot.Contracts.Commands
{
    public class CreateTransactionCommand : ICommand
    {
        public Guid ProcessId { get; set; }
        public Guid BotClientId { get; set; }
        public string DomainName { get; set; }
        public string UserName { get; set; }
        public string ReferenceId { get; set; }
        public DateTime EventStart { get; set; }
        public DateTime EventEnd { get; set; }

        public CreateTransactionCommand(Guid processId, Guid botClientId, string domainName,string userName,string referenceId, DateTime eventStart, DateTime eventEnd)
        {
            ProcessId = processId;
            BotClientId = botClientId;
            DomainName = domainName;
            UserName = userName;
            ReferenceId = referenceId;
            EventStart = eventStart;
            EventEnd = eventEnd;
        }
    }
}
