﻿using SimpleCqrs.Commanding;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Echobot.Contracts.Commands
{
    public class CreateProcessCommand : ICommand
    {
        public string CompanyId { get; set; }
        public string ProcessName { get; set; }
        public string Description { get; set; }
        public CreateProcessCommand(string companyId, string processName, string description)
        {
            CompanyId = companyId;
            ProcessName = processName;
            Description = description;
        }
    }
}
