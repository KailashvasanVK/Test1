﻿using SimpleCqrs.Eventing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Echobot.Contracts.Events
{
    public class LicenseRevokedEvent : DomainEvent
    {
        public bool Status { get; set; }

        public LicenseRevokedEvent(Guid id, bool status)
        {
            AggregateRootId = id;
            Status = status;
        }
    }
}
