﻿using SimpleCqrs.Eventing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Echobot.Contracts.Events
{
    public class UpdateBotInstancesEvent : DomainEvent
    {
        public int BotInstances { get; set; }

        public UpdateBotInstancesEvent(Guid id, int botInstances)
        {
            AggregateRootId = id;
            BotInstances = botInstances;
        }
    }
}
