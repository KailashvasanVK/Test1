﻿using SimpleCqrs.Eventing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Echobot.Contracts.Events
{
    public class ContactChangedEvent : DomainEvent
    {
        public string CompanyAddress { get; set; }
        public string ContactEmailId { get; set; }
        public string ContactMobile { get; set; }

        public ContactChangedEvent(Guid id, string newAddress, string newEmailId, string newMobile)
        {
            AggregateRootId = id;
            CompanyAddress = newAddress;
            ContactEmailId = newEmailId;
            ContactMobile = newMobile;
        }
    }
}
