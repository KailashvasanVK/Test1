﻿using SimpleCqrs.Eventing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Echobot.Contracts.Events
{
    public class LicenseRegisteredClientEvent : DomainEvent
    {
        public string SerialKey { get; set; }

        public LicenseRegisteredClientEvent(Guid id, string serialKey)
        {
            AggregateRootId = id;
            SerialKey = serialKey;
        }
    }
}
