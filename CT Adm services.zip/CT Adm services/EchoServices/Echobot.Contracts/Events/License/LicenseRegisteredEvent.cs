﻿using SimpleCqrs.Eventing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Echobot.Contracts.Events
{
    public class LicenseRegisteredEvent : DomainEvent
    {
        public string Name { get; set; }
        public string Address { get; set; }
        public string ContactEmailId { get; set; }
        public string ContactMobile { get; set; }
        //public Guid SerialKey { get; set; }
        public int BotInstances { get; set; }
        public bool Status { get; set; }

        public LicenseRegisteredEvent(Guid echolicenseId, string companyName, string companyAddress, string emailId, string companyMobile, int botInstances, bool status)
        {
            AggregateRootId = echolicenseId;
            Name = companyName;
            Address = companyAddress;
            ContactEmailId = emailId;
            ContactMobile = companyMobile;
            //SerialKey = serialKey;
            BotInstances = botInstances;
            Status = status;
        }
    }
}
