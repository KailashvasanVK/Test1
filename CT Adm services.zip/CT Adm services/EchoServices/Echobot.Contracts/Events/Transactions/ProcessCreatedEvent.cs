﻿using SimpleCqrs.Eventing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Echobot.Contracts.Events
{
    public class ProcessCreatedEvent : DomainEvent
    {
        public string CompanyId { get; set; }
        public string ProcessName { get; set; }
        public string Description { get; set; }

        public ProcessCreatedEvent(Guid processId, string companyId, string processName, string description)
        {
            AggregateRootId = processId;
            CompanyId = companyId;
            ProcessName = processName;
            Description = description;
        }
    }
}
