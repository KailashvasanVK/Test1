﻿using SimpleCqrs.Eventing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Echobot.Contracts.Events
{
    public class BotClientCreatedEvent:DomainEvent
    {
        public string CompanyId { get; set; }
        public int MachineId { get; set; }
        public string MachineName { get; set; }

        public BotClientCreatedEvent(Guid botclientId, string companyId, int machineId, string machineName)
        {
            AggregateRootId = botclientId;
            CompanyId = companyId;
            MachineId = machineId;
            MachineName = machineName;
        }
    }
}
