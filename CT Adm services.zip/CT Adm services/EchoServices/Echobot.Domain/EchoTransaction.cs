﻿using Echobot.Contracts.Events;
using SimpleCqrs.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Echobot.Domain
{
    public class echobot_lic_processTransaction : AggregateRoot
    {
        public Guid ProcessId { get; set; }
        public Guid BotClientId { get; set; }
        public string DomainName { get; set; }
        public string UserName { get; set; }
        public string ReferenceId { get; set; }
        public DateTime EventStart { get; set; }
        public DateTime EventEnd { get; set; }

        public echobot_lic_processTransaction() { }

        public echobot_lic_processTransaction(Guid trnId, Guid processId, Guid botClientId, string domainName, string userName, string referenceId, DateTime eventStart, DateTime eventEnd)
        {
            Apply(new TransactionCreatedEvent(trnId, processId, botClientId, domainName, userName, referenceId, eventStart, eventEnd));
        }

        protected void OnTransactionCreated(TransactionCreatedEvent domainEvent)
        {
            Id = domainEvent.AggregateRootId;
            ProcessId = domainEvent.ProcessId;
            BotClientId = domainEvent.BotClientId;
            DomainName = domainEvent.DomainName;
            UserName = domainEvent.UserName;
            ReferenceId = domainEvent.ReferenceId;
            EventStart = domainEvent.EventStart;
            EventEnd = domainEvent.EventEnd;
        }
    }

    public class echobot_lic_process : AggregateRoot
    {
        public string CompanyId { get; set; }
        public string ProcessName { get; set; }
        public string Description { get; set; }

        public echobot_lic_process() { }

        public echobot_lic_process(Guid processId, string companyId, string processName, string description)
        {
            Apply(new ProcessCreatedEvent(processId, companyId, processName, description));
        }

        protected void OnProcessCreated(ProcessCreatedEvent domainEvent)
        {
            Id = domainEvent.AggregateRootId;
            CompanyId = domainEvent.CompanyId;
            ProcessName = domainEvent.ProcessName;
            Description = domainEvent.Description;
        }
    }

    public class echobot_lic_botClient : AggregateRoot
    {
        public string CompanyId { get; set; }
        public int MachineId { get; set; }
        public string MachineName { get; set; }

        public echobot_lic_botClient() { }

        public echobot_lic_botClient(Guid botId, string companyId, int machineId, string machineName)
        {
            Apply(new BotClientCreatedEvent(botId, companyId, machineId, machineName));
        }

        protected void OnBotClientCreated(BotClientCreatedEvent domainEvent)
        {
            Id = domainEvent.AggregateRootId;
            CompanyId = domainEvent.CompanyId;
            MachineId = domainEvent.MachineId;
            MachineName = domainEvent.MachineName;
        }
    }
}