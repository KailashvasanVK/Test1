﻿using Echobot.Contracts.Events;
using SimpleCqrs.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Echobot.Domain
{
    public class echobot_lic_companyDetails : AggregateRoot
    {
        public string CompanyName { get; set; }
        public string CompanyAddress { get; set; }
        public string ContactEmailId { get; set; }
        public string ContactMobile { get; set; }
        //public Guid SerialKey { get; set; }
        public int BotInstances { get; set; }
        public bool Status { get; set; }
        public echobot_lic_companyDetails() { }

        public echobot_lic_companyDetails(Guid echolicenseId, string name, string address, string emailId, string mobile, int botInstances, bool status)
        {
            Apply(new LicenseRegisteredEvent(echolicenseId, name, address, emailId, mobile, botInstances, status));
        }

        public void Update(Guid echolicenseId, string newAddress, string emailId, string mobile, int botInstances, bool licStatus)
        {
            if (newAddress != CompanyAddress || emailId != ContactEmailId || mobile != ContactMobile)
            {
                Apply(new ContactChangedEvent(echolicenseId, newAddress, emailId, mobile));
            }
            if (!licStatus)
            {
                Apply(new LicenseRevokedEvent(echolicenseId, licStatus));
            }
            if (botInstances != BotInstances)
            {
                Apply(new UpdateBotInstancesEvent(echolicenseId, botInstances));
            }
        }

        protected void OnLicenseRegistered(LicenseRegisteredEvent domainEvent)
        {
            Id = domainEvent.AggregateRootId;
            CompanyName = domainEvent.Name;
            CompanyAddress = domainEvent.Address;
            ContactEmailId = domainEvent.ContactEmailId;
            ContactMobile = domainEvent.ContactMobile;
        }

        protected void OnLicenseRevoked(LicenseRevokedEvent domainEvent)
        {
            Status = domainEvent.Status;
        }

        protected void OnContactChanged(ContactChangedEvent domainEvent)
        {
            CompanyAddress = domainEvent.CompanyAddress;
            ContactEmailId = domainEvent.ContactEmailId;
            ContactMobile = domainEvent.ContactMobile;
        }

        protected void OnUpdateBotInstances(UpdateBotInstancesEvent domainEvent)
        {
            BotInstances = domainEvent.BotInstances;
        }
    }

    public class echobot_lic_clientSide : AggregateRoot
    {
        public string SerialKey { get; set; }
        public echobot_lic_clientSide(Guid id, string serialKey)
        {
            Apply(new LicenseRegisteredClientEvent(id, serialKey));
        }
    }
}
