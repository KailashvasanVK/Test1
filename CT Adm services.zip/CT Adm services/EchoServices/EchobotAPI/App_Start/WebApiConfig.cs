﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web.Http;
using Microsoft.Owin.Security.OAuth;
using Newtonsoft.Json.Serialization;
using Echobot.License.ReadModel.Repositories.Interfaces;
using EchobotAPI.Resolver;
using Echobot.License.ReadModel.Repositories;
using System.Web.Http.Cors;
using Microsoft.Practices.Unity;
using System.Web.Http.ExceptionHandling;
using EchobotAPI.ExceptionsLogger;
using EchobotAPI.ErrorHandling;

namespace EchobotAPI
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            var corsAttr = new EnableCorsAttribute("*", "*", "*");
            config.EnableCors(corsAttr);

            var container = new UnityContainer();
            container.RegisterType<ILicenseRepository, LicenseRepository>(new HierarchicalLifetimeManager());
            config.DependencyResolver = new UnityResolver(container);

            // Web API configuration and services
            // Configure Web API to use only bearer token authentication.
            config.SuppressDefaultHostAuthentication();
            config.Filters.Add(new HostAuthenticationFilter(OAuthDefaults.AuthenticationType));

            //Exception Handler
            config.Services.Replace(typeof(IExceptionHandler), new PassthroughHandler());
            config.Services.Add(typeof(IExceptionLogger), new ExceptionManagerApi());

            // Web API routes
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );
        }
    }
}
