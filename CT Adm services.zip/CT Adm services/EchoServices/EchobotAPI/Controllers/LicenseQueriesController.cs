﻿using Echobot.License.ReadModel;
using Echobot.License.ReadModel.Repositories.Interfaces;
using EchobotAPI.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Web.Http;
using System.Web.Script.Serialization;

namespace EchobotAPI.Controllers
{
    [Authorize]
    [RoutePrefix("lquery")]
    public class LicenseQueriesController : ApiController
    {

        private readonly ILicenseRepository _licenseRepo;

        public LicenseQueriesController(ILicenseRepository licenseRepo)
        {
            _licenseRepo = licenseRepo;
        }

        public IEnumerable<echobot_lic_companyDetails> Get()
        {
            return _licenseRepo.GetAll();
        }

        [Route("key")]
        [HttpPost]
        public IHttpActionResult LicenseValidation(LicenseInfoFetchModel info)
        {
            var record = _licenseRepo.GetByClientKey(info.HashToken);
            var decrypted = RSAEncryptionService.Decrypt(info.UserKey, record.PrivateLicenseKey);

            var isValid = _licenseRepo.ValidateLicense(Guid.Parse(decrypted));
            return Ok(isValid);
        }

        [Route("userKey")]
        [HttpPost]
        public IHttpActionResult GenerateUserKey([FromBody]string hashToken)
        {
            var record = _licenseRepo.GetByClientKey(hashToken);
            if (record != null)
            {
                var encryptedLicenseKey = RSAEncryptionService.Encrypt(Convert.ToString(record.id), hashToken);
                return Ok(encryptedLicenseKey);
            }
            return BadRequest("Invalid token");
        }

        [Route("licInfo")]
        [HttpPost]
        public IHttpActionResult GetLicenseInfo(LicenseInfoFetchModel info)
        {
            var record = _licenseRepo.GetByClientKey(info.HashToken);
            var decrypted = RSAEncryptionService.Decrypt(info.UserKey, record.PrivateLicenseKey);

            if (record != null)
            {
                var lRecord = _licenseRepo.GetByID(Guid.Parse(decrypted));
                if (lRecord != null)
                    return Ok(new LicenseInformation() { LicenseSerialKey = info.UserKey, HashToken = info.HashToken, ValidFrom = record.validFrom, ValidTo = record.validTo, UserName = record.name, EmailId = record.contactEmailId, BotInstances = record.botInstances });
            }
            return BadRequest(message: "Record not found");
        }

        [Route("ide/key")]
        [HttpPost]
        public IHttpActionResult IdeVerification(LicenseInfoFetchModel info)
        {
            var record = _licenseRepo.GetByClientKey(info.HashToken);
            var decrypted = RSAEncryptionService.Decrypt(info.UserKey, record.PrivateLicenseKey);

            var lRecord = _licenseRepo.GetByID(Guid.Parse(decrypted));
            if (lRecord != null)
            {
                return Ok("Valid Key");
            }
            else
            {
                return BadRequest(message: "Invalid Key");
            }
        }

        [Route("generateLic")]
        [HttpPost]
        public IHttpActionResult LicenseFileGeneration(LicenseInfoFetchModel info)
        {
            try
            {
                var record = _licenseRepo.GetByClientKey(info.HashToken);
                var decrypted = RSAEncryptionService.Decrypt(info.UserKey, record.PrivateLicenseKey);
                LicenseInformation lic;
                if (record != null)
                {
                    var lRecord = _licenseRepo.GetByID(Guid.Parse(decrypted));
                    if (lRecord != null)
                    {
                        lic = new LicenseInformation() { LicenseSerialKey = info.UserKey, HashToken = info.HashToken, ValidFrom = record.validFrom, ValidTo = record.validTo, UserName = record.name, EmailId = record.contactEmailId, BotInstances = record.botInstances };
                        string pathToLicense = @"\\10.20.0.185\it-ahs\EchoBot\License\" + lic.UserName + "_EchoBotLicense.lic";
                        File.WriteAllText(pathToLicense, TripleDESEncryptionService.Encrypt(new JavaScriptSerializer().Serialize(lic), true, "ech0B0t@h$"));
                        Mailer.sendMail(new MailInformation()
                        {
                            From = "mail.support@accesshealthcare.co",
                            To = lic.EmailId,
                            Subject = "Your Echobot License",
                            CarbonCopy = "",
                            Body = "Attachment contains Echobot license file.</br> Kindly register it in control tower.</br></br>",
                            IsHtml = true,
                            FilePath = pathToLicense
                        });
                        return Ok(true);
                    }
                    else
                        return BadRequest("No license details found for the key");
                }
                else
                    return BadRequest("Invalid key or token");
            }
            catch(Exception ex)
            {
                return BadRequest(message: ex.InnerException.StackTrace);
            }
        }
        [Route("decryptLic")]
        [HttpPost]
        public IHttpActionResult LicenseFileDecryption([FromBody]string encryptedString)
        {
            LicenseInformation obj = new JavaScriptSerializer().Deserialize<LicenseInformation>(TripleDESEncryptionService.Decrypt(encryptedString, true, "ech0B0t@h$"));
            return Ok(obj);
        }

        [AllowAnonymous]
        [Route("Token")]
        [HttpPost]
        public IHttpActionResult Token(LicenseInfoFetchModel info)
        {
                var record = _licenseRepo.GetByClientKey(info.HashToken);
                var decrypted = RSAEncryptionService.Decrypt(info.UserKey, record.PrivateLicenseKey);
                var _company = _licenseRepo.GetByID(Guid.Parse(decrypted));
                if (_company != null)
                {
                        var _tokenDetails = Providers.ApplicationOAuthProvider.GetUserAuthToken(_company);
                        return Ok(_tokenDetails);
                }
                else
                {
                return BadRequest(message: "Invalid Credentials");
                }
        }
    }
}
