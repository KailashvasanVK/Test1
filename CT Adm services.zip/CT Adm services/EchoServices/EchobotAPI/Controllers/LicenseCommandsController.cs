﻿namespace EchobotAPI.Controllers
{
    using Echobot.Contracts.Commands;
    using Echobot.License.CommandHandler;
    using Echobot.License.ReadModel;
    using Echobot.License.ReadModel.Repositories.Interfaces;
    using SimpleCqrs;
    using SimpleCqrs.Commanding;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;

    [Authorize]
    [RoutePrefix("lcommand")]
    public class LicenseCommandsController : ApiController
    {
        public ICommandBus CommandBus;

        public LicenseCommandsController() : this(ServiceLocator.Current.Resolve<ICommandBus>())
        {
        }

        public LicenseCommandsController(ICommandBus commandBus)
        {
            CommandBus = commandBus;
        }

        [HttpPost]
        [Route("register")]
        public IHttpActionResult LicenseRegistration(RegisterLicenseCommand command)
        {
            try
            {
                var result = (RegisterLicenseStatus)CommandBus.Execute(command);
                if (result == RegisterLicenseStatus.Successful)
                {
                    return Ok();
                }
                return BadRequest("Sorry something happened.Try again!");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.InnerException.Message);
            }
        }

        [HttpPost]
        [Route("client/register")]
        public IHttpActionResult LicenseClientRegistration(RegisterClientSideCommand command)
        {
            var result = (RegisterClientStatus)CommandBus.Execute(command);
            if (result == RegisterClientStatus.Successful)
            {
                return Ok();
            }
            return BadRequest("Sorry something happened.Try again!");
        }
        [HttpPost]
        [Route("update")]
        public void UpdateLicenseStatus(UpdateLicenseCommand command)
        {
            CommandBus.Execute(command);
        }
    }
}
