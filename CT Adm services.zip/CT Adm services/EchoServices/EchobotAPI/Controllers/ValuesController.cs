﻿using Echobot.Contracts.Commands;
using Echobot.License.CommandHandler;
using SimpleCqrs;
using SimpleCqrs.Commanding;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace EchobotAPI.Controllers
{
    [Authorize]
    public class ValuesController : ApiController
    {
        public IEnumerable<string> Get()
        {
            return new string[] { "TestResult1", "Result2" };
        }
    }
}
