﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace EchobotAPI.Services
{
    public class EncryptionService
    {
        /// <summary>
        /// RSA encryption Service
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static Tuple<string, string, string> Encrypt(string value)
        {
            string encryptedString = string.Empty;
            string publicKey = string.Empty, privateKey = string.Empty;

            if (!string.IsNullOrEmpty(value))
            {
                var csp = new RSACryptoServiceProvider(2048);
                var privKey = csp.ExportParameters(true);
                var pubKey = csp.ExportParameters(false);

                var sw = new System.IO.StringWriter();
                var xs = new System.Xml.Serialization.XmlSerializer(typeof(RSAParameters));
                xs.Serialize(sw, pubKey);
                publicKey = sw.ToString();
                xs.Serialize(sw, privKey);
                privateKey = sw.ToString();
                csp = new RSACryptoServiceProvider();
                csp.ImportParameters(pubKey);

                var bytesData = Encoding.Unicode.GetBytes(value);

                //apply pkcs#1.5 padding and encrypt our data 
                var bytesEncrypted = csp.Encrypt(bytesData, false);
                var cypherText = Convert.ToBase64String(bytesEncrypted);
            }
            return new Tuple<string, string, string>(publicKey, privateKey, encryptedString);
        }
        /// <summary>
        /// RSA decryption service
        /// </summary>
        /// <param name="encryptedValue"></param>
        /// <param name="publicKey"></param>
        /// <param name="privateKey"></param>
        /// <returns></returns>
        public string Decrypt(string encryptedValue, string publicKey, string privateKey)
        {
            var pub = new System.IO.StringReader(publicKey);
            var priv = new System.IO.StringReader(publicKey);
            var xs = new System.Xml.Serialization.XmlSerializer(typeof(RSAParameters));
            var pubKey = (RSAParameters)xs.Deserialize(pub);
            var privKey = (RSAParameters)xs.Deserialize(priv);
            var bytesEncrypted = Convert.FromBase64String(encryptedValue);

            var csp = new RSACryptoServiceProvider();
            csp.ImportParameters(privKey);

            var bytesData = csp.Decrypt(bytesEncrypted, false);

            string decryptedValue = System.Text.Encoding.Unicode.GetString(bytesData);
            return decryptedValue;
        }
    }
}