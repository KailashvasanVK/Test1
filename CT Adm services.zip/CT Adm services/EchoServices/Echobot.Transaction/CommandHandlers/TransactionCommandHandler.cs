﻿using Echobot.Contracts.Commands;
using SimpleCqrs.Commanding;
using SimpleCqrs.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Echobot.Transaction.CommandHandlers
{
    public class TransactionCommandHandler : CommandHandler<CreateTransactionCommand>
    {
        protected IDomainRepository _repository;

        public TransactionCommandHandler(IDomainRepository repository)
        {
            _repository = repository;
        }

        public override void Handle(CreateTransactionCommand command)
        {

            var location = new Domain.echobot_lic_processTransaction(Guid.NewGuid(), command.ProcessId, command.BotClientId, command.DomainName, command.UserName, command.ReferenceId, command.EventStart, command.EventEnd);

            _repository.Save(location);
        }
    }
}
