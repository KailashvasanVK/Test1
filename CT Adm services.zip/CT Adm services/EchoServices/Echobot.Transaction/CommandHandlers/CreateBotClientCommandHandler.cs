﻿using Echobot.Contracts.Commands;
using SimpleCqrs.Commanding;
using SimpleCqrs.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Echobot.Transaction.CommandHandlers
{

    public enum BotClientCreatedStatus
    {
        Successful
    }
    public class CreateBotClientCommandHandler : CommandHandler<CreateBotClientCommand>
    {
        protected IDomainRepository _repository;

        public CreateBotClientCommandHandler(IDomainRepository repository)
        {
            _repository = repository;
        }

        public override void Handle(CreateBotClientCommand command)
        {
            Return(ValidateCommand(command));
            var location = new Domain.echobot_lic_botClient(Guid.NewGuid(), command.CompanyId, command.MachineId, command.MachineName);

            _repository.Save(location);
        }

        protected BotClientCreatedStatus ValidateCommand(CreateBotClientCommand command)
        {
            return BotClientCreatedStatus.Successful;
        }
    }
}
