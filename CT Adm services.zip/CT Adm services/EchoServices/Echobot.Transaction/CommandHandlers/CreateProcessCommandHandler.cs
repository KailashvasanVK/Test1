﻿using Echobot.Contracts.Commands;
using SimpleCqrs.Commanding;
using SimpleCqrs.Domain;
using System;

namespace Echobot.Transaction.CommandHandlers
{
    public enum ProcessCreatedStatus
    {
        Successful
    }
    public class CreateProcessCommandHandler : CommandHandler<CreateProcessCommand>
    {
        protected IDomainRepository _repository;

        public CreateProcessCommandHandler(IDomainRepository repository)
        {
            _repository = repository;
        }

        public override void Handle(CreateProcessCommand command)
        {
            Return(ValidateCommand(command));
            var location = new Domain.echobot_lic_process(Guid.NewGuid(), command.CompanyId, command.ProcessName, command.Description);

            _repository.Save(location);
        }

        protected ProcessCreatedStatus ValidateCommand(CreateProcessCommand command)
        {
            return ProcessCreatedStatus.Successful;
        }
    }
}
