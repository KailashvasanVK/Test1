﻿using Echobot.Contracts.Events;
using Echobot.Transaction.ReadModel;
using SimpleCqrs.Eventing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Echobot.Transaction.EventHandlers
{
    public class TransactionEventHandler : IHandleDomainEvents<TransactionCreatedEvent>, IHandleDomainEvents<ProcessCreatedEvent>, IHandleDomainEvents<BotClientCreatedEvent>
                
    {
        public void Handle(ProcessCreatedEvent domainEvent)
        {
            using (TransactionModel dbEntity = new TransactionModel())
            {
                dbEntity.echobot_lic_process.Add(new echobot_lic_process()
                {
                    id = domainEvent.AggregateRootId,
                    company_id = Guid.Parse(domainEvent.CompanyId),
                    name = domainEvent.ProcessName,
                    description = domainEvent.Description,
                    createdOn = DateTime.Now
                });

                dbEntity.SaveChanges();
            }
        }

        public void Handle(TransactionCreatedEvent domainEvent)
        {
            using (TransactionModel dbEntity = new TransactionModel())
            {
                dbEntity.echobot_lic_processTransaction.Add(new echobot_lic_processTransaction() {
                    process_id = domainEvent.ProcessId,
                    botClient_id = domainEvent.BotClientId,
                    domainName = domainEvent.DomainName,
                    referenceId = domainEvent.ReferenceId,
                    userName = domainEvent.UserName,
                    eventStart = domainEvent.EventStart,
                    eventEnd = domainEvent.EventEnd
                });

                dbEntity.SaveChanges();
            }
        }

        public void Handle(BotClientCreatedEvent domainEvent)
        {
            using (TransactionModel dbEntity = new TransactionModel())
            {
                dbEntity.echobot_lic_botClient.Add(new echobot_lic_botClient()
                {
                    Id = domainEvent.AggregateRootId,
                    company_id = Guid.Parse(domainEvent.CompanyId),
                    machineId = domainEvent.MachineId,
                    machineName = domainEvent.MachineName,
                    createdOn = DateTime.Now,
                    status = true,
                    modifiedOn = DateTime.Now
                });

                dbEntity.SaveChanges();
            }
        }
    }
}
