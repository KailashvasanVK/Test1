﻿using Echobot.Transaction.ReadModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Echobot.Transaction.ReadModel.Repositories.Interfaces
{
    public interface ITransactionRepository
    {
        IEnumerable<echobot_lic_process> GetAll();
        echobot_lic_process GetByID(Guid id);
        echobot_lic_companyDetails GetCompanyByClientKey(string publicKey);
        echobot_lic_companyDetails GetCompanyById(Guid id);
    }
}
    