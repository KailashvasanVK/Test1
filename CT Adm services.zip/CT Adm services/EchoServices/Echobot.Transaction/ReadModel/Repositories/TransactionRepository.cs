﻿using Echobot.Transaction.ReadModel;
using Echobot.Transaction.ReadModel.Repositories.Interfaces;
using Microsoft.Practices.Unity;
using SimpleCqrs.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Echobot.Transaction.ReadModel.Repositories
{
    public class TransactionRepository : IDisposable,ITransactionRepository
    {
        public TransactionModel context = new TransactionModel();
        public IEnumerable<echobot_lic_process> GetAll()
        {
            return context.echobot_lic_process;
        }
        public echobot_lic_process GetByID(Guid id)
        {
            return context.echobot_lic_process.FirstOrDefault(p => p.id == id);
        }

        public echobot_lic_companyDetails GetCompanyByClientKey(string publicKey)
        {
            var record = context.echobot_lic_companyDetails.FirstOrDefault(p => p.PublicLicenseKey == publicKey);
            return record;
        }
        public echobot_lic_companyDetails GetCompanyById(Guid id)
        {
            var record = context.echobot_lic_companyDetails.FirstOrDefault(p => p.id == id);
            return record;
        }
        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    if (context != null)
                    {
                        context.Dispose();
                        context = null;
                    }
                }

                disposedValue = true;
            }
        }

         void IDisposable.Dispose()
        {
            Dispose(true);
            // GC.SuppressFinalize(this);
        }
       #endregion
    }
}
