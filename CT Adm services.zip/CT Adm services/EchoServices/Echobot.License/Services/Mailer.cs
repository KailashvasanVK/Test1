﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Echobot.License.ReadModel
{
    public static class Mailer
    {
        public static void sendMail(MailInformation info)
        {
            using (SqlConnection conn = new SqlConnection("Data source=SQL-Listner; Persist Security Info=false; Initial Catalog=ARC_REC; UID=Docmenttooluser; PWD=D@cum@ntt@@lu5@r;pooling=false;multisubnetfailover=true;"))
            {
                using (SqlCommand cmd = new SqlCommand("Exec SP_INS_ARC_REC_MAIL_TRAN '" + info.From + "','" + info.To + "','" + info.CarbonCopy + "','" + info.Subject + "','" + info.Body + "','" + (info.IsHtml ? "Y" : "N") + "','" + info.FilePath + "'", conn))
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
        }
    }
}
