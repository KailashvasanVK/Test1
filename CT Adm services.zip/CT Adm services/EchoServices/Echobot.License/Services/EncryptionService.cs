﻿using System;
using System.Security.Cryptography;
using System.Text;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.OpenSsl;
using Org.BouncyCastle.Security;
using System.IO;
using System.Web;

namespace Echobot.License.ReadModel
{
    public static class TripleDESEncryptionService
    {
        public static string Encrypt(string toEncrypt, bool useHashing, string SecurityKey)
        {
            byte[] keyArray;
            byte[] toEncryptArray = UTF8Encoding.UTF8.GetBytes(toEncrypt);
            string key = SecurityKey;
            if (useHashing)
            {
                MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
                keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(key));
                hashmd5.Clear();
            }
            else
                keyArray = UTF8Encoding.UTF8.GetBytes(key);

            TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider
            {
                Key = keyArray,
                Mode = CipherMode.ECB,
                Padding = PaddingMode.PKCS7
            };

            ICryptoTransform cTransform = tdes.CreateEncryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
            tdes.Clear();
            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }
        public static string Decrypt(string cipherString, bool useHashing, string SecurityKey)
        {
            byte[] keyArray;

            byte[] toEncryptArray = Convert.FromBase64String(cipherString);
            string key = SecurityKey;

            if (useHashing)
            {
                MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
                keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(key));

                hashmd5.Clear();
            }
            else
            {
                keyArray = UTF8Encoding.UTF8.GetBytes(key);
            }

            TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider
            {
                Key = keyArray,
                Mode = CipherMode.ECB,
                Padding = PaddingMode.PKCS7
            };

            ICryptoTransform cTransform = tdes.CreateDecryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
            tdes.Clear();
            return UTF8Encoding.UTF8.GetString(resultArray);
        }
    }

    public static class RSAEncryptionService
    {
        /// <summary>
        /// Generates public and private keys
        /// </summary>
        /// <returns></returns>
        public static Tuple<string, string> GetKeys()
        {
            var csp = new RSACryptoServiceProvider(2048);
            return new Tuple<string, string>(RSAKeys.ExportPublicKey(csp), RSAKeys.ExportPrivateKey(csp));
        }
       /// <summary>
       /// RSA encryption Service
       /// </summary>
       /// <param name="_value"></param>
       /// <param name="_publicKey"></param>
       /// <returns></returns>
        public static string Encrypt(string _value, string _publicKey)
        {
            string encryptedString = string.Empty;
            if (!string.IsNullOrEmpty(_value))
            {
                _publicKey = HttpUtility.UrlDecode(_publicKey);
                var csp = RSAKeys.ImportPublicKey(_publicKey);
                var bytesData = Encoding.Unicode.GetBytes(_value);

                //apply pkcs#1.5 padding and encrypt our data 
                var bytesEncrypted = csp.Encrypt(bytesData, false);
                encryptedString = Convert.ToBase64String(bytesEncrypted);
            }
            return  encryptedString;
        }
        /// <summary>
        /// RSA decryption service
        /// </summary>
        /// <param name="_encryptedValue"></param>
        /// <param name="_privateKey"></param>
        /// <returns></returns>
        public static string Decrypt(string _encryptedValue, string _privateKey)
        {
            _privateKey = HttpUtility.UrlDecode(_privateKey);
            var bytesEncrypted = Convert.FromBase64String(_encryptedValue);
            var csp = RSAKeys.ImportPrivateKey(_privateKey);

            var bytesData = csp.Decrypt(bytesEncrypted, false);

            string decryptedValue = Encoding.Unicode.GetString(bytesData);
            return decryptedValue;
        }
    }

    public static class RSAKeys
    {
        /// <summary>
        /// OpenSSH PEM private key string into RSA import
        /// </summary>
        /// <param name="_pem"></param>
        /// <returns></returns>
        public static RSACryptoServiceProvider ImportPrivateKey(string _pem)
        {
            PemReader pr = new PemReader(new StringReader(_pem));
            AsymmetricCipherKeyPair keyPair = (AsymmetricCipherKeyPair)pr.ReadObject();
            RSAParameters rsaParams = DotNetUtilities.ToRSAParameters((RsaPrivateCrtKeyParameters)keyPair.Private);

            RSACryptoServiceProvider csp = new RSACryptoServiceProvider();
            csp.ImportParameters(rsaParams);
            return csp;
        }
        /// <summary>
        /// OpenSSH PEM public key string into RSA import
        /// </summary>
        /// <param name="_pem"></param>
        /// <returns></returns>
        public static RSACryptoServiceProvider ImportPublicKey(string _pem)
        {
            PemReader pr = new PemReader(new StringReader(_pem));
            AsymmetricKeyParameter publicKey = (AsymmetricKeyParameter)pr.ReadObject();
            RSAParameters rsaParams = DotNetUtilities.ToRSAParameters((RsaKeyParameters)publicKey);

            RSACryptoServiceProvider csp = new RSACryptoServiceProvider();
            csp.ImportParameters(rsaParams);
            return csp;
        }

        /// <summary>
        /// RSA private key into OpenSSH PEM string export
        /// </summary>
        /// <param name="_csp"></param>
        /// <returns></returns>
        public static string ExportPrivateKey(RSACryptoServiceProvider _csp)
        {
            StringWriter outputStream = new StringWriter();
            if (_csp.PublicOnly) throw new ArgumentException("CSP does not contain a private key", "csp");
            var _params = _csp.ExportParameters(true);
            using (var stream = new MemoryStream())
            {
                var writer = new BinaryWriter(stream);
                writer.Write((byte)0x30); 
                using (var innerStream = new MemoryStream())
                {
                    var innerWriter = new BinaryWriter(innerStream);
                    EncodeIntegerBigEndian(innerWriter, new byte[] { 0x00 }); 
                    EncodeIntegerBigEndian(innerWriter, _params.Modulus);
                    EncodeIntegerBigEndian(innerWriter, _params.Exponent);
                    EncodeIntegerBigEndian(innerWriter, _params.D);
                    EncodeIntegerBigEndian(innerWriter, _params.P);
                    EncodeIntegerBigEndian(innerWriter, _params.Q);
                    EncodeIntegerBigEndian(innerWriter, _params.DP);
                    EncodeIntegerBigEndian(innerWriter, _params.DQ);
                    EncodeIntegerBigEndian(innerWriter, _params.InverseQ);
                    var length = (int)innerStream.Length;
                    EncodeLength(writer, length);
                    writer.Write(innerStream.GetBuffer(), 0, length);
                }

                var base64 = Convert.ToBase64String(stream.GetBuffer(), 0, (int)stream.Length).ToCharArray();
                // Output as Base64 with lines chopped at 64 characters
                outputStream.Write("-----BEGIN RSA PRIVATE KEY-----\n");
                for (var i = 0; i < base64.Length; i += 64)
                {
                    outputStream.Write(base64, i, Math.Min(64, base64.Length - i));
                    outputStream.Write("\n");
                }
                outputStream.Write("-----END RSA PRIVATE KEY-----");
            }

            return outputStream.ToString();
        }

        /// <summary>
        /// RSA Pulbic key into OpenSSH PEM string export
        /// </summary>
        /// <param name="_csp"></param>
        /// <returns></returns>
        public static string ExportPublicKey(RSACryptoServiceProvider _csp)
        {
            StringWriter outputStream = new StringWriter();
            var _params = _csp.ExportParameters(false);
            using (var stream = new MemoryStream())
            {
                var writer = new BinaryWriter(stream);
                writer.Write((byte)0x30);
                using (var innerStream = new MemoryStream())
                {
                    var innerWriter = new BinaryWriter(innerStream);
                    innerWriter.Write((byte)0x30);
                    EncodeLength(innerWriter, 13);
                    innerWriter.Write((byte)0x06);
                    var rsaEncryptionOid = new byte[] { 0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x01, 0x01 };
                    EncodeLength(innerWriter, rsaEncryptionOid.Length);
                    innerWriter.Write(rsaEncryptionOid);
                    innerWriter.Write((byte)0x05);
                    EncodeLength(innerWriter, 0);
                    innerWriter.Write((byte)0x03);
                    using (var bitStringStream = new MemoryStream())
                    {
                        var bitStringWriter = new BinaryWriter(bitStringStream);
                        bitStringWriter.Write((byte)0x00);
                        bitStringWriter.Write((byte)0x30);
                        using (var paramsStream = new MemoryStream())
                        {
                            var paramsWriter = new BinaryWriter(paramsStream);
                            EncodeIntegerBigEndian(paramsWriter, _params.Modulus);
                            EncodeIntegerBigEndian(paramsWriter, _params.Exponent);
                            var paramsLength = (int)paramsStream.Length;
                            EncodeLength(bitStringWriter, paramsLength);
                            bitStringWriter.Write(paramsStream.GetBuffer(), 0, paramsLength);
                        }
                        var bitStringLength = (int)bitStringStream.Length;
                        EncodeLength(innerWriter, bitStringLength);
                        innerWriter.Write(bitStringStream.GetBuffer(), 0, bitStringLength);
                    }
                    var length = (int)innerStream.Length;
                    EncodeLength(writer, length);
                    writer.Write(innerStream.GetBuffer(), 0, length);
                }

                var base64 = Convert.ToBase64String(stream.GetBuffer(), 0, (int)stream.Length).ToCharArray();
                outputStream.Write("-----BEGIN PUBLIC KEY-----\n");
                for (var i = 0; i < base64.Length; i += 64)
                {
                    outputStream.Write(base64, i, Math.Min(64, base64.Length - i));
                    outputStream.Write("\n");
                }
                outputStream.Write("-----END PUBLIC KEY-----");
            }

            return outputStream.ToString();
        }

        private static void EncodeLength(BinaryWriter _stream, int _length)
        {
            if (_length < 0) throw new ArgumentOutOfRangeException("length", "Length must be non-negative");
            if (_length < 0x80)
            {
                _stream.Write((byte)_length);
            }
            else
            {
                var temp = _length;
                var bytesRequired = 0;
                while (temp > 0)
                {
                    temp >>= 8;
                    bytesRequired++;
                }
                _stream.Write((byte)(bytesRequired | 0x80));
                for (var i = bytesRequired - 1; i >= 0; i--)
                {
                    _stream.Write((byte)(_length >> (8 * i) & 0xff));
                }
            }
        }

        private static void EncodeIntegerBigEndian(BinaryWriter _stream, byte[] _value, bool _forceUnsigned = true)
        {
            _stream.Write((byte)0x02);
            var prefixZeros = 0;
            for (var i = 0; i < _value.Length; i++)
            {
                if (_value[i] != 0) break;
                prefixZeros++;
            }
            if (_value.Length - prefixZeros == 0)
            {
                EncodeLength(_stream, 1);
                _stream.Write((byte)0);
            }
            else
            {
                if (_forceUnsigned && _value[prefixZeros] > 0x7f)
                {
                    EncodeLength(_stream, _value.Length - prefixZeros + 1);
                    _stream.Write((byte)0);
                }
                else
                {
                    EncodeLength(_stream, _value.Length - prefixZeros);
                }
                for (var i = prefixZeros; i < _value.Length; i++)
                {
                    _stream.Write(_value[i]);
                }
            }
        }
    }

}
