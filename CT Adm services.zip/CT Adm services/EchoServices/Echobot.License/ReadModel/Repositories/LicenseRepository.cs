﻿using Echobot.License.ReadModel.Repositories.Interfaces;
using Microsoft.Practices.Unity;
using SimpleCqrs.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Echobot.License.ReadModel.Repositories
{
    public class LicenseRepository : IDisposable,ILicenseRepository
    {
        public LicenseModel context = new LicenseModel();

        public IEnumerable<echobot_lic_companyDetails> GetAll()
        {
            return context.echobot_lic_companyDetails;
        }

        public echobot_lic_companyDetails GetByID(Guid id)
        {
            return context.echobot_lic_companyDetails.FirstOrDefault(p => p.id == id);
        }

        public echobot_lic_companyDetails GetByEmailId(string emailId)
        {
            return context.echobot_lic_companyDetails.FirstOrDefault(p => p.contactEmailId == emailId);
        }
        public echobot_lic_companyDetails GetByClientKey(string publicKey)
        {
            var record = context.echobot_lic_companyDetails.FirstOrDefault(p => p.PublicLicenseKey == publicKey);
            return record;
        }
        public string ValidateLicense(Guid id)
        {
            var record = context.echobot_lic_companyDetails.FirstOrDefault(r => r.id == id);
            if(record != null)
            {
                var result = DateTime.Compare(DateTime.Now, record.validTo);
                if (record.status && result > 0)
                {
                    return "License expired. Kindly renew!";
                }
                else if(!record.status && result < 0)
                {
                    return "License revoked. Contact help center";
                }
                else
                {
                    return "Valid key";
                }
            }
            return "Invalid key";
        }

        public string VerifyIde(string userKey)
        {
            var record = context.echobot_lic_clientSide.FirstOrDefault(r => r.SerialKey == userKey);
            if (record != null)
            {
                return "Valid key";

            }
            return "Invalid key";
        }
        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    if (context != null)
                    {
                        context.Dispose();
                        context = null;
                    }
                }

                disposedValue = true;
            }
        }

         void IDisposable.Dispose()
        {
            Dispose(true);
            // GC.SuppressFinalize(this);
        }
        #endregion
    }
}
