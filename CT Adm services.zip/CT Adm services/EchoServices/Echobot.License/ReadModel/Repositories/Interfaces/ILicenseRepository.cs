﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Echobot.License.ReadModel.Repositories.Interfaces
{
    public interface ILicenseRepository
    {
        IEnumerable<echobot_lic_companyDetails> GetAll();
        echobot_lic_companyDetails GetByID(Guid id);
        echobot_lic_companyDetails GetByEmailId(string emailId);
        echobot_lic_companyDetails GetByClientKey(string publicKey);
        string ValidateLicense(Guid id);
        /// <summary>
        /// To verify key during echobot ide installation
        /// </summary>
        /// <param name="userKey"></param>
        /// <returns></returns>
        string VerifyIde(string userKey);
    }
}
    