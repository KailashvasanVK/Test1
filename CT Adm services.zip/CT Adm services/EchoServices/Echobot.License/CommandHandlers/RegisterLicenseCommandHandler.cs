﻿using Echobot.Contracts.Commands;
using SimpleCqrs.Commanding;
using SimpleCqrs.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Echobot.License.CommandHandler
{
    public enum RegisterLicenseStatus
    {
        Successful
    }
    public class RegisterLicenseCommandHandler : CommandHandler<RegisterLicenseCommand>
    {
        protected IDomainRepository _repository;

        public RegisterLicenseCommandHandler(IDomainRepository repository)
        {
            _repository = repository;
        }

        public override void Handle(RegisterLicenseCommand command)
        {
            Return(ValidateCommand(command));

            var location = new Domain.echobot_lic_companyDetails(Guid.NewGuid(), command.Name, command.Address, command.ContactEmailId, command.ContactMobile, command.BotInstances, command.Status);

            _repository.Save(location);
        }
        protected RegisterLicenseStatus ValidateCommand(RegisterLicenseCommand command)
        {
            return RegisterLicenseStatus.Successful;
        }
    }
}