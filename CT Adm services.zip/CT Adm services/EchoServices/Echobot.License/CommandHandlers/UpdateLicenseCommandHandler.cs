﻿using Echobot.Contracts.Commands;
using Echobot.Domain;
using SimpleCqrs.Commanding;
using SimpleCqrs.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Echobot.License.CommandHandlers
{
    public class UpdateLicenseCommandHandler : AggregateRootCommandHandler<UpdateLicenseCommand, echobot_lic_companyDetails>
    {
        protected IDomainRepository _repository;
        public UpdateLicenseCommandHandler(IDomainRepository repository) : base(repository) { }
        public override void Handle(UpdateLicenseCommand command, echobot_lic_companyDetails echoLicense)
        {
            echoLicense.Update(command.AggregateRootId, command.Address, command.ContactEmailId, command.ContactMobile, command.BotInstances, command.Status);
        }
    }
}
