﻿using Echobot.Contracts.Commands;
using SimpleCqrs.Commanding;
using SimpleCqrs.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Echobot.License.CommandHandler
{
    public enum RegisterClientStatus
    {
        Successful
    }
    public class RegisterClientSideCommandHandler : CommandHandler<RegisterClientSideCommand>
    {
        protected IDomainRepository _repository;

        public RegisterClientSideCommandHandler(IDomainRepository repository)
        {
            _repository = repository;
        }

        public override void Handle(RegisterClientSideCommand command)
        {
            Return(ValidateCommand(command));

            var location = new Domain.echobot_lic_clientSide(Guid.NewGuid(), command.SerialKey);

            _repository.Save(location);
        }
        protected RegisterClientStatus ValidateCommand(RegisterClientSideCommand command)
        {
            return RegisterClientStatus.Successful;
        }
    }
}
