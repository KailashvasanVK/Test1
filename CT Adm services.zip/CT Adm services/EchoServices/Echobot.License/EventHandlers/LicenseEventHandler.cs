﻿using Echobot.Contracts.Events;
using Echobot.License.ReadModel;
using SimpleCqrs.Eventing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Echobot.License.EventHandlers
{
    public class LicenseEventHandler : IHandleDomainEvents<LicenseRegisteredEvent>, 
                                       IHandleDomainEvents<LicenseRevokedEvent>,
                                       IHandleDomainEvents<LicenseExtendedEvent>,
                                       IHandleDomainEvents<ContactChangedEvent>,
                                       IHandleDomainEvents<UpdateBotInstancesEvent>,
                                       IHandleDomainEvents<LicenseRegisteredClientEvent>
                
    {
        public void Handle(LicenseRegisteredEvent domainEvent)
        {
            var encryptionKeys = RSAEncryptionService.GetKeys();
            using (LicenseModel dbEntity = new LicenseModel())
            {
                dbEntity.echobot_lic_companyDetails.Add(new echobot_lic_companyDetails() {
                    id = domainEvent.AggregateRootId,
                    address = domainEvent.Address,
                    contactEmailId = domainEvent.ContactEmailId,
                    contactMobile = domainEvent.ContactMobile,
                    botInstances = domainEvent.BotInstances,
                    validFrom = DateTime.Now,
                    validTo = DateTime.Now.AddDays(30),
                    createdOn= DateTime.Now,
                    createdBy = "balasubraman.l",
                    status = true,
                    name= domainEvent.Name,
                    PublicLicenseKey = HttpUtility.UrlEncode(encryptionKeys.Item1),
                    PrivateLicenseKey = HttpUtility.UrlEncode(encryptionKeys.Item2)
                });

                dbEntity.SaveChanges();
            }
        }

        public void Handle(LicenseExtendedEvent domainEvent)
        {
            throw new NotImplementedException();
        }

        public void Handle(LicenseRegisteredClientEvent domainEvent)
        {
            using (LicenseModel dbEntity = new LicenseModel())
            {
                dbEntity.echobot_lic_clientSide.Add(new echobot_lic_clientSide()
                {
                    SerialKey = domainEvent.SerialKey,
                    CreatedDate = DateTime.Now
                });
                dbEntity.SaveChanges();
            }
        }

        public void Handle(ContactChangedEvent domainEvent)
        {
            using (LicenseModel dbEntity = new LicenseModel())
            {
                var currRecord = dbEntity.echobot_lic_companyDetails.Find(domainEvent.AggregateRootId);
                currRecord.address = domainEvent.CompanyAddress;
                currRecord.contactEmailId = domainEvent.ContactEmailId;
                currRecord.contactMobile = domainEvent.ContactMobile;
                dbEntity.SaveChanges();
            }
        }

        public void Handle(LicenseRevokedEvent domainEvent)
        {
            using (LicenseModel dbEntity = new LicenseModel())
            {
                var currRecord = dbEntity.echobot_lic_companyDetails.Find(domainEvent.AggregateRootId);
                currRecord.status = domainEvent.Status;
                dbEntity.SaveChanges();
            }
        }

        public void Handle(UpdateBotInstancesEvent domainEvent)
        {
            using (LicenseModel dbEntity = new LicenseModel())
            {
                var currRecord = dbEntity.echobot_lic_companyDetails.Find(domainEvent.AggregateRootId);
                currRecord.botInstances = domainEvent.BotInstances;
                dbEntity.SaveChanges();
            }
        }
    }
}
