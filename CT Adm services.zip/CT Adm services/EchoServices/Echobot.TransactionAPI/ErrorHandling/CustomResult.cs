﻿using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;

namespace Echobot.TransactionAPI.ErrorHandling
{
    public class CustomResult : IHttpActionResult
    {
        public HttpRequestMessage Request { get; }

        public CustomResult(HttpRequestMessage request)
        {
            Request = request;
        }

        public Task<HttpResponseMessage> ExecuteAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult(new HttpResponseMessage(HttpStatusCode.InternalServerError)
            {
                RequestMessage = Request,
                Content = new StringContent("Something went wrong!", Encoding.UTF8)
            });
        }
    }
}