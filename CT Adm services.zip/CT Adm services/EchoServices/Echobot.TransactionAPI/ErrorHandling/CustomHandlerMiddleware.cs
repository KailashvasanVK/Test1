﻿using System;
using System.Threading.Tasks;
using Microsoft.Owin;

namespace Echobot.TransactionAPI.ErrorHandling
{
    public class CustomHandlerMiddleware : OwinMiddleware
    {
        public CustomHandlerMiddleware(OwinMiddleware next) : base(next)
        {
        }

        public override async Task Invoke(IOwinContext context)
        {
            try
            {
                await Next.Invoke(context);
            }
            catch (Exception ex)
            {
                context.Response.StatusCode = 500;
                await context.Response.WriteAsync($"Phew, we handled that too!\n\nThe state of the captured exception is untouched:\n{ex}");
            }
        }
    }
}