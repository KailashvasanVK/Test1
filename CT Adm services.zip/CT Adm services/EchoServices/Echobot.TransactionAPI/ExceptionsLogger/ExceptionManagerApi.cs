﻿using log4net;
using System;
using System.IO;
using System.Reflection;
using System.Web.Http.ExceptionHandling;

namespace Echobot.TransactionAPI.ExceptionsLogger
{
    public class ExceptionManagerApi : ExceptionLogger
    {
        ILog _logger = null;
        public ExceptionManagerApi()
        {
            // Gets directory path of the calling application  
            // RelativeSearchPath is null if the executing assembly i.e. calling assembly is a  
            // stand alone exe file (Console, WinForm, etc).   
            var log4NetConfigDirectory = AppDomain.CurrentDomain.RelativeSearchPath ?? AppDomain.CurrentDomain.BaseDirectory;
            var log4NetConfigFilePath = Path.Combine(log4NetConfigDirectory,"ExceptionsLogger", "log4net.config");

            log4net.Config.XmlConfigurator.ConfigureAndWatch(new FileInfo(log4NetConfigFilePath));
            GlobalContext.Properties["LogFileName"] = Path.Combine(log4NetConfigDirectory, "ExceptionsLogger");
            log4net.Config.XmlConfigurator.Configure();
        }
        public override void Log(ExceptionLoggerContext context)
        {
            _logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
            _logger.Error(context.Exception.ToString());
        }
        public void Log(string ex)
        {
            _logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
            _logger.Error(ex);
        }
    }
}