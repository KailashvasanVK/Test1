﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web.Http;
using Microsoft.Owin.Security.OAuth;
using Newtonsoft.Json.Serialization;
using Echobot.TransactionAPI.Resolver;
using Echobot.Transaction.ReadModel.Repositories;
using Echobot.Transaction.ReadModel.Repositories.Interfaces;
using Microsoft.Practices.Unity;
using Echobot.TransactionAPI.ExceptionsLogger;
using System.Web.Http.ExceptionHandling;
using Echobot.TransactionAPI.ErrorHandling;

namespace Echobot.TransactionAPI
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            var container = new UnityContainer();
            container.RegisterType<ITransactionRepository, TransactionRepository>(new HierarchicalLifetimeManager());
            config.DependencyResolver = new UnityResolver(container);

            // Web API configuration and services
            // Configure Web API to use only bearer token authentication.
            config.SuppressDefaultHostAuthentication();
            config.Filters.Add(new HostAuthenticationFilter(OAuthDefaults.AuthenticationType));

            //Exception Handler
            config.Services.Replace(typeof(IExceptionHandler), new PassthroughHandler());
            config.Services.Add(typeof(IExceptionLogger), new ExceptionManagerApi());
            // Web API routes
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );
        }
    }


}
