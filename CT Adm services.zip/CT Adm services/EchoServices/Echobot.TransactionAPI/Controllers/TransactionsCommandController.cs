﻿using Echobot.Contracts.Commands;
using Echobot.Transaction.CommandHandlers;
using SimpleCqrs;
using SimpleCqrs.Commanding;
using System;
using System.Web.Http;

namespace Echobot.TransactionAPI.Controllers
{
    [Authorize]
    [RoutePrefix("tCommand")]
    public class TransactionsCommandController : ApiController
    {
        public ICommandBus CommandBus;

        public TransactionsCommandController() : this(ServiceLocator.Current.Resolve<ICommandBus>())
        {
        }

        public TransactionsCommandController(ICommandBus commandBus)
        {
            CommandBus = commandBus;
        }
        [HttpGet]
        [Route("test")]
        public string GetValue()
        {
            return "valuess";
        }
        [HttpPost]
        [Route("Log")]
        public IHttpActionResult LogTransactions(CreateTransactionCommand command)
        {
            try
            {
                CommandBus.Execute(command);
                return Ok();
            }
            catch(Exception)
            {
                return BadRequest("Sorry something happened.Try again!");
            }
        }   

        [HttpPost]
        [Route("CreateProcess")]
        public IHttpActionResult ProcessCreation(CreateProcessCommand command)
        {
             var result = (ProcessCreatedStatus)CommandBus.Execute(command);
             if (result == ProcessCreatedStatus.Successful)
             {
                 return Ok();
             }
             return BadRequest("Sorry something happened.Try again!");
        }

        [HttpPost]
        [Route("CreateBotClient")]
        public IHttpActionResult BotClientCreation(CreateBotClientCommand command)
        {
            var result = (BotClientCreatedStatus)CommandBus.Execute(command);
            if (result == BotClientCreatedStatus.Successful)
            {
                return Ok();
            }
            return BadRequest("Sorry something happened.Try again!");
        }
    }
}
