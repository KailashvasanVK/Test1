﻿using Echobot.Transaction.ReadModel;
using Echobot.Transaction.ReadModel.Repositories.Interfaces;
using Echobot.TransactionAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Echobot.TransactionAPI.Controllers
{
    [Authorize]
    [RoutePrefix("tquery")]
    public class TransactionsQueryController : ApiController
    {
        private readonly ITransactionRepository _transRepo;

        public TransactionsQueryController(ITransactionRepository transRepo)
        {
            _transRepo = transRepo;
        }

        [AllowAnonymous]
        [Route("Token")]
        [HttpPost]
        public IHttpActionResult Token(InfoFetchModel info)
        {
            var record = _transRepo.GetCompanyByClientKey(info.HashToken);
            var decrypted = RSAEncryptionService.Decrypt(info.UserKey, record.PrivateLicenseKey);
            var _company = _transRepo.GetCompanyById(Guid.Parse(decrypted));
            if (_company != null)
            {
                var _tokenDetails = Providers.ApplicationOAuthProvider.GetUserAuthToken(_company);
                return Ok(_tokenDetails);
            }
            else
            {
                return BadRequest(message: "Invalid Credentials");
            }
        }
    }
}
