﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Owin;
using Owin;
using Echobot.TransactionAPI.ErrorHandling;

[assembly: OwinStartup(typeof(Echobot.TransactionAPI.Startup))]

namespace Echobot.TransactionAPI
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            app.UseCors(Microsoft.Owin.Cors.CorsOptions.AllowAll);
            ////app.Use<CustomHandlerMiddleware>().Use(async (ctx, next) =>
            ////{
            ////    try { await next(); }
            ////    catch (Exception ex)
            ////    {
            ////        // log error, rewrite http response etc
            ////    }
            ////});

            ConfigureAuth(app);
        }
    }
}
