﻿using System;
using System.Linq;
using System.Text;
using System.Activities;
using System.Data;
using ActivityKibrary1;
using System.Data.SqlClient;
using System.IO;
using System.Xml.Serialization;
using FTPParameters;
using System.Net;


namespace ServerConnection
{

    public sealed class botFTPDownload : CodeActivity
    {
        // Define an activity input argument of type string

        private string process;
        private int FileTakenCount;
        private string clientName;
        private SqlConnection Sqlcon;
        private SqlCommand Sqlcmd;
        private SqlDataReader SqlRead;
        private FtpWebRequest ftpRequest = null;
        private FtpWebResponse ftpResponse = null;
        private Stream ftpStream = null;
        private int bufferSize = 2048;
        public string host;
        public string userid;
        public string pass;
        public static string destinationPath;
        RuleSetParameters rulesParameters = new RuleSetParameters();
        private static DateTime fileCreatedTime;
        private static DateTime yesterday = DateTime.Now.AddDays(-1).Date;
        private static DateTime Today = DateTime.Now.AddDays(0).Date;

        DataTable Batches = new DataTable();
        public InArgument<Boolean> XMLtype { get; set; }
        public InArgument<string> SourcePath { get; set; }
        public InArgument<string> DestinationPath { get; set; }
        public InArgument<string> PortNumber { get; set; }
        public InArgument<string> ServerName { get; set; }
        public InArgument<string> UserName { get; set; }
        public InArgument<string> Password { get; set; }
        public InArgument<string> DateFormat { get; set; }
        public InArgument<string> FolderName { get; set; }
        public InArgument<string> FolderDate { get; set; }
        public InArgument<string> Process { get; set; }

        public InArgument<string> ClientName { get; set; }
        public InArgument<string> RuleSetName { get; set; }
        public InArgument<string> ZipFolder { get; set; }

        // If your activity returns a value, derive from CodeActivity<TResult>
        // and return the value from the Execute method.
        protected override void Execute(CodeActivityContext context)
        {
            FtpClientParameters parameters = new FtpClientParameters();
            Connection.Batches.Columns.Add("BatchNo", typeof(string));
            Connection.Batches.Columns.Add("sourceFileSize", typeof(Int64));
            Connection.Batches.Columns.Add("destinationFileSize", typeof(Int64));
          
            
            if (context.GetValue(this.XMLtype) == false)
            {

                // Obtain the runtime value of the Text input argument
                parameters.DownloadSource = context.GetValue(this.SourcePath);
                parameters.DownloadDestination = context.GetValue(this.DestinationPath);
                parameters.FolderDate = context.GetValue(this.FolderDate);
                parameters.FolderName = context.GetValue(this.FolderName);
                parameters.DateFormat = context.GetValue(this.DateFormat);
                parameters.ServerName = context.GetValue(this.ServerName);
                parameters.Port = context.GetValue(this.PortNumber);
                parameters.UserId = context.GetValue(this.UserName);
                parameters.Password = context.GetValue(this.Password);
                parameters.RuleSetName = context.GetValue(this.RuleSetName);
                parameters.ClientName = context.GetValue(this.ClientName);
                parameters.Process = context.GetValue(this.Process);

            }

            else
            {


                clientName = Connection.ClientName;
                parameters = DeSerialize(clientName);
                context.SetValue(Process, parameters.Process);
                context.SetValue(SourcePath, parameters.DownloadSource);
                context.SetValue(DestinationPath, parameters.DownloadDestination);
                context.SetValue(FolderDate, parameters.FolderDate);
                context.SetValue(FolderName, parameters.FolderName);
                context.SetValue(DateFormat, parameters.DateFormat);
                context.SetValue(ServerName, parameters.ServerName);
                context.SetValue(UserName, parameters.UserId);
                context.SetValue(Password, parameters.Password);
                context.SetValue(RuleSetName, parameters.RuleSetName);
                context.SetValue(ClientName, parameters.ClientName);
                context.SetValue(ZipFolder, parameters.ZipFolder);
                Connection.Process = parameters.Process;
            }
           // botSFTPConnect();
            Download(parameters);
        }

               private void Download(FtpClientParameters parameters)
        {
            try

            {

                Connection.processlog = Connection.processlog + "Connect the FTP Server ";
              

                rulesParameters.ClientParameters = parameters;
                clientName = parameters.ClientName;
                process = parameters.Process;
                ApplyRule(rulesParameters);
                destinationPath = parameters.DownloadDestination;
                ZipFolder = rulesParameters.zipFolder;

                FileTakenCount = 0;
                RowsClear();
                Connection.Client = parameters.ClientName;

                ftp ftpClient = new ftp(parameters.ServerName, parameters.UserId, parameters.Password);

                string[] simpleDirectoryListing = ftpClient.directoryListSimple(rulesParameters.DownloadSource);

                if (parameters.ClientName != "Pacific ARR Download")
                {
                    for (int i = 0; i < simpleDirectoryListing.Count(); i++)
                    {
                        if (simpleDirectoryListing[i] != "")
                        {



                            if (Path.GetExtension(rulesParameters.DownloadSource + @"/" + simpleDirectoryListing[i]) != parameters.FileExtension && parameters.FileExtension != "")
                            {
                                if (!File.Exists(rulesParameters.DownloadDestination + @"\" + simpleDirectoryListing[i]))
                                    Connection.sourceFileCount++;
                                ftpClient.download(rulesParameters.DownloadSource + @"/" + simpleDirectoryListing[i], rulesParameters.DownloadDestination + @"\" + simpleDirectoryListing[i]);
                                FileInfo ff = new FileInfo(rulesParameters.DownloadDestination + @"\" + simpleDirectoryListing[i]);
                                //  FileInfo SourceFile = new FileInfo(rulesParameters.DownloadSource + @"/" + simpleDirectoryListing[i]);
                                Connection.Batches.Rows.Add(simpleDirectoryListing[i], ftpClient.GetFileSize(rulesParameters.DownloadSource + @"/" + simpleDirectoryListing[i]), ff.Length);
                            }
                            else if (!File.Exists(rulesParameters.DownloadDestination + @"\" + simpleDirectoryListing[i]) && parameters.FileExtension == "")
                            {
                                Connection.sourceFileCount++;
                                ftpClient.download(rulesParameters.DownloadSource + @"/" + simpleDirectoryListing[i], rulesParameters.DownloadDestination + @"\" + simpleDirectoryListing[i]);
                                FileInfo ff = new FileInfo(rulesParameters.DownloadDestination + @"\" + simpleDirectoryListing[i]);
                                //  FileInfo SourceFile = new FileInfo(rulesParameters.DownloadSource + @"/" + simpleDirectoryListing[i]);
                                Connection.Batches.Rows.Add(simpleDirectoryListing[i], ftpClient.GetFileSize(rulesParameters.DownloadSource + @"/" + simpleDirectoryListing[i]), ff.Length);
                            }


                        }

                    }

                }
                else

                {
                    for (int i = 0; i < simpleDirectoryListing.Count(); i++)
                    {
                        if (simpleDirectoryListing[i] != "")
                        {

                            if (!File.Exists(rulesParameters.DownloadDestination + @"\" + simpleDirectoryListing[i]))
                            {
                            
                                ftpClient.downloadTimewise(rulesParameters.DownloadSource + @"/" + simpleDirectoryListing[i], rulesParameters.DownloadDestination + @"\" + simpleDirectoryListing[i]);
                               
                            }
                        }
                    }
                }



                Connection.ProcessLogFiles(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);

            }
            catch (Exception ex)
            {
                //  Program.logger.Error(ex, clientName);
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail("", "");
                Connection.LogFiles();


            }
            //TODO: Download files
        }
        private long FileSize(long Filelength)
        {
            string[] suffixes = { "B", "KB", "MB" };
            int s = 0;
            while (Filelength >= 1024)
            {
                s++;
                Filelength /= 1024;
            }

            return Filelength;
        }



        private void RowsClear()
        {
            if (Connection.Batches.Rows.Count > 0)
            {
                Connection.Batches.Rows.Clear();
            }        
        }



        private FtpClientParameters DeSerialize(string clientName)
        {
            try
            {
                Connection.processlog = Connection.processlog + "call the DeSerialize Function ";
                XmlSerializer deserializer = new XmlSerializer(typeof(FtpClientParameters));
                TextReader reader = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + @"\Xml\" + clientName + @".xml");
                object obj = deserializer.Deserialize(reader);
                FtpClientParameters XmlData = (FtpClientParameters)obj;
                reader.Close();
                return XmlData;
            }
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail("", "");
                Connection.LogFiles();
                return null;
            }


        }
        private RuleSetParameters ApplyRule(RuleSetParameters parameters)
        {
            try
            {

                RuleSetManager rsm = new RuleSetManager();
                rsm.LoadRuleSet(parameters.ClientParameters.RuleSetName);
                rsm.ExecuteRuleSet(parameters);
                return parameters;
            }
            catch (Exception ex)
            {
                // Program.logger.Error(ex, clientName);
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail("", "");
                Connection.LogFiles();
                return null;
            }

        }
        public void Mail(string Source, string Dest)
        {

            try
            {
                string SubjectText = clientName + " File  " + process + "  Details on " + DateTime.Now.ToString("MM/dd/yyyy");

                StringBuilder BodyMsg = new StringBuilder();
                BodyMsg.AppendLine("Hi All");
                BodyMsg.AppendLine("<br><br>");
  
                BodyMsg.AppendLine("<br> <br> <Table  border=1> <tr bgcolor=blue>  <td> Path Type </td>  <td> FilePath </td> <td> BatchCount </td> <td>Batch Size </td>  </tr> ");
                string FilePlacedSize = Batches.Compute("Sum(FilePlacedPath)", "").ToString();
                string FiletakenSize = Batches.Compute("Sum(FiletakenPathSize)", "").ToString();

                BodyMsg.AppendLine("<tr><td> Source </td><td>" + Source + "</td><td>" + Convert.ToString(FileTakenCount) + "</td><td>" + FiletakenSize + "</td><tr>");
                BodyMsg.AppendLine("<tr><td> Destination  </td><td>" + Dest + "</td><td>" + Convert.ToString(Batches.Rows.Count) + "</td><td>" + FilePlacedSize + "</td></tr>");
                BodyMsg.AppendLine("</table> <br><br><b> Thanks  <br><br> **** This is Auto generated Mail **** </b><br><br>");


                //else

                //{
                //    BodyMsg.AppendLine("File has not received in this path " + Source);
                //    BodyMsg.AppendLine("<br><br><b> Thanks  <br><br> **** This is Auto generated Mail **** </b><br><br>");
                //}


                String Qury = "exec  FTp_Mailsend @Subject,@Body";
                Sqlcon = new SqlConnection("Data Source=SQL-Listner;Initial catalog=ARC_ATHENA;User id=offlineAppuser;PWD=offline@app$2@16; multisubnetfailover=true");
                if (Sqlcon.State == ConnectionState.Closed)
                {
                    Sqlcon.Open();
                }
                Sqlcmd = new SqlCommand(Qury, Sqlcon);
                Sqlcmd.Parameters.AddWithValue("@Subject", SubjectText);
                Sqlcmd.Parameters.AddWithValue("@BODY", BodyMsg.ToString());
                Sqlcmd.ExecuteNonQuery();
                Environment.Exit(0);
            }
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail("", "");
                Connection.LogFiles();
            }

        }
        public void ProcessLogFiles(string Source, string Dest)
        {

            try
            {

                Connection.processlog = Connection.processlog + "call the ProcessLogFiles Function ";
                Sqlcon = new SqlConnection(Connection.strSqlCon);

                if (Sqlcon.State == ConnectionState.Closed)
                {
                    Sqlcon.Open();
                }
                //ClientName varchar(100),@ProcessName varchar(30),@FiletakenPath varchar(300),@FilePlacedPath varchar(500),@Batchno BatchTrack readonly
                string strCmd = "FTP_MoveBatchlist";
                Sqlcmd = new SqlCommand(strCmd, Sqlcon);
                Sqlcmd.CommandType = CommandType.StoredProcedure;
                Sqlcmd.Parameters.Add("@ClientName", SqlDbType.VarChar, 100).Value = clientName;
                Sqlcmd.Parameters.Add("@ProcessName", SqlDbType.VarChar, 50).Value = process;
                Sqlcmd.Parameters.Add("@FiletakenPath", SqlDbType.VarChar, 50).Value = Source;
                Sqlcmd.Parameters.Add("@FilePlacedPath", SqlDbType.VarChar, 50).Value = Dest;
                SqlParameter Param = Sqlcmd.Parameters.AddWithValue("@Batchinfo", Batches);
                Param.SqlDbType = SqlDbType.Structured;

                Sqlcmd.ExecuteNonQuery();
                Sqlcmd.Cancel();
                Sqlcon.Close();
            }
            catch (Exception ex)
            {
                // Program.logger.Error(ex, clientName);
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.LogFiles();
            }

        }

        class ftp
        {

            public string flag;
            private string host = null;
            private string user = null;
            private string pass = null;
            private FtpWebRequest ftpRequest = null;
            private FtpWebResponse ftpResponse = null;
            private Stream ftpStream = null;
            private int bufferSize = 2048;
            public string processlog;

            /* Construct Object */
            public ftp(string hostIP, string userName, string password)
            { host = hostIP; user = userName; pass = password; }
            //ftp ftpClient = new ftp(@"ftp://172.18.94.250/", "ahs01", "ahsgroup033");
            /* Download File */
            public void download(string remoteFile, string localFile)
            {
                try
                {

                  

                        processlog = processlog + "| download process start on " + DateTime.Now.ToString();
                        /* Create an FTP Request */
                        ftpRequest = (FtpWebRequest)FtpWebRequest.Create(new Uri("ftp://" + host + "/" + remoteFile));
                        /* Log in to the FTP Server with the User Name and Password Provided */
                        ftpRequest.Credentials = new NetworkCredential(user, pass);
                        /* When in doubt, use these options */
                        ftpRequest.UseBinary = true;
                        ftpRequest.UsePassive = true;
                        ftpRequest.KeepAlive = true;
                        /* Specify the Type of FTP Request */
                        ftpRequest.Method = WebRequestMethods.Ftp.DownloadFile;
                        /* Establish Return Communication with the FTP Server */

                        //ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
                        //ftpRequest.EnableSsl = true;
                        ftpResponse = (FtpWebResponse)ftpRequest.GetResponse();

                        /* Get the FTP Server's Response Stream */
                        ftpStream = ftpResponse.GetResponseStream();
                        /* Open a File Stream to Write the Downloaded File */
                        FileStream localFileStream = new FileStream(localFile, FileMode.Create);
                        /* Buffer for the Downloaded Data */
                        byte[] byteBuffer = new byte[bufferSize];
                        int bytesRead = ftpStream.Read(byteBuffer, 0, bufferSize);
                        /* Download the File by Writing the Buffered Data Until the Transfer is Complete */
                        try
                        {
                            while (bytesRead > 0)
                            {
                                localFileStream.Write(byteBuffer, 0, bytesRead);
                                bytesRead = ftpStream.Read(byteBuffer, 0, bufferSize);
                            }
                        }
                        catch (Exception ex)
                    {

                        processlog = processlog + "|" + ex.Message + " on " + DateTime.Now.ToString();
                        Connection.processlog = processlog;
                        Connection.Errorstate = true;
                        Connection.Mail("", "");
                        Connection.LogFiles();
                    }
                        /* Resource Cleanup */
                        localFileStream.Close();
                        ftpStream.Close();
                        ftpResponse.Close();
                        ftpRequest = null;
                        processlog = processlog + "| download process End on " + DateTime.Now.ToString();
                    
                }
                catch (Exception ex)
                {
                    processlog = processlog + "|" + ex.Message + " on " + DateTime.Now.ToString();
                    Connection.processlog = processlog;
                    Connection.Errorstate = true;
                    Connection.Mail("", "");
                    Connection.LogFiles();
                   
                    //ft.LogFiles();

                }

            }


            public void downloadTimewise(string remoteFile, string localFile)
            {
                try
                {

                    /* Create an FTP Request */
                    ftpRequest = (FtpWebRequest)FtpWebRequest.Create(new Uri("ftp://" + host + "/" + remoteFile));
                    /* Log in to the FTP Server with the User Name and Password Provided */
                    ftpRequest.Credentials = new NetworkCredential(user, pass);
                    /* When in doubt, use these options */
                    ftpRequest.UseBinary = true;
                    ftpRequest.UsePassive = true;
                    ftpRequest.KeepAlive = true;
                    /* Specify the Type of FTP Request */
                    ftpRequest.Method = WebRequestMethods.Ftp.GetDateTimestamp;

                    //ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
                    //ftpRequest.EnableSsl = true;

                    ftpResponse = (FtpWebResponse)ftpRequest.GetResponse();
                    fileCreatedTime = ftpResponse.LastModified;

                    ftpRequest = null;
                    ftpResponse.Close();
                    //DateTime tt = Convert.ToDateTime(fileCreatedTime.ToString("hh:mm tt"));
                    //DateTime ttt = Convert.ToDateTime("08:00AM");

                    if ((fileCreatedTime.ToString("dd/MM/yyyy") == yesterday.ToString("dd/MM/yyyy") && Convert.ToDateTime(fileCreatedTime.ToString("hh:mm tt")) > Convert.ToDateTime("08:00AM") ) ||(fileCreatedTime.ToString("dd/MM/yyyy") == Today.ToString("dd/MM/yyyy") && Convert.ToDateTime(fileCreatedTime.ToString("hh:mm tt")) <= Convert.ToDateTime("08:00AM")))
                    {

                        processlog = processlog + "| download process start on " + DateTime.Now.ToString();
                        /* Create an FTP Request */
                        ftpRequest = (FtpWebRequest)FtpWebRequest.Create(new Uri("ftp://" + host + "/" + remoteFile));
                        /* Log in to the FTP Server with the User Name and Password Provided */
                        ftpRequest.Credentials = new NetworkCredential(user, pass);
                        /* When in doubt, use these options */
                        ftpRequest.UseBinary = true;
                        ftpRequest.UsePassive = true;
                        ftpRequest.KeepAlive = true;
                        /* Specify the Type of FTP Request */
                        ftpRequest.Method = WebRequestMethods.Ftp.DownloadFile;
                        /* Establish Return Communication with the FTP Server */

                        //ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
                        //ftpRequest.EnableSsl = true;
                        ftpResponse = (FtpWebResponse)ftpRequest.GetResponse();

                        /* Get the FTP Server's Response Stream */
                        ftpStream = ftpResponse.GetResponseStream();
                        /* Open a File Stream to Write the Downloaded File */
                        FileStream localFileStream = new FileStream(localFile, FileMode.Create);
                        /* Buffer for the Downloaded Data */
                        byte[] byteBuffer = new byte[bufferSize];
                        int bytesRead = ftpStream.Read(byteBuffer, 0, bufferSize);
                        Connection.sourceFileCount++;
                        /* Download the File by Writing the Buffered Data Until the Transfer is Complete */
                        try
                        {
                            while (bytesRead > 0)
                            {
                                localFileStream.Write(byteBuffer, 0, bytesRead);
                                bytesRead = ftpStream.Read(byteBuffer, 0, bufferSize);
                            }
                        }
                        catch (Exception ex)
                        {
                            processlog = processlog + "|" + ex.Message + " on " + DateTime.Now.ToString();
                            Connection.processlog = processlog;
                            Connection.Errorstate = true;
                            Connection.Mail("", "");
                            Connection.LogFiles();

                         }
                        /* Resource Cleanup */
                        localFileStream.Close();
                        ftpStream.Close();
                        ftpResponse.Close();
                        ftpRequest = null;
                        FileInfo ff = new FileInfo(localFile);
                        //  FileInfo SourceFile = new FileInfo(rulesParameters.DownloadSource + @"/" + simpleDirectoryListing[i]);
                        Connection.Batches.Rows.Add(Path.GetFileName(localFile), ff.Length, GetFileSize(remoteFile));
                        processlog = processlog + "| download process End on " + DateTime.Now.ToString();
                    }
                }
                
                catch (Exception ex)
                {
                    processlog = processlog + "|" + ex.Message + " on " + DateTime.Now.ToString();
                    Connection.processlog = processlog;
                    Connection.Errorstate = true;
                    Connection.Mail("", "");
                    Connection.LogFiles();
                   
                    //ft.LogFiles();

                }

            }

            public long GetFileSize(string FileName)
            {
                try
                {
                    long FileLength;
                    ftpRequest = (FtpWebRequest)FtpWebRequest.Create(new Uri("ftp://" + host + "/" + FileName));
                    /* Log in to the FTP Server with the User Name and Password Provided */
                    ftpRequest.Credentials = new NetworkCredential(user, pass);
                    /* When in doubt, use these options */
                    ftpRequest.UseBinary = true;
                    ftpRequest.UsePassive = true;
                    ftpRequest.KeepAlive = true;

                    ftpRequest.Method = WebRequestMethods.Ftp.GetFileSize;


                    //ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
                    //ftpRequest.EnableSsl = true;
                    ftpResponse = (FtpWebResponse)ftpRequest.GetResponse();
                    FileLength = ftpResponse.ContentLength;


                    ftpResponse.Close();
                    ftpRequest = null;
                    if (FileLength < 0) FileLength = 0;
                    return FileLength;
                }
                catch (Exception ex)
                {
                    Connection.processlog = Connection.processlog + "|" + ex.Message +" on " + DateTime.Now.ToString();
                    Connection.Errorstate = true;
                    Connection.Mail("", "");
                    Connection.LogFiles();
                    return 0;
                }
            }

            public string[] directoryListSimple(string directory)
            {
                try
                {
                    /* Create an FTP Request */
                    ftpRequest = (FtpWebRequest)FtpWebRequest.Create(new Uri("ftp://" + host + "/" + directory));
                    /* Log in to the FTP Server with the User Name and Password Provided */
                    ftpRequest.Credentials = new NetworkCredential(user, pass);
                    /* When in doubt, use these options */
                    ftpRequest.UseBinary = true;
                    ftpRequest.UsePassive = true;
                    ftpRequest.KeepAlive = true;
                    /* Specify the Type of FTP Request */
                    ftpRequest.Method = WebRequestMethods.Ftp.ListDirectory;
                    /* Establish Return Communication with the FTP Server */

                    //ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
                    //ftpRequest.EnableSsl = true;

                    try
                    {
                        ftpResponse = (FtpWebResponse)ftpRequest.GetResponse();
                    }
                    catch (Exception Ex)
                    {

                        Connection.Mail(directory, destinationPath);
                        Connection.LogFiles();
                    }
                    /* Establish Return Communication with the FTP Server */
                    ftpStream = ftpResponse.GetResponseStream();
                        /* Get the FTP Server's Response Stream */
                        StreamReader ftpReader = new StreamReader(ftpStream);
                        /* Store the Raw Response */
                        string directoryRaw = null;
                        /* Read Each Line of the Response and Append a Pipe to Each Line for Easy Parsing */
                        try { while (ftpReader.Peek() != -1) { directoryRaw += ftpReader.ReadLine() + "|"; } }
                        catch (Exception ex) { }
                        /* Resource Cleanup */
                        ftpReader.Close();
                        ftpStream.Close();
                        ftpResponse.Close();
                        ftpRequest = null;
                    /* Return the Directory Listing as a string Array by Parsing 'directoryRaw' with the Delimiter you Append (I use | in This Example) */
                    try { string[] directoryList = directoryRaw.Split("|".ToCharArray()); return directoryList; }
                    catch (Exception ex)
                    {
                        Connection.processlog = Connection.processlog + "|" + ex.Message + " on " + DateTime.Now.ToString();
                        Connection.Errorstate = true;
                        Connection.Mail("", "");
                        Connection.LogFiles();

                    }
                    
                
                }
                
                catch (Exception ex)
                {
                    processlog = processlog + "|" + ex.Message + " on " + DateTime.Now.ToString();
                    Connection.processlog = processlog;
                    Connection.Errorstate = true;
                    Connection.Mail("", "");
                    Connection.LogFiles();
                    //ft.LogFiles();
                }
             
                /* Return an Empty string Array if an Exception Occurs */
                return new string[] { "" };
            }

        }
        }
    }
