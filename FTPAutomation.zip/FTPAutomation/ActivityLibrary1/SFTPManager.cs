﻿using FTPParameters;
using Renci.SshNet;
using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using ICSharpCode.SharpZipLib.Core;
using ICSharpCode.SharpZipLib.Zip;
namespace ActivityKibrary1
{
    public class SFTPManager
    {
        private int FileTakenCount;
        private  SqlConnection Sqlcon;
        private  SqlCommand Sqlcmd;
        private  SqlDataReader SqlRead;
        private string process;
        public static string clientName;
        private string ZipFolder;
        private bool ErrorState;
        DataTable Batches = new DataTable();
        RuleSetParameters rulesParameters = new RuleSetParameters();
      
        public void ExecuteProcess(string clientName)
        {

            Batches.Columns.Add("BatchNo", typeof(string));
            Batches.Columns.Add("FiletakenPathSize", typeof(Int64));
            Batches.Columns.Add("FilePlacedPath", typeof(Int64));

            FtpClientParameters clientParameters = new FtpClientParameters();

         //   FtpClientParameters clientParameters = DeSerialize(clientName);
         // Program.logger.Info("Select the Process");

            switch (clientParameters.Process)
            {
                case "Upload":
                    Upload(clientParameters);
                    break;
                case "Download":
                    Download(clientParameters);
                    break;
                case "Archive":
                    Archive(clientParameters);
                    break;

                    
            }
        }

        private void Upload(FtpClientParameters parameters)
        {
            RuleSetParameters rulesParameters = new RuleSetParameters();
            rulesParameters.ClientParameters = parameters;
            ApplyRule(rulesParameters);
            //sftp sftpConn = ConnectSFtp(parameters);
            //TODO: Upload files
        }

        private void Download(FtpClientParameters parameters)
        {
            try

            {
                
                

               
                rulesParameters.ClientParameters = parameters;
                clientName = parameters.ClientName;
                process = parameters.Process;
                ApplyRule(rulesParameters);
             
                ZipFolder = rulesParameters.zipFolder;
          
                FileTakenCount = 0;
                RowsClear();
                using (var client = new SftpClient(parameters.ServerName, Convert.ToInt16(parameters.Port), parameters.UserId, parameters.Password))
                {
                    client.Connect();
                   
                   if(client.Exists(rulesParameters.DownloadSource)==true)
                    DownloadDirectory(client, rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                   else if(rulesParameters.DownloadSourceNext!=null)
                    {
                        if (client.Exists(rulesParameters.DownloadSourceNext) == true)
                        {
                            DownloadDirectory(client, rulesParameters.DownloadSourceNext, rulesParameters.DownloadDestination); }
                        }
                
                }
             
                //ProcessLogFiles(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                //Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);

            }
            catch (Exception ex)
            {
              //  Program.logger.Error(ex, clientName);
                //Connection.processlog = Connection.processlog + ex.Message;
                //Connection.LogFiles();
  
         
            }
            //TODO: Download files
        }

        public  void RowsClear()
        {
            if (Batches.Rows.Count > 0)
            {
                Batches.Rows.Clear();
            }
        }

        private void DownloadDirectory(SftpClient client, string source, string destination)
        {

            try
            {
                Connection.processlog = Connection.processlog + "dwonload the all files";
                if(clientName== "NewPort")
                {
                    DeleteDirectory(destination);
                }
     
                if ( rulesParameters.FolderModified== true)
                {
                    DateTime yesterday = DateTime.Now.AddDays(-1).Date;
                    DateTime Today = DateTime.Now.AddDays(0).Date;

                    var Files =  client.ListDirectory(source).AsEnumerable().Select(x => {
                        
                        return x;
                    }).Where(x => (x.LastWriteTime.Date == yesterday && Convert.ToDateTime(x.LastWriteTime.ToShortTimeString()) > Convert.ToDateTime("06:00 AM")) || (x.LastWriteTime.Date==Today && Convert.ToDateTime(x.LastWriteTime.ToShortTimeString()) <= Convert.ToDateTime("06:00 AM")))
                                   .ToArray()
                                   ;
                                 foreach (var file in Files)
                    {
                        if (!file.IsDirectory && !file.IsSymbolicLink)
                        {
                            if (file.Name != "." && file.Name != "..")
                            {
                                if (File.Exists(Path.Combine(destination, file.Name)) == false)
                                {
                                    FileTakenCount++;
                                    using (Stream fileStream = File.OpenWrite(Path.Combine(destination, file.Name)))
                                    {

                                        client.DownloadFile(file.FullName, fileStream);
                                        FileInfo ff = new FileInfo(Path.Combine(destination, file.Name));
                                        Batches.Rows.Add(file.Name, FileSize(file.Length), FileSize(ff.Length));
                                    }
                                }
                            }
                        }

                        else if (file.Name != "." && file.Name != "..")
                        {
                            if (!Directory.Exists(Path.Combine(destination, file.Name)))
                            {
                                var dir = Directory.CreateDirectory(Path.Combine(destination, file.Name));
                                DownloadDirectory(client, file.FullName, dir.FullName);
                            }
                        }
                    }
                }
                else
                {
                  var   Files = client.ListDirectory(source);
                    foreach (var file in Files)
                    {
                        if (!file.IsDirectory && !file.IsSymbolicLink)
                        {
                            if (file.Name != "." && file.Name != "..")
                            {
                                if (File.Exists(Path.Combine(destination, file.Name)) == false)
                                {
                                    FileTakenCount++;
                                    using (Stream fileStream = File.OpenWrite(Path.Combine(destination, file.Name)))
                                    {

                                        client.DownloadFile(file.FullName, fileStream);

                                        FileInfo ff = new FileInfo(Path.Combine(destination, file.Name));
                                        Batches.Rows.Add(file.Name, FileSize(file.Length), FileSize(ff.Length));
                                    }
                                }
                            }
                        }

                        else if (file.Name != "." && file.Name != "..")
                        {
                            if (!Directory.Exists(Path.Combine(destination, file.Name)))
                            {
                                var dir = Directory.CreateDirectory(Path.Combine(destination, file.Name));
                                DownloadDirectory(client, file.FullName, dir.FullName);
                            }
                        }
                    }
                }
                

                if (clientName == "Midwest TP Download")
                {
                    RowsClear();
                    ExtractZipFile(destination, ZipFolder);
                }
            }
            catch (Exception ex)
            {

                Connection.processlog = Connection.processlog + ex.Message;
                Connection.LogFiles();
            }
        }


        private void ArchiveDirectory(SftpClient client, string source, string destination)
        {

            try
            {
                Connection.processlog = Connection.processlog + "Archive the all files";
                if (clientName == "NewPort")
                {
                    DeleteDirectory(destination);
                }

                if (rulesParameters.FolderModified == true)
                {
                    DateTime yesterday = DateTime.Now.AddDays(-1).Date;
                    DateTime Today = DateTime.Now.AddDays(0).Date;

                    var Files = client.ListDirectory(source).AsEnumerable().Select(x => {

                        return x;
                    }).Where(x => (x.LastWriteTime.Date == yesterday && Convert.ToDateTime(x.LastWriteTime.ToShortTimeString()) > Convert.ToDateTime("06:00 AM")) || (x.LastWriteTime.Date == Today && Convert.ToDateTime(x.LastWriteTime.ToShortTimeString()) <= Convert.ToDateTime("06:00 AM")))
                                   .ToArray()
                                   ;
                    foreach (var file in Files)
                    {
                        if (!file.IsDirectory && !file.IsSymbolicLink)
                        {
                            if (file.Name != "." && file.Name != "..")
                            {
                                if (File.Exists(Path.Combine(destination, file.Name)) == false)
                                {
                                    FileTakenCount++;
                                 

                                        client.RenameFile(file.FullName, Path.Combine(destination, file.Name));
                                        FileInfo ff = new FileInfo(Path.Combine(destination, file.Name));
                                        Batches.Rows.Add(file.Name, FileSize(file.Length), FileSize(ff.Length));
                                   
                                }
                            }
                        }

                        else if (file.Name != "." && file.Name != "..")
                        {
                            if (!Directory.Exists(Path.Combine(destination, file.Name)))
                            {
                                var dir = Directory.CreateDirectory(Path.Combine(destination, file.Name));
                               ArchiveDirectory(client, file.FullName, dir.FullName);
                            }
                        }
                    }
                }
                else
                {
                    var Files = client.ListDirectory(source);
                    foreach (var file in Files)
                    {
                        if (!file.IsDirectory && !file.IsSymbolicLink)
                        {
                            if (file.Name != "." && file.Name != "..")
                            {
                                if (client.Exists(Path.Combine(destination, file.Name)) == false)
                                {
                                    FileTakenCount++;
                                    using (Stream fileStream = File.OpenWrite(Path.Combine(destination, file.Name)))
                                    {
                                        

                                        client.RenameFile(file.FullName, Path.Combine(destination, file.Name));
                                        FileInfo ff = new FileInfo(Path.Combine(destination, file.Name));
                                        Batches.Rows.Add(file.Name, FileSize(file.Length), FileSize(ff.Length));
                                    }
                                }
                            }
                        }

                        else if (file.Name != "." && file.Name != "..")
                        {
                            if (!Directory.Exists(Path.Combine(destination, file.Name)))
                            {
                                var dir = Directory.CreateDirectory(Path.Combine(destination, file.Name));
                                ArchiveDirectory(client, file.FullName, dir.FullName);
                            }
                        }
                    }
                }


                if (clientName == "Midwest TP Download")
                {
                    RowsClear();
                    ExtractZipFile(destination, ZipFolder);
                }
            }
            catch (Exception ex)
            {

                Connection.processlog = Connection.processlog + ex.Message;
                Connection.LogFiles();
            }
        }

        private long FileSize(long Filelength)
        {
            string[] suffixes = { "B", "KB", "MB" };
            int s = 0;
                        while (Filelength >= 1024)
            {
                s++;
                Filelength /= 1024;
            }

            return Filelength;
        }


        private void GetLastModifiedFiles(String Path)
        {
            DateTime today = DateTime.Now.AddDays(-1).Date;
        
            FileInfo[] todaysFiles = new DirectoryInfo(Path)
                           .EnumerateFiles()
                           .Select(x => {
                               x.Refresh();
                               return x;
                           })
                           .Where(x => x.LastWriteTime.Date == today )
                           .ToArray()
                           ;

        }

        
        private void Archive(FtpClientParameters parameters)
        {

            try
            {
             Connection.processlog = Connection.processlog + "call the Archive Function";
             RuleSetParameters rulesParameters = new RuleSetParameters();
            rulesParameters.ClientParameters = parameters;
            ApplyRule(rulesParameters);

                ZipFolder = rulesParameters.zipFolder;

                FileTakenCount = 0;
                RowsClear();
                using (var client = new SftpClient(parameters.ServerName, Convert.ToInt16(parameters.Port), parameters.UserId, parameters.Password))
                {
                    client.Connect();

                    if (client.Exists(rulesParameters.DownloadSource) == true)
                        ArchiveDirectory(client, rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                }

                //ProcessLogFiles(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                //Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
            }
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.LogFiles();
            }

        }


        private RuleSetParameters ApplyRule(RuleSetParameters parameters)
        {
            try
            {
                Connection.processlog = Connection.processlog + "call the ApplyRule Function";
                RuleSetManager rsm = new RuleSetManager();
                rsm.LoadRuleSet(parameters.ClientParameters.RuleSetName);
                rsm.ExecuteRuleSet(parameters);
                return parameters;
            }
            catch (Exception ex)
            {
               // Program.logger.Error(ex, clientName);
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.LogFiles();
                return null;
            }
           
        }

        //private FtpClientParameters DeSerialize(string clientName)
        //{
        //    try
        //    {
        //        Connection.processlog = Connection.processlog + "call the DeSerialize Function";
        //        XmlSerializer deserializer = new XmlSerializer(typeof(FtpClientParameters));
        //        TextReader reader = new StreamReader(Application.StartupPath + @"\Xml\" + clientName + @".xml");
        //        object obj = deserializer.Deserialize(reader);
        //        FtpClientParameters XmlData = (FtpClientParameters)obj;
        //        reader.Close();
        //        return XmlData;
        //    }
        //    catch (Exception ex)
        //    {
        //        Connection.processlog = Connection.processlog + ex.Message;
        //        Connection.LogFiles();
        //        return null;
        //    }


        //}

        //public void ProcessLogFiles(string Source, string Dest)
        //{

        //    try
        //    {

        //        Connection.processlog = Connection.processlog + "call the ProcessLogFiles Function";
        //        Sqlcon = new SqlConnection(Connection.strSqlCon);

        //        if (Sqlcon.State == ConnectionState.Closed)
        //        {
        //            Sqlcon.Open();
        //        }
        //        //ClientName varchar(100),@ProcessName varchar(30),@FiletakenPath varchar(300),@FilePlacedPath varchar(500),@Batchno BatchTrack readonly
        //        string strCmd = "FTP_MoveBatchlist";
        //        Sqlcmd = new SqlCommand(strCmd, Sqlcon);
        //        Sqlcmd.CommandType = CommandType.StoredProcedure;
        //        Sqlcmd.Parameters.Add("@ClientName", SqlDbType.VarChar, 100).Value = clientName;
        //        Sqlcmd.Parameters.Add("@ProcessName", SqlDbType.VarChar, 50).Value = process;
        //        Sqlcmd.Parameters.Add("@FiletakenPath", SqlDbType.VarChar, 50).Value = Source;
        //        Sqlcmd.Parameters.Add("@FilePlacedPath", SqlDbType.VarChar, 50).Value = Dest;
        //        SqlParameter Param = Sqlcmd.Parameters.AddWithValue("@Batchinfo", Program.Batches);
        //        Param.SqlDbType = SqlDbType.Structured;

        //        Sqlcmd.ExecuteNonQuery();
        //        Sqlcmd.Cancel();
        //        Sqlcon.Close();
        //    }
        //    catch (Exception ex)
        //    {
        //       // Program.logger.Error(ex, clientName);
        //        Connection.processlog = Connection.processlog + ex.Message;
        //        Connection.LogFiles();
        //    }
         
        //}
        private void DeleteDirectory(String pathName)
        {


            if (Directory.Exists(pathName))
            {
               
             
               // Directory.Delete(pathName);
               
            
                foreach (string file in Directory.GetFiles(pathName))
                {
                    if (File.Exists(file))
                        File.Delete(file);
                }
               
                foreach (string directory in Directory.GetDirectories(pathName))
                {
                    if (Directory.Exists(directory))
                        DeleteDirectory(directory);
                    Directory.Delete(directory);

                }
            }
        }

  


        public void ExtractZipFile(string archiveFilenameIn, string outFolder)
        {
            ZipFile zf = null;
            try
                


            {
                
               // Program.logger.Info("Zip File Extract started");


                var zipFiles = Directory.GetFiles(archiveFilenameIn);

                foreach (var FileName in zipFiles)
                {
                    if (Path.GetExtension(FileName) == ".zip")
                    {
                        FileStream fs = File.OpenRead(FileName);
                        zf = new ZipFile(fs);

                        foreach (ZipEntry zipEntry in zf)
                        {
                            if (!zipEntry.IsFile) continue; // Ignore directories

                            String entryFileName = zipEntry.Name;
                            //to remove the folder from the entry:
                            entryFileName = Path.GetFileName(entryFileName);
                          

                            byte[] buffer = new byte[4096];     // 4K is optimum
                            Stream zipStream = zf.GetInputStream(zipEntry);
                                       // Manipulate the output filename here as desired.
                            String fullZipToPath = Path.Combine(outFolder, entryFileName);
                            string directoryName = Path.GetDirectoryName(fullZipToPath);
                            if (directoryName.Length > 0)
                                Directory.CreateDirectory(directoryName);

                            using (FileStream streamWriter = File.Create(fullZipToPath))
                            {
                                StreamUtils.Copy(zipStream, streamWriter, buffer);
                                Batches.Rows.Add(entryFileName, FileSize(streamWriter.Length), FileSize(streamWriter.Length));
                            }
                        }
                    }
            }


            }

            catch (Exception ex)
            {
               
              //  Program.logger.Error(ex,"UnZip Error",clientName);
            }
            finally
            {
                if (zf != null)
                {
                    zf.IsStreamOwner = true;
                    zf.Close();
                }
            }
        }
        //public void Mail(string Source, string Dest)
        //{

        //    try
        //    {
        //           string SubjectText = clientName + " File  " + process + "  Details on " + DateTime.Now.ToString("MM/dd/yyyy");

        //            StringBuilder BodyMsg = new StringBuilder();
        //             BodyMsg.AppendLine("Hi All");
        //             BodyMsg.AppendLine("<br><br>");
        //       // if(Err)
        //             BodyMsg.AppendLine("<br> <br> <Table  border=1> <tr bgcolor=blue>  <td> Path Type </td>  <td> FilePath </td> <td> BatchCount </td> <td>Batch Size </td>  </tr> ");
        //            string FilePlacedSize = Program.Batches.Compute("Sum(FilePlacedPath)", "").ToString();
        //            string FiletakenSize = Program.Batches.Compute("Sum(FiletakenPathSize)", "").ToString();

        //            BodyMsg.AppendLine("<tr><td> Source </td><td>" + Source + "</td><td>" + Convert.ToString(FileTakenCount) + "</td><td>" + FiletakenSize + "</td><tr>");
        //            BodyMsg.AppendLine("<tr><td> Destination  </td><td>" + Dest + "</td><td>" + Convert.ToString(Program.Batches.Rows.Count) + "</td><td>" + FilePlacedSize + "</td></tr>");
        //            BodyMsg.AppendLine("</table> <br><br><b> Thanks  <br><br> **** This is Auto generated Mail **** </b><br><br>");
              

        //        //else

        //        //{
        //        //    BodyMsg.AppendLine("File has not received in this path " + Source);
        //        //    BodyMsg.AppendLine("<br><br><b> Thanks  <br><br> **** This is Auto generated Mail **** </b><br><br>");
        //        //}


        //        String Qury = "exec  FTp_Mailsend @Subject,@Body";
        //        Sqlcon = new SqlConnection("Data Source=SQL-Listner;Initial catalog=ARC_ATHENA;User id=offlineAppuser;PWD=offline@app$2@16; multisubnetfailover=true");
        //        if (Sqlcon.State == ConnectionState.Closed)
        //        {
        //            Sqlcon.Open();
        //        }
        //        Sqlcmd = new SqlCommand(Qury, Sqlcon);
        //        Sqlcmd.Parameters.AddWithValue("@Subject", SubjectText);
        //        Sqlcmd.Parameters.AddWithValue("@BODY", BodyMsg.ToString());
        //        Sqlcmd.ExecuteNonQuery();
        //        Environment.Exit(0);
        //    }
        //    catch (Exception ex)
        //    {
        //        Connection.processlog = Connection.processlog + ex.Message;
        //        Connection.LogFiles();
        //    }

        //}
    }
}
