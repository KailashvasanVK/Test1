﻿using System;
using System.Linq;
using System.Text;
using System.Activities;
using System.Data;
using ActivityKibrary1;
using System.Data.SqlClient;
using System.IO;
using System.Xml.Serialization;
using FTPParameters;
using System.Net;


namespace ServerConnection
{

    public sealed class botFTPUpload : CodeActivity
    {
        // Define an activity input argument of type string

 
        private SqlConnection Sqlcon;
        private SqlCommand Sqlcmd;
        private SqlDataReader SqlRead;
        private FtpWebRequest ftpRequest = null;
        private FtpWebResponse ftpResponse = null;
        private Stream ftpStream = null;
        private int bufferSize = 2048;
        public string host;
        public string userid;
        public string pass;
      
        RuleSetParameters rulesParameters = new RuleSetParameters();
   
        public InArgument<Boolean> XMLtype { get; set; }
        public InArgument<string> SourcePath { get; set; }
        public InArgument<string> DestinationPath { get; set; }
        public InArgument<string> PortNumber { get; set; }
        public InArgument<string> ServerName { get; set; }
        public InArgument<string> UserName { get; set; }
        public InArgument<string> Password { get; set; }
        public InArgument<string> DateFormat { get; set; }
        public InArgument<string> FolderName { get; set; }
        public InArgument<string> FolderDate { get; set; }
        public InArgument<string> Process { get; set; }

        public InArgument<string> ClientName { get; set; }
        public InArgument<string> RuleSetName { get; set; }
        public InArgument<string> ZipFolder { get; set; }

        // If your activity returns a value, derive from CodeActivity<TResult>
        // and return the value from the Execute method.
        protected override void Execute(CodeActivityContext context)
        {
            FtpClientParameters parameters = new FtpClientParameters();
            Connection.Batches.Columns.Add("BatchNo", typeof(string));
            Connection.Batches.Columns.Add("sourceFileSize", typeof(Int64));
            Connection.Batches.Columns.Add("destinationFileSize", typeof(Int64));

            if (context.GetValue(this.XMLtype) == false)
            {

                // Obtain the runtime value of the Text input argument
                parameters.DownloadSource = context.GetValue(this.SourcePath);
                parameters.DownloadDestination = context.GetValue(this.DestinationPath);
                parameters.FolderDate = context.GetValue(this.FolderDate);
                parameters.FolderName = context.GetValue(this.FolderName);
                parameters.DateFormat = context.GetValue(this.DateFormat);
                parameters.ServerName = context.GetValue(this.ServerName);
                parameters.Port = context.GetValue(this.PortNumber);
                parameters.UserId = context.GetValue(this.UserName);
                parameters.Password = context.GetValue(this.Password);
                parameters.RuleSetName = context.GetValue(this.RuleSetName);
                parameters.ClientName = context.GetValue(this.ClientName);
                parameters.Process = context.GetValue(this.Process);

            }

            else
            {


              
                parameters = DeSerialize(Connection.ClientName);
                Connection.Process = parameters.Process;
                context.SetValue(Process, parameters.Process);
                context.SetValue(SourcePath, parameters.DownloadSource);
                context.SetValue(DestinationPath, parameters.DownloadDestination);
                context.SetValue(FolderDate, parameters.FolderDate);
                context.SetValue(FolderName, parameters.FolderName);
                context.SetValue(DateFormat, parameters.DateFormat);
                context.SetValue(ServerName, parameters.ServerName);
                context.SetValue(UserName, parameters.UserId);
                context.SetValue(Password, parameters.Password);
                context.SetValue(RuleSetName, parameters.RuleSetName);
                context.SetValue(ClientName, parameters.ClientName);
                context.SetValue(ZipFolder, parameters.ZipFolder);
            }
           // botSFTPConnect();
            Upload(parameters);
        }

               private void Upload(FtpClientParameters parameters)
        {
            try

            {

                Connection.processlog = Connection.processlog + "Connect the SFTP Server ";
              

                rulesParameters.ClientParameters = parameters;
                ApplyRule(rulesParameters);

                ZipFolder = rulesParameters.zipFolder;
                Connection.Client = parameters.ClientName;
                Connection.sourceFileCount = 0;
                RowsClear();


     

               Connection.processlog = Connection.processlog + "File Upload has Strat ";

                UploadDirectory(parameters.ServerName, parameters.UserId, parameters.Password,rulesParameters.DownloadSource, rulesParameters.DownloadDestination);

                Connection.processlog = Connection.processlog + "File Upload has End ";
                Connection.ProcessLogFiles(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);

            }
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();


            }
            
        }

        private void UploadDirectory(string ServerName, string Userid, string Password, string source, string destination)
        {

            try
            {

                if (Directory.Exists(source))
                {
                    ftp ftpClient = new ftp(ServerName, Userid, Password);
                    string[] simpleDirectoryListing = Directory.GetFiles(source);
                    for (int i = 0; i < simpleDirectoryListing.Count(); i++)
                    {

                        Connection.sourceFileCount++;
                        ftpClient.Upload(source + @"\" + Path.GetFileName(simpleDirectoryListing[i]), destination + @"/" + Path.GetFileName(simpleDirectoryListing[i]));
                        long FileSize = Convert.ToInt64(ftpClient.GetFileSize(destination + @"/" + Path.GetFileName(simpleDirectoryListing[i])));
                        Connection.Batches.Rows.Add(Path.GetFileName(simpleDirectoryListing[i]), new FileInfo(simpleDirectoryListing[i]).Length, FileSize);

                    }

                    string[] subDirectoryListing = Directory.GetDirectories(source);
                    foreach (string directory in subDirectoryListing)
                    {
                        ftpClient.FTPcreateDirectory(destination + @"/" + Path.GetFileName(directory));
                        UploadDirectory(ServerName, Userid, Password, directory, destination + @"/" + Path.GetFileName(directory));

                    }
                }
            }

            catch(Exception ex)
            {

                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();
            }
        }
        private void RowsClear()
        {
            if (Connection.Batches.Rows.Count > 0)
            {
                Connection.Batches.Rows.Clear();
            }        
        }

        private long FileSize(long Filelength)
        {
            string[] suffixes = { "B", "KB", "MB" };
            int s = 0;
            while (Filelength >= 1024)
            {
                s++;
                Filelength /= 1024;
            }

            return Filelength;
        }


        private FtpClientParameters DeSerialize(string clientName)
        {
            try
            {
                Connection.processlog = Connection.processlog + "call the DeSerialize Function ";
                XmlSerializer deserializer = new XmlSerializer(typeof(FtpClientParameters));
                TextReader reader = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + @"\Xml\" + clientName + @".xml");
                object obj = deserializer.Deserialize(reader);
                FtpClientParameters XmlData = (FtpClientParameters)obj;
                reader.Close();
                Connection.processlog = Connection.processlog + "DeSerialized the XML";
                return XmlData;
            }
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();
                return null;
            }


        }
        private RuleSetParameters ApplyRule(RuleSetParameters parameters)
        {
            try
            {
                Connection.processlog = Connection.processlog + "calling the Ruleset ";
                RuleSetManager rsm = new RuleSetManager();
                rsm.LoadRuleSet(parameters.ClientParameters.RuleSetName);
                Connection.processlog = Connection.processlog + "called the Ruleset.";
                rsm.ExecuteRuleSet(parameters);
                return parameters;
            }
            catch (Exception ex)
            {
                // Program.logger.Error(ex, clientName);
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();
                return null;
            }

        }
   

        class ftp
        {

            public string flag;
            private string host = null;
            private string user = null;
            private string pass = null;
            private FtpWebRequest ftpRequest = null;
            private FtpWebResponse ftpResponse = null;
            private Stream ftpStream = null;
            private int bufferSize = 2048;
            public string processlog;


            /* Construct Object */
            public ftp(string hostIP, string userName, string password)
            { host = hostIP; user = userName; pass = password; }
            //ftp ftpClient = new ftp(@"ftp://172.18.94.250/", "ahs01", "ahsgroup033");
            /* Download File */
            public void Upload(string localFile, string  remoteFile)
            {
                try
                {
                    processlog = processlog + "| Upload process start on " + DateTime.Now.ToString();
                    /* Create an FTP Request */
                    ftpRequest = (FtpWebRequest)FtpWebRequest.Create(new Uri("ftp://" + host + "/" + remoteFile));
                    /* Log in to the FTP Server with the User Name and Password Provided */
                    ftpRequest.Credentials = new NetworkCredential(user, pass);
                    /* When in doubt, use these options */
                    ftpRequest.UseBinary = true;
                    ftpRequest.UsePassive = true;
                    ftpRequest.KeepAlive = true;
                    /* Specify the Type of FTP Request */
                    ftpRequest.Method = WebRequestMethods.Ftp.UploadFile;

                    //ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
                    //ftpRequest.EnableSsl = true;
                    /* Establish Return Communication with the FTP Server */
                    using (FileStream fs = File.OpenRead(localFile))
                    {
                        byte[] buffer = new byte[fs.Length];
                        fs.Read(buffer, 0, buffer.Length);
                        fs.Close();
                        ftpStream = ftpRequest.GetRequestStream();
                        ftpStream.Write(buffer, 0, buffer.Length);
                        ftpStream.Flush();
                        
                    }
                 
                    ftpStream.Close();
                    ftpRequest = null;
                    processlog = processlog + "| Upload process End on " + DateTime.Now.ToString();
                }
                catch (Exception ex)
                {
                    Connection.processlog = Connection.processlog + ex.Message;
                    Connection.Errorstate = true;
                    Connection.Mail(remoteFile, localFile);
                    Connection.LogFiles();

                }
                return;
            }

            public string[] directoryListSimple(string directory)
            {
                try
                {
                    /* Create an FTP Request */
                    ftpRequest = (FtpWebRequest)FtpWebRequest.Create(new Uri("ftp://" + host + "/" + directory));
                    /* Log in to the FTP Server with the User Name and Password Provided */
                    ftpRequest.Credentials = new NetworkCredential(user, pass);
                    /* When in doubt, use these options */
                    ftpRequest.UseBinary = true;
                    ftpRequest.UsePassive = true;
                    ftpRequest.KeepAlive = true;
                    /* Specify the Type of FTP Request */
                    ftpRequest.Method = WebRequestMethods.Ftp.ListDirectory;
                    /* Establish Return Communication with the FTP Server */

                    //ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
                    //ftpRequest.EnableSsl = true;


                    ftpResponse = (FtpWebResponse)ftpRequest.GetResponse();
                    /* Establish Return Communication with the FTP Server */
                    ftpStream = ftpResponse.GetResponseStream();
                    /* Get the FTP Server's Response Stream */
                    StreamReader ftpReader = new StreamReader(ftpStream);
                    /* Store the Raw Response */
                    string directoryRaw = null;
                    /* Read Each Line of the Response and Append a Pipe to Each Line for Easy Parsing */
                    try { while (ftpReader.Peek() != -1) { directoryRaw += ftpReader.ReadLine() + "|"; } }
                    catch (Exception ex) { }
                    /* Resource Cleanup */
                    ftpReader.Close();
                    ftpStream.Close();
                    ftpResponse.Close();
                    ftpRequest = null;
                    /* Return the Directory Listing as a string Array by Parsing 'directoryRaw' with the Delimiter you Append (I use | in This Example) */
                    try { string[] directoryList = directoryRaw.Split("|".ToCharArray()); return directoryList; }
                    catch (Exception ex) { }
                }
                catch (Exception ex)
                {
                    Connection.processlog = Connection.processlog + ex.Message;
                    Connection.Errorstate = true;
                    Connection.Mail("", "");
                    Connection.LogFiles();
                    //ft.LogFiles();
                }
                /* Return an Empty string Array if an Exception Occurs */
                return new string[] { "" };
            }
            public void FTPcreateDirectory(string newDirectory)
            {
                try
                {
                    /* Create an FTP Request */
                    ftpRequest = (FtpWebRequest)WebRequest.Create(new Uri("ftp://" + host + "/" + newDirectory));
                    /* Log in to the FTP Server with the User Name and Password Provided */
                    ftpRequest.Credentials = new NetworkCredential(user, pass);
                    /* When in doubt, use these options */
                    ftpRequest.UseBinary = true;
                    ftpRequest.UsePassive = true;
                    ftpRequest.KeepAlive = true;
                    /* Specify the Type of FTP Request */

                    //ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
                    //ftpRequest.EnableSsl = true;
                    try
                    {
                        ftpRequest.Method = WebRequestMethods.Ftp.MakeDirectory;
                        ftpResponse = (FtpWebResponse)ftpRequest.GetResponse();
                    }
                    catch (Exception ex)
                    {
                        return;
                    }
                    /* Establish Return Communication with the FTP Server */




                    /* Resource Cleanup */
                    ftpResponse.Close();
                    ftpRequest = null;
                }
                catch (Exception ex)
                {
                    Connection.processlog = Connection.processlog + ex.Message;
                    Connection.Errorstate = true;
                    Connection.Mail("", "");
                    Connection.LogFiles();
                }
                return;
            }
            public long GetFileSize(string FileName)
            {
                try
                {
                    long FileLength;
                    ftpRequest = (FtpWebRequest)FtpWebRequest.Create(new Uri("ftp://" + host + "/" + FileName));
                    /* Log in to the FTP Server with the User Name and Password Provided */
                    ftpRequest.Credentials = new NetworkCredential(user, pass);
                    /* When in doubt, use these options */
                    ftpRequest.UseBinary = true;
                    ftpRequest.UsePassive = true;
                    ftpRequest.KeepAlive = true;

                    ftpRequest.Method = WebRequestMethods.Ftp.GetFileSize;


                    //ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
                    //ftpRequest.EnableSsl = true;
                    ftpResponse = (FtpWebResponse)ftpRequest.GetResponse();
                    FileLength = ftpResponse.ContentLength;


                    ftpResponse.Close();
                    ftpRequest = null;
                    if (FileLength < 0) FileLength = 0;
                    return FileLength;
                }
                catch (Exception ex)
                {
                    Connection.processlog = Connection.processlog + ex.Message;
                    Connection.Errorstate = true;
                    Connection.Mail("", "");
                    Connection.LogFiles();
                    return 0;
                }
            }

        }
        }
    }
