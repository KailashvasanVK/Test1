﻿using System;
using System.Linq;
using System.Text;
using System.Activities;
using System.Data;
using ActivityKibrary1;
using Renci.SshNet;
using System.Data.SqlClient;
using System.IO;
using System.Xml.Serialization;
using FTPParameters;
using ICSharpCode.SharpZipLib.Zip;
using ICSharpCode.SharpZipLib.Core;
using System.Collections.Generic;

namespace ServerConnection
{
    //private int FileTakenCount;
    //private string process;
    //public static string clientName;
    //private bool ErrorState;
    //DataTable Batches = new DataTable();
    //;
    public sealed class botSFTPWisconsin : CodeActivity
    {
        private string process;
        private int FileTakenCount;
        private string clientName;
        private SqlConnection Sqlcon;
        private SqlCommand Sqlcmd;
        private SqlDataReader SqlRead;

        RuleSetParameters rulesParameters = new RuleSetParameters();
        DataTable Batches = new DataTable();


        // Define an activity input argument of type string
        public InArgument<Boolean> XMLtype { get; set; }
        public InArgument<string> SourcePath { get; set; }
        public InArgument<string> DestinationPath { get; set; }
        public InArgument<string> PortNumber { get; set; }
        public InArgument<string> ServerName { get; set; }
        public InArgument<string> UserName { get; set; }
        public InArgument<string> Password { get; set; }
        public InArgument<string> DateFormat { get; set; }
        public InArgument<string> FolderName { get; set; }
        public InArgument<string> FolderDate { get; set; }
        public InArgument<string> Process { get; set; }

        public InArgument<string> ClientName { get; set; }
        public InArgument<string> RuleSetName { get; set; }
        public InArgument<string> ZipFolder { get; set; }
        public InArgument<string> FileExtension { get; set; }

        public InArgument<bool> ExtractZip { get; set; }
        //public int FileTakenCount { get; private set; }
        //public string clientName { get; private set; }

        // If your activity returns a value, derive from CodeActivity<TResult>
        // and return the value from the Execute method.
        protected override void Execute(CodeActivityContext context)
        {
            FtpClientParameters parameters = new FtpClientParameters();
            Batches.Columns.Add("BatchNo", typeof(string));
            Batches.Columns.Add("FiletakenPathSize", typeof(Int64));
            Batches.Columns.Add("FilePlacedPath", typeof(Int64));


            if (context.GetValue(this.XMLtype) == false)
            {
       
                // Obtain the runtime value of the Text input argument
                parameters.DownloadSource = context.GetValue(this.SourcePath);
                parameters.DownloadDestination = context.GetValue(this.DestinationPath);
                parameters.FolderDate = context.GetValue(this.FolderDate);
                parameters.FolderName = context.GetValue(this.FolderName);
                parameters.DateFormat = context.GetValue(this.DateFormat);
                parameters.ServerName = context.GetValue(this.ServerName);
                parameters.Port = context.GetValue(this.PortNumber);
                parameters.UserId = context.GetValue(this.UserName);
                parameters.Password = context.GetValue(this.Password);
                parameters.RuleSetName = context.GetValue(this.RuleSetName);
                parameters.ClientName = context.GetValue(this.ClientName);
                parameters.Process = context.GetValue(this.Process);
                parameters.ZipFolder = context.GetValue(this.ZipFolder);
                parameters.FileExtension = context.GetValue(this.FileExtension);
                parameters.ExtractZip = context.GetValue(this.ExtractZip);

            }

            else
            {
               clientName = Connection.ClientName;
               parameters = DeSerialize(clientName);
                context.SetValue(Process, parameters.Process);
                context.SetValue(SourcePath, parameters.DownloadSource);
                context.SetValue(DestinationPath, parameters.DownloadDestination);
                context.SetValue(FolderDate, parameters.FolderDate);
                context.SetValue(FolderName, parameters.FolderName);
                context.SetValue(DateFormat, parameters.DateFormat);
                context.SetValue(ServerName, parameters.ServerName);
                context.SetValue(UserName, parameters.UserId);
                context.SetValue(Password, parameters.Password);
                context.SetValue(RuleSetName, parameters.RuleSetName);
                context.SetValue(ClientName, parameters.ClientName);
                context.SetValue(ZipFolder, parameters.ZipFolder);

                context.SetValue(FileExtension, parameters.FileExtension);
                context.SetValue(ExtractZip, parameters.ExtractZip);



            }
            Download(parameters);

        }


        private void Download(FtpClientParameters parameters)
        {
            try

            {

                Connection.processlog = Connection.processlog + "Connecting the SFTP Server. ";


                rulesParameters.ClientParameters = parameters;
                clientName = parameters.ClientName;
                Connection.Client = clientName;
                process = parameters.Process;
                ApplyRule(rulesParameters);

              

                FileTakenCount = 0;
                RowsClear();
                using (var client = new SftpClient(parameters.ServerName, Convert.ToInt16(parameters.Port), parameters.UserId, parameters.Password))
                {
                    client.Connect();
                    Connection.processlog = Connection.processlog + "Connected the SFTP Server.Download started  ";

                    if (client.Exists(rulesParameters.DownloadSource) == true)
                        DownloadDirectory(client, rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                    else if (rulesParameters.DownloadSourceNext != null)
                    {
                        if (client.Exists(rulesParameters.DownloadSourceNext) == true)
                        {
                            DownloadDirectory(client, rulesParameters.DownloadSourceNext, rulesParameters.DownloadDestination);
                        }
                    }


                }
                Connection.processlog = Connection.processlog + "Download has completed.  ";
                ProcessLogFiles(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);

            }
            catch (Exception ex)
            {
                //  Program.logger.Error(ex, clientName);
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();


            }
            //TODO: Download files
        }

        private FtpClientParameters DeSerialize(string clientName)
        {
            try
            {
                Connection.processlog = Connection.processlog + "DeSerialize the XML. ";
                Connection.processlog = Connection.processlog + AppDomain.CurrentDomain.BaseDirectory + @"\Xml\" + clientName + @".xml";
                XmlSerializer deserializer = new XmlSerializer(typeof(FtpClientParameters));
                TextReader reader = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + @"\Xml\" + clientName + @".xml");
                object obj = deserializer.Deserialize(reader);
                FtpClientParameters XmlData = (FtpClientParameters)obj;
                reader.Close();
                Connection.processlog = Connection.processlog + "DeSerialize has completed. ";
                return XmlData;
            }
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();
                return null;
            }


        }
        private void DownloadDirectory(SftpClient client, string source, string destination)
        {

            try
            {
                  

                
                    var Files = client.ListDirectory(source);
                    foreach (var file in Files)
                    {
                        if (!file.IsDirectory && !file.IsSymbolicLink)
                        {
                            if (file.Name != "." && file.Name != ".." && file.Name != "Thumbs.db")
                            {
                                

                                if (Path.GetExtension(file.FullName) == ".pdf" && Path.GetExtension(file.FullName)==".txt")
                                {

                                    if (File.Exists(Path.Combine(destination, file.Name)) == false)
                                    {
                                        FileTakenCount++;
                                        using (Stream fileStream = File.OpenWrite(Path.Combine(destination, file.Name)))
                                        {
                                            client.DownloadFile(file.FullName, fileStream);
                                            FileInfo ff = new FileInfo(Path.Combine(destination, file.Name));
                                            Batches.Rows.Add(file.Name, FileSize(file.Length), FileSize(ff.Length));
                                        }
                                    }
                                }

                                else if(Path.GetFileName(file.FullName).Contains("CMNs")== true)
                                {
                                    if (File.Exists(Path.Combine(destination, file.Name)) == false)
                                    {
                                        FileTakenCount++;
                                        using (Stream fileStream = File.OpenWrite(Path.Combine(destination, file.Name)))
                                        {
                                            client.DownloadFile(file.FullName, fileStream);
                                            FileInfo ff = new FileInfo(Path.Combine(destination, file.Name));
                                            Batches.Rows.Add(file.Name, FileSize(file.Length), FileSize(ff.Length));
                                        }
                                    }

                                }
                            }
                        }

                        else if (file.Name != "." && file.Name != ".." && file.Name != "Thumbs.db")
                        {
                            if (!Directory.Exists(Path.Combine(destination, file.Name)))
                            {
                                var dir = Directory.CreateDirectory(Path.Combine(destination, file.Name));
                                DownloadDirectory(client, file.FullName, dir.FullName);
                            }
                        }
                    }
                


                if (rulesParameters.ExtractZip==true)
                {
                    RowsClear();
                    Connection.processlog = Connection.processlog + "Zip Extract has Start. ";
                    ExtractZipFile(destination, rulesParameters.zipFolder);
                    Connection.processlog = Connection.processlog + "Zip Extract has Completed. ";
                }
            }
            catch (Exception ex)
            {

                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();
            }
        }


        public void ExtractZipFile(string archiveFilenameIn, string outFolder)
        {
            ZipFile zf = null;
            try



            {

                // Program.logger.Info("Zip File Extract started");

                FileTakenCount = 0;
                var zipFiles = Directory.GetFiles(archiveFilenameIn);

                foreach (var FileName in zipFiles)
                {
                    if (Path.GetExtension(FileName) == ".zip")
                    {
                        FileStream fs = File.OpenRead(FileName);
                        zf = new ZipFile(fs);

                        foreach (ZipEntry zipEntry in zf)
                        {
                            if (!zipEntry.IsFile) continue; // Ignore directories

                            String entryFileName = zipEntry.Name;
                            //to remove the folder from the entry:
                            entryFileName = Path.GetFileName(entryFileName);

                            byte[] buffer = new byte[4096];     // 4K is optimum
                            Stream zipStream = zf.GetInputStream(zipEntry);
                            // Manipulate the output filename here as desired.
                            String fullZipToPath = Path.Combine(outFolder, entryFileName);
                            string directoryName = Path.GetDirectoryName(fullZipToPath);
                            if (directoryName.Length > 0)
                                Directory.CreateDirectory(directoryName);

                            using (FileStream streamWriter = File.Create(fullZipToPath))
                            {
                                FileTakenCount = FileTakenCount + 1;
                                StreamUtils.Copy(zipStream, streamWriter, buffer);
                               Batches.Rows.Add(entryFileName, FileSize(streamWriter.Length), FileSize(streamWriter.Length));
                            }
                        }
                    }
                }


            }

            catch (Exception ex)
            {

                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();
            }
            finally
            {
                if (zf != null)
                {
                    zf.IsStreamOwner = true;
                    zf.Close();
                }
            }
        }

        public void Mail(string Source, string Dest)
        {

            try
            {
                string SubjectText = clientName + " File  " + process + "  Details on " + DateTime.Now.ToString("MM/dd/yyyy");

                StringBuilder BodyMsg = new StringBuilder();
                BodyMsg.AppendLine("Hi All");
                BodyMsg.AppendLine("<br><br>");
                // if(Err)
                BodyMsg.AppendLine("<br> <br> <Table  border=1> <tr bgcolor=blue>  <td> Path Type </td>  <td> FilePath </td> <td> BatchCount </td> <td>Batch Size </td>  </tr> ");
                string FilePlacedSize = Batches.Compute("Sum(FilePlacedPath)", "").ToString();
                string FiletakenSize = Batches.Compute("Sum(FiletakenPathSize)", "").ToString();

                BodyMsg.AppendLine("<tr><td> Source </td><td>" + Source + "</td><td>" + Convert.ToString(FileTakenCount) + "</td><td>" + FiletakenSize + "</td><tr>");
                BodyMsg.AppendLine("<tr><td> Destination  </td><td>" + Dest + "</td><td>" + Convert.ToString(Batches.Rows.Count) + "</td><td>" + FilePlacedSize + "</td></tr>");
                BodyMsg.AppendLine("</table> <br><br><b> Thanks  <br><br> **** This is Auto generated Mail **** </b><br><br>");


                //else

                //{
                //    BodyMsg.AppendLine("File has not received in this path " + Source);
                //    BodyMsg.AppendLine("<br><br><b> Thanks  <br><br> **** This is Auto generated Mail **** </b><br><br>");
                //}


                String Qury = "exec  FTp_Mailsend @Subject,@Body";
                Sqlcon = new SqlConnection("Data Source=SQL-Listner;Initial catalog=ARC_ATHENA;User id=offlineAppuser;PWD=offline@app$2@16; multisubnetfailover=true");
                if (Sqlcon.State == ConnectionState.Closed)
                {
                    Sqlcon.Open();
                }
                Sqlcmd = new SqlCommand(Qury, Sqlcon);
                Sqlcmd.Parameters.AddWithValue("@Subject", SubjectText);
                Sqlcmd.Parameters.AddWithValue("@BODY", BodyMsg.ToString());
                Sqlcmd.ExecuteNonQuery();
                Environment.Exit(0);
            }
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.LogFiles();
            }

        }
        public void ProcessLogFiles(string Source, string Dest)
        {

            try
            {

                Connection.processlog = Connection.processlog + "call the ProcessLogFiles Function";
                Sqlcon = new SqlConnection(Connection.strSqlCon);

                if (Sqlcon.State == ConnectionState.Closed)
                {
                    Sqlcon.Open();
                }
                //ClientName varchar(100),@ProcessName varchar(30),@FiletakenPath varchar(300),@FilePlacedPath varchar(500),@Batchno BatchTrack readonly
                string strCmd = "FTP_MoveBatchlist";
                Sqlcmd = new SqlCommand(strCmd, Sqlcon);
                Sqlcmd.CommandType = CommandType.StoredProcedure;
                Sqlcmd.Parameters.Add("@ClientName", SqlDbType.VarChar, 100).Value = clientName;
                Sqlcmd.Parameters.Add("@ProcessName", SqlDbType.VarChar, 50).Value = process;
                Sqlcmd.Parameters.Add("@FiletakenPath", SqlDbType.VarChar, 50).Value = Source;
                Sqlcmd.Parameters.Add("@FilePlacedPath", SqlDbType.VarChar, 50).Value = Dest;
                SqlParameter Param = Sqlcmd.Parameters.AddWithValue("@Batchinfo", Batches);
                Param.SqlDbType = SqlDbType.Structured;

                Sqlcmd.ExecuteNonQuery();
                Sqlcmd.Cancel();
                Sqlcon.Close();
            }
            catch (Exception ex)
            {
                // Program.logger.Error(ex, clientName);
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.LogFiles();
            }

        }
        private void RowsClear()
        {
            if (Batches.Rows.Count > 0)
            {
                Batches.Rows.Clear();
            }
        }

        private long FileSize(long Filelength)
        {
            string[] suffixes = { "B", "KB", "MB" };
            int s = 0;
            while (Filelength >= 1024)
            {
                s++;
                Filelength /= 1024;
            }

            return Filelength;
        }


       


        private RuleSetParameters ApplyRule(RuleSetParameters parameters)
        {
            try
            {
                
                RuleSetManager rsm = new RuleSetManager();
                rsm.LoadRuleSet(parameters.ClientParameters.RuleSetName);
                rsm.ExecuteRuleSet(parameters);
                return parameters;
            }
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();
                return null;
            }

        }
    }
}
