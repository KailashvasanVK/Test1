﻿using System;
using System.Linq;
using System.Text;
using System.Activities;
using System.Data;
using ActivityKibrary1;
using System.Data.SqlClient;
using System.IO;
using System.Xml.Serialization;
using FTPParameters;
using System.Net;
using FluentFTP;
using System.Collections.Generic;
using Renci.SshNet;

namespace ServerConnection
{

    public sealed class botHoustonDownlaod : CodeActivity
    {
        // Define an activity input argument of type string
        int inc=0;
        private string process;
        private int FileTakenCount;
        private string clientName;
        private SqlConnection Sqlcon;
        private SqlCommand Sqlcmd;
        private SqlDataReader SqlRead;
        private FtpWebRequest ftpRequest = null;
        private FtpWebResponse ftpResponse = null;
        private Stream ftpStream = null;
        private int bufferSize = 2048;
        public string host;
        public string userid;
        public string pass;

        RuleSetParameters rulesParameters = new RuleSetParameters();
  
        DataTable FileName = new DataTable();
        DataTable batchDetails = new DataTable();

        Boolean errorState = false;
        public InArgument<Boolean> XMLtype { get; set; }
        public InArgument<string> SourcePath { get; set; }
        public InArgument<string> DestinationPath { get; set; }
        public InArgument<string> PortNumber { get; set; }
        public InArgument<string> ServerName { get; set; }
        public InArgument<string> UserName { get; set; }
        public InArgument<string> Password { get; set; }
        public InArgument<string> DateFormat { get; set; }
        public InArgument<string> FolderName { get; set; }
        public InArgument<string> FolderDate { get; set; }
        public InArgument<string> Process { get; set; }

        public InArgument<string> ClientName { get; set; }
        public InArgument<string> RuleSetName { get; set; }
        public InArgument<string> ZipFolder { get; set; }

        // If your activity returns a value, derive from CodeActivity<TResult>
        // and return the value from the Execute method.
        protected override void Execute(CodeActivityContext context)
        {
            FtpClientParameters parameters = new FtpClientParameters();
            batchDetails = new DataTable("batchDetails");
             batchDetails.Columns.Add("FileName", typeof(string));
            batchDetails.Columns.Add("FileSize", typeof(string));
            batchDetails.Columns.Add("CreatedTime", typeof(DateTime));

            FileName.Columns.Add("FileName", typeof(string));
            FileName.Columns.Add("FiletakenPathSize", typeof(Int64));
            FileName.Columns.Add("FilePlacedPath", typeof(Int64));


            Connection.Batches.Columns.Add("BatchNo", typeof(string));
            Connection.Batches.Columns.Add("sourceFileSize", typeof(Int64));
            Connection.Batches.Columns.Add("destinationFileSize", typeof(Int64));

            if (context.GetValue(this.XMLtype) == false)
            {

                // Obtain the runtime value of the Text input argument
                parameters.DownloadSource = context.GetValue(this.SourcePath);
                parameters.DownloadDestination = context.GetValue(this.DestinationPath);
                parameters.FolderDate = context.GetValue(this.FolderDate);
                parameters.FolderName = context.GetValue(this.FolderName);
                parameters.DateFormat = context.GetValue(this.DateFormat);
                parameters.ServerName = context.GetValue(this.ServerName);
                parameters.Port = context.GetValue(this.PortNumber);
                parameters.UserId = context.GetValue(this.UserName);
                parameters.Password = context.GetValue(this.Password);
                parameters.RuleSetName = context.GetValue(this.RuleSetName);
                parameters.ClientName = context.GetValue(this.ClientName);
                parameters.Process = context.GetValue(this.Process);

            }

            else
            {


                clientName = Connection.ClientName;
                parameters = DeSerialize(clientName);
                context.SetValue(Process, parameters.Process);
                context.SetValue(SourcePath, parameters.DownloadSource);
                context.SetValue(DestinationPath, parameters.DownloadDestination);
                context.SetValue(FolderDate, parameters.FolderDate);
                context.SetValue(FolderName, parameters.FolderName);
                context.SetValue(DateFormat, parameters.DateFormat);
                context.SetValue(ServerName, parameters.ServerName);
                context.SetValue(UserName, parameters.UserId);
                context.SetValue(Password, parameters.Password);
                context.SetValue(RuleSetName, parameters.RuleSetName);
                context.SetValue(ClientName, parameters.ClientName);
                context.SetValue(ZipFolder, parameters.ZipFolder);
            }
           // botSFTPConnect();
            Download(parameters);
        }

               private void Download(FtpClientParameters parameters)
        {
            try

            {

                Connection.processlog = Connection.processlog + "Connect the SFTP Server ";
              

                rulesParameters.ClientParameters = parameters;
                clientName = parameters.ClientName;
                process = parameters.Process;
               Connection.Process = parameters.Process;
                Connection.Client = clientName;
                ApplyRule(rulesParameters);

                ZipFolder = rulesParameters.zipFolder;

                Connection.sourceFileCount = 0;
                RowsClear();



                FtpClient client = new FtpClient(parameters.ServerName, parameters.UserId, parameters.Password);
               
                client.EncryptionMode = FtpEncryptionMode.Implicit;
                client.SslProtocols = System.Security.Authentication.SslProtocols.Tls;
                client.ValidateCertificate += Client_ValidateCertificate;
                client.Connect();
                client.DisableUTF8();


                if (parameters.ClientName != "Houston Access")
                {
                    DownloadFile(client, rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                }
                else

                {
                    DownloadFile(client, rulesParameters.DownloadSource + @"/Deficiency screenshots", rulesParameters.DownloadDestination + @"\Deficiency screenshots");
                    DownloadFile(client, rulesParameters.DownloadSource + @"/Access Deficiency Log", rulesParameters.DownloadDestination + @"\Access Deficiency Log");
                }
             
                client.Disconnect();


                Connection.ProcessLogFiles(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);

            }
            catch (Exception ex) 
            {
               
                //  Program.logger.Error(ex, clientName);
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail("", "");
                Connection.LogFiles();


            }
            //TODO: Download files
        }

        private void DownloadFile(FtpClient client,String Source, String Destination)
        {
            DateTime yesterday = DateTime.Now.AddDays(-1).Date;
            DateTime Today = DateTime.Now.AddDays(0).Date;
            if (rulesParameters.FolderModified == true)
            {

                var Files = client.GetListing(Source).AsEnumerable().Select(x =>
                    {

                        return x;
                    }).Where(x => (x.Modified.Date == yesterday && Convert.ToDateTime(x.Modified.ToShortTimeString()) > Convert.ToDateTime("08:00 AM")) || (x.Modified.Date == Today && Convert.ToDateTime(x.Modified.ToShortTimeString()) <= Convert.ToDateTime("08:00 AM")))
                                     .ToArray();


                    foreach (FtpListItem item in Files)
                    {
                        //listBox1.Items.Add(item.FullName);



                        if (item.Type == FtpFileSystemObjectType.File)
                        {
                            if (item.Name != "." && item.Name != ".." && item.Name != "Thumbs.db")
                            {
                            if (!File.Exists(Destination + @"\" + Path.GetFileName(item.FullName)))
                            {
                                Connection.sourceFileCount++;
                                inc++;
                                long size = client.GetFileSize(item.FullName);
                                client.DownloadFile(Destination + @"\" + Path.GetFileName(item.FullName), item.FullName);
                                FileInfo ff = new FileInfo(Path.Combine(Destination, item.Name));
                                Connection.Batches.Rows.Add(item.Name, size, ff.Length);
                                // FileName.Rows.Add(parameters.ClientName, item.Name);
                            }
                            }
                        }

                        else if (item.Type == FtpFileSystemObjectType.Directory)
                        {
                            if (item.Name != "Completed")
                            {
                                if (Directory.Exists(Destination + @"\" + item.Name) == false)
                                {
                                    Directory.CreateDirectory(Destination + @"\" + item.Name);
                                }
                                DownloadFile(client, Source + @"/" + item.Name, Destination + @"\" + item.Name);
                            }

                        }

                    }
                }

               
            else

            {

                foreach (FtpListItem item in client.GetListing(Source))
                {
                    //listBox1.Items.Add(item.FullName);

                    if (item.Type == FtpFileSystemObjectType.File)
                    {
                        if (item.Name != "." && item.Name != ".." && item.Name != "Thumbs.db")
                        {
                            if (!File.Exists(Destination + @"\" + Path.GetFileName(item.FullName)))
                            {
                                Connection.sourceFileCount++;
                                inc++;
                                long size = client.GetFileSize(item.FullName);
                                client.DownloadFile(Destination + @"\" + Path.GetFileName(item.FullName), item.FullName);
                                FileInfo ff = new FileInfo(Path.Combine(Destination, item.Name));
                                Connection.Batches.Rows.Add(item.Name, size, ff.Length);
                                // FileName.Rows.Add(parameters.ClientName, item.Name);
                            }
                        }
                    }

                    else if (item.Type == FtpFileSystemObjectType.Directory)
                    {
                        if (item.Name != "Completed")
                        {
                            if (Directory.Exists(Destination + @"\" + item.Name) == false)
                            {
                                Directory.CreateDirectory(Destination + @"\" + item.Name);
                            }
                            DownloadFile(client, Source + @"/" + item.Name, Destination + @"\" + item.Name);
                        }

                    }

                }
            }
        }
       

     

        private void Client_ValidateCertificate(FtpClient control, FtpSslValidationEventArgs e)
        {
            e.Accept = true;
        }
        private String FileSize(long Filelength)
        {
            string[] suffixes = { "B", "KB", "MB" };
            int s = 0;
            while (Filelength >= 1024)
            {
                s++;
                Filelength /= 1024;
            }

            return Convert.ToString(Filelength) + " " + suffixes[s];
        }



        private void RowsClear()
        {
            if (Connection.Batches.Rows.Count > 0)
            {
                Connection.Batches.Rows.Clear();
            }        
        }



        private FtpClientParameters DeSerialize(string clientName)
        {
            try
            {
                Connection.processlog = Connection.processlog + "call the DeSerialize Function ";
                XmlSerializer deserializer = new XmlSerializer(typeof(FtpClientParameters));
                TextReader reader = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + @"\Xml\" + clientName + @".xml");
                object obj = deserializer.Deserialize(reader);
                FtpClientParameters XmlData = (FtpClientParameters)obj;
                reader.Close();
                return XmlData;
            }
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail("", "");
                Connection.LogFiles();
                return null;
            }


        }
        private RuleSetParameters ApplyRule(RuleSetParameters parameters)
        {
            try
            {

                RuleSetManager rsm = new RuleSetManager();
                rsm.LoadRuleSet(parameters.ClientParameters.RuleSetName);
                rsm.ExecuteRuleSet(parameters);
                return parameters;
            }
            catch (Exception ex)
            {
                // Program.logger.Error(ex, clientName);
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail("", "");
                Connection.LogFiles();
                return null;
            }

        }
  
      
        

        class ftp
        {

            public string flag;
            private string host = null;
            private string user = null;
            private string pass = null;
            private FtpWebRequest ftpRequest = null;
            private FtpWebResponse ftpResponse = null;
            private Stream ftpStream = null;
            private int bufferSize = 2048;
            public string processlog;

            /* Construct Object */
            public ftp(string hostIP, string userName, string password)
            { host = hostIP; user = userName; pass = password; }
            //ftp ftpClient = new ftp(@"ftp://172.18.94.250/", "ahs01", "ahsgroup033");
            /* Download File */
            public void download(string remoteFile, string localFile)
            {
                try
                {
                    processlog = processlog + "| download process start on " + DateTime.Now.ToString();
                    /* Create an FTP Request */
                    ftpRequest = (FtpWebRequest)FtpWebRequest.Create(new Uri("ftp://" + host + "/" + remoteFile));
                    /* Log in to the FTP Server with the User Name and Password Provided */
                    ftpRequest.Credentials = new NetworkCredential(user, pass);
                    /* When in doubt, use these options */
                    ftpRequest.UseBinary = true;
                    ftpRequest.UsePassive = true;
                    ftpRequest.KeepAlive = true;
                    /* Specify the Type of FTP Request */
                    ftpRequest.Method = WebRequestMethods.Ftp.DownloadFile;
                    /* Establish Return Communication with the FTP Server */
                    
                    //ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
                    //ftpRequest.EnableSsl = true;
                    ftpResponse = (FtpWebResponse)ftpRequest.GetResponse();

                    /* Get the FTP Server's Response Stream */
                    ftpStream = ftpResponse.GetResponseStream();
                    /* Open a File Stream to Write the Downloaded File */
                    FileStream localFileStream = new FileStream(localFile, FileMode.Create);
                    /* Buffer for the Downloaded Data */
                    byte[] byteBuffer = new byte[bufferSize];
                    int bytesRead = ftpStream.Read(byteBuffer, 0, bufferSize);
                    /* Download the File by Writing the Buffered Data Until the Transfer is Complete */
                    try
                    {
                        while (bytesRead > 0)
                        {
                            localFileStream.Write(byteBuffer, 0, bytesRead);
                            bytesRead = ftpStream.Read(byteBuffer, 0, bufferSize);
                        }
                    }
                    catch (Exception ex) { }
                    /* Resource Cleanup */
                    localFileStream.Close();
                    ftpStream.Close();
                    ftpResponse.Close();
                    ftpRequest = null;
                    processlog = processlog + "| download process End on " + DateTime.Now.ToString();
                }
                catch (Exception ex)
                {
                    Connection.processlog = processlog;
                    Connection.LogFiles();
                    processlog = processlog + "|" + ex.Message + " on " + DateTime.Now.ToString();
                    //ft.LogFiles();

                }

            }


            private void getFTPDetails(string remoteFile)
            {
                ftpRequest = (FtpWebRequest)FtpWebRequest.Create(new Uri("ftp://" + host + "/" + remoteFile));
                /* Log in to the FTP Server with the User Name and Password Provided */
                ftpRequest.Credentials = new NetworkCredential(user, pass);
                /* When in doubt, use these options */
                ftpRequest.UseBinary = true;
                ftpRequest.UsePassive = true;
                ftpRequest.KeepAlive = true;
                ftpRequest.Method = WebRequestMethods.Ftp.GetFileSize;
                ftpResponse = (FtpWebResponse)ftpRequest.GetResponse();

                
                
            }

            public string[] directoryListSimple(string directory)
            {
                try
                {
                    /* Create an FTP Request */
                    ftpRequest = (FtpWebRequest)FtpWebRequest.Create(new Uri("ftp://" + host + "/" + directory));
                    /* Log in to the FTP Server with the User Name and Password Provided */
                    ftpRequest.Credentials = new NetworkCredential(user, pass);
                    /* When in doubt, use these options */
                    ftpRequest.UseBinary = true;
                    ftpRequest.UsePassive = true;
                    ftpRequest.KeepAlive = true;
                    /* Specify the Type of FTP Request */
                    ftpRequest.Method = WebRequestMethods.Ftp.ListDirectory;
                    /* Establish Return Communication with the FTP Server */

                    //ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
                    //ftpRequest.EnableSsl = true;


                    ftpResponse = (FtpWebResponse)ftpRequest.GetResponse();
                    /* Establish Return Communication with the FTP Server */
                    ftpStream = ftpResponse.GetResponseStream();
                    /* Get the FTP Server's Response Stream */
                    StreamReader ftpReader = new StreamReader(ftpStream);
                    /* Store the Raw Response */
                    string directoryRaw = null;
                    /* Read Each Line of the Response and Append a Pipe to Each Line for Easy Parsing */
                    try { while (ftpReader.Peek() != -1) { directoryRaw += ftpReader.ReadLine() + "|"; } }
                    catch (Exception ex) { }
                    /* Resource Cleanup */
                    ftpReader.Close();
                    ftpStream.Close();
                    ftpResponse.Close();
                    ftpRequest = null;
                    /* Return the Directory Listing as a string Array by Parsing 'directoryRaw' with the Delimiter you Append (I use | in This Example) */
                    try { string[] directoryList = directoryRaw.Split("|".ToCharArray()); return directoryList; }
                    catch (Exception ex) { }
                }
                catch (Exception ex)
                {
                    processlog = processlog + "|" + ex.Message + " on " + DateTime.Now.ToString();
                    Connection.processlog = processlog;
                    Connection.LogFiles();
                    //ft.LogFiles();
                }
                /* Return an Empty string Array if an Exception Occurs */
                return new string[] { "" };
            }

        }
        }
    }
