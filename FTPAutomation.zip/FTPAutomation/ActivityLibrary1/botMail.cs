﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Activities;

namespace ServerConnection
{

    public sealed class botMail : CodeActivity
    {
    

        // Define an activity input argument of type string
        public InArgument<string> FromMail { get; set; }
        public InArgument<string> ToMail { get; set; }
        public InArgument<string> CcMail { get; set; }
        public InArgument<string> SubjectText{ get; set; }
        public InArgument<string> Body { get; set; }
        public InArgument<string> ProcessName { get; set; }



        // If your activity returns a value, derive from CodeActivity<TResult>
        // and return the value from the Execute method.
        protected override void Execute(CodeActivityContext context)
        {
            // Obtain the runtime value of the Text input argument
            string FromMail = context.GetValue(this.FromMail);
            string ToMail = context.GetValue(this.ToMail);
            string CcMail = context.GetValue(this.CcMail);
            string SubjectText = context.GetValue(this.SubjectText);
            string Body = context.GetValue(this.Body);

        }
    }
}
