﻿using Renci.SshNet;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServerConnection
{
   public class SFTPConnect
    {
        private  SqlConnection Sqlcon;
        private  SqlCommand Sqlcmd;
        private  SqlDataReader SqlRead;

        string ServerName;
        string UserName;
        string Password;
        string PortNumber;
        public SftpClient ServerConnect(string ConnectionString, string SPName, string ProcessName, string ServerType)
        {
            Sqlcon = new SqlConnection(ConnectionString);

            if (Sqlcon.State == ConnectionState.Closed)
            {
                Sqlcon.Open();
            }
            //ClientName varchar(100),@ProcessName varchar(30),@FiletakenPath varchar(300),@FilePlacedPath varchar(500),@Batchno BatchTrack readonly
           // string strCmd = "FTPAthena_pGetServerDetails";
            Sqlcmd = new SqlCommand(SPName, Sqlcon);
            Sqlcmd.CommandType = CommandType.StoredProcedure;
            Sqlcmd.Parameters.Add("@ProcessName", SqlDbType.VarChar, 50).Value = ProcessName;
            Sqlcmd.Parameters.Add("@ServerType", SqlDbType.VarChar, 50).Value = ServerType;
            SqlRead = Sqlcmd.ExecuteReader();
            SqlRead.Read();
            if (SqlRead.HasRows)
            {
                ServerName = SqlRead["ServerIPAddress"].ToString();
                UserName = SqlRead["UserId"].ToString();
                Password = SqlRead["Password"].ToString();
                PortNumber = SqlRead["PortNumber"].ToString();

            }
            SqlRead.Close();
            Sqlcmd.Cancel();
            Sqlcon.Close();


            var client = new SftpClient(ServerName, Convert.ToInt16(PortNumber), UserName, Password);
            client.Connect();
            return client;
                //{
                //    client.Connect();
                //}

        }



    

    }
}
