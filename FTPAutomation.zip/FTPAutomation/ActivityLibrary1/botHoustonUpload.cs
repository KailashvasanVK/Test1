﻿using System;
using System.Linq;
using System.Text;
using System.Activities;
using System.Data;
using ActivityKibrary1;
using System.Data.SqlClient;
using System.IO;
using System.Xml.Serialization;
using FTPParameters;
using System.Net;
using FluentFTP;
using System.Collections.Generic;
using Renci.SshNet;

namespace ServerConnection
{

    public sealed class botHoustonUpload: CodeActivity
    {
        // Define an activity input argument of type string
        int inc=0;
        private string process;
        private int FileTakenCount;
        private string clientName;
        private SqlConnection Sqlcon;
        private SqlCommand Sqlcmd;
        private SqlDataReader SqlRead;
        private FtpWebRequest ftpRequest = null;
        private FtpWebResponse ftpResponse = null;
        private Stream ftpStream = null;
        private int bufferSize = 2048;
        public string host;
        public string userid;
        public string pass;

        RuleSetParameters rulesParameters = new RuleSetParameters();
        DataTable Batches = new DataTable();
        DataTable FileName = new DataTable();
        DataTable batchDetails = new DataTable();

        Boolean errorState = false;
        public InArgument<Boolean> XMLtype { get; set; }
        public InArgument<string> SourcePath { get; set; }
        public InArgument<string> DestinationPath { get; set; }
        public InArgument<string> PortNumber { get; set; }
        public InArgument<string> ServerName { get; set; }
        public InArgument<string> UserName { get; set; }
        public InArgument<string> Password { get; set; }
        public InArgument<string> DateFormat { get; set; }
        public InArgument<string> FolderName { get; set; }
        public InArgument<string> FolderDate { get; set; }
        public InArgument<string> Process { get; set; }

        public InArgument<string> ClientName { get; set; }
        public InArgument<string> RuleSetName { get; set; }
        public InArgument<string> ZipFolder { get; set; }

        // If your activity returns a value, derive from CodeActivity<TResult>
        // and return the value from the Execute method.
        protected override void Execute(CodeActivityContext context)
        {
            FtpClientParameters parameters = new FtpClientParameters();
            batchDetails = new DataTable("batchDetails");
             batchDetails.Columns.Add("FileName", typeof(string));
            batchDetails.Columns.Add("FileSize", typeof(string));
            batchDetails.Columns.Add("CreatedTime", typeof(DateTime));

            FileName.Columns.Add("FileName", typeof(string));
            FileName.Columns.Add("FiletakenPathSize", typeof(Int64));
            FileName.Columns.Add("FilePlacedPath", typeof(Int64));

            Connection.Batches.Columns.Add("BatchNo", typeof(string));
            Connection.Batches.Columns.Add("sourceFileSize", typeof(Int64));
            Connection.Batches.Columns.Add("destinationFileSize", typeof(Int64));

            if (context.GetValue(this.XMLtype) == false)
            {

                // Obtain the runtime value of the Text input argument
                parameters.DownloadSource = context.GetValue(this.SourcePath);
                parameters.DownloadDestination = context.GetValue(this.DestinationPath);
                parameters.FolderDate = context.GetValue(this.FolderDate);
                parameters.FolderName = context.GetValue(this.FolderName);
                parameters.DateFormat = context.GetValue(this.DateFormat);
                parameters.ServerName = context.GetValue(this.ServerName);
                parameters.Port = context.GetValue(this.PortNumber);
                parameters.UserId = context.GetValue(this.UserName);
                parameters.Password = context.GetValue(this.Password);
                parameters.RuleSetName = context.GetValue(this.RuleSetName);
                parameters.ClientName = context.GetValue(this.ClientName);
                parameters.Process = context.GetValue(this.Process);

            }

            else
            {


                clientName = Connection.ClientName;
                parameters = DeSerialize(clientName);
                context.SetValue(Process, parameters.Process);
                context.SetValue(SourcePath, parameters.DownloadSource);
                context.SetValue(DestinationPath, parameters.DownloadDestination);
                context.SetValue(FolderDate, parameters.FolderDate);
                context.SetValue(FolderName, parameters.FolderName);
                context.SetValue(DateFormat, parameters.DateFormat);
                context.SetValue(ServerName, parameters.ServerName);
                context.SetValue(UserName, parameters.UserId);
                context.SetValue(Password, parameters.Password);
                context.SetValue(RuleSetName, parameters.RuleSetName);
                context.SetValue(ClientName, parameters.ClientName);
                context.SetValue(ZipFolder, parameters.ZipFolder);
            }
            // botSFTPConnect();
            Upload(parameters);
        }

               private void Upload(FtpClientParameters parameters)
        {
            try

            {

                Connection.processlog = Connection.processlog + "Connect the FTP Server  on" +  DateTime.Now.ToString();
              

                rulesParameters.ClientParameters = parameters;
                clientName = parameters.ClientName;
                process = parameters.Process;
                ApplyRule(rulesParameters);
                Connection.Client = clientName;
                Connection.Process = process;
                ZipFolder = rulesParameters.zipFolder;

                Connection.sourceFileCount = 0;
                RowsClear();

                if (Directory.Exists(rulesParameters.DownloadSource))
                {

                    FtpClient client = new FtpClient(parameters.ServerName, parameters.UserId, parameters.Password);
                    client.EncryptionMode = FtpEncryptionMode.Implicit;
                    client.SslProtocols = System.Security.Authentication.SslProtocols.Tls;
                    client.ValidateCertificate += Client_ValidateCertificate;
                    client.Connect();
                    Connection.processlog = Connection.processlog + "Connected the FTP Server  on" + DateTime.Now.ToString();
                    Connection.processlog = Connection.processlog + "File is starting to Upload  on" + DateTime.Now.ToString();

                    if (parameters.FolderModified == false)
                    {

                        if (!client.DirectoryExists(rulesParameters.DownloadDestination))
                        {
                            client.CreateDirectory(rulesParameters.DownloadDestination);
                        }

                        UploadFile(client, rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                    }
                    else

                    {

                        Connection.sourceFileCount++;
                        if (client.FileExists(rulesParameters.DownloadDestination))
                        {

                            client.DeleteFile(rulesParameters.DownloadDestination);
                        }
                        client.UploadFile(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                        long size = client.GetFileSize(rulesParameters.DownloadDestination);
                        FileInfo ff = new FileInfo(rulesParameters.DownloadSource);
                        Connection.Batches.Rows.Add(FileName, size, ff.Length);
                    }
                    client.Disconnect();
                }
                Connection.processlog = Connection.processlog + "File Upload has Completed on" + DateTime.Now.ToString();
                Connection.ProcessLogFiles(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
             

            }
            catch (Exception ex) 
            {
                //  Program.logger.Error(ex, clientName);
                Connection.processlog = Connection.processlog + ex.Message + "on" + DateTime.Now.ToString();
                Connection.Errorstate = true;
                Connection.Mail("", "");
                Connection.LogFiles();


            }
            //TODO: Download files
        }

      
        private void UploadFile(FtpClient client,String source, String destination)
        {

            DirectoryInfo dir = new DirectoryInfo(source);
            var Files = dir.GetFiles("*.*");
            foreach (FileInfo item in Files)
            {
                //listBox1.Items.Add(item.FullName); 


                if (item.Name != "." && item.Name != ".." && item.Name != "Thumbs.db")
                {
                    if (!client.FileExists(destination + @"/" + Path.GetFileName(item.FullName)))
                    {
                        Connection.sourceFileCount++;
                        inc++;

                        client.UploadFile(item.FullName, destination + @"\" + Path.GetFileName(item.FullName));
                        long size = client.GetFileSize(Path.Combine(destination, item.Name));
                        FileInfo ff = new FileInfo(item.FullName);
                        Connection.Batches.Rows.Add(item.Name, size, ff.Length);
                        // FileName.Rows.Add(parameters.ClientName, item.Name);
                    }
                }
            }
                string[] subdirectory = Directory.GetDirectories(source);
                foreach (string directory in subdirectory)
                {
                    if (!client.DirectoryExists(destination + @"/" + Path.GetFileName(directory)))
                    {
                        client.CreateDirectory(destination + @"/" + Path.GetFileName(directory));
                        UploadFile(client, directory, destination + @"/" + Path.GetFileName(directory));
                    }
                }




            
        }
       

        private void getNewFileName()
        {
            Sqlcon = new SqlConnection(Connection.strSqlCon);
            string  Qury = "FTP_pGetNewFileName";
            Sqlcmd = new SqlCommand(Qury, Sqlcon);
            if (Sqlcon.State == ConnectionState.Closed)
            {
                Sqlcon.Open();
            }
            Sqlcmd.Parameters.AddWithValue("@ClientName", clientName);
            Sqlcmd.CommandType = CommandType.StoredProcedure;
            SqlParameter param = Sqlcmd.Parameters.AddWithValue("@File", batchDetails);
            param.SqlDbType = SqlDbType.Structured;
            SqlRead = Sqlcmd.ExecuteReader();
            Batches.Load(SqlRead);
            SqlRead.Close();
            Sqlcmd.Cancel();
            Sqlcon.Close();

        }

        private void Client_ValidateCertificate(FtpClient control, FtpSslValidationEventArgs e)
        {
            e.Accept = true;
        }
      


        private void RowsClear()
        {
            if (Connection.Batches.Rows.Count > 0)
            {
                Connection.Batches.Rows.Clear();
            }        
        }



        private FtpClientParameters DeSerialize(string clientName)
        {
            try
            {
                Connection.processlog = Connection.processlog + "call the DeSerialize Function ";
                XmlSerializer deserializer = new XmlSerializer(typeof(FtpClientParameters));
                TextReader reader = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + @"\Xml\" + clientName + @".xml");
                object obj = deserializer.Deserialize(reader);
                FtpClientParameters XmlData = (FtpClientParameters)obj;
                reader.Close();
                return XmlData;
            }
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail("", "");
                Connection.LogFiles();
                return null;
            }


        }
        private RuleSetParameters ApplyRule(RuleSetParameters parameters)
        {
            try
            {

                RuleSetManager rsm = new RuleSetManager();
                rsm.LoadRuleSet(parameters.ClientParameters.RuleSetName);
                rsm.ExecuteRuleSet(parameters);
                return parameters;
            }
            catch (Exception ex)
            {
                // Program.logger.Error(ex, clientName);
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail("", "");
                Connection.LogFiles();
                return null;
            }

        }
  
      
        
        
        }
    }
