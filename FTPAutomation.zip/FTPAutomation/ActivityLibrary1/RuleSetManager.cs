﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Workflow.Activities.Rules;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Xml;

namespace ActivityKibrary1
{
    public class RuleSetManager
    {
        RuleSet ruleSet;
        private string _ruleSetName = "";
        public string RuleSetName
        {
            get { return _ruleSetName; }
            set { _ruleSetName = value; }
        }
        public void LoadRuleSet(string ruleSetName)
        {

            try
            {

                Connection.processlog = Connection.processlog + "Load the Ruleset start. ";
               WorkflowMarkupSerializer serializer = new WorkflowMarkupSerializer();
                if (string.IsNullOrEmpty(ruleSetName))
                    throw new Exception("Ruleset name cannot be null or empty.");
                //if (!string.Equals(RuleSetName, ruleSetName))
                {
                    _ruleSetName = ruleSetName;

                    ruleSet = GetRuleSetFromDB(serializer);
                    if (ruleSet == null)
                    {
                        
                        Connection.processlog = Connection.processlog + "RuleSet could not be loaded. Make sure the connection string and ruleset name are correct.";
                        Connection.Errorstate = true;
                        Connection.Mail("", "");
                        Connection.LogFiles();
                    }
                }
            }
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail("", "");
                Connection.LogFiles();
            }
        }

        private RuleSet GetRuleSetFromDB(WorkflowMarkupSerializer serializer)
        {

            Connection.processlog = Connection.processlog + "Connect the DB for Rules Load. ";
            string _connectionString = string.Empty;
            //ConnectionStringSettingsCollection connectionStringSettingsCollection = ConfigurationManager.ConnectionStrings;
            //foreach (ConnectionStringSettings connectionStringSettings in connectionStringSettingsCollection)
            //{
            //    if (string.CompareOrdinal(connectionStringSettings.Name, "RuleSetStoreConnectionString") == 0)
            //        _connectionString = connectionStringSettings.ConnectionString;
            //}

            //if (_connectionString == string.Empty)
            //    //MessageBox.Show("SQL connection string not available (should be provided in the config file).", "Configuration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    //ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('SQL connection string not available (should be provided in the config file).');", true);
            //if (string.IsNullOrEmpty(_connectionString))
            //    return null;
            SqlDataReader reader = null;
            SqlConnection sqlConn = null;
            try
            {
                sqlConn = new SqlConnection(Connection.strSqlCon);

                if (sqlConn.State == ConnectionState.Closed)
                {
                    sqlConn.Open();
                }
                SqlParameter p1 = new SqlParameter("@p1", _ruleSetName);
                string commandString = "SELECT * FROM FTP_RuleSet WHERE Name= @p1 ORDER BY ModifiedDate DESC";
                SqlCommand command = new SqlCommand(commandString, sqlConn);
                command.Parameters.Add(p1);
                reader = command.ExecuteReader();
            }
            catch (Exception ex)
            {

                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail("", "");
                Connection.LogFiles();
            }
            RuleSet resultRuleSet = null;
            try
            {
                reader.Read();
                resultRuleSet = DeserializeRuleSet(reader.GetString(3), serializer);
                Connection.processlog = Connection.processlog + "Loaded the Rules From DB. ";
            }
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail("", "");
                Connection.LogFiles();
            }
            sqlConn.Close();
            sqlConn.Dispose();
            return resultRuleSet;
        }

        private RuleSet DeserializeRuleSet(string ruleSetXmlDefinition, WorkflowMarkupSerializer serializer)
        {
            StringReader stringReader = new StringReader(ruleSetXmlDefinition);
            XmlTextReader reader = new XmlTextReader(stringReader);
            return serializer.Deserialize(reader) as RuleSet;
        }

        private RuleExecution ValidateRuleSet(object targetObject, RuleSet ruleSet)
        {

            try
            {

                Connection.processlog = Connection.processlog + "Validate the Rulesset.";
                RuleValidation ruleValidation;

            ruleValidation = new RuleValidation(targetObject.GetType(), null);
            if (!ruleSet.Validate(ruleValidation))
            {
                string errors = "";
                foreach (ValidationError validationError in ruleValidation.Errors)
                    errors = errors + validationError.ErrorText + "\n";
                    Connection.processlog = Connection.processlog + errors;
                return null;
            }
            else
            {
                return new RuleExecution(ruleValidation, targetObject);
            }
            }
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail("", "");
                Connection.LogFiles();
                return null;
            }
        }

        private void ExecuteRule(RuleExecution ruleExecution)
        {

            try
            {

                Connection.processlog = Connection.processlog + "Execute the Rule. ";
                if (null != ruleExecution)
                {
                    ruleSet.Execute(ruleExecution);
                }
                else
                {
                    Connection.processlog = Connection.processlog + "RuleExecution is null. ";
                    throw new Exception("RuleExecution is null.");
                }
            }

            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail("", "");
                Connection.LogFiles();
            }
           
        }

        public void ExecuteRuleSet(object targetObject)
        {

            try
            {

                Connection.processlog = Connection.processlog + "Execute the Ruleset. ";
                if (ruleSet != null)
                {
                    RuleExecution ruleExecution;
                    ruleExecution = ValidateRuleSet(targetObject, ruleSet);
                    ExecuteRule(ruleExecution);
                }
            }


            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail("", "");
                Connection.LogFiles();
            }

        }
    }
}
