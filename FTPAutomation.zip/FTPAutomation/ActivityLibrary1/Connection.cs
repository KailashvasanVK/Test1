﻿using System;
using System.Linq;
using System.Xml;
using System.IO;
using System.Xml.Serialization;
using System.Reflection;
//using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace ActivityKibrary1
{

    public class Connection
    {
        public static string strArc_Live_Off;
        public static string strArc_Live_Flow;
        XmlDataDocument xmldoc = new XmlDataDocument();
        XmlDataDocument SQldoc = new XmlDataDocument();
        XmlNodeList xmlConnectionnode, xmlCustomerDetailsnode, xmldestinationDirnode,xmlSqlConnectionnode;
        string xmlConPassword = "", xmlUserId = "";
        string CommendlineParam = "", UserRole = "";
        string SqlUesrid,SqlPwd, SqlDB,SqlServer;
        public static string strSqlCon = "Data Source=172.19.5.23;Initial catalog=Arc_athena;User id=UATLOGIN;PWD=Uadfw#qweLJu83@loinfd3@#$";
        //public static string strSqlCon = "Data Source=MK-DB-LISTNER;Initial catalog=ARC_AZUS_AR;User id=MK_AppUser;PWD=App@U$#r!MKU$2@17;pooling=true;Max Pool size=15000;";
        private static SqlConnection Sqlcon;
        private static SqlCommand Sqlcmd;
        private static SqlDataReader SqlRead;

        public static int sourceFileCount;
        string DateFormat;
        string Dowloadftppath,Dowloadlocalpath;
        string uploadftppath, uploadlocalpath;
        string ZipFilePath, FTPIP,ArchiveFtppath;
        public static string processlog;
        public static string Client;
        int PortId;
        public static string Process;
        public static string ClientName;
      
        public static bool Errorstate;
        public  static DataTable Batches = new DataTable();
        
          
       
        public static string ProName
        {
            get
            {
                return Process;
            }
            set
            {
                Process = value;
            }
        }

        public static string Clients
        {
            get
            {
                return ClientName;
            }
            set
            {
                ClientName = value;
            }
        }



        //public void PacificConnection()
        //{
        //    try
        //    {
        //        string[] args = Environment.GetCommandLineArgs();

        //        if (args.Length > 1)
        //            CommendlineParam = args[1];
        //        //string fileName = @"\\10.1.0.1\athenaftp\FTP\ConnectionString\ConfigurationOffline.xml";

        //        string fileName;//= Application.StartupPath + "\\" + "Configuration.xml";

        //        FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
        //        xmldoc.Load(fs);
        //        fs.Close();
        //        xmlConnectionnode = xmldoc.GetElementsByTagName(Connection.ClientName + "Connection");
        //        if (xmlConnectionnode.Count > 0)
        //        {

        //            ArchiveFtppath = xmlConnectionnode[0].ChildNodes.Item(8).InnerText.Trim();
        //            uploadlocalpath = xmlConnectionnode[0].ChildNodes.Item(7).InnerText.Trim();
        //            uploadftppath = xmlConnectionnode[0].ChildNodes.Item(6).InnerText.Trim();
        //            DateFormat = xmlConnectionnode[0].ChildNodes.Item(5).InnerText.Trim();
        //            Dowloadlocalpath = xmlConnectionnode[0].ChildNodes.Item(4).InnerText.Trim();
        //            Dowloadftppath = xmlConnectionnode[0].ChildNodes.Item(3).InnerText.Trim();
        //            FTPIP = xmlConnectionnode[0].ChildNodes.Item(2).InnerText.Trim();
        //            xmlConPassword = xmlConnectionnode[0].ChildNodes.Item(1).InnerText.Trim();
        //            xmlUserId = xmlConnectionnode[0].ChildNodes.Item(0).InnerText.Trim();
        //            ftp ftpClient = new ftp(FTPIP, xmlUserId, xmlConPassword);

        //            if (Process == "Download")
        //            //  if (Dowloadlocalpath != "")
        //            {
        //                Client = "Floridadwnld";
        //                Directory.CreateDirectory(Dowloadlocalpath + DateTime.Now.ToString(DateFormat));

        //                string[] simpleDirectoryListing = ftpClient.directoryListSimple(Dowloadftppath);
        //                for (int i = 0; i < simpleDirectoryListing.Count(); i++)
        //                {

        //                    string path = Dowloadlocalpath + DateTime.Now.ToString(DateFormat) + @"\" + simpleDirectoryListing[i];
        //                    string Filename = Dowloadftppath + @"\" + simpleDirectoryListing[i];
        //                    ftpClient.download(Filename, path);

        //                }

        //                //ftpClient.createDirectory(ArchiveFtppath + DateTime.Now.ToString(DateFormat));
        //                //string[] localDirectoryListing = ftpClient.directoryListSimple(Dowloadftppath);
        //                //for (int i = 0; i < localDirectoryListing.Count(); i++)
        //                //{

        //                //    string path = ArchiveFtppath + DateTime.Now.ToString(DateFormat) + @"/" + localDirectoryListing[i];
        //                //    string Filename = Dowloadftppath + @"/" + localDirectoryListing[i];
        //                //    //File.Move(Filename, path);

        //                //    ftpClient.rename(Filename, path);

        //                //}


        //            }

        //            if (uploadlocalpath != "")
        //            {
        //                Client = "Pacificupld";
        //                string filename = uploadftppath + DateTime.Now.ToString(DateFormat);
        //                ftpClient.createDirectory(filename);
        //                string[] downloadDirectoryListing = Directory.GetFiles(uploadlocalpath);
        //                for (int i = 0; i < downloadDirectoryListing.Count(); i++)
        //                {

        //                    string path = uploadftppath + DateTime.Now.ToString(DateFormat) + @"\" + Path.GetFileName(downloadDirectoryListing[i]);
        //                    string Filename = downloadDirectoryListing[i];
        //                    ftpClient.upload(path, Filename);

        //                }
        //            }



        //        }





        //    }
        //    catch (Exception Ex)
        //    {
        //        Environment.Exit(0);
        //    }
        //}

        public static void LogFiles()
        {

            try
            {


                FileInfo fileInfo = new FileInfo(Assembly.GetExecutingAssembly().Location);
                string LogPath = fileInfo.DirectoryName + "\\\\" + "ErrorLog";

                if ((Directory.Exists(LogPath) == false))
                {
                    Directory.CreateDirectory(LogPath);
                }
                string filename = Connection.ClientName + "-" + DateTime.Now.ToString("MMddyyyy") + ".txt";
                string filepath = LogPath + "\\\\" + filename;


                if ((File.Exists(filepath) == false))
                {
                    using (StreamWriter writer = new StreamWriter(filepath, true))
                    {

                        writer.WriteLine(Environment.NewLine);

                        writer.WriteLine(Connection.processlog);
                    }


                }
                else
                {
                    StreamWriter writer = File.CreateText(filepath);
                    writer.WriteLine(Environment.NewLine);
                    writer.WriteLine(Connection.processlog);
                    writer.Close();
                }
               // Environment.Exit(0);

            }
            catch (Exception ex)
            {
               Environment.Exit(0);
            }
        }


        public static void Mail(string Source, string Dest)
        {

            try
            {
                string SubjectText = Connection.Client + "  File  " + Process + "  Details on " + DateTime.Now.ToString("MM/dd/yyyy");

                StringBuilder BodyMsg = new StringBuilder();
                BodyMsg.AppendLine("Hi All");
                BodyMsg.AppendLine("<br><br>");
                if (Errorstate == false)
                {

                   // StringBuilder BodyMsg = new StringBuilder();
                    //BodyMsg.AppendLine("Hi All");
                    //BodyMsg.AppendLine("<br><br>");
                    BodyMsg.AppendLine("<br> <br> <Table  border=1> <tr bgcolor=blue>  <td> Path Type </td>  <td> FilePath </td> <td> BatchCount </td> <td>Batch Size </td>  </tr> ");
                    string FileSourceSize = Connection.Batches.Compute("Sum(sourceFileSize)", "").ToString();
                    string FileDestSize = Connection.Batches.Compute("Sum(destinationFileSize)", "").ToString();
                    if (String.IsNullOrEmpty(FileSourceSize)) FileSourceSize = "0";
                    if (String.IsNullOrEmpty(FileDestSize)) FileDestSize = "0";

                    BodyMsg.AppendLine("<tr><td> Source </td><td>" + Source + "</td><td>" + Convert.ToString(Connection.sourceFileCount) + "</td><td>" + FileSize(Convert.ToInt64(FileDestSize)) + "</td><tr>");
                    BodyMsg.AppendLine("<tr><td> Destination  </td><td>" + Dest + "</td><td>" + Convert.ToString(Connection.Batches.Rows.Count) + "</td><td>" + FileSize(Convert.ToInt64(FileSourceSize)) + "</td></tr>");
                    BodyMsg.AppendLine("</table> <br><br><b> Thanks  <br><br> **** This is Auto generated Mail **** </b><br><br>");

                }

                else

                {
                    BodyMsg.AppendLine(Connection.processlog);
                    BodyMsg.AppendLine("<br><br><b> Thanks  <br><br> **** This is Auto generated Mail **** </b><br><br>");
                }


                String Qury = "exec  AuditFilemovement_Mailsend  @Subject,@Body";
                Sqlcon = new SqlConnection("Data Source=SQL-Listner;Initial catalog=DBAEVENTS;User id=offlineAppuser;PWD=offline@app$2@16; multisubnetfailover=true");
                if (Sqlcon.State == ConnectionState.Closed)
                {
                    Sqlcon.Open();
                }
                Sqlcmd = new SqlCommand(Qury, Sqlcon);
                Sqlcmd.Parameters.AddWithValue("@Subject", SubjectText);
                Sqlcmd.Parameters.AddWithValue("@BODY", BodyMsg.ToString());
                Sqlcmd.ExecuteNonQuery();

                if(Errorstate==false)
                {
                    Environment.Exit(0);
                }
           
            }
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.LogFiles();
            }

        }
        public static String FileSize(double Filelength)
        {
            string[] suffixes = { "B", "KB", "MB", "GB" };
            int s = 0;
            while (Filelength >= 1024)
            {
                s++;
                Filelength /= 1024;
            }

            return Convert.ToString(Filelength.ToString("#.##")) + " " + suffixes[s];
        }
        public static void ProcessLogFiles(string Source, string Dest)
        {

            try
            {

                Connection.processlog = Connection.processlog + "calling the Logs insert Function ";
                Sqlcon = new SqlConnection(Connection.strSqlCon);

                if (Sqlcon.State == ConnectionState.Closed)
                {
                    Sqlcon.Open();
                }
                //ClientName varchar(100),@ProcessName varchar(30),@FiletakenPath varchar(300),@FilePlacedPath varchar(500),@Batchno BatchTrack readonly
                string strCmd = "FTP_MoveBatchlist";
                Sqlcmd = new SqlCommand(strCmd, Sqlcon);
                Sqlcmd.CommandType = CommandType.StoredProcedure;
                Sqlcmd.Parameters.Add("@ClientName", SqlDbType.VarChar, 100).Value = Client;
                Sqlcmd.Parameters.Add("@ProcessName", SqlDbType.VarChar, 50).Value = Process;
                Sqlcmd.Parameters.Add("@FiletakenPath", SqlDbType.VarChar, 50).Value = Source;
                Sqlcmd.Parameters.Add("@FilePlacedPath", SqlDbType.VarChar, 50).Value = Dest;
                SqlParameter Param = Sqlcmd.Parameters.AddWithValue("@Batchinfo", Batches);
                Param.SqlDbType = SqlDbType.Structured;

                Sqlcmd.ExecuteNonQuery();
                Sqlcmd.Cancel();
                Sqlcon.Close();
                Connection.processlog = Connection.processlog + "Logs insert Function End ";
            }
            catch (Exception ex)
            {
                // Program.logger.Error(ex, clientName);
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.LogFiles();
            }

        }
        //public void WisconsinConnection()
        //{
        //    try
        //    {
        //        string[] args = Environment.GetCommandLineArgs();

        //        if (args.Length > 1)
        //            CommendlineParam = args[1];
        //        //string fileName = @"\\10.1.0.1\athenaftp\FTP\ConnectionString\ConfigurationOffline.xml";

        //        string fileName = Application.StartupPath + "\\" + "Configuration.xml";

        //        FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
        //        xmldoc.Load(fs);
        //        fs.Close();
        //        xmlConnectionnode = xmldoc.GetElementsByTagName("WisconsinConnection");
        //        if (xmlConnectionnode.Count > 0)
        //        {

        //            ArchiveFtppath = xmlConnectionnode[0].ChildNodes.Item(9).InnerText.Trim();
        //            ZipFilePath = xmlConnectionnode[0].ChildNodes.Item(8).InnerText.Trim();
        //            uploadlocalpath = xmlConnectionnode[0].ChildNodes.Item(7).InnerText.Trim();
        //            uploadftppath = xmlConnectionnode[0].ChildNodes.Item(6).InnerText.Trim();
        //            DateFormat = xmlConnectionnode[0].ChildNodes.Item(5).InnerText.Trim();
        //            Dowloadlocalpath = xmlConnectionnode[0].ChildNodes.Item(4).InnerText.Trim();
        //            Dowloadftppath = xmlConnectionnode[0].ChildNodes.Item(3).InnerText.Trim();
        //            FTPIP = xmlConnectionnode[0].ChildNodes.Item(2).InnerText.Trim();
        //            xmlConPassword = xmlConnectionnode[0].ChildNodes.Item(1).InnerText.Trim();
        //            xmlUserId = xmlConnectionnode[0].ChildNodes.Item(0).InnerText.Trim();

        //            sftp ftpClient = new sftp(FTPIP, xmlUserId, xmlConPassword);

        //            string[] simpleDirectoryListing = ftpClient.directoryListSimple(Dowloadftppath);

        //             if (Dowloadlocalpath != "")
        //             {
        //                Directory.CreateDirectory(Dowloadlocalpath + DateTime.Now.ToString(DateFormat));
        //             Directory.CreateDirectory(ZipFilePath + DateTime.Now.ToString(DateFormat));

        //             Client = "Wisconsindwnld";
        //             for (int i = 0; i < simpleDirectoryListing.Count(); i++)
        //             {

        //                 if (Path.GetExtension(simpleDirectoryListing[i]) != ".zip")
        //                 {


        //                     string path = Dowloadlocalpath + DateTime.Now.ToString(DateFormat) + @"\" + simpleDirectoryListing[i];
        //                     string Filename = Dowloadftppath + @"\" + simpleDirectoryListing[i];
        //                     ftpClient.download(Filename, path);

        //                 }
        //                 else if (Path.GetExtension(simpleDirectoryListing[i]) == ".zip")
        //                 {

        //                     string path = ZipFilePath + DateTime.Now.ToString(DateFormat) + @"\" + simpleDirectoryListing[i];
        //                     string Filename = Dowloadftppath + @"\" + simpleDirectoryListing[i];
        //                     string filepath = (ZipFilePath + DateTime.Now.ToString(DateFormat));
        //                     ftpClient.download(Filename, path);
        //                     ftpClient.UnZip(path, filepath);
        //                 }

        //             }

        //            ftpClient.createDirectory(ArchiveFtppath + DateTime.Now.ToString(DateFormat));
        //            string[] localDirectoryListing = ftpClient.directoryListSimple(Dowloadftppath);
        //            for (int i = 0; i < localDirectoryListing.Count(); i++)
        //            {

        //                string path = ArchiveFtppath + DateTime.Now.ToString(DateFormat) + @"/" + localDirectoryListing[i];
        //                string Filename = Dowloadftppath + @"/" + localDirectoryListing[i];
        //                //File.Move(Filename, path);

        //                ftpClient.rename(Filename, path);

        //            }

        //            }
        //             if (Process == "Upload")
        //             {
        //                 Client = "Wisconsinupld";
        //                 string filename = uploadftppath + DateTime.Now.ToString(DateFormat);
        //                 ftpClient.createDirectory(filename);
        //                 string[] downloadDirectoryListing = Directory.GetFiles(uploadlocalpath);
        //                 for (int i = 0; i < downloadDirectoryListing.Count(); i++)
        //                 {

        //                     string path = uploadftppath + DateTime.Now.ToString(DateFormat) + @"/" + Path.GetFileName(downloadDirectoryListing[i]);
        //                     string Filename = downloadDirectoryListing[i];
        //                     ftpClient.upload(path, Filename);

        //                 }
        //             }





        //            //string zipPath = @"c:\example\result.zip";
        //            //string extractPath = @"c:\example\extract";


        //        }





        //    }
        //    catch (Exception Ex)
        //    {
        //    }
        //}


        //public void SQLConn()
        //{

        //    try
        //    {

        //        Connection.processlog = Connection.processlog + "Get the SQlConnection from XML";
        //        string[] args = Environment.GetCommandLineArgs();

        //        if (args.Length > 1)
        //            CommendlineParam = args[1];
        //        //string fileName = @"\\10.1.0.1\athenaftp\FTP\ConnectionString\ConfigurationOffline.xml";

        //       string fileName ;//= Application.StartupPath + "\\" + "Configuration.xml";



        //        FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
        //        SQldoc.Load(fs);
        //        fs.Close();

        //        xmlSqlConnectionnode = SQldoc.GetElementsByTagName("SQLConnection");
        //        if (xmlSqlConnectionnode.Count > 0)
        //        {
        //            SqlServer = xmlSqlConnectionnode[0].ChildNodes.Item(3).InnerText.Trim();
        //            SqlDB = xmlSqlConnectionnode[0].ChildNodes.Item(2).InnerText.Trim();
        //            SqlPwd = xmlSqlConnectionnode[0].ChildNodes.Item(1).InnerText.Trim();
        //            SqlUesrid = xmlSqlConnectionnode[0].ChildNodes.Item(0).InnerText.Trim();
        //            strSqlCon = "Password=" + SqlPwd + ";Persist Security Info=True;User ID=" + SqlUesrid + ";Initial Catalog=" + SqlDB + ";Data Source=" + SqlServer + "; pooling=false; connection lifetime=121";
        //        }
        //    }

        //    catch (Exception ex)

        //    {
        //        Connection.processlog = Connection.processlog + ex.Message;
        //        Connection.LogFiles();
        //    }
        //   // XMLNodeClear();
        //}


        //public void SFTPCon()
        //{
        //    try
        //    {
        //        string[] args = Environment.GetCommandLineArgs();

        //        if (args.Length > 1)
        //            CommendlineParam = args[1];
        //        //string fileName = @"\\10.1.0.1\athenaftp\FTP\ConnectionString\ConfigurationOffline.xml";

        //        string fileName = Application.StartupPath + "\\" + "Configuration.xml";

        //        FtpClientParameters param = new FtpClientParameters();
        //        //param = @"C:\Users\leela.thangavel\Desktop\PDF";
        //        //param.Year = "No";
        //        //param.Month = "1";
        //        //param.FolderDate = "0";
        //        //param.Folderformat = "ddMMyyyy";
        //        //param.FolderName = "Batch";

        //        //RuleSetManager rules = new RuleSetManager();
        //        //rules.LoadRuleSet("FTPPath");
        //        //rules.ExecuteRuleSet(param);

        //        //string path = param.DirectoryPath;

        //        //Directory.CreateDirectory(param.DirectoryPath);
        //        FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
        //        xmldoc.Load(fs);
        //        fs.Close();
        //        xmlConnectionnode = xmldoc.GetElementsByTagName(Connection.ClientName + "Connection");
        //        if (xmlConnectionnode.Count > 0)
        //        {
        //            PortId = Convert.ToInt16(xmlConnectionnode[0].ChildNodes.Item(9).InnerText.Trim());
        //            ArchiveFtppath = xmlConnectionnode[0].ChildNodes.Item(8).InnerText.Trim();
        //            uploadlocalpath = xmlConnectionnode[0].ChildNodes.Item(7).InnerText.Trim();
        //            uploadftppath = xmlConnectionnode[0].ChildNodes.Item(6).InnerText.Trim();
        //            DateFormat = xmlConnectionnode[0].ChildNodes.Item(5).InnerText.Trim();
        //            Dowloadlocalpath = xmlConnectionnode[0].ChildNodes.Item(4).InnerText.Trim();
        //            Dowloadftppath = xmlConnectionnode[0].ChildNodes.Item(3).InnerText.Trim();
        //            FTPIP = xmlConnectionnode[0].ChildNodes.Item(2).InnerText.Trim();
        //            xmlConPassword = xmlConnectionnode[0].ChildNodes.Item(1).InnerText.Trim();
        //            xmlUserId = xmlConnectionnode[0].ChildNodes.Item(0).InnerText.Trim();
        //            SFTPConnection ftpClient = new SFTPConnection(FTPIP, PortId, xmlUserId, xmlConPassword);

        //            if (Process == "Download")
        //            {
        //                processlog = ClientName + " download has started on  " + DateTime.Now.ToString();
        //                if (Directory.Exists(param.DirectoryPath) == false)
        //                    Directory.CreateDirectory(param.DirectoryPath);

        //                ftpClient.DownloadFile(Dowloadftppath, Dowloadlocalpath + DateTime.Now.ToString(DateFormat));
        //                processlog = ClientName + " download has Completed on  " + DateTime.Now.ToString();
        //            }

        //            if (Process == "Upload")
        //            {

        //                processlog = ClientName + " upload has started on  " + DateTime.Now.ToString();
        //                ftpClient.UploadFile(uploadftppath, uploadlocalpath, DateFormat);
        //                processlog = ClientName + " upload has Completed on  " + DateTime.Now.ToString();
        //            }
        //            if (Process == "Archive")
        //            {
        //                processlog = ClientName + " Archive has started on  " + DateTime.Now.ToString();
        //                ftpClient.MoveFolderToArchive(Dowloadftppath, ArchiveFtppath + DateTime.Now.ToString(DateFormat) + @"/");
        //                processlog = ClientName + " Archive has Completed on  " + DateTime.Now.ToString();
        //            }


        //            //   XMLNodeClear();


        //        }





        //    }
        //    catch (Exception Ex)
        //    {
        //        processlog = ClientName + Process + " Prrocess Error is  " + Ex.Message + " on " + DateTime.Now.ToString();
        //        Environment.Exit(0);
        //    }
        //}

        public void XMLNodeClear()
        {
            XmlNode root = xmldoc.DocumentElement;
            root.RemoveAll();
            foreach (XmlNode node in xmlConnectionnode)
            {
                node.ParentNode.ParentNode.RemoveChild(node.ParentNode);
            }
           
        }

        //public void  Deserializer()
        //{
           
        //    try
        //    {

        //        string somestring = " <MidwestConnection>   <UserId> AHS </UserId> " +
        //         "<Pwd> G9eBriet </Pwd>"+
        //        "<FTPIP> 162.247.247.75 </FTPIP>"+
        //       "<downloadSourcePath>/ FOR_AHS / Archive / 05152017 </downloadSourcePath >" +
        //      "<downloaddestinationPath>"+ @"C:\Users\leela.thangavel\Desktop\PDF\</downloaddestinationPath>" + 
        //         "<Port>22</Port>"+         
        //    "</MidwestConnection> ";
        //        var xmlSerializer = new XmlSerializer(typeof(MidwestConnection));
        //        MidwestConnection reslt;
        //        using (TextReader stringreader = new StringReader(somestring))
        //        {
        //            reslt = (MidwestConnection)xmlSerializer.Deserialize(stringreader);
        //        }

        //        string Password = reslt.Pwd;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        
        //}

        //public void Paramters()
        //{
        //    SqlConnection conn = new SqlConnection("Data Source = 172.19.5.23; Initial catalog = ARC_ATHENA; User id=UATLOGIN; PWD=Uadfw#qweLJu83@loinfd3@#$");

        //    SqlCommand cmd = new SqlCommand();
        //    System.Xml.XmlReader xmlreader;
        //    XmlDataDocument xmlDataDoc = new XmlDataDocument();
        //    try
        //    {
        //        cmd.Connection = conn;
        //        conn.Open();
        //        cmd.CommandText = "select * from FTP_XmlDetails where ClineNmae='Midwest' and Status=1";
        //        xmlreader = cmd.ExecuteXmlReader();
        //        DataSet ds = new DataSet();
        //        //DataTable dt = new DataTable();
        //        //dt.Columns.Add("AcademicYearId", typeof(string));
        //        //dt.Columns.Add("AcademicYearName", typeof(string));
        //        //dt.Columns.Add("StartingYear", typeof(string));
        //        //dt.Columns.Add("EndingYear", typeof(string));
        //        //dt.Columns.Add("Comments", typeof(string));
        //        //dt.Columns.Add("RCO", typeof(string));
        //        //dt.Columns.Add("UserID", typeof(string));

        //        //ds.Tables.Add(dt);
        //        while (xmlreader.Read())
        //        {
        //            xmlDataDoc.DataSet.ReadXml(xmlreader);
        //        }
        //        ds = xmlDataDoc.DataSet;
        //        xmlreader.Close();
        //        conn.Close();
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}
    }

    
}
