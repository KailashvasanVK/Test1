﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace FTPParameters
{
    public class FTPParameters
    {
        public static string host;
        public static string user;
        public static string pass;
         public static int port;
        public static string dateformat,foldermonth,folderyear;
        public static string dowloadsourcepath, dowloaddestpath;
        public static string uploadsourcepath, uploaddestpath;
        public static string zipfilepath, archiveftppath;

        public string FolderDate { get; set; }

        public string Slash { get; set; }

        public string Server { get; set; }
        public string Useid { get; set; }
        public string Password { get; set; }

        public int Portnumber { get; set; }

        public string Folderformat { get; set; }

        public string FolderName { get; set; }

        public string Month { get; set; }

        public string Year { get; set; }

        public string DownloadSource { get; set; }
        public string dwnlddestination { get; set; }

        public string upldsource { get; set; }

        public string uplddestination { get; set; }
        public string archivepath { get; set; }

        public string zippath { get; set; }

        public string Process { get; set; }

        public string DirectoryPath { get; set; }
        
        public void GetDirectoryPath()
        {
            string path;
            if (Process == "Download")
                Slash = @"\";
            else
                Slash = @"/";
            path = DownloadSource;
            if (Year != "No")
                path = path + Slash + DateTime.Now.ToString("yyyy");
            if(Month!="No")
                path=path + Slash + DateTime.Now.ToString("MMM");
            if(FolderDate!="No")
                path = path + Slash + DateTime.Now.AddDays(Convert.ToInt16(FolderDate)).ToString(dateformat);
            if (FolderName != "No")
                path = path + Slash + FolderName;

            //return path;
          //Directory.CreateDirectory(path);

        }
    }
}
