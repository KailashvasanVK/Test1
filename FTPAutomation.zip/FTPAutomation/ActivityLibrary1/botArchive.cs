﻿using System;
using System.Linq;
using System.Text;
using System.Activities;
using System.Data;
using ActivityKibrary1;
using Renci.SshNet;
using System.Data.SqlClient;
using System.IO;
using System.Xml.Serialization;
using FTPParameters;
using ICSharpCode.SharpZipLib.Zip;
using ICSharpCode.SharpZipLib.Core;

namespace ServerConnection
{
    //private int FileTakenCount;
    //private string process;
    //public static string clientName;
    //private bool ErrorState;
    //DataTable Batches = new DataTable();
    //;
    public sealed class botArchive : CodeActivity
    {
        private string process;
        private string clientName;
     

        RuleSetParameters rulesParameters = new RuleSetParameters();
       


        // Define an activity input argument of type string
        public InArgument<Boolean> XMLtype { get; set; }
        public InArgument<string> SourcePath { get; set; }
        public InArgument<string> DestinationPath { get; set; }
        public InArgument<string> PortNumber { get; set; }
        public InArgument<string> ServerName { get; set; }
        public InArgument<string> UserName { get; set; }
        public InArgument<string> Password { get; set; }
        public InArgument<string> DateFormat { get; set; }
        public InArgument<string> FolderName { get; set; }
        public InArgument<string> FolderDate { get; set; }
        public InArgument<string> Process { get; set; }

        public InArgument<string> ClientName { get; set; }
        public InArgument<string> RuleSetName { get; set; }
        public InArgument<string> ZipFolder { get; set; }
        public InArgument<string> FileExtension { get; set; }

        public InArgument<bool> ExtractZip { get; set; }
        //public int FileTakenCount { get; private set; }
        //public string clientName { get; private set; }

        // If your activity returns a value, derive from CodeActivity<TResult>
        // and return the value from the Execute method.
        protected override void Execute(CodeActivityContext context)
        {
            FtpClientParameters parameters = new FtpClientParameters();
            Connection.Batches.Columns.Add("BatchNo", typeof(string));
            Connection.Batches.Columns.Add("FiletakenPathSize", typeof(Int64));
            Connection.Batches.Columns.Add("FilePlacedPath", typeof(Int64));


            if (context.GetValue(this.XMLtype) == false)
            {

                // Obtain the runtime value of the Text input argument
                parameters.DownloadSource = context.GetValue(this.SourcePath);
                parameters.DownloadDestination = context.GetValue(this.DestinationPath);
                parameters.FolderDate = context.GetValue(this.FolderDate);
                parameters.FolderName = context.GetValue(this.FolderName);
                parameters.DateFormat = context.GetValue(this.DateFormat);
                parameters.ServerName = context.GetValue(this.ServerName);
                parameters.Port = context.GetValue(this.PortNumber);
                parameters.UserId = context.GetValue(this.UserName);
                parameters.Password = context.GetValue(this.Password);
                parameters.RuleSetName = context.GetValue(this.RuleSetName);
                parameters.ClientName = context.GetValue(this.ClientName);
                parameters.Process = context.GetValue(this.Process);
                parameters.ZipFolder = context.GetValue(this.ZipFolder);
                parameters.FileExtension = context.GetValue(this.FileExtension);
                parameters.ExtractZip = context.GetValue(this.ExtractZip);

            }

            else
            {
                clientName = Connection.ClientName;
                parameters = DeSerialize(clientName);
                context.SetValue(Process, parameters.Process);
                context.SetValue(SourcePath, parameters.DownloadSource);
                context.SetValue(DestinationPath, parameters.DownloadDestination);
                context.SetValue(FolderDate, parameters.FolderDate);
                context.SetValue(FolderName, parameters.FolderName);
                context.SetValue(DateFormat, parameters.DateFormat);
                context.SetValue(ServerName, parameters.ServerName);
                context.SetValue(UserName, parameters.UserId);
                context.SetValue(Password, parameters.Password);
                context.SetValue(RuleSetName, parameters.RuleSetName);
                context.SetValue(ClientName, parameters.ClientName);
                context.SetValue(ZipFolder, parameters.ZipFolder);
                context.SetValue(FileExtension, parameters.FileExtension);
                context.SetValue(ExtractZip, parameters.ExtractZip);



            }
            Archive(parameters);

        }


        private void Archive(FtpClientParameters parameters)
        {
            try

            {




                rulesParameters.ClientParameters = parameters;
                clientName = parameters.ClientName;
                process = parameters.Process;
                ApplyRule(rulesParameters);



                Connection.sourceFileCount = 0;
                RowsClear();


                if (Directory.Exists(rulesParameters.DownloadSource) == true)
                {
                    ArchiveDirectory(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                }
                else if (rulesParameters.DownloadSourceNext != null)
                {
                    if (Directory.Exists(rulesParameters.DownloadSourceNext) == true)
                    {
                        ArchiveDirectory(rulesParameters.DownloadSourceNext, rulesParameters.DownloadDestination);
                    }
                }

                DeleteDirectory(rulesParameters.DownloadSource);
                Connection.ProcessLogFiles(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);

            }
            catch (Exception ex)
            {
                //  Program.logger.Error(ex, clientName);
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = false;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();


            }
            //TODO: Download files
        }

        private FtpClientParameters DeSerialize(string clientName)
        {
            try
            {
                Connection.processlog = Connection.processlog + "call the DeSerialize Function";
                Connection.processlog = Connection.processlog + AppDomain.CurrentDomain.BaseDirectory + @"\Xml\" + clientName + @".xml";
                XmlSerializer deserializer = new XmlSerializer(typeof(FtpClientParameters));
                TextReader reader = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + @"\Xml\" + clientName + @".xml");
                object obj = deserializer.Deserialize(reader);
                FtpClientParameters XmlData = (FtpClientParameters)obj;
                reader.Close();
                return XmlData;
            }
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = false;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();
                return null;
            }


        }
        private void ArchiveDirectory(string source, string destination)
        {

            try
            {
                // Connection.processlog = Connection.processlog + "dwonload the all files";
                //if (clientName == "NewPort")
                //{
                //    DeleteDirectory(destination);
                //}
              
                    if (rulesParameters.FolderModified == true)
                {
                    DateTime yesterday = DateTime.Now.AddDays(-1).Date;
                    DateTime Today = DateTime.Now.AddDays(0).Date;

                    FileInfo[] files = new DirectoryInfo(source)
                            .EnumerateFiles()
                            .Select(x => {
                                x.Refresh();
                                return x;
                            }).Where(x => (x.LastWriteTime.Date == yesterday && Convert.ToDateTime(x.LastWriteTime.ToShortTimeString()) > Convert.ToDateTime("06:00 AM")) || (x.LastWriteTime.Date == Today && Convert.ToDateTime(x.LastWriteTime.ToShortTimeString()) <= Convert.ToDateTime("06:00 AM")))
                                   .ToArray()
                                   ;
                    foreach (FileInfo file in files)
                    {
                        if (Directory.Exists(file.FullName)==false)
                        {

                            if (Path.GetExtension(file.FullName) == rulesParameters.FileExtension && rulesParameters.FileExtension != "")
                            {

                                if (File.Exists(Path.Combine(destination, file.Name)) == false)
                                {
                                    Connection.sourceFileCount++;

                                    File.Copy(file.FullName, Path.Combine(destination, file.Name));
                        

                                        FileInfo ff = new FileInfo(Path.Combine(destination, file.Name));
                                        Connection.Batches.Rows.Add(file.Name, FileSize(file.FullName.Length), FileSize(ff.Length));
                                    
                                }
                            }

                            else
                            {
                                if (File.Exists(Path.Combine(destination, file.Name)) == false)
                                {
                                    Connection.sourceFileCount++;
                                    using (Stream fileStream = File.OpenWrite(Path.Combine(destination, file.Name)))
                                    {

                                        File.Copy(file.FullName, Path.Combine(destination, file.Name));

                                        FileInfo ff = new FileInfo(Path.Combine(destination, file.Name));
                                        Connection.Batches.Rows.Add(file.Name, FileSize(file.FullName.Length), FileSize(ff.Length));
                                    }
                                }


                            }
                        }

                        else 
                        {
                            if (!Directory.Exists(Path.Combine(destination, file.Name)))
                            {
                                var dir = Directory.CreateDirectory(Path.Combine(destination, file.Name));
                                ArchiveDirectory(file.FullName, dir.FullName);
                            }
                        }

                    }

                        
                }
         
                else
                {
                    //Directory.Move(source, destination);
                  

                    DirectoryInfo dir = new DirectoryInfo(source);
                    var Files = dir.GetFiles();
                      foreach (FileInfo file in Files)
                {
                    if (!Directory.Exists(file.FullName))
                    {
                        
                            if (Path.GetExtension(file.FullName)== rulesParameters.FileExtension && rulesParameters.FileExtension != "")
                            {

                                if (File.Exists(Path.Combine(destination, Path.GetFileName(file.FullName))) == false && Path.GetFileName(file.FullName) != "thumbs.db")
                                {
                                    Connection.sourceFileCount++;
                                    File.Move(file.FullName, Path.Combine(destination, Path.GetFileName(file.FullName)));
                                    FileInfo ff = new FileInfo(Path.Combine(destination, Path.GetFileName(file.FullName)));
                                    Connection.Batches.Rows.Add(file.Name, FileSize(file.FullName.Length), FileSize(ff.Length));
                                }
                                }
                            

                            else
                            {

                            if (File.Exists(Path.Combine(destination, Path.GetFileName(file.FullName))) == false && Path.GetFileName(file.FullName)!="thumbs.db")
                            {
                                    Connection.sourceFileCount++;


                                    File.Move(file.FullName, Path.Combine(destination, Path.GetFileName(file.FullName)));
                                    FileInfo ff = new FileInfo(Path.Combine(destination, Path.GetFileName(file.FullName)));
                                    Connection.Batches.Rows.Add(file.Name, FileSize(file.FullName.Length), FileSize(ff.Length));
                                }
                        }

                    }
                        

                    else 
                    {
                        if (!Directory.Exists(Path.Combine(destination, Path.GetFileName(file.FullName))))
                        {
                            var dr = Directory.CreateDirectory(Path.Combine(destination,Path.GetFileName(file.FullName)));
                                ArchiveDirectory(Path.GetFileName(file.FullName), dr.FullName);
                                
                        }
                    }
                }

                    foreach (string Sourcedir in Directory.GetDirectories(source))
                    {

                        if (!Directory.Exists((Path.Combine(destination, Path.GetFileName(Sourcedir)))))
                        { 
                            var Destinationdir = Directory.CreateDirectory(Path.Combine(destination, (Path.Combine(destination, Path.GetFileName(Sourcedir)))));
                            ArchiveDirectory(Sourcedir, Destinationdir.FullName);
                        }

                    }
                }


                if (rulesParameters.ExtractZip == true)
            {
                RowsClear();
                ExtractZipFile(destination, rulesParameters.zipFolder);
            }
        } 
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = false;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();
            }
        }

        private void DeleteDirectory(string diretoryName)
        {

            foreach (string Sourcedir in Directory.GetDirectories(diretoryName))
            {
                Directory.Delete(Sourcedir,true);
            }
        }
        public void ExtractZipFile(string archiveFilenameIn, string outFolder)
        {
            ZipFile zf = null;
            try



            {

                // Program.logger.Info("Zip File Extract started");

                Connection.sourceFileCount = 0;
                var zipFiles = Directory.GetFiles(archiveFilenameIn);

                foreach (var FileName in zipFiles)
                {
                    if (Path.GetExtension(FileName) == ".zip")
                    {
                        FileStream fs = File.OpenRead(FileName);
                        zf = new ZipFile(fs);

                        foreach (ZipEntry zipEntry in zf)
                        {
                            if (!zipEntry.IsFile) continue; // Ignore directories

                            String entryFileName = zipEntry.Name;
                            //to remove the folder from the entry:
                            entryFileName = Path.GetFileName(entryFileName);


                            byte[] buffer = new byte[4096];     // 4K is optimum
                            Stream zipStream = zf.GetInputStream(zipEntry);
                            // Manipulate the output filename here as desired.
                            String fullZipToPath = Path.Combine(outFolder, entryFileName);
                            string directoryName = Path.GetDirectoryName(fullZipToPath);
                            if (directoryName.Length > 0)
                                Directory.CreateDirectory(directoryName);

                            using (FileStream streamWriter = File.Create(fullZipToPath))
                            {
                                Connection.sourceFileCount = Connection.sourceFileCount + 1;
                                StreamUtils.Copy(zipStream, streamWriter, buffer);
                               Connection.Batches.Rows.Add(entryFileName, FileSize(streamWriter.Length), FileSize(streamWriter.Length));
                            }
                        }
                    }
                }


            }

            catch (Exception ex)
            {

                //  Program.logger.Error(ex,"UnZip Error",clientName);
            }
            finally
            {
                if (zf != null)
                {
                    zf.IsStreamOwner = true;
                    zf.Close();
                }
            }
        }

     
        private void RowsClear()
        {
            if (Connection.Batches.Rows.Count > 0)
            {
                Connection.Batches.Rows.Clear();
            }
        }

        private long FileSize(long Filelength)
        {
            string[] suffixes = { "B", "KB", "MB" };
            int s = 0;
            while (Filelength >= 1024)
            {
                s++;
                Filelength /= 1024;
            }

            return Filelength;
        }


       


        private RuleSetParameters ApplyRule(RuleSetParameters parameters)
        {
            try
            {
                
                RuleSetManager rsm = new RuleSetManager();
                rsm.LoadRuleSet(parameters.ClientParameters.RuleSetName);
                rsm.ExecuteRuleSet(parameters);
                return parameters;
            }
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = false;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();
                return null;
            }

        }
    }
}
