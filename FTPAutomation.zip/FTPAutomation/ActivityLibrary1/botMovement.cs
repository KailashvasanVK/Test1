﻿using System;
using System.Linq;
using System.Text;
using System.Activities;
using System.Data;
using ActivityKibrary1;
using Renci.SshNet;
using System.Data.SqlClient;
using System.IO;
using System.Xml.Serialization;
using FTPParameters;
using ICSharpCode.SharpZipLib.Zip;
using ICSharpCode.SharpZipLib.Core;
using System.Text.RegularExpressions;

namespace ServerConnection
{
    //private int FileTakenCount;
    //private string process;
    //public static string clientName;
    //private bool ErrorState;
    //DataTable Batches = new DataTable();
    //;
    public sealed class botMovement : CodeActivity
    {
        private string process;
        private int FileTakenCount;
        private string clientName;
        private SqlConnection Sqlcon;
        private SqlCommand Sqlcmd;
        private SqlDataReader SqlRead;

        RuleSetParameters rulesParameters = new RuleSetParameters();
        DataTable Batches = new DataTable();


        // Define an activity input argument of type string
        public InArgument<Boolean> XMLtype { get; set; }
        public InArgument<string> SourcePath { get; set; }
        public InArgument<string> DestinationPath { get; set; }
        public InArgument<string> PortNumber { get; set; }
        public InArgument<string> ServerName { get; set; }
        public InArgument<string> UserName { get; set; }
        public InArgument<string> Password { get; set; }
        public InArgument<string> DateFormat { get; set; }
        public InArgument<string> FolderName { get; set; }
        public InArgument<string> FolderDate { get; set; }
        public InArgument<string> Process { get; set; }

        public InArgument<string> ClientName { get; set; }
        public InArgument<string> RuleSetName { get; set; }
        public InArgument<string> ZipFolder { get; set; }
        public InArgument<string> FileExtension { get; set; }
        public InArgument<string> FileSize { get; set; }

        public InArgument<bool> ExtractZip { get; set; }
        //public int FileTakenCount { get; private set; }
        //public string clientName { get; private set; }

        // If your activity returns a value, derive from CodeActivity<TResult>
        // and return the value from the Execute method.
        protected override void Execute(CodeActivityContext context)
        {
            FtpClientParameters parameters = new FtpClientParameters();


            Connection.Batches.Columns.Add("BatchNo", typeof(string));
            Connection.Batches.Columns.Add("sourceFileSize", typeof(Int64));
            Connection.Batches.Columns.Add("destinationFileSize", typeof(Int64));

            if (context.GetValue(this.XMLtype) == false)
            {

                // Obtain the runtime value of the Text input argument
                parameters.DownloadSource = context.GetValue(this.SourcePath);
                parameters.DownloadDestination = context.GetValue(this.DestinationPath);
                parameters.FolderDate = context.GetValue(this.FolderDate);
                parameters.FolderName = context.GetValue(this.FolderName);
                parameters.DateFormat = context.GetValue(this.DateFormat);
                parameters.ServerName = context.GetValue(this.ServerName);
                parameters.Port = context.GetValue(this.PortNumber);
                parameters.UserId = context.GetValue(this.UserName);
                parameters.Password = context.GetValue(this.Password);
                parameters.RuleSetName = context.GetValue(this.RuleSetName);
                parameters.ClientName = context.GetValue(this.ClientName);
                parameters.Process = context.GetValue(this.Process);
                parameters.ZipFolder = context.GetValue(this.ZipFolder);
                parameters.FileExtension = context.GetValue(this.FileExtension);
                parameters.ExtractZip = context.GetValue(this.ExtractZip);
                parameters.FileSize = context.GetValue(this.FileSize);

            }

            else
            {
                clientName = Connection.ClientName;
                parameters = DeSerialize(clientName);
                context.SetValue(Process, parameters.Process);
                context.SetValue(SourcePath, parameters.DownloadSource);
                context.SetValue(DestinationPath, parameters.DownloadDestination);
                context.SetValue(FolderDate, parameters.FolderDate);
                context.SetValue(FolderName, parameters.FolderName);
                context.SetValue(DateFormat, parameters.DateFormat);
                context.SetValue(ServerName, parameters.ServerName);
                context.SetValue(UserName, parameters.UserId);
                context.SetValue(Password, parameters.Password);
                context.SetValue(RuleSetName, parameters.RuleSetName);
                context.SetValue(ClientName, parameters.ClientName);
                context.SetValue(ZipFolder, parameters.ZipFolder);
                context.SetValue(FileExtension, parameters.FileExtension);
                context.SetValue(ExtractZip, parameters.ExtractZip);
                context.SetValue(FileSize, parameters.FileSize);



            }
            Download(parameters);

        }


        private void Download(FtpClientParameters parameters)
        {
            try

            {




                rulesParameters.ClientParameters = parameters;
                clientName = parameters.ClientName;
                process = parameters.Process;
                ApplyRule(rulesParameters);


                Connection.Client = clientName;
                Connection.Process = process;
                Connection.sourceFileCount = 0;
                RowsClear();
                Connection.processlog = "Download is started on " + DateTime.Now.ToString();

                if (Directory.Exists(rulesParameters.DownloadSource) == true)
                {
                    DownloadDirectory(rulesParameters.DownloadSource, rulesParameters.DownloadDestination,rulesParameters.FileSize);
                    
                }
              

                Connection.processlog = "Download  has completed on " + DateTime.Now.ToString();

                Connection.ProcessLogFiles(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);

            }
            catch (Exception ex)
            {
                //  Program.logger.Error(ex, clientName);
                Connection.processlog = Connection.processlog + ex.Message + " on " + DateTime.Now.ToString();
                Connection.Errorstate = true;
                Connection.Mail("", "");
                Connection.LogFiles();


            }
            //TODO: Download files
        }

        private FtpClientParameters DeSerialize(string clientName)
        {
            try
            {
                Connection.processlog = Connection.processlog + "call the DeSerialize Function";
                Connection.processlog = Connection.processlog + AppDomain.CurrentDomain.BaseDirectory + @"\Xml\" + clientName + @".xml";
                XmlSerializer deserializer = new XmlSerializer(typeof(FtpClientParameters));
                TextReader reader = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + @"\Xml\" + clientName + @".xml");
                object obj = deserializer.Deserialize(reader);
                FtpClientParameters XmlData = (FtpClientParameters)obj;
                reader.Close();
                return XmlData;
            }
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message + " on " + DateTime.Now.ToString();
                Connection.Errorstate = true;
                Connection.Mail("", "");
                Connection.LogFiles();

                return null;
            }


        }
        private void DownloadDirectory(string source, string destination,string filesize)
        {

            try
            {
                //var fixedSize = Regex.Matches(filesize, @"\D+|\d+")
                // .Cast<Match>()
                // .Select(m => m.Value)
                // .ToArray();
                var fixedSize = filesize.Remove(filesize.Length - 2, 2);
                var filetype = filesize.Remove(0, filesize.Length-2);
                DirectoryInfo dir = new DirectoryInfo(source);
                    var Files = dir.GetFiles();
                foreach (FileInfo file in Files)
                {
                    if (!Directory.Exists(file.FullName))
                    {


                        if (File.Exists(Path.Combine(destination, Path.GetFileName(file.FullName))) == false && Path.GetFileName(file.FullName) != "thumbs.db" && Path.GetFileName(file.FullName) != "Thumbs.db")
                        {
                            String Size = Connection.FileSize(file.Length);

                            var currentFileSize = Size.Remove(Size.Length - 2, 2);
                            var currentFiletype = Size.Remove(0, Size.Length - 2);


                            if (Convert.ToDouble(fixedSize) <= Convert.ToDouble(currentFileSize) && filetype == currentFiletype)
                            {
                                Connection.sourceFileCount++;
                                File.Copy(file.FullName, Path.Combine(destination, Path.GetFileName(file.FullName)));
                                FileInfo ff = new FileInfo(Path.Combine(destination, Path.GetFileName(file.FullName)));
                                Connection.Batches.Rows.Add(Path.GetFileName(file.FullName), file.Length, ff.Length);
                                File.Delete(file.FullName);
                            }

                        }
                    }


                    else
                    {
                        if (!Directory.Exists(Path.Combine(destination, Path.GetFileName(file.FullName))))
                        {
                            var dr = Directory.CreateDirectory(Path.Combine(destination, Path.GetFileName(file.FullName)));
                            DownloadDirectory(Path.GetFileName(file.FullName), dr.FullName, filesize);
                        }
                    }
                }

                    foreach (DirectoryInfo Sourcedir in dir.GetDirectories())
                    {

                        string str = Path.Combine(destination, Sourcedir.Name);
                        var Destinationdir = Directory.CreateDirectory(Path.Combine(destination, Sourcedir.Name));
                        DownloadDirectory(Sourcedir.FullName, Destinationdir.FullName, filesize);
                    }


     


        } 
            catch (Exception ex)
            {

                Connection.processlog = Connection.processlog + ex.Message + " on " + DateTime.Now.ToString();
                Connection.Errorstate = true;
                Connection.Mail("", "");
                Connection.LogFiles();

            }
        }


        public void ExtractZipFile(string archiveFilenameIn, string outFolder)
        {
            ZipFile zf = null;
            try



            {

                // Program.logger.Info("Zip File Extract started");

                FileTakenCount = 0;
                var zipFiles = Directory.GetFiles(archiveFilenameIn);

                foreach (var FileName in zipFiles)
                {
                    if (Path.GetExtension(FileName) == ".zip")
                    {
                        FileStream fs = File.OpenRead(FileName);
                        zf = new ZipFile(fs);

                        foreach (ZipEntry zipEntry in zf)
                        {
                            if (!zipEntry.IsFile) continue; // Ignore directories

                            String entryFileName = zipEntry.Name;
                            //to remove the folder from the entry:
                            entryFileName = Path.GetFileName(entryFileName);


                            byte[] buffer = new byte[4096];     // 4K is optimum
                            Stream zipStream = zf.GetInputStream(zipEntry);
                            // Manipulate the output filename here as desired.
                            String fullZipToPath = Path.Combine(outFolder, entryFileName);
                            string directoryName = Path.GetDirectoryName(fullZipToPath);
                            if (directoryName.Length > 0)
                                Directory.CreateDirectory(directoryName);

                            using (FileStream streamWriter = File.Create(fullZipToPath))
                            {
                                FileTakenCount = FileTakenCount + 1;
                                StreamUtils.Copy(zipStream, streamWriter, buffer);
                                Connection.Batches.Rows.Add(entryFileName, streamWriter.Length, streamWriter.Length);
                            }
                        }
                    }
                }


            }

            catch (Exception ex)
            {

                Connection.processlog = Connection.processlog + ex.Message + " on " + DateTime.Now.ToString();
                Connection.Errorstate = true;
                Connection.Mail("", "");
                Connection.LogFiles();

            }
            finally
            {
                if (zf != null)
                {
                    zf.IsStreamOwner = true;
                    zf.Close();
                }
            }
        }

       
        private void RowsClear()
        {
            if (Connection.Batches.Rows.Count > 0)
            {
                Connection.Batches.Rows.Clear();
            }
        }

     
       


        private RuleSetParameters ApplyRule(RuleSetParameters parameters)
        {
            try
            {
                
                RuleSetManager rsm = new RuleSetManager();
                rsm.LoadRuleSet(parameters.ClientParameters.RuleSetName);
                rsm.ExecuteRuleSet(parameters);
                return parameters;
            }
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message + " on " + DateTime.Now.ToString();
                Connection.Errorstate = true;
                Connection.Mail("", "");
                Connection.LogFiles();

                return null;
            }

        }
    }
}
