﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Activities;

namespace ServerConnection
{

    public sealed class botSFTPConnect : CodeActivity
    {
        // Define an activity input argument of type string
        public InArgument<Boolean> XMLtype { get; set; }
        public InArgument<string> ServerName { get; set; }
        public InArgument<string> UserName { get; set; }
        public InArgument<string> Password { get; set; }
        public InArgument<string> PortNumber { get; set; }


        // If your activity returns a value, derive from CodeActivity<TResult>
        // and return the value from the Execute method.
        protected override void Execute(CodeActivityContext context)
        {
           
            // Obtain the runtime value of the Text input argument
            FtpClientParameters parameters = new FtpClientParameters();
            if (context.GetValue(this.XMLtype) == false)
            {
      
                parameters.UserId = context.GetValue(this.UserName);
                parameters.Password = context.GetValue(this.Password);
                parameters.Port = context.GetValue(this.PortNumber);
                parameters.ServerName = context.GetValue(this.ServerName);
            }
            else
            {
               // clientName = Connection.ClientName;
                //parameters = DeSerialize(clientName);
                context.SetValue(ServerName, parameters.ServerName);
                context.SetValue(UserName, parameters.UserId);
                context.SetValue(Password, parameters.Password);
                context.SetValue(PortNumber, parameters.Port);
            }



        }
    }
}
