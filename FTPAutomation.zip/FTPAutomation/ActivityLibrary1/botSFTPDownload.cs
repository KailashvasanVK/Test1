﻿using System;
using System.Linq;
using System.Text;
using System.Activities;
using System.Data;
using ActivityKibrary1;
using Renci.SshNet;
using System.Data.SqlClient;
using System.IO;
using System.Xml.Serialization;
using FTPParameters;
using ICSharpCode.SharpZipLib.Zip;
using ICSharpCode.SharpZipLib.Core;
using System.Collections.Generic;
using System.Diagnostics;
using AutoIt;

namespace ServerConnection
{
    //private int FileTakenCount;
    //private string process;
    //public static string clientName;
    //private bool ErrorState;
    //DataTable Batches = new DataTable();
    //;
    public sealed class botSFTPDownload : CodeActivity
    {
        private string process;
        private int FileTakenCount;
        private string clientName;
        private SqlConnection Sqlcon;
        private SqlCommand Sqlcmd;
        private SqlDataReader SqlRead;

        RuleSetParameters rulesParameters = new RuleSetParameters();
        DataTable Batches = new DataTable();


        // Define an activity input argument of type string
        public InArgument<Boolean> XMLtype { get; set; }
        public InArgument<string> SourcePath { get; set; }
        public InArgument<string> DestinationPath { get; set; }
        public InArgument<string> PortNumber { get; set; }
        public InArgument<string> ServerName { get; set; }
        public InArgument<string> UserName { get; set; }
        public InArgument<string> Password { get; set; }
        public InArgument<string> DateFormat { get; set; }
        public InArgument<string> FolderName { get; set; }
        public InArgument<string> FolderDate { get; set; }
        public InArgument<string> Process { get; set; }

        public InArgument<string> ClientName { get; set; }
        public InArgument<string> RuleSetName { get; set; }
        public InArgument<string> ZipFolder { get; set; }
        public InArgument<string> FileExtension { get; set; }
        public InArgument<string> FileName { get; set; }
        public InArgument<bool> ExtractZip { get; set; }
        public InArgument<int> FileModifieddate { get; set; }
        public InArgument<int> FolderModifieddate { get; set; }
        public InArgument<bool> FolderModified { get; set; }
        //public int FileTakenCount { get; private set; }
        //public string clientName { get; private set; }

        // If your activity returns a value, derive from CodeActivity<TResult>
        // and return the value from the Execute method.
        protected override void Execute(CodeActivityContext context)
        {
            FtpClientParameters parameters = new FtpClientParameters();
            Connection.Batches.Columns.Add("BatchNo", typeof(string));
            Connection.Batches.Columns.Add("sourceFileSize", typeof(Int64));
            Connection.Batches.Columns.Add("destinationFileSize", typeof(Int64));



            if (context.GetValue(this.XMLtype) == false)
            {
       
                // Obtain the runtime value of the Text input argument
                parameters.DownloadSource = context.GetValue(this.SourcePath);
                parameters.DownloadDestination = context.GetValue(this.DestinationPath);
                parameters.FolderDate = context.GetValue(this.FolderDate);
                parameters.FolderName = context.GetValue(this.FolderName);
                parameters.DateFormat = context.GetValue(this.DateFormat);
                parameters.ServerName = context.GetValue(this.ServerName);
                parameters.Port = context.GetValue(this.PortNumber);
                parameters.UserId = context.GetValue(this.UserName);
                parameters.Password = context.GetValue(this.Password);
                parameters.RuleSetName = context.GetValue(this.RuleSetName);
                parameters.ClientName = context.GetValue(this.ClientName);
                parameters.Process = context.GetValue(this.Process);
                parameters.ZipFolder = context.GetValue(this.ZipFolder);
                parameters.FileExtension = context.GetValue(this.FileExtension);
                parameters.ExtractZip = context.GetValue(this.ExtractZip);
                parameters.FileName = context.GetValue(this.FileName);
                parameters.FileModifiedDate = context.GetValue(this.FileModifieddate);

            }

            else
            {
               clientName = Connection.ClientName;
               parameters = DeSerialize(clientName);
                context.SetValue(Process, parameters.Process);
                context.SetValue(SourcePath, parameters.DownloadSource);
                context.SetValue(DestinationPath, parameters.DownloadDestination);
                context.SetValue(FolderDate, parameters.FolderDate);
                context.SetValue(FolderName, parameters.FolderName);
                context.SetValue(DateFormat, parameters.DateFormat);
                context.SetValue(ServerName, parameters.ServerName);
                context.SetValue(UserName, parameters.UserId);
                context.SetValue(Password, parameters.Password);
                context.SetValue(RuleSetName, parameters.RuleSetName);
                context.SetValue(ClientName, parameters.ClientName);
                context.SetValue(ZipFolder, parameters.ZipFolder);

                context.SetValue(FileExtension, parameters.FileExtension);
                context.SetValue(ExtractZip, parameters.ExtractZip);
                context.SetValue(FileName, parameters.FileName);
                context.SetValue(FileModifieddate, parameters.FileModifiedDate);
                context.SetValue(FolderModifieddate, parameters.FolderModifiedDate);
                context.SetValue(FolderModified, parameters.FolderModified);

            }
            Download(parameters);

        }


        private void Download(FtpClientParameters parameters)
        {
            try

            {

                Connection.processlog = Connection.processlog + "Connecting the SFTP Server. ";


                rulesParameters.ClientParameters = parameters;
                clientName = parameters.ClientName;
                Connection.Client = clientName;
                process = parameters.Process;
                Connection.Process = process;
                ApplyRule(rulesParameters);


              //  ConnectwithRSA(parameters.ServerName, parameters.UserId, parameters.Password, parameters.Port);
                FileTakenCount = 0;
                RowsClear();
                System.Threading.Thread.Sleep(1000);
                using (var client = new SftpClient(parameters.ServerName, Convert.ToInt16(parameters.Port), parameters.UserId, parameters.Password))
                {
                    //string oldHostKey = HostKeysDataSource.GetHostKey(this.connectionData.Host, this.connectionData.Port);
                    client.Connect();
                    //client.GiveUpSecurityAndAcceptAnySshHostKey = True

                    Connection.processlog = Connection.processlog + "Connected the SFTP Server.Download started  ";
                    if (rulesParameters.ClientParameters.FileName == "" || rulesParameters.ClientParameters.FileName == null)
                    {

                        if (client.Exists(rulesParameters.DownloadSource) == true)
                            DownloadDirectory(client, rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                        else if (rulesParameters.DownloadSourceNext != null)
                        {
                            if (client.Exists(rulesParameters.DownloadSourceNext) == true)
                            {
                                DownloadDirectory(client, rulesParameters.DownloadSourceNext, rulesParameters.DownloadDestination);
                            }
                        }
                    }

                    else
                    {
                        Connection.sourceFileCount = 0;
                        DownloadFile(client, rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                    }


                }
                Connection.processlog = Connection.processlog + "Download has completed.  ";
                Connection.ProcessLogFiles(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);

            }
            catch (Exception ex)
            {
                //  Program.logger.Error(ex, clientName);
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();


            }
            //TODO: Download files
        }

        private FtpClientParameters DeSerialize(string clientName)
        {
            try
            {
                Connection.processlog = Connection.processlog + "DeSerialize the XML. ";
                Connection.processlog = Connection.processlog + AppDomain.CurrentDomain.BaseDirectory + @"\Xml\" + clientName + @".xml";
                XmlSerializer deserializer = new XmlSerializer(typeof(FtpClientParameters));
                TextReader reader = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + @"\Xml\" + clientName + @".xml");
                object obj = deserializer.Deserialize(reader);
                FtpClientParameters XmlData = (FtpClientParameters)obj;
                reader.Close();
                Connection.processlog = Connection.processlog + "DeSerialize has completed. ";
                return XmlData;
            }
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();
                return null;
            }


        }

        private void ConnectwithRSA(string hostName,string userID,string passWord,string portNo)
        {
            string path = "C:\\Program Files (x86)\\WinSCP\\WinSCP.EXE";
            //string userID = "accesshealthcare";
            //string passWord = "N2Y0MzlkNGI2OGNj";
            //string hostName = "accesshealthcare@secure.challc.net";
            //int portNo = 22;
            Process proc = new Process();
            proc.StartInfo.FileName = path;
            proc.Start();
            System.Threading.Thread.Sleep(3000);
            AutoItX.Send(hostName);
            AutoItX.Send("{TAB}");
            System.Threading.Thread.Sleep(100);
            AutoItX.Send(portNo.ToString());
            AutoItX.Send("{TAB}");
            System.Threading.Thread.Sleep(100);
            AutoItX.Send(userID);
            AutoItX.Send("{TAB}");
            System.Threading.Thread.Sleep(100);
            AutoItX.Send(passWord);
            AutoItX.Send("{TAB 3}");
            System.Threading.Thread.Sleep(100);
            AutoItX.Send("{ENTER}");
            System.Threading.Thread.Sleep(4000);
            AutoItX.Send("{ENTER}");
            System.Threading.Thread.Sleep(5000);
            AutoItX.WinClose();
            System.Threading.Thread.Sleep(200);
            AutoItX.Send("{ENTER}");
        }
        private void DownloadFile(SftpClient client, string sourceFile, string destinationFile)
        {

            if (DateTime.Now.ToString("dd/MM/yyyy") == client.GetLastWriteTime(sourceFile).ToString("dd/MM/yyyy"))
            {

                if (File.Exists(destinationFile) == false)
                {
                    Connection.sourceFileCount++;
                    using (Stream fileStream = File.OpenWrite(destinationFile))
                    {

                        client.DownloadFile(sourceFile, fileStream);
                        long size = client.Get(sourceFile).Length;


                        FileInfo ff = new FileInfo(destinationFile);
                        Connection.Batches.Rows.Add(Path.GetFileNameWithoutExtension(sourceFile), size, ff.Length);
                    }
                }
            }
        }
        private void DownloadDirectory(SftpClient client, string source, string destination)
        {

            try
            {
                    //processlog + "dwonload the all files";
                //if (clientName == "NewPort")
                //{
                //    DeleteDirectory(destination);
                //}



                if (rulesParameters.FolderModified == true)
                {
                  

                    if (rulesParameters.FolderModifiedDate !=0)
                    {
                        DateTime yesterday = DateTime.Now.AddDays(-1).Date;
                        DateTime Today = DateTime.Now.AddDays(0).Date;

                        var Files = client.ListDirectory(source).AsEnumerable().Select(x =>
                        {

                            return x;
                        }).Where(x => (x.LastWriteTime.Date == yesterday && Convert.ToDateTime(x.LastWriteTime.ToShortTimeString()) > Convert.ToDateTime("06:00 AM")) || (x.LastWriteTime.Date == Today && Convert.ToDateTime(x.LastWriteTime.ToShortTimeString()) <= Convert.ToDateTime("06:00 AM")))
                                       .ToArray()
                                       ;


                        foreach (var file in Files)
                        {
                            if (!file.IsDirectory && !file.IsSymbolicLink)
                            {
                                if (file.Name != "." && file.Name != ".." && file.Name != "Thumbs.db")
                                {
                                    if (Path.GetExtension(file.FullName) == rulesParameters.FileExtension && rulesParameters.FileExtension != "")
                                    {

                                        if (File.Exists(Path.Combine(destination, file.Name)) == false)
                                        {
                                            Connection.sourceFileCount++;
                                            using (Stream fileStream = File.OpenWrite(Path.Combine(destination, file.Name)))
                                            {
                                      
                                              
                                                client.DownloadFile(file.FullName, fileStream);
                                                FileInfo ff = new FileInfo(Path.Combine(destination, file.Name));
                                                long size = client.Get(file.FullName).Length;
                                                Connection.Batches.Rows.Add(file.Name, size, ff.Length);
                                            }
                                        }
                                    }

                                    else
                                    {
                                        if (File.Exists(Path.Combine(destination, file.Name)) == false)
                                        {
                                            Connection.sourceFileCount++;
                                            using (Stream fileStream = File.OpenWrite(Path.Combine(destination, file.Name)))
                                            {

                                                client.DownloadFile(file.FullName, fileStream);

                                                FileInfo ff = new FileInfo(Path.Combine(destination, file.Name));
                                                long size = client.Get(file.FullName).Length;
                                                Connection.Batches.Rows.Add(file.Name, size, ff.Length);
                                            }
                                        }

                                    }
                                }
                            }

                            else if (file.Name != "." && file.Name != ".." && file.Name != "Thumbs.db")
                            {
                                if (!Directory.Exists(Path.Combine(destination, file.Name)))
                                {
                                    var dir = Directory.CreateDirectory(Path.Combine(destination, file.Name));
                                    DownloadDirectory(client, file.FullName, dir.FullName);
                                }
                            }
                        }

                    }

                    else if(rulesParameters.FolderModifiedDate==0)
                    {
                        DateTime Today = DateTime.Now.AddDays(rulesParameters.FileModifiedDate).ToUniversalTime().Date;
                                        var Files = client.ListDirectory(source).AsEnumerable().Select(x =>
                        {

                            return x;
                        }).Where(x => (x.LastWriteTimeUtc.Date == Today.ToUniversalTime().Date))
                                       .ToArray();

                        foreach (var file in Files)
                        {
                            if (!file.IsDirectory && !file.IsSymbolicLink)
                            {
                                if (file.Name != "." && file.Name != ".." && file.Name != "Thumbs.db")
                                {
                                    if (Path.GetExtension(file.FullName) == rulesParameters.FileExtension && rulesParameters.FileExtension != "")
                                    {

                                        if (File.Exists(Path.Combine(destination, file.Name)) == false)
                                        {
                                            Connection.sourceFileCount++;
                                            using (Stream fileStream = File.OpenWrite(Path.Combine(destination, file.Name)))
                                            {

                                                client.DownloadFile(file.FullName, fileStream);
                                                FileInfo ff = new FileInfo(Path.Combine(destination, file.Name));
                                                long size = client.Get(file.FullName).Length;
                                                Connection.Batches.Rows.Add(file.Name, size, ff.Length);
                                            }
                                        }
                                    }

                                    else
                                    {
                                        if (File.Exists(Path.Combine(destination, file.Name)) == false)
                                        {
                                            Connection.sourceFileCount++;
                                            using (Stream fileStream = File.OpenWrite(Path.Combine(destination, file.Name)))
                                            {

                                                client.DownloadFile(file.FullName, fileStream);

                                                FileInfo ff = new FileInfo(Path.Combine(destination, file.Name));
                                                long size = client.Get(file.FullName).Length;
                                                Connection.Batches.Rows.Add(file.Name, size, ff.Length);
                                            }
                                        }

                                    }
                                }
                            }

                            else if (file.Name != "." && file.Name != ".." && file.Name != "Thumbs.db")
                            {
                                if (!Directory.Exists(Path.Combine(destination, file.Name)))
                                {
                                    var dir = Directory.CreateDirectory(Path.Combine(destination, file.Name));
                                    DownloadDirectory(client, file.FullName, dir.FullName);
                                }
                            }
                        }
                    }




                }
                else
                {
                    var Files = client.ListDirectory(source);
                   
                    foreach (var file in Files)
                    {
                   
                        if (!file.IsDirectory && !file.IsSymbolicLink)
                        {
                            if (file.Name != "." && file.Name != ".." && file.Name != "Thumbs.db" )
                            {
                                

                                if (Path.GetExtension(file.FullName) == rulesParameters.FileExtension && rulesParameters.FileExtension!="")
                                {

                                    if (File.Exists(Path.Combine(destination, file.Name)) == false)
                                    {
                                        Connection.sourceFileCount++;
                                        using (Stream fileStream = File.OpenWrite(Path.Combine(destination, file.Name)))
                                        {

                                            client.DownloadFile(file.FullName, fileStream);

                                            FileInfo ff = new FileInfo(Path.Combine(destination, file.Name));
                                            long size = client.Get(file.FullName).Length;
                                            Connection.Batches.Rows.Add(file.Name, size, ff.Length);
                                        }
                                    }
                                }

                                else
                                {
                                    if (File.Exists(Path.Combine(destination, file.Name)) == false)
                                    {
                                        Connection.sourceFileCount++;
                                        using (Stream fileStream = File.OpenWrite(Path.Combine(destination, file.Name)))
                                        {

                                            client.DownloadFile(file.FullName, fileStream);

                                            FileInfo ff = new FileInfo(Path.Combine(destination, file.Name));
                                            long size = client.Get(file.FullName).Length;
                                            Connection.Batches.Rows.Add(file.Name, size, ff.Length);
                                        }
                                    }

                                }
                            }
                        }

                        else if (file.Name != "." && file.Name != ".." && file.Name != "Thumbs.db")
                        {
                            if (!Directory.Exists(Path.Combine(destination, file.Name)))
                            {
                                var dir = Directory.CreateDirectory(Path.Combine(destination, file.Name));
                                DownloadDirectory(client, file.FullName, dir.FullName);
                            }
                        }
                    }
                }


                if (rulesParameters.ClientParameters.ExtractZip==true)
                {
                    RowsClear();
                    Connection.processlog = Connection.processlog + "Zip Extract has Start. ";
                    ExtractZipFile(destination, rulesParameters.zipFolder);
                    Connection.processlog = Connection.processlog + "Zip Extract has Completed. ";
                }
            }
            catch (Exception ex)
            {

                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();
            }
        }


        public void ExtractZipFile(string archiveFilenameIn, string outFolder)
        {
            ZipFile zf = null;
            try



            {

                // Program.logger.Info("Zip File Extract    started");

                FileTakenCount = 0;
                var zipFiles = Directory.GetFiles(archiveFilenameIn);

                foreach (var FileName in zipFiles)
                {
                    if (Path.GetExtension(FileName) == ".zip")
                    {
                        FileStream fs = File.OpenRead(FileName);
                        zf = new ZipFile(fs);

                        foreach (ZipEntry zipEntry in zf)
                        {
                            if (!zipEntry.IsFile) continue; // Ignore directories

                            String entryFileName = zipEntry.Name;
                            //to remove the folder from the entry:
                            entryFileName = Path.GetFileName(entryFileName);

                            byte[] buffer = new byte[4096];     // 4K is optimum
                            Stream zipStream = zf.GetInputStream(zipEntry);
                            // Manipulate the output filename here as desired.
                            String fullZipToPath = Path.Combine(outFolder, entryFileName);
                            string directoryName = Path.GetDirectoryName(fullZipToPath);
                            if (directoryName.Length > 0)
                                Directory.CreateDirectory(directoryName);


                            if (Path.GetFileName(fullZipToPath) != "Thumbs.db")
                            {
                                using (FileStream streamWriter = File.Create(fullZipToPath))
                                {

                                    StreamUtils.Copy(zipStream, streamWriter, buffer);
                                    if (Path.GetExtension(fullZipToPath) != ".xlsx" && Path.GetExtension(fullZipToPath) != ".xml" && Path.GetExtension(fullZipToPath) != ".xls")
                                    {
                                        Connection.sourceFileCount++;
                                       // Batches.Rows.Add(entryFileName, FileSize(streamWriter.Length), FileSize(streamWriter.Length));
                                   
                                        Connection.Batches.Rows.Add(entryFileName, streamWriter.Length, streamWriter.Length);
                                    }
                                }
                            }
                        }
                    }
                }


            }

            catch (Exception ex)
            {

                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();
            }
            finally
            {
                if (zf != null)
                {
                    zf.IsStreamOwner = true;
                    zf.Close();
                }
            }
        }

     
        private void RowsClear()
        {
            if (Connection.Batches.Rows.Count > 0)
            {
                Connection.Batches.Rows.Clear();
            }
        }

        private long FileSize(long Filelength)
        {
            string[] suffixes = { "B", "KB", "MB" };
            int s = 0;
            while (Filelength >= 1024)
            {
                s++;
                Filelength /= 1024;
            }

            return Filelength;
        }


       


        private RuleSetParameters ApplyRule(RuleSetParameters parameters)
        {
            try
            {
                
                RuleSetManager rsm = new RuleSetManager();
                rsm.LoadRuleSet(parameters.ClientParameters.RuleSetName);
                rsm.ExecuteRuleSet(parameters);
                return parameters;
            }
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();
                return null;
            }

        }
    }
}
