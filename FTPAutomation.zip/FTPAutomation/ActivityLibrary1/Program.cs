﻿
using ActivityKibrary1;
using ActivityLibrary1;
using System;
using System.Activities;
//using System.Security.Cryptography.X509Certificates;
using System.Data;
using System.IO;
using System.Net;


namespace ServerConnection
{

    static class Program
    {
        public static DataTable Batches = new DataTable();
        //public static Logger logger = LogManager.GetLogger("databaseLogger");
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]

        public static void Main()
        {
            try
            {

                String dte = System.DateTime.Now.AddDays(System.Convert.ToInt16(0)).ToString("ddMMyyyy hh:mm:ss");
                Connection.processlog = "Start";
                Connection.LogFiles();
                string[] args = new string[1];
                args[0] = "continuum";

                string paramList = string.Join(" ", args);
                string[] parameter = paramList.Split(',');
                Connection.ClientName = parameter[0];
                Activity workflow1 = new FTPProcess();
                WorkflowInvoker.Invoke(workflow1);
                Environment.Exit(0);

            }
            catch(Exception ex)
            {
                Connection.processlog = ex.InnerException.Message;
                Connection.LogFiles();
            }
        }


    }
}
