﻿using System;
using System.Linq;
using System.Text;
using System.Activities;
using System.Data;
using ActivityKibrary1;
using Renci.SshNet;
using System.Data.SqlClient;
using System.IO;
using System.Xml.Serialization;
using FTPParameters;
using ICSharpCode.SharpZipLib.Zip;
using ICSharpCode.SharpZipLib.Core;

namespace ServerConnection
{
    //private int Connection.sourceFileCount;
    //private string process;
    //public static string clientName;
    //private bool ErrorState;
    //DataTable Batches = new DataTable();
    //;
    public sealed class botSFTPArchive : CodeActivity
    {

        private string clientName;
        private SqlConnection Sqlcon;
        private SqlCommand Sqlcmd;
        private SqlDataReader SqlRead;

        RuleSetParameters rulesParameters = new RuleSetParameters();



        // Define an activity input argument of type string
        public InArgument<Boolean> XMLtype { get; set; }
        public InArgument<string> SourcePath { get; set; }
        public InArgument<string> DestinationPath { get; set; }
        public InArgument<string> PortNumber { get; set; }
        public InArgument<string> ServerName { get; set; }
        public InArgument<string> UserName { get; set; }
        public InArgument<string> Password { get; set; }
        public InArgument<string> DateFormat { get; set; }
        public InArgument<string> FolderName { get; set; }
        public InArgument<string> FolderDate { get; set; }
        public InArgument<string> Process { get; set; }

        public InArgument<string> ClientName { get; set; }
        public InArgument<string> RuleSetName { get; set; }
        public InArgument<string> ZipFolder { get; set; }
        public InArgument<string> FileExtension { get; set; }

        public InArgument<bool> ExtractZip { get; set; }
        //public int Connection.sourceFileCount { get; private set; }
        //public string clientName { get; private set; }

        // If your activity returns a value, derive from CodeActivity<TResult>
        // and return the value from the Execute method.
        protected override void Execute(CodeActivityContext context)
        {
            FtpClientParameters parameters = new FtpClientParameters();
            Connection.Batches.Columns.Add("BatchNo", typeof(string));
            Connection.Batches.Columns.Add("sourceFileSize", typeof(Int64));
            Connection.Batches.Columns.Add("destinationFileSize", typeof(Int64));


            if (context.GetValue(this.XMLtype) == false)
            {
       
                // Obtain the runtime value of the Text input argument
                parameters.DownloadSource = context.GetValue(this.SourcePath);
                parameters.DownloadDestination = context.GetValue(this.DestinationPath);
                parameters.FolderDate = context.GetValue(this.FolderDate);
                parameters.FolderName = context.GetValue(this.FolderName);
                parameters.DateFormat = context.GetValue(this.DateFormat);
                parameters.ServerName = context.GetValue(this.ServerName);
                parameters.Port = context.GetValue(this.PortNumber);
                parameters.UserId = context.GetValue(this.UserName);
                parameters.Password = context.GetValue(this.Password);
                parameters.RuleSetName = context.GetValue(this.RuleSetName);
                parameters.ClientName = context.GetValue(this.ClientName);
                parameters.Process = context.GetValue(this.Process);
                parameters.ZipFolder = context.GetValue(this.ZipFolder);
                parameters.FileExtension = context.GetValue(this.FileExtension);
                parameters.ExtractZip = context.GetValue(this.ExtractZip);

            }

            else
            {
               clientName = Connection.ClientName;
               parameters = DeSerialize(clientName);
                Connection.Process = parameters.Process;
                context.SetValue(Process, parameters.Process);
                context.SetValue(SourcePath, parameters.DownloadSource);
                context.SetValue(DestinationPath, parameters.DownloadDestination);
                context.SetValue(FolderDate, parameters.FolderDate);
                context.SetValue(FolderName, parameters.FolderName);
                context.SetValue(DateFormat, parameters.DateFormat);
                context.SetValue(ServerName, parameters.ServerName);
                context.SetValue(UserName, parameters.UserId);
                context.SetValue(Password, parameters.Password);
                context.SetValue(RuleSetName, parameters.RuleSetName);
                context.SetValue(ClientName, parameters.ClientName);
                context.SetValue(ZipFolder, parameters.ZipFolder);

                context.SetValue(FileExtension, parameters.FileExtension);
                context.SetValue(ExtractZip, parameters.ExtractZip);



            }
            Archive(parameters);

        }


        private void Archive(FtpClientParameters parameters)
        {
            try

            {

                Connection.processlog = Connection.processlog + "Connecting the SFTP Server. ";


                rulesParameters.ClientParameters = parameters;
                clientName = parameters.ClientName;
                Connection.Client = clientName;
                Connection.Process = parameters.Process;
              
                ApplyRule(rulesParameters);            
                Connection.sourceFileCount = 0;
                RowsClear();
                using (var client = new SftpClient(parameters.ServerName, Convert.ToInt16(parameters.Port), parameters.UserId, parameters.Password))
                {
                    client.Connect();
                    Connection.processlog = Connection.processlog + "Connected the SFTP Server.Archive has started  ";
                    if (client.Exists(rulesParameters.DownloadSource) == true)
                     ArchiveDirectory(client, rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                   

                }
                Connection.processlog = Connection.processlog + "Archive has completed.  ";
                Connection.ProcessLogFiles(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);

            }
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();

            }
            
        }

        private FtpClientParameters DeSerialize(string clientName)
        {
            try
            {
                Connection.processlog = Connection.processlog + "DeSerialize the XML. ";
                Connection.processlog = Connection.processlog + AppDomain.CurrentDomain.BaseDirectory + @"\Xml\" + clientName + @".xml";
                XmlSerializer deserializer = new XmlSerializer(typeof(FtpClientParameters));
                TextReader reader = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + @"\Xml\" + clientName + @".xml");
                object obj = deserializer.Deserialize(reader);
                FtpClientParameters XmlData = (FtpClientParameters)obj;
                reader.Close();
                Connection.processlog = Connection.processlog + "DeSerialize has completed. ";
                return XmlData;
            }
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();
                return null;
            }


        }
        private void ArchiveDirectory(SftpClient client, string source, string destination)
        {

            try
            {
               

                 if (Connection.Client=="StLouisBatchFile")
                {
                    var Files = client.ListDirectory(source);
                    foreach (var file in Files)
                    {
                        if (!file.IsDirectory && !file.IsSymbolicLink)
                        {
                            if (file.Name != "." && file.Name != ".." && file.Name != "Thumbs.db")
                            {
                                if (Path.GetExtension(file.FullName) == rulesParameters.FileExtension && rulesParameters.FileExtension != "")
                                {

                                    if (client.Exists(destination + @"/" + file.Name) == false)
                                    {


                                        Connection.sourceFileCount++;

                                        client.RenameFile(file.FullName, destination + @"/" + file.Name);
                                        Connection.Batches.Rows.Add(file.Name, FileSize(file.Length), FileSize(client.Get(destination + @"/" + file.Name).Length));

                                    }
                                }

                                else
                                {
                                    if (client.Exists(destination + @"/" + file.Name) == false)
                                    {


                                        Connection.sourceFileCount++;
                                        client.RenameFile(file.FullName, destination + @"/" + file.Name);
                                        Connection.Batches.Rows.Add(file.Name, FileSize(file.Length), FileSize(client.Get(destination + @"/" + file.Name).Length));

                                    }

                                }
                            }
                        }
                        else if (file.Name != "." && file.Name != ".." && file.Name != "Thumbs.db")
                        {
                            if ( file.Name!= "Current Batch Logs" && (file.Name)!= "Allocation Spreadsheets")
                            {

                                if (!client.Exists(destination + @"/" + file.Name))
                                {
                                    client.CreateDirectory(destination + @"/" + file.Name);
                                    ArchiveDirectory(client, file.FullName, destination + @"/" + file.Name);
                                }
                            }
                        }

                    }

                   

                }
                else
                {
                    var Files = client.ListDirectory(source);
                    foreach (var file in Files)
                    {
                        if (!file.IsDirectory && !file.IsSymbolicLink)
                        {
                            if (file.Name != "." && file.Name != ".." && file.Name != "Thumbs.db")
                            {
                                

                                if (Path.GetExtension(file.FullName) == rulesParameters.FileExtension && rulesParameters.FileExtension!="")
                                {

                                    if (client.Exists(destination + @"/" + file.Name) == false)
                                    {


                                        Connection.sourceFileCount++;
                                        client.RenameFile(file.FullName, destination + @"/" + file.Name);
                                                                 
                                        Connection.Batches.Rows.Add(file.Name, FileSize(file.Length), FileSize(client.Get(destination + @"/" + file.Name).Length));
                                        
                                    }
                                }

                                else
                                {
                                    if (client.Exists(destination + @"/" + file.Name) == false)
                                    {
                                        Connection.sourceFileCount++;
                                        client.RenameFile(file.FullName, destination + @"/" + file.Name);
                                        Connection.Batches.Rows.Add(file.Name, FileSize(file.Length), FileSize(client.Get(destination + @"/" + file.Name).Length));

                                    }

                                }
                            }
                        }

                        else if (file.Name != "." && file.Name != ".." && file.Name != "Thumbs.db")
                        {
                            if (!client.Exists(destination + @"/" + file.Name))
                            {
                               client.CreateDirectory(destination + @"/" + file.Name);
                                ArchiveDirectory(client, file.FullName,destination + @"/" + file.Name);
                            }
                        }
                    }
                }


                if (rulesParameters.ExtractZip==true)
                {
                    RowsClear();
                    Connection.processlog = Connection.processlog + "Zip Extract has Start. ";
                    ExtractZipFile(destination, rulesParameters.zipFolder);
                    Connection.processlog = Connection.processlog + "Zip Extract has Completed. ";
                }
            }
            catch (Exception ex)
            {

                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();
            }
        }


        public void ExtractZipFile(string archiveFilenameIn, string outFolder)
        {
            ZipFile zf = null;
            try



            {

                // Program.logger.Info("Zip File Extract started");

                Connection.sourceFileCount = 0;
                var zipFiles = Directory.GetFiles(archiveFilenameIn);

                foreach (var FileName in zipFiles)
                {
                    if (Path.GetExtension(FileName) == ".zip")
                    {
                        FileStream fs = File.OpenRead(FileName);
                        zf = new ZipFile(fs);

                        foreach (ZipEntry zipEntry in zf)
                        {
                            if (!zipEntry.IsFile) continue; // Ignore directories

                            String entryFileName = zipEntry.Name;
                            //to remove the folder from the entry:
                            entryFileName = Path.GetFileName(entryFileName);


                            byte[] buffer = new byte[4096];     // 4K is optimum
                            Stream zipStream = zf.GetInputStream(zipEntry);
                            // Manipulate the output filename here as desired.
                            String fullZipToPath = Path.Combine(outFolder, entryFileName);
                            string directoryName = Path.GetDirectoryName(fullZipToPath);
                            if (directoryName.Length > 0)
                                Directory.CreateDirectory(directoryName);

                            using (FileStream streamWriter = File.Create(fullZipToPath))
                            {
                                Connection.sourceFileCount = Connection.sourceFileCount + 1;
                                StreamUtils.Copy(zipStream, streamWriter, buffer);
                                Connection.Batches.Rows.Add(entryFileName, FileSize(streamWriter.Length), FileSize(streamWriter.Length));
                            }
                        }
                    }
                }


            }

            catch (Exception ex)
            {

                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();
            }
            finally
            {
                if (zf != null)
                {
                    zf.IsStreamOwner = true;
                    zf.Close();
                }
            }
        }

        private void RowsClear()
        {
            if (Connection.Batches.Rows.Count > 0)
            {
                Connection.Batches.Rows.Clear();
            }
        }

        private long FileSize(long Filelength)
        {
            string[] suffixes = { "B", "KB", "MB" };
            int s = 0;
            while (Filelength >= 1024)
            {
                s++;
                Filelength /= 1024;
            }

            return Filelength;
        }


       


        private RuleSetParameters ApplyRule(RuleSetParameters parameters)
        {
            try
            {
                
                    Connection.processlog = Connection.processlog + "calling the Ruleset ";
                    RuleSetManager rsm = new RuleSetManager();
                    rsm.LoadRuleSet(parameters.ClientParameters.RuleSetName);
                    Connection.processlog = Connection.processlog + "called the Ruleset.";
                    rsm.ExecuteRuleSet(parameters);
                   return parameters;
            }
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = false;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();
                return null;
            }

        }
    }
}
