﻿using System;
using System.Linq;
using System.Text;
using System.Activities;
using System.Data;
using ActivityKibrary1;
using Renci.SshNet;
using System.Data.SqlClient;
using System.IO;
using System.Xml.Serialization;
using FTPParameters;
using ICSharpCode.SharpZipLib.Zip;
using ICSharpCode.SharpZipLib.Core;

namespace ServerConnection
{
    //private int FileTakenCount;
    //private string process;
    //public static string clientName;
    //private bool ErrorState;
    //DataTable Batches = new DataTable();
    //;
    public sealed class botSFTPTest : CodeActivity
    {
        private string process;
        private string clientName;
        private SqlConnection Sqlcon;
        private SqlCommand Sqlcmd;
        private SqlDataReader SqlRead;


        RuleSetParameters rulesParameters = new RuleSetParameters();
 


        // Define an activity input argument of type string
        public InArgument<Boolean> XMLtype { get; set; }
        public InArgument<string> SourcePath { get; set; }
        public InArgument<string> DestinationPath { get; set; }
        public InArgument<string> PortNumber { get; set; }
        public InArgument<string> ServerName { get; set; }
        public InArgument<string> UserName { get; set; }
        public InArgument<string> Password { get; set; }
        public InArgument<string> DateFormat { get; set; }
        public InArgument<string> FolderName { get; set; }
        public InArgument<string> FolderDate { get; set; }
        public InArgument<string> Process { get; set; }

        public InArgument<string> ClientName { get; set; }
        public InArgument<string> RuleSetName { get; set; }
        public InArgument<string> ZipFolder { get; set; }
        public InArgument<string> FileExtension { get; set; }

        public InArgument<bool> ExtractZip { get; set; }
        //public int FileTakenCount { get; private set; }
        //public string clientName { get; private set; }

        // If your activity returns a value, derive from CodeActivity<TResult>
        // and return the value from the Execute method.
        protected override void Execute(CodeActivityContext context)
        {
            FtpClientParameters parameters = new FtpClientParameters();
          Connection.Batches.Columns.Add("BatchNo", typeof(string));
            Connection.Batches.Columns.Add("sourceFileSize", typeof(Int64));
            Connection.Batches.Columns.Add("destinationFileSize", typeof(Int64));


            if (context.GetValue(this.XMLtype) == false)
            {
       
                // Obtain the runtime value of the Text input argument
                parameters.DownloadSource = context.GetValue(this.SourcePath);
                parameters.DownloadDestination = context.GetValue(this.DestinationPath);
                parameters.FolderDate = context.GetValue(this.FolderDate);
                parameters.FolderName = context.GetValue(this.FolderName);
                parameters.DateFormat = context.GetValue(this.DateFormat);
                parameters.ServerName = context.GetValue(this.ServerName);
                parameters.Port = context.GetValue(this.PortNumber);
                parameters.UserId = context.GetValue(this.UserName);
                parameters.Password = context.GetValue(this.Password);
                parameters.RuleSetName = context.GetValue(this.RuleSetName);
                parameters.ClientName = context.GetValue(this.ClientName);
                parameters.Process = context.GetValue(this.Process);
                parameters.ZipFolder = context.GetValue(this.ZipFolder);
                parameters.FileExtension = context.GetValue(this.FileExtension);
                parameters.ExtractZip = context.GetValue(this.ExtractZip);

            }

            else
            {
               clientName = Connection.ClientName;
               parameters = DeSerialize(clientName);
                Connection.Process = parameters.Process;
                context.SetValue(Process, parameters.Process);
                context.SetValue(SourcePath, parameters.DownloadSource);
                context.SetValue(DestinationPath, parameters.DownloadDestination);
                context.SetValue(FolderDate, parameters.FolderDate);
                context.SetValue(FolderName, parameters.FolderName);
                context.SetValue(DateFormat, parameters.DateFormat);
                context.SetValue(ServerName, parameters.ServerName);
                context.SetValue(UserName, parameters.UserId);
                context.SetValue(Password, parameters.Password);
                context.SetValue(RuleSetName, parameters.RuleSetName);
                context.SetValue(ClientName, parameters.ClientName);
                context.SetValue(ZipFolder, parameters.ZipFolder);

                context.SetValue(FileExtension, parameters.FileExtension);
                context.SetValue(ExtractZip, parameters.ExtractZip);



            }
            Upload(parameters);

        }


        private void Upload(FtpClientParameters parameters)
        {
            try

            {
           



                rulesParameters.ClientParameters = parameters;
                clientName = parameters.ClientName;
                Connection.Client = clientName;
                process = parameters.Process;
                ApplyRule(rulesParameters);

              

                Connection.sourceFileCount = 0;
                RowsClear();
                if (!File.Exists(rulesParameters.DownloadSource))
                {
                    using (var client = new SftpClient(parameters.ServerName, Convert.ToInt16(parameters.Port), parameters.UserId, parameters.Password))
                    {
                        client.Connect();

                       // client.CreateDirectory(rulesParameters.DownloadDestination);
                        Connection.processlog = Connection.processlog + "Upload Process has Start. ";

                        UploadDirectory(client, rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                    }
                }
                else if (rulesParameters.DownloadSourceNext != null)
                {
                    if (File.Exists(rulesParameters.DownloadSourceNext) == true)
                    {
                        using (var client = new SftpClient(parameters.ServerName, Convert.ToInt16(parameters.Port), parameters.UserId, parameters.Password))
                        {
                            client.Connect();

                            UploadDirectory(client, rulesParameters.DownloadSourceNext, rulesParameters.DownloadDestination);
                        }
                    }
                }

                    Connection.processlog = Connection.processlog + "Upload Process has End. ";

                

                Connection.ProcessLogFiles(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);

            }
            catch (Exception ex)
            {
                //  Program.logger.Error(ex, clientName);
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();

            }
            //TODO: Download files
        }

        private FtpClientParameters DeSerialize(string clientName)
        {
            try
            {
                Connection.processlog = Connection.processlog + "call the DeSerialize Function. ";
                Connection.processlog = Connection.processlog + AppDomain.CurrentDomain.BaseDirectory + @"\Xml\" + clientName + @".xml";
                XmlSerializer deserializer = new XmlSerializer(typeof(FtpClientParameters));
                TextReader reader = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + @"\Xml\" + clientName + @".xml");
                object obj = deserializer.Deserialize(reader);
                FtpClientParameters XmlData = (FtpClientParameters)obj;
                reader.Close();
                Connection.processlog = Connection.processlog + "DeSerialized the XML. ";
                return XmlData;
            }
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();

                return null;
            }


        }
        private void UploadDirectory(SftpClient client, string source, string destination)
        {

            try
            {
                string destinationPath;
                // Connection.processlog = Connection.processlog + "dwonload the all files";
                //if (clientName == "NewPort")
                //{
                //    DeleteDirectory(destination);
                //}


                //   var FileName = Directory.GetFiles(source,"*.*");
                //    DirectoryInfo dir = new DirectoryInfo(source);
                //    var Files = dir.GetFiles("*.*",SearchOption.AllDirectories);
                //    foreach (FileInfo file in Files)
                //    {

                //    if (!destination.Contains(new DirectoryInfo(System.IO.Path.GetDirectoryName(file.FullName)).Name))
                //    {
                //        destinationPath = destination + @"/" + new DirectoryInfo(System.IO.Path.GetDirectoryName(file.FullName)).Name;
                //    }
                //    else
                //    {
                //        destinationPath = destination;
                //    }
                //    if (client.Exists(destinationPath))
                //        {

                //            if (Path.GetExtension(file.FullName) == rulesParameters.FileExtension && rulesParameters.FileExtension != "")
                //            {

                //                if (client.Exists((destinationPath + @"/" +  Path.GetFileName(file.FullName))) == false && Path.GetFileName(file.FullName) != "thumbs.db")
                //                {
                //                    Connection.sourceFileCount++;
                //                    using (Stream fileStream = File.OpenRead(file.FullName))
                //                    {

                //                        client.UploadFile(fileStream, (destination + @"/" + file.Name));

                //                        Connection.Batches.Rows.Add(file.Name, FileSize(file.Length), FileSize(client.Get(destination + @"/" + file.Name).Length));
                //                    }
                //                }
                //            }

                //            else
                //            {
                //                if (client.Exists((destinationPath + @"/" + file.Name)) == false)
                //                {
                //                    Connection.sourceFileCount++;
                //                    using (Stream fileStream = File.OpenRead(file.FullName))
                //                    {

                //                        client.UploadFile( fileStream, (destination + @"/" + file.Name) );
                //                        Connection.Batches.Rows.Add(file.Name, FileSize(file.Length), FileSize(client.Get(destination + @"/" + file.Name).Length));
                //                    }
                //                }

                //            }
                //        }


                //        else if (file.Name != "." && file.Name != ".." && file.Name != "Thumbs.db")
                //    {
                //        if (!client.Exists(destinationPath))
                //        {
                //             client.CreateDirectory(destinationPath);
                //            UploadDirectory(client, Path.GetDirectoryName(file.FullName), destinationPath);
                //        }
                //    }
                //}
                DirectoryInfo dir = new DirectoryInfo(source);
                var Files = dir.GetFiles("*.*");
                foreach (FileInfo file in Files)
                {

                    if (client.Exists((destination + @"/" + Path.GetFileName(file.FullName))) == false && Path.GetFileName(file.FullName) != "thumbs.db")
                    {
                        Connection.sourceFileCount++;
                        using (Stream fileStream = File.OpenRead(file.FullName))
                        {
                            File.Copy(file.FullName, (destination + @"/" + Path.GetFileName(file.FullName)));
                           // client.UploadFile(fileStream, (destination + @"/" + Path.GetFileName(file.FullName)));

                            //Connection.Batches.Rows.Add(file, FileSize(file.Length), FileSize(client.Get(destination + @"/" + file.Name).Length));
                        }
                    }
                }
                string[] subdirectory = Directory.GetDirectories(source);
                foreach (string directory in subdirectory)
                {
                    if (!client.Exists(destination + @"/" + directory))
                    {
                        //client.CreateDirectory(destination + @"/" + directory);
                        Directory.CreateDirectory(destination + @"\" + Path.GetFileName(directory));
                        UploadDirectory(client, directory, destination + @"\" + Path.GetFileName(directory));
                    }
                }

                    //if (rulesParameters.ExtractZip==true)
                    //{
                    //    RowsClear();
                    //    ExtractZipFile(destination, rulesParameters.zipFolder);
                    //}
                }
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();

            }
        }



public void ExtractZipFile(string archiveFilenameIn, string outFolder)
        {
            ZipFile zf = null;
            try



            {

                Connection.processlog = Connection.processlog + "Zip Extract has Start. ";
                // Program.logger.Info("Zip File Extract started");

                Connection.sourceFileCount = 0;
                var zipFiles = Directory.GetFiles(archiveFilenameIn);

                foreach (var FileName in zipFiles)
                {
                    if (Path.GetExtension(FileName) == ".zip")
                    {
                        FileStream fs = File.OpenRead(FileName);
                        zf = new ZipFile(fs);

                        foreach (ZipEntry zipEntry in zf)
                        {
                            if (!zipEntry.IsFile) continue; // Ignore directories

                            String entryFileName = zipEntry.Name;
                            //to remove the folder from the entry:
                            entryFileName = Path.GetFileName(entryFileName);


                            byte[] buffer = new byte[4096];     // 4K is optimum
                            Stream zipStream = zf.GetInputStream(zipEntry);
                            // Manipulate the output filename here as desired.
                            String fullZipToPath = Path.Combine(outFolder, entryFileName);
                            string directoryName = Path.GetDirectoryName(fullZipToPath);
                            if (directoryName.Length > 0)
                                Directory.CreateDirectory(directoryName);

                            using (FileStream streamWriter = File.Create(fullZipToPath))
                            {
                                Connection.sourceFileCount = Connection.sourceFileCount + 1;
                                StreamUtils.Copy(zipStream, streamWriter, buffer);
                                Connection.Batches.Rows.Add(entryFileName, FileSize(streamWriter.Length), FileSize(streamWriter.Length));
                            }
                        }
                    }
                }
                Connection.processlog = Connection.processlog + "Zip Extract has End. ";

            }

            catch (Exception ex)
            {

                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();

            }
            finally
            {
                if (zf != null)
                {
                    zf.IsStreamOwner = true;
                    zf.Close();
                }
            }
        }

        //public void Mail(string Source, string Dest)
        //{

        //    try
        //    {
        //        string SubjectText = clientName + " File  " + process + "  Details on " + DateTime.Now.ToString("MM/dd/yyyy");

        //        StringBuilder BodyMsg = new StringBuilder();
        //        BodyMsg.AppendLine("Hi All");
        //        BodyMsg.AppendLine("<br><br>");
        //        if (Errorstate == false)
        //        {
        //            BodyMsg.AppendLine("<br> <br> <Table  border=1> <tr bgcolor=blue>  <td> Path Type </td>  <td> FilePath </td> <td> BatchCount </td> <td>Batch Size </td>  </tr> ");
        //            string FilePlacedSize = Batches.Compute("Sum(FilePlacedPath)", "").ToString();
        //            string FiletakenSize = Batches.Compute("Sum(FiletakenPathSize)", "").ToString();

        //            BodyMsg.AppendLine("<tr><td> Source </td><td>" + Source + "</td><td>" + Convert.ToString(FileTakenCount) + "</td><td>" + FiletakenSize + "</td><tr>");
        //            BodyMsg.AppendLine("<tr><td> Destination  </td><td>" + Dest + "</td><td>" + Convert.ToString(Batches.Rows.Count) + "</td><td>" + FilePlacedSize + "</td></tr>");
        //            BodyMsg.AppendLine("</table> <br><br><b> Thanks  <br><br> **** This is Auto generated Mail **** </b><br><br>");
        //        }

        //        else

        //        {
        //            BodyMsg.AppendLine(Connection.processlog);
        //            BodyMsg.AppendLine("<br><br><b> Thanks  <br><br> **** This is Auto generated Mail **** </b><br><br>");
        //        }


        //        String Qury = "exec  FTp_Mailsend @Subject,@Body";
        //        Sqlcon = new SqlConnection("Data Source=SQL-Listner;Initial catalog=ARC_ATHENA;User id=offlineAppuser;PWD=offline@app$2@16; multisubnetfailover=true");
        //        if (Sqlcon.State == ConnectionState.Closed)
        //        {
        //            Sqlcon.Open();
        //        }
        //        Sqlcmd = new SqlCommand(Qury, Sqlcon);
        //        Sqlcmd.Parameters.AddWithValue("@Subject", SubjectText);
        //        Sqlcmd.Parameters.AddWithValue("@BODY", BodyMsg.ToString());
        //        Sqlcmd.ExecuteNonQuery();
        //        Environment.Exit(0);
        //    }
        //    catch (Exception ex)
        //    {
        //        Connection.processlog = Connection.processlog + ex.Message;
        //        Connection.LogFiles();
        //    }

        //}
        //public void ProcessLogFiles(string Source, string Dest)
        //{

        //    try
        //    {

        //        Connection.processlog = Connection.processlog + "calling the Logs insert Function ";
        //        Sqlcon = new SqlConnection(Connection.strSqlCon);

        //        if (Sqlcon.State == ConnectionState.Closed)
        //        {
        //            Sqlcon.Open();
        //        }
        //        //ClientName varchar(100),@ProcessName varchar(30),@FiletakenPath varchar(300),@FilePlacedPath varchar(500),@Batchno BatchTrack readonly
        //        string strCmd = "FTP_MoveBatchlist";
        //        Sqlcmd = new SqlCommand(strCmd, Sqlcon);
        //        Sqlcmd.CommandType = CommandType.StoredProcedure;
        //        Sqlcmd.Parameters.Add("@ClientName", SqlDbType.VarChar, 100).Value = clientName;
        //        Sqlcmd.Parameters.Add("@ProcessName", SqlDbType.VarChar, 50).Value = process;
        //        Sqlcmd.Parameters.Add("@FiletakenPath", SqlDbType.VarChar, 50).Value = Source;
        //        Sqlcmd.Parameters.Add("@FilePlacedPath", SqlDbType.VarChar, 50).Value = Dest;
        //        SqlParameter Param = Sqlcmd.Parameters.AddWithValue("@Batchinfo", Batches);
        //        Param.SqlDbType = SqlDbType.Structured;

        //        Sqlcmd.ExecuteNonQuery();
        //        Sqlcmd.Cancel();
        //        Sqlcon.Close();
        //        Connection.processlog = Connection.processlog + "Logs insert Function End ";
        //    }
        //    catch (Exception ex)
        //    {
        //        // Program.logger.Error(ex, clientName);
        //        Connection.processlog = Connection.processlog + ex.Message;
        //        Connection.LogFiles();
        //    }

        //}
        private void RowsClear()
        {
            if (Connection.Batches.Rows.Count > 0)
            {
                Connection.Batches.Rows.Clear();
            }
        }

        private long FileSize(long Filelength)
        {
            string[] suffixes = { "B", "KB", "MB" };
            int s = 0;
            while (Filelength >= 1024)
            {
                s++;
                Filelength /= 1024;
            }

            return Filelength;
        }


       


        private RuleSetParameters ApplyRule(RuleSetParameters parameters)
        {
            try
            {
                Connection.processlog = Connection.processlog + "calling the Ruleset. ";

                RuleSetManager rsm = new RuleSetManager();
                rsm.LoadRuleSet(parameters.ClientParameters.RuleSetName);
                Connection.processlog = Connection.processlog + "called the Ruleset.";
                rsm.ExecuteRuleSet(parameters);
                return parameters;
            }
            catch (Exception ex)
            {
                Connection.processlog = Connection.processlog + ex.Message;
                Connection.Errorstate = true;
                Connection.Mail(rulesParameters.DownloadSource, rulesParameters.DownloadDestination);
                Connection.LogFiles();

                return null;
            }

        }
    }
}
