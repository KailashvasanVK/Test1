﻿using EmailMicroserviceCore.External.Model;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;

namespace EmailMicroserviceCore.External
{
    public class HttpClient: IHttpClient
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public HttpClient(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }
     
        public User ValidateToken(User user)
        {
            try
            {
                var client = _httpClientFactory.CreateClient();
                /*Need to move the URL to configuration
                 Incorporate Validation code*/
                client.BaseAddress = new Uri("https://localhost:44356/User/ValidateToken");
                var response = client.PostAsJsonAsync("", user).Result;
                var responseContent = response.Content.ReadAsStringAsync().Result;
                var responseObj = JsonConvert.DeserializeObject<User>(responseContent);
                return responseObj;
            }
            catch(Exception ex)
            {
                //Handle Exception
                throw ex;
            }
        }
    }
}