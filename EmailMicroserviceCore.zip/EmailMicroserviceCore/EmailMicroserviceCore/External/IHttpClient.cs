﻿using EmailMicroserviceCore.External.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmailMicroserviceCore.External
{
    public interface IHttpClient
    {
        User ValidateToken(User user);
    }
}
