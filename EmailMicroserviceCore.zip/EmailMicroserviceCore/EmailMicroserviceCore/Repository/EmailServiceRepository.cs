﻿using AutoMapper;
using EmailMicroservice.Command;
using EmailMicroservice.Models;
using EmailMicroserviceCore.Models.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmailMicroservice.Repository
{
    //This Repository is for a particular table/Entity (Example: "EmailStore").
    public class EmailServiceRepository: IEmailServiceRepository
    {
        private AhsPlatform_183Context _context;
        private DbSet<EmailStore> _emailEntity;
        private IMapper _mapper;
        EmailResponse emailResponse = null;

        public EmailServiceRepository(AhsPlatform_183Context context, IMapper mapper)
        {
            this._context = context;
            _emailEntity = context.Set<EmailStore>();
            _mapper = mapper;
            
        }
        public async Task<EmailResponse> InsertEmailRequest(SendEmailRequestCommand emailRequestCommand)
        {
            /* Automapper is used to map the command object to the Domain object. */
            try
            {
                var emsailStore = _mapper.Map<EmailStore>(emailRequestCommand);
                emailResponse = new EmailResponse();
                _context.Entry(emsailStore).State = EntityState.Added;
                var Result = await _context.SaveChangesAsync();
                emailResponse.Status = Result.ToString();
                return emailResponse;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }         
        //For Query operation, Use Automapper to map the domain object to the DTO/response object.
    }
}
