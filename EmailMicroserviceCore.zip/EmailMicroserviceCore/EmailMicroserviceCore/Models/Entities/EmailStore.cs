﻿using System;
using System.Collections.Generic;

namespace EmailMicroserviceCore.Models.Entities
{
    public partial class EmailStore
    {
        public int RequestId { get; set; }
        public string From { get; set; }
        public string To { get; set; }
        public string Body { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
    }
}
