﻿using EmailMicroservice.Models;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmailMicroservice.Command
{
    //For Query - This model is not generic. Can have seperate response type for each query.
    public class PendingDetailsResponse
    {
        public int RequestId { get; set; }
        public string From { get; set; }
        public string To { get; set; }
        public string Body { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }

        //Other details.
    }
}