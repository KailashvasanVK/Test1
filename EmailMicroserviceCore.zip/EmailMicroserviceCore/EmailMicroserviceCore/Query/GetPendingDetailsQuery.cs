﻿using EmailMicroservice.Models;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmailMicroservice.Command
{
    public class GetPendingDetailsQuery: IRequest<PendingDetailsResponse>
    {
        public int RequestId { get; set; }
        public string From { get; set; }
        public string To { get; set; }
        public string CreatedBy { get; set; }
    }
}