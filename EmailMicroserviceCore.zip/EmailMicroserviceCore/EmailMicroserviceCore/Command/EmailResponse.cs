﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmailMicroservice.Models
{
    //For Command - This is an example generic response type that can be used across all commands accordingly. 
    public class EmailResponse
    {
        public string Status { get; set; }
        public string StatusCode { get; set; }

        //The below info is optional for command operation Response type.
        public string TO { get; set; }   
        public string FROM { get; set; }
        public string Body { get; set; }
        
    }
}