﻿using EmailMicroservice.Models;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmailMicroservice.Command
{
    public class SendEmailRequestCommand: IRequest<EmailResponse>
    {
        public int RequestId { get; set; }
        public string From { get; set; }
        public string To { get; set; }
        public string Body { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
    }
}