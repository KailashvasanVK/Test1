﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MediatR;
using EmailMicroservice.Models;
using System.Threading;
using System.Threading.Tasks;
using EmailMicroservice.Repository;

namespace EmailMicroservice.Command
{
    //Sending the Emails using SMTP to be handled from the Handler. For DB operation to use the Repository.
    public class SendEmailRequestHandler: IRequestHandler<SendEmailRequestCommand, EmailResponse>
    {
        IEmailServiceRepository _emailServiceRepository;
        public SendEmailRequestHandler(IEmailServiceRepository emailServiceRepository)
        {
            _emailServiceRepository = emailServiceRepository;
        }
        public async Task<EmailResponse> Handle (SendEmailRequestCommand emailRequest, CancellationToken cancellationToekn )
        {
            try
            {
                var Result = await _emailServiceRepository.InsertEmailRequest(emailRequest);
                return Result;
            }
            catch (Exception ex)
            {
                //Log Exception
                throw ex;
            }
        }
    }
}