﻿using ControlTowerCore.Services;
using ControlTowerCore.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ControlTowerCore.Controllers
{
    [Authorize]
    [Route("api/UserConfig")]
    [ApiController]
    public class ConfigUserController : ControllerBase
    {
        private readonly IUserConfigOperations _configOperations;

        public ConfigUserController(IUserConfigOperations configOperations)
        {
            _configOperations = configOperations;
        }

        [HttpGet]
        [Route("getRemoteUsers")]
        public IActionResult GetRemoteUsers()
        {
            var result = _configOperations.GetRemoteUsers();
            return result.Count == 0 ? NoContent() : (ActionResult)Ok(result);
        }

        [HttpPost]
        [Route("addRemoteUser")]
        public IActionResult AddRemoteUser(RemoteUser remoteUser)
        {
            if (_configOperations.AddRemoteUser(remoteUser).Result)
                return Ok();
            return BadRequest("Remote user already exist!");
        }

        [HttpPut]
        [Route("updateRemoteUser")]
        public IActionResult UpdateRemoteUser(RemoteUser remoteUser)
        {
            if (_configOperations.UpdateRemoteUser(remoteUser).Result)
                return Ok();
            return BadRequest("Remote user does not exist!");

        }

        [HttpDelete]
        [Route("deleteRemoteUser/{username}")]
        public IActionResult DeleteRemoteUser(string username)
        {
            if (_configOperations.DeleteRemoteUser(username).Result)
                return Ok();
            return BadRequest("Remote user does not exist!");
        }
    }
}