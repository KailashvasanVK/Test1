﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ControlTowerCore.Services;
using ControlTowerCore.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace ControlTowerCore.Controllers
{
    [Route("api/audit")]
    [ApiController]
    public class auditController : ControllerBase
    {
        Iauditservice _audit;
        public auditController(Iauditservice audit)
        {
            _audit = audit;
        }
        [HttpPost]
        [Route("GetAuditData")]
        public IActionResult getauditData(Auditinputdata data)
        {
            var result = _audit.getauditdata(data);
            return Ok(result);
        }

    }
}