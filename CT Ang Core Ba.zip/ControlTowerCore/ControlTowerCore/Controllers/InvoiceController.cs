﻿using System;
using ControlTowerCore.Services;
using ControlTowerCore.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace ControlTowerCore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InvoiceController : ControllerBase
    {
        private readonly IInvoiceService Invoice;

        public InvoiceController(IInvoiceService _Invoice)
        {
            Invoice = _Invoice;
        }

        [HttpPost]
        [Route("GetPDFpath")]
        public IActionResult GetPDFPath(GenerateInvoice InvoiceData)
        {
            var result = Invoice.GetPDFpath(InvoiceData);
            return Ok(result);
        }
    }
}