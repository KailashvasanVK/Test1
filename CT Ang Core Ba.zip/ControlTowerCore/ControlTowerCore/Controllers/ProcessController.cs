﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ControlTowerCore.Constants;
using ControlTowerCore.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ControlTowerCore.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ProcessController : ControllerBase
    {
        private readonly IFileOperations _fileOperations;
        private readonly IProcessOperations _processOperations;

        public ProcessController(IFileOperations fileOperations, IProcessOperations processOperations)
        {
            _fileOperations = fileOperations;
            _processOperations = processOperations;
        }
        [HttpGet]
        [Route("getAllProcesses")]
        public ActionResult GetProcesses()
        {
            var result = _processOperations.GetProcesses();
            return Ok(result);
        }

        [HttpPost]
        [Route("Upload")]
        public ActionResult Upload(IFormFile file)
        {
            if (!string.IsNullOrEmpty(file.FileName))
            {
                _fileOperations.UploadFile(file);
                return Ok(new { status = file.FileName });
            }
            return Ok(new { status = false });
        }
        // PUT api/<controller>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }

        [HttpGet]
        [Route("UpdateProcessViewStatus")]
        public ActionResult UpdateProcessViewStatus(string ProcessId)
        {
            if(ProcessId != "")
            {
                _processOperations.UpdateProcessViewStatus(ProcessId);
            }
            return Ok(true);
        }
    }
}
