﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ControlTowerCore.Models;
using ControlTowerCore.Services;
using ControlTowerCore.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ControlTowerCore.Controllers
{
    [Route("api/License")]
    [ApiController]
    public class LicenseController : ControllerBase
    {
        ILicenseService service;
        public LicenseController(ILicenseService _service)
        {
            service = _service;
        }
        [HttpGet]
        [Route("Companies")]
        public IActionResult GetCompanies()
        {
            var result = service.GetCompanies();
            return Ok(result);
        }
        [HttpPost]
        [Route("GetProcessStatusdata")]
        public IActionResult GetProcessStatusdata(ProcessStatusInput ProcessInputData)
        {
            
            var result=service.GetProcessStatusdata(ProcessInputData);
            return Ok(result);

        }
        
        [HttpGet]
        [Route("ProcessType")]
        public IActionResult getProcessTypes()
        {
            var result = service.GetProcessTypes();
            return Ok(result);
        }
        [HttpGet]
        [Route("Companiesbyname/{CompanyName}")]
        public IActionResult GetCompaniesbyname(int CompanyName)
        {
            var result = service.Companiesbyname(CompanyName);
            return Ok(result);
        }
        [HttpGet]
        [Route("CompanyData/{CompanyName}")]
        public IActionResult GetComapnyData(int CompanyName)
        {
            var result = service.GetCompanyData(CompanyName);
            return Ok(result);
        }
        [HttpGet]
        [Route("CheckPrimeBot/{CompanyName}")]
        public IActionResult CheckPrimeBot(string CompanyName)
        {
            var result = service.CheckPrimeBot(CompanyName);
            return Ok(result);
        }

        [HttpGet]
        [Route("Processbyname/{CompanyName}")]
        public IActionResult GetProcessbyname(string CompanyName)
        {
            var result = service.Processbyname(CompanyName);
            return Ok(result);
        }
        [HttpGet]
        [Route("productKey/{Clientname}")]
        public IActionResult ProductKeyDetails(string Clientname)
        {
            var result = service.GetProductkeys(Clientname);
            return Ok(result);
        }
        [HttpGet]
        [Route("CheckCompany/{CompanyName}")]
        public IActionResult CheckCompany(string CompanyName)
        {
            var result = service.CheckCompany(CompanyName);
            return Ok(result);
        }
        [HttpPost]
        [Route("addCompany")]
        public IActionResult AddCompanyDetails(companyDetailsData CompanyData)
        {
            string Username = HttpContext.User.Identity.Name;
            Username = null != Username ? Username.Substring(Username.LastIndexOf(@"\") + 1) : "Application Development - Access Healthcare Services";
            if (service.Addcompanydetails(CompanyData, Username).Result)
                return Ok("{\"message\":\"Company Added Successfully!\"}");
            return BadRequest("{\"message\":\"Company already exist!\"}");

        }
        [HttpPost]
        [Route("AddBotrateDetails")]
        public IActionResult AddBotrateDetails(T_BOTRATE_DETAILS RateData)
        {
            try
            {            
            string Username = HttpContext.User.Identity.Name;
            Username = null != Username ? Username.Substring(Username.LastIndexOf(@"\") + 1) : "Application Development - Access Healthcare Services";
            if (service.AddBotrateDetails(RateData, Username))
                return Ok("{\"message\":\"RateDetails Added Successfully!\"}");
            return BadRequest("{\"message\":\"SomethingWent Wrong!\"}");
            }
            catch (Exception ex)
            {
                return BadRequest("{\"message\":\"SomethingWent Wrong!\"}");
                throw;
            }

        }
        [HttpPost]
        [Route("generateKey")]
        public IActionResult GenerateKey(Clientdata CompanyData)
        {
            var result = service.GeneratekeyforClient(CompanyData);
                return Ok(result);
            
        }
        [HttpPut]
        [Route("UpdateCompany")]
        public IActionResult UpdateCompany(companyDetailsData CompanyData)
        {
            string Username = HttpContext.User.Identity.Name;
            Username = null != Username ? Username.Substring(Username.LastIndexOf(@"\") + 1) : "Application Development - Access Healthcare Services";
            if (service.UpdateCompanyDetails(CompanyData, Username).Result)
                return Ok("{\"message\":\"Company Updated Successfully!\"}");
            return BadRequest("{\"message\":\"Company Not Exits!\"}");
        }
    }
}