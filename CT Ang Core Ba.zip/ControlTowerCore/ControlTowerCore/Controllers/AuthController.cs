﻿using ControlTowerCore.Services;
using ControlTowerCore.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Web;

namespace ControlTowerCore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : Controller
    {
        private readonly IUserService _userService;

        public AuthController(IUserService userService, IHttpContextAccessor httpContextAccessor)
        {
            _userService = userService;
        }

        [AllowAnonymous]
        [HttpPost("[action]")]
        public IActionResult Login([FromBody]UserModel login)
        {
            IActionResult response = Unauthorized();
            var user = _userService.Authenticate(login);

            if (user == null)
            {
                return BadRequest(new { message = "Username or password is incorrect" });
            }

            return Ok(new { id = 1, username = user.Username, password = string.Empty, token = user.Token });
        }

        [AllowAnonymous]
        [HttpGet("[action]")]
        public IActionResult getToken()
        {
            IActionResult response = Unauthorized();           
            var user = _userService.GenerateToken();

            if (null == user)
            {
                return BadRequest(new { message = "User is invalid" });
            }

            return Ok(new { id = 1, username = user.Username, password = string.Empty, token = user.Token });
        }

    }
}
