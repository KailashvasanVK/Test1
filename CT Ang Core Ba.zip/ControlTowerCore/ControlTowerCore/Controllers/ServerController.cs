﻿using Microsoft.AspNetCore.Mvc;
using ControlTowerCore.ViewModels;
using ControlTowerCore.Services;
using Microsoft.AspNetCore.Authorization;

namespace ControlTowerCore.Controllers
{
    [Authorize]
    [Route("api/Server")]
    [ApiController]
    public class ServerController : ControllerBase
    {
        private readonly IServerOperations _serverOperations;

        public ServerController(IServerOperations serverOperations)
        {
            _serverOperations = serverOperations;
        }

        [HttpGet]
        [Route("getAllServers")]
        public IActionResult GetServers()
        {
            var result = _serverOperations.GetServers();
            return result.Count == 0 ? NoContent() : (ActionResult)Ok(result);
        }

        [HttpPost]
        [Route("addServer")]
        public IActionResult AddServer(Server dataServer)
        {
            if (_serverOperations.AddServer(dataServer).Result)
                return Ok();
            return BadRequest("Server already exist!");
        }

        [HttpPut]
        [Route("updateServer")]
        public IActionResult UpdateServer(Server dataServer)
        {
            if (_serverOperations.UpdateServer(dataServer).Result)
                return Ok();
            return BadRequest("Server does not exist!");

        }

        [HttpDelete]
        [Route("deleteServer/{ip}")]
        public IActionResult DeleteServer(string ip)
        {
            if (_serverOperations.DeleteServer(ip).Result)
                return Ok();
            return BadRequest("Server does not exist!");
        }

    }
}