﻿using ControlTowerCore.Services;
using ControlTowerCore.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ControlTowerCore.Controllers
{
    [Authorize]
    [Route("api/Dashboard")]
    [ApiController]
    public class DashboardController : ControllerBase
    {
        private readonly IDashboardService _dashService;

        public DashboardController(IDashboardService dashboardService)
        {
            _dashService = dashboardService;
        }

        [HttpGet]
        [Route("getDashData")]
        public IActionResult GetDashboardData()
        {
            var result = _dashService.GetDashboardData();
            return result == null ? NoContent() : (ActionResult)Ok(result);
        }

        [HttpGet]
        [Route("getBotsData")]
        public IActionResult GetBotDetails()
        {
            var result = _dashService.GetBotsStatus();
            return result.Count == 0 ? NoContent() : (ActionResult)Ok(result);
        }

        [HttpGet]
        [Route("getBotsRunningStatus")]
        public IActionResult GetBotsRunningStatus()
        {
            var result = _dashService.GetBotsRunningStatus();
            return result.Count == 0 ? NoContent() : (ActionResult)Ok(result);
        }

        [HttpPost]
        [Route("getBotsServerDetails")]
        public IActionResult GetBotsServerDetails([FromBody]string processName)
        {
            var result = _dashService.GetBotsServerDetails(processName);
            return result.Count == 0 ? NoContent() : (ActionResult)Ok(result);
        }

        [HttpPost]
        [Route("UpdateActiveStatus")]
        public IActionResult UpdateActiveStatus([FromBody]string TaskName)
        {
            var result = _dashService.UpdateActiveStatus(TaskName);
            return Ok(true);
        }

        [HttpPost]
        [Route("getBotsServerRunningStatus")]
        public IActionResult GetBotsServersRunningStatus(BotsServersInput inputData)
        {
            var result = _dashService.GetBotsServerRunningStatus(inputData);
            return result == null ? NoContent() : (ActionResult)Ok(result);
        }

        [HttpPost]
        [Route("getBotMonitoringData")]
        public IActionResult GetBotsMonitoringStatus(EyeViewInput input)
        {
            var result = _dashService.GetBotMonitoringStatus(input);
            return result.Count == 0 ? NoContent() : (ActionResult)Ok(result);
        }

        [HttpPost]
        [Route("getTransactionDetails")]
        public IActionResult GetTransactionDetails([FromBody]int type)
        {
            var result = _dashService.GetTransactionDetails(type);
            return result.Count == 0 ? NoContent() : (ActionResult)Ok(result);
        }

        [HttpPost]
        [Route("getTransactionProcess")]
        public IActionResult GetTransactionProcess([FromBody]string processName)
        {
            var result = _dashService.GetProcessTransactions(processName);
            return result.Length == 0 ? NoContent() : (ActionResult)Ok(result);
        }
    }
}