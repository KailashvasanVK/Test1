﻿using ControlTowerCore.Services;
using ControlTowerCore.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace ControlTowerCore.Controllers
{
    [Authorize]
    [Route("api/Schedule")]
    [ApiController]
    public class ScheduleController : ControllerBase
    {
        private readonly ISchedulerOperations _schedulerService;
        private readonly IFileOperations _fileService;
        private readonly ITaskService _taskService;

        public ScheduleController(ISchedulerOperations schedulerService, IFileOperations fileService, ITaskService taskService)
        {
            this._schedulerService = schedulerService;
            this._fileService = fileService;
            this._taskService = taskService;
        }

        [HttpGet]
        [Route("getAllSchedules")]
        public IActionResult GetSchedules()
        {
            var result = _schedulerService.GetSchedules();
            return result.Count == 0 ? NoContent() : (ActionResult)Ok(result);
        }

        [HttpGet]
        [Route("getScheduleInputs")]
        public IActionResult GetScheduleInputs()
        {
            var result = _schedulerService.GetSchedulerInputs();
            return result == null ? NoContent() : (ActionResult)Ok(result);
        }

        [HttpPost]
        [Route("getDrives")]
        public IActionResult GetTargetDrives(ScheduledBotsViewModel task)
        {
            var result = _fileService.GetDrives(task);
            return result.Count == 0 ? NoContent() : (ActionResult)Ok(result);
        }

        [HttpPost]
        [Route("addTask")]
        public IActionResult CreateNewTask(ScheduledBotsViewModel task)
        {
            if (_schedulerService.AddSchedule(task).Result)
                return Ok();
            return BadRequest("Task creation failed. Try again later.");
        }

        [HttpPut]
        [Route("updateTask")]
        public IActionResult UpdateTask(ScheduledBotsViewModel task)
        {
            if (_schedulerService.UpdateSchedule(task).Result)
                return Ok();
            return BadRequest("Task update failed. Try again later.");
        }

        [HttpPut]
        [Route("deleteTask")]
        public IActionResult DeleteTask(ScheduledBotsViewModel task)
        {
            if (_schedulerService.DeleteSchedule(task))
                return Ok();
            return BadRequest("Task doesnot exist.");
        }

        [HttpPost]
        [Route("modifySchedule")]
        public IActionResult ModifySchedule(ModifyTasks tasks)
        {
            Tuple<bool, string> result = _taskService.modifySchedule(tasks);
            if (result.Item1)
                return Ok("Success");
            return BadRequest(result.Item2);
        }
    }
}