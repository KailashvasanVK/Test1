﻿using System;
using System.Collections.Generic;

namespace ControlTowerCore.Models
{
    public partial class CtScheduler
    {
        public int Id { get; set; }
        public int? ProcessId { get; set; }
        public int? UserId { get; set; }
        public string TaskName { get; set; }
        public string Description { get; set; }
        public string HostName { get; set; }
        public string Repetitionmode { get; set; }
        public DateTime? StartDateTime { get; set; }
        public int? RepetationInterval { get; set; }
        public string WeekDays { get; set; }
        public string DaysOfMonth { get; set; }
        public string MonthOfYear { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string CustomField { get; set; }
        public bool? RunOnLastDayOfMonth { get; set; }
        public string UserName { get; set; }
        public string ServerIp { get; set; }
        public string TargetDrive { get; set; }
        public string TokenKey { get; set; }
        public Guid? BotClientId { get; set; }
        public string Status { get; set; }
        public DateTime? LastRunTime { get; set; }
        public DateTime? NextRunTime { get; set; }
        public string ScheduleStatus { get; set; }
    }
}
