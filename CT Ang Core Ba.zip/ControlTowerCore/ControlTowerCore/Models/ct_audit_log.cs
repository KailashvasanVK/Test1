﻿using System;

namespace ControlTowerCore.Models
{
    public class ct_audit_log
    {
        public int id { get; set; }
        public string category { get; set; }
        public string user { get; set; }
        public string action { get; set; }
        public DateTime time { get; set; }
    }
}