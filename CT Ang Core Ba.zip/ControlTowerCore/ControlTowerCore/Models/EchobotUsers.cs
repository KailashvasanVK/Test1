﻿using System;
using System.Collections.Generic;

namespace ControlTowerCore.Models
{
    public partial class EchobotUsers
    {
        public EchobotUsers()
        {
            EchobotUserClaims = new HashSet<EchobotUserClaims>();
            EchobotUserLogins = new HashSet<EchobotUserLogins>();
            EchobotUserRoles = new HashSet<EchobotUserRoles>();
        }

        public string UserId { get; set; }
        public string Email { get; set; }
        public bool EmailConfirmed { get; set; }
        public string PasswordHash { get; set; }
        public string SecurityStamp { get; set; }
        public string PhoneNumber { get; set; }
        public bool PhoneNumberConfirmed { get; set; }
        public bool TwoFactorEnabled { get; set; }
        public DateTime? LockoutEndDateUtc { get; set; }
        public bool LockoutEnabled { get; set; }
        public int AccessFailedCount { get; set; }
        public string UserName { get; set; }
        public string Discriminator { get; set; }

        public ICollection<EchobotUserClaims> EchobotUserClaims { get; set; }
        public ICollection<EchobotUserLogins> EchobotUserLogins { get; set; }
        public ICollection<EchobotUserRoles> EchobotUserRoles { get; set; }
    }
}
