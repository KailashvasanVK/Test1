﻿using System;
using System.Collections.Generic;

namespace ControlTowerCore.Models
{
    public partial class echobot_lic_companyDetails
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string ContactEmailId { get; set; }
        public string ContactMobile { get; set; }
        public DateTime ValidFrom { get; set; }
        public DateTime ValidTo { get; set; }
        public int BotInstances { get; set; }
        public bool Status { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? LicenseType { get; set; }
        public int? No_WorkFlows { get; set; }
        public int? No_Bots { get; set; }
        public decimal? Bot_Rate { get; set; }
        public decimal? Prime_Bot_Rate { get; set; }
        public int? Rate_Base { get; set; }
        public decimal? Rate { get; set; }
        public int? Maintenance_Hours { get; set; }
        public decimal? Maintenance_Rate { get; set; }
        public string ProcessName { get; set; }




    }
}
