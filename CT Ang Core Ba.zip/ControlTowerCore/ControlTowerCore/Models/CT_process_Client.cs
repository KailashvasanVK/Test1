﻿using System;

namespace ControlTowerCore.Models
{
    public class CT_process_Client
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Status { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string UserName { get; set; }
        public string ExeName { get; set; }
        public string FileName { get; set; }
        public string Address { get; set; }
        public string Contact_Mobile { get; set; }
        public int Bot_Instance { get; set; }
        public Guid processID { get; set; }
    }
   }