﻿using System;
using System.Collections.Generic;

namespace ControlTowerCore.Models
{
    public partial class echobot_lic_clientSide
    {
        public int Id { get; set; }
        public string SerialKey { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
    }
}
