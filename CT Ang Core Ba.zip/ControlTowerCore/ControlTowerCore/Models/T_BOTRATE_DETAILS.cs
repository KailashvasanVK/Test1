﻿using System;

namespace ControlTowerCore.Models
{
    public class T_BOTRATE_DETAILS
    {
        public int ID { get; set; }
        public int ProcessId { get; set; }
        public string LicenceType { get; set; }
        public int YearlyCost { get; set; }
        public int MonthlyCost { get; set; }
        public int Bot { get; set; }
        public decimal Botrate { get; set; }
        public int PrimeBot { get; set; }
        public int PrimeBotRate { get; set; }
        public string RateType { get; set; }
        public int Rate { get; set; }
        public string MaintenanceHours { get; set; }
        public int MaintenanceRate { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string ModifiedBy { get; set; }
        public int? No_of_Workfolws { get; set; }
        public int? No_of_Bots { get; set; }
        public long AmortizeMonth { get; set; }       

    }
    
}