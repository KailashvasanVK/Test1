﻿using System;
using System.Collections.Generic;

namespace ControlTowerCore.Models
{
    public partial class echobot_lic_botClient
    {
        public Guid Id { get; set; }
        public Guid CompanyId { get; set; }
        public int MachineId { get; set; }
        public string MachineName { get; set; }
        public DateTime CreatedOn { get; set; }
        public bool Status { get; set; }
        public DateTime ModifiedOn { get; set; }
    }
}
