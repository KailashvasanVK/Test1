﻿using System;
using System.Collections.Generic;

namespace ControlTowerCore.Models
{
    public partial class CtProjectUsage
    {
        public int Id { get; set; }
        public string Project { get; set; }
        public string Process { get; set; }
        public string SubProcess { get; set; }
        public string Team { get; set; }
        public string SubTeam { get; set; }
        public string Location { get; set; }
        public string Facility { get; set; }
        public string UserName { get; set; }
        public DateTime? Date { get; set; }
        public int? UsageCount { get; set; }
        public string CustomField { get; set; }
        public string Status { get; set; }
        public int? Count { get; set; }
    }
}
