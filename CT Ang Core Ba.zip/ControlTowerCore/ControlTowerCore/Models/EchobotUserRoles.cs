﻿using System;
using System.Collections.Generic;

namespace ControlTowerCore.Models
{
    public partial class EchobotUserRoles
    {
        public string UserId { get; set; }
        public string RoleId { get; set; }
        public string IdentityUserId { get; set; }

        public EchobotUsers IdentityUser { get; set; }
        public EchobotRoles Role { get; set; }
    }
}
