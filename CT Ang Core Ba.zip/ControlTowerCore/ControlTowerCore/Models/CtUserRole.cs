﻿using System;
using System.Collections.Generic;

namespace ControlTowerCore.Models
{
    public partial class CtUserRole
    {
        public int Id { get; set; }
        public int? UserId { get; set; }
        public int? RoleId { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string Status { get; set; }
        public string ModifiedBy { get; set; }
    }
}
