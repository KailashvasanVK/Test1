﻿using System;
using System.Collections.Generic;

namespace ControlTowerCore.Models
{
    public partial class CtTransactions
    {
        public int ID { get; set; }
        public string LOB { get; set; }
        public string Process { get; set; }
        public int Transacations { get; set; }
        public DateTime Date { get; set; }
    }
}
