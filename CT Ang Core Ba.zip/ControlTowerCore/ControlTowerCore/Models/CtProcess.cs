﻿using System;
using System.Collections.Generic;

namespace ControlTowerCore.Models
{
    public partial class CtProcess
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Status { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string UserName { get; set; }
        public string ExeName { get; set; }
        public string FileName { get; set; }
        public Guid? ProcessId { get; set; }
        public string ProcessType { get; set; }
    }
}
