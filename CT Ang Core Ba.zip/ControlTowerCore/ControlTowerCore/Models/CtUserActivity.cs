﻿using System;
using System.Collections.Generic;

namespace ControlTowerCore.Models
{
    public partial class CtUserActivity
    {
        public int Id { get; set; }
        public string Message { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string UserName { get; set; }
        public string Module { get; set; }
    }
}
