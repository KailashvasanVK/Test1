﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace ControlTowerCore.Models
{
    public partial class AhsPlatformContext : DbContext
    {
        public AhsPlatformContext()
        {
        }

        public AhsPlatformContext(DbContextOptions<AhsPlatformContext> options)
            : base(options)
        {
        }

        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    modelBuilder.Entity<T_BOTRATE_DETAILS>().Property(obect => obect.Botrate).HasColumnType("decimal(18, 3)"); 

        //    base.OnModelCreating(modelBuilder);
        //}

        public virtual DbSet<CtBotRunningStatus> CtBotRunningStatus { get; set; }
        public virtual DbSet<CtBotStatus> CtBotStatus { get; set; }
        public virtual DbSet<CtBotStatusLog> CtBotStatusLog { get; set; }
        public virtual DbSet<CtPageAccess> CtPageAccess { get; set; }
        public virtual DbSet<CtPages> CtPages { get; set; }
        public virtual DbSet<CtProcess> CtProcess { get; set; }
        public virtual DbSet<CtProjectUsage> CtProjectUsage { get; set; }
        public virtual DbSet<CtRoles> CtRoles { get; set; }
        public virtual DbSet<CtScheduler> CtScheduler { get; set; }
        public virtual DbSet<CtSchedulerLog> CtSchedulerLog { get; set; }
        public virtual DbSet<CtServers> CtServers { get; set; }
        public virtual DbSet<CtUser> CtUser { get; set; }
        public virtual DbSet<CtUserActivity> CtUserActivity { get; set; }
        public virtual DbSet<CtUserRole> CtUserRole { get; set; }
        public virtual DbSet<CtTransactions> CtTransactions { get; set; }
        public virtual DbSet<echobot_lic_companyDetails> echobot_lic_companyDetails { get; set; }
        public virtual DbSet<CT_process_Client> ct_Process_Client { get; set; }
        public virtual DbSet<echobot_LicenseType> echobot_LicenseType { get; set; }
        public virtual DbSet<echobot_lic_botClient> echobot_lic_botClient { get; set; }
        public virtual DbSet<echobot_lic_clientcompanyDetails> echobot_lic_clientcompanyDetails { get; set; }
        public virtual DbSet<echobot_lic_clientSide> echobot_lic_clientSide { get; set; }
        public virtual DbSet<T_BOTRATE_DETAILS> t_Botrate_Details { get; set; }
        public virtual DbSet<echobot_lic_company> echobot_lic_company { get; set; }
        public virtual DbSet<echobot_lic_controlTowerInfo> echobot_lic_controlTowerInfo { get; set; }
        public virtual DbSet<echobot_lic_exceptions> echobot_lic_exceptions { get; set; }
        public virtual DbSet<echobot_lic_process> echobot_lic_process { get; set; }
        public virtual DbSet<echobot_lic_processTransaction> echobot_lic_processTransaction { get; set; }
        public virtual DbSet<echobot_LicenseSlab> echobot_LicenseSlab { get; set; }
        public virtual DbSet<CT_Transactions_Testing> CT_Transactions_Testing { get; set; }
        public virtual DbSet<CT_LiveProcess> CT_LiveProcess { get; set; }
        public virtual DbSet<T_BOTRATE_DETAILS_AUDIT> t_Botrate_Details_Audit { get; set; }
        public virtual DbSet<ct_audit_log> ct_audit_log { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Server=ahs-hq-devdb,30786;Database=AhsPlatform;integrated security=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<CtBotRunningStatus>(entity =>
            {
                entity.ToTable("CT_BotRunningStatus");

                entity.Property(e => e.Name)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CtBotStatus>(entity =>
            {
                entity.ToTable("CT_BotStatus");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Author)
                    .HasMaxLength(350)
                    .IsUnicode(false);

                entity.Property(e => e.BotName)
                    .HasMaxLength(350)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.EndTime).HasColumnType("datetime");

                entity.Property(e => e.MachineIp)
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.ProcessName)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.StartTime).HasColumnType("datetime");

                entity.Property(e => e.SubProcessName)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .HasMaxLength(350)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CtBotStatusLog>(entity =>
            {
                entity.ToTable("CT_BotStatusLog");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Message).IsUnicode(false);

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Status)
                    .HasMaxLength(650)
                    .IsUnicode(false);

                entity.Property(e => e.TokenKey)
                    .HasMaxLength(1850)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .HasMaxLength(650)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CtPageAccess>(entity =>
            {
                entity.ToTable("CT_PageAccess");

                entity.Property(e => e.CanDelete).HasDefaultValueSql("((0))");

                entity.Property(e => e.CanRead).HasDefaultValueSql("((0))");

                entity.Property(e => e.CanWrite).HasDefaultValueSql("((0))");

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy)
                    .HasMaxLength(350)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.Status)
                    .HasMaxLength(150)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CtPages>(entity =>
            {
                entity.ToTable("CT_Pages");

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.MenuCaption)
                    .HasMaxLength(650)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .HasMaxLength(650)
                    .IsUnicode(false);

                entity.Property(e => e.Status)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Url)
                    .HasColumnName("URL")
                    .HasMaxLength(650)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CtProcess>(entity =>
            {
                entity.ToTable("CT_Process");

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.ExeName)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.FileName)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.ProcessId).HasColumnName("processID");

                entity.Property(e => e.Status)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CtProjectUsage>(entity =>
            {
                entity.ToTable("CT_ProjectUsage");

                entity.Property(e => e.CustomField).IsUnicode(false);

                entity.Property(e => e.Date).HasColumnType("datetime");

                entity.Property(e => e.Facility)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.Location)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.Process)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.Project)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.Status)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.SubProcess)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.SubTeam)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.Team)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CtRoles>(entity =>
            {
                entity.ToTable("CT_Roles");

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .HasMaxLength(650)
                    .IsUnicode(false);

                entity.Property(e => e.Status)
                    .HasMaxLength(150)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CtScheduler>(entity =>
            {
                entity.ToTable("CT_Scheduler");

                entity.Property(e => e.BotClientId).HasColumnName("botClientID");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.CustomField).IsUnicode(false);

                entity.Property(e => e.DaysOfMonth)
                    .HasMaxLength(2050)
                    .IsUnicode(false);

                entity.Property(e => e.Description)
                    .HasMaxLength(3050)
                    .IsUnicode(false);

                entity.Property(e => e.HostName)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.MonthOfYear)
                    .HasMaxLength(2050)
                    .IsUnicode(false);

                entity.Property(e => e.Repetitionmode)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ServerIp)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.StartDateTime).HasColumnType("datetime");

                entity.Property(e => e.TargetDrive)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TaskName)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.TokenKey)
                    .HasMaxLength(1250)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.WeekDays)
                    .HasMaxLength(2050)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CtSchedulerLog>(entity =>
            {
                entity.ToTable("CT_SchedulerLog");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.CustomField).IsUnicode(false);

                entity.Property(e => e.DaysOfMonth)
                    .HasMaxLength(2050)
                    .IsUnicode(false);

                entity.Property(e => e.Description)
                    .HasMaxLength(3050)
                    .IsUnicode(false);

                entity.Property(e => e.HostName)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.MonthOfYear)
                    .HasMaxLength(2050)
                    .IsUnicode(false);

                entity.Property(e => e.Repetitionmode)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ServerIp)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.StartDateTime).HasColumnType("datetime");

                entity.Property(e => e.TargetDrive)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TaskName)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.TokenKey)
                    .HasMaxLength(1250)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.WeekDays)
                    .HasMaxLength(2050)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CtServers>(entity =>
            {
                entity.ToTable("CT_Servers");

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.IpAddress)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MachineName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.Status)
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CtUser>(entity =>
            {
                entity.ToTable("CT_User");

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.Domain)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.Email)
                    .HasMaxLength(650)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .HasMaxLength(550)
                    .IsUnicode(false);

                entity.Property(e => e.FullName)
                    .HasMaxLength(650)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasMaxLength(550)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.NtLogin)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.Status)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CtUserActivity>(entity =>
            {
                entity.ToTable("CT_UserActivity");

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.Message).IsUnicode(false);

                entity.Property(e => e.Module)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CtUserRole>(entity =>
            {
                entity.ToTable("CT_UserRole");

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy)
                    .HasMaxLength(350)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.Status)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CtTransactions>(entity =>
            {
                entity.ToTable("CT_Transactions");

                entity.Property(e => e.Date).HasColumnType("datetime");
            });
            modelBuilder.Entity<T_BOTRATE_DETAILS>(entity =>
            {
                entity.ToTable("t_Botrate_Details");

                entity.Property(e => e.Botrate).HasColumnType("decimal(18,3)");
            });
            
        }
    }

   
}
