﻿using System;
using System.Collections.Generic;

namespace ControlTowerCore.Models
{
    public partial class CtBotStatusLog
    {
        public int Id { get; set; }
        public string TokenKey { get; set; }
        public string Status { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string UserName { get; set; }
        public string Message { get; set; }
    }
}
