﻿using System;
using System.Collections.Generic;

namespace ControlTowerCore.Models
{
    public partial class CtPageAccess
    {
        public int Id { get; set; }
        public int? RoleId { get; set; }
        public int? PageId { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string Status { get; set; }
        public bool? CanRead { get; set; }
        public bool? CanWrite { get; set; }
        public bool? CanDelete { get; set; }
        public string ModifiedBy { get; set; }
    }
}
