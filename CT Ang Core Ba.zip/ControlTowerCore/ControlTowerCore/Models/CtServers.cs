﻿using System;
using System.Collections.Generic;

namespace ControlTowerCore.Models
{
    public partial class CtServers
    {
        public int Id { get; set; }
        public string IpAddress { get; set; }
        public string MachineName { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string Status { get; set; }
        public string UserName { get; set; }
        public int? ServerType { get; set; }
    }
}
