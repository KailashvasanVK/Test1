﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ControlTowerCore.Models
{
    public class CT_LiveProcess
    {
        [Key]
        public int ProcessID { get; set; }
        public string ProcessName { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public string WindowName { get; set; }

    }
}
