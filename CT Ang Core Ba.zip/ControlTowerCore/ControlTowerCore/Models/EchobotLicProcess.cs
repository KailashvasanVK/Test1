﻿using System;
using System.Collections.Generic;

namespace ControlTowerCore.Models
{
    public partial class echobot_lic_process
    {
        public Guid Id { get; set; }
        public Guid CompanyId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime CreatedOn { get; set; }
    }
}
