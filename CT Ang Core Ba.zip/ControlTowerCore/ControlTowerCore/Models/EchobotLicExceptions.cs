﻿using System;
using System.Collections.Generic;

namespace ControlTowerCore.Models
{
    public partial class echobot_lic_exceptions
    {
        public int Id { get; set; }
        public Guid ProcessId { get; set; }
        public Guid BotClientId { get; set; }
        public string ErrorMessage { get; set; }
        public string ErrorEvent { get; set; }
        public DateTime ErrorTime { get; set; }
    }
}
