﻿using System;
using System.Collections.Generic;

namespace ControlTowerCore.Models
{
    public partial class echobot_LicenseType
    {
        public int Id { get; set; }
        public string LicenseType { get; set; }

    }
}
