﻿using System;
using System.Collections.Generic;

namespace ControlTowerCore.Models
{
    public partial class echobot_lic_processTransaction
    {
        public int Id { get; set; }
        public Guid ProcessId { get; set; }
        public Guid BotClientId { get; set; }
        public string DomainName { get; set; }
        public string UserName { get; set; }
        public string ReferenceId { get; set; }
        public DateTime EventStart { get; set; }
        public DateTime EventEnd { get; set; }
        public int? Status { get; set; }
    }
}
