﻿using System;
using System.Collections.Generic;

namespace ControlTowerCore.Models
{
    public partial class echobot_lic_clientcompanyDetails
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string ContactEmailId { get; set; }
        public string ContactMobile { get; set; }
        public DateTime ValidFrom { get; set; }
        public DateTime ValidTo { get; set; }
        public int BotInstances { get; set; }
        public bool Status { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }

        
    }
}
