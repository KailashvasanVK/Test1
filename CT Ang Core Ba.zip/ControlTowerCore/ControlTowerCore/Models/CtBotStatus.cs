﻿using System;
using System.Collections.Generic;

namespace ControlTowerCore.Models
{
    public partial class CtBotStatus
    {
        public int Id { get; set; }
        public string MachineIp { get; set; }
        public string BotName { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public int? StatusId { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string UserName { get; set; }
        public string Author { get; set; }
        public string ProcessName { get; set; }
        public string SubProcessName { get; set; }
    }
}
