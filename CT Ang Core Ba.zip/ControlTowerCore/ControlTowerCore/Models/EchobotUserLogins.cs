﻿using System;
using System.Collections.Generic;

namespace ControlTowerCore.Models
{
    public partial class EchobotUserLogins
    {
        public string LoginProvider { get; set; }
        public string ProviderKey { get; set; }
        public string UserId { get; set; }
        public string IdentityUserId { get; set; }

        public EchobotUsers IdentityUser { get; set; }
    }
}
