﻿using System;
using System.Collections.Generic;

namespace ControlTowerCore.Models
{
    public partial class EchobotRoles
    {
        public EchobotRoles()
        {
            EchobotUserRoles = new HashSet<EchobotUserRoles>();
        }

        public string Id { get; set; }
        public string Name { get; set; }

        public ICollection<EchobotUserRoles> EchobotUserRoles { get; set; }
    }
}
