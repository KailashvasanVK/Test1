﻿using System;
using System.Collections.Generic;

namespace ControlTowerCore.Models
{
    public partial class echobot_LicenseSlab
    {
        public int Id { get; set; }
        public int NoOfWorkflows { get; set; }
        public string NoOfBots { get; set; }
    }
}
