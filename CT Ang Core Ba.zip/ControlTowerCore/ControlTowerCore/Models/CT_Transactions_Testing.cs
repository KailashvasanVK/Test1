﻿using System;

namespace ControlTowerCore.Models
{
   
    public partial class CT_Transactions_Testing
    {
        public int ID { get; set; }
        public string LOB { get; set; }
        public string Process { get; set; }
        public int Transacations { get; set; }
        public DateTime Date { get; set; }
    }
}