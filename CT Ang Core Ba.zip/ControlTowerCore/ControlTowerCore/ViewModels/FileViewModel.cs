﻿namespace ControlTowerCore.ViewModels
{
    public class TargetDrives
    {
        private string _drive;
        private string _freeSpace;
        private decimal _freeSpacePercent;
        private string _totalSpace;
        private decimal _usedSpacePercent;
        private bool _selectedDrive;
        private bool _processFolderExist;

        public string Drive { get => _drive; set => _drive = value; }
        public string FreeSpace { get => _freeSpace; set => _freeSpace = value; }
        public decimal FreeSpacePercent { get => _freeSpacePercent; set => _freeSpacePercent = value; }
        public string TotalSpace { get => _totalSpace; set => _totalSpace = value; }
        public decimal UsedSpacePercent { get => _usedSpacePercent; set => _usedSpacePercent = value; }
        public bool SelectedDrive { get => _selectedDrive; set => _selectedDrive = value; }
        public bool ProcessFolderExist { get => _processFolderExist; set => _processFolderExist = value; }
    }
}