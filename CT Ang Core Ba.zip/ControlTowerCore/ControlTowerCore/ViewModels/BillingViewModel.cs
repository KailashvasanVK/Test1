﻿using ControlTowerCore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ControlTowerCore.ViewModels
{
    public class BillingViewModel
    {
        public int InvoiceNumber { get; set; }
        public echobot_lic_clientcompanyDetails CompanyDetails { get; set; }
        public BillItems BillDetails { get; set; }
        public int Subtotal { get; set; }
        public int Tax { get; set; }
        public int Total { get; set; }
        public int AmountDue { get; set; }
    }
}
