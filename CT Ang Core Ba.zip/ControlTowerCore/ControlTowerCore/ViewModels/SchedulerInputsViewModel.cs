﻿using System.Collections.Generic;

namespace ControlTowerCore.ViewModels
{
    public class SchedulerInputsViewModel
    {
        private IList<ServerInputs> _serverData;
        private IList<ProcessInputs> _processData;
        private IList<UserInputs> _userData;

        public IList<ServerInputs> ServerData { get => _serverData; set => _serverData = value; }
        public IList<ProcessInputs> ProcessData { get => _processData; set => _processData = value; }
        public IList<UserInputs> UserData { get => _userData; set => _userData = value; }
    }

    public class ProcessInputs
    {
        private int _processId;
        private string _processName;

        public int ProcessId { get => _processId; set => _processId = value; }
        public string ProcessName { get => _processName; set => _processName = value; }
    }

    public class ServerInputs
    {
        private int _serverId;
        private string _serverName;

        public int ServerId { get => _serverId; set => _serverId = value; }
        public string ServerName { get => _serverName; set => _serverName = value; }
    }

    public class UserInputs
    {
        private int _userId;
        private string _userName;

        public int UserId { get => _userId; set => _userId = value; }
        public string UserName { get => _userName; set => _userName = value; }
    }

    public class ModifyTasks
    {
        private string _schedulerName;
        private int _type;

        public string SchedulerName { get => _schedulerName; set => _schedulerName = value; }
        public int Type { get => _type; set => _type = value; }
    }
}
