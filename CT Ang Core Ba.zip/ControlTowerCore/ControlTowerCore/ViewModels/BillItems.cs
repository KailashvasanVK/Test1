﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ControlTowerCore.ViewModels
{
    public class BillItems
    {
        public string Description { get; set; }
        public string UnitCost { get; set; }
        public string Quantity { get; set; }
        public string Amount { get; set; }
    }
}
