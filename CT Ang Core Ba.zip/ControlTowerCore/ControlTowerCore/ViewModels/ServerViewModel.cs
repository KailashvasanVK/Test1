﻿using System;

namespace ControlTowerCore.ViewModels
{
    public class Server
    {
        private int _sno;
        private string _serverIp;
        private string _serverName;
        private string _serverType;
        private DateTime _createdDate;
        private DateTime _modifiedDate;

        public int Sno { get => _sno; set => _sno = value; }
        public string ServerIp { get => _serverIp; set => _serverIp = value; }
        public string ServerName { get => _serverName; set => _serverName = value; }
        public string ServerType { get => _serverType; set => _serverType = value; }
        public DateTime CreatedDate { get => _createdDate; set => _createdDate = value; }
        public DateTime ModifiedDate { get => _modifiedDate; set => _modifiedDate = value; }
    }
}
