﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ControlTowerCore.ViewModels
{
    public class LicenceModel
    {

    }
    public class AllCompany
    {
        public int value { get; set; }

        public string viewValue { get; set; }
    }

    public class Invoicedata
    {
        public string EmailId { get; set; }

        public string Address { get; set; }
        public int? LicenceType { get; set; }

        public string CompanyName { get; set; }

    }
    public class CompanyData
    {
        public string EmailId { get; set; }

        public string address { get; set; }


        public string MobileNo { get; set; }

        public int BotInstance { get; set; }
    }
    public class companyDetails
    {
        public string EmailId { get; set; }

        public string address { get; set; }

        public string MobileNo { get; set; }

        public int BotInstance { get; set; }
        public string LicenceType { get; set; }
        public long YearlyCost { get; set; }
        public long MonthlyCost { get; set; }
        public long Bot { get; set; }
        public decimal Botrate { get; set; }
        public long PrimeBot { get; set; }
        public long PrimeBotRate { get; set; }
        public string RateBased { get; set; }
        public long OptionRate { get; set; }
        public string Maintenance { get; set; }
        public long MaintenanceRate { get; set; }
        public int? No_of_Workfolws { get; set; }
        public int? No_of_Bots { get; set; }

        public long? AmortizeMonth { get; set; }


    }
    public class ProductKeyDetails
    {
        public string ClientName { get; set; }

        public string ProcessName { get; set; }

        public string ClientId { get; set; }

        public string ProcessId { get; set; }
        public string flag { get; set; }



    }
    public class Companyavailable
    {
        public string Status { get; set; }

        public string result { get; set; }


    }
    public class ProcessstatusOutput
    {
        public string name { get; set; }

        public string processType { get; set; }
        public string Status { get; set; }
        public DateTime CreatedDate { get; set; }       


    }

    public class PdfPath
    {

        public string Path { get; set; }


    }

    public class GenerateInvoice
    {

        public DateTime date { get; set; }
        public string CompanyName { get; set; }
        public int ProcessId { get; set; }



    }
    public class companyDetailsData
    {
        public string CompanyName { get; set; }

        public string ProcessName { get; set; }
        public string EmailId { get; set; }

        public string address { get; set; }

        public string MobileNo { get; set; }

        public int BotInstance { get; set; }


    }
    public class Clientdata
    {
        public string ClientName { get; set; }
        public string ProcessName { get; set; }

    }
    public class ProcessStatusInput
    {
        public string ProcessType { get; set; }
        public string Status { get; set; }

    }

}
