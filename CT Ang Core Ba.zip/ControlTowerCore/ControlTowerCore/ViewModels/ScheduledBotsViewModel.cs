﻿using System;

namespace ControlTowerCore.ViewModels
{
    public class ProcessViewModel
    {
        private int _id;
        private string _name;
        private DateTime? _createdDate;
        private DateTime? _modifiedDate;
        private string _userName;
        private string _exeName;
        private string _fileName;
        private Guid? _processId;

        public int Id { get => _id; set => _id = value; }
        public string Name { get => _name; set => _name = value; }
        public DateTime? CreatedDate { get => _createdDate; set => _createdDate = value; }
        public DateTime? ModifiedDate { get => _modifiedDate; set => _modifiedDate = value; }
        public string UserName { get => _userName; set => _userName = value; }
        public string ExeName { get => _exeName; set => _exeName = value; }
        public string FileName { get => _fileName; set => _fileName = value; }
        public Guid? ProcessID { get => _processId; set => _processId = value; }
    }
    public class ScheduledBotsViewModel
    {
        private string _description;
        private string _schedulerName;
        private int _idProcess;
        private string _processName;
        private int _idUser;
        private string _userName;
        private string _password;
        private int _idMachine;
        private string _machineIp;
        private int _machineType;
        private string _mode;
        private string _targetDrive;
        private TaskViewModel _taskInputs;

        public string SchedulerName { get => _schedulerName; set => _schedulerName = value; }
        public string Description { get => _description; set => _description = value; }
        public string MachineIP { get => _machineIp; set => _machineIp = value; }
        public int MachineType { get => _machineType; set => _machineType = value; }
        public int IdMachine { get => _idMachine; set => _idMachine = value; }
        public string ProcessName { get => _processName; set => _processName = value; }
        public int IdProcess { get => _idProcess; set => _idProcess = value; }
        public string UserName { get => _userName; set => _userName = value; }
        public string Password { get => _password; set => _password = value; }
        public int IdUser { get => _idUser; set => _idUser = value; }
        public string Mode { get => _mode; set => _mode = value; }
        public string TargetDrive { get => _targetDrive; set => _targetDrive = value; }
        public TaskViewModel TaskInputs { get => _taskInputs; set => _taskInputs = value; }
    }

    public class TaskViewModel
    {
        private string _exeName;
        private DateTime _startDateTime;
        private int _repetitionInterval;
        private string[] _weekdays;
        private string[] _daysOfMonth;
        private string[] _monthOfYear;
        private bool _runOnLastDayOfMonth;

        public string ExeName { get => _exeName; set => _exeName = value; }
        public DateTime StartDateTime { get => _startDateTime; set => _startDateTime = value; }
        public int RepetitionInterval { get => _repetitionInterval; set => _repetitionInterval = value; }
        public string[] WeekDays { get => _weekdays; set => _weekdays = value; }
        public string[] DaysOfMonth { get => _daysOfMonth; set => _daysOfMonth = value; }
        public string[] MonthOfYear { get => _monthOfYear; set => _monthOfYear = value; }
        public bool RunOnLastDayOfMonth { get => _runOnLastDayOfMonth; set => _runOnLastDayOfMonth = value; }
    }
}
