﻿namespace ControlTowerCore.ViewModels
{
    public class UserModel
    {
        private string _username;
        private string _password;
        private string _token;

        public string Username { get => _username; set => _username = value; }
        public string Password { get => _password; set => _password = value; }
        public string Token { get => _token; set => _token = value; }
    }
}
