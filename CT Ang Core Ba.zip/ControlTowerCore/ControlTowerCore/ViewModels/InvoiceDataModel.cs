﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ControlTowerCore.ViewModels
{
    public class InvoiceDataModel
    {
        public string Process1 { get; set; }
        public decimal Price { get; set; }
    }

    public class SomeData
    {
        public string heading { get; set; }

        public List<InvoiceDataModel> ChildNodes { get; set; }
    }
}
