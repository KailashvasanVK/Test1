﻿using System;

namespace ControlTowerCore.ViewModels
{
    #region DashboardViewModel
    public class DashboardViewModel
    {
        private ServersDash _servers { get; set; }
        private ProcessDash _process { get; set; }
        private BotsDash _bots { get; set; }
        private int[][] _transaction { get; set; }
        private BotStatus _botStatus { get; set; }

        public ServersDash Servers { get => _servers; set => _servers = value; }
        public ProcessDash Process { get => _process; set => _process = value; }
        public BotsDash Bots { get => _bots; set => _bots = value; }
        public int[][] Transaction { get => _transaction; set => _transaction = value; }
        public BotStatus BotStatus { get => _botStatus; set => _botStatus = value; }
    }

    public class ServersDash
    {
        private int _machines { get; set; }
        private int _servers { get; set; }

        public int Machines { get => _machines; set => _machines = value; }
        public int Servers { get => _servers; set => _servers = value; }
    }

    public class ProcessDash
    {
        private int _athena { get; set; }
        private int _nonAthena { get; set; }
        private int _Customer { get; set; }


        public int Athena { get => _athena; set => _athena = value; }
        public int NonAthena { get => _nonAthena; set => _nonAthena = value; }
        public int Customer { get => _Customer; set => _Customer = value; }
    }

    public class BotsDash
    {
        private int _athena { get; set; }
        private int _nonAthena { get; set; }
        private int _Customer { get; set; }

        public int Athena { get => _athena; set => _athena = value; }
        public int NonAthena { get => _nonAthena; set => _nonAthena = value; }
        public int Customer { get => _Customer; set => _Customer = value; }
    }

    public class BotStatus
    {
        private Athena _athena { get; set; }
        private NonAthena _nonAthena { get; set; }
        private Customer _customer { get; set; }

        public Athena Athena { get => _athena; set => _athena = value; }
        public NonAthena NonAthena { get => _nonAthena; set => _nonAthena = value; }
        public Customer Customer { get => _customer; set => _customer = value; }
    }
}

public class Athena
{
    private int _running { get; set; }
    private int _inQueue { get; set; }
    private int _stopped { get; set; }

    public int Running { get => _running; set => _running = value; }
    public int InQueue { get => _inQueue; set => _inQueue = value; }
    public int Stopped { get => _stopped; set => _stopped = value; }
}

public class NonAthena
{
    private int _running { get; set; }
    private int _inQueue { get; set; }
    private int _stopped { get; set; }

    public int Running { get => _running; set => _running = value; }
    public int InQueue { get => _inQueue; set => _inQueue = value; }
    public int Stopped { get => _stopped; set => _stopped = value; }
}

public class Customer
{
    private int _running { get; set; }
    private int _inQueue { get; set; }
    private int _stopped { get; set; }

    public int Running { get => _running; set => _running = value; }
    public int InQueue { get => _inQueue; set => _inQueue = value; }
    public int Stopped { get => _stopped; set => _stopped = value; }
}

#endregion

public class BotDetailsViewModel
{
    private string _processName;
    private int _processCount;

    public string ProcessName { get => _processName; set => _processName = value; }
    public int ProcessCount { get => _processCount; set => _processCount = value; }
}

public class BotsStatusViewModel
{
    private string _processName;
    private int _running;
    private int _inQueue;
    private int _stopped;

    public string ProcessName { get => _processName; set => _processName = value; }
    public int Running { get => _running; set => _running = value; }
    public int InQueue { get => _inQueue; set => _inQueue = value; }
    public int Stopped { get => _stopped; set => _stopped = value; }
}

public class BotMonitoringViewModel
{
    private string _taskName;
    private string _description;
    private string _processName;
    private string _serverIp;
    private string _taskStatus;
    private string _hostName;
    private string _repititionMode;
    private string _userName;
    private DateTime _lastRunTime;
    private DateTime _nextRunTime;
    private bool _expanded;

    public string TaskName { get => _taskName; set => _taskName = value; }
    public string Description { get => _description; set => _description = value; }
    public string ProcessName { get => _processName; set => _processName = value; }
    public string ServerIp { get => _serverIp; set => _serverIp = value; }
    public string TaskStatus { get => _taskStatus; set => _taskStatus = value; }
    public string HostName { get => _hostName; set => _hostName = value; }
    public string RepititionMode { get => _repititionMode; set => _repititionMode = value; }
    public string UserName { get => _userName; set => _userName = value; }
    public DateTime LastRunTime { get => _lastRunTime; set => _lastRunTime = value; }
    public DateTime NextRunTime { get => _nextRunTime; set => _nextRunTime = value; }
    public bool Expanded { get => _expanded; set => _expanded = value; }
}

public class EyeViewInput
{
    private string _processName = string.Empty;
    private string _serverName = string.Empty;
    private string _botStatus = string.Empty;

    public string ProcessName { get => _processName; set => _processName = value; }
    public string ServerName { get => _serverName; set => _serverName = value; }
    public string BotStatus { get => _botStatus; set => _botStatus = value; }
}

public class BotsServers
{
    private string _serverName;
    private int _count;

    public string ServerName { get => _serverName; set => _serverName = value; }
    public int Count { get => _count; set => _count = value; }
}

public class BotsServersInput
{
    private string _processName = string.Empty;
    private string _serverName = string.Empty;

    public string ProcessName { get => _processName; set => _processName = value; }
    public string ServerName { get => _serverName; set => _serverName = value; }
}


