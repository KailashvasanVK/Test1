﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Management;
using System.Net;
using System.Net.Sockets;
using ControlTowerCore.Constants;
using ControlTowerCore.Models;
using ControlTowerCore.ViewModels;
using Microsoft.AspNetCore.Http;

namespace ControlTowerCore.Services
{
    public class FileOperations : IFileOperations
    {
        public string _hostEnvironment { get; set; }
        public FileOperations(string HostEnviroment)
        {
            _hostEnvironment = HostEnviroment;
        }
        public IList<TargetDrives> GetDrives(ScheduledBotsViewModel task)
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                IQueryable<CtServers> servers = connection.CtServers;

                task.MachineType = servers.Where(_ => _.Id == task.IdMachine).FirstOrDefault().ServerType ?? 1;

                var options = new ConnectionOptions { Username = task.MachineType == 1 ? Credentials.Get(1)["UserName"] : Credentials.Get(2)["UserName"], Password = task.MachineType == 1 ? Credentials.Get(1)["Password"] : Credentials.Get(2)["Password"] };
                ManagementScope scope = null;
                Func<string> getLocalIpAddress = () =>
                {
                    var host = Dns.GetHostEntry(Dns.GetHostName());
                    foreach (var ip in host.AddressList)
                    {
                        if (ip.AddressFamily == AddressFamily.InterNetwork)
                        {
                            return ip.ToString();
                        }
                    }
                    throw new Exception("No network adapters with an IPv4 address in the system!");
                };

                if (getLocalIpAddress() == task.MachineIP)
                    scope = new ManagementScope(@"\\" + task.MachineIP + "\\root\\cimv2");
                else
                    scope = new ManagementScope(@"\\" + task.MachineIP + "\\root\\cimv2", options);
                var queryString = "select Name, Size, FreeSpace from Win32_LogicalDisk where DriveType=3"; var query = new ObjectQuery(queryString);
                var worker = new ManagementObjectSearcher(scope, query);
                var results = worker.Get();

                IList<TargetDrives> lstServerDriveInfo = new List<TargetDrives>();

                foreach (ManagementObject item in results)
                {
                    var DestinationPath = @"\\" + task.MachineIP + "\\" + item["Name"].ToString().Replace(":", "") + "$\\" + task.ProcessName;
                    var ProcessFolderExist = Directory.Exists(DestinationPath);
                    var freeSpaceinGB = Math.Round(((ulong)item["FreeSpace"] / 1024M / 1024M / 1024M), 2);
                    var totalSpaceinGB = Math.Round(((ulong)item["Size"] / 1024M / 1024M / 1024M), 2);
                    var freeSpacePercent = Math.Round(freeSpaceinGB / totalSpaceinGB * 100, 2);
                    var occupiedSpacePercent = Math.Round(100 - freeSpacePercent, 2);
                    lstServerDriveInfo.Add(new TargetDrives
                    {
                        Drive = item["Name"].ToString().Replace(":", ""),
                        TotalSpace = totalSpaceinGB.ToString() + " GB",
                        FreeSpace = freeSpaceinGB.ToString() + " GB",
                        UsedSpacePercent = occupiedSpacePercent,
                        FreeSpacePercent = freeSpacePercent,
                        ProcessFolderExist = ProcessFolderExist
                    });
                }

                return lstServerDriveInfo;
            }
        }
        public bool UploadFile(IFormFile file)
        {
            bool result = false;
            if (!string.IsNullOrEmpty(file.FileName))
            {
                var filename = Path.GetFileName(file.FileName);
                var path = Path.Combine(_hostEnvironment, "Processes_Uploaded", file.FileName);
                if (File.Exists(path))
                    File.Delete(path);
                using (var stream = new FileStream(path, FileMode.Create))
                {
                    file.CopyTo(stream);
                }
                result = true;
            }
            return result;
        }
    }
}