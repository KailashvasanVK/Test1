﻿using System;
using System.Collections.Generic;
using System.Linq;
using ControlTowerCore.Models;
using ControlTowerCore.ViewModels;

namespace ControlTowerCore.Services
{
    public class DashboardService : IDashboardService
    {
        public IList<BotMonitoringViewModel> GetBotMonitoringStatus(EyeViewInput input)
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                IQueryable<CtProcess> process = connection.CtProcess;
                IQueryable<CtScheduler> scheduled = connection.CtScheduler;
                IQueryable<CtServers> server = connection.CtServers;

                var result = scheduled.Join(inner: process, outerKeySelector: s => s.ProcessId, innerKeySelector: p => p.Id, resultSelector: (s, p) => new { s, p }).Where(_ => _.p.Status == "Active" && _.s.Status != "Deleted");

                if (!string.IsNullOrEmpty(input.ProcessName))
                    result = result.Where(_ => _.p.Name.Trim().Equals(input.ProcessName));

                if (!string.IsNullOrEmpty(input.ServerName))
                    result = result.Where(_ => _.s.ServerIp.Trim().Equals(input.ServerName));

                if (!string.IsNullOrEmpty(input.BotStatus))
                    result = result.Where(_ => _.s.Status.Trim().Equals(input.BotStatus));

                return result.Select(_ => new BotMonitoringViewModel()
                {
                    TaskName = _.s.TaskName,
                    Description = _.s.Description,
                    ProcessName = _.p.Name,
                    ServerIp = _.s.ServerIp,
                    HostName = _.s.HostName,
                    TaskStatus = _.s.Status,
                    RepititionMode = _.s.Repetitionmode,
                    UserName = _.s.UserName,
                    LastRunTime = _.s.LastRunTime ?? DateTime.Now,
                    NextRunTime = _.s.NextRunTime ?? DateTime.Now,
                    Expanded = false
                }).ToList();
            }
        }

        public IList<BotsStatusViewModel> GetBotsRunningStatus()
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                IQueryable<CtProcess> process = connection.CtProcess;
                IQueryable<CtScheduler> scheduled = connection.CtScheduler;
                IQueryable<CtServers> server = connection.CtServers;

                IList<BotsStatusViewModel> result = scheduled.Join(inner: process, outerKeySelector: s => s.ProcessId, innerKeySelector: p => p.Id, resultSelector: (s, p) => new { s, p }).Where(_ => _.p.Status == "Active").GroupBy(_ => _.p.Name).Select(_ => new BotsStatusViewModel()
                {
                    ProcessName = _.FirstOrDefault().p.Name,
                    Running = _.Count(x => x.s.Status == "Running"),
                    InQueue = _.Count(x => x.s.Status == "InQueue"),
                    Stopped = _.Count(x => x.s.Status == "Stopped")
                }).ToList();

                return result;
            }
        }

        public IList<BotsServers> GetBotsServerDetails(string processName)
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                IQueryable<CtProcess> process = connection.CtProcess;
                IQueryable<CtScheduler> scheduled = connection.CtScheduler;
                IQueryable<CtServers> server = connection.CtServers;

                IList<BotsServers> result = scheduled.Join(inner: process, outerKeySelector: s => s.ProcessId, innerKeySelector: p => p.Id, resultSelector: (s, p) => new { s, p }).Where(_ => _.p.Status == "Active" && _.p.Name == processName && _.s.Status != "Deleted").GroupBy(_ => _.s.ServerIp).Select(_ => new BotsServers()
                {
                    ServerName = _.FirstOrDefault().s.ServerIp,
                    Count = _.Count()
                }).ToList();

                return result;
            }
        }


        public bool UpdateActiveStatus(string TaskName)
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                var processList = connection.CT_LiveProcess.ToList();
                foreach (var p in processList)
                {
                    p.IsActive = false;
                    connection.SaveChanges();
                }
                var result = connection.CT_LiveProcess.FirstOrDefault(_ => _.ProcessName == TaskName);
                if (result != null)
                {
                    result.IsActive = true;
                    connection.SaveChanges();
                    return true;
                }
                return false;
            }
        }
            public BotsStatusViewModel GetBotsServerRunningStatus(BotsServersInput input)
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                IQueryable<CtProcess> process = connection.CtProcess;
                IQueryable<CtScheduler> scheduled = connection.CtScheduler;
                IQueryable<CtServers> server = connection.CtServers;

                BotsStatusViewModel result = scheduled.Join(inner: process, outerKeySelector: s => s.ProcessId, innerKeySelector: p => p.Id, resultSelector: (s, p) => new { s, p })
                    .Where(_ => _.p.Status == "Active" && _.p.Name == input.ProcessName && _.s.ServerIp == input.ServerName).GroupBy(_ => _.s.ServerIp).Select(_ => new BotsStatusViewModel()
                    {
                        ProcessName = _.FirstOrDefault().s.ServerIp,
                        Running = _.Count(x => x.s.Status == "Running"),
                        InQueue = _.Count(x => x.s.Status == "InQueue"),
                        Stopped = _.Count(x => x.s.Status == "Stopped")
                    }).SingleOrDefault();

                return result;
            }
        }

        public IList<BotDetailsViewModel> GetBotsStatus()
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                IQueryable<CtProcess> process = connection.CtProcess;
                IQueryable<CtScheduler> scheduled = connection.CtScheduler;
                IQueryable<CtServers> server = connection.CtServers;

                IList<BotDetailsViewModel> result = scheduled.Join(inner: process, outerKeySelector: s => s.ProcessId, innerKeySelector: p => p.Id, resultSelector: (s, p) => new { s, p }).Where(_ => _.p.Status == "Active" && _.s.Status != "Deleted").GroupBy(_ => _.p.Name).Select(_ => new BotDetailsViewModel()
                {
                    ProcessName = _.FirstOrDefault().p.Name,
                    ProcessCount = _.Count()
                }).ToList();

                return result;
            }
        }

        public DashboardViewModel GetDashboardData()
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                IQueryable<CtProcess> process = connection.CtProcess;
                IQueryable<CtScheduler> scheduled = connection.CtScheduler;
                IQueryable<CtServers> server = connection.CtServers;
                IQueryable<CtTransactions> transactions = connection.CtTransactions;
                IQueryable<CT_Transactions_Testing> transactionsTesting = connection.CT_Transactions_Testing;

                int[][] trans = transactions.Where(_ => _.Date >= DateTime.Now.AddDays(-16)).GroupBy(_ => _.Date).OrderBy(_ => _.Max(x => x.Date)).Select(_ => new int[] { _.Max(x => x.Date.Day), _.Sum(x => x.Transacations) }).ToArray();

                return new DashboardViewModel()
                {
                    Servers = new ServersDash()
                    {
                        Servers = server.Count(_ => _.Status == "Active" && _.ServerType == 1),
                        Machines = server.Count(_ => _.Status == "Active" && _.ServerType == 2),
                    },
                    Process = new ProcessDash()
                    {
                        Athena = process.Count(_ => _.Status == "Active" && _.ProcessType == "Athena"),
                        NonAthena = process.Count(_ => _.Status == "Active" && _.ProcessType == "Non-Athena"),
                        Customer=process.Count(_ => _.Status=="Active"&& _.ProcessType =="Customer")
                    },
                    Bots = new BotsDash()
                    {
                        Athena = scheduled.Join(inner: process, outerKeySelector: s => s.ProcessId, innerKeySelector: p => p.Id, resultSelector: (s, p) => new { s, p }).Where(_ => _.p.Status == "Active" && _.p.ProcessType == "Athena" && _.s.Status != "Deleted").Select(_ => _.s.Id).Count(),
                        NonAthena = scheduled.Join(inner: process, outerKeySelector: s => s.ProcessId, innerKeySelector: p => p.Id, resultSelector: (s, p) => new { s, p }).Where(_ => _.p.Status == "Active" && _.p.ProcessType == "Non-Athena" && _.s.Status != "Deleted").Select(_ => _.s.Id).Count(),
                        Customer = scheduled.Join(inner: process, outerKeySelector: s => s.ProcessId, innerKeySelector: p => p.Id, resultSelector: (s, p) => new { s, p }).Where(_ => _.p.Status == "Active" && _.p.ProcessType == "Customer" && _.s.Status != "Deleted").Select(_ => _.s.Id).Count()
                    },
                    Transaction = trans,
                    BotStatus = new BotStatus()
                    {
                        Athena = new Athena()
                        {
                            Running = scheduled.Join(inner: process, outerKeySelector: s => s.ProcessId, innerKeySelector: p => p.Id, resultSelector: (s, p) => new { s, p }).Where(_ => _.p.Status == "Active" && _.p.ProcessType == "Athena" && _.s.Status == "Running").Select(_ => _.s.Id).Count(),
                            InQueue = scheduled.Join(inner: process, outerKeySelector: s => s.ProcessId, innerKeySelector: p => p.Id, resultSelector: (s, p) => new { s, p }).Where(_ => _.p.Status == "Active" && _.p.ProcessType == "Athena" && _.s.Status == "InQueue").Select(_ => _.s.Id).Count(),
                            Stopped = scheduled.Join(inner: process, outerKeySelector: s => s.ProcessId, innerKeySelector: p => p.Id, resultSelector: (s, p) => new { s, p }).Where(_ => _.p.Status == "Active" && _.p.ProcessType == "Athena" && _.s.Status == "Stopped").Select(_ => _.s.Id).Count()
                        },
                        NonAthena = new NonAthena()
                        {
                            Running = scheduled.Join(inner: process, outerKeySelector: s => s.ProcessId, innerKeySelector: p => p.Id, resultSelector: (s, p) => new { s, p }).Where(_ => _.p.Status == "Active" && _.p.ProcessType == "Non-Athena" && _.s.Status == "Running").Select(_ => _.s.Id).Count(),
                            InQueue = scheduled.Join(inner: process, outerKeySelector: s => s.ProcessId, innerKeySelector: p => p.Id, resultSelector: (s, p) => new { s, p }).Where(_ => _.p.Status == "Active" && _.p.ProcessType == "Non-Athena" && _.s.Status == "InQueue").Select(_ => _.s.Id).Count(),
                            Stopped = scheduled.Join(inner: process, outerKeySelector: s => s.ProcessId, innerKeySelector: p => p.Id, resultSelector: (s, p) => new { s, p }).Where(_ => _.p.Status == "Active" && _.p.ProcessType == "Non-Athena" && _.s.Status == "Stopped").Select(_ => _.s.Id).Count()
                        },
                        Customer = new Customer()
                        {
                            Running = scheduled.Join(inner: process, outerKeySelector: s => s.ProcessId, innerKeySelector: p => p.Id, resultSelector: (s, p) => new { s, p }).Where(_ => _.p.Status == "Active" && _.p.ProcessType == "Customer" && _.s.Status == "Running").Select(_ => _.s.Id).Count(),
                            InQueue = scheduled.Join(inner: process, outerKeySelector: s => s.ProcessId, innerKeySelector: p => p.Id, resultSelector: (s, p) => new { s, p }).Where(_ => _.p.Status == "Active" && _.p.ProcessType == "Customer" && _.s.Status == "InQueue").Select(_ => _.s.Id).Count(),
                            Stopped = scheduled.Join(inner: process, outerKeySelector: s => s.ProcessId, innerKeySelector: p => p.Id, resultSelector: (s, p) => new { s, p }).Where(_ => _.p.Status == "Active" && _.p.ProcessType == "Customer" && _.s.Status == "Stopped").Select(_ => _.s.Id).Count()
                        }
                    }
                };
            }
        }

        public int[][] GetProcessTransactions(string processName)
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                IQueryable<CtTransactions> transactions = connection.CtTransactions;

                int[][] trans = transactions.Where(_ => _.Date >= DateTime.Now.AddDays(-16) && _.Process == processName).GroupBy(_ => _.Date).OrderBy(_ => _.Max(x => x.Date)).Select(_ => new int[] { _.Max(x => x.Date.Day), _.Sum(x => x.Transacations) }).ToArray();

                return trans;
            }
        }

        public IList<BotDetailsViewModel> GetTransactionDetails(int type)
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                IQueryable<CtTransactions> transactions = connection.CtTransactions;

                IList<BotDetailsViewModel> result = new List<BotDetailsViewModel>();

                switch (type)
                {
                    case 1:
                        result = transactions.Where(_ => _.Date.Date == DateTime.Now.AddDays(-1).Date && _.Transacations != 0).GroupBy(_ => _.Process).Select(_ => new BotDetailsViewModel()
                        {
                            ProcessName = _.FirstOrDefault().Process,
                            ProcessCount = _.Sum(x => x.Transacations)
                        }).ToList();
                        break;
                    case 2:
                        result = transactions.Where(_ => _.Date.Date >= DateTime.Now.AddDays(-7).Date && _.Transacations != 0).GroupBy(_ => _.Process).Select(_ => new BotDetailsViewModel()
                        {
                            ProcessName = _.FirstOrDefault().Process,
                            ProcessCount = _.Sum(x => x.Transacations)
                        }).ToList();
                        break;
                    case 3:
                        result = transactions.Where(_ => _.Date.Date >= DateTime.Now.AddDays(-15).Date && _.Transacations != 0).GroupBy(_ => _.Process).Select(_ => new BotDetailsViewModel()
                        {
                            ProcessName = _.FirstOrDefault().Process,
                            ProcessCount = _.Sum(x => x.Transacations)
                        }).ToList();
                        break;
                };

                return result;
            }
        }
    }
}