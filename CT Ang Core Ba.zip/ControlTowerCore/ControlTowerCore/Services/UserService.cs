﻿using System.Linq;
using Microsoft.Extensions.Configuration;
using ControlTowerCore.Models;
using ControlTowerCore.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authentication;
using System.DirectoryServices.AccountManagement;
using System.Security.Principal;
using System;

namespace ControlTowerCore.Services
{
    public class UserService : IUserService
    {
        private readonly IConfiguration _config;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private static string currUserName;

        public UserService(IConfiguration config, IHttpContextAccessor httpContextAccessor)
        {
            _config = config;
            _httpContextAccessor = httpContextAccessor;
            currUserName = _httpContextAccessor.HttpContext.User.Identity.Name;
        }

        public UserModel Authenticate(UserModel login)
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                if (connection.CtUser.FirstOrDefault(_ => _.UserName == login.Username && CryptoService.Decrypt(_.Password) == login.Password) == null)
                    return null;
            }

            var user = new UserModel()
            {
                Username = login.Username,
                Token = TokenService.GenerateJSONWebToken(_config),
                Password = null
            };

            return user;
        }

        public UserModel GenerateToken()
        {
            var userName = currUserName;

            if (string.IsNullOrEmpty(userName))
                userName = "serviceaccount1";

            Console.WriteLine(userName);

            using (PrincipalContext context = new PrincipalContext(ContextType.Domain, "ACCESSHEALTHCAR"))
            {
                using (UserPrincipal user = UserPrincipal.FindByIdentity(context, IdentityType.SamAccountName, userName))
                {
                    if (null != user)
                    {
                        string userContext = user.Context.ToString();
                        return new UserModel()
                        {
                            Username = userName,
                            Token = TokenService.GenerateJSONWebToken(_config),
                            Password = null
                        };
                    }
                    return null;
                }
            }
        }
    }
}
