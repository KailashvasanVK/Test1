﻿using ControlTowerCore.Constants;
using ControlTowerCore.Models;
using ControlTowerCore.ViewModels;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ControlTowerCore.Services
{
    public class ServerOperations : IServerOperations
    {
        public async Task<bool> AddServer(Server dataServer)
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                IQueryable<CtServers> servers = connection.CtServers;

                var result = connection.CtServers.FirstOrDefault(_ => _.IpAddress == dataServer.ServerIp);
                if (result == null)
                {
                    connection.CtServers.Add(new CtServers()
                    {
                        IpAddress = dataServer.ServerIp,
                        MachineName = dataServer.ServerName,
                        ServerType = dataServer.ServerType == "Server" ? 1 : 2,
                        Status = Status.Active,
                        UserName = "",
                        CreatedDate = DateTime.Now,
                        ModifiedDate = DateTime.Now
                    });

                    await connection.SaveChangesAsync();

                    return true;
                }

                return false;
            }
        }

        public async Task<bool> DeleteServer(string ip)
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                var item = connection.CtServers.FirstOrDefault(_ => _.IpAddress == ip);
                if (item != null)
                {
                    item.Status = Status.Deleted;
                    item.ModifiedDate = DateTime.Now;

                    await connection.SaveChangesAsync();

                    return true;
                }

                return false;
            }
        }

        public IList<Server> GetServers()
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                IQueryable<CtServers> servers = connection.CtServers;

                var result = servers.Where(_ => _.Status == Status.Active).Select(_ => new Server()
                {
                    Sno = _.Id,
                    ServerIp = _.IpAddress,
                    ServerName = _.MachineName.Contains(".accesshealthcare.co") ? _.MachineName.Replace(".accesshealthcare.co", string.Empty) : _.MachineName,
                    ServerType = _.ServerType == 1 ? "Server" : "Desktop",
                    CreatedDate = _.CreatedDate ?? DateTime.Now,
                    ModifiedDate = _.ModifiedDate ?? DateTime.Now
                }).AsNoTracking().ToList();

                return result;
            }
        }

        public async Task<bool> UpdateServer(Server dataServer)
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                var result = connection.CtServers.FirstOrDefault(_ => _.IpAddress == dataServer.ServerIp);
                if (result != null)
                {
                    result.IpAddress = dataServer.ServerIp;
                    result.MachineName = dataServer.ServerName;
                    result.ServerType = dataServer.ServerType == "Server" ? 1 : 2;
                    result.ModifiedDate = DateTime.Now;

                    await connection.SaveChangesAsync();

                    return true;
                }

                return false;
            }
        }

    }
}
