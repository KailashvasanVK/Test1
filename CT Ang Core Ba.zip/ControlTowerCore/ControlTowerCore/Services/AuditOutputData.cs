﻿using System;

namespace ControlTowerCore.Services
{
    internal class AuditOutputData
    {
        public string category { get; set; }
        public string User { get; set; }
        public string Action { get; set; }
        public string Time { get; set; }

      
    }
}