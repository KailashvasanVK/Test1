﻿using System;
using System.IO;
using System.Linq;
using ControlTowerCore.Constants;
using ControlTowerCore.Models;
using ControlTowerCore.ViewModels;
using Microsoft.Win32.TaskScheduler;

namespace ControlTowerCore.Services
{
    public class TaskOperations : ITaskService
    {
        public bool DeleteSchedule(ScheduledBotsViewModel taskName)
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                IQueryable<CtScheduler> scheduler = connection.CtScheduler;
                IQueryable<CtServers> servers = connection.CtServers;

                //string machineIP = scheduler.Where(t => t.Status == null || t.Status == Status.Active).FirstOrDefault(_ => _.TaskName.Equals(taskName.SchedulerName)).ServerIp;
                //int machineType = servers.Where(t=>t.Status == Status.Active).FirstOrDefault(_ => _.IpAddress == machineIP).ServerType ?? 1;
                string machineIP = taskName.MachineIP;
                int machineType = taskName.MachineType;

                using (TaskService ts = new TaskService(machineIP, machineType == 1 ? Credentials.Get(1)["UserName"] : Credentials.Get(2)["UserName"], Domain.AccessHealthcare, machineType == 1 ? Credentials.Get(1)["Password"] : Credentials.Get(2)["Password"]))
                {
                    Task task = ts.FindTask(taskName.SchedulerName, true);
                    if (null != task)
                    {
                        ts.RootFolder.DeleteTask(task.Name, false);
                        Task findTask = ts.FindTask(task.Name, true);
                        if(findTask == null)
                        {
                            DeleteEmptySchedule(taskName);
                        }
                        return true;
                    }
                    return false;
                }
            }
        }
        public void DeleteEmptySchedule(ScheduledBotsViewModel task)
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                CtScheduler scheduler = connection.CtScheduler.Where(t => t.TaskName == task.SchedulerName).FirstOrDefault();
                scheduler.ScheduleStatus = Status.Deleted;
                connection.SaveChanges();
            }
        }

        public Tuple<bool, string> modifySchedule(ModifyTasks tasks)
        {
            try
            {
                using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
                {
                    IQueryable<CtScheduler> scheduler = connection.CtScheduler;
                    IQueryable<CtServers> servers = connection.CtServers;

                    string machineIP = scheduler.FirstOrDefault(_ => _.TaskName.Equals(tasks.SchedulerName)).ServerIp;

                    int machineType = servers.FirstOrDefault(_ => _.IpAddress == machineIP).ServerType ?? 1;

                    using (TaskService ts = new TaskService(machineIP, machineType == 1 ? Credentials.Get(1)["UserName"] : Credentials.Get(2)["UserName"], Domain.AccessHealthcare, machineType == 1 ? Credentials.Get(1)["Password"] : Credentials.Get(2)["Password"]))
                    {
                        Task task = ts.FindTask(tasks.SchedulerName, true);
                        if (null != task)
                        {
                            if (tasks.Type == 0)
                            {
                                task.Stop();
                                scheduler.FirstOrDefault(_ => _.TaskName == tasks.SchedulerName).Status = "Stopped";
                            }
                            else
                            {
                                task.Run();
                                scheduler.FirstOrDefault(_ => _.TaskName == tasks.SchedulerName).Status = "Running";
                            }
                            connection.SaveChanges();
                            return new Tuple<bool, string>(true, "Completed");
                        }
                        return new Tuple<bool, string>(false, "Task Not Found");
                    }
                }
            }
            catch
            {
                return new Tuple<bool, string>(false, "Something happened wrong");
            }
        }

        public bool RunNow(ScheduledBotsViewModel input)
        {
            try
            {
                using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
                {
                    IQueryable<CtServers> servers = connection.CtServers;
                    var password = connection.CtUser.Where(t => t.Id == input.IdUser).FirstOrDefault().Password;
                    var decryptedPwd = CryptoService.Decrypt(password);
                    input.MachineType = servers.Where(_ => _.Id == input.IdMachine && _.Status == Status.Active).FirstOrDefault().ServerType ?? 1;

                    using (TaskService ts = new TaskService(input.MachineIP, input.MachineType == 1 ? Credentials.Get(1)["UserName"] : Credentials.Get(2)["UserName"], Domain.AccessHealthcare, input.MachineType == 1 ? Credentials.Get(1)["Password"] : Credentials.Get(2)["Password"]))
                    {
                        Task task = ts.FindTask(input.SchedulerName, true);
                        TaskDefinition td;

                        if (null == task)
                        {
                            td = ts.NewTask();
                        }
                        else
                        {
                            td = task.Definition;
                            td.Triggers.Clear(); td.Actions.Clear();
                        }
                        //td.Settings.RunOnlyIfLoggedOn = false;
                        td.RegistrationInfo.Description = input.Description;
                        td.RegistrationInfo.Author = input.MachineType == 1 ? Credentials.Get(1)["UserName"] : Credentials.Get(2)["UserName"];
                        td.Triggers.Add(new TimeTrigger() { StartBoundary = DateTime.Now.AddMinutes(1) });
                        td.Actions.Add(new ExecAction(Path.Combine(input.TargetDrive + ":\\", input.ProcessName + "\\" + input.TaskInputs.ExeName + ".exe"), null, null));
                        td.Principal.RunLevel = TaskRunLevel.Highest;
                        ts.RootFolder.RegisterTaskDefinition(input.SchedulerName, td, TaskCreation.CreateOrUpdate, input.UserName, decryptedPwd, (input.MachineType == 1 ? TaskLogonType.InteractiveTokenOrPassword : TaskLogonType.InteractiveToken), null);
                    }
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool ScheduleDaily(ScheduledBotsViewModel input)
        {
            try
            {
                using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
                {
                    IQueryable<CtServers> servers = connection.CtServers;
                    var password = connection.CtUser.Where(t => t.Id == input.IdUser).FirstOrDefault().Password;
                    var decryptedPwd = CryptoService.Decrypt(password);
                    input.MachineType = servers.Where(_ => _.Id == input.IdMachine && _.Status == Status.Active).FirstOrDefault().ServerType ?? 1;
                    using (TaskService ts = new TaskService(input.MachineIP, input.MachineType == 1 ? Credentials.Get(1)["UserName"] : Credentials.Get(2)["UserName"], Domain.AccessHealthcare, input.MachineType == 1 ? Credentials.Get(1)["Password"] : Credentials.Get(2)["Password"]))
                    {
                        Task task = ts.FindTask(input.SchedulerName, true);
                        TaskDefinition td;

                        if (null == task)
                        {
                            td = ts.NewTask();
                        }
                        else
                        {
                            td = task.Definition;
                            td.Triggers.Clear(); td.Actions.Clear();
                        }
                        td.RegistrationInfo.Description = input.Description;
                        td.RegistrationInfo.Author = input.MachineType == 1 ? Credentials.Get(1)["UserName"] : Credentials.Get(2)["UserName"];
                        DailyTrigger daily = new DailyTrigger();
                        daily.StartBoundary = input.TaskInputs.StartDateTime;
                        daily.DaysInterval = Convert.ToInt16(input.TaskInputs.RepetitionInterval);
                        td.Triggers.Add(daily);
                        td.Actions.Add(new ExecAction(Path.Combine(input.TargetDrive + ":\\", input.ProcessName + "\\" + input.TaskInputs.ExeName + ".exe"), null, null));
                        td.Principal.RunLevel = TaskRunLevel.Highest;
                        ts.RootFolder.RegisterTaskDefinition(input.SchedulerName, td, TaskCreation.CreateOrUpdate, input.UserName, decryptedPwd, (input.MachineType == 1 ? TaskLogonType.InteractiveTokenOrPassword : TaskLogonType.InteractiveToken));
                    }
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool ScheduleMonthly(ScheduledBotsViewModel input)
        {
            try
            {
                using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
                {
                    IQueryable<CtServers> servers = connection.CtServers;
                    var password = connection.CtUser.Where(t => t.Id == input.IdUser).FirstOrDefault().Password;
                    var decryptedPwd = CryptoService.Decrypt(password);
                    input.MachineType = servers.Where(_ => _.Id == input.IdMachine && _.Status == Status.Active).FirstOrDefault().ServerType ?? 1;
                    using (TaskService ts = new TaskService(input.MachineIP, input.MachineType == 1 ? Credentials.Get(1)["UserName"] : Credentials.Get(2)["UserName"], Domain.AccessHealthcare, input.MachineType == 1 ? Credentials.Get(1)["Password"] : Credentials.Get(2)["Password"]))
                    {
                        Task task = ts.FindTask(input.SchedulerName, true);
                        TaskDefinition td;

                        if (null == task)
                        {
                            td = ts.NewTask();
                        }
                        else
                        {
                            td = task.Definition;
                            td.Triggers.Clear(); td.Actions.Clear();
                        }
                        td.RegistrationInfo.Description = input.Description;
                        td.RegistrationInfo.Author = input.MachineType == 1 ? Credentials.Get(1)["UserName"] : Credentials.Get(2)["UserName"];
                        MonthlyTrigger mTrigger = new MonthlyTrigger();
                        mTrigger.StartBoundary = input.TaskInputs.StartDateTime;
                        if (input.TaskInputs.RunOnLastDayOfMonth)
                            mTrigger.RunOnLastDayOfMonth = true;
                        else
                        {
                            if (input.TaskInputs.DaysOfMonth.Count() > 0)
                                mTrigger.DaysOfMonth = input.TaskInputs.DaysOfMonth.Select(x => Convert.ToInt32(x)).ToArray();
                            if (input.TaskInputs.MonthOfYear.Count() > 0)
                            {
                                foreach (var item in input.TaskInputs.MonthOfYear.Select((value, index) => new { Value = value, Index = index }))
                                {
                                    if (item.Index == 0)
                                        mTrigger.MonthsOfYear = Enum.Parse<MonthsOfTheYear>(item.Value);
                                    else
                                        mTrigger.MonthsOfYear |= Enum.Parse<MonthsOfTheYear>(item.Value);
                                }
                            }
                        }
                        td.Triggers.Add(mTrigger);
                        td.Actions.Add(new ExecAction(Path.Combine(input.TargetDrive + ":\\", input.ProcessName + "\\" + input.TaskInputs.ExeName + ".exe"), null, null));
                        td.Principal.RunLevel = TaskRunLevel.Highest;
                        ts.RootFolder.RegisterTaskDefinition(input.SchedulerName, td, TaskCreation.CreateOrUpdate, input.UserName, decryptedPwd, (input.MachineType == 1 ? TaskLogonType.InteractiveTokenOrPassword : TaskLogonType.InteractiveToken));
                    }
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool ScheduleOnce(ScheduledBotsViewModel input)
        {
            try
            {
                using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
                {
                    IQueryable<CtServers> servers = connection.CtServers;

                    var password = connection.CtUser.Where(t => t.Id == input.IdUser).FirstOrDefault().Password;
                    var decryptedPwd = CryptoService.Decrypt(password);
                    input.MachineType = servers.Where(_ => _.Id == input.IdMachine && _.Status == Status.Active).FirstOrDefault().ServerType ?? 1;
                    using (TaskService ts = new TaskService(input.MachineIP, input.MachineType == 1 ? Credentials.Get(1)["UserName"] : Credentials.Get(2)["UserName"], Domain.AccessHealthcare, input.MachineType == 1 ? Credentials.Get(1)["Password"] : Credentials.Get(2)["Password"]))
                    {
                        Task task = ts.FindTask(input.SchedulerName, true);
                        TaskDefinition td;

                        if (null == task)
                        {
                            td = ts.NewTask();
                        }
                        else
                        {
                            td = task.Definition;
                            td.Triggers.Clear(); td.Actions.Clear();
                        }
                        td.RegistrationInfo.Description = input.Description;
                        td.RegistrationInfo.Author = input.MachineType == 1 ? Credentials.Get(1)["UserName"] : Credentials.Get(2)["UserName"];
                        td.Triggers.Add(new TimeTrigger() { StartBoundary = input.TaskInputs.StartDateTime.AddMinutes(1) });
                        td.Actions.Add(new ExecAction(Path.Combine(input.TargetDrive + ":\\", input.ProcessName + "\\" + input.TaskInputs.ExeName + ".exe"), null, null));
                        td.Principal.RunLevel = TaskRunLevel.Highest;
                        ts.RootFolder.RegisterTaskDefinition(input.SchedulerName, td, TaskCreation.CreateOrUpdate, input.UserName, decryptedPwd, (input.MachineType == 1 ? TaskLogonType.InteractiveTokenOrPassword : TaskLogonType.InteractiveToken));
                    }
                }
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public bool ScheduleWeekly(ScheduledBotsViewModel input)
        {
            try
            {
                using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
                {
                    IQueryable<CtServers> servers = connection.CtServers;

                    input.MachineType = servers.Where(_ => _.Id == input.IdMachine && _.Status == Status.Active).FirstOrDefault().ServerType ?? 1;
                    using (TaskService ts = new TaskService(input.MachineIP, input.MachineType == 1 ? Credentials.Get(1)["UserName"] : Credentials.Get(2)["UserName"], Domain.AccessHealthcare, input.MachineType == 1 ? Credentials.Get(1)["Password"] : Credentials.Get(2)["Password"]))
                    {
                        Task task = ts.FindTask(input.SchedulerName, true);
                        TaskDefinition td;

                        if (null == task)
                        {
                            td = ts.NewTask();
                        }
                        else
                        {
                            td = task.Definition;
                            td.Triggers.Clear(); td.Actions.Clear();
                        }
                        td.RegistrationInfo.Description = input.Description;
                        td.RegistrationInfo.Author = input.MachineType == 1 ? Credentials.Get(1)["UserName"] : Credentials.Get(2)["UserName"];
                        WeeklyTrigger week = new WeeklyTrigger();
                        week.StartBoundary = input.TaskInputs.StartDateTime;
                        week.WeeksInterval = Convert.ToInt16(input.TaskInputs.RepetitionInterval);
                        foreach (var item in input.TaskInputs.WeekDays.Select((value, index) => new { Value = value, Index = index }))
                        {
                            if (item.Index == 0)
                                week.DaysOfWeek = Enum.Parse<DaysOfTheWeek>(item.Value);
                            else
                                week.DaysOfWeek |= Enum.Parse<DaysOfTheWeek>(item.Value);
                        }
                        td.Triggers.Add(week);
                        td.Actions.Add(new ExecAction(Path.Combine(input.TargetDrive + ":\\", input.ProcessName + "\\" + input.TaskInputs.ExeName + ".exe"), null, null));
                        td.Principal.RunLevel = TaskRunLevel.Highest;
                        ts.RootFolder.RegisterTaskDefinition(input.SchedulerName, td, TaskCreation.CreateOrUpdate, input.UserName, input.Password, (input.MachineType == 1 ? TaskLogonType.InteractiveTokenOrPassword : TaskLogonType.InteractiveToken));
                    }
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

    }
}
