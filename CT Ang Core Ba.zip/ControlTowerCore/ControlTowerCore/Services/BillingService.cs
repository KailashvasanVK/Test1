﻿using ControlTowerCore.Models;
using ControlTowerCore.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ControlTowerCore.Services
{
    public class BillingService : IBillingService
    {
        public BillItems BillItemsGenerator(int CompanyId, string Month)
        {
            throw new NotImplementedException();
        }

        public string BillRemainsGenerator(int CompanyId, string Month)
        {
            throw new NotImplementedException();
        }

        public string GenerateBill(int CompanyId, string Month)
        {
            throw new NotImplementedException();
        }

        public echobot_lic_companyDetails HeaderItemsGenerator(int CompanyId)
        {
            throw new NotImplementedException();
        }
    }
}
