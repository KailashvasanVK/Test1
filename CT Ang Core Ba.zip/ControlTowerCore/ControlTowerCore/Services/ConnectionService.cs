﻿using ControlTowerCore.Models;
using System;

namespace ControlTowerCore.Services
{
    internal class ConnectionService : IDisposable
    {
        private AhsPlatformContext _connection;
        public AhsPlatformContext CreateConnection()
        {
            _connection = new AhsPlatformContext();
            return _connection;
        }

        public void Dispose()
        {
            _connection.Dispose();
        }
    }
}
 