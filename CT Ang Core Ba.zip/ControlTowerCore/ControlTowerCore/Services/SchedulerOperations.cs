﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ControlTowerCore.Constants;
using ControlTowerCore.Models;
using ControlTowerCore.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace ControlTowerCore.Services
{
    public class SchedulerOperations : ISchedulerOperations
    {
        private readonly ITaskService _taskService;
        public SchedulerOperations(ITaskService taskService)
        {
            _taskService = taskService;
        }

        public async Task<bool> AddSchedule(ScheduledBotsViewModel dataSchedule)
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                IQueryable<CtScheduler> schedule = connection.CtScheduler;
                string exeName = connection.CtProcess.FirstOrDefault(t => t.Id == dataSchedule.IdProcess).ExeName;
                if (!string.IsNullOrEmpty(exeName))
                    dataSchedule.TaskInputs.ExeName = exeName;
                var isDuplicate = connection.CtScheduler.Where(t =>t.ScheduleStatus == Status.Active).FirstOrDefault(_ => _.ServerIp == dataSchedule.MachineIP && _.UserId == dataSchedule.IdUser);
                if (isDuplicate == null)
                {
                    bool isScheduled = false;
                    switch (dataSchedule.Mode)
                    {
                        case "RunNow":
                            isScheduled = _taskService.RunNow(dataSchedule);
                            break;
                        case "OneTime":
                            isScheduled = _taskService.ScheduleOnce(dataSchedule);
                            break;
                        case "Daily":
                            isScheduled = _taskService.ScheduleDaily(dataSchedule);
                            break;
                        case "Weekly":
                            isScheduled = _taskService.ScheduleWeekly(dataSchedule);
                            break;
                        case "Monthly":
                            isScheduled = _taskService.ScheduleMonthly(dataSchedule);
                            break;
                    };

                    if (isScheduled)
                    {
                        connection.CtScheduler.Add(new CtScheduler()
                        {
                            ProcessId = dataSchedule.IdProcess,
                            UserId = dataSchedule.IdUser,
                            TaskName = dataSchedule.SchedulerName,
                            Description = dataSchedule.Description,
                            HostName = dataSchedule.MachineIP,
                            Repetitionmode = dataSchedule.Mode,
                            StartDateTime = dataSchedule.TaskInputs.StartDateTime,
                            RepetationInterval = dataSchedule.TaskInputs.RepetitionInterval,
                            WeekDays = string.Join(",", dataSchedule.TaskInputs.WeekDays),
                            DaysOfMonth = string.Join(",", dataSchedule.TaskInputs.DaysOfMonth),
                            MonthOfYear = string.Join(",", dataSchedule.TaskInputs.MonthOfYear),
                            CreatedDate = DateTime.Now,
                            ModifiedDate = DateTime.Now,
                            CustomField = null,
                            RunOnLastDayOfMonth = dataSchedule.TaskInputs.RunOnLastDayOfMonth,
                            UserName = dataSchedule.UserName,
                            ServerIp = dataSchedule.MachineIP,
                            TargetDrive = dataSchedule.TargetDrive,
                            TokenKey = Guid.NewGuid().ToString(),
                            BotClientId = null,
                            Status = Status.InQueue,
                            ScheduleStatus = Status.Active
                        });

                        await connection.SaveChangesAsync();
                    }

                    return true;
                }
                return false;
            }
        }

        public bool DeleteSchedule(ScheduledBotsViewModel scheduleName)
        {
            if (_taskService.DeleteSchedule(scheduleName))
                return true;
            return false;
        }

        public SchedulerInputsViewModel GetSchedulerInputs()
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                IQueryable<CtProcess> processes = connection.CtProcess;
                IQueryable<CtServers> servers = connection.CtServers;
                IQueryable<CtUser> users = connection.CtUser;

                var result = new SchedulerInputsViewModel
                {
                    ServerData = servers.Where(_ => _.Status == Status.Active).Select(_ => new ServerInputs()
                    {
                        ServerId = _.Id,
                        ServerName = _.IpAddress
                    }).OrderBy(_ => _.ServerName).AsNoTracking().ToList(),
                    ProcessData = processes.Where(_ => _.Status == Status.Active).Select(_ => new ProcessInputs()
                    {
                        ProcessId = _.Id,
                        ProcessName = _.Name
                    }).OrderBy(_ => _.ProcessName).AsNoTracking().ToList(),
                    UserData = users.Where(_ => _.Status == Status.Active).Select(_ => new UserInputs()
                    {
                        UserId = _.Id,
                        UserName = _.UserName
                    }).OrderBy(_ => _.UserName).AsNoTracking().ToList()
                };

                return result;
            }
        }

        public IList<ScheduledBotsViewModel> GetSchedules()
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                IQueryable<CtProcess> process = connection.CtProcess;
                IQueryable<CtScheduler> scheduled = connection.CtScheduler;
                IQueryable<CtServers> server = connection.CtServers;
                IQueryable<CtUser> user = connection.CtUser;

                DateTime t = new DateTime();


                var result = scheduled.Join(inner: process, outerKeySelector: s => s.ProcessId, innerKeySelector: p => p.Id, resultSelector: (s, p) => new { s, p }).Where(_ => _.s.ScheduleStatus == Status.Active).OrderByDescending( _ => _.s.Id)
                        .Join(inner: server, outerKeySelector: s => s.s.ServerIp, innerKeySelector: p => p.IpAddress, resultSelector: (s, p) => new { s, p }).Where(_ => _.p.Status == Status.Active)
                        .Join(inner: user, outerKeySelector: s => s.s.s.UserId, innerKeySelector: p => p.Id, resultSelector: (s, p) => new ScheduledBotsViewModel()
                        {
                            Description = s.s.s.Description,
                            IdMachine = s.p.Id,
                            IdProcess = s.s.p.Id,
                            IdUser = s.s.s.UserId ?? 0,
                            MachineIP = s.p.IpAddress,
                            MachineType = s.p.ServerType ?? 1,
                            Mode = s.s.s.Repetitionmode,
                            ProcessName = s.s.p.Name,
                            SchedulerName = s.s.s.TaskName,
                            TargetDrive = s.s.s.TargetDrive,
                            UserName = s.s.s.UserName,
                            Password = p.Password,
                            TaskInputs = new TaskViewModel()
                            {
                                ExeName = s.s.p.ExeName,
                                RepetitionInterval = s.s.s.RepetationInterval ?? 1,
                                StartDateTime = s.s.s.StartDateTime.HasValue ? s.s.s.StartDateTime.Value : t,
                                DaysOfMonth = !string.IsNullOrEmpty(s.s.s.DaysOfMonth) ? s.s.s.DaysOfMonth.Split(",", StringSplitOptions.None) : new string[] { },
                                WeekDays = !string.IsNullOrEmpty(s.s.s.WeekDays) ? s.s.s.WeekDays.Split(",", StringSplitOptions.None) : new string[] { },
                                MonthOfYear = !string.IsNullOrEmpty(s.s.s.MonthOfYear) ? s.s.s.MonthOfYear.Split(",", StringSplitOptions.None) : new string[] { },
                                RunOnLastDayOfMonth = s.s.s.RunOnLastDayOfMonth ?? false
                            }
                        }).AsNoTracking().ToList();

                return result;
            }
        }

        public async Task<bool> UpdateSchedule(ScheduledBotsViewModel dataSchedule)
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                IQueryable<CtScheduler> schedule = connection.CtScheduler;

                var existingSchedule = connection.CtScheduler.FirstOrDefault(_ => _.ServerIp == dataSchedule.MachineIP && _.UserId == dataSchedule.IdUser);
                if (existingSchedule != null)
                {
                    bool isScheduled = false;
                    switch (dataSchedule.Mode)
                    {
                        case "RunNow":
                            isScheduled = _taskService.RunNow(dataSchedule);
                            break;
                        case "OneTime":
                            isScheduled = _taskService.ScheduleOnce(dataSchedule);
                            break;
                        case "Daily":
                            isScheduled = _taskService.ScheduleDaily(dataSchedule);
                            break;
                        case "Weekly":
                            isScheduled = _taskService.ScheduleWeekly(dataSchedule);
                            break;
                        case "Monthly":
                            isScheduled = _taskService.ScheduleMonthly(dataSchedule);
                            break;
                    };

                    if (isScheduled)
                    {

                        existingSchedule.ProcessId = dataSchedule.IdProcess;
                        existingSchedule.UserId = dataSchedule.IdUser;
                        existingSchedule.TaskName = dataSchedule.SchedulerName;
                        existingSchedule.Description = dataSchedule.Description;
                        existingSchedule.HostName = dataSchedule.MachineIP;
                        existingSchedule.Repetitionmode = dataSchedule.Mode;
                        existingSchedule.StartDateTime = dataSchedule.TaskInputs.StartDateTime;
                        existingSchedule.RepetationInterval = dataSchedule.TaskInputs.RepetitionInterval;
                        existingSchedule.WeekDays = string.Join(",", dataSchedule.TaskInputs.WeekDays);
                        existingSchedule.DaysOfMonth = string.Join(",", dataSchedule.TaskInputs.DaysOfMonth);
                        existingSchedule.MonthOfYear = string.Join(",", dataSchedule.TaskInputs.MonthOfYear);
                        existingSchedule.CreatedDate = DateTime.Now;
                        existingSchedule.ModifiedDate = DateTime.Now;
                        existingSchedule.CustomField = null;
                        existingSchedule.RunOnLastDayOfMonth = dataSchedule.TaskInputs.RunOnLastDayOfMonth;
                        existingSchedule.UserName = dataSchedule.UserName;
                        existingSchedule.ServerIp = dataSchedule.MachineIP;
                        existingSchedule.TargetDrive = dataSchedule.TargetDrive;
                        existingSchedule.TokenKey = existingSchedule.TokenKey;
                        existingSchedule.BotClientId = null;    

                        await connection.SaveChangesAsync();
                    }

                    return true;
                }
                return false;
            }
        }
    }
}
