﻿using ControlTowerCore.Constants;
using ControlTowerCore.Models;
using ControlTowerCore.ViewModels;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ControlTowerCore.Services
{
    public class LicenseService : ILicenseService
    {
        public void GenerateLicense(echobot_lic_companyDetails company)
        {
            throw new NotImplementedException();
        }

        public object GetCompanies()
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                var _companies = connection.ct_Process_Client. Where(_ => _.Status == "Active").Select(s => new AllCompany()
                {
                    viewValue =s.Name
                }).Distinct().ToList();

                return _companies;
            }
        }
        public object GetProcessTypes()
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                var _companies = connection.CtProcess.Where(d=>d.ProcessType != null).Select(s => new AllCompany()
                {
                    viewValue = s.ProcessType
                }).Distinct().ToList();

                return _companies;
            }
        }
        public object Companiesbyname(int companyname)
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                var _companies = connection.t_Botrate_Details.Where(x => x.ProcessId == companyname).Select(b => new companyDetails()
                {
                    YearlyCost = b.YearlyCost,
                    MonthlyCost = b.MonthlyCost,
                    Bot = b.Bot,
                    Botrate = b.Botrate,
                    PrimeBot = b.PrimeBot,
                    PrimeBotRate = b.PrimeBotRate,
                    AmortizeMonth=b.AmortizeMonth,
                    RateBased = b.RateType,
                    OptionRate = b.Rate,
                    Maintenance = b.MaintenanceHours,
                    MaintenanceRate = b.MaintenanceRate,
                    No_of_Bots = b.No_of_Bots,
                    No_of_Workfolws = b.No_of_Workfolws
                }).ToList();
               
                return _companies;
            }
        }
        public object GetCompanyData(int companyname)
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                var _companies = connection.ct_Process_Client.Where(x => x.ID == companyname).Select(s => new CompanyData()
                {
                    EmailId=s.UserName,
                    address=s.Address,
                    BotInstance=s.Bot_Instance,
                    MobileNo=s.Contact_Mobile

                }).ToList();

                return _companies;
            }
        }
        public long CheckPrimeBot(string companyname)
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                var PrimeBot = (from a in connection.ct_Process_Client
                                join b in connection.t_Botrate_Details
                                on a.ID equals b.ProcessId
                                where a.Name == companyname
                                select new
                                {
                                    b.PrimeBot  
                                }).Take(1);
                return 5;
                
            } 
        }
        
        public object Processbyname(string companyname)
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                var _companies = connection.ct_Process_Client.Where(_ => _.Name == companyname).Select(s => new AllCompany()
                {
                    value=s.ID,
                    viewValue=s.ExeName
                }).ToList();

                return _companies;
            }
        }
        public object GetProductkeys(string CilentName)
        {

            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
               var data = (from a in connection.CtProcess
                            join b in connection.CtScheduler
                            on a.Id equals b.ProcessId
                            where a.Name.Contains(CilentName)
                            && a.Status == "Active"
                           select new ProductKeyDetails()
                            {
                                ClientName = a.Name,
                                ProcessName = a.ExeName,
                                ClientId = b.BotClientId.ToString(),
                                ProcessId = a.ProcessId.ToString()
                            }).ToList();

                return data;
            }
        }
        public object GeneratekeyforClient(Clientdata CompanyData)
        {
            object result = null;
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                int? Processcheck = connection.CtProcess.FirstOrDefault(c => c.ExeName == CompanyData.ProcessName)?.Id;
                if (Processcheck ==null)
                {
                    DateTime now = DateTime.Now;
                    Guid guid = Guid.NewGuid();

                    connection.CtProcess.Add(new CtProcess()
                    {
                        Name = CompanyData.ClientName,
                        Status = "Active",
                        CreatedDate = now,
                        ModifiedDate = now,
                        UserName = "accesshealthcare",
                        ExeName = CompanyData.ProcessName,
                        FileName = CompanyData.ProcessName + ".zip",
                        ProcessId = guid
                    });
                    connection.SaveChanges();
                    var ProcessId = connection.CtProcess.FirstOrDefault(X => X.ProcessId == guid).Id;
                    guid = Guid.NewGuid();
                    connection.CtScheduler.Add(new CtScheduler()
                    {
                        ProcessId = ProcessId,
                        UserId = 1,
                        TaskName = "CT_" + CompanyData.ProcessName,
                        Description = CompanyData.ProcessName,
                        HostName = "AHS-CBE-ATHENA2",
                        Repetitionmode = "RunNow",
                        StartDateTime = null,
                        RepetationInterval = null,
                        WeekDays = null,
                        DaysOfMonth = null,
                        MonthOfYear = null,
                        CreatedDate = now,
                        ModifiedDate = now,
                        CustomField = null,
                        RunOnLastDayOfMonth = null,
                        UserName = "ppm@accesshealthcare.com",
                        ServerIp = "10.20.79.116",
                        TargetDrive = "C",
                        TokenKey = Guid.NewGuid().ToString(),
                        BotClientId = guid
                    });
                    connection.SaveChanges();
                    var data = (from a in connection.CtProcess
                                join b in connection.CtScheduler
                                on a.Id equals b.ProcessId
                                where a.Id == ProcessId
                                && a.Status == "Active"
                                select new ProductKeyDetails()
                                {
                                    ClientName = a.Name,
                                    ProcessName = a.ExeName,
                                    ClientId = b.BotClientId.ToString(),
                                    ProcessId = a.ProcessId.ToString(),
                                    flag = "NOT EXIST"
                                }).ToList();

                    result = data;
                }
                else
                {
                    result = new ProductKeyDetails
                    {
                        flag = "EXIST"
                    };
                }
            }
            //connection.ct_audit_log.Add(new ct_audit_log()
            //{
            //    category = "Process",
            //    user = Username,
            //    action = "Invoice Amount added",
            //    time = DateTime.Now
            //});
            //connection.SaveChanges();
            return result;
        }
        public Companyavailable CheckCompany(string ProcessName)
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                CT_process_Client result = connection.ct_Process_Client.FirstOrDefault(_ => _.ExeName == ProcessName);
                if (null != result)
                {
                    return new Companyavailable()
                    {
                        Status = connection.ct_Process_Client.FirstOrDefault(_ => _.ExeName == ProcessName).Status,
                        result = "THERE"
                    };
                }
                else
                {
                    return new Companyavailable()
                    {
                        Status = "NO",
                        result = "NOT THERE"
                    };
                }
            }
        }
        public object GetProcessStatusdata(ProcessStatusInput ProcessInputData)
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                var result =connection.CtProcess.Where(_ => _.Status == ProcessInputData.Status && _.ProcessType == ProcessInputData.ProcessType).Select(_ => new ProcessstatusOutput()
                {
                    name = _.Name,
                    processType=_.ProcessType,
                    Status=_.Status,
                    CreatedDate=_.CreatedDate ?? DateTime.Now                    
                }).ToList();

                return result;

            }
        }
        
        public async Task<bool> Addcompanydetails(companyDetailsData companyDetails,string UserName)
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                int id = (from record in connection.ct_Process_Client orderby record.ID select record.ID).Last();
                var result = connection.ct_Process_Client.FirstOrDefault(_ => _.ExeName == companyDetails.ProcessName);
                if (result == null)
                {
                    connection.ct_Process_Client.Add(new CT_process_Client()
                    {
                        ID = id + 1,
                        Name = companyDetails.CompanyName,
                        Contact_Mobile = companyDetails.MobileNo,
                        UserName = companyDetails.EmailId,
                        Bot_Instance = companyDetails.BotInstance,
                        Address = companyDetails.address,
                        Status = "Active",
                        ExeName = companyDetails.ProcessName,
                        FileName = companyDetails.ProcessName + ".Zip",
                        processID = Guid.NewGuid(),
                        CreatedDate = DateTime.Now,
                        ModifiedDate = null

                    });
                    connection.ct_audit_log.Add(new ct_audit_log()
                    {
                        category = "Invoice",
                        user = UserName,
                        action = "New Company added",
                        time = DateTime.Now
                    });
                    
                    await connection.SaveChangesAsync();

                    return true;
                }

                return false;
            }
        }
        public  bool AddBotrateDetails(T_BOTRATE_DETAILS RateData, string Username)
         {
            DateTime Date = DateTime.Now;
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                
                var result = connection.t_Botrate_Details.FirstOrDefault(c => c.ProcessId == RateData.ProcessId);  //&& c.AmortizeMonth==RateData.AmortizeMonth
               
                if (result == null)
                {
                    if (RateData.LicenceType != "Bot per Month")
                    {
                        connection.t_Botrate_Details.Add(new T_BOTRATE_DETAILS()
                        {
                            ProcessId = RateData.ProcessId,
                            LicenceType = RateData.LicenceType,
                            YearlyCost = RateData.YearlyCost,
                            MonthlyCost = RateData.MonthlyCost,
                            Bot = RateData.Bot,
                            Botrate = RateData.Botrate,
                            PrimeBot = RateData.PrimeBot,
                            PrimeBotRate = RateData.PrimeBotRate,
                            RateType = RateData.RateType,
                            Rate = RateData.Rate,
                            AmortizeMonth = RateData.AmortizeMonth,
                            MaintenanceHours = RateData.MaintenanceHours,
                            MaintenanceRate = RateData.MaintenanceRate,
                            CreatedDate = Date,
                            CreatedBy = Username,
                            ModifiedDate = null
                        });
                        connection.SaveChanges();

                    }
                    else
                    {
                        connection.t_Botrate_Details.Add(new T_BOTRATE_DETAILS()
                        {
                            ProcessId = RateData.ProcessId,
                            LicenceType = RateData.LicenceType,
                            No_of_Bots = RateData.No_of_Bots,
                            No_of_Workfolws = RateData.No_of_Workfolws,
                            CreatedDate = Date,
                            CreatedBy = Username,
                            ModifiedDate = null
                        });

                        connection.SaveChanges();


                    }
                    connection.ct_audit_log.Add(new ct_audit_log()
                    {
                        category = "Invoice",
                        user = Username,
                        action = "Invoice Amount added",
                        time = DateTime.Now
                    });
                    connection.SaveChanges();
                }
                else
                {

                    if (RateData.LicenceType != "Bot per Month") {
                        result.LicenceType = RateData.LicenceType;
                        result.YearlyCost = RateData.YearlyCost;
                        result.MonthlyCost = RateData.MonthlyCost;
                        result.AmortizeMonth = RateData.AmortizeMonth;
                        result.Bot = RateData.Bot;
                        result.Botrate = RateData.Botrate;
                        result.PrimeBot = RateData.PrimeBot;
                        result.PrimeBotRate = RateData.PrimeBotRate;
                        result.RateType = RateData.RateType;
                        result.Rate = RateData.Rate;
                        result.MaintenanceHours = RateData.MaintenanceHours;
                        result.MaintenanceRate = RateData.MaintenanceRate;
                        result.ModifiedDate = Date;
                        result.ModifiedBy = Username;
                        connection.ct_audit_log.Add(new ct_audit_log()
                        {
                            category = "Invoice",
                            user = Username,
                            action = "Invoice Amount Modified",
                            time = DateTime.Now
                        });
                        connection.SaveChanges();
                        return true;
                    } else {
                        result.YearlyCost = 0;
                        result.MonthlyCost = 0;
                        result.Bot =0;
                        result.Botrate = 0;
                        result.PrimeBot = 0;
                        result.PrimeBotRate = 0;
                        result.RateType = null;
                        result.Rate = 0;
                        result.MaintenanceHours = null;
                        result.MaintenanceRate = 0;
                        result.LicenceType = RateData.LicenceType;
                        result.No_of_Bots = RateData.No_of_Bots;
                        result.No_of_Workfolws = RateData.No_of_Workfolws;
                        result.ModifiedDate = Date;
                        result.ModifiedBy = Username;
                        connection.SaveChanges();

                        connection.ct_audit_log.Add(new ct_audit_log()
                        {
                            category = "Invoice",
                            user = Username,
                            action = "Invoice Amount Modified",
                            time = DateTime.Now
                        });
                        connection.SaveChanges();
                     
                    }

                }
                return true;


            }
            
        }
        public async Task<bool> UpdateCompanyDetails(companyDetailsData companyDetails,string UserName)
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                var result = connection.ct_Process_Client.FirstOrDefault(_ => _.ExeName == companyDetails.ProcessName);
                if (result != null)
                {
                    result.Contact_Mobile = companyDetails.MobileNo;
                    result.UserName = companyDetails.EmailId;
                    result.Bot_Instance = companyDetails.BotInstance;
                    result.Address = companyDetails.address;
                    
                    await connection.SaveChangesAsync();
                    connection.ct_audit_log.Add(new ct_audit_log()
                    {
                        category = "Invoice",
                        user = UserName ,
                        action = "Company Information Modified",
                        time = DateTime.Now
                    });
                    connection.SaveChanges();
                    return true;
                }

                return false;
            }
        }
    }

}
