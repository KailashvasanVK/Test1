﻿using System.IO;
using System;
using ControlTowerCore.ViewModels;
using ControlTowerCore.Models;
using System.Linq;
using System.Collections.Generic;
using iText.Html2pdf;
using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Layout;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Globalization;

namespace ControlTowerCore.Services
{
    public class InvoiceService : IInvoiceService
    {
        public InvoiceService(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public IConfiguration Configuration { get; }
        public PdfPath GetPDFpath(GenerateInvoice InvoiceData)
        {
            var runningtime= GetRuntimeValue(InvoiceData.CompanyName);
            if (Convert.ToInt32(runningtime) == 0)
            {
                return new PdfPath()
                {
                    Path = "NOT"
                };
            }
            else
            {
                string Bottype = string.Empty;

                List<Invoicedata> _companies = new List<Invoicedata>();
                SomeData someData = null;
                decimal Subscriptionvalue = 0;
                decimal Maintenancevalue = 0;
                decimal Runtimevalue = 0;
                string address = string.Empty;
                using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
                {
                    var result = (from a in connection.t_Botrate_Details
                                  join b in connection.ct_Process_Client
                                  on a.ProcessId equals b.ID
                                  where b.Name == InvoiceData.CompanyName
                                  select new
                                  {
                                      b.ExeName,
                                      a.AmortizeMonth,
                                      a.MonthlyCost,
                                      a.PrimeBotRate,
                                      a.MaintenanceRate,
                                      b.Bot_Instance,
                                      a.PrimeBot,
                                      a.Rate,
                                      b.Address
                                  }).ToList();

                    var data = (from a in result
                                select new InvoiceDataModel()
                                {
                                    Process1 = $"{a.ExeName} {a.AmortizeMonth}/12",
                                    Price = a.MonthlyCost
                                }).ToList();

                    someData = new SomeData() { heading = "Automation Project", ChildNodes = data };

                    int PrimeBot = result.Select(c => c.PrimeBot).FirstOrDefault();
                    int PrimeBotRate = result.Select(x => x.PrimeBotRate).FirstOrDefault();
                    address = result.Select(n => n.Address).FirstOrDefault();
                    double Value = 0;
                    if (PrimeBot > 0)
                    {
                        int test = result.Sum(c => c.Bot_Instance);
                         Value =(double) test / PrimeBot;
                    }
                    else
                    {
                        Value = (result.Sum(c => c.Bot_Instance));
                    }
                    bool Isvalue = Value.ToString(CultureInfo.InvariantCulture).Contains('.');
                    if (Isvalue)
                    {
                        Subscriptionvalue =Convert.ToInt64(Value.ToString(CultureInfo.InvariantCulture).Split(".")[1]);
                        int i1 = Convert.ToInt16(Value.ToString(CultureInfo.InvariantCulture).Split(".")[0]);
                        if (Subscriptionvalue > 0)
                        {
                            Subscriptionvalue = (i1 + 1) * PrimeBotRate;
                        }
                        else
                        {
                            Subscriptionvalue = i1 * PrimeBotRate;
                        }
                    }
                    else
                    {
                        Subscriptionvalue = int.Parse(Value.ToString(CultureInfo.InvariantCulture)) * PrimeBotRate;
                    }
                    Runtimevalue = result.Select(c => c.Rate).FirstOrDefault() * Convert.ToInt32(runningtime);
                    Maintenancevalue = Convert.ToInt32(result.Select(c => c.MaintenanceRate).FirstOrDefault()) * result.Sum(c => c.Bot_Instance);
                }

                someData.ChildNodes.AddRange(new List<InvoiceDataModel>()
            {
                new InvoiceDataModel()
                {
                    Process1="Prime BOT Subscription Fees",
                    Price=Subscriptionvalue
                },
                new InvoiceDataModel()
                {
                    Process1="BOT Run Time Fees",
                    Price=Runtimevalue
                },
                new InvoiceDataModel()
                {
                    Process1="BOT Maintenance Fees",
                    Price=Maintenancevalue
                }
            });
                string tData = "";
                Decimal cnt = 0;
                //for (int i = 0; i < someData.ChildNodes.Length; i++)
                //{
                tData = tData + "<tr><th style = 'text-align:left;padding: 5px;'>" + 1 + "</th><th style = 'text-align:left;padding: 5px;'>" + someData.heading + "</th><th></th></tr>";
                foreach (var element in someData.ChildNodes)
                {
                    tData = tData + "<tr><td></td><td style = 'text-align:left;padding: 5px;'>" + element.Process1 + "</td><td style='background:#9e9e9e;text-align:left;padding: 5px;'> $ " + element.Price + "</td></tr>";
                    cnt = cnt + element.Price;
                }
                //}
                string table_data = "<table style='width:100%;font-size:11px;text-align:center;'><tr><th style = 'padding: 5px;'>S No </th><th style = 'padding: 5px;'>Description</th><th style = 'padding: 5px;'>TOTAL</th> " + tData + "<tr><td style = 'padding: 5px;' colSpan = 2>Total</td><td style = 'padding: 5px;'> $ " + cnt + "</td><tr></table>";
                string filePath = Environment.CurrentDirectory + "/ControlTowerApp/dist/assets/Invoice/InvoiceTemplate.html";
                string html = File.ReadAllText(filePath);
                html = html.Replace("{{ReplaceValue}}", table_data);
                html = html.Replace("{{Currentdate}}", DateTime.Now.Date.ToString("dd-MM-yyyy"));
                html = html.Replace("{{address}}", address);
                GeneratePDF(html);

                return new PdfPath()
                {
                    Path = "assets\\Invoice\\Invoice.pdf"
                };
            }
        }
        public void GeneratePDF(string htmlFile)
        {
            try
            {

                //HTML String
                string htmlString = htmlFile;
                //Setting destination 
                using (FileStream fileOutputStream = new FileStream("ControlTowerApp/dist/assets/Invoice/Invoice.pdf", FileMode.Create))
                {
                    PdfWriter pdfWriter = new PdfWriter(fileOutputStream);
                    ConverterProperties converterProperties = new ConverterProperties();
                    PdfDocument pdfDocument = new PdfDocument(pdfWriter);
                    pdfDocument.SetDefaultPageSize(new PageSize(PageSize.A4));
                    Document document = HtmlConverter.ConvertToDocument(htmlFile, pdfDocument, converterProperties);
                    document.Close();
                }
            }
            catch (Exception e)
            {

            }
        }
        public object GetRuntimeValue(string CompanyName)
        {
            try
            {           
            string constring = string.Format(Configuration.GetConnectionString("ControlTowerDatabase"));
                using (SqlConnection sqlcon = new SqlConnection(constring))
                {
                    using (SqlCommand cmd = new SqlCommand("P_GET_PROCESS_RUNTIME", sqlcon))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@ProcessName", CompanyName);
                        sqlcon.Open();
                        var value =cmd.ExecuteScalar().ToString();                        
                        sqlcon.Close();
                            int runtimevalue = 0;
                            if (value != string.Empty)
                            {   
                                var result =value.Split(":");
                                if((Convert.ToInt32(result[1])) >=30)
                                {
                                    runtimevalue = Convert.ToInt32(result[0]) + 1;
                                }
                                else
                                {
                                    runtimevalue = Convert.ToInt32(result[0]);
                                }                            
                            }
                            return runtimevalue;
                    }
                
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
