﻿using ControlTowerCore.Models;
using ControlTowerCore.ViewModels;
using System.Collections.Generic;
using System.Linq;

namespace ControlTowerCore.Services
{
    public interface IProcessOperations
    {
        IList<ProcessViewModel> GetProcesses();
        bool UpdateProcessViewStatus(string processId);
    }
}
