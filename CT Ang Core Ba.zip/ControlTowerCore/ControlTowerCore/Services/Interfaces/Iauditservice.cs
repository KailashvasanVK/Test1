﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ControlTowerCore.Services.Interfaces
{
    public interface Iauditservice
    {
        object getauditdata(Auditinputdata data);
    }
}
