﻿using ControlTowerCore.ViewModels;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ControlTowerCore.Services
{
    public interface IServerOperations
    {
        IList<Server> GetServers();
        Task<bool> AddServer(Server dataServer);
        Task<bool> UpdateServer(Server dataServer);
        Task<bool> DeleteServer(string ip);
    }
}
