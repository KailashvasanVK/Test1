﻿using ControlTowerCore.Models;
using ControlTowerCore.ViewModels;
using System.Threading.Tasks;

namespace ControlTowerCore.Services
{
    public interface IBillingService
    {
        BillItems BillItemsGenerator(int CompanyId, string Month);
        echobot_lic_companyDetails HeaderItemsGenerator(int CompanyId);
        string BillRemainsGenerator(int CompanyId, string Month);
        string GenerateBill(int CompanyId, string Month);
    }
}
