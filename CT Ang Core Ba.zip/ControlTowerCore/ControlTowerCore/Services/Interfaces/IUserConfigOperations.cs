﻿using ControlTowerCore.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ControlTowerCore.Services
{
    public interface IUserConfigOperations
    {
        IList<RemoteUser> GetRemoteUsers();
        Task<bool> AddRemoteUser(RemoteUser remoteUser);
        Task<bool> UpdateRemoteUser(RemoteUser remoteUser);
        Task<bool> DeleteRemoteUser(string name);
    }
}
