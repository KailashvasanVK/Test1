﻿using ControlTowerCore.Models;
using ControlTowerCore.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ControlTowerCore.Services
{
    public interface ILicenseService
    {
        void GenerateLicense(echobot_lic_companyDetails company);
        object GetCompanies();
        object GetProcessTypes();
        object Companiesbyname(int companyname);
        object GetCompanyData(int companyname);
        long CheckPrimeBot(string companyname);
        object Processbyname(string companyname);
        object GetProductkeys(string CilentName);

        object GeneratekeyforClient(Clientdata CompanyData);


        Companyavailable CheckCompany(string companyname);
        object GetProcessStatusdata(ProcessStatusInput ProcessInputData);
        

        Task<bool> Addcompanydetails(companyDetailsData companyDetails, string Username);
        bool AddBotrateDetails(T_BOTRATE_DETAILS RateData, string Username);

        Task<bool> UpdateCompanyDetails(companyDetailsData companyDetails,string UserName);
    }
}
