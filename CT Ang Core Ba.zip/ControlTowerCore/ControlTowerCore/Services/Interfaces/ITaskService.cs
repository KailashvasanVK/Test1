﻿using ControlTowerCore.ViewModels;
using System;
using System.Threading.Tasks;

namespace ControlTowerCore.Services
{
    public interface ITaskService
    {
        bool RunNow(ScheduledBotsViewModel input);
        bool ScheduleOnce(ScheduledBotsViewModel input);
        bool ScheduleDaily(ScheduledBotsViewModel input);
        bool ScheduleWeekly(ScheduledBotsViewModel input);
        bool ScheduleMonthly(ScheduledBotsViewModel input);
        bool DeleteSchedule(ScheduledBotsViewModel taskName);
        Tuple<bool, string> modifySchedule(ModifyTasks tasks);
    }
}
