﻿using ControlTowerCore.ViewModels;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;

namespace ControlTowerCore.Services
{
    public interface IFileOperations
    {
        IList<TargetDrives> GetDrives(ScheduledBotsViewModel task);
        bool UploadFile(IFormFile file);
    }
}
