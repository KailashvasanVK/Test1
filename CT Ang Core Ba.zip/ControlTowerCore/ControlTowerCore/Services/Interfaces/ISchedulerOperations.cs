﻿using ControlTowerCore.ViewModels;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ControlTowerCore.Services
{
    public interface ISchedulerOperations
    {
        SchedulerInputsViewModel GetSchedulerInputs();
        IList<ScheduledBotsViewModel> GetSchedules();
        Task<bool> AddSchedule(ScheduledBotsViewModel dataSchedule);
        Task<bool> UpdateSchedule(ScheduledBotsViewModel dataSchedule);
        bool DeleteSchedule(ScheduledBotsViewModel scheduleName);
    }
}