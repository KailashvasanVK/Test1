﻿using ControlTowerCore.ViewModels;
using System.Collections.Generic;

namespace ControlTowerCore.Services
{
    public interface IDashboardService
    {
        DashboardViewModel GetDashboardData();
        IList<BotDetailsViewModel> GetBotsStatus();
        IList<BotDetailsViewModel> GetTransactionDetails(int type);
        IList<BotsStatusViewModel> GetBotsRunningStatus();
        IList<BotsServers> GetBotsServerDetails(string processName);
        bool UpdateActiveStatus(string TaskName);
        int[][] GetProcessTransactions(string processName);
        BotsStatusViewModel GetBotsServerRunningStatus(BotsServersInput input);
        IList<BotMonitoringViewModel> GetBotMonitoringStatus(EyeViewInput input);
    }
}
