﻿using ControlTowerCore.ViewModels;

namespace ControlTowerCore.Services
{
    public interface IUserService
    {
        UserModel Authenticate(UserModel login);
        UserModel GenerateToken();
    }
}
