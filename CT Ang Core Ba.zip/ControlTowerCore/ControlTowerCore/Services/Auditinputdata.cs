﻿using System;

namespace ControlTowerCore.Services
{
    public class Auditinputdata
    {
        public string FromDate { get; set; }
        public string Todate { get; set; }
        public string ModuleType { get; set; }
    }
}