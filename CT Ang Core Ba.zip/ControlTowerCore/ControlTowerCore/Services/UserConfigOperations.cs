﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ControlTowerCore.Constants;
using ControlTowerCore.Models;
using ControlTowerCore.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace ControlTowerCore.Services
{
    public class UserConfigOperations : IUserConfigOperations
    {
        public async Task<bool> AddRemoteUser(RemoteUser remoteUser)
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                IQueryable<CtUser> users = connection.CtUser;

                var result = connection.CtUser.FirstOrDefault(_ => _.UserName == remoteUser.UserName);
                if (result == null)
                {
                    connection.CtUser.Add(new CtUser()
                    {
                        UserName = remoteUser.UserName,
                        Domain  = remoteUser.Domain,                        
                        Status = Status.Active,
                        NtLogin = remoteUser.NtLogin,
                        Password = remoteUser.Password,
                        CreatedDate = DateTime.Now,
                        ModifiedDate = DateTime.Now
                    });

                    await connection.SaveChangesAsync();

                    return true;
                }

                return false;
            }

        }

        public async Task<bool> DeleteRemoteUser(string name)
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                var item = connection.CtUser.FirstOrDefault(_ => _.UserName == name);
                if (item != null)
                {
                    item.Status = Status.Deleted;
                    item.ModifiedDate = DateTime.Now;

                    await connection.SaveChangesAsync();

                    return true;
                }

                return false;
            }
        }

        public IList<RemoteUser> GetRemoteUsers()
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                IQueryable<CtUser> users = connection.CtUser;

                var result = users.Where(_ => _.Status == Status.Active).Select(_ => new RemoteUser()
                {
                    Id = _.Id,
                    UserName = _.UserName,
                    Domain = _.Domain,
                    NtLogin = _.NtLogin,
                    Password = _.Password,
                    CreatedDate = _.CreatedDate ?? DateTime.Now,
                    ModifiedDate = _.ModifiedDate ?? DateTime.Now
                }).AsNoTracking().ToList();

                return result;
            }
        }

        public Task<bool> UpdateRemoteUser(RemoteUser remoteUser)
        {
            throw new NotImplementedException();
        }
    }
}
