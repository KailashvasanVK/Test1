﻿using ControlTowerCore.Constants;
using ControlTowerCore.Models;
using ControlTowerCore.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ControlTowerCore.Services
{
    public class ProcessOperations : IProcessOperations
    {
        public IList<ProcessViewModel> GetProcesses()
        {
            List<ProcessViewModel> processes = new List<ProcessViewModel>();
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                var result = connection.CtProcess.Where(a => a.Status == Status.Active).ToList();
                if(result != null)
                {
                    processes = result.Select(p => new ProcessViewModel()
                    {
                        Id = p.Id,
                        Name = p.Name,
                        ProcessID = p.ProcessId,
                        FileName = p.FileName,
                        ExeName = p.ExeName,
                        UserName = p.UserName,
                        CreatedDate = p.CreatedDate,
                        ModifiedDate = p.ModifiedDate
                    }).ToList();
                }
            }

            return processes;
        }

        public bool UpdateProcessViewStatus(string ProcessId)
        {
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {
                var processList = connection.CT_LiveProcess.ToList();
                foreach(var p in processList)
                {
                    p.IsActive = false;
                    connection.SaveChanges();
                }
                var result = connection.CT_LiveProcess.FirstOrDefault(_ => _.ProcessID == Convert.ToInt32(ProcessId));
                if (result != null)
                {
                    result.IsActive = true;
                    connection.SaveChanges();
                    return true;
                }
                return false;
            }
        }
    }
}
