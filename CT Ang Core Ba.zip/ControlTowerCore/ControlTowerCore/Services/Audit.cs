﻿using ControlTowerCore.Models;
using ControlTowerCore.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;


namespace ControlTowerCore.Services
{
    public class Audit : Iauditservice
    {
        public object getauditdata(Auditinputdata data)
        {
            DateTime fromdate = Convert.ToDateTime(data.FromDate);
            DateTime todate = Convert.ToDateTime(data.Todate);
             
            using (AhsPlatformContext connection = new ConnectionService().CreateConnection())
            {               
                    var result = (from a in connection.ct_audit_log
                                  where a.time > fromdate && a.time <= todate && a.category == data.ModuleType
                                  select new AuditOutputData
                                  {
                                      category = a.category,
                                      User = a.user,
                                      Action = a.action,
                                      Time = a.time.ToString()
                                  }).ToList();
                    return result;
               

            }
        }
    }
}
