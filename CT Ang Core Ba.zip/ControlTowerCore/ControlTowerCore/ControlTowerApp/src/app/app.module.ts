  import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { FlexLayoutModule } from '@angular/flex-layout';
import { JwtModule } from '@auth0/angular-jwt';
import { MaterialModule } from './modules/material';
import { GoogleChartsModule } from './modules/angular-google-charts';

import { AuthGuard } from './core/guards';
import { Globals, HttpErrorHandler, MessageService, UploadService } from './core/services';

import { AppComponent } from './app.component';
import { HomeComponent } from './layouts/home';
import { DashboardComponent, BotStatusComponent, TransactionsComponent, ProcessesComponent, DashBotsComponent } from './layouts/dashboard';
import { AnalyticsComponent } from './layouts/analytics';
import { LayoutComponent } from './layouts/layout';
import { LoginComponent } from './layouts/login';
import { ServersComponent, AddserverComponent } from './layouts/servers';
import { BotsComponent, DialogComponent, ProcessAddComponent } from './layouts/bots';
import { UsersComponent, UserlistComponent, PermissionsComponent, AdduserComponent } from './layouts/users';
import { UserMenuAccessComponent } from './layouts/user-menu-access';
import { BotScheduleComponent, ScheduleProcessComponent, ModeInfoComponent, DatetimePickerComponent, DrivePickerComponent } from './layouts/bot-schedule';
import { BotMonitorComponent } from './layouts/bot-monitor';

import { SidenavListComponent, LoaderComponent, HeaderComponent } from './shared/navigation';
import { LoadingScreenInterceptor, DelayResolve } from './core/interceptors';
import { ProcesslistComponent } from './layouts/bot-monitor/processlist/processlist.component';
import { ProcessBotsComponent } from './layouts/dashboard/process-bots/process-bots.component';
import { BotStatusDetailComponent } from './layouts/dashboard/bot-status-detail/bot-status-detail.component';
import { EyeViewComponent } from './layouts/dashboard/eye-view/eye-view.component';
import { DateFormatPipe } from './shared/utils/custompipes-utils';
import { TransactionDetailsComponent } from './layouts/dashboard/transaction-details/transaction-details.component';
import { PromptComponent } from './shared/navigation/prompt/prompt.component';
import { RaiseticketsComponent } from './layouts/raisetickets/raisetickets.component';
import { LicenceGenerationComponent } from './layouts/licence-generation/licence-generation.component';
import { InvoiceGenerateComponent } from './layouts/invoice-generate/invoice-generate.component';
import { DialograteComponent } from './layouts/licence-generation/dialograte/dialograte.component';
import { AddCompanyDetailsComponent } from './layouts/licence-generation/add-company-details/add-company-details.component';
import { ProductBotIDGenerateComponent } from './layouts/product-bot-id-generate/product-bot-id-generate.component';
import { ProcessStatusComponent } from './layouts/process-status/process-status.component';
import { CheckProcessStatusComponent } from './layouts/process-status/check-process-status/check-process-status.component';
import { CheckServerStatusComponent } from './layouts/process-status/check-server-status/check-server-status.component';
import { LivebotComponent } from './layouts/livebot/livebot.component';
import { AuditLogsComponent } from './layouts/audit-logs/audit-logs.component';


//import { SharedService } from './core/services/sharedservice';






@NgModule({
  
  declarations: [    
    AppComponent,
    DateFormatPipe,
    HomeComponent,
    DashboardComponent,
    AnalyticsComponent,
    HeaderComponent,
    SidenavListComponent,
    LayoutComponent,
    LoginComponent,
    ServersComponent,
    BotsComponent,
    UsersComponent,
    UserMenuAccessComponent,
    BotScheduleComponent,
    BotMonitorComponent,
    LoaderComponent,
    AddserverComponent,
    ScheduleProcessComponent,
    DrivePickerComponent,
    ProcesslistComponent,
    ProcessAddComponent,
    DialogComponent,
    UserlistComponent,
    PermissionsComponent,
    AdduserComponent,
    DatetimePickerComponent,
    ModeInfoComponent,
    ProcessesComponent,
    TransactionsComponent,
    BotStatusComponent,
    DashBotsComponent,
    ProcessBotsComponent,
    BotStatusDetailComponent,
    EyeViewComponent,
    TransactionDetailsComponent,
    PromptComponent,
    RaiseticketsComponent,
    LicenceGenerationComponent,
    InvoiceGenerateComponent,
    DialograteComponent,
    AddCompanyDetailsComponent,    
    ProductBotIDGenerateComponent, ProcessStatusComponent, CheckProcessStatusComponent, CheckServerStatusComponent, LivebotComponent, AuditLogsComponent 
    ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
    BrowserAnimationsModule,    
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    FlexLayoutModule,
    GoogleChartsModule.forRoot('AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY'),
    JwtModule.forRoot({
      config: {
        tokenGetter: tokenGetter
      }
    }),
    RouterModule.forRoot([
      //{ path: 'login', component: LoginComponent, pathMatch: 'full' },TransactionDetailsComponent
      {
        path: '', component: HomeComponent, canActivate: [AuthGuard], children:
          [
            { path: 'dashboard', component: DashboardComponent, resolve: [DelayResolve] },
            { path: 'dashboard/processdetails', component: ProcessBotsComponent, resolve: [DelayResolve] },
            { path: 'dashboard/transactiondetails', component: TransactionDetailsComponent, resolve: [DelayResolve] },
            { path: 'dashboard/processdetails/eyeview', component: EyeViewComponent, resolve: [DelayResolve] },
            { path: 'dashboard/botstatus', component: BotStatusDetailComponent, resolve: [DelayResolve] },
            { path: 'config/servers', component: ServersComponent, resolve: [DelayResolve] },
            { path: 'config/bots', component: BotsComponent, resolve: [DelayResolve] },
            { path: 'config/users', component: UsersComponent, resolve: [DelayResolve] },
            //{ path: 'config/access', component: UserMenuAccessComponent, resolve: [DelayResolve]  },
            { path: 'bot/schedule', component: BotScheduleComponent, resolve: [DelayResolve] },
            { path: 'bot/monitor', component: BotMonitorComponent, resolve: [DelayResolve] },
            { path: 'raisetickets', component: RaiseticketsComponent, resolve: [DelayResolve] },
            { path: 'licence-generation', component: LicenceGenerationComponent, resolve: [DelayResolve] },
            { path: 'invoice-generate', component: InvoiceGenerateComponent, resolve: [DelayResolve] },
            { path: 'product-bot-id-generate', component: ProductBotIDGenerateComponent, resolve: [DelayResolve] },
            { path: 'process-status', component: ProcessStatusComponent, resolve: [DelayResolve] },
            { path: 'livebot', component: LivebotComponent, resolve: [DelayResolve] },
            { path: 'Audit-Logs', component: AuditLogsComponent, resolve: [DelayResolve] }

          ]
      }, 
    ])
  ],
  entryComponents: [DrivePickerComponent, ModeInfoComponent, DialogComponent, DatetimePickerComponent, PromptComponent, DialograteComponent,AddCompanyDetailsComponent],
  exports: [DateFormatPipe],
  
  providers: [{
    
    provide: HTTP_INTERCEPTORS,
    useClass: LoadingScreenInterceptor,
    multi: true
  },
    
    Globals, HttpErrorHandler, MessageService, DelayResolve, UploadService],
  bootstrap: [AppComponent]
})



export class AppModule { }

export function tokenGetter() {
  return localStorage.getItem('access_token');
}
