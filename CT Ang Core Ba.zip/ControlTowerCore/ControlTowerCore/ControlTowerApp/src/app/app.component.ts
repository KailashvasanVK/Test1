import { Component } from '@angular/core';
import { User } from './shared/models';
import { JwtService } from './core/services';
import { CustomIconService } from './core/services';
import 'rxjs/add/observable/of';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
  
})
export class AppComponent {
  currentUser: User;
  
  constructor(
    private authenticationService: JwtService,
    private customIconService: CustomIconService
  ) {
    this.authenticationService.currentUser.subscribe(x => this.currentUser = x);
    this.customIconService.init();
  }
}
