import { Component, OnInit, Inject, Output, EventEmitter, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { SharedService } from '../../../core/services/sharedservice';
import * as types from '../../../shared/models/LicenseModel';
@Component({
  selector: 'app-dialograte',
  templateUrl: './dialograte.component.html',
  styleUrls: ['./dialograte.component.css']
})
export class DialograteComponent implements OnInit {
  @Output() cancel = new EventEmitter();
  constructor(public dialogRef: MatDialogRef<DialograteComponent>, private service: SharedService, @Inject(MAT_DIALOG_DATA) public BotrateDetails: types.BotrateDetails,
    private snackBar: MatSnackBar) { }
  RateBased: any;
  BotRate: any;
  PrimeBotRate: any;
  PrimeBot: any;
  Rate: any;
  MonthlyCost: any;
  primebotdisable: boolean;
  YearlyCost: any;
  AmortizeMonth : any;
  MaintenanceRate: any;
  MaintenanceHours: any;
  ngOnInit() {

    this.RateBased = this.BotrateDetails.RateBased;
    this.MaintenanceHours = '40 hours';
    this.BotRate = this.BotrateDetails.Botrate;
    //this.service.CheckPrimeBot(this.BotrateDetails.CompanyName).subscribe((res: any) => {
      
    //}, err => { });
    this.PrimeBot = this.BotrateDetails.PrimeBot;
    //if (this.BotrateDetails.PrimeBot == null) {
    //  this.primebotdisable = false;
    //} else {
    //  this.primebotdisable = true;
    //}
      this.PrimeBotRate = this.BotrateDetails.PrimeBotRate;
      this.YearlyCost = this.BotrateDetails.YearlyCost;
      this.MonthlyCost = this.BotrateDetails.MonthlyCost;
      this.MaintenanceRate = this.BotrateDetails.MaintenanceRate;
      this.Rate = this.BotrateDetails.OptionRate;
    this.AmortizeMonth = String(this.BotrateDetails.AmortizeMonth);
  }
  PopupSave() {   
    this.BotrateDetails.Botrate = this.BotRate;
    this.BotrateDetails.Maintenance = this.MaintenanceHours;
    this.BotrateDetails.MaintenanceRate = this.MaintenanceRate;
    this.BotrateDetails.OptionRate = this.Rate;
    this.BotrateDetails.PrimeBotRate = this.PrimeBotRate;
    this.BotrateDetails.RateBased = this.RateBased;
    this.BotrateDetails.MonthlyCost = this.MonthlyCost;
    this.BotrateDetails.YearlyCost = this.YearlyCost;
    this.BotrateDetails.AmortizeMonth = this.AmortizeMonth;
    this.BotrateDetails.PrimeBot = this.PrimeBot;
    this.dialogRef.close();
  }
  PopupCancel() {
    this.dialogRef.close();
    this.BotrateDetails.Botrate = null;
    this.BotrateDetails.Maintenance = null;
    this.BotrateDetails.MaintenanceRate = null;
    this.BotrateDetails.OptionRate = null;
    this.BotrateDetails.PrimeBotRate = null;
    this.BotrateDetails.RateBased = null;
    this.BotrateDetails.MonthlyCost = null;
    this.BotrateDetails.YearlyCost = null;
    this.BotrateDetails.AmortizeMonth = null;
    this.BotrateDetails.PrimeBot = null;
    this.service.cancel.next(null);
  }
  YearlyChanged() {
    this.MonthlyCost = (this.YearlyCost / 12).toFixed();
  }
}
