import { Component, OnInit } from '@angular/core';
import { DialograteComponent } from '../licence-generation/dialograte/dialograte.component'
import { MatDialog, MatSnackBar } from '@angular/material';
import { SharedService } from '../../core/services/sharedservice';
import { AddCompanyDetailsComponent } from './add-company-details/add-company-details.component';
import * as types from '../../shared/models/LicenseModel';

@Component({
  selector: 'app-licence-generation',
  templateUrl: './licence-generation.component.html',
  styleUrls: ['./licence-generation.component.css']
})




export class LicenceGenerationComponent implements OnInit {
  //@ViewChild('LicGen')licgen: NgForm;
  displayedColumns: any;
  companydata = {
    EmailId: '',
    address: '',
    MobileNo: '',
    BotInstance: '',
    LicenceType:''
  };
  BotrateDetails = {} as types.BotrateDetails;
  Data = {} as types.CompanyDetailsdata;
  BotRate = {} as types.BotRate;
  CompanyName: any;
  ProcessName: any;
  dataSource: any;
  blnSlab = true;
  WorkFlows: any;
  btnedit = true;
  Bots: any;
  instancetable = true;
  AmortizeMonth: any;
  BotTable = true;
  WorkTable = true;
  Licencetype = null;
  Licenceslab = null;
  customrate = true;
  pattern = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

  LicenceTypes: types.Licencetype[] = [
    { value: '1', viewValue: 'Bot per Month' },
    { value: '2', viewValue: 'Custom' }

  ];

  Companynames: types.CompanyName[] = [];
  ProcessNames: types.ProcessName[] =[];

  CompanyDetails: types.CompanyDetails[] = [];

  constructor(public dialog: MatDialog, private service: SharedService, private snackBar: MatSnackBar) { }

  getCompanies() {
    this.service.getCompanies().subscribe((res: types.CompanyName[]) => {      
        this.Companynames = res;     
    }, err => {
    });
  }
 
  Licence() {
    this.Licenceslab = null;
    if (this.Licencetype == "1") {
      this.blnSlab = true;
      this.customrate = true;
      this.instancetable = true;
      this.BotTable = false;
      this.WorkTable = false;
      this.WorkFlows = 4;
      this.Bots = 4;
      this.Licenceslab = null;
      this.BotrateDetails = {} as types.BotrateDetails;
    }
    else if (this.Licencetype == "2") {
      this.service.getCompaniesbyCompanyname(this.ProcessName).subscribe((res: types.BotRate) => {
        if (res[0] != undefined) {  
          this.BotrateDetails = res[0];
          this.BotrateDetails.CompanyName = this.CompanyName;
        }
        else {
          this.BotrateDetails.CompanyName = this.CompanyName;          
        }
        this.dialog.open(DialograteComponent, {
          width: '50%',
          data: this.BotrateDetails
        });
        this.BotTable = true;
        this.WorkTable = true;
        this.customrate = false;
      },err => { });
    }
    else {
      this.blnSlab = false;
      this.BotTable = true;
      this.WorkTable = true;
      this.instancetable = true;
    }

  }
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;

  }

  ngOnInit() {
    this.getCompanies();
    this.service.cancel.subscribe(res => {
      this.Licencetype = res;
      this.customrate = true;
    });

  }

  addCompanyClick() {
    this.Data.flag = 'ADD';
    this.Data.buttonName = 'Save';
    this.Data.CompanyName = '';
    this.Data.EmailId = '';
    this.Data.address = '';
    this.Data.ProcessName = '';
    this.Data.BotInstance = null;
    this.Data.MobileNo = '';
    this.CompanyName = null;
    this.ProcessNames = [];
    this.btnedit = true;
    this.dialog.open(AddCompanyDetailsComponent, {
      width: '40%',
      data : this.Data
    });    
  }
  SaveBotRate() {
    this.BotRate.ProcessId = this.ProcessName;
    this.BotRate.LicenceType = this.LicenceTypes.find(X => X.value == this.Licencetype).viewValue;
    this.BotRate.YearlyCost = this.BotrateDetails.YearlyCost;
    this.BotRate.MonthlyCost = this.BotrateDetails.MonthlyCost;
    this.BotRate.Bot = 1;
    this.BotRate.PrimeBot = this.BotrateDetails.PrimeBot;
    this.BotRate.Botrate =this.BotrateDetails.Botrate;
    this.BotRate.PrimeBotRate = this.BotrateDetails.PrimeBotRate;
    this.BotRate.RateType = this.BotrateDetails.RateBased;
    this.BotRate.Rate = this.BotrateDetails.OptionRate;
    this.BotRate.MaintenanceHours = this.BotrateDetails.Maintenance;
    this.BotRate.MaintenanceRate = this.BotrateDetails.MaintenanceRate;
    this.BotRate.No_of_WorkFolws = 4;
    this.BotRate.No_of_Bots = 4;
    this.BotRate.AmortizeMonth = this.BotrateDetails.AmortizeMonth;
    this.service.addBotrateDetails(this.BotRate).subscribe((result: any) => {
      this.snackBar.open(result.message, "OK", { duration: 2000, });
      this.Licencetype = null;
      this.customrate = true;
    }, err => {
      
    });
  }
  CompanyNameChange() {
    this.service.getProcessbyCompanyname(this.CompanyName).subscribe((res: any) => {
      this.ProcessNames = res;
      }, err => {
    });
  }
  ProcessNameChange() {
  this.btnedit = false;    
    this.service.GetCompanyData(this.ProcessName).subscribe((res: types.CompanyDetails) => {
      this.companydata = res[0];
      this.Data = res[0];
      this.Data.CompanyName = this.CompanyName;
      this.Data.ProcessName = this.ProcessNames.find(x => x.value == this.ProcessName).viewValue;
      }, err => { });
  }
  
  EditCompanyDetails() {
    this.Data.flag = 'EDIT';
    this.Data.buttonName = 'Update';
    this.dialog.open(AddCompanyDetailsComponent, {
      width: '40%',
      data: this.Data
    });
    this.CompanyName = null;
    this.ProcessNames = [];
    this.btnedit = true;
  }
}


export class test {
  ID: number;
  companyName: string;
}
