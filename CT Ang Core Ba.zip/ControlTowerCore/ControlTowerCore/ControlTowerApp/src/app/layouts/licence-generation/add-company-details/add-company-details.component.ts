import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatSnackBar,  MatSnackBarConfig,MatSnackBarHorizontalPosition,MatSnackBarVerticalPosition, } from '@angular/material';
import { BehaviorSubject } from 'rxjs';
import { SharedService } from '../../../core/services/sharedservice';
import * as types from '../../../shared/models/LicenseModel';
@Component({
  selector: 'app-add-company-details',
  templateUrl: './add-company-details.component.html',
  styleUrls: ['./add-company-details.component.css']
})
export class AddCompanyDetailsComponent implements OnInit {
  disCompany = false;
  pattern = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  companydatadetails = {} as types.CompanyDetailsdata;
  constructor(public dialogRef: MatDialogRef<AddCompanyDetailsComponent>, private service: SharedService, private snackBar: MatSnackBar
    , @Inject(MAT_DIALOG_DATA) public data: types.CompanyDetailsdata) { }
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  ngOnInit() {
    this.companydatadetails = this.data;
    if (this.companydatadetails.flag == 'ADD') {
      this.disCompany = false;
      }
    else {
      this.disCompany = true;
      }
   
  }
  onSearchChange(searchValue: string): void {
    this.service.CheckCompany(searchValue).subscribe((res: types.CompanyAvailableDetails) => {
      let config = new MatSnackBarConfig();
      config.verticalPosition = this.verticalPosition;
      config.horizontalPosition = this.horizontalPosition;
      if (res.result == 'THERE' && res.Status == 'InActive') {
        this.snackBar.open('Process Already Available,But Status Inactive', "OK", config);
        this.companydatadetails.CompanyName = null;        
        this.companydatadetails.ProcessName = null;        
      }
      else if (res.result == 'THERE' && res.Status =='Active') {
        this.snackBar.open('Process Already Available', "OK", config);
        this.companydatadetails.CompanyName = null;
        this.companydatadetails.ProcessName = null;
      }
      
    }, err => {
    });
    
  }
  dialogclose() {
    this.companydatadetails.EmailId = '';
    this.companydatadetails.address = '';
    this.companydatadetails.BotInstance = null;
    this.companydatadetails.MobileNo = '';
    this.dialogRef.close();
    
  }
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;

  }
  DetailsSave() {
    if (this.companydatadetails.flag == 'ADD') {
        this.service.addCompany(this.companydatadetails).subscribe((result: any) => {
        this.snackBar.open(result.message, "OK", { duration: 2000, });
        this.companydatadetails.CompanyName = '';
        this.companydatadetails.EmailId = '';
        this.companydatadetails.address = '';
        this.companydatadetails.BotInstance = null;
        this.companydatadetails.MobileNo = '';
        this.companydatadetails.ProcessName = '';
        this.dialogRef.close();

      }, err => {
        
        this.snackBar.open("Something happened wrong. Try again.", "OK", { duration: 2000, });
        this.dialogRef.close();
      });
    }
    else if (this.companydatadetails.flag == 'EDIT') {
      this.service.UpdateCompany(this.companydatadetails).subscribe((res: any) => {
        let config = new MatSnackBarConfig();
        config.verticalPosition = this.verticalPosition;
        config.horizontalPosition = this.horizontalPosition;
        this.snackBar.open(res.message, "OK", config);
        this.companydatadetails.CompanyName = '';
        this.companydatadetails.EmailId = '';
        this.companydatadetails.address = '';
        this.companydatadetails.BotInstance = null;
        this.companydatadetails.MobileNo = '';
        this.companydatadetails.ProcessName = '';
        this.dialogRef.close();

      }, err => {
        this.snackBar.open("Something happened wrong. Try again.", "OK", { duration: 2000, });
        this.dialogRef.close();
      });
    }
  }
}
