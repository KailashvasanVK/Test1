import { Component, OnInit } from '@angular/core';
import { JwtService } from '../../core/services';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.css']
})
export class LayoutComponent implements OnInit {
  public signin: boolean;
  constructor(private authenticationService: JwtService) { }

  ngOnInit() {
    var current = this.authenticationService.currentUser.subscribe(x => {
      if (x != null) {
        this.signin = true;
      }
    });
  }

}
