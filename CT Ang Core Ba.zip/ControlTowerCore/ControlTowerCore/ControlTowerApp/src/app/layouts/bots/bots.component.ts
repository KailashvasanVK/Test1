import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Bots } from '../../shared/models'
import { MatTableDataSource, MatPaginator, MatSort, MatSnackBar } from '@angular/material';
import { BotService, DataTransferService } from '../../core/services';

@Component({
  selector: 'app-bots',
  templateUrl: './bots.component.html',
  styleUrls: ['./bots.component.css']
})
export class BotsComponent implements OnInit {
  step = 1;

  botsData: Bots[];
  displayedColumns: string[] = ['Name', 'UserName','CreatedDate', 'ModifiedDate', 'Actions'];
  dataSource: MatTableDataSource<Bots>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

   constructor(
     private changeDetector: ChangeDetectorRef,
     private botService: BotService,
     private snackBar: MatSnackBar,
     private dataService: DataTransferService
  ) {
    this.dataSource = new MatTableDataSource(this.botsData);
  }

  ngOnInit() {
    this.getData();
    this.dataService.currentData.subscribe(info => {
      if (typeof info == 'number')
        this.step = info;

    });
  }

  setStep(index: number) {
    this.step = index;
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  addProcess(bot: Bots) {
    this.botService.addProcess(bot);
  }
  editProcess(bot: Bots) {
    this.step = 0;
    if (this.dataService.updateData(bot)) {
      return true;
    }
    return false;
  }
  saveOrCancel(input) {
    if (typeof input != 'string') {
      if (this.editProcess(input)) {
        this.snackBar.open("Saved successfully", "OK", { duration:2000 });
      }
    }
    this.step = 1;
  }
  getData() {

    this.botService.getAllProcesses().subscribe(dataProcesses => {
      this.botsData = dataProcesses as Bots[]
      this.dataSource = new MatTableDataSource(this.botsData);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      this.changeDetector.detectChanges();
    },
      error => {
        console.log(error);
      });

  }

  refresh() {
    this.dataSource = new MatTableDataSource(this.botsData);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.changeDetector.detectChanges();
  }

}
