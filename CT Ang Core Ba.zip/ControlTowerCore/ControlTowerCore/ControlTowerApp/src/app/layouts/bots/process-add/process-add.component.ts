import { Component, OnInit, ChangeDetectorRef, Output, EventEmitter } from '@angular/core';
import { MatDialog } from '@angular/material';
import { UploadService, DataTransferService } from '../../../core/services';
import { DialogComponent } from '../dialog/dialog.component';
import { Bots } from '../../../shared/models';
@Component({
  selector: 'app-process-add',
  templateUrl: './process-add.component.html',
  styleUrls: ['./process-add.component.css']
})
export class ProcessAddComponent implements OnInit {

  @Output() compOutput: EventEmitter<any> = new EventEmitter<any>();

  constructor(private changeDetector: ChangeDetectorRef, public dialog: MatDialog, public uploadService: UploadService, public dataService: DataTransferService) { }
  private inData: Bots;
  public currentProcess = {
    processname: '',
    exename: '',
    file:'',
  };
  ngOnInit() {
    this.dataService.currentData.subscribe(data => {
      this.inData = data;
      this.currentProcess = {
        processname: data.Name,
        exename: data.ExeName,
        file: data.FileName
      };
    });
  }

  public onSave() {
    if (this.currentProcess.file == '' || this.currentProcess.processname == '' || this.currentProcess.exename == '') {
      return;
    }
    this.inData.FileName = this.currentProcess.file;
    this.inData.Name = this.currentProcess.processname;
    this.inData.ExeName = this.currentProcess.exename;
    this.compOutput.emit(this.inData);
  }

  public onCancel() {
    this.currentProcess = {    processname: '',    exename: '',    file: '',  };
    this.compOutput.emit('cancel');
  }

  public openUploadDialog() {
    let dialogRef = this.dialog.open(DialogComponent, { width: '50%', height: '25%' });
    dialogRef.afterClosed().subscribe(result => {
      this.currentProcess.file = result;
      this.changeDetector.detectChanges();
    });
  }

}
