import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-check-server-status',
  templateUrl: './check-server-status.component.html',
  styleUrls: ['./check-server-status.component.css']
})
export class CheckServerStatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
