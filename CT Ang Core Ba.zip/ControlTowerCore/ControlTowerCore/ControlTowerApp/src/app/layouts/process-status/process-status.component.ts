import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-process-status',
  templateUrl: './process-status.component.html',
  styleUrls: ['./process-status.component.css']
})
export class ProcessStatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
