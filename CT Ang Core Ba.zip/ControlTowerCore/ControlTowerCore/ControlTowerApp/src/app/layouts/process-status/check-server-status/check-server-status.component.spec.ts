import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckServerStatusComponent } from './check-server-status.component';

describe('CheckServerStatusComponent', () => {
  let component: CheckServerStatusComponent;
  let fixture: ComponentFixture<CheckServerStatusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckServerStatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckServerStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
