import { Component, OnInit, ViewChild } from '@angular/core';
import * as types from '../../../shared/models/LicenseModel';
import { SharedService } from '../../../core/services/sharedservice';
import { MatTableDataSource, MatPaginator, MatSort, MatSnackBar } from '@angular/material';
import { ProcessStatus } from '../../../shared/models';

export interface status {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-check-process-status',
  templateUrl: './check-process-status.component.html',
  styleUrls: ['./check-process-status.component.css']
})
export class CheckProcessStatusComponent implements OnInit {
  rUsersData: ProcessStatus[];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  ProcessType: string;
  Status: string;
  ProcessTypes: types.ProcessType[] = [];
  ProcessData = {} as types.ProcessstatusData;
  displayedColumns: string[] = ['ProcessName', 'processType', 'Status', 'ModifiedDate', 'Actions'];
  dataSource: MatTableDataSource<ProcessStatus>;

  statuss: status[] = [
    { value: '0', viewValue: 'Active' },
    { value: '1', viewValue: 'Deleted' }
  ];
  constructor(private service: SharedService) { }
  ngOnInit() {
    this.getProcessTypes();
    
  }
  getProcessTypes() {
    this.service.getProcessTypes().subscribe((res: types.ProcessType[]) => {
      this.ProcessTypes = res;
    }, err => {
    });
  }
  GetProcessData() {
    this.ProcessData.ProcessType = this.ProcessType;
    this.ProcessData.Status = this.Status;
    this.service.GetProcessData(this.ProcessData).subscribe(res => {
      this.rUsersData = res as ProcessStatus[]
      this.dataSource = new MatTableDataSource(this.rUsersData);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, err => {
    });
  }
}
