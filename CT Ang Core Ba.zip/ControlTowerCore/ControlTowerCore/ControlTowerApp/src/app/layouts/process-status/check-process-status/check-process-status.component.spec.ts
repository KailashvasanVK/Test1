import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckProcessStatusComponent } from './check-process-status.component';

describe('CheckProcessStatusComponent', () => {
  let component: CheckProcessStatusComponent;
  let fixture: ComponentFixture<CheckProcessStatusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckProcessStatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckProcessStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
