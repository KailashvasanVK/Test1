import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LivebotComponent } from './livebot.component';

describe('LivebotComponent', () => {
  let component: LivebotComponent;
  let fixture: ComponentFixture<LivebotComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LivebotComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LivebotComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
