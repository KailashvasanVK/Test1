import { Component, OnInit } from '@angular/core';
import { BotService, DataTransferService } from '../../core/services';

@Component({
  selector: 'app-livebot',
  templateUrl: './livebot.component.html',
  styleUrls: ['./livebot.component.css'],
})
export class LivebotComponent implements OnInit {
  constructor(private bot:BotService) {}
  processId: any;
  processList: any;
  ngOnInit() {
    this.processList = [{ "processId": 1, "processName": "TPX PreCall" }, { "processId": 2, "processName": "TPX AlertCreation", }, { "processId": 3, "processName": "EchoPay" }]
  }
  viewOnClick(processIds) {
      this.bot.updateBotViewStatus(processIds).subscribe(
        data => {
          
        },
        err => {

        }
      );
    }
}
