import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-menu-access',
  templateUrl: './user-menu-access.component.html',
  styleUrls: ['./user-menu-access.component.css']
})
export class UserMenuAccessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
