import { Component, OnInit } from '@angular/core';
import { SharedService } from '../../core/services/sharedservice';
import { MatSnackBar } from '@angular/material';
import * as types from '../../shared/models/LicenseModel';
import { debug } from 'util';

@Component({
  selector: 'app-product-bot-id-generate',
  templateUrl: './product-bot-id-generate.component.html',
  styleUrls: ['./product-bot-id-generate.component.css']
})
export class ProductBotIDGenerateComponent implements OnInit {
  grddetail = true;
  Clientname: null;
  ProcessName: null;
  LicenceDetail: types.LicenceDetails;
  ClientDetails = {} as types.ClientDetails;
  displayedColumns: string[] = ['ClientName', 'ProcessName', 'ProcessId', 'ClientId'];
  constructor(private service: SharedService, private snackBar: MatSnackBar) {
  }

  ngOnInit() {
  }
  btnSerchClick() {
    
    this.service.GetProductKeys(this.Clientname).subscribe((res: any) => {
      if (res.length >0 ) {
        this.grddetail = false;        
        this.LicenceDetail = res;
        this.ProcessName = null;
      } else {
        this.grddetail = true; 
        this.LicenceDetail = null;
        this.ProcessName =null;
        this.snackBar.open("No Data Found!!!", "OK");
      }
    }, err => {
      this.snackBar.open("Something Went Wrong", "OK");
    });
  }
  btnGeneratekey() {
    this.ClientDetails.ClientName = this.Clientname;
    this.ClientDetails.ProcessName = this.ProcessName;
    this.service.GenerateKeysforClient(this.ClientDetails).subscribe((res: any) => {      
      if (res.flag == 'EXIST') {
        this.grddetail = true;
        this.LicenceDetail = null;
        this.snackBar.open("Process Name Already Exist!!!", "OK");
      } else if (res[0].flag == 'NOT EXIST') {
        this.grddetail = false;
        this.LicenceDetail = res;
      } 
    }, err => {
      this.snackBar.open("Something Went Wrong", "OK");
    });
  }
}
