import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort, MatSnackBar } from '@angular/material';
import { RemoteUser } from '../../../shared/models';
import { RemoteusersService } from '../../../core/services';

@Component({
  selector: 'userlist',
  templateUrl: './userlist.component.html',
  styleUrls: ['./userlist.component.css']
})
export class UserlistComponent implements OnInit {
  rUsersData: RemoteUser[];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  displayedColumns: string[] = ['UserName', 'Domain', 'CreatedDate', 'ModifiedDate', 'Actions'];
  dataSource: MatTableDataSource<RemoteUser>;

  constructor(
    private changeDetector: ChangeDetectorRef,
    private remoteUserService: RemoteusersService,
    private snackBar: MatSnackBar
  ) {
    this.dataSource = new MatTableDataSource(this.rUsersData);
  }

  ngOnInit() {
    this.getData();
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  update(user: RemoteUser, updated: any) {
    if ((user == undefined) && (updated != null || updated != undefined)) {

      this.rUsersData.push({
        Id: this.dataSource.data.length + 1,
        UserName: updated.machineip,
        Password: updated.machinename,
        Domain: updated.machinetype,
        NtLogin: updated.ntlogin,
        Status: 'Active',
        CreatedDate: new Date(),
        ModifiedDate: new Date(),
        FullName: '',
        FirstName: '',
        LastName: '',
        Email: ''
      });
      this.refresh();

      const remoteUser: RemoteUser = {
        Id: (this.dataSource.data.length + 1),
        UserName: updated.username,
        Password: updated.password,
        Domain: updated.domain,
        NtLogin: updated.ntlogin,
        Status: 'Active',
        CreatedDate: new Date(),
        ModifiedDate: new Date(),
        FullName: '',
        FirstName: '',
        LastName: '',
        Email: ''
      }

      this.remoteUserService.addRemoteUser(remoteUser).subscribe(() => {
        this.snackBar.open("User added successfully", "OK", { duration: 2000, });
      },
        () => {
          this.snackBar.open("Something happened wrong. Try again.", "OK", { duration: 2000, });
        });
    }
    else if (updated != null || updated != undefined) {

      let itemToUpdate = this.dataSource.data.find(s => s.Id === user.Id);
      let itemIndex = this.dataSource.data.indexOf(itemToUpdate);
      this.dataSource.data[itemIndex].Domain = updated.machineip;
      this.dataSource.data[itemIndex].UserName = updated.machinename;
      this.dataSource.data[itemIndex].NtLogin = updated.machinetype;
      this.dataSource.data[itemIndex].ModifiedDate = new Date();

      const remoteUser: RemoteUser = {
        Id: user.Id,
        UserName: updated.machineip,
        Password: updated.password,
        Domain: updated.machinename,
        NtLogin: updated.machinetype,
        Status: 'Active',
        CreatedDate: updated.CreatedDate,
        ModifiedDate: new Date(),
        FullName: '',
        FirstName: '',
        LastName: '',
        Email: ''
      }

      this.remoteUserService.updateRemoteUser(remoteUser).subscribe(() => {
        this.snackBar.open("User updated successfully", "OK", { duration: 2000, });
      },
        () => {
          this.snackBar.open("Something happened wrong. Try again.", "OK", { duration: 2000, });
        });
    }
  }

  deleteRemoteUser(remoteUser: RemoteUser) {
    if (confirm('Confirm delete? Action cannot be revoked !')) {
      if (remoteUser != undefined) {

        let itemIndex = this.dataSource.data.indexOf(this.dataSource.data.find(s => s.UserName === remoteUser.UserName));
        this.rUsersData.splice(itemIndex, 1);
        this.refresh();

        this.remoteUserService.deleteRemoteUser(remoteUser.UserName).subscribe(() => {
          this.snackBar.open("User deleted successfully.", "OK", { duration: 2000, });
        },
          () => {
            this.snackBar.open("Something happened wrong. Try again.", "OK", { duration: 2000, });
          });

      } else {
        this.snackBar.open("Unable to delete user. Try again.", "OK", { duration: 2000, });
      }
    }
  }

  getData() {
    this.remoteUserService.getRemoteUsers().subscribe(remoteUsers => {
      this.rUsersData = remoteUsers as RemoteUser[]
      this.dataSource = new MatTableDataSource(this.rUsersData);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      this.changeDetector.detectChanges();
    },
      error => {
        console.log(error);
      });
  }

  refresh() {
    this.dataSource = new MatTableDataSource(this.rUsersData);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.changeDetector.detectChanges();
  }
}
