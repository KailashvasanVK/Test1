import { Component, OnInit } from '@angular/core';
import * as types from '../../../shared/models/LicenseModel';
import { MatTableDataSource, MatPaginator, MatSort, MatSnackBar } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';


export interface PeriodicElement {
  Menus: string;
  position: number;
 }

@Component({
  selector: 'permissions',
  templateUrl: './permissions.component.html',
  styleUrls: ['./permissions.component.css']
})

export class PermissionsComponent implements OnInit {
  btnSave = true;
  RoleType1: any;
  tblAccess = true;
  RoleType: any;
  topping: any;
  HeaderRead= false;
  //ELEMENT_DATA: PeriodicElement[] = [
  //  { position: 1, Menus: 'Dashboard' },
  //  { position: 2, Menus: 'UserMenuAccess',}
  //];
   ELEMENT_DATA: PeriodicElement[] = [
     { position: 1, Menus: 'Dashboard' },
     { position: 2, Menus: 'Configuration'},
     { position: 3, Menus: 'Servers'},
     { position: 4, Menus: 'Bots' },
     { position: 5, Menus: 'Users'},
     { position: 6, Menus: 'Schedule and Monitor' },
     { position: 7, Menus: 'Bot Schedule' },
     { position: 8, Menus: 'Bot Monitor' },
     { position: 9, Menus: 'Raise Ticket' }
   ];
  displayedColumns: string[] = ['Menus','select', 'position','Select2'];
  dataSource: MatTableDataSource<PeriodicElement> = new MatTableDataSource<PeriodicElement>([]) ;
  selection: SelectionModel<PeriodicElement> = new SelectionModel<PeriodicElement>(true, []);
  position = new SelectionModel<PeriodicElement>(true, []);
  Select2 = new SelectionModel<PeriodicElement>(true, []);

  headercheck() {
    const numSelected = this.selection.selected.length ;
    const numRows = this.dataSource.data.length;
    if (numSelected == numRows || numSelected == (numRows - 1)) {
      this.HeaderRead = true;
      return true;
      
    } else {
      return false;
    }
  }
  isAllSelected(which) {
    if (which != undefined) {
      if (which == "one") {
        const numSelected = this.selection.selected.length;
        const numRows = this.dataSource.data.length;
       if (numSelected == 0 )
          return true
        else if (numSelected == numRows)
          return false
        else if (numSelected != numRows)
          return false
        

      } else if (which == "two") {
        const numPosition = this.position.selected.length;
        const numRows = this.dataSource.data.length;
        return numPosition === numRows;
      }
      else if (which == "three") {
        const numPosition = this.Select2.selected.length;
        const numRows = this.dataSource.data.length;
        return numPosition === numRows;
      }
    }

  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle(which) {
    
    if (which != undefined) {
      if (which == "one") {
        this.isAllSelected(which) ?
          this.dataSource.data.forEach(row =>
            this.selection.select(row)
            ) :
          this.selection.clear();
      } else if (which == "two") {
        this.isAllSelected(which) ?
          this.position.clear() :
          this.dataSource.data.forEach(row => this.position.select(row));
      }
      else if (which == "three") {
        this.isAllSelected(which) ?
          this.Select2.clear() :
          this.dataSource.data.forEach(row => this.Select2.select(row));
      }
      
     
    }   
  }
  btnSubmit() {
    alert(this.RoleType + '-'+this.topping);  
  }
  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: PeriodicElement, which = "one"): string {
    if (!row) {
      
      return `${this.isAllSelected(which) ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.position + 1}`;
  } 

  constructor() { }
  RoleTypes: types.RoleType[] = [
    { value: '1', viewValue: 'Admin' },
    { value: '2', viewValue: 'Normal' },
    { value: '3', viewValue: 'Deployment'}

  ];
 
  toppingList: types.topping[] = [
    { value: '1', viewValue: 'Serviceaccount1' },
    { value: '2', viewValue: 'Serviceaccount2' },
    { value: '3', viewValue: 'Serviceaccount3' }

  ];

  ngOnInit() {
  }
  RoleWiseMenuClick() {
    if (this.RoleType1 != undefined) {
      this.btnSave = false;      
      this.dataSource = new MatTableDataSource(this.ELEMENT_DATA);
      this.selection = new SelectionModel<PeriodicElement>(true, []);
      this.tblAccess = false;
    }
  }
}



