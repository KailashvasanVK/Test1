import { Component, OnInit, Optional, Host, Input } from '@angular/core';
import { SatPopover } from '@ncstate/sat-popover';
import { RemoteUser } from '../../../shared/models';

@Component({
  selector: 'adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.css']
})
export class AdduserComponent implements OnInit {
  loading = false;
  submitted = false;
  returnUrl: string;
  error = '';
  constructor(@Optional() @Host() public popover: SatPopover) { }
  @Input()
  get value(): RemoteUser { return this._value; }
  set value(x: RemoteUser) {
    this.currentUser = {
      domain: (x != null || x != undefined) ? x.Domain : '',
      username: (x != null || x != undefined) ? x.UserName : '',
      password: (x != null || x != undefined) ? x.Password : ''
    };
  }
  private _value: RemoteUser;

  currentUser = {
    domain: '',
    username: '',
    password: '',
  };

  ngOnInit() {
  }

  onSave() {
    this.submitted = true;
    if (this.currentUser.domain == '' || this.currentUser.username == '' || this.currentUser.password == '') {
      return;
    }
    if (this.popover) {
      this.popover.close(this.currentUser);
    }
  }

  onCancel() {
    if (this.popover) {
      this.popover.close();
    }
  }
}

