import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import {  MatSnackBar } from '@angular/material';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDatepicker } from '@angular/material/datepicker';
import { SharedService } from '../../core/services/sharedservice';
import * as types from '../../shared/models/LicenseModel';

import * as _moment from 'moment';
// tslint:disable-next-line:no-duplicate-imports
import { default as _rollupMoment, Moment } from 'moment';

const moment = _rollupMoment || _moment;
export const MY_FORMATS = {
  parse: {
    dateInput: 'MM/YYYY',
  },
  display: {
    dateInput: 'MM/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};
@Component({
  selector: 'app-invoice-generate',
  templateUrl: './invoice-generate.component.html',
  styleUrls: ['./invoice-generate.component.css'],
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },

    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],
})

export class InvoiceGenerateComponent implements OnInit {
  Companynames: types.CompanyName[] = [];
  CompanyName: any;
  ProcessName: any;
  ProcessNames: types.ProcessName[] = [];
  GenerateInvoice = {} as types.GenerateInvoice;
  constructor(private service: SharedService, private snackBar: MatSnackBar) { }
  date = new FormControl(moment());
  path: any;
  pdfSrc: string;
   chosenYearHandler(normalizedYear: Moment) {
    const ctrlValue = this.date.value;
    ctrlValue.year(normalizedYear.year());
    this.date.setValue(ctrlValue);
  }
  CompanyNameChange() {
    this.service.getProcessbyCompanyname(this.CompanyName).subscribe((res: any) => {
      this.ProcessNames = res;
    }, err => {
    });
  }
  chosenMonthHandler(normalizedMonth: Moment, datepicker: MatDatepicker<Moment>) {
    const ctrlValue = this.date.value;
    ctrlValue.month(normalizedMonth.month());
    this.date.setValue(ctrlValue);
    datepicker.close();
  }
  ngOnInit() {
    this.getCompanies();
  }
  getCompanies() {
     this.service.getCompanies().subscribe((res: types.CompanyName[]) => {
       this.Companynames = res;
    }, err => {
    });
  }
  preview() {
    this.GenerateInvoice.date = this.date.value.format('YYYY-MM-DDTHH:mm:ss');
    this.GenerateInvoice.CompanyName = this.CompanyName;
    this.GenerateInvoice.ProcessId = this.ProcessName;
    this.service.getPdfPath(this.GenerateInvoice).subscribe((res: types.PdfPath) => {
      if (res.Path !== 'NOT') {
        this.pdfSrc = res.Path;
      } else {
        this.pdfSrc = '';
        this.snackBar.open('No Data Found', "OK", { duration: 2000, });
      }
      }, err => {
      });
    }
    
  
  downloadFile() {
    let link = document.createElement("a");
    link.download = "Invoice_" + this.date.value.format('MMM');
    link.href =  this.pdfSrc;
    link.click();
  }
}
