import { Component, OnInit, ViewChild, Input, SimpleChanges } from '@angular/core';
import { LoaderService } from '../../../core/services';
import { ChartErrorEvent, ChartEvent, GoogleChartComponent } from '../../../modules/angular-google-charts/src/public_api';
import { DashboardMain } from '../../../shared/models';

@Component({
  selector: 'dash-bots',
  templateUrl: './dash-bots.component.html',
  styleUrls: ['./dash-bots.component.css']
})
export class DashBotsComponent implements OnInit {
  spanValue: number;

  charts: Array<{
    title: string,
    type: string,
    data: Array<Array<string | number | {}>>,
    roles: Array<{ type: string, role: string, index?: number }>,
    columnNames?: Array<string>,
    options?: {}
  }> = [];

  @ViewChild('chart')
  chart: GoogleChartComponent;

  @Input() DashboardData: DashboardMain;

  constructor(private loader: LoaderService) { }

  ngOnInit() {
    this.spanValue = 0;
  }

  ngOnChanges(change: SimpleChanges) {
    this.inputChangeEvent(change.DashboardData.currentValue)
  }

  inputChangeEvent(DashboardData: DashboardMain) {

    if (DashboardData != undefined) {

      this.spanValue = DashboardData.Bots.Athena + DashboardData.Bots.NonAthena + DashboardData.Bots.Customer;

      this.charts.push({
        title: '',
        type: 'PieChart',
        columnNames: ['Type', 'Count'],
        data: [
          ['Athena', DashboardData.Bots.Athena],
          ['NonAthena', DashboardData.Bots.NonAthena],
          ['Customer', DashboardData.Bots.Customer]
        ],
        roles: [],
        options: {
          is3D: true,
          height: '340',
          width: '340',
          colors: ['#ffc107', '#15426c', '#fc0303'],
          pieSliceTextStyle: {
            fontSize: 20
          },
          legend: {
            position: 'bottom',
            textStyle: {
              fontSize: 15
            }
          }
        }
      });

    }

  }

  getFontSize() {
    return (this.spanValue <= 999) ? '4vw' : '2.5vw';
  }

  onReady() {

  }
  onError(error: ChartErrorEvent) {

  }

  onSelect(event: ChartEvent) {

  }

  onMouseEnter(event: ChartEvent) {

  }

  onMouseLeave(event: ChartEvent) {

  }
}
