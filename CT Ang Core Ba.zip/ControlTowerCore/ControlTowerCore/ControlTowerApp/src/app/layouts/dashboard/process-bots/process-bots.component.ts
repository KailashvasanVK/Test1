import { Component, OnInit, ViewChild } from '@angular/core';
import { LoaderService, DashboardService } from '../../../core/services';
import { ChartErrorEvent, ChartEvent, GoogleChartComponent } from '../../../modules/angular-google-charts/src/public_api';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { BotsStatus } from '../../../shared/models';

@Component({
  selector: 'app-process-bots',
  templateUrl: './process-bots.component.html',
  styleUrls: ['./process-bots.component.css']
})
export class ProcessBotsComponent implements OnInit {

  spanValue: number;
  charts: Array<{
    title: string,
    type: string,
    data: Array<Array<string | number | {}>>,
    roles: Array<{ type: string, role: string, index?: number }>,
    columnNames?: Array<string>,
    options?: {}
  }> = [];

  @ViewChild('chart')
  chart: GoogleChartComponent;

  botsData: BotsStatus[];

  constructor(private loader: LoaderService, private router: Router, private dashService: DashboardService) {

    var colors = [
      { color: '#0f416c' }
    ];

    this.dashService.getBotsData().subscribe(botsData => {

      this.botsData = botsData;

      let inputArray: (string | number)[][] = [];

      this.botsData.forEach((item) => {
        inputArray.push(new Array<string | number>(item.ProcessName, item.ProcessCount));
      });

      this.charts.push({
        title: '',
        type: 'Bar',
        columnNames: ['', 'Bots'],
        data: inputArray,    
        options: {
          is3D: true,
          legend: 'none',
          height: '750',
          width: '1200',
          bars: 'horizontal',
          series: colors
        },
        roles: []
      });

    });

  }

  ngOnInit() {
  }

  getFontSize() {
    return (this.spanValue <= 999) ? '4vw' : '2.5vw';
  }

  onReady() {
    
  }

  onError(error: ChartErrorEvent) {
    
  }

  onSelect(event: ChartEvent) {
    let pName = this.charts[0].data[event["0"].row];
    this.router.navigate(['dashboard/processdetails/eyeview'], { queryParams: { processName: pName["0"], serverName: '', taskStatus:'' } });
  }

  onMouseEnter(event: ChartEvent) {
    
  }

  onMouseLeave(event: ChartEvent) {
    
  }

}
