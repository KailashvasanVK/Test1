import { Component, OnInit, ViewChild, Input, SimpleChanges } from '@angular/core';
import { LoaderService } from '../../../core/services';
import { ChartErrorEvent, ChartEvent, GoogleChartComponent } from '../../../modules/angular-google-charts/src/public_api';
import { DashboardMain } from '../../../shared/models';

@Component({
  selector: 'dash-transactions',
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.css']
})
export class TransactionsComponent implements OnInit {
  spanValue: string;

  charts: Array<{
    title: string,
    type: string,
    data: Array<Array<string | number | {}>>,
    roles: Array<{ type: string, role: string, index?: number }>,
    columnNames?: Array<string>,
    options?: {}
  }> = [];

  @ViewChild('chart')
  chart: GoogleChartComponent;

  @Input() DashboardData: DashboardMain;

  constructor(private loader: LoaderService) { }

  ngOnInit() {
    this.spanValue = "0";
  }

  ngOnChanges(change: SimpleChanges) {
    this.inputChangeEvent(change.DashboardData.currentValue)
  }

  inputChangeEvent(DashboardData: DashboardMain) {

    if (DashboardData != undefined) {

      this.spanValue = DashboardData.Transaction[DashboardData.Transaction.length - 1][1].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");

      let inputArray: (string | number)[][] = [];      

      DashboardData.Transaction.forEach((item) => {
        inputArray.push(new Array<string | number>(item[0].toString(), item[1]));
      });

      this.charts.push({
        title: '',
        type: 'AreaChart',
        columnNames: ['Date', 'Transactions'],
        data: inputArray,
        options: {
          is3D: true,
          legend: 'top',
          vAxis: { gridlines: { count: 0 } },
          hAxis: { gridlines: { count: 15 },title:'Last 15 Days' },
          series: {
            0: {
              areaOpacity: 1, color: '#15426c'
            }
          },
          height: '200',
          width: '700',
          labels: true
        },
        roles: []
      });

    }

  }

  onReady() {

  }

  getFontSize() {
    //return (this.spanValue <= 999) ? '4vw' : '4vw';
    return '4vw';
  }

  onError(error: ChartErrorEvent) {

  }

  onSelect(event: ChartEvent) {

  }

  onMouseEnter(event: ChartEvent) {

  }

  onMouseLeave(event: ChartEvent) {

  }
}
