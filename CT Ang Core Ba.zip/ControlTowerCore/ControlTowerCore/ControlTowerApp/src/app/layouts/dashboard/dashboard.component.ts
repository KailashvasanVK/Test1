import { Component, OnInit, ViewChild } from '@angular/core';
import { LoaderService, DashboardService } from '../../core/services';
import { ChartErrorEvent, ChartEvent, GoogleChartComponent } from '../../modules/angular-google-charts/src/public_api';
import { DashboardMain } from '../../shared/models';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  machinesCount: number;

  charts: Array<{
    title: string,
    type: string,
    data: Array<Array<string | number | {}>>,
    roles: Array<{ type: string, role: string, index?: number }>,
    columnNames?: Array<string>,
    options?: {}
  }> = [];

  @ViewChild('chart')
  chart: GoogleChartComponent;

  dashboardData: DashboardMain;

  constructor(private loader: LoaderService, private dashService: DashboardService) {

    this.dashService.getDashboardData().subscribe(dashData => {    

      this.dashboardData = dashData;
      this.machinesCount = this.dashboardData.Servers.Machines + this.dashboardData.Servers.Servers;

      this.charts.push({
        title: '',
        type: 'PieChart',
        columnNames: ['Type', 'Count'],
        data: [
          ['Desktop', this.dashboardData.Servers.Machines],
          ['Server', this.dashboardData.Servers.Servers]
        ],
        roles: [],
        options: {
          is3D: true,          
          height: '340',
          width: '340',
          colors: ['#15426c', '#fc0303', '#ffc107'],
          pieSliceTextStyle: {
            fontSize: 20
          },
          legend: {
            position:'bottom',
            textStyle: {
              fontSize: 15
            }
          }
        }
      });

    });

  }

  ngOnInit() {    
    
  }
  getFontSize() {
    return (this.machinesCount <= 999) ? '4vw' : '2.5vw';
  }
  onReady() {
    
  }

  onError(error: ChartErrorEvent) {
    
  }

  onSelect(event: ChartEvent) {
    
  }

  onMouseEnter(event: ChartEvent) {
    
  }

  onMouseLeave(event: ChartEvent) {
    
  }
}
