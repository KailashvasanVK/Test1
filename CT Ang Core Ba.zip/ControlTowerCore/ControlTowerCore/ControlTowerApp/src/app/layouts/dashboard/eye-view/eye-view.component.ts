import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { MatRipple } from '@angular/material/core';
import { MatTableDataSource, MatPaginator, MatSort, MatSnackBar, Sort, PageEvent, MatExpansionPanel } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { TaskDetails, GetDetailsInput, ModifyTasks } from '../../../shared/models';
import { DashboardService, SchedulerService } from '../../../core/services'
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { map, expand } from 'rxjs/operators';
import { fromMatSort, sortRows, fromMatPaginator, paginateRows } from '../../../shared/utils/datasource-utils';
import { DateFormatPipe } from '../../../shared/utils/custompipes-utils';
import { isNullOrUndefined } from 'util';
@Component({
  selector: 'app-eye-view',
  templateUrl: './eye-view.component.html',
  styleUrls: ['./eye-view.component.css']
})


export class EyeViewComponent implements OnInit {

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatRipple) ripple: MatRipple;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  static sortEvents$: Observable<Sort>;
  static pageEvents$: Observable<PageEvent>;
  inputDetails: GetDetailsInput = {
    ProcessName: '',
    ServerName: '',
    BotStatus: ''
  };

  displayedRows$: Observable<TaskDetails[]>;
  totalRows$: Observable<number>;
  loadData: TaskDetails[];
  botDataSource: TaskDetails[];

  constructor(
    private route: ActivatedRoute,
    private snackBar: MatSnackBar,
    private changeDetector: ChangeDetectorRef,
    private dashboardService: DashboardService,
    private schedulerService: SchedulerService
  ) {
  }

  ngOnInit() {

    EyeViewComponent.sortEvents$ = fromMatSort(this.sort);
    EyeViewComponent.pageEvents$ = fromMatPaginator(this.paginator);
    this.route.queryParams.subscribe(params => {
      this.inputDetails = {
        ProcessName: params.processName,
        ServerName: params.serverName,
        BotStatus: params.taskStatus
      };
    });
    this.getData();
  }

  expandPanel(matExpansionPanel: MatExpansionPanel, event: Event): void {
    event.stopPropagation();
    if (matExpansionPanel.expanded) matExpansionPanel.close(); else matExpansionPanel.open();
  }

  prevent(matExpansionPanel: MatExpansionPanel, event: Event): void {
    event.preventDefault();
    matExpansionPanel.close();
  }

  toggleSchedule(task, status) {
    let inputTask: ModifyTasks = {
      SchedulerName: task.TaskName,
      Type: status
    };

    this.schedulerService.modifySchedule(inputTask).subscribe(res => {
      if (res == 'Success') {
        task.TaskStatus = (status == 0 ? "Stopped" : "Running");
        this.snackBar.open((status == 0 ? "Schedule stopped." : "Schedule started"), "OK", { duration: 2000, });
      }
    },
      err => {
        if (!isNullOrUndefined(err.error.text) && err.error.text == 'Success') {
          task.TaskStatus = (status == 0 ? "Stopped" : "Running");
          this.snackBar.open((status == 0 ? "Schedule stopped." : "Schedule started"), "OK", { duration: 2000, });
        } else {
          this.snackBar.open(err.error, "OK", { duration: 2000, });
        }

      }
    );

  }
  view(SheduleName) {
    
    this.dashboardService.UpdateActiveStatus(SheduleName.TaskName).subscribe(data => {
      
    },
      error => {
        console.log(error);
      });
  }
  
  getData() {

    this.dashboardService.getBotMonitoringData(this.inputDetails).subscribe(data => {
      this.loadData = this.botDataSource = data;
      const rows$ = of(this.loadData);
      this.totalRows$ = rows$.pipe(map(rows => rows.length));
      this.displayedRows$ = rows$.pipe(sortRows(EyeViewComponent.sortEvents$), paginateRows(EyeViewComponent.pageEvents$), (rows$) => { return DateFormatPipe.apply(rows$); });
      this.changeDetector.detectChanges();
    },
      error => {
        console.log(error);
      });
  }

  applyFilter(filterValue) {
    this.loadData = this.botDataSource.filter(w => w.TaskName.toLowerCase().includes(filterValue.toLowerCase()));
    const rows$ = of(this.loadData);
    this.totalRows$ = rows$.pipe(map(rows => rows.length));
    this.displayedRows$ = rows$.pipe(sortRows(EyeViewComponent.sortEvents$), paginateRows(EyeViewComponent.pageEvents$));
    this.changeDetector.detectChanges();
  }
}

//export const exampleData: TaskDetails[] = [
//  {
//    TaskName: 'EnrollmentDumpDownload_2300',
//    Description: 'US',
//    ProcessName: 'IMO8675368',
//    UserName: 'ahsathena8',
//    TaskStatus: 'running',
//    NextRunTime: new Date(),
//    LastRunTime: new Date(),
//    ServerIp: '10.20.0.116',
//    Repetitionmode: '',
//    HostName: 'BHS_VMIBOT_1',
//    Expanded: false
//  }
//];

