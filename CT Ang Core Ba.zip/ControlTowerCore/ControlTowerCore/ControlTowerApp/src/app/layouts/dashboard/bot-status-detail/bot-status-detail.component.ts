import { Component, OnInit, ViewChild } from '@angular/core';
import { LoaderService, DashboardService } from '../../../core/services';
import { ChartErrorEvent, ChartEvent, GoogleChartComponent } from '../../../modules/angular-google-charts/src/public_api';
import { BotsRunningStatus, BotsServers, BotsServersRunningInput } from '../../../shared/models';
import { Router } from '@angular/router';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-bot-status-detail',
  templateUrl: './bot-status-detail.component.html',
  styleUrls: ['./bot-status-detail.component.css']
})
export class BotStatusDetailComponent implements OnInit {

  spanValue: number;
  charts: Array<{
    title: string,
    type: string,
    data: Array<Array<string | number | {}>>,
    roles: Array<{ type: string, role: string, index?: number }>,
    columnNames?: Array<string>,
    options?: {}
  }> = [];

  serverCharts: Array<{
    title: string,
    type: string,
    data: Array<Array<string | number | {}>>,
    roles: Array<{ type: string, role: string, index?: number }>,
    columnNames?: Array<string>,
    options?: {}
  }> = [];

  serverRunningCharts: Array<{
    title: string,
    type: string,
    data: Array<Array<string | number | {}>>,
    roles: Array<{ type: string, role: string, index?: number }>,
    columnNames?: Array<string>,
    options?: {}
  }> = [];

  @ViewChild('chart')
  chart: GoogleChartComponent;

  botsData: BotsRunningStatus[];
  serverInDetailData: BotsServers[];
  serverInDetailRunningData: BotsRunningStatus;
  currProcessName: string = '';
  currServerName: string = '';

  constructor(private loader: LoaderService, private router: Router, private dashService: DashboardService) {

    var colors = [
      { color: '#0f416c' },
      { color: '#f4b400' },
      { color: '#e3262e' }
    ];
    this.dashService.getBotsRunningStatus().subscribe(botsData => {

      this.botsData = botsData;

      let inputArray: (string | number | {})[][] = [];

      this.botsData.forEach((item) => {
        inputArray.push(new Array<string | number | number | number>(item.ProcessName, item.Running, item.InQueue, item.Stopped));
      });

      this.charts.push({
        title: '',
        type: 'Bar',
        columnNames: ['Bots', 'Running', 'InQueue', 'Stopped'],
        data: inputArray,
        options: {
          stacked: true,
          is3D: true,
          legend: 'none',
          height: '750',
          width: '1200',
          bars: 'horizontal',
          series: colors
        },
        roles: []
      });

    });

  }

  ngOnInit() {

  }
  getFontSize() {
    return (this.spanValue <= 999) ? '4vw' : '2.5vw';
  }
  onReady() {

  }
  onError(error: ChartErrorEvent) {

  }

  onSelectServer(event: ChartEvent) {

    var colors = [
      { color: '#0f416c' },
      { color: '#f4b400' },
      { color: '#e3262e' }
    ];

    if (!isNullOrUndefined(event["0"])) {

      this.serverInDetailRunningData = undefined;
      this.serverRunningCharts = [];

      let sName = this.serverCharts[0].data[event["0"].row];

      this.currServerName = sName["0"];

      let inputData: BotsServersRunningInput = {
        ProcessName: this.currProcessName,
        ServerName: this.currServerName
      }

      this.dashService.getBotsServerRunningStatus(inputData).subscribe(res => {

        this.serverRunningCharts.push({
          title: '',
          type: 'PieChart',
          columnNames: ['Server', 'Count'],
          data: [
            ["Running", res.Running],
            ["InQueue", res.InQueue],
            ["Stopped", res.Stopped]
          ],
          roles: [],
          options: {
            is3D: true,
            legend: 'bottom',
            height: '340',
            width: '340',
            series: colors
          }
        });

        this.serverInDetailRunningData = res;

      });

    }

  }
  onSelectServerRunning(event: ChartEvent) {
    this.router.navigate(['dashboard/processdetails/eyeview'], { queryParams: { processName: this.currProcessName, serverName: this.currServerName, taskStatus: '' } });
  }
  onSelect(event: ChartEvent) {

    if (!isNullOrUndefined(event["0"])) {

      this.serverInDetailRunningData = this.serverInDetailData = undefined;
      this.serverRunningCharts = this.serverCharts = [];
      this.currProcessName = this.currServerName = '';

      let pName = this.charts[0].data[event["0"].row];

      this.currProcessName = pName["0"];

      this.dashService.getBotsServerInDetail(this.currProcessName).subscribe(res => {

        let inputArray: (string | number)[][] = [];

        res.forEach((item) => {
          inputArray.push(new Array<string | number>(item.ServerName, item.Count));
        });

        this.serverCharts.push({
          title: '',
          type: 'PieChart',
          columnNames: ['Server', 'Count'],
          data: inputArray,
          roles: [],
          options: {
            is3D: true,
            legend: 'bottom',
            height: '340',
            width: '340'
          }
        });

        this.serverInDetailData = res;

      });

    }
  }
  onMouseEnter(event: ChartEvent) {

  }
  onMouseLeave(event: ChartEvent) {

  }

}
