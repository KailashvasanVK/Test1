//import { exampleData } from './eye-view/eye-view.component';

export * from './dashboard.component';
export * from './bot-status/bot-status.component';
export * from './processes/processes.component';
export * from './transactions/transactions.component';
export * from './dash-bots/dash-bots.component';
export * from './bot-status-detail/bot-status-detail.component';
export * from './dash-bots/dash-bots.component';
export * from './eye-view/eye-view.component';
export * from './process-bots/process-bots.component';
export * from './transaction-details/transaction-details.component';
