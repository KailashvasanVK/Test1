import { Component, OnInit, ViewChild } from '@angular/core';
import { LoaderService, DashboardService } from '../../../core/services';
import { ChartErrorEvent, ChartEvent, GoogleChartComponent } from '../../../modules/angular-google-charts/src/public_api';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { BotsStatus } from '../../../shared/models';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-transaction-details',
  templateUrl: './transaction-details.component.html',
  styleUrls: ['./transaction-details.component.css']
})
export class TransactionDetailsComponent implements OnInit {

  spanValue: number;
  charts: Array<{
    title: string,
    type: string,
    data: Array<Array<string | number | {}>>,
    roles: Array<{ type: string, role: string, index?: number }>,
    columnNames?: Array<string>,
    options?: {}
  }> = [];

  tranCharts: Array<{
    title: string,
    type: string,
    data: Array<Array<string | number | {}>>,
    roles: Array<{ type: string, role: string, index?: number }>,
    columnNames?: Array<string>,
    options?: {}
  }> = [];

  @ViewChild('chart')
  chart: GoogleChartComponent;

  botsData: BotsStatus[];
  selected = '1';
  DashboardData: number[][];

  constructor(private loader: LoaderService, private router: Router, private dashService: DashboardService) {
    this.drawChart(1);
  }

  drawChart(type: number): void {

    var colors = [
      { color: '#15426c' }
    ];

    this.botsData = undefined;
    this.charts = [];

    this.dashService.getTransactionDetails(type).subscribe(botsData => {

      this.botsData = botsData;

      let inputArray: (string | number)[][] = [];

      this.botsData.forEach((item) => {
        inputArray.push(new Array<string | number>(item.ProcessName, item.ProcessCount));
      });

      this.charts.push({
        title: '',
        type: 'Bar',
        columnNames: ['', 'Process'],
        data: inputArray,
        options: {
          is3D: true,
          legend: 'none',
          height: '750',
          width: '1200',
          bars: 'horizontal',
          series: colors
        },
        roles: []
      });

    });

  }

  ngOnInit() {

  }

  getFontSize() {
    return (this.spanValue <= 999) ? '4vw' : '2.5vw';
  }

  onReady() {

  }

  onError(error: ChartErrorEvent) {

  }

  onSelect(event: ChartEvent) {

    if (!isNullOrUndefined(event["0"])) {
      this.tranCharts = [];
      this.DashboardData = undefined;

      let pName = this.charts[0].data[event["0"].row];

      this.dashService.getTransactionProcess(pName["0"]).subscribe(res => {

        let inputArray: (string | number)[][] = [];

        res.forEach((item) => {
          inputArray.push(new Array<string | number>(item[0].toString(), item[1]));
        });

        this.tranCharts.push({
          title: '',
          type: 'AreaChart',
          columnNames: ['Date', 'Transactions'],
          data: inputArray,
          options: {
            is3D: true,
            legend: 'top',
            vAxis: { gridlines: { count: 0 } },
            hAxis: { gridlines: { count: 15 }, title: 'Last 15 Days' },
            series: {
              0: {
                areaOpacity: 1, color: '#2a709c'
              }
            },
            height: '200',
            width: '700',
            labels: true
          },
          roles: []
        });

        this.DashboardData = res;

      });

    }
  }

  onMouseEnter(event: ChartEvent) {

  }

  onMouseLeave(event: ChartEvent) {

  }

  onModeChange(): void {
    if (!isNullOrUndefined(this.selected))
      this.drawChart(parseInt(this.selected));
  }

}
