import { Component, OnInit, ViewChild, Input, SimpleChanges } from '@angular/core';
import { LoaderService } from '../../../core/services';
import { ChartErrorEvent, ChartEvent, GoogleChartComponent } from '../../../modules/angular-google-charts/src/public_api';
import { DashboardMain } from '../../../shared/models';

@Component({
  selector: 'dash-bot-status',
  templateUrl: './bot-status.component.html',
  styleUrls: ['./bot-status.component.css']
})
export class BotStatusComponent implements OnInit {
  spanValue: number;
  charts: Array<{
    title: string,
    type: string,
    data: Array<Array<string | number | {}>>,
    roles: Array<{ type: string, role: string, index?: number }>,
    columnNames?: Array<string>,
    options?: {}
  }> = [];

  @ViewChild('chart')
  chart: GoogleChartComponent;

  @Input() DashboardData: DashboardMain;

  constructor(private loader: LoaderService) { }

  ngOnInit() { }

  ngOnChanges(change: SimpleChanges) {
    this.inputChangeEvent(change.DashboardData.currentValue)
  }

  inputChangeEvent(DashboardData: DashboardMain) {

    if (DashboardData != undefined) {

      var colors = [
        { color: '#0f416c' },
        { color: '#f4b400' },
        { color: '#e3262e' }
      ];

      this.charts.push({
        title: '',
        type: 'Bar',
        columnNames: ['', 'Running', 'InQueue', 'Stopped'],
        data: [
          ['Athena', DashboardData.BotStatus.Athena.Running, DashboardData.BotStatus.Athena.InQueue, DashboardData.BotStatus.Athena.Stopped],
          ['Non-Athena', DashboardData.BotStatus.NonAthena.Running, DashboardData.BotStatus.NonAthena.InQueue, DashboardData.BotStatus.NonAthena.Stopped],
          ['Customer', DashboardData.BotStatus.Customer.Running, DashboardData.BotStatus.Customer.InQueue, DashboardData.BotStatus.Customer.Stopped]
        ],
        options: {
          is3D: true,
          legend: 'none',
          height: '290',
          width: '700',
          series: colors,
          hAxis: { gridlines: { count: 0 } }
        },
        roles: []
      });

    }

  }

  getFontSize() {
    return (this.spanValue <= 999) ? '4vw' : '2.5vw';
  }
  onReady() {

  }

  onError(error: ChartErrorEvent) {

  }

  onSelect(event: ChartEvent) {

  }

  onMouseEnter(event: ChartEvent) {

  }

  onMouseLeave(event: ChartEvent) {

  }

}
