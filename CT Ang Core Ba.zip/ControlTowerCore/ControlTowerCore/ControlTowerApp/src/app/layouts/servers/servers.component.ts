import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort, MatSnackBar } from '@angular/material';
import { Servers } from '../../shared/models'
import { ServerService } from '../../core/services'
import { DateFormatPipe } from '../../shared/utils/custompipes-utils';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-servers',
  templateUrl: './servers.component.html',
  styleUrls: ['./servers.component.css']
})


export class ServersComponent implements OnInit {

  serversData: Servers[];
  displayedColumns: string[] = ['ServerIp', 'ServerName', 'ServerType', 'CreatedDate', 'ModifiedDate', 'Actions'];
  dataSource: MatTableDataSource<Servers>;
  expandedElement: Servers | null;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  constructor(
    private changeDetector: ChangeDetectorRef,
    private serverService: ServerService,
    private snackBar: MatSnackBar
  ) {
    this.dataSource = new MatTableDataSource(this.serversData);
  }

  ngOnInit() {
    this.getData();
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  deleteServer(server: Servers) {
    if (confirm('Confirm delete? Action cannot be revoked !')) {
      if (server != undefined) {

        let itemIndex = this.dataSource.data.indexOf(this.dataSource.data.find(s => s.ServerIp === server.ServerIp));
        this.serversData.splice(itemIndex, 1);
        this.refresh();

        this.serverService.deleteServer(server.ServerIp).subscribe(() => {
          this.snackBar.open("Server deleted successfully.", "OK", { duration: 2000, });
        },
          () => {
            this.snackBar.open("Something happened wrong. Try again.", "OK", { duration: 2000, });
          });

      } else {
        this.snackBar.open("Unable to delete server. Try again.", "OK", { duration: 2000, });
      }
    }
  }

  update(server: Servers, updated: any) {
    if ((server == undefined) && (updated != null || updated != undefined)) {

      this.serversData.push({
        "Sno": this.dataSource.data.length + 1,
        "ServerIp": updated.machineip,
        "ServerName": updated.machinename,
        "ServerType": updated.machinetype,
        "CreatedDate": new Date(),
        "ModifiedDate": new Date()
      });
      this.refresh();

      const dataServer: Servers = {
        Sno: (this.dataSource.data.length + 1),
        ServerIp: updated.machineip,
        ServerName: updated.machinename,
        ServerType: updated.machinetype,
        CreatedDate: new Date(),
        ModifiedDate: new Date()
      }

      this.serverService.addServer(dataServer).subscribe(() => {
        this.snackBar.open("Server added successfully", "OK", { duration: 2000, });
      },
        () => {
          this.snackBar.open("Something happened wrong. Try again.", "OK", { duration: 2000, });
        });
    }
    else if (updated != null || updated != undefined) {

      let itemToUpdate = this.dataSource.data.find(s => s.Sno === server.Sno);
      let itemIndex = this.dataSource.data.indexOf(itemToUpdate);
      this.dataSource.data[itemIndex].ServerIp = updated.machineip;
      this.dataSource.data[itemIndex].ServerName = updated.machinename;
      this.dataSource.data[itemIndex].ServerType = updated.machinetype;
      this.dataSource.data[itemIndex].ModifiedDate = new Date();

      const dataServer: Servers = {
        Sno: server.Sno,
        ServerIp: updated.machineip,
        ServerName: updated.machinename,
        ServerType: updated.machinetype,
        CreatedDate: server.CreatedDate,
        ModifiedDate: new Date()
      }

      this.serverService.updateServer(dataServer).subscribe(() => {
        this.snackBar.open("Server updated successfully", "OK", { duration: 2000, });
      },
        () => {
          this.snackBar.open("Something happened wrong. Try again.", "OK", { duration: 2000, });
        });
    }
  }

  getData() {

    this.serverService.getAllServers().subscribe(dataServers => {
      this.serversData = dataServers as Servers[]
      this.dataSource = new MatTableDataSource(this.serversData);
      //this.dataSource.data = this.dataSource.data.map(x => {
      //  x.CreatedDate = DateFormatPipe.prototype.transform(x.CreatedDate);
      //  x.ModifiedDate = DateFormatPipe.prototype.transform(x.ModifiedDate);
      //  return x;
      //});
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      this.changeDetector.detectChanges();
    },
      error => {
        console.log(error);
      });

  }

  refresh() {
    this.dataSource = new MatTableDataSource(this.serversData);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.changeDetector.detectChanges();
  }

}
