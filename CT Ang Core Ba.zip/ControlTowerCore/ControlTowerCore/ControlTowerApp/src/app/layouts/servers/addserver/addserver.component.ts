import { Component, OnInit, Optional, Host, Input } from '@angular/core';
import { SatPopover } from '@ncstate/sat-popover';
import { Servers } from '../../../shared/models';

@Component({
  selector: 'addserver',
  templateUrl: './addserver.component.html',
  styleUrls: ['./addserver.component.css']
})
export class AddserverComponent implements OnInit {
  loading = false;
  submitted = false;
  returnUrl: string;
  error = '';
  constructor(@Optional() @Host() public popover: SatPopover) { }
  @Input()
  get value(): Servers { return this._value; }
  set value(x: Servers) {
    this.currentServer = {
      machineip: (x != null || x != undefined) ? x.ServerIp : '',
      machinename: (x != null || x != undefined) ? x.ServerName:'',
      machinetype: (x != null || x != undefined) ? x.ServerType:''
    };
  }
  private _value: Servers;

  currentServer = {
    machinename: '',
    machineip :'',
    machinetype :'',
  };

  ngOnInit() {
   }

  onSave() {
    this.submitted = true;
    if (this.currentServer.machineip == '' || this.currentServer.machinename == '' || this.currentServer.machinetype == '') {
      return;
    }
    if (this.popover) {
      this.popover.close(this.currentServer);
    }
  }

  onCancel() {
    if (this.popover) {
      this.popover.close();
    }
  }
}
