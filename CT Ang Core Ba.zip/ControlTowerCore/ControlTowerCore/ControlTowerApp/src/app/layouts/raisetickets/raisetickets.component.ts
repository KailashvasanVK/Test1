import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { strict } from 'assert';


export interface Department {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-raisetickets',
  templateUrl: './raisetickets.component.html',
  styleUrls: ['./raisetickets.component.css']
})
export class RaiseticketsComponent implements OnInit {
  Issueddl = true;
  Subissueddl = true;
  Supervisorddl = true;
  btnsubmit = true;
  Departments: Department[] = [
    { value: 'steak-0', viewValue: 'Steak' },
    { value: 'pizza-1', viewValue: 'Pizza' },
    { value: 'tacos-2', viewValue: 'Tacos' }
  ];
  constructor() { }

  ngOnInit() {
  }

  DepartmentChange() {
    this.Issueddl = false;
  }
  IssueChange() {
    this.Subissueddl = false;
  }
  SubIssueChange() {
    this.Supervisorddl = false;
  }
  

}
