import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { Task, TargetDrive } from '../../../shared/models';
import { SchedulerService, LoaderService } from '../../../core/services';

@Component({
  selector: 'app-drive-picker',
  templateUrl: './drive-picker.component.html',
  styleUrls: ['./drive-picker.component.css']
})
export class DrivePickerComponent implements OnInit {

  constructor(
    private loaderService: LoaderService,
    private schedulerService: SchedulerService,
    public dialogRef: MatDialogRef<DrivePickerComponent>,
    private snackBar: MatSnackBar,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) { }

  driverInputs: TargetDrive[];
  taskInput: Task;

  closeDialog(): void {
    this.dialogRef.close();
  }

  ngOnInit() {
    if (this.data != undefined) {
      this.driverInputs = this.data.driveData;
      this.taskInput = this.data.taskData;
    }
    //this.loaderService.startLoading();
    //this.schedulerService.getDrives(this.data).subscribe(dataDrives => {
    //  this.driverInputs = dataDrives;
    //  this.loaderService.stopLoading();
    //},
    //  () => {
    //    this.snackBar.open("Something happened wrong. Try again.", "OK", { duration: 2000, });
    //  });
  }

}
