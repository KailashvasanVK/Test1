import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material';
import { Task } from '../../../shared/models';
import { DatetimePickerComponent } from '../datetime-picker/datetime-picker.component';

@Component({
  selector: 'app-mode-info',
  templateUrl: './mode-info.component.html',
  styleUrls: ['./mode-info.component.css']
})
export class ModeInfoComponent implements OnInit {

  constructor(
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<ModeInfoComponent>,
    @Inject(MAT_DIALOG_DATA) public data: Task
  ) { }

  incrementValue: number = 0;
  currMode: string;
  monthPicker: boolean = true;
  weeksChoosen = [];
  monthsChoosen = [];
  daysChoosen = [];

  ngOnInit() {
    this.currMode = this.data.Mode;
  }

  intervalValue(value: number) {
    if (this.incrementValue >= 0 && this.incrementValue <= 30) {
      if ((this.incrementValue == 0 && value == -1) || (this.incrementValue == 30 && value + 1)) return;
      this.incrementValue = this.incrementValue + value;
    }
  }

  openDatePicker() {
    this.dialog.open(DatetimePickerComponent, {
      width: '25%',
      data: this.data
    });
  }

  cancelChanges() {
    this.dialogRef.close();
  }

  saveModeInformation() {

    switch (this.currMode) {
      case 'OneTime':

        break;
      case 'Daily':

        this.data.TaskInputs.RepetitionInterval = this.incrementValue;

        break;
      case 'Weekly':

        this.data.TaskInputs.RepetitionInterval = this.incrementValue;
        this.data.TaskInputs.WeekDays = this.weeksChoosen;

        break;
      case 'Monthly':

        this.data.TaskInputs.RepetitionInterval = this.incrementValue;
        this.data.TaskInputs.RunOnLastDayOfMonth = !this.monthPicker;
        if (this.monthPicker) {
          this.data.TaskInputs.MonthOfYear = [];
          this.data.TaskInputs.DaysOfMonth = [];
        }
        else {
          this.data.TaskInputs.MonthOfYear = this.monthsChoosen;
          this.data.TaskInputs.DaysOfMonth = this.daysChoosen;
        }

        break;
    };    

    this.dialogRef.close();
  }

}
