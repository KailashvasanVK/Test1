import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Task } from '../../shared/models';
import { MatDialog } from '@angular/material';
import { MatTableDataSource, MatPaginator, MatSort, MatSnackBar } from '@angular/material';
import { SchedulerService } from '../../core/services';
import { PromptComponent } from '../../shared/navigation';

@Component({
  selector: 'app-bot-schedule',
  templateUrl: './bot-schedule.component.html',
  providers: [SchedulerService],
  styleUrls: ['./bot-schedule.component.css']
})
export class BotScheduleComponent implements OnInit {
  tasks: Task[];
  task: Task;
  step = 1;

  displayedColumns: string[] = ['SchedulerName', 'ProcessName', 'MachineIP', 'UserName', 'Mode', 'Actions'];
  dataSource: MatTableDataSource<Task>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(
    private schedulerService: SchedulerService,
    private changeDetector: ChangeDetectorRef,
    private snackBar: MatSnackBar,
    public dialog: MatDialog,
  ) {
  }

  ngOnInit() {
    this.getTasks();
  }

  addORupdateSchedule(task: Task) {
    let item = this.dataSource.data.find(s => s.SchedulerName === task.SchedulerName);

    if (item == null) {

      this.tasks.push({
        "Description": task.Description,
        "IdMachine": task.IdMachine,
        "IdProcess": task.IdProcess,
        "IdUser": task.IdUser,
        "MachineIP": task.MachineIP,
        "MachineType": task.MachineType,
        "Mode": task.Mode,
        "ProcessName": task.ProcessName,
        "SchedulerName": task.SchedulerName,
        "TargetDrive": task.TargetDrive,
        "UserName": task.UserName,
        "Password": task.Password,
        "TaskInputs": {
          "DaysOfMonth": task.TaskInputs.DaysOfMonth,
          "ExeName": task.TaskInputs.ExeName,
          "MonthOfYear": task.TaskInputs.MonthOfYear,
          "RepetitionInterval": task.TaskInputs.RepetitionInterval,
          "RunOnLastDayOfMonth": task.TaskInputs.RunOnLastDayOfMonth,
          "StartDateTime": task.TaskInputs.StartDateTime,
          "WeekDays": task.TaskInputs.WeekDays
        }
      });
      this.refresh();

      this.schedulerService.addTask(task).subscribe(() => {
        this.snackBar.open("Scheduler added successfully", "OK", { duration: 2000, });
      },
        () => {
          this.snackBar.open("Scheduler creation failed. Try again later.", "OK", { duration: 2000, });
        });

    } else {

      let itemIndex = this.dataSource.data.indexOf(item);

      this.dataSource.data[itemIndex] = task;
      this.refresh();

      this.schedulerService.updateTask(task).subscribe(() => {
        this.snackBar.open("Scheduler updated successfully", "OK", { duration: 2000, });
      },
        () => {
          this.snackBar.open("Scheduler update failed. Try again later.", "OK", { duration: 2000, });
        });
    }

  }

  //openPromptDialog(): void {    
  //  this.dialog.open(PromptComponent, {
  //    //width: '30%',
  //    data: "Confirm delete? Action cannot be revoked !"
  //  });
  //}

  setStep(index: number) {
    this.step = index;
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  getTasks(): void {
    this.schedulerService.getAll().subscribe(tasks => {
      this.tasks = tasks;
      this.dataSource = new MatTableDataSource(this.tasks);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      this.changeDetector.detectChanges();
    }, error => { console.log(error); });
  }

  //addTask(task: Task): void {
  //  this.scheduler.addTask(task).subscribe(task => this.tasks.push(task));
  //}

  editTask(task: Task): void {
    this.task = {
      Description: task.Description,
      IdMachine: task.IdMachine,
      IdProcess :task.IdProcess,
      IdUser : task.IdUser,
      MachineIP : task.MachineIP,
      MachineType : task.MachineType,
      Mode : task.Mode,
      Password : task.Password,
      ProcessName : task.ProcessName,
      SchedulerName : task.SchedulerName,
      TargetDrive : task.TargetDrive,
      TaskInputs : task.TaskInputs,
      UserName : task.UserName
    }
      this.step = 0;
  }

  deleteTask(task: Task): void {
    if (confirm('Confirm delete? Action cannot be revoked !')) {
      let itemIndex = this.dataSource.data.indexOf(this.dataSource.data.find(s => s.SchedulerName === task.SchedulerName));
      this.tasks.splice(itemIndex, 1);
      this.refresh();

      this.schedulerService.deleteTask(task).subscribe(() => {
        this.snackBar.open("Scheduler deleted successfully", "OK", { duration: 2000, });
      },
        () => {
          this.snackBar.open("Scheduler doesnot exist.", "OK", { duration: 2000, });
        });
    }
  }

  OnSchedulerAddorUpdate(info) {
    if (typeof info != 'string') {
      this.addORupdateSchedule(info);
    }
    this.step = 1;
  }

  refresh() {
    this.dataSource = new MatTableDataSource(this.tasks);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.changeDetector.detectChanges();
  }
}
