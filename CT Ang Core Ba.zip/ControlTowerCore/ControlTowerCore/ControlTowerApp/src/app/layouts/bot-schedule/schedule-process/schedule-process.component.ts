import { Component, OnInit, Input, Output, EventEmitter, SimpleChange, SimpleChanges } from '@angular/core';
import { MatDialog, MatSnackBar } from '@angular/material';
import { SchedulerService ,LoaderService } from '../../../core/services';
import { ProcessInput, ServerInput, UserInput, Task, TargetDrive } from '../../../shared/models';
import { DrivePickerComponent } from '../drive-picker/drive-picker.component';
import { ModeInfoComponent } from '../mode-info/mode-info.component';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'schedule-process',
  templateUrl: './schedule-process.component.html',
  styleUrls: ['./schedule-process.component.css']
})
export class ScheduleProcessComponent implements OnInit {

  processInputs: ProcessInput[];
  serverInputs: ServerInput[];
  userInputs: UserInput[];
  driverInputs: TargetDrive[];

  formGroup: FormGroup;

  constructor
    (
    private scheduleService: SchedulerService,
    public dialog: MatDialog,
    private formBuilder: FormBuilder,
    private loaderService: LoaderService,
    private snackBar: MatSnackBar,
    ) { }

  @Input() taskInfo: Task;

  @Output() dataParent: EventEmitter<any> = new EventEmitter<any>();

  emptyData: Task = {
    SchedulerName: '',
    Description: '',
    MachineIP: '',
    MachineType: 0,
    IdMachine: 0,
    ProcessName: '',
    IdProcess: 0,
    UserName: '',
    IdUser: 0,
    Mode: '',
    TargetDrive: '',
    Password: '',
    TaskInputs: {
      DaysOfMonth: [],
      ExeName: '',
      MonthOfYear: [],
      RepetitionInterval: 0,
      RunOnLastDayOfMonth: false,
      StartDateTime: new Date(),
      WeekDays: []
    }
  };

  ngOnInit() {

    this.taskInfo = this.emptyData;
    this.createValidation();

    this.scheduleService.getFormInputData().subscribe(dataInputs => {

      this.processInputs = dataInputs.ProcessData;
      this.serverInputs = dataInputs.ServerData;
      this.userInputs = dataInputs.UserData;

    },
      error => {
        console.log(error);
      }
    );

  }

  ngOnChanges(change: SimpleChanges) {
    this.inputChangeEvent(change.taskInfo.currentValue)
  }

  inputChangeEvent(taskdet: Task) {
    this.createValidation();
  }

  createValidation() {

    this.formGroup = this.formBuilder.group({
      'process': [null, Validators.required],
      'server': [null, Validators.required],
      'user': [null, Validators.required],
      'description': [null, Validators.required],
      'mode': [null, Validators.required],
    });

  }

  get process() {
    return this.formGroup.get('process') as FormControl
  }
  get server() {
    return this.formGroup.get('server') as FormControl
  }
  get user() {
    return this.formGroup.get('user') as FormControl
  }
  get description() {
    return this.formGroup.get('description') as FormControl
  }
  get mode() {
    return this.formGroup.get('mode') as FormControl
  }

  openTargetDialog(): void {
    this.loaderService.startLoading();
    this.updateTaskInputs();
    this.scheduleService.getDrives(this.taskInfo).subscribe(dataDrives => {
      this.driverInputs = dataDrives;
      this.loaderService.stopLoading();
      this.dialog.open(DrivePickerComponent, {
        width: '30%',
        data: {driveData: this.driverInputs,taskData :this.taskInfo }
      });
    },
      () => {
        this.snackBar.open("Something happened wrong. Try again.", "OK", { duration: 2000, });
      });
  }

  saveTask() {
    console.log(this.taskInfo);
    this.updateTaskInputs();

    this.dataParent.emit(this.taskInfo);
    this.taskInfo = this.emptyData;
  }

  cancelChanges() {
    this.taskInfo = this.emptyData;
    this.dataParent.emit('');
  }

  updateTaskInputs() {
    this.taskInfo.MachineIP = this.serverInputs.find(_ => _.ServerId === this.taskInfo.IdMachine).ServerName;
    this.taskInfo.ProcessName = this.processInputs.find(_ => _.ProcessId === this.taskInfo.IdProcess).ProcessName;
    this.taskInfo.UserName = this.userInputs.find(_ => _.UserId === this.taskInfo.IdUser).UserName;
    this.taskInfo.SchedulerName.length === 0 ? this.taskInfo.SchedulerName = 'CT_' + this.taskInfo.ProcessName + '_Rand' : this.taskInfo.SchedulerName;
  }

  onModeChange(): void {    
    this.updateTaskInputs();
    if (this.taskInfo.Mode != 'RunNow') {
      this.dialog.open(ModeInfoComponent, {
        width: '25%',
        data: this.taskInfo
      });
    }
  }

}
