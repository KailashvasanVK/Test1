import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDatepickerInputEvent } from '@angular/material';
import { Task } from '../../../shared/models';

@Component({
  selector: 'app-datetime-picker',
  templateUrl: './datetime-picker.component.html',
  styleUrls: ['./datetime-picker.component.css']
})
export class DatetimePickerComponent implements OnInit {

  public pickedDate: Date;
  public exportTime = { hour: (new Date().getHours() > 12 ? new Date().getHours() - 12 : new Date().getHours()), minute: new Date().getMinutes(), meriden: (new Date().getHours() >= 12 ? 'PM' : 'AM'), format: 12 };

  constructor
    (
    public dialogRef: MatDialogRef<DatetimePickerComponent>,
    @Inject(MAT_DIALOG_DATA) public data: Task
    ) { }

  ngOnInit() {    
  }

  changeEvent(event: MatDatepickerInputEvent<Date>) {
    this.pickedDate = event.value;
  }

  onRevertTime() {
    this.exportTime = { hour: (new Date().getHours() > 12 ? new Date().getHours() - 12 : new Date().getHours()), minute: new Date().getMinutes(), meriden: (new Date().getHours() >= 12 ? 'PM' : 'AM'), format: 12 };
    this.dialogRef.close();
  }

  onSubmitTime() {
    this.pickedDate.setHours(this.exportTime.meriden == 'PM' ? (this.exportTime.hour + 12) : this.exportTime.hour, this.exportTime.minute);
    this.data.TaskInputs.StartDateTime = this.pickedDate;
    this.dialogRef.close();
  }

}
