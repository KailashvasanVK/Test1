import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { TaskDetails } from '../../../shared/models';

@Component({
  selector: 'processlist',
  templateUrl: './processlist.component.html',
  styleUrls: ['./processlist.component.css']
})
export class ProcesslistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  displayedColumns: string[] = ['TaskName', 'Description', 'ProcessName', 'ServerIp', 'NTLogin', 'LastRunTime', 'NextRunTime', 'Actions'];
  dataSource: MatTableDataSource<TaskDetails>;
}
