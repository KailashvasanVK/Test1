import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bot-monitor',
  templateUrl: './bot-monitor.component.html',
  styleUrls: ['./bot-monitor.component.css']
})
export class BotMonitorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
