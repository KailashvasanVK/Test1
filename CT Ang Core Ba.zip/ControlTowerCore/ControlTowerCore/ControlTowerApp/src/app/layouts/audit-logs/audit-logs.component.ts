import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import * as types from '../../shared/models/LicenseModel';
import { SharedService } from '../../core/services/sharedservice';
import { MatSnackBar } from '@angular/material';
import * as _moment from 'moment';

import { default as _rollupMoment, Moment } from 'moment';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { error } from 'util';

const moment = _rollupMoment || _moment;
export interface Module {
  value: string;
  viewValue: string;
}
export interface PeriodicElement {
  category: string;
  User: string;
  Action: string;
  Time: string;
}

@Component({
  selector: 'app-audit-logs',
  templateUrl: './audit-logs.component.html',
  styleUrls: ['./audit-logs.component.css']
})
export class AuditLogsComponent implements OnInit {
  Moduletype: any;  
  dataSource: PeriodicElement[];
  fromdate = new FormControl('');
  Todate = new FormControl('');
  grdaudit = true;
  inputInvoice = {} as types.inputInvoice;
  Modules: Module[] = [
    { value: '0', viewValue: 'Invoice' },
    { value: '1', viewValue: 'Process' },
    { value: '2', viewValue: 'server' }
  ];
  displayedColumns = ['category', 'User', 'Action', 'Time'];
  constructor(private service: SharedService, private snackBar: MatSnackBar) { }
  
  Searchclick() {    
    this.inputInvoice.FromDate = moment(this.fromdate.value).format('DD/MM/YYYY');
    this.inputInvoice.Todate = moment(this.Todate.value).format('DD/MM/YYYY');
    this.inputInvoice.ModuleType = this.Moduletype;
    this.service.AuditInvoiceData(this.inputInvoice).subscribe((res: any) => { 
      if (res.length > 0) {
        this.dataSource = res;
        this.grdaudit = false;
      }
      else {
        this.grdaudit = true;
        this.snackBar.open("No data found", "OK");
      }
    }, err => {
      this.snackBar.open("Something Went Wrong", "OK");
    });    
  }  
  ngOnInit() {   
    
  }

}
