export interface Role {
  type: string;
  role: string;
  p?: object;
  index?: number;
}
