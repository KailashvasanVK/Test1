import { InjectionToken } from '@angular/core';

export const GOOGLE_API_KEY = new InjectionToken<string>('GOOGLE_API_KEY');
