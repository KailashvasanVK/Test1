import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatFileUploadModule } from 'mat-file-upload';
import {
  MatTabsModule, MatSidenavModule, MatToolbarModule, MatIconModule, MatButtonModule, MatListModule, MatMenuModule, MatTooltipModule,
  MatCardModule, MatExpansionModule, MatDividerModule, MatGridListModule, MatTableModule, MatFormFieldModule, MatInputModule, MatPaginatorModule,
  MatSortModule, MatSelectModule, MatSnackBarModule, MatProgressSpinnerModule, MatAutocompleteModule, MatDialogModule, MatProgressBarModule, MatDatepickerModule,
  MatSlideToggleModule, MatNativeDateModule, MatRippleModule, MatCheckboxModule
} from '@angular/material';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { NgScrollbarModule } from 'ngx-scrollbar';
import { SatPopoverModule } from '@ncstate/sat-popover';
import { TruncateModule } from 'ng2-truncate';
import { MaterialTimeControlModule } from '../material-time-control/src/material-time-control.module';

const modules = [
  MatMenuModule,
  MatTabsModule,
  MatSidenavModule,
  MatToolbarModule,
  MatIconModule,
  MatButtonModule,
  CommonModule,
  MatListModule,
  MatTooltipModule,
  MatCardModule,
  MatExpansionModule,
  MatDividerModule,
  MatGridListModule,
  MatTableModule,
  MatFormFieldModule,
  MatInputModule,
  MatPaginatorModule,
  MatSortModule,
  MatSelectModule,
  MatProgressSpinnerModule,
  SatPopoverModule,
  NgScrollbarModule,
  MatSnackBarModule,
  MatAutocompleteModule,
  MatDialogModule,
  MatProgressBarModule,
  TruncateModule,
  MatDatepickerModule,
  MatSlideToggleModule,
  MaterialTimeControlModule,
  MatNativeDateModule,
  MatRippleModule,
  MatFileUploadModule,
  PdfViewerModule,
  MatCheckboxModule
];

@NgModule({
  imports: [
    modules
  ],
  exports: [
    modules
  ],
  declarations: []
})
export class MaterialModule { }
