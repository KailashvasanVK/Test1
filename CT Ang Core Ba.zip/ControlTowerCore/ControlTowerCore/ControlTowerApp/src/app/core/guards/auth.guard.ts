import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, ActivatedRoute } from '@angular/router';

import { JwtService, Globals } from '../services';
import { first } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {

  returnUrl: string;
  isPostBack: boolean;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private authenticationService: JwtService,
    private global: Globals
  ) {
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/dashboard';
    this.isPostBack = true;
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {

    const currentUser = this.authenticationService.currentUserValue;
        
    if (currentUser && !this.isPostBack) {

      //this.router.navigate(['dashboard'], { queryParams: { returnUrl: state.url } });
      return true;

    } else {

      this.authenticationService.getToken().pipe(first())
        .subscribe(
          data => {
            this.global.signedIn = true;
            this.router.navigate([this.returnUrl]);
            this.isPostBack = false;
            return true;
          },
          error => {
            console.log(error);
            return false;
          });

    }

    //// not logged in so redirect to login page with the return url
    //this.router.navigate(['/'], { queryParams: { returnUrl: state.url } });
    //return false;
  }
}
