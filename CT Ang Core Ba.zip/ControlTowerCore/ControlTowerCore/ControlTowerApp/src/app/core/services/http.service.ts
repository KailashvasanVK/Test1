import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json'
    // 'Authorization': 'my-auth-token',
  })
};

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private http: HttpClient) { }


  getData(url): Observable<any> {

    return this.http.get<any>(url, httpOptions)
      .pipe(
        retry(2),
        catchError(this.handleError)
      );

  };

  postData(url, data: any): Observable<any> {

    return this.http.post(url, data, httpOptions)
      .pipe(
        retry(2),
        catchError(this.handleError)
      );

  };

  deleteData(url, data: number): Observable<any> {
    const urlToDelete = `${url}/${data}`;
    return this.http.delete(urlToDelete, httpOptions)
      .pipe(
        retry(2),
        catchError(this.handleError)
      );

  };

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      console.error('An error occurred:', error.error.message);
    } else {
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    return throwError('Something bad happened; please try again later.');
  };

}
