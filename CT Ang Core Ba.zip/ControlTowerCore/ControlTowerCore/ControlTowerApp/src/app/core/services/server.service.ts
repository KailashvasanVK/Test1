import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Servers, User } from '../../shared/models'
import { HttpErrorHandler, HandleError } from '../services/http-error-handler.service';
import { JwtService } from '../services/jwt.service';

@Injectable({
  providedIn: 'root'
})
export class ServerService {

  serverUrl = 'api/Server';
  private handleError: HandleError;
  private currentUser: User;  
  private httpOptions = {
    headers: new HttpHeaders({
      "Content-Type": "application/json;"
    })
  };
  constructor(
    private http: HttpClient,
    httpErrorHandler: HttpErrorHandler,
    userService: JwtService)
  {
    this.handleError = httpErrorHandler.createHandleError('ServerService');
    this.currentUser = userService.currentUserValue;
    this.httpOptions.headers = this.httpOptions.headers.set('Authorization', "Bearer " + this.currentUser.token);
  }

  getAllServers(): Observable<Servers[]> {
    return this.http.get<Servers[]>(this.serverUrl + '/getAllServers', this.httpOptions)
      .pipe(
        catchError(this.handleError('getAllServers', []))
      );
  }

  addServer(server: Servers): Observable<{}> {
    return this.http.post<Servers>(this.serverUrl + '/addServer', server, this.httpOptions)
      .pipe(
        catchError(this.handleError('addServer', server))
      );
  }

  deleteServer(ip: string): Observable<{}> {
    const url = `${this.serverUrl}/deleteServer/${ip}`;
    return this.http.delete(url, this.httpOptions)
      .pipe(
        catchError(this.handleError('deleteServer'))
      );
  }

  updateServer(server: Servers): Observable<{}> {
    return this.http.put<Servers>(this.serverUrl + '/updateServer', server, this.httpOptions)
      .pipe(
        catchError(this.handleError('updateServer', server))
      );
  }

}
