import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Task, User, SchedulerInputs, TargetDrive, ModifyTasks} from '../../shared/models';
import { HttpErrorHandler, HandleError } from '../services/http-error-handler.service';
import { JwtService } from '../services/jwt.service';

@Injectable({
  providedIn: 'root'
})

export class SchedulerService {

  schedulerUrl = 'api/Schedule';
  private handleError: HandleError;
  private currentUser: User;
  private httpOptions = {
    headers: new HttpHeaders({
      "Content-Type": "application/json;"
    })
  };

  constructor(
    private http: HttpClient,
    httpErrorHandler: HttpErrorHandler,
    userService: JwtService) {
    this.handleError = httpErrorHandler.createHandleError('SchedulerService');
    this.currentUser = userService.currentUserValue;
    this.httpOptions.headers = this.httpOptions.headers.set('Authorization', "Bearer " + this.currentUser.token);
  }

  getDrives(task: Task): Observable<TargetDrive[]> {
    return this.http.post<TargetDrive[]>(this.schedulerUrl + '/getDrives', task, this.httpOptions);
    //.pipe(
    //  catchError(this.handleError('getDrives', []))
    //);
  }

  getFormInputData(): Observable<SchedulerInputs> {
    let errHandle: any;
    return this.http.get<SchedulerInputs>(this.schedulerUrl + '/getScheduleInputs', this.httpOptions)
    //.pipe(
    //  catchError(this.handleError('getInputs', errHandle))
    //);
  }

  getAll(): Observable<Task[]> {
    return this.http.get<Task[]>(this.schedulerUrl + '/getAllSchedules', this.httpOptions)
    //.pipe(
    //  catchError(this.handleError('getAll', []))
    //);
  }

  addTask(task: Task): Observable<Task> {
    return this.http.post<Task>(this.schedulerUrl + '/addTask', task, this.httpOptions)
    //.pipe(
    //  catchError(this.handleError('addTask', task))
    //);
  }

  //deleteTask(taskName: string): Observable<{}> {
  //  const url = `${this.schedulerUrl}/deleteTask/${taskName}`;
  //  return this.http.delete(url, this.httpOptions)
  //  //.pipe(
  //  //  catchError(this.handleError('deleteTask'))
  //  //);
  //}.
  deleteTask(task: Task): Observable<Task> {
    return this.http.put<Task>(this.schedulerUrl + '/deleteTask', task, this.httpOptions)
  }
  updateTask(task: Task): Observable<Task> {
    return this.http.put<Task>(this.schedulerUrl + '/updateTask', task, this.httpOptions)
    //.pipe(
    //  catchError(this.handleError('updateTask', task))
    //);
  }

  modifySchedule(task: ModifyTasks): Observable<string> {
    return this.http.post<string>(this.schedulerUrl + '/modifySchedule', task, this.httpOptions)
  }

}
