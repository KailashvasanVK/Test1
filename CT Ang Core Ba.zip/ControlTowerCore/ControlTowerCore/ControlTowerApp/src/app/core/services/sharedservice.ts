import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject, Subject } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Servers, User } from '../../shared/models'
import { HttpErrorHandler, HandleError } from '../services/http-error-handler.service';
import { JwtService } from '../services/jwt.service';
import * as types from '../../shared/models/LicenseModel'; 

@Injectable({
  providedIn: 'root'
})
export class SharedService {

  
  serverUrl = 'api/License';
  serverUrl1 = 'api/Invoice';
  private handleError: HandleError;
  private currentUser: User;
  private httpOptions = {
    headers: new HttpHeaders({
      "Content-Type": "application/json;"
    })
  };
  cancel: Subject<any> = new Subject();
  data: Subject<any> = new Subject();
  constructor(
    private http: HttpClient,
    httpErrorHandler: HttpErrorHandler,
    userService: JwtService) {
    this.handleError = httpErrorHandler.createHandleError('SharedService');
    this.currentUser = userService.currentUserValue;
    this.httpOptions.headers = this.httpOptions.headers.set('Authorization', "Bearer " + this.currentUser.token);
  }

  getPdfPath(data:types.GenerateInvoice): Observable<any> {
   return this.http.post<types.CompanyDetailsdata>(this.serverUrl1 + '/GetPDFpath', data, this.httpOptions)
      .pipe(
      catchError(this.handleError('GetPDFpath', data))
      );
  }
  GetProcessData(data: types.ProcessstatusData): Observable<any> {
    return this.http.post<types.ProcessstatusData>(this.serverUrl + '/GetProcessStatusdata', data, this.httpOptions)
      .pipe(
      catchError(this.handleError('GetProcessStatusdata', data))
      );
  }
  getCompanies(): Observable<any> {
    return this.http.get<any>(this.serverUrl + '/Companies', this.httpOptions)
      .pipe(
        catchError(this.handleError('getCompanies', []))
      );
  }

  getProcessTypes(): Observable<any> {
    return this.http.get<any>(this.serverUrl + '/ProcessType', this.httpOptions)
      .pipe(
      catchError(this.handleError('getProcessTypes', []))
      );
  }
 
  CheckCompany(CompanyName: any): Observable<any> {
    const url = `${this.serverUrl}/CheckCompany/${CompanyName}`;
    return this.http.get<any>(url, this.httpOptions)
      .pipe(
      catchError(this.handleError('CheckCompany', []))
      );
  }
  getCompaniesbyCompanyname(companyname: any): Observable<any> {
    const url = `${this.serverUrl}/Companiesbyname/${companyname}`;
    return this.http.get<any>(url,  this.httpOptions)
      .pipe(
        catchError(this.handleError('Companiesbyname', []))
      );

  }
  GetCompanyData(companyname: any): Observable<any> {
    const url = `${this.serverUrl}/CompanyData/${companyname}`;
    return this.http.get<any>(url, this.httpOptions)
      .pipe(
      catchError(this.handleError('CompanyData', []))
      );
  }
  CheckPrimeBot(companyname: any): Observable<any> {
       const url = `${this.serverUrl}/CheckPrimeBot/${companyname}`;
    return this.http.get<any>(url, this.httpOptions)
      .pipe(
      catchError(this.handleError('CheckPrimeBot', []))
      );
  }
  getProcessbyCompanyname(companyname: any): Observable<any> {
    const url = `${this.serverUrl}/Processbyname/${companyname}`;
    return this.http.get<any>(url, this.httpOptions)
      .pipe(
      catchError(this.handleError('Processbyname', []))
      );
  }
  GetProductKeys(ClientName: any): Observable<any> {
    const url = `${this.serverUrl}/productKey/${ClientName}`;
    return this.http.get<any>(url, this.httpOptions)
      .pipe(
      catchError(this.handleError('productKey', []))
      );
  } 
  GenerateKeysforClient(CompanyData: types.ClientDetails): Observable<{}> {
    return this.http.post<types.ClientDetails>(this.serverUrl + '/generateKey', CompanyData, this.httpOptions)
      .pipe(
        catchError(this.handleError('addCompany', CompanyData))
      );
  }
  AuditInvoiceData(data:types.inputInvoice): Observable<{}> {
    return this.http.post<types.inputInvoice>('api/audit' + '/GetAuditData', data, this.httpOptions)
      .pipe(
      catchError(this.handleError('GetAuditData', data))
      );
  }
  addCompany(CompanyData: types.CompanyDetailsdata): Observable<{}> {
    return this.http.post<types.CompanyDetailsdata>(this.serverUrl + '/addCompany', CompanyData, this.httpOptions)
      .pipe(
      catchError(this.handleError('addCompany', CompanyData))
      );
  }
  addBotrateDetails(Botrate: types.BotRate): Observable<{}> {
    return this.http.post<types.BotRate>(this.serverUrl + '/AddBotrateDetails', Botrate, this.httpOptions)
      .pipe(
      catchError(this.handleError('AddBotrateDetails', Botrate))
      );
  }

  UpdateCompany(CompanyData: types.CompanyDetailsdata): Observable<{}> {
    return this.http.put<types.CompanyDetailsdata>(this.serverUrl + '/UpdateCompany', CompanyData, this.httpOptions)
      .pipe(
        catchError(this.handleError('UpdateCompany', CompanyData))
      );
  }

  revokeCompany(ip: string): Observable<{}> {
    const url = `${this.serverUrl}/deleteServer/${ip}`;
    return this.http.delete(url, this.httpOptions)
      .pipe(
        catchError(this.handleError('deleteServer'))
      );
  }

  

}
