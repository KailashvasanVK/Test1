import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { RemoteUser, User } from '../../shared/models'
import { HttpErrorHandler, HandleError } from '../services/http-error-handler.service';
import { JwtService } from '../services/jwt.service';

@Injectable({
  providedIn: 'root'
})
export class RemoteusersService {

  apiUrl = 'api/UserConfig';
  private handleError: HandleError;
  private currentUser: User;
  private httpOptions = {
    headers: new HttpHeaders({
      "Content-Type": "application/json;"
    })
  };
  constructor(
    private http: HttpClient,
    httpErrorHandler: HttpErrorHandler,
    userService: JwtService) {
    this.handleError = httpErrorHandler.createHandleError('RemoteusersService');
    this.currentUser = userService.currentUserValue;
    this.httpOptions.headers = this.httpOptions.headers.set('Authorization', "Bearer " + this.currentUser.token);
  }

  getRemoteUsers(): Observable<RemoteUser[]> {
    return this.http.get<RemoteUser[]>(this.apiUrl + '/GetRemoteUsers', this.httpOptions)
      .pipe(
      catchError(this.handleError('GetRemoteUsers', []))
      );
  }

  addRemoteUser(rUser: RemoteUser): Observable<{}> {
    return this.http.post<RemoteUser>(this.apiUrl + '/addRemoteUser', rUser, this.httpOptions)
      .pipe(
      catchError(this.handleError('addRemoteUser', rUser))
      );
  }

  deleteRemoteUser(ip: string): Observable<{}> {
    const url = `${this.apiUrl}/deleteRemoteUser/${ip}`;
    return this.http.delete(url, this.httpOptions)
      .pipe(
      catchError(this.handleError('deleteRemoteUser'))
      );
  }

  updateRemoteUser(rUser: RemoteUser): Observable<{}> {
    return this.http.put<RemoteUser>(this.apiUrl + '/updateRemoteUser', rUser, this.httpOptions)
      .pipe(
      catchError(this.handleError('updateRemoteUser', rUser))
      );
  }

}
