import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { TaskDetails, User } from '../../shared/models';
import { HttpErrorHandler, HandleError } from '../services/http-error-handler.service';
import { JwtService } from '../services/jwt.service';

@Injectable({
  providedIn: 'root'
})
export class MonitorService {
  private monitorUrl = "api/CT_Schedule";
  private handleError: HandleError;
  private currentUser: User;
  private httpOptions = {
    headers: new HttpHeaders({
      "Content-Type": "application/json;"
    })
  };
  constructor(
    private http: HttpClient,
    httpErrorHandler: HttpErrorHandler,
    userService: JwtService) {
    this.handleError = httpErrorHandler.createHandleError('SchedulerService');
    this.currentUser = userService.currentUserValue;
    this.httpOptions.headers = this.httpOptions.headers.set('Authorization', "Bearer " + this.currentUser.token);
  }
  getTasks(): Observable<TaskDetails[]> {
    return this.http.get<TaskDetails[]>(this.monitorUrl + 'getTaskDetails', this.httpOptions)
      .pipe(
        catchError(this.handleError('getTasks',[])) 
      )
  }
}
