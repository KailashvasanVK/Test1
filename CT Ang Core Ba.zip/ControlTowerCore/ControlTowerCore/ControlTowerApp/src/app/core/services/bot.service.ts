import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Bots, User } from '../../shared/models'
import { HttpErrorHandler, HandleError } from '../services/http-error-handler.service';
import { JwtService } from '../services/jwt.service';

@Injectable({
  providedIn: 'root'
})
export class BotService {

  serverUrl = 'api/Process';
  private handleError: HandleError;
  private currentUser: User;  
  private httpOptions = {
    headers: new HttpHeaders({
      "Content-Type": "application/json;"
    })
  };
  constructor(
    private http: HttpClient,
    httpErrorHandler: HttpErrorHandler,
    userService: JwtService)
  {
    this.handleError = httpErrorHandler.createHandleError('BotService');
    this.currentUser = userService.currentUserValue;
    this.httpOptions.headers = this.httpOptions.headers.set('Authorization', "Bearer " + this.currentUser.token);
  }

  getAllProcesses(): Observable<Bots[]> {
    return this.http.get<Bots[]>(this.serverUrl + '/getAllProcesses', this.httpOptions)
      .pipe(
        catchError(this.handleError('getAllServers', []))
      );
  }

  addProcess(process: Bots): Observable<{}> {
    return this.http.post<Bots>(this.serverUrl + '/addProcess', process, this.httpOptions)
      .pipe(
      catchError(this.handleError('addProcess', process))
      );
  }

  deleteProcess(ip: string): Observable<{}> {
    const url = `${this.serverUrl}/deleteProcess/${ip}`;
    return this.http.delete(url, this.httpOptions)
      .pipe(
      catchError(this.handleError('deleteProcess'))
      );
  }

  updateProcess(process: Bots): Observable<{}> {
    return this.http.put<Bots>(this.serverUrl + '/updateProcess', process, this.httpOptions)
      .pipe(
      catchError(this.handleError('updateProcess', process))
      );
  }
  updateBotViewStatus(processId :any): Observable<any> {
    return this.http.get<any>(this.serverUrl + '/UpdateProcessViewStatus?ProcessId='+processId, this.httpOptions)
      .pipe(
      catchError(this.handleError('UpdateProcessViewStatus', []))
      );
  }

}
