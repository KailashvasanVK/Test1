import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DashboardMain, User, BotsStatus, BotsRunningStatus, TaskDetails, GetDetailsInput, BotsServers, BotsServersRunningInput } from '../../shared/models';
import { HttpErrorHandler, HandleError } from '../services/http-error-handler.service';
import { JwtService } from '../services/jwt.service';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  dashboardUrl = 'api/Dashboard';
  private handleError: HandleError;
  private currentUser: User;
  private httpOptions = {
    headers: new HttpHeaders({
      "Content-Type": "application/json;"
    })
  };

  constructor(
    private http: HttpClient,
    httpErrorHandler: HttpErrorHandler,
    userService: JwtService
  ) {
    this.handleError = httpErrorHandler.createHandleError('DashboardService');
    this.currentUser = userService.currentUserValue;
    this.httpOptions.headers = this.httpOptions.headers.set('Authorization', "Bearer " + this.currentUser.token);
  }

  getDashboardData(): Observable<DashboardMain> {
    return this.http.get<DashboardMain>(this.dashboardUrl + '/getDashData', this.httpOptions);
  }

  getBotsData(): Observable<BotsStatus[]> {
    return this.http.get<BotsStatus[]>(this.dashboardUrl + '/getBotsData', this.httpOptions);
  }

  getBotsRunningStatus(): Observable<BotsRunningStatus[]> {
    return this.http.get<BotsRunningStatus[]>(this.dashboardUrl + '/getBotsRunningStatus', this.httpOptions);
  }

  getBotsServerInDetail(processName: string): Observable<BotsServers[]> {
    return this.http.post<BotsServers[]>(this.dashboardUrl + '/getBotsServerDetails', '"' + processName + '"', this.httpOptions);
  }
  UpdateActiveStatus(TaskName: string): Observable<BotsServers[]> {
    return this.http.post<BotsServers[]>(this.dashboardUrl + '/UpdateActiveStatus', '"' + TaskName + '"', this.httpOptions);
  }

  getBotsServerRunningStatus(inputData: BotsServersRunningInput): Observable<BotsRunningStatus> {
    return this.http.post<BotsRunningStatus>(this.dashboardUrl + '/getBotsServerRunningStatus', inputData, this.httpOptions);
  }

  getBotMonitoringData(filters: GetDetailsInput): Observable<TaskDetails[]> {
    return this.http.post<TaskDetails[]>(this.dashboardUrl + '/getBotMonitoringData', filters, this.httpOptions);
  }

  getTransactionDetails(type: number): Observable<BotsStatus[]> {
    return this.http.post<BotsStatus[]>(this.dashboardUrl + '/getTransactionDetails', type, this.httpOptions);
  }

  getTransactionProcess(processName: string): Observable<number[][]> {
    return this.http.post<number[][]>(this.dashboardUrl + '/getTransactionProcess', '"' + processName + '"', this.httpOptions);
  }
}
