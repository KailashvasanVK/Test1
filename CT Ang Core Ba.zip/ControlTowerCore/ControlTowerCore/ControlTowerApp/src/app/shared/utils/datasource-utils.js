"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var collections_1 = require("@angular/cdk/collections");
var of_1 = require("rxjs/observable/of");
var combineLatest_1 = require("rxjs/observable/combineLatest");
var concat_1 = require("rxjs/observable/concat");
var operators_1 = require("rxjs/operators");
var defer_1 = require("rxjs/observable/defer");
var SimpleDataSource = /** @class */ (function (_super) {
    __extends(SimpleDataSource, _super);
    function SimpleDataSource(rows$) {
        var _this = _super.call(this) || this;
        _this.rows$ = rows$;
        return _this;
    }
    SimpleDataSource.prototype.connect = function (collectionViewer) { return this.rows$; };
    SimpleDataSource.prototype.disconnect = function (collectionViewer) { };
    return SimpleDataSource;
}(collections_1.DataSource));
exports.SimpleDataSource = SimpleDataSource;
function defaultSort(a, b) {
    //treat null === undefined for sorting
    a = a === undefined ? null : a;
    b = b === undefined ? null : b;
    if (a === b) {
        return 0;
    }
    if (a === null) {
        return -1;
    }
    if (b === null) {
        return 1;
    }
    //from this point on a & b can not be null or undefined.
    if (a > b) {
        return 1;
    }
    else if (a < b) {
        return -1;
    }
    else {
        return 0;
    }
}
/** RxJS operator to map a material Sort object to a sort function */
function toSortFn(sortFns, useDefault) {
    if (sortFns === void 0) { sortFns = {}; }
    if (useDefault === void 0) { useDefault = true; }
    return function (sort$) { return sort$.pipe(operators_1.map(function (sort) {
        if (!sort.active || sort.direction === '') {
            return undefined;
        }
        var sortFn = sortFns[sort.active];
        if (!sortFn) {
            if (!useDefault) {
                throw new Error("Unknown sort property [" + sort.active + "]");
            }
            //By default assume sort.active is a property name, and sort using the default sort
            //  uses < and >.
            sortFn = function (a, b) { return defaultSort(a[sort.active], b[sort.active]); };
        }
        return sort.direction === 'asc' ? sortFn : function (a, b) { return sortFn(b, a); };
    })); };
}
/** Creates an Observable stream of Sort objects from a MatSort component */
function fromMatSort(sort) {
    return concat_1.concat(defer_1.defer(function () { return of_1.of({
        active: sort.active,
        direction: sort.direction
    }); }), sort.sortChange.asObservable());
}
exports.fromMatSort = fromMatSort;
/** RxJs operator to sort an array based on an Observable of material Sort events **/
function sortRows(sort$, sortFns, useDefault) {
    if (sortFns === void 0) { sortFns = {}; }
    if (useDefault === void 0) { useDefault = true; }
    return function (rows$) { return combineLatest_1.combineLatest(rows$, sort$.pipe(toSortFn(sortFns, useDefault)), function (rows, sortFn) {
        if (!sortFn) {
            return rows;
        }
        var copy = rows.slice();
        return copy.sort(sortFn);
    }); };
}
exports.sortRows = sortRows;
/* TODO: handle ngIf'd MatPager controls.

function isEqualPageEvents(a: PageEvent, b: PageEvent) {
  return a.length === b.length
    && a.pageSize === b.pageSize
    && a.pageIndex === b.pageIndex;

}


export function fromMatPaginators(pagers: QueryList<MatPaginator>): Observable<PageEvent> {
  return pagers.changes.pipe(
    startWith(pagers),
    switchMap(_ =>
      merge(...pagers.map(p => fromMatPaginator(p))).pipe(
        distinctUntilChanged(isEqualPageEvents),
        tap(page => pagers.forEach(pager => {
          if (pager.pageIndex !== page.pageIndex) {
            pager.pageIndex = page.pageIndex;
          }
          if (pager.pageSize !== page.pageSize) {
            pager.pageSize = page.pageSize;
          }
          if (pager.length !== page.length) {
            pager.length = page.length;
          }
        }))
      )
    ),
    distinctUntilChanged(isEqualPageEvents),
  );
}
 */
/** Creates an Observable stream of PageEvent objects from a MatPaginator component */
function fromMatPaginator(pager) {
    return concat_1.concat(defer_1.defer(function () { return of_1.of({
        pageIndex: pager.pageIndex,
        pageSize: pager.pageSize,
        length: pager.length,
    }); }), pager.page.asObservable());
}
exports.fromMatPaginator = fromMatPaginator;
/** RxJs operator to paginate an array based on an Observable of PageEvent objects **/
function paginateRows(page$) {
    return function (rows$) { return combineLatest_1.combineLatest(rows$, page$, function (rows, page) {
        var startIndex = page.pageIndex * page.pageSize;
        var copy = rows.slice();
        return copy.splice(startIndex, page.pageSize);
    }); };
}
exports.paginateRows = paginateRows;
//# sourceMappingURL=datasource-utils.js.map
