import { Component, OnInit, Output, Input, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { JwtService, Globals } from '../../../core/services';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
   @Output() public sidenavToggle = new EventEmitter(true);
  public userName: string;
  public signedIn: boolean;
  constructor(
    private authenticationService: JwtService,
    private router: Router,
    private global: Globals
  ) {
    this.signedIn = global.signedIn;
  }

  ngOnInit() {    
    if (this.authenticationService.currentUserValue != null) {
      this.userName = this.authenticationService.currentUserValue.username;
      this.signedIn = this.global.signedIn;
    }
  }

  public onToggleSidenav = () => {
    this.sidenavToggle.emit();
  }
  Auditclick() {
    this.router.navigate(['/Audit-Logs']);
  }
  public onLogOut = () => {
    this.authenticationService.logout();
    this.global.signedIn = false;
    this.router.navigate(['/login']);
  }


}
