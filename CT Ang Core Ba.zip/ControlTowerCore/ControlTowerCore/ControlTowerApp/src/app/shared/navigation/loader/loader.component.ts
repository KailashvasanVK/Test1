import { Component, OnInit, Input } from '@angular/core';
import { LoaderService } from '../../../core/services';
import { Subscription } from "rxjs";
import { debounceTime } from 'rxjs/operators';

@Component({
  selector: 'app-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.css']
})
export class LoaderComponent implements OnInit {

  isLoading : boolean = false;
  loadingSubscription: Subscription;
  constructor(private loadingScreenService: LoaderService) { }

  ngOnInit() {

    this.loadingSubscription = this.loadingScreenService.loadingStatus.pipe(debounceTime(20)).subscribe((value) => {
      this.isLoading = value;
    });   

  }
  
  ngOnDestroy() {
    this.loadingSubscription.unsubscribe();
  }

}
