export interface Task {
  SchedulerName: string,
  Description: string,
  MachineIP: string,
  MachineType: number,
  IdMachine: number,
  ProcessName: string,
  IdProcess: number,
  UserName: string,
  Password: string,
  IdUser: number,
  Mode: string,
  TargetDrive: string,
  TaskInputs: TaskInputs
}

export interface TaskInputs {
  ExeName: string,
  StartDateTime: Date,
  RepetitionInterval: number,
  WeekDays: string[],
  DaysOfMonth: string[],
  MonthOfYear: string[],
  RunOnLastDayOfMonth: boolean
}

export interface ModifyTasks {
  SchedulerName: string,
  Type: number;
}
