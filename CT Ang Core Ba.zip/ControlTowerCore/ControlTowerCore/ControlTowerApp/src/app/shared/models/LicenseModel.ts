export interface Licencetype {
  value: string;
  viewValue: string;
}
export interface RoleType {
  value: string;
  viewValue: string;
}
export interface topping {
  value: string;
  viewValue: string;
} 
export interface CompanyName {
  viewValue: string;
}
export interface ProcessName {
  value: number;
  viewValue: string;
}
export interface ProcessType {
  value: number;
  viewValue: string;
}
export interface LicenceDetails {
  ClientName: string;
  ProcessName: string;
  ClientId: string;
  ProcessId: string;
  flag: string;
}

export interface PdfPath {
  Path: string;
}
export interface GenerateInvoice {
  date: any;
  CompanyName: string;
  ProcessId: number;
}
export interface ProcessstatusData {
  ProcessType: string;
  Status: string;
}

export interface CompanyAvailableDetails {
  Status: string;
  result: string;
}

export interface CompanyDetails {
  EmailId: string;
  address: string;
  MobileNo: string;
  BotInstance: number;
}

export interface CompanyDetailsdata {
  flag: string;
  CompanyName: string;
  ProcessName: string;
  EmailId: string;
  address: string;
  MobileNo: string;
  BotInstance: number;
  buttonName: string;
}
export interface BotRate {
  CompanyName: any;
  ProcessId: number;
  LicenceType: string;
  YearlyCost: number;
  MonthlyCost: number;
  Bot: number;
  Botrate: any;
  PrimeBot: number;
  PrimeBotRate: number;
  RateType: string;
  Rate: number;
  MaintenanceHours: string;
  MaintenanceRate: number;
  AmortizeMonth: number;
  No_of_WorkFolws: number;
  No_of_Bots: number;
}
export interface inputInvoice {
  FromDate: string;
  Todate: string;
  ModuleType: string;
}
export interface ClientDetails {
  ClientName: string;
  ProcessName: string;
  }
export interface BotrateDetails {
  CompanyName: any;
  Botrate: any;
  PrimeBot: number;
  PrimeBotRate: number;
  RateBased: string;
  OptionRate: number;
  Maintenance: string;
  MaintenanceRate: number;
  YearlyCost: number;
  MonthlyCost: number;
  AmortizeMonth: number;
}

