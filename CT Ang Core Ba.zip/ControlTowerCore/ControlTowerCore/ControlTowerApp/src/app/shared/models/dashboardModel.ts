export interface DashboardMain {
  Servers: {
    Machines: number
    Servers: number
  },
  Process: {
    Athena: number,
    NonAthena: number,
    Customer:number
  },
  Bots: {
    Athena: number,
    NonAthena: number,
    Customer: number
  },
  Transaction: number[][],
  BotStatus: {
    Athena: {
      Running: number,
      InQueue: number,
      Stopped: number
    },
    NonAthena: {
      Running: number,
      InQueue: number,
      Stopped: number
    },
    Customer: {
      Running: number,
      InQueue: number,
      Stopped: number
    }
  }
}

export interface BotsStatus {
  ProcessName: string,
  ProcessCount: number
}

export interface BotsRunningStatus {
  ProcessName: string,
  Running: number,
  InQueue: number
  Stopped: number
}

export interface BotsServers {
  ServerName: string,
  Count: number
}

export interface BotsServersRunningInput {
  ProcessName: string,
  ServerName: string  
}
