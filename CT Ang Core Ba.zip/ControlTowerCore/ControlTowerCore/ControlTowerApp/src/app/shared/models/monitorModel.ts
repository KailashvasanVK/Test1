export interface TaskDetails {
  TaskName: string,
  Description: string,
  ProcessName: string,
  ServerIp: string,
  TaskStatus: string,
  HostName: string,
  UserName: string,
  Repetitionmode: string,
  NextRunTime: Date,
  LastRunTime: Date,
  Expanded: boolean
}

export interface GetDetailsInput {
  ProcessName: string;
  ServerName: string;
  BotStatus: string;
}
