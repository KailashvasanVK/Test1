export interface RemoteUser {
  Id: number;
  UserName: string;
  Password: string;
  Domain: string;
  NtLogin: string;
  Status: string;
  CreatedDate: Date;
  ModifiedDate: Date;
  FullName: string;
  FirstName: string;
  LastName: string;
  Email: string;
}

export interface ProcessStatus {
  name: string;
  processType: string;
  Status: string;
  CreatedDate: Date;  
}
