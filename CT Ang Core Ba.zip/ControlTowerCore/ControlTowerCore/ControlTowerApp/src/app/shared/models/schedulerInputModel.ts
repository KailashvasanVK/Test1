export interface SchedulerInputs {
  ServerData: ServerInput[];
  ProcessData: ProcessInput[];
  UserData: UserInput[];
}

export interface ServerInput {
  ServerId: number;
  ServerName: string;
}

export interface ProcessInput {
  ProcessId: number;
  ProcessName: string;
}

export interface UserInput {
  UserId: number;
  UserName: string;
}

export interface TargetDrive {
  Drive: string;
  FreeSpace: string;
  FreeSpacePercent: number;
  TotalSpace: string;
  UsedSpacePercent: number;
  SelectedDrive: boolean;
  ProcessFolderExist: boolean;
}
