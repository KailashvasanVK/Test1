export interface Servers {
  Sno: number;
  ServerIp: string;
  ServerName: string;
  ServerType: string;
  CreatedDate: Date;
  ModifiedDate: Date;
}

export interface Bots {
  Sno: number;
  Name: string;
  UserName: string;
  FileName: string;
  ExeName: string;
  ProcessName: string;
  CreatedDate: Date;
  ModifiedDate: Date;
}
