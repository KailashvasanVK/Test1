﻿namespace ControlTowerCore.Constants
{
    public static class Status
    {
        public const string Active = "Active"; 
        public const string Deleted = "Deleted";
        public const string InQueue = "InQueue";
    }
}
