﻿using System.Collections.Generic;

namespace ControlTowerCore.Constants
{
    public static class Credentials
    {
        public static IDictionary<string, string> Get(int machineType)
        {
            IDictionary<string, string> creds = new Dictionary<string, string>();
            if (machineType == 1)
            {
                creds.Add("UserName", "Serviceaccount1");
                creds.Add("Password", "P@ssw0rd");
                return creds;
            }
            else
            {
                creds.Add("UserName", "ahsathena9");
                creds.Add("Password", "Temp1234");
                return creds;
            }
        }
    }
}
