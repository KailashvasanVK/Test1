﻿namespace ControlTowerCore.Constants
{
    public static class Domain
    {
        public const string AccessHealthcare = "ACCESSHEALTHCAR";
    }
}
