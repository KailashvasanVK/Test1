﻿namespace ControlTowerCore.Constants
{
    public class User
    {

    }
}
