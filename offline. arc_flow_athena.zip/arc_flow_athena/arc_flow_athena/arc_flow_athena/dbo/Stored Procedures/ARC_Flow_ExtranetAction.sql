﻿CREATE Procedure [dbo].[ARC_Flow_ExtranetAction]
@Action varchar(100),    
@UserId int,    
@ILogId int = 0,    
@ILogStatus int = 0,    
@Comments varchar(max) ='',    
@Query varchar(max)='',    
@Sort varchar(max)='',    
@displayStart int=0,    
@displayLength int =25,    
@RecCount int =0    
As    
/*    
Created By  : Karthik Ic     
Created on : 05 July 2013    
Purpose  : To load the basic data into datatable( Testing only )    
Ex : TRN_pExtranetPendingILog  @Action=PendingILog,@UserId=1859 ,@ILogId =51, @Query='',@Sort='',@displayStart=0,@displayLength=25,@RecCount=0,@Result=0    
Ex : TRN_pExtranetPendingILog  @Action=PendingILog,@UserId=1859,@ILogId =51    
ILogComments    
*/    
Begin    
Declare @CustomerId int    
Declare @CmpKey varchar(5)    
Declare  @AccType varchar(1)    
Select @CustomerId = CLIENT_ID, @AccType= AccountType from ARC_REC_Athena..ARC_REC_USER_INFO Where USERID = @UserId    
Select @CmpKey = CmpKey from ADM_Customer where CustomerId =  @CustomerId    
Declare  @Qry varchar(max)    
--********************** Get User Service Here **********************--    
Declare @QryTempClinet  varchar(max)    
if OBJECT_ID('tempdb..#TempUserService') is not null drop table #TempUserService    
Create table #TempUserService( ClientId int,ServiceId int)    
set @QryTempClinet  ='    
Insert into  #TempUserService(ClientId,ServiceId)    
Select Distinct (acli.ClientId) ClientId ,acli.ServiceId ServiceId -- ,ASer.ServiceName,AC.ClientName    
from ARC_FLOW_Athena..ADM_CustomerServices   ACus    
inner join ARC_FLOW_Athena..ADM_ClientServices  ACli on Acus.ServiceId = acli.ServiceId    
inner join ARC_FLOW_Athena..ADM_Service ASer on ASer.ServiceId = ACus.ServiceId    
inner join ARC_FLOW_Athena..ADM_Client  AC on ACli.ClientId = AC.ClientId    
'    
if @AccType = 'G'    
Begin    
--Set @QryTempClinet +='Inner join ARC_FLOW_Athena..ADM_AccessClient ACCli on ACCli.ClientId = Ac.ClientId     
--'    
Set @QryTempClinet +='Inner join ARC_FLOW_Athena..ADM_AccessClient ACCli on Acli.ClientId = ACCli.ClientId and acus.ServiceId = Accli.ServiceId  
'    
End    
Set @QryTempClinet +='Where ACus.CustomerId = ' + CAST(@CustomerId as varchar)    
if @AccType = 'G'    
Begin    
Set @QryTempClinet +='     
and ACCli.UserId =' + cast(@UserId as varchar)    
End    
Set @QryTempClinet += '    
Order by acli.ServiceId '    
print @QryTempClinet    
exec (@QryTempClinet)    
--Select * from #TempUserService    
    
--********************** Get User Service Here **********************--    
    
if OBJECT_ID('tempdb..#PendingILog') is not null drop table #PendingILog    
Create table #PendingILog(ServiceName varchar(50),ClientName varchar(75),BatchNo varchar(50),ScanDate date,PageNo varchar(max),ILogId int,BatchId int,comment varchar(max),Action varchar(max))    
Set @Qry = '    
insert into #PendingILog(ServiceName ,ClientName ,BatchNo ,ScanDate ,PageNo  ,ILogId,BatchId,Action,comment)    
Select    
Ser.ServiceName, Cli.ClientName,Bat.BatchNo,Bat.ScanDate,IL.PageNo  as PageNo,ILogId,Bat.BatchId    
,' + '''<a href ="#" class ="lnkText" onclick="return showDialog(''' + ' +  convert(varchar(10),IL.ILogId)+ ''' + ',' +'''+    
cast(IL.PageNo as varchar)'+ '+ ''' + ')"  >''' + '+'''+' <span class="ui-icon ui-icon-pencil IconBackGround"></span>'''+' + '+ '''</a>''' + ' as Action 
,Comments = (select top 1 Comments  from TRN_k'+@CmpKey+'_tBatchIssueLogHistory ILH  where ILH.ILogId =il.ilogid  order by ilh.ILogHistId desc)
from TRN_k'+@CmpKey+'_tBatchIssueLog IL    
inner join TRN_k'+@CmpKey+'_tBatchQueue BatQ on IL.BatchProcessId = BatQ.BatchProcessId    
inner join TRN_k'+@CmpKey+'_tBatches  as Bat  on Bat.BatchId = IL.BatchId    
-- inner join Adm_AccessClient as ACli on ACli.CustomerId = '+cast(@CustomerId as varchar)+' And ACli.UserId = '+CAST(@UserId as varchar)+'    
inner join #TempUserService TMp on TMp.ClientId =  Bat.ClientId    
inner join ADM_Service Ser on Ser.ServiceId = Bat.ServiceId and Ser.ServiceId = TMp.ServiceId    
inner join ADM_Client Cli on Cli.ClientId = Bat.ClientId  and Cli.ClientId = TMp.ClientId  
Where ILog_Status = 0'    
if isnull(@ILogId,0) <> 0 /** for ILogComments */    
Set @Qry += ' And ILogId = '+ cast(@ILogId as varchar)    
Exec (@Qry)    
print (@Qry)    
----------------------------------------------PendingILog    
if @Action = 'PendingILog'    
Begin    
if @Sort = '' set @Sort = ' order by BatchNo asc'    
if OBJECT_ID('tempdb..#TempIssueLog') is not null drop table #TempIssueLog    
Create table #TempIssueLog(    
RowNumber int    
,ServiceName varchar(50)    
,ClientName varchar(50)    
,BatchNo varchar(50)    
,ScanDate date    
,PageNo varchar(max),    
Action varchar(max),    
Comment varchar(max)    
)    
Set @Qry  ='Insert into #TempIssueLog(RowNumber,ServiceName,ClientName ,BatchNo ,ScanDate ,pageNo,Action,Comment )    
select ROW_NUMBER() OVER ('+@Sort+' )  AS RowNumber ,ServiceName,ClientName ,BatchNo ,ScanDate ,pageNo,Action,Comment    
from(    
Select    
ServiceName,ClientName,BatchNo,ScanDate,PageNo,Action,Comment    
from #PendingILog     
) as tblTest'    
if(@Query<>'')    
Set @qry += ' Where '+@Query+''    
If(@Sort<>'')    
begin    
Set @qry += ' '+@Sort+''    
End    
print @qry    
Exec  (@qry)    
SELECT @RecCount = COUNT(*) FROM #TempIssueLog    
  if @displayLength=-1 set @displayLength = @RecCount    
  declare @QryExec  varchar(max)    
  set @QryExec  = 'select  ServiceName,ClientName ,BatchNo ,convert(varchar,ScanDate ,101) as ScanDate,pageNo,Comment ,Action from #TempIssueLog where RowNumber between '    
  + cast(@displayStart as varchar) +' and ' + cast(@displayLength as varchar) +' SELECT RecCount = COUNT(*) FROM #TempIssueLog '    
  print @QryExec    
  Exec(@QryExec)    
  End    
---------------------------------------------- ILogComments    
if @Action = 'ILogComments'    
Begin    
print 'TRN_k'+@CmpKey+'_tBatchIssueLogHistory'    
Set @Qry = '    
Select Comments    
from TRN_k'+@CmpKey+'_tBatchIssueLogHistory as ILHis    
inner join #PendingILog as PL on PL.ILogId = ILHis.ILogId    
Order by ILHis.ILogHistId    
    
select PL.ServiceName,PL.ClientName ,PL.BatchNo ,convert(varchar,PL.ScanDate,101) as ScanDate,PL.pageNo,Bat.FName,PL.ILogId from TRN_k'+@CmpKey+'_tBatches Bat    
inner join #PendingILog as PL on PL.batchid = Bat.batchid    
'    
print (@Qry)    
exec (@Qry)    
End    
--    ----------------------------------------------ResponseILog                
--if @Action = 'ResponseILog'                    
--Begin                    
--/* Req param ILogId,ILogStatus,Comments */                    
--if (Select COUNT(*) from #PendingILog) > 0                    
-- Begin                    
-- Declare @@ILogHistId int                    
-- Exec TRN_pBatchILogHistoryInsert                    
-- @CmpKey = @CmpKey                
-- ,@ILogId = @ILogId                
-- ,@Comments = @Comments                
-- ,@ILog_Status = @ILogStatus                
-- ,@CreatedBy = @UserId                    
-- Select 'Updated'                    
-- End                    
--Else                    
-- Begin                    
-- Select 'Already Updated'                    
-- End                    
--End                    
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Flow_ExtranetAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Flow_ExtranetAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Flow_ExtranetAction] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Flow_ExtranetAction] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Flow_ExtranetAction] TO [DB_DMLSupport]
    AS [dbo];

