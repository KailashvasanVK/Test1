﻿CREATE PROCEDURE pIndexingAutomation_ViewBatches_New          
(          
@UserInfo varchar(50)          
)          
As   
/*              
Created By     : Gobinath.M                          
Created Date   : 2015-07-21            
Purpose        : To Show the transaction in Indexing Application                          
Ticket/SCR ID  :            
TL Verified By : Ramakrishnan.G            
            
Implemented On : Ganesh           
Implemented On : 28-April-2016        
Reviewed by    : Ganesh           
Reviewed On    : 28-April-2016        
*/                     
Begin           
          
SELECT  BatchID, BatchNo, tb.ScanDate AS ScanDate, b.BATCHTOTAL As DollarAmount,ISNULL(Adm.PayerId , 0) As InsuranceName, '' As Automation,
ClientType = (Select Top 1 Category from ARC_ATHENA.dbo.SubClient_Info (nolock) Where SubClient = SUBSTRING(tb.BatchNo,CHARINDEX('A',tb.BatchNo)+1,(LEN(tb.BatchNo)-CHARINDEX('A',tb.BatchNo))+1)),                
'' AS TaxID, '' AS NPID, '' AS PayeeNo,  FName,'' As CheckDate, 0 As Complete,           
SubClient = SUBSTRING(tb.BatchNo,CHARINDEX('A',tb.BatchNo)+1,(LEN(tb.BatchNo)-CHARINDEX('A',tb.BatchNo))+1)
from dbo.POFF_Batchindex trb            
Inner join TRN_kOFF_tBatches (nolock) tb on tb.BatchNo = trb.batchnum                      
Left join  Arc_Athena..CBO_Payerinfo (nolock) cb on cb.Batch = tb.BatchNo                          
Left join  ADM_PayerName Adm on Adm.PayerName = cb.PAYMENTBATCHROUTE                          
Left join  ARC_Athena..BatchTotal b on b.batchNum = tb.BatchNo                          
Where  trb.userinfo = @UserInfo        
          
END  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[pIndexingAutomation_ViewBatches_New] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexingAutomation_ViewBatches_New] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexingAutomation_ViewBatches_New] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[pIndexingAutomation_ViewBatches_New] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexingAutomation_ViewBatches_New] TO [DB_DMLSupport]
    AS [dbo];

