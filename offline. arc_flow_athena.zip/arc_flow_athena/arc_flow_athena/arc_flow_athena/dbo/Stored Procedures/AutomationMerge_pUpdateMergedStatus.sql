﻿
   CREATE Proc AutomationMerge_pUpdateMergedStatus @Serviceid varchar(10),@Mergetype Varchar(30)       
  as        
 begin    
 /*  
Cretaed By     : Leela.T                    
Created Date   : 09-May-2018                  
Purpose        : Update the Servicedetails after complete the Merge                  
Ticket/SCR ID  : <>                    
TL Verified By : <>                  
                
                
Implemented by : Karmegan.c                 
Implemented On :  10-05-2018    
*/    
  Declare @StrCmd varchar(300)     
  Set @StrCmd='update Merge_tStatusofMerged set LastMergeddt=''' + Convert(Varchar(30),getdate()) +''' where ChildServiceid= cast('''+ @Serviceid +'''as int) and servicename like ' +  '''%' + @Mergetype + '%'''    exec (@StrCmd)  
 End


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AutomationMerge_pUpdateMergedStatus] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AutomationMerge_pUpdateMergedStatus] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AutomationMerge_pUpdateMergedStatus] TO [DB_DMLSupport]
    AS [dbo];

