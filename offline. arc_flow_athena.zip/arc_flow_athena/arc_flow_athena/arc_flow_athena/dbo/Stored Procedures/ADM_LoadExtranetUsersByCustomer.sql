﻿CREATE Procedure ADM_LoadExtranetUsersByCustomer
@CustomerId int
as
begin
/*
  Created by : Kathiravan.K
  Created Dt : 14-Feb-2014
  Purpose    :     To load the Extranet userd for the specilfic customer in Extanet Report(Productionlogreport.aspx)
*/
   select USERID,UserName from ARC_REC_Athena..ARC_REC_USER_INFO  
   where ExtUser='Y' and ACTIVE=1 and  LastCustomerId = @CustomerId
   order by UserName 
End



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_LoadExtranetUsersByCustomer] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_LoadExtranetUsersByCustomer] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_LoadExtranetUsersByCustomer] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_LoadExtranetUsersByCustomer] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_LoadExtranetUsersByCustomer] TO [DB_DMLSupport]
    AS [dbo];

