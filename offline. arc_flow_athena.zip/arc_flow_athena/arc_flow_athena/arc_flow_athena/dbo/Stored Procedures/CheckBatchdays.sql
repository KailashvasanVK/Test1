﻿CREATE Procedure CheckBatchdays  
as  
begin  
Set nocount on;  
DECLARE @deadlock_var NCHAR(3);  
SET @deadlock_var = N'LOW';  
  
SET DEADLOCK_PRIORITY @deadlock_var;
Set Transaction Isolation Level Read uncommitted;
if OBJECT_id('tempdb.dbo.#temp') is not null  
drop table #temp  
declare @id tinyint=7,@daybatch tinyint,@prebatch tinyint,@updateid tinyint,@Min tinyint,@max tinyint  
  
select DENSE_RANK() OVER(ORDER BY scandate desc) SL,DayBatch,[DayName],ScanDate ,TotalBatch,Completed,TotalBatch-Completed Pending,Top10Pending  
 into #temp from (    
select DATENAME(DW,ScanDate) [DayName],    
ScanDate,TotalBatch=(select count(*) from TRN_kOFF_tBatches sub where status=1 and sub.ScanDate=a.ScanDate),    
Completed=(select count(*) from TRN_kOFF_tBatches sub where status=1 and sub.ScanDate=a.ScanDate and UploadDt is not null),    
Top10Pending=  isnull(STUFF((select top 10 ',' +s.batchno+'(pg-'+convert(varchar,PgCount)+')' from TRN_kOFF_tBatches s    
 where status=1 and a.ScanDate=s.ScanDate and UploadDt is  null order by PgCount desc   
FOR XML PATH('')), 1, 1, ''),'No Pending')  ,    
DayBatch=(case when datepart(weekday,ScanDate)  in(1,7) then 0 else  ROW_NUMBER() OVER(ORDER BY a.scandate desc) end)    
from TRN_kOFF_tBatches a where ScanDate>GETDATE() -7    
group by ScanDate    
) as U  order by 3 desc   
  
  
select @Min=min(SL),@max=Max(SL)  from #Temp where daybatch=0  
set @id =@Min  
while @id<7  
begin  
select @updateid=SL+1 from #Temp where sl=@max  
if @id>5  
break;  
update #Temp set daybatch=@id  where sl=@updateid   
  
set @id=@id+1  
set @max=@max+1  
end  
  
Alter table #Temp drop column Sl  
  
select * from #Temp order by scandate desc  
drop table #Temp  
End
GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CheckBatchdays] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CheckBatchdays] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CheckBatchdays] TO [DB_DMLSupport]
    AS [dbo];

