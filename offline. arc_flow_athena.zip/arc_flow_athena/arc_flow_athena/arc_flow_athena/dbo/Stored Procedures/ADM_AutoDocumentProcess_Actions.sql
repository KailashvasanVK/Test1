﻿CREATE Procedure ADM_AutoDocumentProcess_Actions
(  
	@Action varchar(100)='',   
	@ServiceId int=0,  
	@CustomerId int=0,  
	@ILogClassifyId int=0,
	@CreatedBy int=0,
	@ADPId INT=0,
	@ADPName varchar(100)=''   
)  
As 
BEGIN
/*     
    Purpose :Loading AutoDoc Document insert and Retrival     
    Created By   : Kathiravan          
    Created Date : 27 may 2013          
    Impact to    :servicecreation.aspx          
 */   
 if(@Action='GetILogClassificationByServiceId')
 BEGIN
	select iLog.ClassifyId,iLog.ClassifyName from ADM_AutoDocumentProcess  as doc
	LEFT JOIN ADM_IssueLogClassification as iLog on iLog.ClassifyId=doc.ILogClassifyId
	where doc.ServiceId=@ServiceId and doc.CustomerId=@CustomerId --and doc.CreatedBy = @CreatedBy
	 group by ClassifyId,ClassifyName
 END
 if(@Action ='LoadADPNames')
 begin
		select ADPName,ADPId from  ADM_AutoDocumentProcess doc where  doc.ServiceId=@ServiceId  and doc.CustomerId=@CustomerId  and doc.ILogClassifyId=@ILogClassifyId
		
 end
 if(@Action='ValidateADPName')
 begin
           if exists(select top 1 ADPName from   ADM_AutoDocumentProcess  where ADPName=@ADPName and  ServiceId=@ServiceId and CustomerId=@CustomerId and ILogClassifyId =@ILogClassifyId)
            BEGIN
                select 'Exist'
            END
            ELSE
            BEGIN
                 select 'NotExist'
            END
 end
 if(@Action='LoadParamsByADPName')
 BEGIN
	--select ROW_NUMBER() OVER (order by Params)as Rowno,params.ADPId,params.Params,doc.Script from ADM_AutoDocumentProcessParams as params
	--LEFT JOIN ADM_AutoDocumentProcess as doc on doc.ADPId = params.ADPId
	--where doc.ADPId=@ADPId and doc.ServiceId=@ServiceId and doc.CustomerId=@CustomerId
	select doc.Script from ADM_AutoDocumentProcess as doc 	
	where doc.ADPId=@ADPId and  doc.CustomerId=@CustomerId and ServiceId=@ServiceId 

	select ROW_NUMBER() OVER (order by PId)as Rowno,params.ADPId,params.Params,doc.Script from ADM_AutoDocumentProcessParams as params
	LEFT JOIN ADM_AutoDocumentProcess as doc on doc.ADPId = params.ADPId
	where doc.ADPId=@ADPId and  doc.CustomerId=@CustomerId and @ServiceId=@ServiceId
 END
 if(@Action='MoveToLog')
 begin
      INSERT INTO ADM_AutoDocumentProcessParamsLog(PId,ADPId,Params,CreatedBy,CreatedDt)
       select  PId,ADPId,Params,@CreatedBy,GETDATE() from  ADM_AutoDocumentProcessParams   where  ADPId=@ADPId     
       Delete from   ADM_AutoDocumentProcessParams  where  ADPId=@ADPId   
       
      INSERT INTO ADM_AutoDocumentProcessLog(ADPId,ADPName,ServiceId,CustomerId,ILogClassifyId,Script,CreatedBy,CreatedDt)      
       SELECT ADPId,ADPName,ServiceId,CustomerId,ILogClassifyId,Script,@CreatedBy,GETDATE() FROM ADM_AutoDocumentProcess  where ADPId=@ADPId      
       Delete  from  ADM_AutoDocumentProcess where ADPId=@ADPId   
       
      
 end
END



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_AutoDocumentProcess_Actions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AutoDocumentProcess_Actions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AutoDocumentProcess_Actions] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_AutoDocumentProcess_Actions] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AutoDocumentProcess_Actions] TO [DB_DMLSupport]
    AS [dbo];

