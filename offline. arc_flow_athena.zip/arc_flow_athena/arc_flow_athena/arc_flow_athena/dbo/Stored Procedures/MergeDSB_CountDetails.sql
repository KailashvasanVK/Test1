﻿CREATE Proc MergeDSB_CountDetails @category varchar(20)=Null,@fromDate varchar(10)=null, @ToDate  varchar(10)=null,@payerid int=0 ,@childpayerid int     
as     
begin    
    
Declare @TotBatch Float ,
@ChildCount float, @Percent Float    
    
if (@category='Merge Count')    
begin    
  
select scandate, servicename,count(distinct parentbatchno)as 'Merge Count',COUNT(childbatchno) as chidBatchcount from  TRN_kOFF_tBatches(nolock) a   
inner join mergebatchdetails(nolock) b on a.BatchNo=b.ChildBatchNo  
inner join ADM_Service s on s.ServiceId=a.ServiceId
where  CONVERT(varchar,ScanDate,101) between CONVERT(varchar,@fromDate,101) and CONVERT(varchar,@ToDate ,101)  group by ScanDate,ServiceName
order by ScanDate desc  
End    
    
if(@category='Statusdets')    
begin    
   
create table #StatusDetails(Status varchar(20),StatusCnt Float)    
insert into #StatusDetails    
select  'Pending : '  , Count(BatchNo) from TRN_kOFF_tBatches(NOlock) tbat   
where LEFT(BatchNo,1)='M' and Convert(varchar,ScanDate,101)= Convert(varchar,@fromDate,101) and tbat.status<>99  
and PostedDt is not null  and serviceid=@payerid    
union    
select  'Entry Completed :', Count(BatchNo) from TRN_kOFF_tBatches(NOlock) tbat     
where LEFT(BatchNo,1)='M' and Convert(varchar,ScanDate,101) = Convert(varchar,@fromDate,101) and tbat.status<>99 
and PostedDt is null  and serviceid=@payerid     
union    
select 'QC Completed : ' , Count(BatchNo) from TRN_kOFF_tBatches (NOlock) tbat     
where LEFT(BatchNo,1)='M' and convert(varchar,ScanDate,101) = Convert(varchar,@fromDate,101) and tbat.status<>99  
and PostedDt is not null and AuditedDt is not null and serviceid=@payerid    
union    
select 'Completed : ',COUNT(distinct Mbat.ParentBatchNo) from TRN_kOFF_tBatches (NOlock) tbat    
inner join  mergebatchdetails  (NOlock) Mbat on tbat.batchno=Mbat.ParentBatchNo     
where LEFT(BatchNo,1)='M' and convert(varchar,ScanDate,101)=Convert(varchar,@fromDate,101) and tbat.status=99 and serviceid=@payerid 
  if(@payerid=365)
  begin
  set @childpayerid=355
  End
  else if(@payerid=373)
  begin
  set @childpayerid=357
  end  
select @TotBatch=COUNT(Batchno) from TRN_kOFF_tBatches where ServiceId=@childpayerid and convert(varchar,ScanDate,101)=Convert(varchar,@fromDate,101)     
select @ChildCount=Count(childbatchno) from   mergebatchdetails where ParentBatchNo in (    
select batchno from  TRN_kOFF_tBatches  where LEFT(batchno,1)='M' and convert(varchar,ScanDate,101)=Convert(varchar,@fromDate,101) and ServiceId=@payerid )    
print @TotBatch    
print @ChildCount     
     
Set @Percent =Round((( @ChildCount /@TotBatch))* 100,2)   

insert into #StatusDetails values ('Merged% : ',@Percent)    
select * from #StatusDetails 
drop table  #StatusDetails    
  End   
  End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[MergeDSB_CountDetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MergeDSB_CountDetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MergeDSB_CountDetails] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[MergeDSB_CountDetails] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MergeDSB_CountDetails] TO [DB_DMLSupport]
    AS [dbo];

