﻿CREATE Procedure [dbo].[ADM_ServicePriceConfigActions]  
       @Action VARCHAR(100)  
       ,@CmpKey varchar(20)     
       ,@ServiceId int         
As  
  
Begin  
/*                
Purpose           : To do ClientServiceConfig Actions     
Created By        : Bhuvaneswari                
Created Date      : 1 Apr 2013                
Impact to         : ClientServiceConfig.aspx                
*/     


declare @CUSTOMER_ID int 
select @CUSTOMER_ID = CustomerId from ADM_Customer where CmpKey = @CmpKey
IF @Action = 'GET_CUSTOMER_PENDINGPRICE'  
BEGIN  
if OBJECT_ID('tempdb..#CustomerPendingPrice') is not null drop table #CustomerPendingPrice                        
create table #CustomerPendingPrice(CUSTOMERID int,CUSTOMERNAME varchar(1000),FULLNAME varchar(1000),NUMBEROF_CLIENTS int,PendingPriceCount int)          
  
insert into #CustomerPendingPrice(CUSTOMERID,CUSTOMERNAME,FULLNAME,NUMBEROF_CLIENTS,PendingPriceCount)   
 SELECT CU.CUSTOMERID, CU.INTERNALNAME AS CUSTOMERNAME, CU.FULLNAME   
,(SELECT ISNULL(COUNT(CLIENTID),0) FROM ADM_CLIENT WHERE CUSTOMERID = CU.CUSTOMERID) AS NUMBEROF_CLIENTS,0                
 FROM ADM_CUSTOMER CU                          
 WHERE CU.STATUS = 1  AND CU.CUSTOMERID =@CUSTOMER_ID   
   
 update #CustomerPendingPrice set  
 PendingPriceCount = (select count(c.ClientId) as EmptyPriceCount        
from ADM_ClientServices cs        
left join ADM_ClientServicePrice P on cs.ClientId = p.ClientId and cs.ServiceId = p.ServiceId   
inner join ADM_Service s on s.ServiceId = cs.ServiceId   
and s.FieldType = 'T'  
inner join ADM_Client c on cs.ClientId = c.ClientId            
inner join ADM_Customer Cu on c.CustomerId = cu.CustomerId    
where cu.CustomerId = @CUSTOMER_ID and ISNULL(P.Price,0) = 0)    
from #CustomerPendingPrice tmp  
where PendingPriceCount = 0  
  
   
   
 select * from #CustomerPendingPrice  
END  
ELSE IF @Action = 'GET_CUSTOMERSERVICES'  
Begin  
  
if OBJECT_ID('tempdb..#Customerservices') is not null drop table #Customerservices                          
create table #Customerservices(ServiceId int,ServiceName varchar(500),ServiceAcmName varchar(100),[Description] varchar(1000),EmptyPriceCount int)          
insert into #Customerservices(ServiceId,ServiceName,ServiceAcmName,[Description],EmptyPriceCount)    
select ServiceId,ServiceName,ServiceAcmName,Description,0 from ADM_Service           
where ServiceId in (select distinct(ServiceId) from ADM_ClientServices cs          
inner join ADM_Client c on cs.ClientId = c.ClientId          
inner join ADM_Customer cu on c.CustomerId = cu.CustomerId          
where cu.CustomerId = @CUSTOMER_ID ) and FieldType = 'T'         
    
    
update #Customerservices set    
EmptyPriceCount = (select count(c.ClientId) as EmptyPriceCount        
from ADM_ClientServices cs        
left join ADM_ClientServicePrice P on cs.ClientId = p.ClientId and cs.ServiceId = p.ServiceId          
inner join ADM_Client c on cs.ClientId = c.ClientId            
inner join ADM_Customer Cu on c.CustomerId = cu.CustomerId    
where  cs.ServiceId = tmp.ServiceId and cu.CustomerId = @CUSTOMER_ID and ISNULL(P.Price,0) = 0)    
from #Customerservices tmp    
where EmptyPriceCount = 0    
    
    
select ServiceId,ServiceName,ServiceAcmName,[Description],EmptyPriceCount from #Customerservices    
  
End  
ELSE IF @Action = 'GET_CLIENTSERVICEPRICECONFIGVIEW'  
BEGIN  
select  cu.InternalName as CustomerName,cl.ClientName,se.ServiceName,cu.CustomerId,cs.ClientId,cs.ServiceId,cs.DataType,csp.Price  
from ADM_ClientServices as cs  
inner join ADM_Client as cl on cl.CustomerId = @CUSTOMER_ID and cl.ClientId = cs.ClientId  
inner join ADM_Customer cu on cu.CustomerId = cl.CustomerId  
inner join ADM_Service as se on se.FieldType = 'T' and se.ServiceId = cs.ServiceId  
left join ADM_ClientServicePrice csp on csp.ClientId = cs.ClientId and csp.ServiceId = cs.ServiceId  
END  
ELSE IF @Action = 'GET_CUSTOMERSERVICE_PRICES'  
BEGIN  
select Price from ADM_CustomerServices where CustomerId = @CUSTOMER_ID and ServiceId = @ServiceId  
--select COUNT(CustomerId),ServiceId,CustomerId from ADM_CustomerServices   
--group by CustomerId,ServiceId HAVING COUNT(ServiceId) > 1  
END  
  
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ServicePriceConfigActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ServicePriceConfigActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ServicePriceConfigActions] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ServicePriceConfigActions] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ServicePriceConfigActions] TO [DB_DMLSupport]
    AS [dbo];

