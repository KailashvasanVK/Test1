﻿CREATE Procedure [dbo].[ADM_TATConfigActionsInsert]     
(    
@Action varchar(100)='',   
@CustomerId INT=0,    
@ClientId INT=0,    
@ServiceId INt=0,    
@TatDuration int='',    
@EffectiveFrom varchar(50)='',  
@CreatedBy INT=0,    
@TatId int=0,  
@TID INT OUTPUT       
  
)    
AS    
BEGIN    
IF(@Action ='InsertTAT')        
 BEGIN    
  INSERT INTO ADM_TAT(CustomerId,ClientId,ServiceId,TAT_Duration,EffectiveFrom,CreatedBy)    
  Select @CustomerId,@ClientId,@ServiceId,@TatDuration,convert(varchar,@EffectiveFrom,101),@CreatedBy  
SELECT @TID = IDENT_CURRENT('ADM_TAT')   
 END    
 END


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_TATConfigActionsInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_TATConfigActionsInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_TATConfigActionsInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_TATConfigActionsInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_TATConfigActionsInsert] TO [DB_DMLSupport]
    AS [dbo];

