﻿CREATE Procedure  ADM_ToBeUpload 
(
	@BatchProcessId int = 0,
	@CmpKey varchar(5) = ''
)
as
BEGIN
	Declare @Sql varchar(max)
	Set @Sql = '
	Declare @BatchId int
	Declare @CustomerId int
	Declare @FName varchar(75)
	Set @CustomerId = (Select CustomerId from ADM_Customer where CmpKey = '''+@CmpKey+''')
	Insert into ADM_ToBeUploadTran(CustomerId,BatchId,FName,status,CreatedBy,CreatedDt)
	select @CustomerId,bat.BatchId,bat.FName,0 Status,1777,getdate() 
	from  TRN_k'+@CmpKey+'_tBatches bat
	inner join ADM_ToBeUploadMaster as tobeMaster on tobeMaster.CustomerId = @CustomerId and tobeMaster.ServiceId = bat.ServiceId
	inner join ADM_Customer cust on cust.CustomerId = @CustomerId
	Where exists (Select 1 from TRN_k'+@CmpKey+'_tBatchQueue where BatchProcessId = '+CONVERT(varchar,@BatchProcessId)+' and BatchId = bat.BatchId)
	and not exists (Select 1 from ADM_ToBeUploadTran Where BatchId = @BatchId and CustomerId = @CustomerId)
	'
	print @sql
	Exec (@Sql)
END





GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ToBeUpload] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ToBeUpload] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ToBeUpload] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ToBeUpload] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ToBeUpload] TO [DB_DMLSupport]
    AS [dbo];

