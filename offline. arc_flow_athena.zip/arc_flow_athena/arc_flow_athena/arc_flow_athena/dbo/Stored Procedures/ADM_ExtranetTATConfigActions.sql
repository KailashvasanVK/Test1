﻿CREATE Procedure [dbo].[ADM_ExtranetTATConfigActions]       
(      
@Action varchar(100)='',     
@CustomerId INT=0,      
@ClientId INT=0,      
@ServiceId INT=0,      
@TatDuration INT=0, 
@EffectiveFrom varchar(50)='',    
@CreatedBy INT=0,      
@TatId int=0,
@SearchStr varchar(100) = '',
@SearchPattern varchar(4) = '=' /** = or % **/  
--@FID INT OUTPUT         
    
)      
AS      
BEGIN   
declare @Qry varchar(max)       
IF(@Action ='InsertTAT')          
 BEGIN      
  INSERT INTO ADM_ExtranetTAT(CustomerId,ServiceId,TAT_Duration,EffectiveFrom,CreatedBy)      
  Select @CustomerId,@ServiceId,@TatDuration,convert(varchar,@EffectiveFrom,101),@CreatedBy    
-- SELECT @FID = IDENT_CURRENT('ADM_Factor')     
 END      
ELSE IF(@Action ='SelectTATDetails')      
 BEGIN      
 --select ser.ServiceId as [ServiceId~Hide],t.TATId as [TATId~Hide],ser.ServiceName,t.TAT_Duration,    
 -- CONVERT(varchar,t.EffectiveFrom,101) as EffectiveFrom,CONVERT(varchar,t.EffectiveTo,101) as EffectiveTo,    
 -- case when t.Status=0 then 'Inactive' when t.Status=1 then 'Active' end as Status from ADM_ExtranetTAT t    
   
 select ser.ServiceId as [ServiceId~Hide],t.TATId as [TATId~Hide],isnull(ser.ServiceName,'All') as ServiceName,t.TAT_Duration,    
  CONVERT(varchar,t.EffectiveFrom,101) as EffectiveFrom,CONVERT(varchar,t.EffectiveTo,101) as EffectiveTo,    
  case when t.Status=0 then 'Inactive' when t.Status=1 then 'Active' end as Status ,
  case when t.Status=0 then '' when t.Status=1 then 
  '<div> <div style="float: left;padding-top:6px;"> <a id="btnTatConfig" onclick="return UpdateFactor('+ CONVERT(varchar, TATId )
+ ',' + CONVERT(varchar, TAT_Duration)+','''+CONVERT(varchar, EffectiveFrom)+''',''' + CONVERT(varchar, ser.ServiceName )
+ ''');">   <span class="ui-icon ui-icon-pencil IconBackGround" title="Click here to edit "></span></a></div></div>'  end as [Action]
  from ADM_ExtranetTAT t 
  --inner join ADM_Client c on c.ClientId=t.ClientId      
  left join ADM_Service ser on ser.ServiceId=t.ServiceId where t.CustomerId=@CustomerId   
 END      
ELSE IF(@Action='UpdateTAT')      
 BEGIN      
   Update ADM_ExtranetTAT set Status=0,EffectiveTo=DATEADD(DAY,-1,CONVERT(varchar,@EffectiveFrom,101)),UpdatedBy=@CreatedBy,UpdatedDt=GETDATE()  where TATId=@TatId           
   INSERT INTO ADM_ExtranetTAT(CustomerId ,ClientId,ServiceId,TAT_Duration,EffectiveFrom,CreatedBy)      
    select @CustomerId,ClientId,ServiceId,@TatDuration,convert(varchar,@EffectiveFrom,101),@CreatedBy from ADM_ExtranetTAT where TATId=@TatId
       
 END 
 ELSE IF(@Action='SelectExtranetTATServices')
  BEGIN				
set @Qry ='
		select  Distinct(Ser.ServiceId),Ser.ServiceName from  ADM_CustomerServices cser
		inner join ADM_Service  ser on  ser.ServiceId=cser.ServiceId and  Ser.Status = 1  and Ser.FieldType = ''T'' and ser.ServiceId
		not in (select ServiceId from ADM_ExtranetTAT tat where tat.CustomerId = '+convert(varchar,@CustomerId)+' and Status=1)
		where cser.CustomerId='+convert(varchar,@CustomerId)+''  
		if(select COUNT(*) from ADM_ExtranetTAT where  ServiceId=0) =0
		set @Qry +='union all select ''0'' as ServiceId,''All'' as ServiceName order by ser.ServiceId'
      exec(@Qry) 
  END       
END



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ExtranetTATConfigActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ExtranetTATConfigActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ExtranetTATConfigActions] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ExtranetTATConfigActions] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ExtranetTATConfigActions] TO [DB_DMLSupport]
    AS [dbo];

