﻿Create Proc iEOBMerge_pAvailBatch_Manual  @Scandate varchar(10)
as         
begin        
        
        
/*                                  
                              
Cretaed By     : Leela.T                              
Created Date   : 2018-01-15                                
Purpose        : Check the available batches from iEOB for Manual Merge                         
Ticket/SCR ID  :                              
TL Verified By :          
        
Implemented by :                               
Implemented On :           
        
*/        
        
select Convert(varchar(10),trn.Scandate,101),ttemp.TemplateName ,count(trn.Batchid) as Batch from trn_koff_tbatches(nolock) trn                 
inner join trn_koff_tbatchqueue (nolock) bq on trn.batchno=bq.batchno           
inner join Arc_Athena..Batchmaster (nolock) bat on bat.batchnum=trn.batchno           
inner join arc_athena..iEOB_tAutomationBatchQueue(nolock) tque on tque.batchno=bat.Batchnum  and tque.statusid=5        
inner join arc_athena..iEOB_tAutoIdentifyTemplate ttemp on ttemp.BatchNo = tque.BatchNo            
left join mergebatchdetails (nolock) mrg on trn.batchno=mrg.childbatchno           
left join TRN_kOFF_tBatchResetLog Rp on RP.batchno= trn.batchno    
left join trn_koff_theldbatches (nolock) hld on trn.batchid=hld.batchid                   
where trn.status=88 and trn.posteddt is null  and  bq.assigned=0  and trn.serviceid=452 and (hld.Batchid is null or hld.ReleaseDate is not null)                        
and bq.statusid=0 and  trn.UploadDt is null and left(trn.batchno,1) not in ('M','S') and mrg.childbatchno is null                              
and bat.ULStatus is null and bat.uploaddate is null and PgCount between 2 and 20   and RP.batchno is null 
and Convert(varchar(10),trn.Scandate,101)=Convert(varchar(10),@Scandate,101)                    
group by Convert(varchar(10),trn.Scandate,101),ttemp.TemplateName  having  count(trn.Batchid)<=20    
        
End 
GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOBMerge_pAvailBatch_Manual] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[iEOBMerge_pAvailBatch_Manual] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOBMerge_pAvailBatch_Manual] TO [DB_DMLSupport]
    AS [dbo];

