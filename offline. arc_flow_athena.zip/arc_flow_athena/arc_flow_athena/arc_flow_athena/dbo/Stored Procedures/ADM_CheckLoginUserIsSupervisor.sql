﻿CREATE Procedure ADM_CheckLoginUserIsSupervisor
(
@UserId int
)
AS
Begin
    Declare @Nt_USerName varchar(100)
    
    Set @Nt_USerName=(Select Nt_USername from ARC_REC_Athena..ARC_REC_USER_INFO where USERID=@UserId)
	if exists( Select 1 from ARC_REC_Athena..ARC_REC_USER_INFO where REPORTING_TO=@Nt_USerName)
	select 1 as IsSupervisor
	else 
	select 0 as  IsSupervisor
End


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_CheckLoginUserIsSupervisor] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_CheckLoginUserIsSupervisor] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_CheckLoginUserIsSupervisor] TO [DB_DMLSupport]
    AS [dbo];

