﻿CREATE PROCEDURE BatchIndexing_pExceptionInsert      
(      
@BatchNo varchar(30) = NULL,      
@PayerName varchar(30) = NULL,      
@ntusername varchar(100) = NULL,      
@PageNo int = NULL      
)      
As     
/*      
Created by : Gobi    
Created dt : 2017-02-10      
Purpose : Batch Entry completed status at Indexing pahse   and transaction inserting in batchexception based on the 1099 tax form     
*/        
Begin   
If(@PayerName = '1099TAX')   
Begin   
Declare @UserId int, @BatchProcessID int, @LocationID int      
Set @UserId = (Select USERID from ARC_REC_ATHENA.dbo.ARC_REC_USER_INFO(nolock) Where NT_USERNAME =  @ntusername)      
Set @BatchProcessID = (Select BatchProcessId from ARC_FLOW_ATHENA.dbo.TRN_koff_tBatchQueue(nolock) Where BatchNo = @BatchNo)      
Set @LocationID = (Select LocationId from ARC_FLOW_ATHENA.dbo.trn_koff_tbatches(nolock) Where Batchno = @BatchNo)      
   
/*Batch Exception Insert*/      
Insert into ARC_ATHENA.dbo.BatchException(Amt,descriptions,Comments,pageNum, BatchNum,CheckAmt, ProcessID, CreatedDate, ModifiedBy, ModifiedDate, LocationId, IsQCEntry)       
VALUES (0, @PayerName, '1099 Tax Form', @PageNo, @BatchNo, 0, @BatchProcessID, GETDATE(), @UserId, GETDATE(), @LocationID, 0)      

/*BatchLog Information Added At Feb 02,2018 Ticket : 269090  */
INSERT INTO  Arc_athena.dbo.BatchLogInformation(Batchnum,Pge,CreatedPtnCnt,PaymentInsCnt,ExceptionCnt,PtnPostingCnt,ColPostingCnt,UserId,CreatedDate)                  
VALUES(@BatchNo,@PageNo,0,0,1,0,0,@UserId,GETDATE())         
    
 
      
EXEC CUS_kOFF_pIndexingStageBatchProcessSubmitV1 @BatchNo,@UserId   
      
END   
End 


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[BatchIndexing_pExceptionInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[BatchIndexing_pExceptionInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[BatchIndexing_pExceptionInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[BatchIndexing_pExceptionInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[BatchIndexing_pExceptionInsert] TO [DB_DMLSupport]
    AS [dbo];

