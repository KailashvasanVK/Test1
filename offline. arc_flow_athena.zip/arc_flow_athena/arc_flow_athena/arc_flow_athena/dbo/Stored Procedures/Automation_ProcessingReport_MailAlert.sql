﻿
CREATE Procedure Automation_ProcessingReport_MailAlert  
as  
begin  

if object_id('tempdb.dbo.#TempbatchList') is not null drop table tempdb.dbo.#TempbatchList 
 
create table #TempbatchList (UserName varchar(max),BatchNo varchar(max),	pgCount int,MaxPageProcessed int,	
PaymentTrans int,CreationTrans int,	ExceptionTrans	int, PatientPosting int,CollectionPosting int)

insert into #TempbatchList(UserName,BatchNo,pgCount,MaxPageProcessed,PaymentTrans,CreationTrans,ExceptionTrans,PatientPosting,CollectionPosting)
exec Automation_ProcessingReport
declare @xml varchar(max),@body varchar(Max)          
          
SET @xml = CAST((select ROW_NUMBER() over(order by ServerName) AS 'td',''                      
,UserName AS 'td',''                                   
,BatchNo AS 'td',''                                   
,pgCount AS 'td',''  
,MaxPageProcessed AS 'td',''  
,PaymentTrans  AS 'td'  
,CreationTrans AS 'td',''                                   
,ExceptionTrans AS 'td',''  
,PatientPosting AS 'td',''  
,CollectionPosting  AS 'td' 
from ReplicationStatus  
          
FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))             
          
select @xml           
          
SET @body ='<html><head><title>Access Healthcare</title>                      
   <style type=text/css>                       
   .general{    FONT-FAMILY:VERDANA,ARIAL;FONT-SIZE:8pt;}                      
   .general1{    FONT-FAMILY:VERDANA,ARIAL;FONT-SIZE:14pt;}                      
   .general2{    FONT-FAMILY:VERDANA,ARIAL;FONT-SIZE:12pt;}                      
   .titleTR {     FONT-FAMILY:VERDANA,ARIAL;    FONT-SIZE:8pt; color: #FFFFFF; font-weight:bold; background-color:#003366; height:20;}                      
   tr {      FONT-FAMILY:VERDANA,ARIAL;    FONT-SIZE:8pt; background-color:#F0F0FF ; height:20;}                      
   </style>                       
</head><body>                                    
                                    
<table  border=0 cellspacing=1 cellpadding=1 width=75% align=center  >                                    
<tr class=''titletr''  bgcolor=#1457a7  align=center color=#FFFFFF height=''20''>  
<th><font color=#FFFFFF>SL.No</font></th>                                     
<th>UserName</th>  
<th>BatchNo</th>                                    
<th>pgCount</th>  
<th>MaxPageProcessed</th>  
<th>PaymentTrans</th>  
<th>CreationTrans</th>  
<th>ExceptionTrans</th>                                    
<th>PatientPosting</th>  
<th>CollectionPosting</th>  
 </tr>'                                        
                                     
SET @body = @body + @xml +'<tr class=''titletr''   bgcolor=#1457a7  align=center color=#FFFFFF height=''20''><th colspan=''12''>&nbsp;</th></tr></table></br>                                    
<table>               
</body></html>'                   
                       
           
           
if (len(@body) >50)                          
begin                                 
EXEC msdb.dbo.sp_send_dbmail                                                                                                 
@profile_name = 'ARC_Support',                                                                               
--@recipients='manishankar.pal@accesshealthcare.co' ,                                                                                                     
@recipients='dl_dba@accesshealthcare.com' ,                              
@subject='Transactional Replication Alert' ,                                                                                                                                                                                                  
@body = @body,                                                                                
@body_format  = 'HTML'                    
End                       
                 
END  
GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Automation_ProcessingReport_MailAlert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Automation_ProcessingReport_MailAlert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Automation_ProcessingReport_MailAlert] TO [DB_DMLSupport]
    AS [dbo];

