﻿Create procedure TRN_kOFF_pBucketwiseBatchCount
(
@ScanDateFrom datetime,
@ScanDateTo datetime
)
as
begin 
      select Service,sum(BatchCount) from (
            select ser.ServiceName as Service,count(trn.batchid) as BatchCount from TRN_kOFF_tBatchTransact (nolock) trn
            inner join TRN_kOFF_tBatches (nolock) bat on trn.BatchId=bat.BatchId and bat.status=1
            inner join ADM_Service ser on trn.BatchServiceId=ser.ServiceId
            --inner join Arc_rec_athena..HR_LocationMaster loc on trn.LocationId=loc.LocationID
            where cast(bat.ScanDate as date) between @ScanDateFrom and @ScanDateTo and substring(bat.batchno,1,1) not in ('s','m')
            group by ser.ServiceName--,loc.LocationName
            union all
            select ser.ServiceName as Service,count(trn.batchid) as BatchCount from TRN_kOFF_tBatchTransact (nolock) trn
            inner join TRN_kOFF_tBatches (nolock) bat on trn.BatchId=bat.BatchId and bat.status=99
            inner join ADM_Service ser on trn.BatchServiceId=ser.ServiceId
            --inner join Arc_rec_athena..HR_LocationMaster loc on trn.LocationId=loc.LocationID
            where cast(bat.ScanDate as date) between @ScanDateFrom and @ScanDateTo and substring(bat.batchno,1,1) not in ('s','m')
            group by ser.ServiceName--,loc.LocationName
      )as BtchCount group by Service
end

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pBucketwiseBatchCount] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBucketwiseBatchCount] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBucketwiseBatchCount] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pBucketwiseBatchCount] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBucketwiseBatchCount] TO [DB_DMLSupport]
    AS [dbo];

