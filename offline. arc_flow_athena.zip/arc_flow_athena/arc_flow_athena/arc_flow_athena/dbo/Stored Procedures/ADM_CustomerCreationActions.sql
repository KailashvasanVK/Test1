﻿CREATE Procedure ADM_CustomerCreationActions
@Action   varchar(75),
@CustomerId int = 0 ,
@Price int = 0,
@ServiceId int = 0,
@ValidateName varchar(100) = null,
@SearchVal varchar(50) = null,
@SearchStr varchar(100) = '',  
@SearchPattern varchar(4) = '=' /** = or % **/   
As
/*
Impact to  : CustomerCreation.aspx
Created by : Karthik Ic
Created on : 24 april 2013
Purpose    : To get the data from ADM_Customer based on procedure and user input.
*/
Begin


if @Action = 'ADM_CustomerCreationGet'
-- Purpose    :  To get the Customer details using CustomerId.    --
Begin
Select CustomerId,FinName,FinEmailId,FinPhone1,FinPhone2,FinFax,CONVERT(VARCHAR,ContractStartDt,101) AS  ContractStartDt,
CONVERT(VARCHAR,ContractEndDt,101) AS ContractEndDt,Discount, TAT , Quality ,Status,CustomerAddress,FullName,InternalName,ExternalName
From ADM_Customer  Where Status = 1 and CustomerId = @CustomerId
Select cs.CustomerId,cs.ServiceId,ADMS.serviceName,cs.Price,cs.CSId,cs.FunctionalityId,cs.Paymode,
LEFT(CONVERT(CHAR(20), cs.EffectiveFrom, 101), 2)  + '/' +  cast( datepart(year,cs.EffectiveFrom)AS varchar) as  EffectiveFrom,cs.FteCount
,cs.FtePrice,cs.HrsValue,cs.HrsPrice,cs.HrsFteCount,cs.MonTargetTran,cs.MonPrice,cs.DayTargetTran,cs.DayPrice,cs.DayWorkMode,cs.AprStatus
,isnull(cs.Code,'') as Code,ISNULL(cs.GroupName,'') as GroupName
from ADM_CustomerServices cs
inner join adm_customer AC on AC.customerId = Cs.customerid
inner join ADM_service ADMS on ADMS.ServiceId = cs.serviceId
Where cs.AprStatus in(1,2,3) and cs.CustomerId = @CustomerId
order by  CSId
End
/************************************************************************************************************************************/
else if @Action = 'ADM_CustomerCreationView'
-- Purpose    :  To get the all Customer details to load. --
Begin 
declare @Qry varchar(max)

	if OBJECT_ID('tempdb..#CustomerDetails') is not null drop table #CustomerDetails
	
	Create table #CustomerDetails (FullName	varchar(100),InternalName	varchar(50), BillTo varchar(max),Discount	decimal(5,2)
	,TAT	int,Quality	decimal(5,2),Approval_Status varchar(50),Comments varchar(100),Action varchar(max))
	
	set @Qry  = '
	Insert into #CustomerDetails (FullName,InternalName,BillTo,Discount,TAT,Quality, Approval_Status,Comments,Action)
			Select FullName ,InternalName ,''' 
			 + '<a class="personPopupTrigger" id="reasontip" rel="" > <span class = "ui-icon ui-icon-comment IconBackGround"  ></span> <div class="hdnPopDiv" 
			style="visibility: hidden; display: none;"><div class ="popupDetails" ><table class="popupTblDetails" width  = "450px">
			<tr><th>Finance Person</th><td  class= "popuptdDetails" colspan="3">''+'+' isnull(FinName,''' + ''') + ' + '''</td></tr>
			<tr><th>Address</th><td   class= "popuptdDetails" colspan="3">''+' +' isnull(CustomerAddress,''' + ''') +' + '''</td></tr>
			<tr><th>Email Id</th><td colspan="3" class= "popuptdDetails">''+'+' isnull(FinEmailId,''' + ''') +' + '''</td></tr>
			<tr><th>Phone #1</th><td class= "popuptdDetails">''+' +'  isnull(FinPhone1,''' + ''') +' + '''</td>
			<th>Phone #2</th><td class= "popuptdDetails">''+'+ ' isnull(FinPhone2,''' + ''') +' + '''</td></tr>
			<tr><th>Fax</th><td colspan="3" class= "popuptdDetails" >''+'+ ' isnull(FinFax,''' + ''') +' + '''</td></tr>
			<tr><th>ContractTerm Start</th><td class= "popuptdDetails">''+'+ '  isnull(CONVERT(VARCHAR,ContractStartDt,101),''' + ''') +' + '''</td>
			<th>ContractTerm End</th><td class= "popuptdDetails">''+'+ '  isnull(CONVERT(VARCHAR,ContractEndDt,101),''' + ''') +' + '''</td></tr>
			</table></div></div></a>''' + ',Discount, (Case when TAT = 1 then 24 else 48 end )
			,Case when Quality = 1 then 95 else 98 end ,isnull(StatusCaption,''' + '''),isnull(Comments,'''+''') as Comments,
			''' + '<div> <div style="float: left;padding-top:6px;" title ="Click here to edit the ''+' + 'FullName'+ '' +'+'' details">
			<a id="Edit" onclick="OpenNewDialog(''+'  +'  cast(CustomerId as varchar )'+'+'',''' + ''''''+'+FullName+' +''''''+''');">
			<span  class="ui-icon ui-icon-pencil IconBackGround" ></span></a></div><div style="float: left;">&nbsp;</div></div>'''+'
from ADM_Customer   ADMC
left join  ADM_ApprovalStatus AAS on AAS.AprStatus = isnull (ADMC.AprStatus,1) Where ADMC.Status = 1'	
	
	
	print(@Qry )
	exec (@Qry )

	Exec FilterTable  
	@DbName = 'tempdb'  
	,@TblName = '#CustomerDetails'  
	,@SearchStr = @SearchStr  
	,@SearchPattern = @SearchPattern  
	,@OrderStr = ''
	if OBJECT_ID('tempdb..#CustomerDetails') is not null drop table #CustomerDetails  
	
	
end 
/************************************************************************************************************************************/
else if @Action = 'ADM_CustomerApprovalView'
Begin
-- Purpose    : To Get Approval customer details to view     --
if OBJECT_ID('tempdb..#CustomerApproval') is not null drop table #CustomerApproval
Create table #CustomerApproval( RowNumber int, CreatedBy	varchar(50),CreatedDt	varchar(25),FullName	varchar(100),
InternalName	varchar(50),CustomerId	int)
set @Qry  = '
Insert into #CustomerApproval (RowNumber,FullName,InternalName,CustomerId,CreatedBy,CreatedDt)
Select	ROW_NUMBER() OVER (order by CustomerId  asc )  AS RowNumber,ADMC.FullName,ADMC.InternalName,ADMC.CustomerId,ARUI.NT_USERNAME 
,convert( varchar(21),ADMC.CreatedDt,101) as CreatedDt
from ARC_FLOW_Athena..ADM_Customer ADMC
inner join ARC_REC_Athena..ARC_REC_USER_INFO ARUI on ARUI.USERID =ADMC.CreatedBy
Where ADMC.AprStatus in(2,3)'
--if (isnull(@SearchVal,'') <>'')
--set @Qry   += 'and FinName like ''' + '%' + @SearchVal + '%' +'''
--or FullName  like ''' + '%' + @SearchVal  + '%' +'''
--or InternalName like ''' + '%' + @SearchVal  + '%' +'''
--or NT_USERNAME like ''' + '%' + @SearchVal + '%''' 
set @Qry   += 'order by CustomerId' 
-- print(@Qry )
exec (@Qry )
Select  FullName as FullName,InternalName,CreatedBy as 'CreatedBy / Modify By',CreatedDt as 'CreatedDate / Modify Date',
 '<div> <div style="float: left;padding-top:6px;" title ="Click here to View '+ FullName+' details">
<a id="Edit" onclick="OpenApprovalDialog(' +  cast(CustomerId as varchar )+ ');">
<span  class="ui-icon ui-icon-pencil IconBackGround" ></span></a></div><div style="float: left;">&nbsp;</div></div>' as 'Action'
from  #CustomerApproval
Select COUNT(Rownumber) as RowsCount from #CustomerApproval
End

else if @Action = 'ADM_CustomerFullnameCheck'
-- Purpose    : To check the Customer full name already existing or not.     --
Begin
if exists (Select top 1 'x' from ADM_Customer where  Fullname = @ValidateName)
Select 1 as Result
Else
Select 0 as Result
End

else if @Action = 'ADM_CustomerInernalnameCheck'
-- Purpose    : To check the Customer internal name already existing or not.     --
Begin
if exists (Select top 1 'x' from ADM_Customer where  InternalName = @ValidateName and customerid <> @CustomerId )
Begin
Select 1 as Result
End
Else
Begin
Select 0 as Result
End
End

else if @Action = 'ADM_CustomerExternalnameCheck'
-- Purpose    : To check the Customer external name already existing or not.     --
Begin
if exists (Select top 1 'x' from ADM_Customer where  ExternalName = @ValidateName and customerid <> @CustomerId )
Begin
Select 1 as Result
End
Else
Begin
Select 0 as Result
End
End
ELSE If @Action = 'TranServicesList'
Begin
Select Distinct Ser.ServiceId,Ser.ServiceName
from ADM_Service as Ser
where Ser.Status = 1  and Ser.FieldType = 'T'
Order by Ser.ServiceName
End
ELSE If @Action = 'SelectHolidayType'
Begin
Select Distinct DayType from ADM_WorkingDay 
--where
Order by DayType
End
ELSE If @Action = 'ADM_CustomerPriceDetails'
-- Purpose    : To get the customer services and price list.     --
Begin
Select ADM.ServiceName,ACS.Price from ADM_CustomerServices ACS
inner join  ADM_Service ADM on ADM.ServiceId =ACS.ServiceId
Where CustomerId = @CustomerId and Status =1
order by ADM.ServiceName
End
else if @Action = 'ADM_CustomerServices_PriceCheck'
-- Purpose    : To check the Customer Service price details already existing or not.     --
Begin
if exists (Select top 1 'x' from ADM_CustomerServices where CustomerId=@CustomerId and ServiceId=@ServiceId and Price=@Price )
Begin
Select 1 as Result
End
Else
Begin
Select 0 as Result
End
End
else if @Action = 'ADM_GetWorkingDay'
Begin
Select  distinct(daytype ) from ADM_WorkingDay
End
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_CustomerCreationActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_CustomerCreationActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_CustomerCreationActions] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_CustomerCreationActions] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_CustomerCreationActions] TO [DB_DMLSupport]
    AS [dbo];

