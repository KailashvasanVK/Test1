﻿CREATE Procedure CUS_PPACIF_BatchImportAlgorithm      
@UserName varchar(75)      
as      
Begin      
/*  To Update the ClientId */      
Update  Temp   set Temp.Clientid  =  ADMC.ClientId,Temp.serviceId = ADMS.ServiceId       
from  Temp_CUS_TPACIF_BatchImport Temp       
inner join  ADM_Client ADMC on ADMC.ClientAcmName = Temp.ClientName      
inner join  ADM_service  ADMS on ADMS.serviceName = Temp.ServiceName    
/*  To Update the Invalid Client Status */      
Update  Temp_CUS_TPACIF_BatchImport  set [status] =  'Invalid Client' where ClientId is null      
/*  To Update the Invalid Batchno Status */      
Update  Temp  set [status] =  'Invalid BatchNo'       
from Temp_CUS_TPACIF_BatchImport  Temp      
where exists(Select  BatchNo from  TRN_kPACIF_tBatches  where  BatchNo = Temp.BatchNo and ServiceId =Temp.ServiceId)    
and [status]  is null      
/*  To Update the valid Data*/      
Update  Temp_CUS_TPACIF_BatchImport  set [status] =  'Valid' where [status]  is null      
/*  To Select the all Data*/      
Select ScanDate,BatchNo,ClientName,Status  from Temp_CUS_TPACIF_BatchImport      
/*  To Select the Valid Data*/      
Select TERN.ScanDate,TERN.BatchNo,TERN.ClientId,TERN.ServiceId,UI.USERID from Temp_CUS_TPACIF_BatchImport  TERN      
 inner join ARC_REC_Athena..ARC_REC_USER_INFO UI on UI.NT_USERNAME =@UserName      
where TERN.Status = 'Valid'      
/*  To Drop temp table */      
-- Drop table Temp_CUS_TPACIF_BatchImport       
/*  To get the NT_UserName*/      
End



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_PPACIF_BatchImportAlgorithm] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_PPACIF_BatchImportAlgorithm] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_PPACIF_BatchImportAlgorithm] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_PPACIF_BatchImportAlgorithm] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_PPACIF_BatchImportAlgorithm] TO [DB_DMLSupport]
    AS [dbo];

