﻿CREATE Procedure TRN_GetBatcInfoByName
(
@ServiceName varchar(50),
@ClientAcmName varchar(50)
)
as
BEGIN
       select ClientId from ADM_Client where ClientAcmName=@ClientAcmName
       select ServiceId from ADM_service  where  ServiceName = @ServiceName
END



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_GetBatcInfoByName] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_GetBatcInfoByName] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_GetBatcInfoByName] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_GetBatcInfoByName] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_GetBatcInfoByName] TO [DB_DMLSupport]
    AS [dbo];

