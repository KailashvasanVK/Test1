﻿CREATE Procedure [dbo].[ADM_ServiceInsert]    
(    
@ServiceName varchar(50)    
,@ServiceAcmName varchar(10)    
,@Description varchar(250)    
,@FieldType varchar(1)    
,@Status int    
,@CreatedBy int    
)    
As    
Begin    
 /*     
    Purpose :Insert  services  into  ADM_Service table      
    Created By   : Kathiravan          
    Created Date : 27 may 2013          
    Impact to    :servicecreation.aspx          
 */   
Insert into ADM_Service(ServiceName,ServiceAcmName,Description,FieldType,Status,CreatedBy)    
select @ServiceName,@ServiceAcmName,@Description,@FieldType,@Status,@CreatedBy    
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ServiceInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ServiceInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ServiceInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ServiceInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ServiceInsert] TO [DB_DMLSupport]
    AS [dbo];

