﻿CREATE Procedure TRN_kOFF_pDisregard(@BatchNo varchar(75),@CreatedBy int,@Comments varchar(500))  
As  
Begin  
/*  
Created by : mohamedsafiyu.a  
Created on : 10/15/2015  
Purpose : User can disregard the batch on idexing  
Impact : Offline exe  
*/  
Declare @BatchId int = (Select BatchId from TRN_kOFF_tBatches Where BatchNo = @BatchNo)  
Update TRN_kOFF_tBatches Set Status = 0 Where BatchId  = @BatchId  
Update TRN_kOFF_tBatchQueue Set Assigned = 0,StatusId = 19 Where BatchId  = @BatchId  
Insert into TRN_kOFF_tBatchFlow(BatchId,BatchProcessId,CreatedBy,CreatedDt,Comments,StatusId)  
Select BatchId,BatchProcessId,@CreatedBy,GETDATE(),@Comments,19 from TRN_kOFF_tBatchQueue  
where BatchId  = @BatchId     
Insert into TRN_kOFF_tDisRegard (BatchId,CreatedBy,CreatedDt,Comments,App)  
Select @BatchId,@CreatedBy,GETDATE(),@Comments,'offline'   
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pDisregard] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pDisregard] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pDisregard] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pDisregard] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pDisregard] TO [DB_DMLSupport]
    AS [dbo];

