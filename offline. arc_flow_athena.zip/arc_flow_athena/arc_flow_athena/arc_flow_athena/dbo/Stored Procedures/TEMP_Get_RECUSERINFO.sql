﻿CREATE Procedure [dbo].[TEMP_Get_RECUSERINFO]           
  @PageIndex INT =0          
  ,@PageSize INT = 10          
--  ,@PageCount INT Output            
 ,@RecordCount int Output     
  ,@Query  varchar(max)=''  
  ,@sorting  varchar(max)=''         
As          
BEGIN          
/*          
Created By :kathiravan          
Created Dt :06/05/2013          
Purpose    :For Sqlserviceside pagenation purpose[Sample]          
Used Page  : DatatableServersidePagination.aspx          
*/          
DECLARE  @SqlQuery AS VARCHAR(MAX)
   if @sorting = '' set @sorting = ' order by userid asc'
if OBJECT_ID('tempdb..#Results') is not null drop table #Results  
create table #Results  
(  
	RowNumber int   
	,USERID   int   
	,NT_USERNAME varchar(75)          
	,FIRSTNAME   varchar(50)  
	,LASTNAME    varchar(50)  
	,REPORTING_TO varchar(75)  
 )     
 SET @SqlQuery='   
 insert into #Results(RowNumber,USERID,NT_USERNAME,FIRSTNAME          
 ,LASTNAME          
 ,REPORTING_TO    )  
 SELECT ROW_NUMBER() OVER          
 (          
     '+@sorting+'            
 )AS RowNumber          
          
 ,USERID          
 ,NT_USERNAME          
 ,FIRSTNAME          
 ,LASTNAME          
 ,REPORTING_TO     
 FROM ARC_REC_Athena..ARC_REC_USER_INFO
 '    
  Exec(@SqlQuery) 
       
 SELECT @RecordCount = COUNT(*) FROM #Results       
 --SELECT NT_USERNAME ,FIRSTNAME ,LASTNAME,REPORTING_TO FROM #Results 
 --WHERE RowNumber BETWEEN @PageIndex  AND @PageSize
  Exec('SELECT  USERID ,NT_USERNAME,FIRSTNAME,LASTNAME ,REPORTING_TO   
  FROM #Results  WHERE( RowNumber BETWEEN '+@PageIndex+'  AND '+@PageSize+')'+@Query+''+@sorting) 

 
 --print @Query
    
    
-- print(@SqlQuery+@Query)     
END


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TEMP_Get_RECUSERINFO] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TEMP_Get_RECUSERINFO] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TEMP_Get_RECUSERINFO] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TEMP_Get_RECUSERINFO] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TEMP_Get_RECUSERINFO] TO [DB_DMLSupport]
    AS [dbo];

