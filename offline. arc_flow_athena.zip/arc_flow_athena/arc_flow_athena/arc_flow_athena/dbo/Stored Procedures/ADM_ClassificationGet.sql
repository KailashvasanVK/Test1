﻿CREATE Procedure [dbo].[ADM_ClassificationGet]
@Query varchar(max),
@Sort varchar(max),  
@displayStart int=0,  
@displayLength int =0,
@RecCount int =0    
As
/*
  purpose : To select all the error classification details
  createdBy : karthik ic
  CreatedDt : 12 june 2013
  impact to : ErrorClassification.aspx
	
 */
Begin
Declare  @Qry varchar(max)
if @Sort = '' set @Sort = ' order by ClassifyName asc'
if OBJECT_ID('tempdb..#TempClassify') is not null drop table #TempClassify

Create table #TempClassify(
	RowNumber int  
	,ClassifyName varchar(50)
	,SubClassifyName varchar(50)
	,status varchar(10)
	,Action varchar(max))


Set @Qry  ='
insert into #TempClassify(RowNumber,ClassifyName,SubClassifyName ,status ,Action)
SELECT ROW_NUMBER() OVER                          
 ('+@Sort+' )  AS RowNumber ,ClassifyName,SubClassifyName,status,Action from (
Select   AECM.ClassifyName , AECS.SubClassifyName ,
(case when AECM.Status = 0 then '+ '''InActive''' +'
   when AECS.Status = 0 then '+ '''InActive''' +' else  ' + '''Active''' + ' end )  as Status,
(case when AECM.ClassifyName  IS null  then '' ' + ' '' else ' +
''' <div style ="width:100%;"> <div style="float: left;padding-top:6px;" title="Click here to edit the ''' + ' + AECM.ClassifyName + '''+ '" ><a href ="#" class ="lnk" onclick= "return showDialog(&#39;Edit&#39;,&#39;Main&#39;,''' +'+  CONVERT (varchar(25)

, AECM.ClassifyId)  + ''' + ');" ><span class="ui-icon ui-icon-pencil IconBackGround"></span></a></div><div style="float: left;">&nbsp;&nbsp;</div> ''' +' end)
+(case when AECS.SubClassifyName  IS null  then '' ' + ' '' else ' +
'''<div style="float: left;padding-top:6px;" title ="Click here to edit the ''' + ' + AECS.SubClassifyName + '''+ '"><a href ="#" class ="lnk"  onclick= "return showDialog(&#39;Edit&#39;,&#39;Sub&#39;,'''+ '+  CONVERT (varchar(25), AECS.SubClassifyId)  + 

''' + ');" ><span class="ui-icon ui-icon-document IconBackGround"></span></a></div></div> ''' + ' end)  as Action
from  ADM_ErrClassifyMain AECM
left join ADM_ErrClassifyGroup  AECG on AECG.ClassifyId =  AECM.ClassifyId
left join ADM_ErrClassifySub AECS on AECG.SubClassifyId =  AECS.SubClassifyId and AECG.ClassifyId =  AECM.ClassifyId ) as tblclassify'
if(@Query<>'')
Set @qry += ' Where '+@Query+''
If(@Sort<>'')
begin
Set @qry += ' '+@Sort+''
End  
Print ( @qry)
Exec  (@qry)

SELECT @RecCount = COUNT(*) FROM #TempClassify           
        if @displayLength=-1 set @displayLength = @RecCount      
   Exec('select ClassifyName,SubClassifyName ,status ,Action from #TempClassify where RowNumber between '+@displayStart+' and '+@displayLength+'  
    SELECT RecCount = COUNT(*) FROM #TempClassify ')  
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ClassificationGet] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ClassificationGet] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ClassificationGet] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ClassificationGet] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ClassificationGet] TO [DB_DMLSupport]
    AS [dbo];

