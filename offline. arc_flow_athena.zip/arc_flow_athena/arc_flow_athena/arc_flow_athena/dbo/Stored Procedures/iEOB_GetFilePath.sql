﻿CREATE Proc iEOB_GetFilePath     
/*    
CreatedBy:Noor    
CreatedDate : Nov 16,2017    
Purpose : To Get path    
*/    
as    
Begin    
SELECT PathName,PathDetail FROM iEOB_FilePath(nolock) where status=1 order by id  
End 
GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOB_GetFilePath] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[iEOB_GetFilePath] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOB_GetFilePath] TO [DB_DMLSupport]
    AS [dbo];

