﻿CREATE Procedure ADM_ConfigReports_Move
 @ReportName varchar(75) =''
,@CustomerId int = 0
As
/*
 * Purpose : To Remove the Customizied fields. - karthik
 */
 Begin
	Insert into ADM_ConfigReportsLog (CReportId ,ReportName,FieldName,FieldDisplayText,DisplayOrder,customerId,CtrlType,CtrlValue,CreatedBy,CreatedDt)
	Select CReportId ,ReportName,FieldName,FieldDisplayText,DisplayOrder,customerId,CtrlType,CtrlValue,CreatedBy,CreatedDt from ADM_ConfigReports
	Where CustomerId = @CustomerId and ReportName = @reportName  
 	Delete from ADM_ConfigReports  Where CustomerId = @CustomerId and ReportName = @reportName
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ConfigReports_Move] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ConfigReports_Move] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ConfigReports_Move] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ConfigReports_Move] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ConfigReports_Move] TO [DB_DMLSupport]
    AS [dbo];

