﻿CREATE Proc ReviewTarget_ALL (@serviceid int,@fromdate datetime ,@Todate datetime)        
as     
    
    
if OBJECT_ID('Tempdb..#Tem') is not null drop table #Tem        
if OBJECT_ID('Tempdb..#NormalTrans') is not null drop table #NormalTrans       
if OBJECT_ID('Tempdb..#targ') is not null drop table #targ        
if OBJECT_ID('Tempdb..#Sec') is not null drop table #Sec      
if OBJECT_ID('Tempdb..#sec1') is not null drop table #Sec1   

if OBJECT_ID('Tempdb..#Tem_Non') is not null drop table #Tem_Non        
if OBJECT_ID('Tempdb..#NormalTrans_Non') is not null drop table #NormalTrans_Non       
if OBJECT_ID('Tempdb..#targ_Non') is not null drop table #targ_Non        
if OBJECT_ID('Tempdb..#Sec_Non') is not null drop table #Sec_Non      
if OBJECT_ID('Tempdb..#sec1_Non') is not null drop table #Sec1_Non 

   
        
Select (Select top  1 CreatedDt from TRN_kOFF_tBatchFlow where BatchId = bat.BatchId  and StatusId =1 order by CreatedDt) as StartTime,        
(        
Select top  1 CreatedDt from TRN_kOFF_tBatchFlow where BatchId = bat.BatchId  and StatusId =6 order by CreatedDt desc) as EndTime, Batchno , convert(varchar(10),Posteddt,101) as 'Posteddt',        
sum(paymentinscnt)+sum(Exceptioncnt)+sum(Createdptncnt)+sum(ptnpostingcnt) as 'Transcount' into #NormalTrans        
From TRN_kOFF_tBatches bat  inner join  arc_athena..batchloginformation b on bat.batchno=b.batchnum        
Where         
bat.BatchNo  in (select batchno from trn_koff_tbatches where serviceid not in (363) and left(batchno,1)='M' 
and Posteddt between '04/01/2015' and '07/15/2015')        
group by batchid,batchno  ,convert(varchar(10),Posteddt,101)        

select datediff(ss,starttime,endtime) as 'Timetaken', Posteddt,Transcount,Batchno into #Sec from #NormalTrans   

Select (Timetaken/60) as 'Min', Posteddt,Transcount,Batchno 
Into #sec1 From #Sec

-------NonMerge

Select (Select top  1 CreatedDt from TRN_kOFF_tBatchFlow where BatchId = bat.BatchId  and StatusId =1 order by CreatedDt) as StartTime,        
(        
Select top  1 CreatedDt from TRN_kOFF_tBatchFlow where BatchId = bat.BatchId  and StatusId =6 order by CreatedDt desc) as EndTime, Batchno , convert(varchar(10),Posteddt,101) as 'Posteddt',        
sum(paymentinscnt)+sum(Exceptioncnt)+sum(Createdptncnt)+sum(ptnpostingcnt) as 'Transcount' into #NormalTrans_Non        
From TRN_kOFF_tBatches bat  inner join  arc_athena..batchloginformation b on bat.batchno=b.batchnum        
Where         
bat.BatchNo  in (select batchno from trn_koff_tbatches where serviceid not in (363) --and left(batchno,1)='M' 
and Posteddt between '04/01/2015' and '07/15/2015')        
group by batchid,batchno  ,convert(varchar(10),Posteddt,101)        

select datediff(ss,starttime,endtime) as 'Timetaken', Posteddt,Transcount,Batchno into #Sec_Non from #NormalTrans_Non   

Select (Timetaken/60) as 'Min', Posteddt,Transcount,Batchno 
Into #sec1_Non From #Sec_Non

select a.TotalMin + b.TotalMin as 'Tmin',a.Posteddt, a.TotalTran +b.TotalTran  as 'Tran' into #Overall from 
(select sum([Min]) as 'TotalMin',Posteddt,sum(Transcount) as 'TotalTran' from #sec1_Non 
 where convert(decimal(9,2),Transcount)/convert(decimal(9,2),[Min]) * 60*8 > 400 and [Min]>0 --and posteddt <'05/11/2015'
group by Posteddt )a right outer join
(
select sum([Min]) as 'TotalMin',Posteddt,sum(Transcount) as 'TotalTran' from #sec1 
 where convert(decimal(9,2),Transcount)/convert(decimal(9,2),[Min]) * 60*8 > 400
group by Posteddt ) b on a.Posteddt=b.Posteddt
--Order by         b.Posteddt desc
Union  
select sum([Min]) as 'TotalMin',Posteddt,sum(Transcount) as 'TotalTran' from #sec1_Non 
 where convert(decimal(9,2),Transcount)/convert(decimal(9,2),[Min]) * 60*8 > 400 and [Min]>0 and posteddt < ( select Min(Posteddt) from #sec1 )
group by Posteddt
Order by Posteddt desc

select * from #OverAll











--select datediff(mi,starttime,endtime) as 'Timetaken', Transcount,Batchno into #Tem from #NormalTrans        
--select   convert(decimal(9,2),Transcount)/convert(decimal(9,2),Timetaken) * 60*8 as 'Target' into #Targ from #Tem  where Timetaken>0 and Transcount>0        
      
--select  avg(convert(decimal(9,2),Transcount)/convert(decimal(9,2),Timetaken)) * 60*8 as 'Target'  from #Tem  where Timetaken>0 and Transcount>0        
select  avg(Target)  from #Targ where target>400 --and target<1300     
    
Select * from #Tem    
Select * from #NormalTrans    
Select * from #targ
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ReviewTarget_ALL] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ReviewTarget_ALL] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ReviewTarget_ALL] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ReviewTarget_ALL] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ReviewTarget_ALL] TO [DB_DMLSupport]
    AS [dbo];

