﻿CREATE  Procedure ADM_pGetUsersByService
(
@Userid INT =0,
@QcTargetId INT = 0,
@ServiceId INT = 355,
@CustomerId INT = 25
)
AS
Begin

		--Declare @UserLocationId int =(select isnull(LocationID,1) from ARC_REC_ATHENA..ARC_REC_USER_INFO where USERID=@UserId and ACTIVE=1) -- Code added by mallikarjun.nam
		 if OBJECT_ID('tempdb..#UserLocation') is not null drop table #UserLocation
			Create table #UserLocation( locationid int,LocationName varchar(50))
			insert into  #UserLocation(locationId,LocationName)
			exec ADM_GetUserLocation @userid,0
		 
		
		Select ui.EMPCODE,ui.NT_USERNAME,ui.REPORTING_TO ,ui.DOJ,deg.Designation,fun.FunctionName,ui.UserId ,
		LTRIM(RTRIM(substring((Select  ',' + case when functionality = 'P' then 'Process' when Functionality = 'A' then 'Audit' 
else Functionality end from  ADM_AccessFunctionality where UserId = ui.USERID and Functionality in ('A','P') order by AccFunctionalityId for XML path('')),2,50))) as Functionality

		from ARC_REC_Athena..ARC_REC_USER_INFO  ui
		inner join (select distinct UserId from ADM_AccessServices where  CustomerId = @CustomerId and ServiceId = @ServiceId )x
		on  ui.USERID = x.UserId and isnull(ui.LocationID,1) in(select locationid from #UserLocation)--=@UserLocationId
		--inner join ARC_REC_Athena ..ARC_REC_UserCustomer cust  on  cust.UserId = ui.USERID and cust.CustomerID = @CustomerId 	
		inner join ARC_REC_Athena..HR_Designation deg on deg.DesigId = 	ui.DESIGNATION_ID
		inner join ARC_REC_Athena..HR_Functionality fun on fun.FunctionalityId = ui.FUNCTIONALITY_ID 
		and Ui.Active = 1 and Ui.Ahs_Prl = 'Y' -- and LocationID=@UserLocationId
--		AND  EXISTS (SELECT 1 FROM ADM_AccessTarget WHERE QcTargetId = @QcTargetId and ServiceId = @ServiceId and UserId = ui.UserId)
        order by ui.NT_USERNAME

END








GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pGetUsersByService] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pGetUsersByService] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pGetUsersByService] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pGetUsersByService] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pGetUsersByService] TO [DB_DMLSupport]
    AS [dbo];

