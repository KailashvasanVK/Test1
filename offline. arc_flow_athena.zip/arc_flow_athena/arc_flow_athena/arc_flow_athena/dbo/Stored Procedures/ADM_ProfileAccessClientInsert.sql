﻿
CREATE Procedure [dbo].[ADM_ProfileAccessClientInsert]    
@UserIdCollection varchar(max) ,    
@ClientId int,  
@ServiceId int,  
@CreatedBy  int,
@CustomerId int ,
@GroupId    int  
As    
/*    
Created by : karthick .M7
Created on : 03 03 2015    
Impact to  : ProfileSetup.aspx    
Purpose    : To save the user client wise service details.  
Modified by : *****
*/    
Begin  

		Insert into ADM_AccessClient(UserId,ClientId,ServiceId,CreatedBy,CustomerId,GroupId) 
						       select cast(items as int),@ClientId,@ServiceId,@CreatedBy,@CustomerId,@GroupId
						        from fnSplitString(@UserIdCollection,',')
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ProfileAccessClientInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileAccessClientInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileAccessClientInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ProfileAccessClientInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileAccessClientInsert] TO [DB_DMLSupport]
    AS [dbo];

