﻿CREATE Procedure [dbo].[ADM_MailTranInsert]
(
@From_MailId VARCHAR(100) = ''
,@Recipients varchar(max)
,@Cc VARCHAR(MAX)=''
,@Subject VARCHAR(200)
,@Body NVARCHAR(MAX)
,@IsHtml varchar(1) = 'N'
,@CreatedBy int = 0
,@Description varchar(MAX) = ''
)
AS
BEGIN
IF ISNULL(@From_MailId,'') = '' SET @From_MailId = 'mail.recruit@accesshealthcare.co'
insert into ADM_Mail_Tran(From_MailId, Recipients ,[Subject]  ,Body,IsHtml,Cc,CreatedBy,MailDescription)
values (@From_MailId,@Recipients,@Subject,@Body,@IsHtml,@Cc,@CreatedBy,@Description)
END


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_MailTranInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_MailTranInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_MailTranInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_MailTranInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_MailTranInsert] TO [DB_DMLSupport]
    AS [dbo];

