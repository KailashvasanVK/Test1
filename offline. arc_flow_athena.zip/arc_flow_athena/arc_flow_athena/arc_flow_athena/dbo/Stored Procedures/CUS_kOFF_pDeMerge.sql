﻿CREATE Procedure CUS_kOFF_pDeMerge  (@Batchnum varchar(20))  
As              
Begin              
 /*               
 358 OffLine Pmt              
 361 OffLine Self Posting              
 360 OffLine Exception Posting              
 359 OffLine Collection              
 364 Offline Patient Creation              
 */              
 /*      
 Modified by : mohamedsafiyu.a      
 Modified On : 10/19/2015      
 Action : Directly marked status 99 for parent batch. Hence this routine will work for single batch only      
       
 Modified by : mohamedsafiyu.a      
 Modified On : 10/29/2015      
 Action : Directly marked status 99 for parent batch condition applied on status and uploaddt . Hence this routine will work for single batch only      
       
 Modified by : mohamedsafiyu.a      
 Modified on : 03/24/2016      
 Action : BatchId captured on qcmaster and qccomments on demege      
     
 Modified by : mallikarjun.nam      
 Modified on : 04/10/2017     
 Action : Enter entry transactions which are entered by Qc user.    
   
 Modified by : mallikarjun.nam      
 Modified on : 11/28/2017     
 Action : Update LocationId,ShiftId for missing users batch wise  
   
 Modified by : mallikarjun.nam      
 Modified on : 03/30/2018  
 Action : Update CategoryId,SeverityId for qctran table as requested by Ops Team  
   
 Modified by : mallikarjun.nam                
 Modified on : 04/18/2018            
 Action : Update script to move child batches into entry inprogress held status for Auto upload process            
    
 
 Modified by:Noor
 Modified on: 07/04/2018
 Ticket : 307904
 Action : Update batch location information with respect user held that batch. currently all batches are helded in chennai location. 
 
 Modified by:Mallikarjun.nam
 Modified on: 10/05/2010
 Ticket : 307904
 Action : Added Error rebuttal function to add error into rebuttal process  
 
  
 Modified by: noormohamed.h
 Modified on: 12/07/2018  
 Ticket : 349339  
 Action : Update QC entry Transaction, before it was taken Entry transaction
               
    
*/              
/*************************************** ParentBatches FTE Info ************************************************/              
if OBJECT_ID('Tempdb..#DeMergeBatchesEntry') is not null drop table #DeMergeBatchesEntry             
             
Select Bat.BatchNo as ParentBatchNo,Bat.BatchId,Flow.CreatedBy,Flow.CreatedDt,isnull(FteStFlow.CreatedDt,Flow.CreatedDt) as AssignedDt      
,(Select top 1 LocationId from TRN_kOFF_tBatchTransact Where BatchId = bat.BatchId and isQcEntry = 0) LocationId      
,(Select top 1 ShiftId from TRN_kOFF_tBatchTransact Where BatchId = bat.BatchId and isQcEntry = 0) ShiftId      
into #DeMergeBatchesEntry              
from TRN_kOFF_tBatches as Bat               
left join TRN_kOFF_tBatchFlow as FteStFlow on FteStFlow.BatchId = Bat.BatchId and FteStFlow.StatusId = 1      
inner join TRN_kOFF_tBatchFlow as Flow on Flow.BatchId = Bat.BatchId and Flow.StatusId = 6              
Where Bat.status = 20  and Bat.Batchno=@Batchnum      
  
  
/*Verify and update user location and shift ids for miising batches*/  
If(select Count(BatchId) from #DeMergeBatchesEntry where  isnull(locationid,0)=0)>0  
Begin  
 Update tmp Set tmp.LocationId=usr.LocationId  
 ,ShiftId =(Select Top 1 SHIFT_ID from ARC_REC_ATHENA..ARC_REC_SHIFT_TRAN where USERID = tmp.CreatedBy and Effect_DATE <= GETDATE() Order by Effect_DATE desc)  
 from #DeMergeBatchesEntry tmp  
 inner join arc_rec_athena..arc_rec_user_info usr on usr.UserId=tmp.CreatedBy  
 where tmp.locationid is null  
End  
  
  
  
Declare @ServiceId int       
Select @ServiceId = ServiceId from TRN_kOFF_tBatches as bat Where BatchNo = @Batchnum      
Declare       
@FactorPayment float /** Payment (358) transaction count */          
,@FactorCollection float /** Collection (359) transaction count */          
,@FactorExceptionPosting float /** ExceptionPosting (360) transaction count */          
,@FactorSelfPosting float /** SelfPosting (361) transaction count */          
,@FactorPatientPosting float /** PatientPosting (364) transaction count */       
,@QcFactorPayment float /** Payment (358) transaction count */          
,@QcFactorCollection float /** Collection (359) transaction count */          
,@QcFactorExceptionPosting float /** ExceptionPosting (360) transaction count */          
,@QcFactorSelfPosting float /** SelfPosting (361) transaction count */          
,@QcFactorPatientPosting float /** PatientPosting (364) transaction count */       
      
Select       
@FactorPayment = EntryPayment      
,@FactorCollection = EntryCollection      
,@FactorExceptionPosting = EntryExceptionPosting      
,@FactorSelfPosting = EntrySelfPosting      
,@FactorPatientPosting = EntryPatientCreation       
,@QcFactorPayment = QcPayment      
,@QcFactorCollection = QcCollection      
,@QcFactorExceptionPosting = QcExceptionPosting      
,@QcFactorSelfPosting = QcSelfPosting      
,@QcFactorPatientPosting = QcPatientCreation       
from ADM_FactorWaterTown       
Where ServiceGroupId = @ServiceId and CONVERT(date,getdate()) between EffectiveFrom and isnull(EffectiveTo,GETDATE())      
      
--Create Table DeMergeBatchesEntry_Log (ParentBatchNo varchar(15), BatchId bigint, CreatedBy int, CreatedDt Datetime , AssignedDt Datetime,ExtractTime datetime)      
Insert into DeMergeBatchesEntry_Log        
select ParentBatchNo, BatchId, CreatedBy, CreatedDt, AssignedDt,getdate() from #DeMergeBatchesEntry              
              
/*************************************** ParentBatches QC Info ************************************************/              
if OBJECT_ID('Tempdb..#DeMergeBatchesQc') is not null drop table #DeMergeBatchesQc              
Select Bat.BatchNo as ParentBatchNo        
,Bat.BatchId,Flow.CreatedBy,Flow.CreatedDt,FteFlow.CreatedBy as FteId              
,(Select Top 1 QcPercentage from TRN_kOFF_tBatchQCMaster Where BatchProcessId = Que.BatchProcessId) as QcPerCentage              
,(Select Top 1 LocationId from TRN_kOFF_tBatchQCComments Where BatchProcessId = Que.BatchProcessId) as LocationId       
,(Select Top 1 ShiftId from TRN_kOFF_tBatchQCComments Where BatchProcessId = Que.BatchProcessId) as ShiftId      
,QcStFlow.CreatedDt as QcAssignedDt         
into #DeMergeBatchesQc      
from TRN_kOFF_tBatches as Bat               
inner join TRN_kOFF_tBatchQueue as Que on Que.BatchId = Bat.BatchId              
inner join TRN_kOFF_tBatchFlow as QcStFlow on QcStFlow.BatchId = Bat.BatchId and QcStFlow.StatusId = 7              
inner join TRN_kOFF_tBatchFlow as Flow on Flow.BatchId = Bat.BatchId and Flow.StatusId = 12              
inner join TRN_kOFF_tBatchFlow as FteFlow on FteFlow.BatchId = Bat.BatchId and FteFlow.StatusId = 6              
Where Bat.status = 20    and Bat.Batchno=@Batchnum          
  
/*Verify and update user location and shift ids for miising batches*/  
If(select Count(BatchId) from #DeMergeBatchesQc where  isnull(locationid,0)=0)>0  
Begin  
 Update tmp Set tmp.LocationId=usr.LocationId  
 ,ShiftId=(Select Top 1 SHIFT_ID from ARC_REC_ATHENA..ARC_REC_SHIFT_TRAN where USERID = tmp.CreatedBy and Effect_DATE <= GETDATE() Order by Effect_DATE desc)  
 from #DeMergeBatchesQc tmp  
 inner join arc_rec_athena..arc_rec_user_info usr on usr.UserId=tmp.CreatedBy  
 where tmp.locationid is null  
End  
  
--Create Table DeMergeBatchesQc_Log(ParentBatchNo Varchar(15) ,BatchId bigint, CreatedBy int,CreatedDt DateTime,  FteId      int,ExtractTime Datetime)      
Insert into DeMergeBatchesQc_Log       
select  ParentBatchNo ,BatchId,CreatedBy,CreatedDt,FteId,getdate() from #DeMergeBatchesQc      
              
/*************************************** Inserting Entry Transaction ************************************************/              
Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,LocationId,ShiftId,FactorTrans)      
Select ChildQue.BatchProcessId,ChildBat.PgCount,358,isnull(MergeMast.Payment,0),DeMerge.CreatedBy,DeMerge.CreatedDt,ChildQue.BatchId,ChildQue.ServiceId,ChildQue.ClientId,DeMerge.LocationId,DeMerge.ShiftId,@FactorPayment      
from TRN_kOFF_tBatchQueue as ChildQue              
inner join TRN_kOFF_tBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId              
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo and isnull(MergeMast.Payment,0) > 0              
inner join #DeMergeBatchesEntry as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo              
              
Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,LocationId,ShiftId,FactorTrans)      
Select ChildQue.BatchProcessId,ChildBat.PgCount,361,isnull(MergeMast.Selfpay,0),DeMerge.CreatedBy,DeMerge.CreatedDt,ChildQue.BatchId,ChildQue.ServiceId,ChildQue.ClientId,DeMerge.LocationId,DeMerge.ShiftId,@FactorSelfPosting      
from TRN_kOFF_tBatchQueue as ChildQue              
inner join TRN_kOFF_tBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId              
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo and isnull(MergeMast.Selfpay,0) > 0              
inner join #DeMergeBatchesEntry as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo              
              
Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,LocationId,ShiftId,FactorTrans)      
Select ChildQue.BatchProcessId,ChildBat.PgCount,360,isnull(MergeMast.Exception,0),DeMerge.CreatedBy,DeMerge.CreatedDt,ChildQue.BatchId,ChildQue.ServiceId,ChildQue.ClientId,DeMerge.LocationId,DeMerge.ShiftId,@FactorExceptionPosting      
from TRN_kOFF_tBatchQueue as ChildQue              
inner join TRN_kOFF_tBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId              
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo and isnull(MergeMast.Exception,0) > 0              
inner join #DeMergeBatchesEntry as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo    
              
Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,LocationId,ShiftId,FactorTrans)      
Select ChildQue.BatchProcessId,ChildBat.PgCount,359,isnull(MergeMast.Collection,0),DeMerge.CreatedBy,DeMerge.CreatedDt,ChildQue.BatchId,ChildQue.ServiceId,ChildQue.ClientId,DeMerge.LocationId,DeMerge.ShiftId,@FactorCollection      
from TRN_kOFF_tBatchQueue as ChildQue              
inner join TRN_kOFF_tBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId              
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo and isnull(MergeMast.Collection,0) > 0              
inner join #DeMergeBatchesEntry as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo              
              
Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,LocationId,ShiftId,FactorTrans)      
Select ChildQue.BatchProcessId,ChildBat.PgCount,364,isnull(MergeMast.NewPt,0),DeMerge.CreatedBy,DeMerge.CreatedDt,ChildQue.BatchId,ChildQue.ServiceId,ChildQue.ClientId,DeMerge.LocationId,DeMerge.ShiftId,@FactorPatientPosting      
from TRN_kOFF_tBatchQueue as ChildQue              
inner join TRN_kOFF_tBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId              
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo and isnull(MergeMast.NewPt,0) > 0              
inner join #DeMergeBatchesEntry as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo   
          
  /*************************************** Inserting Entry Transaction which are entered by QC user ************************************************/    
/*Ticket 349339, change QCEntry coloumn*/  
Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,LocationId,ShiftId,FactorTrans,isQcEntry)      
Select ChildQue.BatchProcessId,ChildBat.PgCount,358,isnull(MergeMast.QPaymentEntryTran,0),DeMerge.CreatedBy,DeMerge.CreatedDt,ChildQue.BatchId,ChildQue.ServiceId,ChildQue.ClientId,DeMerge.LocationId,DeMerge.ShiftId,@FactorPayment,1    
from TRN_kOFF_tBatchQueue as ChildQue              
inner join TRN_kOFF_tBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId              
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo and isnull(MergeMast.QPaymentEntryTran,0) > 0        inner join #DeMergeBatchesQc as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo              
              
Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,LocationId,ShiftId,FactorTrans,isQcEntry)      
Select ChildQue.BatchProcessId,ChildBat.PgCount,361,isnull(MergeMast.QSelfPayEntryTran,0),DeMerge.CreatedBy,DeMerge.CreatedDt,ChildQue.BatchId,ChildQue.ServiceId,ChildQue.ClientId,DeMerge.LocationId,DeMerge.ShiftId,@FactorSelfPosting,1    
from TRN_kOFF_tBatchQueue as ChildQue              
inner join TRN_kOFF_tBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId              
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo and isnull(MergeMast.QSelfPayEntryTran,0) > 0              
inner join #DeMergeBatchesQc as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo              
              
Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,LocationId,ShiftId,FactorTrans,isQcEntry)      
Select ChildQue.BatchProcessId,ChildBat.PgCount,360,isnull(MergeMast.QExeptionEntryTran,0),DeMerge.CreatedBy,DeMerge.CreatedDt,ChildQue.BatchId,ChildQue.ServiceId,ChildQue.ClientId,DeMerge.LocationId,DeMerge.ShiftId,    
@FactorExceptionPosting,1 from TRN_kOFF_tBatchQueue as ChildQue              
inner join TRN_kOFF_tBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId              
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo and isnull(MergeMast.QExeptionEntryTran,0) > 0              
inner join #DeMergeBatchesQc as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo              
              
Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,LocationId,ShiftId,FactorTrans,isQcEntry)      
Select ChildQue.BatchProcessId,ChildBat.PgCount,359,isnull(MergeMast.QCollectionEntryTran,0),DeMerge.CreatedBy,DeMerge.CreatedDt,ChildQue.BatchId,ChildQue.ServiceId,ChildQue.ClientId,DeMerge.LocationId,DeMerge.ShiftId,    
@FactorCollection,1 from TRN_kOFF_tBatchQueue as ChildQue              
inner join TRN_kOFF_tBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId              
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo and isnull(MergeMast.QCollectionEntryTran,0) > 0              
inner join #DeMergeBatchesQc as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo              
              
Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,LocationId,ShiftId,FactorTrans,isQcEntry)      
Select ChildQue.BatchProcessId,ChildBat.PgCount,364,isnull(MergeMast.QNewPtEntryTran,0),DeMerge.CreatedBy,DeMerge.CreatedDt,ChildQue.BatchId,ChildQue.ServiceId,ChildQue.ClientId,DeMerge.LocationId,DeMerge.ShiftId,    
@FactorPatientPosting,1 from TRN_kOFF_tBatchQueue as ChildQue              
inner join TRN_kOFF_tBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId              
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo and isnull(MergeMast.QNewPtEntryTran,0) > 0              
inner join #DeMergeBatchesQc as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo       
              
              
/*************************************** Inserting QC Master ************************************************/              
Insert into TRN_kOFF_tBatchQCMaster(BatchProcessId,PageNo,CreatedBy,CreatedDt,ServiceId,TransValue,FTE_Id,QCPercentage,LocationId,ShiftId,FactorTrans,BatchId)      
Select ChildQue.BatchProcessId,ChildBat.PgCount,DeMerge.CreatedBy,DeMerge.CreatedDt,358,isnull(MergeMast.QPayment,0),DeMerge.FteId,DeMerge.QcPerCentage,DeMerge.LocationId,DeMerge.ShiftId,@QcFactorPayment,ChildBat.BatchId      
from TRN_kOFF_tBatchQueue as ChildQue              
inner join TRN_kOFF_tBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId              
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo and isnull(MergeMast.QPayment,0) > 0              
inner join #DeMergeBatchesQc as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo              
              
Insert into TRN_kOFF_tBatchQCMaster(BatchProcessId,PageNo,CreatedBy,CreatedDt,ServiceId,TransValue,FTE_Id,QCPercentage,LocationId,ShiftId,FactorTrans,BatchId)      
Select ChildQue.BatchProcessId,ChildBat.PgCount,DeMerge.CreatedBy,DeMerge.CreatedDt,361,isnull(MergeMast.QSelfpay,0),DeMerge.FteId,DeMerge.QcPerCentage,DeMerge.LocationId,DeMerge.ShiftId,@QcFactorSelfPosting,ChildBat.BatchId      
from TRN_kOFF_tBatchQueue as ChildQue              
inner join TRN_kOFF_tBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId              
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo and isnull(MergeMast.QSelfpay,0) > 0              
inner join #DeMergeBatchesQc as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo              
              
Insert into TRN_kOFF_tBatchQCMaster(BatchProcessId,PageNo,CreatedBy,CreatedDt,ServiceId,TransValue,FTE_Id,QCPercentage,LocationId,ShiftId,FactorTrans,BatchId)      
Select ChildQue.BatchProcessId,ChildBat.PgCount,DeMerge.CreatedBy,DeMerge.CreatedDt,360,isnull(MergeMast.QExeption,0),DeMerge.FteId,DeMerge.QcPerCentage,DeMerge.LocationId,DeMerge.ShiftId,    
@QcFactorExceptionPosting,ChildBat.BatchId      
from TRN_kOFF_tBatchQueue as ChildQue              
inner join TRN_kOFF_tBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId              
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo and isnull(MergeMast.QExeption,0) > 0              
inner join #DeMergeBatchesQc as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo              
            
Insert into TRN_kOFF_tBatchQCMaster(BatchProcessId,PageNo,CreatedBy,CreatedDt,ServiceId,TransValue,FTE_Id,QCPercentage,LocationId,ShiftId,FactorTrans,BatchId)              
Select ChildQue.BatchProcessId,ChildBat.PgCount,DeMerge.CreatedBy,DeMerge.CreatedDt,359,isnull(MergeMast.QCollection,0),DeMerge.FteId,DeMerge.QcPerCentage,DeMerge.LocationId,DeMerge.ShiftId,@QcFactorCollection,ChildBat.BatchId   
from TRN_kOFF_tBatchQueue as ChildQue              
inner join TRN_kOFF_tBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId              
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo and isnull(MergeMast.QCollection,0) > 0              
inner join #DeMergeBatchesQc as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo              
              
Insert into TRN_kOFF_tBatchQCMaster(BatchProcessId,PageNo,CreatedBy,CreatedDt,ServiceId,TransValue,FTE_Id,QCPercentage,LocationId,ShiftId,FactorTrans,BatchId)      
Select ChildQue.BatchProcessId,ChildBat.PgCount,DeMerge.CreatedBy,DeMerge.CreatedDt,364,isnull(MergeMast.QNewPt,0),DeMerge.FteId,DeMerge.QcPerCentage,DeMerge.LocationId,DeMerge.ShiftId,@QcFactorPatientPosting,ChildBat.BatchId  
from TRN_kOFF_tBatchQueue as  ChildQue    
inner join TRN_kOFF_tBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId              
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo and isnull(MergeMast.QNewPt,0) > 0              
inner join #DeMergeBatchesQc as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo              
/*************************************** Inserting Errors ************************************************/              
Insert into TRN_kOFF_tBatchQCTran(BatchProcessId,PageNo,ClassifyId,SubClassifyId,SubClassifyId2,CreatedBy,CreatedDt,ErrNotes,ErrCount,LocationId,ShiftId,CategoryId,SeverityId)  
Select ChildQue.BatchProcessId,(ParentErr.PageNo - MergeMast.StartpgNo)+1 PageNo ,ParentErr.ClassifyId,ParentErr.SubClassifyId,ParentErr.SubClassifyId2,ParentErr.CreatedBy,ParentErr.CreatedDt,    
ParentErr.ErrNotes,ParentErr.ErrCount,DeMerge.LocationId,DeMerge.ShiftId,ParentErr.CategoryId,ParentErr.SeverityId   
from TRN_kOFF_tBatchQueue as ChildQue              
inner join TRN_kOFF_tBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId              
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo              
inner join #DeMergeBatchesQc as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo              
inner join TRN_kOFF_tBatchQueue as ParentQue on ParentQue.BatchId = DeMerge.BatchId              
inner join TRN_kOFF_tBatchQCTran as ParentErr on ParentErr.BatchProcessId = ParentQue.BatchProcessId  and ParentErr.PageNo between MergeMast.StartpgNo and MergeMast.EndPgNo             

/*Inserting the errors into rebuttal process*/
Insert into TRN_kOFF_tBatchErrorRebuttal(QID,BatchProcessId,ErrorDoneBy,CreatedBy,CreatedOn,StatusId)
Select qctrn.QId,qctrn.BatchProcessId,QcCom.FTE_Id,qctrn.CreatedBy,qctrn.CreatedDt,0
from TRN_kOFF_tBatchQCTran qctrn
inner join  TRN_kOFF_tBatchQCComments QcCom on qctrn.BatchProcessId=QcCom.BatchProcessId
inner join TRN_kOFF_tBatches bat on QcCom.BatchId=bat.BatchId
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = bat.BatchNo              
where  MergeMast.ParentBatchNo=@Batchnum 
and not exists (select 1 from TRN_kOFF_tBatchErrorRebuttal err where qctrn.QID=err.Qid and qctrn.BatchProcessId=err.BatchProcessId)
and not exists (select 1 from TRN_kOFF_tBatchErrorRebuttallog elog where qctrn.QID=elog.Qid and qctrn.BatchProcessId=elog.BatchProcessId)

/*Inserting the errors into rebuttal process*/
Insert into TRN_kOFF_tBatchErrorRebuttalFlow(ErrRebId,CreatedBy,CreatedOn,StatusId,Comments)
Select ErrRebId,CreatedBy,CreatedOn,StatusId,'' from TRN_kOFF_tBatchErrorRebuttal  r 
where not exists (select 1 from TRN_kOFF_tBatchErrorRebuttalFlow eflow where  r.ErrRebId=eflow.ErrRebId)
and not exists (select 1 from TRN_kOFF_tBatchErrorRebuttalFlowlog flog where  r.ErrRebId=flog.ErrRebId)
  
/*************************************** Inserting QC Comments ************************************************/              
Insert into TRN_kOFF_tBatchQCComments(BatchProcessId,Comments,CreatedBy,CreatedDt,FTE_Id,BatchId,FTE_QcPer,LocationId,ShiftId)      
Select ChildQue.BatchProcessId,'',DeMerge.CreatedBy,DeMerge.CreatedDt,DeMerge.FteId,ChildQue.BatchId,deMerge.QcPerCentage,DeMerge.LocationId,DeMerge.ShiftId      
from TRN_kOFF_tBatchQueue as ChildQue              
inner join TRN_kOFF_tBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId              
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo              
inner join #DeMergeBatchesQc as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo              
/*************************************** Inserting Entry Assign ************************************************/      
Insert into TRN_kOFF_tBatchFlow(BatchId,BatchProcessId,CreatedDt,CreatedBy,StatusId,Comments)              
Select ChildQue.BatchId,ChildQue.BatchProcessId, ParentEntry.AssignedDt,ParentEntry.CreatedBy,1,''              
from TRN_kOFF_tBatchQueue as ChildQue              
inner join TRN_kOFF_tBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId              
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo              
inner join #DeMergeBatchesEntry as ParentEntry on ParentEntry.ParentBatchNo = MergeMast.ParentBatchNo              
/*************************************** Inserting Entry Complete ************************************************/              
Insert into TRN_kOFF_tBatchFlow(BatchId,BatchProcessId,CreatedDt,CreatedBy,StatusId,Comments)              
Select ChildQue.BatchId,ChildQue.BatchProcessId, ParentEntry.CreatedDt,ParentEntry.CreatedBy,6,''              
from TRN_kOFF_tBatchQueue as ChildQue              
inner join TRN_kOFF_tBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId            
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo              
inner join #DeMergeBatchesEntry as ParentEntry on ParentEntry.ParentBatchNo = MergeMast.ParentBatchNo              
/*************************************** Inserting Qc Assign ************************************************/              
Insert into TRN_kOFF_tBatchFlow(BatchId,BatchProcessId,CreatedDt,CreatedBy,StatusId,Comments)              
Select ChildQue.BatchId,ChildQue.BatchProcessId, ParentQc.QcAssignedDt ,ParentQc.CreatedBy,7,''              
from TRN_kOFF_tBatchQueue as ChildQue              
inner join TRN_kOFF_tBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId              
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo              
inner join #DeMergeBatchesQc as ParentQc on ParentQc.ParentBatchNo = MergeMast.ParentBatchNo              
/*************************************** Inserting Qc Complete ************************************************/              
Insert into TRN_kOFF_tBatchFlow(BatchId,BatchProcessId,CreatedDt,CreatedBy,StatusId,Comments)              
Select ChildQue.BatchId,ChildQue.BatchProcessId, ParentQc.CreatedDt,ParentQc.CreatedBy,12,''              
from TRN_kOFF_tBatchQueue as ChildQue              
inner join TRN_kOFF_tBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId              
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo              
inner join #DeMergeBatchesQc as ParentQc on ParentQc.ParentBatchNo = MergeMast.ParentBatchNo              
/*************************************** Parent Status Change to 99 ************************************************/              
Update TRN_kOFF_tBatches Set status = 99 Where BatchNo =  @Batchnum and UploadDt is not null      
/*      
Update TRN_kOFF_tBatches Set status = 99               
from  TRN_kOFF_tBatches as bat              
inner join #DeMergeBatchesEntry as Parent on parent.BatchId = bat.BatchId              
Where bat.status = 20              
*/      
/*************************************** Child Status update ************************************************/              
Insert into TRN_kOFF_tBatchFlow(BatchId,BatchProcessId,CreatedDt,CreatedBy,StatusId,Comments)              
Select que.BatchId,que.BatchProcessId, TempParent.AssignedDt ,ISNULL(tempQc.CreatedBy, TempParent.CreatedBy) ,13,''              
from TRN_kOFF_tBatchQueue as que      
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = que.BatchNo              
inner join TRN_kOFF_tBatches as Parent on Parent.BatchNo = MergeMast.ParentBatchNo              
inner join #DeMergeBatchesEntry as TempParent on TempParent.BatchId = Parent.BatchId          
left join #DeMergeBatchesQc as TempQc on TempQc.BatchId = parent.BatchId          
      
Update que Set StatusId = 13 ,Assigned = 0              
from  TRN_kOFF_tBatchQueue as que              
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = que.BatchNo              
inner join TRN_kOFF_tBatches as Parent on Parent.BatchNo = MergeMast.ParentBatchNo              
inner join #DeMergeBatchesEntry as TempParent on TempParent.BatchId = Parent.BatchId        
        
Update Child Set UploadDt = Parent.UploadDt,PostedDt = parent.PostedDt,AuditedDt = parent.AuditedDt,status = 1      
from TRN_kOFF_tBatches as Child      
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = child.BatchNo      
inner join TRN_kOFF_tBatches as Parent on Parent.BatchNo = MergeMast.ParentBatchNo      
inner join #DeMergeBatchesEntry as TempParent on TempParent.BatchId = Parent.BatchId      
/*Auto upload process start here*/            
            
/* Delete batch qc comments from BatchQcComments table */            
Delete qcCom from TRN_kOFF_tBatchQcComments qcCom            
/*--inner join  TRN_kOFF_tBatchQueue as ChildQue on qcCom.BatchprocessId=ChildQue.BatchprocessId*/            
inner join TRN_kOFF_tBatches as ChildBat on ChildBat.BatchId = qcCom.BatchId                          
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo                          
inner join #DeMergeBatchesQc as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo             
where exists (select 1 from arc_athena..AutoUpload_HeldBatches autoheld where  autoheld.BatchNo=ChildBat.BatchNo and autoheld.HeldStatus=1)            
/* Delete batch qc transactions from BatchQcMaster table */            
Delete qcMast from TRN_kOFF_tBatchQcMaster qcMast            
inner join  TRN_kOFF_tBatchQueue as ChildQue on qcMast.BatchprocessId=ChildQue.BatchprocessId            
inner join TRN_kOFF_tBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId                          
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo                          
inner join #DeMergeBatchesQc as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo             
where exists (select 1 from arc_athena..AutoUpload_HeldBatches autoheld where  autoheld.BatchNo=ChildQue.BatchNo and autoheld.HeldStatus=1)            
/* Delete batch qc error count from BatchQctran table */            
Delete qctrn from TRN_kOFF_tBatchQcTran qctrn            
inner join  TRN_kOFF_tBatchQueue as ChildQue on qctrn.BatchprocessId=ChildQue.BatchprocessId            
inner join TRN_kOFF_tBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId                          
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo                          
inner join #DeMergeBatchesQc as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo             
where exists (select 1 from arc_athena..AutoUpload_HeldBatches autoheld where  autoheld.BatchNo=ChildQue.BatchNo and autoheld.HeldStatus=1)            
/* Move batch into entry inprocess status*/            
Delete flow from TRN_kOFF_tBatchflow flow             
inner join TRN_kOFF_tBatchQueue as que on que.BatchId=flow.BatchId            
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = que.BatchNo                          
inner join TRN_kOFF_tBatches as Parent on Parent.BatchNo = MergeMast.ParentBatchNo                          
inner join #DeMergeBatchesEntry as TempParent on TempParent.BatchId = Parent.BatchId                      
left join #DeMergeBatchesQc as TempQc on TempQc.BatchId = parent.BatchId                   
where flow.statusId>1            
and exists (select 1 from arc_athena..AutoUpload_HeldBatches autoheld where  autoheld.BatchNo=que.BatchNo and autoheld.HeldStatus=1)            
/* Move batch into held status */            
--Insert into TRN_kOFF_tBatchFlow(BatchId,BatchProcessId,CreatedDt,CreatedBy,StatusId,Comments)        
--Select que.BatchId,que.BatchProcessId,Getdate(),TempParent.CreatedBy ,17            
--,'Move Batch into Held status By the System - Auto upload process'                          
--from TRN_kOFF_tBatchQueue as que             
--inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = que.BatchNo                          
--inner join TRN_kOFF_tBatches as Parent on Parent.BatchNo = MergeMast.ParentBatchNo                          
--inner join #DeMergeBatchesEntry as TempParent on TempParent.BatchId = Parent.BatchId                      
--left join #DeMergeBatchesQc as TempQc on TempQc.BatchId = parent.BatchId                      
--and exists (select 1 from arc_athena..AutoUpload_HeldBatches autoheld where  autoheld.BatchNo=que.BatchNo and autoheld.HeldStatus=1)           
                       
 Insert into TRN_kOFF_tBatchFlow(BatchId,BatchProcessId,CreatedDt,CreatedBy,StatusId,Comments)          
  
Select flow.BatchId,flow.BatchProcessId,Getdate(),TempParent.CreatedBy ,17              
,'Move Batch into Held status By the System - Auto upload process'     
from TRN_kOFF_tBatchflow flow               
inner join TRN_kOFF_tBatchQueue as que on que.BatchId=flow.BatchId              
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = que.BatchNo                            
inner join TRN_kOFF_tBatches as Parent on Parent.BatchNo = MergeMast.ParentBatchNo                            
inner join #DeMergeBatchesEntry as TempParent on TempParent.BatchId = Parent.BatchId                        
left join #DeMergeBatchesQc as TempQc on TempQc.BatchId = parent.BatchId  
where flow.statusId=1   
and exists (select 1 from arc_athena..AutoUpload_HeldBatches autoheld where  autoheld.BatchNo=que.BatchNo and autoheld.HeldStatus=1)              
       
          
/* Move batch into held status */            
Update que Set StatusId = 17 ,Assigned = 0                          
from  TRN_kOFF_tBatchQueue as que                          
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = que.BatchNo                          
inner join TRN_kOFF_tBatches as Parent on Parent.BatchNo = MergeMast.ParentBatchNo                          
inner join #DeMergeBatchesEntry as TempParent on TempParent.BatchId = Parent.BatchId            
and exists (select 1 from arc_athena..AutoUpload_HeldBatches autoheld where  autoheld.BatchNo=que.BatchNo and autoheld.HeldStatus=1)            
/* Move batch from completed status to inprogress status*/            
Update Child Set UploadDt = NULL,PostedDt =NULL,AuditedDt = NULL,status = 1,LocationId= TempParent.LocationId  /* Ticket:307904, Update Location Id information  */   
from TRN_kOFF_tBatches as Child            
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = child.BatchNo            
inner join TRN_kOFF_tBatches as Parent on Parent.BatchNo = MergeMast.ParentBatchNo                  
inner join #DeMergeBatchesEntry as TempParent on TempParent.BatchId = Parent.BatchId             
and exists (select 1 from arc_athena..AutoUpload_HeldBatches autoheld where  autoheld.BatchNo=Child.BatchNo and autoheld.HeldStatus=1)            
/*Move Child batches into held status*/            
Insert into TRN_kOFF_tHeldBatches(BatchId,HeldDate,HeldBy,HeldComment)     
    Select Child.BatchId,Getdate(),TempParent.CreatedBy,'Move Batch into Held status By the System - DoNotAutoUpload - ' + autoheld.usercomments            
from TRN_kOFF_tBatches as Child            
inner join MergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = child.BatchNo                  
inner join TRN_kOFF_tBatches as Parent on Parent.BatchNo = MergeMast.ParentBatchNo                  
inner join #DeMergeBatchesEntry as TempParent on TempParent.BatchId = Parent.BatchId             
inner join       arc_athena.dbo.AutoUpload_HeldBatches autoheld on  autoheld.BatchNo=Child.BatchNo     
where  autoheld.HeldStatus=1           
   
            
Update arc_athena..AutoUpload_HeldBatches set HeldStatus=2,FlowTrack=getdate() where SubMergeBatchNo=@Batchnum  and HeldStatus=1                       
/*Auto upload process end here*/          

/*Missing child batch errors move to rebuttal process*/
EXEC TRN_OFF_DemergeBatchErrormovetoRebuttal @Batchnum
            
if OBJECT_ID('Tempdb..#DeMergeBatchesEntry') is not null drop table #DeMergeBatchesEntry              
if OBJECT_ID('Tempdb..#DeMergeBatchesQc') is not null drop table #DeMergeBatchesQc              
End   
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kOFF_pDeMerge] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kOFF_pDeMerge] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kOFF_pDeMerge] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kOFF_pDeMerge] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kOFF_pDeMerge] TO [DB_DMLSupport]
    AS [dbo];

