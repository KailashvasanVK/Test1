﻿CREATE Proc RollbackMerge
as
delete from dbo.TRN_kOFF_tBatchFlow where batchid in (select batchid from TRN_kOFF_tBatches where left(batchno,1)='m')
delete from  dbo.TRN_kOFF_tBatchQueue  where left(batchno,1)='m'
delete from TRN_kOFF_tBatches where left(batchno,1)='m'
delete from arc_athena..batchmaster where left(batchnum,1)='m'
delete  from mergebatchdetails
update  TRN_kOFF_tBatches set status=1 where status=99
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RollbackMerge] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RollbackMerge] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RollbackMerge] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RollbackMerge] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RollbackMerge] TO [DB_DMLSupport]
    AS [dbo];

