﻿CREATE Procedure MICR_Automation
  as
  /*
  Ticket :357172
  Purpose : Update Micr and payer Information
  Date : Jan 07,2019
  Created By :Noor
  Implented By :Narayana
  */
  BEGIN
  if OBJECT_ID('Tempdb..#UpdateUniqueInformation') is not null drop table #UpdateUniqueInformation
  Create table #UpdateUniqueInformation
   (
    id int identity(1,1),UIBatchno varchar(50),UIPayerId int
   )
  
  DECLARE @Batchno varchar(30)='',@UniqueNo varchar(100)='',@PayerName varchar(100)='',@Rowid int=0,@Micrno varchar(255)=''
  
  INSERT INTO #UpdateUniqueInformation(UIBatchno,UIPayerID)
  SELECT   Batchno,PayerID From trn_koff_tbatches(nolock) tb inner join MICRROUTING(nolock) mc on mc.batch_no=tb.batchno Where UploadDt is not null and convert(date,UploadDt)=convert(date,getdate()) and left(Batchno,1)<> 'S' and isnull(payerid,'')<>''
  and (isnull(micr_no,'') <> '' and isnull(micr_no,'')<>'error')
  --SELECT Batchno,PayerID From trn_koff_tbatches(nolock) Where UploadDt is not null and convert(date,UploadDt)=convert(date,getdate()) and left(Batchno,1)<> 'S' and isnull(payerid,'')<>'' -- GET today uploaded batches
  
  select @Rowid=COUNT(ID) from #UpdateUniqueInformation       
while(@Rowid!=0)  
 BEGIN 
  select @Batchno=UIBatchno,@PayerName=payername from #UpdateUniqueInformation tb inner join adm_payername(nolock) ap on ap.payerid=tb.UIpayerid where  id= @Rowid
  select @UniqueNo=isnull(micr_no,'')+isnull(account_no,''),@Micrno=isnull(MICR_No,'') from MICRROUTING(nolock) where Batch_No=@Batchno 

 if(@Micrno<>'' AND @Micrno<>'error')
 BEGIN
   IF  Exists(select 1 from FinalData(nolock) where uniqueno=@UniqueNo)
    BEGIN
     IF NOT Exists(select 1 from FinalData(nolock) where uniqueno=@UniqueNo and Payer=@PayerName) -- Check in Dictionary     

     INSERT INTO FinalData_Automation(UniqueNo,Payer,CreatedDate)values(@UniqueNo,@PayerName,getdate())
     INSERT INTO FinalData(UniqueNo,Payer)values(@UniqueNo,@PayerName)
    END
   ELSE
    BEGIN
     INSERT INTO FinalData_Automation(UniqueNo,Payer,CreatedDate)values(@UniqueNo,@PayerName,getdate())
     INSERT INTO FinalData(UniqueNo,Payer)values(@UniqueNo,@PayerName)

    END
  END
  set @Rowid=@Rowid-1  
 END
END


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MICR_Automation] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[MICR_Automation] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MICR_Automation] TO [DB_DMLSupport]
    AS [dbo];

