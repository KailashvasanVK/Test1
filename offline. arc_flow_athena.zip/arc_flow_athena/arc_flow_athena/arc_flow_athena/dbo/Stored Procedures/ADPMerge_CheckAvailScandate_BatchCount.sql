﻿CREATE Proc [dbo].[ADPMerge_CheckAvailScandate_BatchCount]               
 as                      
                  
/*                        
                    
Cretaed By     : Leela.T                    
Created Date   : 2017-04-10                    
Purpose        : Check  scandate wise Available Batches for Merge                    
Ticket/SCR ID  : 1195                   
TL Verified By : Udhayaganesh               
                
                 
Implemented by : Udhdyaganesh.p          
Implemented On : 10-April-2017            
                    
Reviewd by     : Udhdyaganesh.p                   
Implemented On : 10-April-2017                   
                    
*/                     
begin  

Declare @From date=  convert(Date,getdate()-8)  ,@todate  date=    convert(Date,getdate())                
                                          
select trn.Scandate,count(trn.batchno) BatchCount,Sum(pgcount) as PageCount from trn_koff_tbatches(nolock) trn            
inner join ARC_Athena..batchMaster(nolock) bat on trn.BatchNo=bat.batchnum                                                 
Inner join TRN_kOFF_tBatchQueue(nolock) bq on trn.batchno=bq.batchno                         
Inner join ADM_Client(nolock) adm on adm.ClientId=trn.ClientId and CustomerId=25 and adm.status=1            
left join mergebatchdetails (nolock) mrg on mrg.childbatchno=trn.batchno 
left join TRN_kOFF_tBatchResetLog Rp on RP.batchno= trn.batchno                
where  mrg.childbatchno is null  and bq.assigned=0 and bq.statusid=0 and RP.batchno is null                
and trn.postedDt is null and trn.UploadDt is null and bat.ULStatus is null      
and trn.status=88  and   PgCount between 9 and 20 and trn.serviceid=418     
and trn.scandate between  @From and  @todate
group by trn.scandate  
              
               
End 


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADPMerge_CheckAvailScandate_BatchCount] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_CheckAvailScandate_BatchCount] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_CheckAvailScandate_BatchCount] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADPMerge_CheckAvailScandate_BatchCount] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_CheckAvailScandate_BatchCount] TO [DB_DMLSupport]
    AS [dbo];

