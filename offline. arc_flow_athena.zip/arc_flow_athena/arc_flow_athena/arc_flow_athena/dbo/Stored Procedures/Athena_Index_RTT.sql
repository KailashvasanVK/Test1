﻿
CREATE Proc Athena_Index_RTT                                       
@userinfo varchar(50)                                   
as                                        
/*This SP willl pick the batch for indexing the batch for TaxID,NPI,Dollaramt and Payeeno*/                                        
/*Create By Ramakrishnang. Aug 7th 2014,Modified by Noor Oct 23,2014                              
to assign multiple user*/                                        
                                        
Declare @Batchno varchar(20),@rowcnt int                                        
                  
GetBatch:                                     
      
SELECT @Batchno=batchnum from batchIndex_TrackBatches_RT a inner join trn_koff_tbatches b on a.batchnum=b.BatchNo where userinfo=@userinfo and cstatus=0  and b.status=3                                      
                                  
if(@Batchno is not null)                                  
begin                                  
      SELECT @Batchno as BatchNo                                  
      return                                  
End                                  
ELSE                                  
BEGIN                                  
                                        
select Top 1 @Batchno=Batchno from trn_koff_tbatches(nolock)                                        
where uploaddt  is null and serviceid=363 and status=3  and BatchNo not  in(select batchnum from   batchIndex_TrackBatches_RT(nolock) where CompletedDate is null )                                    
order by ScanDate asc, PgCount  asc                                   
                           
if(@Batchno is not null)                                  
begin                                                                          
                      
insert into batchIndex_TrackBatches_RT (batchnum,userinfo,cstatus)                      
SELECT @Batchno,@userinfo,0 WHERE NOT EXISTS(SELECT 1 FROM batchIndex_TrackBatches_RT  where batchnum=@Batchno)                    
    
IF NOT EXISTS(SELECT 1 FROM batchIndex_TrackBatches_RT where batchnum=@Batchno and cstatus=0)    
Begin                  
GOTO GetBatch                     
End    
                      
End                                      
SELECT @Batchno as BatchNo                                  
END   

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_RTT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_RTT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_RTT] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_RTT] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_RTT] TO [DB_DMLSupport]
    AS [dbo];

