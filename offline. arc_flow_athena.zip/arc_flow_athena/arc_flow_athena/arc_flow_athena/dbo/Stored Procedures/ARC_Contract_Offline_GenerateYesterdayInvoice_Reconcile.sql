Text
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

CREATE Procedure [ARC_Contract_Offline_GenerateYesterdayInvoice_Reconcile](@fromDate date =null,@toDate date=null)  
As  
Begin  
  
declare @curDate date=getdate()  
  
if(@fromDate is null  and @toDate is null)  
begin  
set @fromDate=getdate()-1  
set @toDate =getdate()-1    
set @curDate  = getdate()  
  
if Datepart(Day,@curDate) <= 10    
 Begin    
 /** Crunch from previous month **/    
 Set @fromDate = DATENAME(YEAR,DATEADD(MM,-1,@curDate)) + '-' + DATENAME(MM,DATEADD(MM,-1,@curDate)) + '-' + '01'    
 Set @toDate = DateAdd(Day,-1,@curDate)    
 End    
else    
 Begin    
 /** Crunch from current month **/    
 Set @fromDate = DATENAME(YEAR,@curDate) + '-' + DATENAME(MM,@curDate) + '-' + '01'    
 Set @toDate = DateAdd(Day,-1,@curDate)    
 End  
end  
   
If object_id('tempdb..#TempDates') is not null drop table #TempDates;  
WITH mycte AS  
(  
  SELECT CAST(@fromDate AS DATETIME) DateValue  
  UNION ALL  
  SELECT  DateValue + 1  
  FROM    mycte     
  WHERE   DateValue + 1 <= @toDate  
)  
  
SELECT  Cast(DateValue as Date) DateValue  
into #TempDates  
FROM    mycte as t  
OPTION (MAXRECURSION 0);  
  
Declare @dd Date  
Declare ddCur cursor for select DateValue from #TempDates  
open ddcur  
while 1=1  
Begin  
Fetch next from ddCur into @dd  
if @@Fetch_status = -1 break  
Exec ARC_Contract_offline_GenerateYesterdayInvoice @Attdate = @dd  
End  
close ddCur  
DeAllocate ddCur  
If object_id('tempdb..#TempDates') is not null drop table #TempDates;  
  
End 

