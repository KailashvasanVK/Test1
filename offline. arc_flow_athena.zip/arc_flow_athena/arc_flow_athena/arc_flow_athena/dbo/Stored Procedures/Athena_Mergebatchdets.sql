﻿CREATE proc Athena_Mergebatchdets ( @clientName varchar(7),@Maxpagecount  int,   
 @MergeBatchno As [dbo].[MergeBatchList] Readonly )  
  
as      
Begin      
      
declare @qury nvarchar(Max),                                     
@toprec varchar(15)=20,@LoopCount                 
int,                                    
@PgCount int,  @batchno varchar(50) ,                                 
@Client varchar(10),@ParentBatchid int,                                    
@StartPgNo int, @EndPgNo int,  @Chk int,                                  
@ParentBatchNo Varchar(20),                                    
@Count int,@Mergequry nvarchar(1000),@Fname varchar(300),                
@BatchCount int,@dollaramt money              
      
create table #MergeBatchDetails                        
 (                                    
BatchNo   Varchar(15),                                                                                                                
PageCount   int,                            
Fname varchar(300) ,                      
status int,      
dollarAmt Money                       
)        
  print @batchno    
                               
INSERT INTO Athena_ParentBatchGeneration(ParentBatch) values (@clientName)                                    
set @ParentBatchid = SCOPE_IDENTITY()                                    
set @ParentBatchNo='M' + Convert(varchar(10),@ParentBatchid) + 'A' + @clientName                                    
Print @ParentBatchNo             
                                 
delete from #MergeBatchDetails                                    
                                 
insert into #MergeBatchDetails(batchno , pagecount,Fname,status,dollarAmt)                                          
select batchno,pgcount,FName,0,b.dollarAmt from trn_koff_tbatches a inner join ARC_Athena..batchMaster b  
on a.BatchNo=b.batchnum where BatchNo in (select Batchno from @MergeBatchno)      
set @Count=0                                
set @Chk=0                                
     
     
 select * from #MergeBatchDetails                                 
                           
declare @CurMergeBatch cursor                                        
set  @CurMergeBatch  = cursor fast_forward for                                   
                                  
select batchno, pagecount,Fname,dollaramt from #MergeBatchDetails where status=0                                     
                                   
open  @CurMergeBatch                                                                                                              
                                                                                                 
fetch next from @CurMergeBatch into                                   
@BatchNo,@PgCount ,@Fname,@dollaramt                                   
                                 
                                 
Print @Count                                                                                              
while(@@fetch_status<>-1)                                     
Begin                                 
                              
set @count=@count+@pgcount                                    
                              
if(@Count>=@Maxpagecount)                                 
begin                                
Set @Count=0                                
Set @Chk=0                        
select @Count=SUM(pagecount) from #MergeBatchDetails where status=0                    
print @count                  
 if(@Count<(@Maxpagecount-Floor(@Maxpagecount*0.2)))                      
begin                  
                    
   update TRN_kOFF_tBatches set status=1 where BatchNo in(                       
   select BatchNo from #MergeBatchDetails where status=0)                
   print @count                        
   Goto NextSubClient                    
                     
End                         
set @count=0                
set @count=@count+@pgcount                                    
Print @Count                                
Print @batchno                              
                              
INSERT INTO Athena_ParentBatchGeneration(ParentBatch) values (@clientName)                                    
set @ParentBatchid = SCOPE_IDENTITY()                                    
set @ParentBatchNo='M' + Convert(varchar(10),@ParentBatchid) + 'A' + @clientName                                    
Print @ParentBatchNo                                 
                              
if (@Chk=0)                                
begin                                
Set @Chk=1                                
set @StartPgNo=1                                
set @EndPgNo=@PgCount                                
End                                
                              
else                                
begin                                
set @StartPgNo=@EndPgNo+1                                
set @EndPgNo= @startpgno + (@PgCount-1)                                
End                               
End                                
                            
else                               
                            
begin                                
if (@Chk=0)                                
begin                                
Set @Chk=1                                
set @StartPgNo=1                                
set @EndPgNo=@PgCount                                
End                                
else                                
begin                               
 set @StartPgNo=@EndPgNo+1                                
set @EndPgNo= @startpgno + (@PgCount-1)                                
End                                
                         
end                                
                                
Print @StartpgNo                                 
Print @EndpgNo                                
Print @Count                 
print @batchno                         
                              
INSERT INTO MergeBatchDetails(ParentBatchNo,childBatchNo,StartPgNo,EndpgNo,TotalPages,status,Fname,dollaramt)                                
values(@ParentBatchNo,@BatchNo,@StartPgNo,@EndPgNo,@PgCount,1,@Fname,@dollaramt)                                   
update #MergeBatchDetails set status=1 where BatchNo=@BatchNo                      
Select * from  #MergeBatchDetails where BatchNo=@BatchNo                     
                             
fetch next from @CurMergeBatch   into                                   
@BatchNo,@PgCount,@Fname,@dollaramt                                    
End                                   
                        
  NextSubClient:                                
close @CurMergeBatch                                   
deallocate @CurMergeBatch                    
Select @LoopCount=@LoopCount-1                                  
Print @loopCount                                
 End 
 
 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Mergebatchdets] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Mergebatchdets] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Mergebatchdets] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Mergebatchdets] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Mergebatchdets] TO [DB_DMLSupport]
    AS [dbo];

