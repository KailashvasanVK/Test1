﻿CREATE Proc Athena_Index_ListInsurance          
as          
BEGIN      
select Payerid as 'ServiceId', RTRIM(LTRIM(PayerName)) as 'InsuranceName'  from adm_payername where status=1   order by PayerName     
--SELECT ServiceId,InsuranceName  FROM BatchIndexing_InsuranceDetail  order by InsuranceName          
END     
  


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_ListInsurance] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_ListInsurance] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_ListInsurance] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_ListInsurance] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_ListInsurance] TO [DB_DMLSupport]
    AS [dbo];

