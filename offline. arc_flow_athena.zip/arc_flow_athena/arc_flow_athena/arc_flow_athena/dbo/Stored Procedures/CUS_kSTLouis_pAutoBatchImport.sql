﻿CREATE Procedure  CUS_kSTLouis_pAutoBatchImport
(
 @pFileName varchar(200) = ''
,@pPageCount int = 0
,@pCmpKey varchar(5)=''
,@pScanDate date=''
,@pBatchNo varchar(50)=''          
)
As
Begin

	--declare @batcchno varchar(75) = '3CARDSP_C_04212014_HP_0422'
	declare @batchnoWithouClint varchar(75) = substring(@pBatchNo,CHARINDEX('_',@pBatchNo)+1,100)
	Declare @Subclient varchar(15)='';
	declare @FileType varchar(1) ='';
	Declare @FilePath varchar(250)
	
	set @Subclient =(Select substring(@pBatchNo,0,CHARINDEX('_',@pBatchNo)))
	set @FileType =(Select substring(@batchnoWithouClint,0,CHARINDEX('_',@batchnoWithouClint)))
	Declare @ServiceId int = 0
	Declare @ClientId int = 0
	set @ClientId = (select ClientId from ADM_Client where ClientAcmName =@Subclient and CustomerId=20)
	if(UPPER(@FileType) ='C')
       begin
            set @ServiceId = 1
          
        End
     else if(UPPER(@FileType) ='P')
         begin
            set @ServiceId = 5          
         End
         
  if(@ClientId <>0 and @ServiceId <>0)
   begin       
       set @FilePath =(select 'St.Louis\TP\'+REPLACE(convert(varchar,GETDATE(),101),'/','')+'\Batch\'+@pBatchNo+'.PDF')
	   Exec TRN_pBatchesInsert @CmpKey ='StLou',@ScanDate=@pScanDate,@BatchNo=@pBatchNo,@FileName =@pFileName,@ClientId =@ClientId,@ServiceId=@ServiceId
							   ,@BatchType=1,@CreatedBy=1777,@PageCount=@pPageCount,@BatchFullName=@FilePath
    End
End






GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kSTLouis_pAutoBatchImport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kSTLouis_pAutoBatchImport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kSTLouis_pAutoBatchImport] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kSTLouis_pAutoBatchImport] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kSTLouis_pAutoBatchImport] TO [DB_DMLSupport]
    AS [dbo];

