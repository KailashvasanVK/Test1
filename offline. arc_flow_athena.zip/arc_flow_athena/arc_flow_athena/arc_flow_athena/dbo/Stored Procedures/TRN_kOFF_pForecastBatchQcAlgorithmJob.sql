﻿CREATE Procedure TRN_kOFF_pForecastBatchQcAlgorithmJob  
As  
Begin    
select ''
/***************************************************************************************************  
   Created Date         :   2019-05-15   
   Created By           :   mallikarjun.nam  
   Description          :   For Random Qc alogothim  
   SCR/Ticket#          :   155811  
  ****************************************************************************************************  
   SUMMARY OF CHANGES  
   Modified Date        Modified By          SCR/Ticket#   Comments  
   ------------------- -------------------  -----------   ------------------------------------------------------------        
***************************************************************************************************/  
  /*
   Set transaction isolation level read uncommitted            
   /*Service buckets are excluded from the random qc algorithim */            
   if(select count(CtlValue) from ADM_SoftControl (nolock) where CtlValue='Y' and CtlID='ForecastQCAlgorithm')>0            
   Begin              
  
      /*For testing in live enable this option for single user*/  
    Declare @UserId int=0  
    Set @UserId=(Select UserId from arc_rec_athena..arc_rec_user_info where nt_username ='Srinivasan.v4')  
            
    Declare @ProcessCount int,@DirUpload int = 0,@NewUser int=0,@isMergeBatch int=0            
   ,@IsbatchAudited int,@CurrentTime int,@ShiftMaxTime int,@RandomNo int=0,@ShiftId int            
   ,@UserTodayEntryCompletedBatchCount int=0,@UserTodayEntryCompletedBatchTransCount int=0            
   ,@BatchTransCount int=0,@IsUserInDayShift int=0,@NT_UserName Varchar(100)            
   ,@QcDate date,@DayStartTime datetime ,@DayEndTime datetime ,@MaxQcUserTransCount int=0   
  
   Set @MaxQcUserTransCount=isnull((select CtlValue from ADM_SoftControl where CtlID='UMTRANS'),100)            
   Set @CurrentTime= Datepart(hh,getdate())  
   if(@CurrentTime<8)  
   Set @QcDate = cast((dateadd(dd,-1,getdate())) as date)            
   else               
   Set @QcDate = cast(getdate() as date)                        
  
   /*set @QcDate='2019-06-21'*/  
      
   set @DayStartTime=  Convert(varchar,Convert(Date,@QcDate)) + ' 08:00'            
   set @DayEndTime= Convert(varchar,Convert(Date,DATEADD(DD,1, @QcDate))) + ' 08:00'   
  
   if object_Id('tempdb..#BatchInfo') is not null drop table #BatchInfo         
   select ROW_NUMBER() OVER(ORDER By EntryTrans) as RowIndex, *   
   into #BatchInfo from (  
   Select bat.BatchId,que.BatchprocessId,flow.CreatedBy as EntryUser  
   ,(Select Sum(TransValue) from TRN_kOFF_tbatchtransact (nolock) trn where trn.BatchProcessID=que.BatchProcessId  and trn.CreatedBy=flow.CreatedBy and trn.TransValue>0) as EntryTrans  
   ,case when Left(bat.BatchNo,1) in ('M','S') then 1 else 0 end as IsMergeBatch  
   ,(select top 1 ShiftId from AMD_UserShift (nolock) where Nt_UserName=usr.Nt_UserName and  Effect_DATE<= @QcDate order by TID desc) as ShiftId   
   ,0 as ShiftMaxTime  
   ,0 as IsBatchAudited  
   ,0 as IsMovetoQc  
   ,0 as BatchMovedRandomNo  
   ,Convert(varchar(500),null) as result  
   ,0 as IsMaxTransCrossed  
   ,0 as TodayProcessedTransCount      
   from trn_kOFF_tbatches (nolock) bat  
   inner join TRN_kOFF_tbatchqueue(nolock) que on bat.BatchId=que.BatchId and bat.status =1 and statusId=6   
   inner join TRN_kOFF_tbatchflow(nolock) flow on bat.BatchId=flow.BatchId and que.BatchprocessId=flow.BatchprocessId and que.statusId=flow.StatusId  
   inner join arc_rec_athena..arc_rec_user_info usr on flow.CreatedBy=usr.UserId  
   where bat.UploadDt is null and bat.AuditedDt is null     
   and bat.postedDt between @DayStartTime and @DayEndTime            
   and flow.CreatedBy=@UserId  
   and not exists (select 1 from ADM_DirectUploadExceptional dEX where bat.ServiceId=dEX.ServiceId)  
   and not exists (select 1 from ADM_QCAuditSkipUsers qcskip where flow.Createdby=qcskip.UserId and qcskip.status=1)  
   and not exists (select 1 from TRN_kOFF_tRandomAuditBatches qcskip where bat.BatchId=qcskip.BatchId)   
   )x order by EntryTrans  
     
   /*Update shift max time based on shift id*/  
   update tBat set ShiftMaxTime =case when isnull(ShiftId,0)=1 then (select CtlValue from ADM_SoftControl (nolock) where CtlID='GSMTIME')  
   else (select CtlValue from ADM_SoftControl (nolock) where CtlID='NSMTIME') end  
   from #BatchInfo tBat  
     
   /* Convert into 24 hours format*/  
   update #BatchInfo set ShiftMaxTime=15 where ShiftMaxTime=3  
  
    update bat Set IsBatchAudited=1  
    from #BatchInfo  bat  
    inner join TRN_kOFF_tRandomAuditBatches (nolock) qcM   on bat.BatchId=qcM.BatchId and bat.BatchProcessId=qcM.BatchPRocessId  
    inner join TRN_kOFF_tBatchQcComments qcCom on qcM.BatchprocessId=qcCom.BatchprocessId  
    and not exists(select 1 from TRN_kOFF_tDirectUpload du (nolock) where du.BatchId=bat.BatchId and du.status=1)  
  
  
   /*Get Random Batch*/           
   /*User wise merge batch completed count from the last week to yesterday*/  
   if object_Id('tempdb..#UesrLastWeekCompletedBatch') is not null drop table #UesrLastWeekCompletedBatch  
   select EntryUser,min(BatchCount) as BatchCount  
   into #UesrLastWeekCompletedBatch  
   from (  
    select tbat.EntryUser, count(distinct flow.batchid) BatchCount  
    from TRN_kOFF_tBatchFlow(nolock) flow  
    inner join TRN_kOFF_tBatches(nolock) bat on flow.BatchId=bat.BatchId and Left(BatchNo,1) in ('M','S') and bat.status in(1,99)  
    inner join #BatchInfo tbat on flow.CreatedBy=tbat.EntryUser  
    where flow.StatusId=6  
    and convert(date,flow.CreatedDt) between getdate()-7 and getdate()-1 and datepart(dw,flow.createdDt) not in(1,7)          
    group by tbat.EntryUser,Convert(Date,bat.PostedDt)         
   )x group by EntryUser  
  
   DECLARE @TotCompLastWeek int=0,@Alloted int=3                    
   if object_Id('tempdb..#batRamdomNo') is not null drop table #batRamdomNo  
   Select userId,  
   case when RandomNo>0 then RandomNo else (select ABS(Checksum(NewID()) % @Alloted)+1) end RandomNo,  
   case when RandomNo>0 then 1 else 0 end isRandomGent  
   into #batRamdomNo from (  
     Select userId,max(RandomNo) as RandomNo from arc_flow_athena.dbo.trn_koff_tQCRandomAuditLogic (nolock) qcR  
     inner join #BatchInfo tbat on qcR.UserId=tbat.EntryUser  
     where convert(date,PresentDayUpdate)=convert(date,getdate())    
     group by userId  
   )x  
  
   Update qcR set RandomNo=batR.RandomNo   
   from arc_flow_athena.dbo.trn_koff_tQCRandomAuditLogic qcR  
   inner join #batRamdomNo batR on qcR.UserId=batR.USerId  
   where convert(date,qcR.PresentDayUpdate)=convert(date,getdate()) and batR.isRandomGent=0   
  
   update qcR set presentday=isnull(presentday,0) + 1,PresentdayUpdate=getdate()   
   from trn_koff_tQCRandomAuditLogic qcR  
   inner join #BatchInfo tbat on qcR.UserId=tbat.EntryUser  
   where PresentdayUpdate<getdate()  
  
   update qcR set ToAudit= case when presentday=1 then 1 else presentday -1 end  
   from trn_koff_tQCRandomAuditLogic qcR  
   inner join #BatchInfo tbat on qcR.UserId=tbat.EntryUser  
   where presentday between 1 and 7  
  
   update qcR set skipdate= convert(date,getdate())  
   from trn_koff_tQCRandomAuditLogic qcR  
   inner join #BatchInfo tbat on qcR.UserId=tbat.EntryUser  
   WHERE isnull(isskip,0)=0 and convert(date,SkipDate)<convert(date,getdate())  
     
   update tBat set IsMovetoQc=0,result='Batch moving to direct upload which are same as SkipDate and getdate()'  
   from #BatchInfo tBat  
   inner join trn_koff_tQCRandomAuditLogic qcR on tBat.EntryUser=qcR.UserId  
   where IsMergeBatch=1 and  convert(date,SkipDate)=convert(date,getdate())  
  
   Update qcR set isskip=1  
   from trn_koff_tQCRandomAuditLogic qcR  
   inner join  #BatchInfo tdu on qcR.UserId=tdu.EntryUser  
   where IsMergeBatch=1 and  convert(date,SkipDate)=convert(date,getdate())  
           
 if object_Id('tempdb..#NoBatchAuditedUsers') is not null drop table #NoBatchAuditedUsers  
 Select distinct bat.EntryUser into #NoBatchAuditedUsers from #BatchInfo bat  
 inner join(  
    select qcR.UserId,qcR.RandomNo from trn_koff_tQCRandomAuditLogic qcR  
    inner join (  
    select tBat.EntryUser as UserId,Count(Batchid) as batCount  
    from #BatchInfo tBat   
    where IsBatchAudited=0 and IsMergeBatch=1  
    group by EntryUser                                                         
    )x on qcR.UserId=x.UserId and qcR.RandomNo=x.batCount           
 )y on bat.EntryUser=y.UserId  
      
    update bat set BatchMovedRandomNo=RandomNo  
    from #BatchInfo bat  
    inner join #batRamdomNo qc on bat.EntryUser=qc.UserId       
      
 update bat set IsMovetoQc=1  
 from #BatchInfo bat  
 inner join(  
    select RowIndex,EntryUser,IsMovetoQc,BatchMovedRandomNo as RandomNo,  
    Row_number() Over(Partition by EntryUser order by RowIndex) as sn  
    from #BatchInfo bat  
    where IsmergeBatch=1 and IsBatchAudited=0       
      
 )x on bat.RowIndex=x.RowIndex and bat.EntryUser=x.EntryUser and bat.BatchMovedRandomNo=x.sn  
  
        
   Update bat set IsMovetoQc=1,result='shift end time crossed batch moved to audit process'   
   from #BatchInfo bat   
   where IsMovetoQc<>1  
   and ShiftMaxTime<=DATEPART(hh,getdate())  
     
   if object_Id('tempdb..#MaxTransCountReachedUsers') is not null drop table #MaxTransCountReachedUsers  
   Select *   
   into #MaxTransCountReachedUsers  from (  
    Select FTE_ID,SUM(TransCount) TransCount          
    from TRN_kOFF_tRandomAuditBatches qbat  
    inner join (Select distinct EntryUser from  #BatchInfo where IsMergeBatch=0 and IsBatchAudited=0)x on qbat.FTE_ID=x.EntryUser  
    where qbat.QCDATE= @QcDate  
    group by qbat.FTE_ID                
   )x   
            
   update b set IsMaxTransCrossed= Case when TransCount>=100 then 1 else 0 end ,TodayProcessedTransCount=TransCount  
   from #BatchInfo b inner join #MaxTransCountReachedUsers c on b.EntryUser=c.FTE_ID  
     
 Declare @RowIndex int=1,  
 @RowCount int =(select Count(BatchId) from #BatchInfo),  
 @SumTransCount int=0,@CurentBatchTransCount int=0  
 WHILE @RowIndex<=@RowCount  
 BEGIN  
    if(select count(*) from #BatchInfo where ROWIndex=@RowIndex and (IsMergeBatch=1 or IsMaxTransCrossed=1 or IsBatchAudited=1 ))=0  
    Begin  
     Select @SumTransCount =  Sum(TodayProcessedTransCount) + Sum(EntryTrans)                        
     from #BatchInfo where ROWIndex=@RowIndex  and IsMergeBatch=0 and IsMaxTransCrossed=0       
                                
     if(@SumTransCount<=100)  
     Begin  
     update #BatchInfo  set IsMovetoQc=1,result='Batches moved to audit process which are all not crossed maximum configured trans count (@MaxQcUserTransCount)'   
     where ROWIndex=@RowIndex     
     update #BatchInfo  set TodayProcessedTransCount=@SumTransCount                       
     ENd  
     if(@SumTransCount>100)  
     break;  
    ENd  
    set @RowIndex=@RowIndex+1  
 END  
    
   update du set status=0,UpdatedBy=1777,UpdatedDt=getdate(),Comments='Random QC,Release from Direct upload by system'  
   from TRN_kOFF_tDirectUpload du  
   inner join #BatchInfo  bat on bat.BatchId=du.BatchId and  bat.IsMovetoQc=1  
   where du.Status = 1  
     
   Insert into TRN_kOFF_tDirectUpload(BatchId,CreatedBy,CreatedDt,Status,Comments)  
   Select BatchId,1777,getdate(),1,result  from #BatchInfo  bat  
   where IsMovetoQc=0 and not exists (select 1 from TRN_kOFF_tDirectUpload where batchid=bat.BatchId and status=1)  
     
   Insert into TRN_kOFF_tRandomAuditBatches(BatchId,BatchProcessId,FTE_ID,TransCount,QCDate,CreatedDt,BatchRandomNo)  
   select BatchId,BatchProcessId,EntryUser,EntryTrans,@QcDate,getdate(),BatchMovedRandomNo from #BatchInfo            
     
End            
Else return;  
*/
End   
  
GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pForecastBatchQcAlgorithmJob] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pForecastBatchQcAlgorithmJob] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pForecastBatchQcAlgorithmJob] TO [DB_DMLSupport]
    AS [dbo];

