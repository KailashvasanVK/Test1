﻿Create Proc ReviewTarget_NonMerge_Less10 (@serviceid int,@fromdate datetime ,@Todate datetime)            
as         
        
        
if OBJECT_ID('Tempdb..#Tem') is not null drop table #Tem            
if OBJECT_ID('Tempdb..#NormalTrans') is not null drop table #NormalTrans           
if OBJECT_ID('Tempdb..#targ') is not null drop table #targ            
            
Select (Select top  1 CreatedDt from TRN_kOFF_tBatchFlow where BatchId = bat.BatchId  and StatusId =1 order by CreatedDt) as StartTime,            
(            
Select top  1 CreatedDt from TRN_kOFF_tBatchFlow where BatchId = bat.BatchId  and StatusId =6 order by CreatedDt desc) as EndTime, Batchno ,             
sum(paymentinscnt)+sum(Exceptioncnt)+sum(Createdptncnt)+sum(ptnpostingcnt) as 'Transcount' into #NormalTrans            
From TRN_kOFF_tBatches bat  inner join  arc_athena..batchloginformation b on bat.batchno=b.batchnum            
Where             
bat.BatchNo  in (select batchno from trn_koff_tbatches where serviceid not in (363,365) and left(batchno,1)<>'M'
 and scandate between @fromdate and @todate ) 
 and batchno not in (select childbatchno from mergebatchdetails)           
group by batchid,batchno            
            
select datediff(mi,starttime,endtime) as 'Timetaken', Transcount,Batchno into #Tem from #NormalTrans            
select   convert(decimal(9,2),Transcount)/convert(decimal(9,2),Timetaken) * 60*8 as 'Target' into #Targ from #Tem  where Timetaken>0 and Transcount>0            
          
--select  avg(convert(decimal(9,2),Transcount)/convert(decimal(9,2),Timetaken)) * 60*8 as 'Target'  from #Tem  where Timetaken>0 and Transcount>0            
select  avg(Target)  from #Targ where target>400          
        
Select * from #Tem        
Select * from #NormalTrans        
Select * from #targ 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ReviewTarget_NonMerge_Less10] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ReviewTarget_NonMerge_Less10] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ReviewTarget_NonMerge_Less10] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ReviewTarget_NonMerge_Less10] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ReviewTarget_NonMerge_Less10] TO [DB_DMLSupport]
    AS [dbo];

