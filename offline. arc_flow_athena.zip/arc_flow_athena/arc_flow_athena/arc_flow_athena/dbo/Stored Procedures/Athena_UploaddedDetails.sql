﻿create proc Athena_UploaddedDetails 
as 
begin
/*      
      
Cretaed By     : Leela.T
Created Date   : 2016-08-11
Purpose        : Get the Uploaded Batch Details in scandate and service wise
Ticket/SCR ID  : <>  
TL Verified By : Ramakrishnan.G  

*/                      

select Scandate,ServiceName, Count(Batchno) as BatchCount from batchmaster(nolock) bat inner join arc_flow_Athena..trn_koff_tbatches(nolock) tbat on bat.batchnum=tbat.batchno
inner join arc_flow_Athena..adm_service ser on ser.serviceid=tbat.serviceid
where UploadDate=(select max(uploaddate) from Batchmaster(nolock)) group by scandate,servicename
order by scandate, ServiceName desc 

End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_UploaddedDetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_UploaddedDetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_UploaddedDetails] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_UploaddedDetails] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_UploaddedDetails] TO [DB_DMLSupport]
    AS [dbo];

