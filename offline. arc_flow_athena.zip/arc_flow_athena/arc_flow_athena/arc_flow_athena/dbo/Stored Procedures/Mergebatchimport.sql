﻿CREATE  proc Mergebatchimport          
as          
begin          
          
declare @Rowcount int,@dollarAmt Float,@batchno varchar(20)          
          
create table #ParentBatches          
(          
Id  int IDENTITY (1, 1) NOT NULL,                                                                                            
BatchNo   Varchar(20))            
             
             
  --drop table #parentbatches          
   insert into #ParentBatches(BatchNo)          
   select distinct parentbatchno from  ARC_Flow_Athena..MergeBatchDetails where status=2          
             
   select @Rowcount=@@ROWCOUNT          
             
   while(@Rowcount>0)          
   begin          
    select @batchno = batchno from #ParentBatches where id=@Rowcount          
    Print @batchno          
--updateARC_Athena..batchMaster set dollarAmt=10 where           
   select @dollarAmt=SUM(dollaramt) from ARC_Athena..batchMaster where          
   batchnum in (          
   select ChildBatchNo from ARC_Flow_Athena..MergeBatchDetails where ParentBatchNo=@batchno          
 )          
             
   Update ARC_Athena..batchMaster set dollarAmt= @dollaramt where batchnum=@batchno          
           
   Update  ARC_Flow_Athena..TRN_kOFF_tBatches set status=1 where batchno=@batchno          
          
   Update ARC_Flow_Athena..MergeBatchDetails  set status=3 where parentbatchno=@batchno          
   set @Rowcount=@Rowcount-1          
   End          
                                                                                                
End   
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Mergebatchimport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Mergebatchimport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Mergebatchimport] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Mergebatchimport] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Mergebatchimport] TO [DB_DMLSupport]
    AS [dbo];

