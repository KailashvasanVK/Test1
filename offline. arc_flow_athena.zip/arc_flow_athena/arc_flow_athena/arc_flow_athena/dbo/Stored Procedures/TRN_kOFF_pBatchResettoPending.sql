﻿CREATE Procedure TRN_kOFF_pBatchResettoPending
(      
 @CustomerId int=0,      
 @BatchId int=0,      
 @BatchServiceId int=0,      
 @CreatedBy int=0,      
 @Comments varchar(250) ='',      
 @EditMoode varchar(2)='RP'
)      
As      
Begin   
  
    
  --Declare @BatchId int =4827243     
  --Declare @BatchServiceId int= 397      
  --Declare @CreatedBy int =5733      
  --Declare @Comments varchar(250) ='Reset by It ,Req by Bismilla'      
  --Declare @CustomerId int=25 
  --       ,@EditMoode varchar(2)='RP'      
  --Declare @msg varchar(500) output

  
  /*
   Modified by : mallikarjun.nam     
   Modified Dt :2017-02-10
   pupose : Validate status merge and remit batches
   Impact : Editbatchdetails.aspx    
   
   Modified by : mallikarjun.nam     
   Modified Dt :2017-03-29
   pupose : Inserting reset batch id in to log table(TRN_kOFF_tBatchResetLog)
   Impact : Editbatchdetails.aspx    
   
    Modified By :Noor   
    Modified Dt :2018-11-20
    Ticket : 343974 
    Purpose : Clear audit log when batch is marked as reset
    Implemented By : Narayana
   
	*/    
  
 
 Declare @CmpKey varchar(5)      
 set @CmpKey = (select CmpKey from ADM_Customer where CustomerId =@CustomerId and  Status=1)      
 Declare @Qry varchar(max)      
 
 Declare @BatchNo varchar(100)      
 Declare @PostedDate date       
 Declare @MonthlastDate date      
 Declare @MonthFirstDate date       
 set @PostedDate  = (SELECT convert(date,PostedDt) from TRN_kOFF_tBatches where BatchId =@BatchId)      
 set @MonthlastDate = (SELECT convert(date,DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,GETDATE())+1,0))))       
 set @MonthFirstDate = (SELECT CONVERT(date,DATEADD(month, DATEDIFF(month, 0, GETDATE()), 0)))      
 Set @BatchNo=(Select batchno from trn_koff_tbatches where batchid=@BatchId)
 /*--   /*Invoice closing checking*/      
 --if(@PostedDate < @MonthFirstDate)      
 --begin      
 -- RAISERROR('Reset failed! Invoice has been closed for the respective batch.',16,1)      
 -- return      
 --End      
      */
 /*Invalid Batch details*/      
 if (select count(*) from TRN_kOFF_tBatches tb Inner Join Arc_athena..BatchMaster bm on tb.batchno=bm.batchnum    
   where tb.BatchId=@BatchId and tb.ServiceId=@BatchServiceId and bm.UlStatus =1 )>0      
    begin        
   Select 'Edit failed ! Completed batch cannot reset'    as [msg]    
   RETURN      
    end              
 /*Invalid Batch details*/      
 if (select count(*) from TRN_kOFF_tBatches where BatchId=@BatchId and ServiceId=@BatchServiceId and status = 1)=0      
    begin        
   Select 'Reset failed ! Invalid batch details' as [msg]     
   RETURN      
    end       
   
 if (select count(*) from TRN_kOFF_tBatchQueue where BatchId=@BatchId and ServiceId=@BatchServiceId)=0      
    begin        
    Select 'Reset failed ! Incomplete / Split batches cannot reset.' as [msg]
    RETURN      
    end       
   
	 Declare @assigned varchar(100)  
	 Set @assigned = isnull((Select u.nt_username from TRN_kOFF_tBatchQueue q   
	 inner join arc_rec_Athena..arc_rec_user_info u on u.userid = q.assigned  
	 where BatchId=@BatchId  
	 ),'')  
   
 if @assigned <> ''  
    begin        
   Select 'Already assigned by ' + @assigned + '. Please release and reset.' as [msg]  
   RETURN      
    end       
           
       
 /*Disregarded Bath */      
 if (select count(*) from TRN_kOFF_tBatches where BatchId=@BatchId and status=0) > 0      
    begin        
   Select 'Reset failed ! You cant able to edit the Disregarded batch'   as [msg]    
   RETURN      
    end      
 /*Created by mallikarjun.nam for restict the merge batches to reset*/
 if (select count(*) from TRN_kOFF_tBatches where BatchId=@BatchId and status=99) > 0      
 begin        
   Select 'Reset failed ! You cant able to edit the merged batches' as [msg]
   RETURN      
 end 
 
 /*Created by mallikarjun.nam for restict the upload hourly (remit batches) batches to reset*/
 if (select count(*) from arc_athena..Upload_Hourly where BatchNum=@BatchNo) > 0      
 begin        
   Select 'Edit failed ! You cant able to edit the remit batches' as [msg] 
   RETURN      
 end                
 /* workflow inprogress */      
 if (select count(*) from TRN_kOFF_tBatchQueue where BatchId=@BatchId and StatusId=15) > 0      
    begin        
   Select 'Reset failed ! You cant able to edit the batch while workflow inprogress' as [msg]      
   RETURN      
    end  
 /* Restrict Inprogress batches to reset  */      
 if (select count(*) from TRN_kOFF_tBatchQueue where BatchId=@BatchId and StatusId in (1,7) and isnull(Assigned,0)<>0) > 0      
    begin        
   Select 'Reset failed ! You cant able to reset the Inprogress batches' as [msg]       
   RETURN      
    end  
 
 if (Select count(UserId) from ADM_BatchResetReleaseAccess where UserId=@CreatedBy and isnull(IsReset,0)=1 and status=1) = 0      
    begin        
   Select 'Reset failed ! You are not having the access to reset the batch'  as [msg]      
   RETURN      
    end  
        
 /*Batch Edit details*/      
 insert into TRN_kOFF_tBatchModified(BatchId,BatchServiceId,CreatedBy,CreaetdDt,Comments,ModifyMode)      
 select  @BatchId,@BatchServiceId,@CreatedBy,GETDATE(),@Comments,@EditMoode      
 /*Qc Details*/      
 delete from TRN_kOFF_tBatchQCMaster where BatchProcessId in (select BatchProcessId from TRN_kOFF_tBatchQueue where BatchId=@BatchId)      
 delete from TRN_kOFF_tBatchQCComments  where  BatchProcessId in (select BatchProcessId from TRN_kOFF_tBatchQueue where BatchId=@BatchId)       
 delete from TRN_kOFF_tBatchQCTran where BatchProcessId in (select BatchProcessId from TRN_kOFF_tBatchQueue where BatchId=@BatchId)      
 /*Issue Fields details*/      
 delete flds from TRN_kOFF_tBatchIssueFields flds      
 inner join TRN_kOFF_tBatchIssueLog ilog on ilog.ILogId = flds.ILogId and       
 ilog.BatchProcessId in (select BatchProcessId from TRN_kOFF_tBatchQueue where BatchId=@BatchId) and ilog.BatchId=@BatchId      
 /*Issue log details*/      
 delete from TRN_kOFF_tBatchIssueLogCloseMirror where BatchProcessId in (select BatchProcessId from TRN_kOFF_tBatchQueue where BatchId=@BatchId)      
 delete from TRN_kOFF_tBatchIssueFieldsMirror where BatchProcessId  in (select BatchProcessId from TRN_kOFF_tBatchQueue where BatchId=@BatchId)      
 delete his from TRN_kOFF_tBatchIssueLogHistory his      
 inner join TRN_kOFF_tBatchIssueLog ilog on ilog.ILogId = his.ILogId and       
 ilog.BatchProcessId in (select BatchProcessId from TRN_kOFF_tBatchQueue where BatchId=@BatchId) and ilog.BatchId=@BatchId      
 delete from TRN_kOFF_tBatchIssueLogMirror where BatchProcessId in (select BatchProcessId from TRN_kOFF_tBatchQueue where BatchId=@BatchId) and BatchId =@BatchId      
 delete from TRN_kOFF_tBatchIssueLog  where --BatchProcessId in (select BatchProcessId from TRN_kOFF_tBatchQueue where BatchId=@BatchId)       
 BatchId =@BatchId        
 /*Transaction Details*/      
 delete from TRN_kOFF_tBatchTransactSummaryLog where BatchId=@BatchId -- and BatchProcessId in (select BatchProcessId from TRN_kOFF_tBatchQueue where BatchId=@BatchId)      
 delete from TRN_kOFF_tBatchTransactSummary where BatchId=@BatchId -- and BatchProcessId in (select BatchProcessId from TRN_kOFF_tBatchQueue where BatchId=@BatchId)      
      
 delete from TRN_kOFF_tBatchTransact  where BatchId=@BatchId --and BatchProcessId in (select BatchProcessId from TRN_kOFF_tBatchQueue where BatchId=@BatchId)      
 delete from TRN_kOFF_tBatchTransactMirror where BatchProcessId in (select BatchProcessId from TRN_kOFF_tBatchQueue where BatchId=@BatchId)      
 /*Processed Bacthes*/      
 /*delete from TRN_kOFF_tProcessedBatches where BatchProcessId  in (select BatchProcessId from TRN_kOFF_tBatchQueue where BatchId=@BatchId)*/      
 delete from TRN_kOFF_tDirectUpload where BatchId=@BatchId    
    
 delete from TRN_kOFF_tBatchFlow Where BatchId = @BatchId and StatusId not in (0,2)  
 
 Update TRN_kOFF_tBatchQueue set Assigned=0,StatusId=0,Comment=''''   
 from TRN_kOFF_tBatchQueue  as Que where Que.BatchId=@BatchId      
 /*Batches Deatils*/        
 update TRN_kOFF_tBatches set PostedDt=null,AuditedDt=null,UploadDt=null where BatchId=@BatchId  
 
 /*Ticket : 343974 
    Purpose : Clear audit log when batch is marked as reset*/ 
  DECLARE @IsbatchAudited int=0
 select @IsbatchAudited=count(distinct qcM.BatchId) from TRN_kOFF_tRandomAuditBatches(nolock) qcM          
  inner join TRN_kOFF_tBatches(nolock) bat on qcM.BatchId=bat.BatchId and bat.status in(1,99)          
  and Left(BatchNo,1) in ('M','S')          
  where bat.batchid=@Batchid       
  and not exists (select 1 from TRN_kOFF_tDirectUpload(nolock) where BatchId=bat.BatchId and status=1)
  IF(@IsbatchAudited>0)
  BEGIN
  DELETE TRN_kOFF_tRandomAuditBatches where batchid=@Batchid
  Insert into TRN_kOFF_tBatchModified(BatchId,BatchServiceId,CreatedBy,CreaetdDt,Comments,ModifyMode)  
     select distinct BatchId,ServiceId,@CreatedBy,GETDATE(),'Reset the batch which is in Audit Queue','ADRP' from TRN_kOFF_tBatches (nolock) 
     WHERE BatchId=@Batchid       
  END
       
 Insert into TRN_kOFF_tBatchResetLog(Scandate,Batchno,Serviceid,Createdby,Createddate,Comments)
 Select Scandate,Batchno,Serviceid,@CreatedBy,GETDATE(),'Reset' from TRN_kOFF_tBatches where BatchId=@BatchId   
 
 
 
Select 'SUCCESS' as msg 
 
  
End 




GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pBatchResettoPending] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchResettoPending] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchResettoPending] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pBatchResettoPending] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchResettoPending] TO [DB_DMLSupport]
    AS [dbo];

