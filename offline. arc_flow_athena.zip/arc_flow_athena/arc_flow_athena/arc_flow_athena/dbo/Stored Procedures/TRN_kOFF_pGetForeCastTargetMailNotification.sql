﻿CREATE Procedure TRN_kOFF_pGetForeCastTargetMailNotification
As
Begin

	/*                  
	Purpose           : Generating html template for  sending mail notification of forecast report on every day morning
	Created By        : mallikarjun.nam
	Created Date      : 04-09-2015
	Impact to         : -

	Modified by : Mallikarjun.nam
	Modified Dt :25-09-2015
	Purpose : Change Mail Reciepts ,mail ids
	
	Modified by : Mallikarjun.nam
	Modified Dt :05-10-2015
	Purpose : Change Mail Template as requested in scr #631 in UAT stage
	
	Modified by : mohamedsafiyu.a
	Modified Dt :03/30/2016
	Purpose : Shipment added as per ticket
	
	Modified by : mohamedsafiyu.a
	Modified Dt :04/01/2016
	Purpose : Day one previous month forecast should be display
	
	 */  
Set transaction isolation level read uncommitted 
Set nocount on;

dECLARE @SYSDATE DATE = getdate()

declare @fromDate date,@toDate date,@HtmlText varchar(max),@weekDays int,@DaywiseReportContent varchar(max)
declare @MonthForecasttarget int,@TargatAchievedTilldate int, @TargatAchievedPec money
,@DayShipmentTotal int,@OverAllShipmentTotal int
 ---- get Today Target
if (OBJECT_ID('tempdb..#tblForeCast') IS NOT NULL)  DROP TABLE #tblForeCast
if (OBJECT_ID('tempdb..#tblForeCastNew') IS NOT NULL)  DROP TABLE #tblForeCastNew
if (OBJECT_ID('tempdb..#FinalReport') IS NOT NULL)  DROP TABLE #FinalReport
if (OBJECT_ID('tempdb..#tblForeCastNew') IS NOT NULL)  DROP TABLE #tblForeCastNew  
if (OBJECT_ID('tempdb..#tblForecastFinalreport') IS NOT NULL)  DROP TABLE #tblForecastFinalreport
if DatePart(DD,@SYSDATE) = 1
	Begin
	Set @fromDate  = DATENAME(Year,DateAdd(DD,-1,@SYSDATE)) + '-' + DATENAME(MONTH,DateAdd(DD,-1,@SYSDATE)) + '-01'
	Set @toDate = DATEAdd(DD,-1,@SYSDATE)
	End
else
	Begin
	Set @fromDate  = CONVERT(VARCHAR(25),DATEADD(dd,-(DAY(@SYSDATE)-1),@SYSDATE),101) -- First day of this month
	Set @toDate =    dATEADD(DD,-1,@SYSDATE)  --get yester day. 
	End

if(@fromDate>@toDate)
  Set @toDate =@fromDate
select @MonthForecasttarget=isnull(Target,0) from  ADM_Forecast where datepart(mm, @fromDate)=Month and datepart(yy, @fromDate)= Year 
declare @LastDayOfMonth varchar(20)=(SELECT DATEADD(d, -1, DATEADD(m, DATEDIFF(m, 0, @toDate) + 1, 0)))  --Get last day of the month 
Set @weekDays  =(select dbo.TRN_kOFF_fnCalculateWeekDays(@fromDate,@LastDayOfMonth)) -- Total working days of this month 

/*---------------Generate Empty forecast report upto till date----------------------------------------------------------*/
;with mths as
(
	select convert(date,@fromDate) as SDate,0 as Achieved,0 as YetToAchieved,0 as [Achieved%]
	,Convert(datetime,convert(varchar,@fromDate) + ' 08:00') as FromDT
	,Convert(datetime,convert(varchar,DAteAdd(DD,1,@fromDate)) + ' 07:59')  ToDT
	union all
	select DATEADD(dd,1,convert(date,SDate)),0 as Achieved,0 as YetToAchieved,0 as [Achieved%]
	,Convert(datetime,convert(varchar,DATEADD(dd,1,convert(date,SDate))) + ' 08:00') as FromDT
	,Convert(datetime,convert(varchar,DAteAdd(DD,1,DATEADD(dd,1,convert(date,SDate)))) + ' 07:59')  ToDT
	from mths
	where DATEADD(dd,1,convert(date,SDate)) <= convert(date,@toDate)
)
		 
select *  into #tblForeCast  from mths
option (maxrecursion 35);
   
/*---------------------------Get forecast Targer from ADM_forecast table and split into day wise target----------------------------------------------*/   
select F1.SDate,F1.Achieved,F1.YetToAchieved,F1.[Achieved%] 
,(case when datename(dw,F1.SDate) IN('Sunday','Saturday') THEN 0 
	   when (select count(Holiday_Date) from arc_rec_athena..Athena_Holidaylist  where Holiday_Date =cast(F1.SDate as date))>0  THEN 0 
       else (Target/@weekDays) end) as [Day wise Target] ,FromDT,ToDT
into #tblForeCastNew 
from #tblForeCast  F1 
left outer join  ADM_Forecast F2 on datepart(mm, F1.SDate)=F2.Month and datepart(yy, F1.SDate)= F2.Year

---- Day wise trans data

	if (OBJECT_ID('tempdb..#tblTrans') IS NOT NULL)  DROP TABLE #tblTrans
	create table #tblTrans(Achieved int, TransDate date)

	insert into #tblTrans(Achieved, TransDate) 
	select sum(TransValue) as Achieved , fc.SDate as TransDate   
	from trn_kOFF_tbatchTransact (nolock) T 
	inner join #tblForeCastNew as fc on t.CreatedDt >= fc.FromDT and  t.CreatedDt <= fc.ToDT
	Inner JOIN trn_kOFF_tbatches (nolock) B ON T.BatchId= B.BatchID AND B.status=1 and T.TransValue <>0 			
	where B.CreatedDt>='1/1/2019'
	group by  fc.SDate 
	option(recompile)

--- Day shipment

	if (OBJECT_ID('tempdb..#tblDayShipment') IS NOT NULL)  DROP TABLE #tblDayShipment
	create table #tblDayShipment(DayShipment int, TransDate date)

	insert into #tblDayShipment(DayShipment, TransDate) 
	select sum(TransValue) as DayShipment, fc.SDate as TransDate  
	from trn_kOFF_tbatchTransact (nolock) T 
	inner join #tblForeCastNew as fc on t.CreatedDt between fc.FromDT and fc.ToDT   
	Inner JOIN trn_kOFF_tbatches (nolock) B ON T.BatchId= B.BatchID AND B.status=1 and T.TransValue <>0 			
	inner join ARC_ATHENA..BatchMaster as bm on bm.batchnum = b.batchno and UploadDate between fc.FromDT and fc.ToDT 
	and bm.downloaddate>='2/1/2019'
	where  B.CreatedDt>='1/1/2019'
	group by  fc.SDate
	option(recompile)

--- Overall Shipment

	if (OBJECT_ID('tempdb..#tblOverAllShipment') IS NOT NULL)  DROP TABLE #tblOverAllShipment
	create table #tblOverAllShipment(OverAllShipment int, TransDate date)

	insert into #tblOverAllShipment(OverAllShipment, TransDate)
	select sum(TransValue) as OverAllShipment, fc.SDate as TransDate  
	from trn_kOFF_tbatchTransact (nolock) T    
	Inner JOIN trn_kOFF_tbatches (nolock) B ON T.BatchId= B.BatchID AND B.status=1 and T.TransValue <>0 			
	inner join ARC_ATHENA..BatchMaster as bm on bm.batchnum = b.batchno and bm.downloaddate>='2/1/2019'
	inner join #tblForeCastNew as fc on bm.UploadDate between fc.FromDT and fc.ToDT 
	where  B.CreatedDt>='1/1/2019'  
	group by  fc.SDate
	option(recompile)

 /*---------------------------Get acheived Target from batchtransact table and split day wise acheived target ----------------------------------------------*/ 

select F.SDate,round(Convert(decimal(10,2), F.[Day wise Target]),0) as [Day wise Target],TarnsTbl.Achieved,
(case when datename(dw,F.SDate) IN('Sunday','Saturday') THEN '0.00' 
	  when (select count(Holiday_Date) from arc_rec_athena..Athena_Holidaylist  where Holiday_Date =cast(F.SDate as date))>0  THEN '0.00'
      else (case when  isnull(round(Convert(decimal(10,2), F.[Day wise Target]),0),0)=0 then '0.00' 
			else  convert(varchar, cast((convert(money,isnull(TarnsTbl.Achieved,0))/convert(money,F.[Day wise Target])*100)as decimal(18,2)))  
	       end)
 end)  as [Achieved%]
,DaysUploaded.DayShipment
,OverAllUploaded.OverAllShipment
into #FinalReport
from #tblForeCastNew F  
left outer join #tblTrans as TarnsTbl ON F.sdate=TarnsTbl.TransDate
left outer join #tblDayShipment as DaysUploaded ON F.sdate=DaysUploaded.TransDate
left outer join #tblOverAllShipment as OverAllUploaded ON F.sdate=OverAllUploaded.TransDate
option(recompile)
 
Create table #tblForecastFinalreport(Sno int identity,Date varchar(20),[Day] varchar(20),[Day wise Target] decimal(10,2),Achieved int,[Achieved%] Decimal(9,2),DayShipment int,OverAllShipment int)

Insert into #tblForecastFinalreport(Date,[Day],[Day wise Target],Achieved,[Achieved%],DayShipment,OverAllShipment)
select Convert(varchar,SDate,101) as Date,
DateName(dw, SDate) Day,[Day wise Target],isnull(Achieved,0) Achieved,[Achieved%],isnull(DayShipment,0),isnull(OverAllShipment,0)
from #FinalReport
Order by SDate

Insert into #tblForecastFinalreport(Date,[Day wise Target],Achieved,[Achieved%],DayShipment,OverAllShipment)
select 'Total' as Date,sum([Day wise Target]) as [Day wise Target],sum(Achieved) as Achieved,
(case when  sum(isnull([Day wise Target],0))=0 then '0.00' else  convert(varchar, cast((convert(money,sum(isnull(Achieved,0)))/convert(money,sum([Day wise Target]))*100)as decimal(18,2)))   end) as [Achieved%]
,isnull(SUM(DayShipment),0),isnull(SUM(OverAllShipment),0)
from #FinalReport 


/*--------------------Generate html table for daywise target for each daywise target and achieved upto till date--------------------------- */
set @DaywiseReportContent =(Select  '#opentr#'+'#opentd#' + convert(varchar,Date) +'#closetd#' +'#opentd#' + convert(varchar,Day) +'#closetd#' +
 '#opentd#' + convert(varchar,[Day wise Target]) +'#closetd#' 
 +'#opentd#' + convert(varchar,Achieved) +'#closetd#' 
 +'#opentd#' + convert(varchar,[Achieved%]) + '%' +'#closetd#'
 +'#opentd#' + convert(varchar,DayShipment) + '#closetd#'
 +'#opentd#' + convert(varchar,OverAllShipment) +'#closetd#' 
 +'#closetr#'
 from #tblForecastFinalreport for xml path(''))

/*--------------------Calculate total Target achieved till date---------------------- */

select @TargatAchievedTilldate=(Achieved)
,@TargatAchievedPec=(Case when isnull(@MonthForecasttarget,0)=0 then 0 else  (convert(money,Achieved*100)/@MonthForecasttarget) end)
,@DayShipmentTotal = DayShipment
,@OverAllShipmentTotal = OverAllShipment
from #tblForecastFinalreport where [DATE] = 'Total'

if (OBJECT_ID('tempdb..#tblForeCast') IS NOT NULL)  DROP TABLE #tblForeCast
if (OBJECT_ID('tempdb..#tblForeCastNew') IS NOT NULL)  DROP TABLE #tblForeCastNew
if (OBJECT_ID('tempdb..#FinalReport') IS NOT NULL)  DROP TABLE #FinalReport
if (OBJECT_ID('tempdb..#tblForeCastNew') IS NOT NULL)  DROP TABLE #tblForeCastNew  
if (OBJECT_ID('tempdb..#tblForecastFinalreport') IS NOT NULL)  DROP TABLE #tblForecastFinalreport
 
set @DaywiseReportContent= Replace(@DaywiseReportContent,'#opentd#','<td>')
set @DaywiseReportContent= Replace(@DaywiseReportContent,'#closetd#','</td>')
set @DaywiseReportContent= Replace(@DaywiseReportContent,'#opentr#','<tr style=''border: 1px solid Silver; font-size: 12px;''>') 
set @DaywiseReportContent= Replace(@DaywiseReportContent,'#closetr#','</tr>') 
 
 set @HtmlText ='<html><body><div style=''font-family: verdana; font-size: 12px''>Hi,<br /><br /><p>Daily production status</p><br />
 <div style=''width:650px;  border: 1px solid green;''>
 <div style=''height: 20px; background: green; font-size: 15px; text-align: center;color: White;''>Daily production status</div>
 <div style=''padding: 10px;  border-top: 1px solid #FFFF66; font-size: 12px;''>
 <table style=''margin-left:18px;''><tr  style=''border: 1px solid Silver; font-size: 12px;''><td align=''center''> <u>Forecast VS Achieved</td>
 <td align=''center''><u>Yet To Achieve</u></td></tr><tr><td>
 
<table border=''1'' style=''font-size: 12px;'' cellpadding=''3'' cellspacing=''0''><tr style=''border: 1px solid Silver; font-size: 12px;background-color:#FFFFCC;''>
 <th>Forecast</th><th>Achieved</th><th>Achieved%</th></tr>
 <tr><td>&nbsp;'+convert(varchar,isnull(@MonthForecasttarget,0))+'</td><td>&nbsp;'+ convert(varchar,isnull(@TargatAchievedTilldate,0))+'</td><td>&nbsp;'+ convert(varchar,isnull(@TargatAchievedPec,0))+'%</td></tr></table>
  
 </td><td><table border=''1'' style=''font-size: 12px;'' cellpadding=''3'' cellspacing=''0''><tr style=''border: 1px solid Silver; font-size: 12px;background-color:#FFFFCC;''>
 <th>Yet to Achieve</th></tr><tr><td>&nbsp;'+convert(varchar,(isnull(@MonthForecasttarget,0)- isnull(@TargatAchievedTilldate,0)))+'</td></tr></table></td></tr></table></div>
  
 <div style=''padding: 10px; font-size: 12px;''>
 <table border=''1'' style=''font-size: 12px;'' cellpadding=''3'' cellspacing=''0''><tr ><td colspan="7" align="center"><b>Day Wise Status  </b></td>
 </tr><tr style=''border: 1px solid Silver; font-size: 12px;background-color:#FFFFCC;''><th>Date</th><th>Day</th><th>Day wise Target</th><th>Achieved</th><th>Achieved% </th><th>DayShipment</th><th>OverAllShipment</th></tr>
 '+@DaywiseReportContent+'
</table></div>
</div> <br />Thanks,<br /><img src=''http://www.accesshealthcare.co/appimages/arc_flow.png'' alt='''' width=''250px''height=''65px'' /></p> ** This is an auto-generated email. Please do not reply
to this email.**</div></body></html>
 '
 Select @HtmlText
 declare @mailsuject varchar(100)='Daily production status-' + convert(varchar(30), @SYSDATE)
 Declare @Receipts varchar(max)
 Set @Receipts='DL-WTP@accesshealthcare.co;ramakrishnan.go@accesshealthcare.co;mirza.karim@accesshealthcare.co'
 Exec ARC_Rec_Athena..SP_INS_ARC_REC_MAIL_TRAN 'mail.support@accesshealthcare.co',@Receipts,'sakkaravarth.k@accesshealthcare.com;mallikarjun.nam@accesshealthcare.co',@mailsuject , @HtmlText,'Y',NULL  

end


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pGetForeCastTargetMailNotification] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pGetForeCastTargetMailNotification] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pGetForeCastTargetMailNotification] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pGetForeCastTargetMailNotification] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pGetForeCastTargetMailNotification] TO [DB_DMLSupport]
    AS [dbo];

