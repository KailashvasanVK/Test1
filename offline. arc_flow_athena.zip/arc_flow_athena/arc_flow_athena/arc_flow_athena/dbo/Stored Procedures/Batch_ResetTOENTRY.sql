﻿CREATE Proc [dbo].[Batch_ResetTOENTRY]  
(  
    @BatchNo varchar(50)  
   ,@UserId int  
)                   
as                
Begin    
--Declare @BatchNo varchar(50) ='IT-Test-01'  
--Declare @UserId int = 1451  
----Declare @BatchServiceId int = 0  
----Declare @Comments varchar(500) =''  
----Declare @EditMoode varchar(2)=''   
----Declare @BatchId int   
   
----Select top 1 @BatchId=BatchId,@BatchServiceId  = ServiceId from TRN_kOFF_tBatches where Batchno = @BatchNo   
----set @Comments = 'Reset to entry completed by  : ' + (select NT_USERNAME from ARC_Rec_Athena..ARC_REC_USER_INFO  where USERID = @UserId)  
   
----insert into TRN_kOFF_tBatchModified(BatchId,BatchServiceId,CreatedBy,CreaetdDt,Comments,ModifyMode)  
----select @BatchId,@BatchServiceId,@UserId,GETDATE(),@Comments,@EditMoode  
----/*Qc Details*/  
----delete from TRN_kOFF_tBatchQCMaster where BatchProcessId in (select BatchProcessId from TRN_kOFF_tBatchQueue where BatchId=@BatchId)  
----delete from TRN_kOFF_tBatchQCComments  where  BatchProcessId in (select BatchProcessId from TRN_kOFF_tBatchQueue where BatchId=@BatchId)   
----delete from TRN_kOFF_tBatchQCTran where BatchProcessId in (select BatchProcessId from TRN_kOFF_tBatchQueue where BatchId=@BatchId)  
----/*Issue Fields details*/   
----/**/    
----delete from TRN_kOFF_tBatchFlow where BatchId=@BatchId  and BatchProcessId in (select BatchProcessId from TRN_kOFF_tBatchQueue where BatchId=@BatchId)  
----and StatusId > 6   
----/*Batch queue Deatils*/    
------delete from TRN_kOFF_tBatchQueue where BatchId=@BatchId  and BatchProcessId <> (select Min(BatchProcessId) from TRN_kOFF_tBatchQueue where BatchId=@BatchId  )  
   
----Update TRN_kOFF_tBatchQueue set Assigned=0,StatusId=6,Comment='', FlowId = (Select MAX(flowid) from TRN_kOFF_tBatchFlow Where BatchProcessId = que.BatchProcessId  and BatchId =@BatchId)  
----from TRN_kOFF_tBatchQueue  as Que where Que.BatchId=@BatchId  
----/*Batches Deatils*/    
----update TRN_kOFF_tBatches set AuditedDt=null,UploadDt=null where BatchId=@BatchId   
Select ''
End  
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Batch_ResetTOENTRY] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Batch_ResetTOENTRY] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Batch_ResetTOENTRY] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Batch_ResetTOENTRY] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Batch_ResetTOENTRY] TO [DB_DMLSupport]
    AS [dbo];

