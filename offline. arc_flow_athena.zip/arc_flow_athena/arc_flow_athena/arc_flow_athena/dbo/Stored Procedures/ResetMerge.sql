﻿Create Procedure ResetMerge(@ParentBatchNo Varchar(75)
,@Comments varchar(1000) = ''
,@NTName varchar(75) = ''
)
As
Begin
/*
Action : this routine will disregard the parent batch and move the child batch status to queue
created by : mohamedsafiyu.a
created on : 02/10/2016
*/

/** checking whether the parent batch in active mode **/
if (Select COUNT(*) from TRN_kOFF_tBatches as b where BatchNo = @ParentBatchno and status = 1) > 0
Begin
 RAISERROR ('Parent batch is in active status. Cannot reset', 16, 1);
End

Begin Transaction  
Begin Try 
Insert into TRN_kOFF_tDisRegard(BatchId,Comments,CreatedBy,CreatedDt)
Select BatchId,'Parent batch reset by : ' + @NTName + ' : ' + @Comments,0,GETDATE()
from TRN_kOFF_tBatches where BatchNo = @ParentBatchno

Insert into TRN_kOFF_tBatchModified(BatchId,BatchServiceId,CreatedBy,CreaetdDt,ModifyMode,Comments)
Select BatchId,ServiceId,0,getdate(),'IT','Parent batch reset by : ' + @NTName + ' : ' + @Comments
from TRN_kOFF_tBatches where BatchNo = @ParentBatchno

Insert into TRN_kOFF_tBatchModified(BatchId,BatchServiceId,CreatedBy,CreaetdDt,ModifyMode,Comments)
Select BatchId,ServiceId,0,getdate(),'IT','child batch release to queue : ' + @NTName + ' : ' + @Comments
from TRN_kOFF_tBatches child
inner join mergebatchdetails as mb on mb.ParentBatchNo = @ParentBatchno and mb.ChildBatchNo = child.BatchNo 
where child.status = 99

Update TRN_kOFF_tBatches Set status = 0 where BatchNo = @ParentBatchno
Update child Set Status = 1
from TRN_kOFF_tBatches child
inner join mergebatchdetails as mb on mb.ParentBatchNo = @ParentBatchno and mb.ChildBatchNo = child.BatchNo 
where child.status = 99

Commit Transaction  
Select ''  
End Try  
Begin Catch  
Rollback transaction  
return Error_Message()  
End catch  
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ResetMerge] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ResetMerge] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ResetMerge] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ResetMerge] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ResetMerge] TO [DB_DMLSupport]
    AS [dbo];

