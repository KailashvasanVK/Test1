﻿CREATE Procedure [dbo].[ADM_AccessTargetQCInsert]
@QualityTargetId varchar(5),
@AccTargetId  int,
@CreatedBy int
As
/*
Created by : Karthik Ic
Created on : 24 May 2013.
Impact to  : ProfileSetup.aspx
Purpose    : To update the service wise user target
*/
Begin
If exists  (Select top 1 'x'  from ADM_AccessTargetQC Where AccTargetId = @AccTargetId)
Begin
Update ADM_AccessTargetQC set QualityTargetId = @QualityTargetId,
 CreatedBy =@CreatedBy,
 QALevelId = case when ISnull(QALevelId,0) = 0 then (select  MIN(QALevelId) from ADM_QaTargetTran where TargetId = @QualityTargetId) else QALevelId end,
 EffectiveFrom = case when Effectivefrom IS null then GETDATE() else EffectiveFrom end,
 CreatedDt = GETDATE()
Where AccTargetId =  @AccTargetId
End
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_AccessTargetQCInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessTargetQCInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessTargetQCInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_AccessTargetQCInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessTargetQCInsert] TO [DB_DMLSupport]
    AS [dbo];

