﻿CREATE PROCEDURE SMETool_RemoveBatchesToUploadP  
 (  
 @BatchNumber nvarchar(50),  
 @CreatedBy nvarchar(50)  
 )  
 As  
 BEGIN  
 Insert into SMETool_RemoveBatchesToUpload   
 Select BatchNum,dollaramt,@CreatedBy, GETDATE()  from upload_hourly Where batchnum = @BatchNumber  
   
if(@@ROWCOUNT > 0)  
BEGIN  
Delete upload_hourly Where batchnum = @BatchNumber  
END    
END  

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[SMETool_RemoveBatchesToUploadP] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SMETool_RemoveBatchesToUploadP] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SMETool_RemoveBatchesToUploadP] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[SMETool_RemoveBatchesToUploadP] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SMETool_RemoveBatchesToUploadP] TO [DB_DMLSupport]
    AS [dbo];

