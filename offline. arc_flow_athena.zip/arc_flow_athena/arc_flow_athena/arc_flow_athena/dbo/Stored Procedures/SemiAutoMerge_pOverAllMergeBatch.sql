﻿CREATE procedure SemiAutoMerge_pOverAllMergeBatch(                                                           
 @Actions varchar(20) =null                                                        
,@scandate varchar(10)=null                                                 
,@Minpagecount varchar(5)=null                                                
,@Maxpagecount int=0                                                
,@serviceid varchar(10)=null                                               
,@Percentlvl int =0                     
)                                                
as                                            
                                                                   
begin                                                 
/*                                                    
Created By     : Leela.T                  
Created Date   : 09-May-2018                
Purpose        : batches will be merge which is avail               
Ticket/SCR ID  : <>                  
TL Verified By : <>    
                               
Modified By     : Leela.T                  
Modified Date   : 08-Oct-2019                
Purpose        : Batches will be merge in invoice table order               
Ticket/SCR ID  : <>                  
TL Verified By : <>                
              
              
Implemented by : Karmegan.c               
Implemented On :  10-05-2018                           
                                         
                                                
*/                                                
                                            
Declare @BatchCount int,@ParentBatchid int ,                                                                      
@ParentBatchNo varchar(30),@Batchclientid int,@count int=0,@pgcount int,                                                                      
@Chk int=0,@StartPgNo int, @EndPgNo int,@Fname varchar(300)                                                                      
,@dollaramt money ,@BatchNo varchar(50), @qury nvarchar(Max) ,@Batchclinetid int                      
,@pdfPath varchar(500)                 
                                   
                                
if(object_id('tempdb.dbo.#BatchCountDetails')is not null)                                                                
drop table #BatchCountDetails              
create table #BatchCountDetails                                        
(BatchCount int)                                                                       
                                            
if(object_id('tempdb.dbo.#BatchDetails')is not null)                                                                          
drop table #BatchDetails                                                                          
create table #BatchDetails                                                                                           
(BatchNo   varchar(30))                                                  
                                           
if(object_id('tempdb.dbo.#InvoiceBatches')is not null)                                                                          
drop table #InvoiceBatches                                                                          
create table #InvoiceBatches                                                                                           
(BatchNo   varchar(30)) 
 
if(object_id('tempdb.dbo.#InvoiceorderBatch')is not null)                                                                          
drop table #InvoiceorderBatch                                                                          
create table #InvoiceorderBatch                                                                                           
(Rowindex int,
BatchNo   varchar(30))                                              
                                           
if(object_id('tempdb.dbo.#MergeBatchDetails')is not null)                                                                
drop table #MergeBatchDetails                                                      
create table #MergeBatchDetails                                                                            
( Rowindex int                                             
,BatchNo   Varchar(15)                                                                                                              
,PageCount   int                                                                                
,Fname varchar(300)                                            
,status int                                                                                
,dollarAmt Money                         
)                                                                                       
         
if(object_id('tempdb.dbo.#EntClient')is not null)                                             
drop table #EntClient                                                                         
create table #EntClient             
(Subclient   varchar(10))                                              
                                 
if (@Actions='Enterprise')                                          
begin                                
 insert into  #EntClient                                              
 select distinct SubClient from ARC_ATHENA..SubClient_Info sub where sub.status=1 and Category like '%Enterprise%'                                
End                                
else if (@Actions='EDS Merge')                                 
begin                                 
 insert into  #EntClient                                              
 select distinct SubClient from ARC_ATHENA..SubClient_Info sub where sub.status=1                                         
End                                          
                                       
set @qury='insert into #BatchCountDetails                                                                      
select count(distinct a.batchno) from trn_koff_tbatches a inner join ARC_Athena..batchMaster b on a.BatchNo=b.batchnum                                                                         
Inner join TRN_kOFF_tBatchQueue bq on a.batchno=bq.batchno                                                  
Inner join ADM_Client adm on adm.ClientId=a.ClientId and CustomerId=25 and adm.status=1                                     
left join mergebatchdetails mrg on mrg.childbatchno=a.batchno                                    
left join TRN_kOFF_tBatchResetLog Rp on RP.batchno= a.batchno
left join arc_athena..Invoice_tAutomationBatchQueue(Nolock) tAbq on  tAbq.BatchNo=b.batchnum  and tAbq.StatusId=2 
left join arc_athena..Entry_InvoiceAutomation(Nolock) inv on inv.BatchNo=b.batchnum'                                           
                                           
if @Actions<>'SubClientMerge'                          
set @qury+=  ' Inner join #EntClient sub on adm.ClientName=sub.SubClient '                                             
       
set @qury+=' where  mrg.childbatchno is null and a.status=1 and bq.assigned=0  and Rp.Batchno is null                                        
and bq.statusid=0 and a.postedDt is null and a.UploadDt is null             
and b.ULStatus is null and a.PgCount <>1 and '                                                       
                                              
set @qury+=' a.PgCount <= cast('''+@Minpagecount+'''as int)'                                                
                                                      
if @Actions='SubClientMerge'                                                        
set @qury+= ' and a.ClientID not in (select Clientid from ExcludeFormerge) '                                               
                                                
if @scandate <>''                                                                                          
Set @qury += ' and convert(varchar,a.scandate,101) = '''+@scandate+''''                                                                                   
                                                
if @serviceid <>''                                                                         
Set @qury += ' and a.serviceid = cast('''+@serviceid+'''as int) '                         
--Set @qury +=  'order by tAbq.BatchNo asc'                    
--if @serviceid ='362'                                                           
--Set @qury += ' and a.PgCount <>2 '                           
                                            
exec (@qury)                                                                
set @qury=''                                
             
select @BatchCount=Batchcount from #BatchCountDetails                                 

if(@BatchCount>=2500)      
begin          
set @Percentlvl=50                         
select @BatchCount=@BatchCount- ROUND(((@batchcount*@Percentlvl)/100),0)        
End                               
                                                                   
if(@BatchCount<15)                                                        
begin                                                         
return                                                        
End                                                                   
                                   
                                              
set @qury='insert into #Batchdetails                                                
select distinct top '+ CONVERT(VARCHAR,@BatchCount) +' a.batchno from TRN_kOFF_tBatches a                        
Inner join TRN_kOFF_tBatchQueue bq on a.batchno=bq.batchno                                                                
inner join ARC_Athena..batchMaster b on a.BatchNo=b.batchnum                                               
Inner join ADM_Client adm on adm.ClientId=a.ClientId and CustomerId=25 and adm.status=1                                    
left join mergebatchdetails mrg on mrg.childbatchno=a.batchno                                        
left join TRN_kOFF_tBatchResetLog Rp on RP.batchno= a.batchno 
left join arc_athena..Invoice_tAutomationBatchQueue(Nolock) tAbq on  tAbq.BatchNo=b.batchnum  and tAbq.StatusId=2 
left join arc_athena..Entry_InvoiceAutomation(Nolock) inv on inv.BatchNo=b.batchnum'                                          
                                            
if @Actions<>'SubClientMerge'                                                                                
set @qury+=  ' Inner join #EntClient sub on adm.ClientName=sub.SubClient '                                             
                                            
set @qury+=' where  mrg.childbatchno is null and a.status=1 and bq.assigned=0 and Rp.Batchno is null                                        
and bq.statusid=0 and a.postedDt is null and a.UploadDt is null                                            
and b.ULStatus is null and a.PgCount <>1 and '                                                        
                                              
set @qury+=' a.PgCount <= cast('''+@Minpagecount+'''as int)'                           
                                                      
if @Actions='SubClientMerge'                                                        
set @qury+= ' and a.ClientID not in (select Clientid from ExcludeFormerge) '                                              
                                                
if @scandate <>''                                                                                          
Set @qury += ' and convert(varchar,a.scandate,101) = '''+@scandate+''''                    
                                                
if @serviceid <>''                                                                         
Set @qury += ' and a.serviceid = cast('''+@serviceid+'''as int) '                           
--Set @qury +=  'order by inv.BatchNo )a'                                                
--if @serviceid ='362'                                                                 
--Set @qury += ' and a.PgCount <>2 '                                                                                  
                                                     
exec (@qury)                                                                         
set @qury=''  
                                                
set @qury='update TRN_kOFF_tBatches set status=99 where BatchNo in (select batchno from #Batchdetails)'     
exec (@qury)                                                                                
set @qury='' 
/***********************  Taking Batches in Invoice table ordern ************************/                                                                                                  
Insert into #InvoiceBatches
Select distinct Batchno from  arc_athena..Entry_InvoiceAutomation(Nolock) where batchno in (Select * from #BatchDetails)
  
Insert into #InvoiceorderBatch                                                                                              
select ROW_NUMBER() over (order by b) as rowindex, BatchNo from ( Select  a.batchno,case when b.BatchNo is not null then 0 else 1 end b 
from #BatchDetails a left join #InvoiceBatches b on a.BatchNo=b.BatchNo)x order by b                                            
                                                
/*********************** Parent Batch Creation ************************/                                                      
insert into Athena_ChildBatchgeneration                                                                       
select MAX(Batchid)+1 from athena_childBatchGeneration                                                                       
select @Batchclientid=MAX(Batchid) from athena_childBatchGeneration                           
INSERT INTO Athena_ParentBatchGeneration(ParentBatch) values (Convert(varchar(10),@Batchclientid) )                                                                                                              
set @ParentBatchid = SCOPE_IDENTITY()                                                                                                              
set @ParentBatchNo='S' + Convert(varchar(10),@ParentBatchid) + 'A1'                                                                       
 /************************ Insert the Child Batch in Temporary  Table  ************************/                                                  
insert into #MergeBatchDetails(Rowindex, BatchNo , pagecount,Fname,status,dollarAmt) 		   
select  c.Rowindex , c.batchno,pgcount,a.FNAMe ,0,b.dollarAmt from trn_koff_tbatches a                                          
inner join Arc_Athena..batchMaster b on a.BatchNo=b.batchnum                                            
inner join #InvoiceorderBatch c on c.BatchNo=b.batchnum                                          
left join mergebatchdetails mrg on a.BatchNo=mrg.ChildBatchNo                                          
where ChildBatchNo is null and convert(varchar,ScanDate,101)=convert(varchar,@scandate,101)                                                                             
and a.status=99  and ServiceId=cast(@serviceid as int) order by c.Rowindex   asc                                                                   
  /***************************Logically Batches are Merge ************************/                                                 
declare @CurMergeBatch cursor                                                                                                                  
set  @CurMergeBatch  = cursor fast_forward for                                                                                                             
                                                         
select batchno, pagecount,Fname,dollaramt from #MergeBatchDetails where status=0 order by Rowindex asc                                                                      
                                                     
open  @CurMergeBatch                                                                                                                                                                     
                                                                        
fetch next from @CurMergeBatch into                                                                                                             
@BatchNo,@PgCount ,@Fname,@dollaramt                                                                                                             
                         
while(@@fetch_status<>-1)                                                     
Begin                                                 
                                                
set @count=@count+@pgcount                                        
if(@Count>=@Maxpagecount)                                                                        
begin  
Set @Count=0                                                                                                          
Set @Chk=0                                                                                                  
select @Count=SUM(pagecount) from #MergeBatchDetails where status=0                                    
if(@Count<40)                                                         
begin                                                                                             
update TRN_kOFF_tBatches set status=1 where BatchNo in(                                                               
select BatchNo from #MergeBatchDetails where status=0)                                                                                            
Goto NextSubClient                                   
End                                                                       
                                             
set @count=0                                                                                          
set @count=@count+@pgcount                                                                                                              
                                                
insert into Athena_ChildBatchgeneration                                                                       
select MAX(Batchid)+1 from athena_childBatchGeneration                                                                        
select @Batchclientid=MAX(Batchid) from athena_childBatchGeneration                                    
INSERT INTO Athena_ParentBatchGeneration(ParentBatch) values (Convert(varchar(10),@Batchclientid) )                                                                                                              
set @ParentBatchid = SCOPE_IDENTITY()                                                                                                              
set @ParentBatchNo='S' + Convert(varchar(10),@ParentBatchid) + 'A1'                                                                                                             
                                                        
                                                
if (@Chk=0)                                                                                                          
begin                                                           
Set @Chk=1                                                                                                          
set @StartPgNo=1                                                                                  
set @EndPgNo=@PgCount                                                                                                          
End                                                                                                            
else     
begin                                                                            
set @StartPgNo=@EndPgNo+1                                                                                                          
set @EndPgNo= @startpgno + (@PgCount-1)                                                                           
End                                                  
End                                                                                                          
                                                
else                                                                                                           
begin                                                                         
if (@Chk=0)                                                    
begin             
Set @Chk=1                                                                       
set @StartPgNo=1                                                                          
set @EndPgNo=@PgCount                                      
End                                                     
               
else                                                           
begin                                                                                                         
set @StartPgNo=@EndPgNo+1                                                                               
set @EndPgNo= @startpgno + (@PgCount-1)                      
End                                                                                                            
end                                                                                                          
                                                
INSERT INTO MergeBatchDetails(ParentBatchNo,childBatchNo,StartPgNo,EndpgNo,TotalPages,status,Fname,dollaramt)                                                                           
values(@ParentBatchNo,@BatchNo,@StartPgNo,@EndPgNo,@PgCount,16,@Fname ,@dollaramt)                                                                                     
update #MergeBatchDetails set status=1 where BatchNo=@BatchNo                                                                                                
                                                 
fetch next from @CurMergeBatch  into                                                                                          
@BatchNo,@PgCount,@Fname,@dollaramt                                                                       
                                                   
End                                                                                                             
                                                
NextSubClient:                                            
                                                  
close @CurMergeBatch                                  
deallocate @CurMergeBatch                                                                                                
                                                     
if(object_id('tempdb.dbo.#MergeBatchDetails')is not null)drop table #MergeBatchDetails                                                       
if(object_id('tempdb.dbo.#BatchDetails')is not null)drop table #BatchDetails                                                       
if(object_id('tempdb.dbo.#BatchCountDetails')is not null)drop table #BatchCountDetails                                             
if(object_id('tempdb.dbo.#EntClient')is not null)drop table #EntClient
if(object_id('tempdb.dbo.#InvoiceBatches')is not null) drop table #InvoiceBatches 
if(object_id('tempdb.dbo.#InvoiceorderBatch')is not null) drop table #InvoiceorderBatch                                               
End 


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SemiAutoMerge_pOverAllMergeBatch] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[SemiAutoMerge_pOverAllMergeBatch] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SemiAutoMerge_pOverAllMergeBatch] TO [DB_DMLSupport]
    AS [dbo];

