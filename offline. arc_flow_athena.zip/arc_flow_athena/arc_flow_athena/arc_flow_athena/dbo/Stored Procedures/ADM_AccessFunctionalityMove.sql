﻿CREATE Procedure  [dbo].[ADM_AccessFunctionalityMove]  
@UserId int
As
/*
Created by : Karthik Ic
Created on : 15 May 2013
Impact to  : ProfileSetup.aspx
Purpose    : To move  all data from log table and delete the data from Functionality table.
*/
Begin
if exists(Select top 1 'x' from ADM_AccessFunctionality Where UserId=@UserId )
Begin
Insert into ADM_AccessFunctionalitylog (UserId,Functionality,CreatedBy,CreatedDt,AccFunctionalityId)
Select UserId,Functionality,CreatedBy,CreatedDt,AccFunctionalityId From  ADM_AccessFunctionality Where UserId=@UserId
Delete from ADM_AccessFunctionality Where UserId=@UserId
End
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_AccessFunctionalityMove] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessFunctionalityMove] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessFunctionalityMove] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_AccessFunctionalityMove] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessFunctionalityMove] TO [DB_DMLSupport]
    AS [dbo];

