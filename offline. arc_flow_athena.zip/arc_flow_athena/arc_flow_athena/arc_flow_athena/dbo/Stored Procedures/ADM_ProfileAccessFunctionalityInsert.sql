﻿

create Procedure [dbo].[ADM_ProfileAccessFunctionalityInsert]
@UserIdCollection varchar(max) = '',
@Functionality varchar(5),
@CreatedBy  int 
As
/*
Created by : Karthik Ic
Created on : 15 May 2013
Impact to  : ProfileSetup.aspx
Purpose    : To save the user and Functionality details
*/
Begin
Insert into ADM_AccessFunctionality(UserId,Functionality,CreatedBy)
select items,@Functionality,@CreatedBy from fnSplitString(@UserIdCollection,',')

End

/*END CustomerFunctionality */


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ProfileAccessFunctionalityInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileAccessFunctionalityInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileAccessFunctionalityInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ProfileAccessFunctionalityInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileAccessFunctionalityInsert] TO [DB_DMLSupport]
    AS [dbo];

