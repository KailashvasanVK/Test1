﻿
CREATE PROCedure [dbo].[ADM_DowntimeNoworkhoursMailNotification]
(
  @DNRowId int
)
AS
Begin 
    
    /* declare @DNRowId int=    205 */
    Declare @MailBody varchar(max),
    @FROM_MAILID varchar(100),
    @CC varchar(max),
    @RECIPIENTS varchar(max),
    @CreatedBy varchar(500),
    @Supervisor varchar(500),
    @ApprovedBy varchar(500),
    @ApprovalStatus varchar(500),
    @Subject varchar(500),
    @HeaderText varchar(max),
    @Manager varchar(100),
    @customerId int,
    @CustomerName varchar(100)
    
    
    Select @customerId=customerid, @CreatedBy=usr.NT_USERNAME,@Supervisor=usr.REPORTING_TO,@ApprovedBy=usrapr.NT_USERNAME
    ,@ApprovalStatus=Case when ISNULL(StatusId,0)=1 then 'Approved' 
						  when ISNULL(StatusId,0)=2 then 'Rejected'
						  else 'Waiting for approval' end  
    from ADM_DownTimeNoWorkHours dn
    inner join ARC_REC_ATHENA..ARC_REC_USER_INFO usr on dn.Createdby=usr.USERID
    left join ARC_REC_ATHENA..ARC_REC_USER_INFO usrapr on dn.StatusUpdatedBy=usrapr.USERID
    where RowId=@DNRowId
    
    select @CustomerName=internalname from adm_customer where customerid=@customerid
    
    
    select @Manager=usr.nt_username from   ARC_REC_ATHENA..ARC_REC_USER_INFO usr where usr.nt_username=@Supervisor
	if isnull(@ApprovedBy,'')=''
	Begin
	Set @RECIPIENTS=@Supervisor+'@accesshealthcare.com'
	Set @CC=@CreatedBy+'@accesshealthcare.com;'+@Manager+'@accesshealthcare.com'
	set @Subject= @CustomerName +' - Downtime/noworks has been initiated for your approval'
    Set @HeaderText =' This is to notify that downtime/nowork hours has been initiated  for your approval. <br><br>' 
	End
	Else
	Begin
	Set @RECIPIENTS=@CreatedBy+'@accesshealthcare.com' 
	Set @CC=@ApprovedBy+'@accesshealthcare.com;'+@Manager+'@accesshealthcare.com'   
	set @Subject= @CustomerName +' - Downtime/noworks has been '+@ApprovalStatus+' '
	Set @HeaderText =' This is to notify that downtime/nowork hours has been '+@ApprovalStatus+ '<br><br>'
	End

     
	Declare @HeaderQuery varchar(max)='',@BodyContent varchar(max)=''
	
	Set @HeaderQuery ='
	<html>
	<head>
	<style>
	body
	{
		font-family: verdana;
		font-size: 12px;
	}
	.box
	{
		filter: progid:DXImageTransform.Microsoft.gradient( startColorstr=''#ffffff'', endColorstr=''#eeeeee'', GradientType=0 );
		-webkit-border-radius: 5px;
		-moz-border-radius: 5px;
		border-radius: 5px;
		-moz-background-clip: padding;
		-webkit-background-clip: padding-box;
		background-clip: padding-box;
		border: 1px solid #aaaaaa;
		-webkit-box-shadow: 0 0 3px #ffffff inset, 0 1px 1px rgba(0,0,0,0.1);
		-moz-box-shadow: 0 0 3px #ffffff inset, 0 1px 1px rgba(0,0,0,0.1);
		box-shadow: 0 0 3px #ffffff inset, 0 1px 1px rgba(0,0,0,0.1);
		padding: 8px; /*  white-space: nowrap;
	     
		line-height: 24px;
		   color: #757575; */
	}
	.cellheader
	{
		color: #004276;
		font-weight: bold;
		background-color: #eeeeee;
		vertical-align: top;
		min-width: 120px;
	}
	table.display
	{
		border-collapse: collapse;
		word-wrap: break-word;
		font-family: verdana;
		font-size: 12px;
		width: 100%;
	}
	table.display tbody td
	{
		border: 0.1em solid #d8dcdf;
		padding: 5px;
	}
	div.forcewrap
	{
		white-space: normal;
		word-wrap: break-word;
		width: 22em;
	}
	</style>
	</head>
	<body>
	'
	Declare @BodyFooter varchar(max)
	Set @BodyFooter =   '<div>
	<img width="300px" height="70px" src="https://www.accesshealthcare.co/appimages/arc_flow.png"
		alt="" />
	</div>
	<div>
	** This is an auto-generated email. Please do not reply to this email.**
	</div>
	</body>
	</html>
			'
/*Downtime/nowork has been intialted by the team for below dates for supervisor approval*/
	select @BodyContent = '
	<div style="margin-left: 5px; font-weight: bold">  
		   <p>
				Hi,
				<br />
				<br />
		'+isnull(@HeaderText,'')+'
		
	</p>
	</div>
	<div class="box">
	<table class="display">
	<tbody>
	    
		<tr><td class="cellheader">Master Type</td><td><div class="forcewrap"> '+CONVERT(varchar(100),mt.TypeName)+' </div></td></tr>
		<tr><td class="cellheader">From Date</td><td><div class="forcewrap"> '+CONVERT(VARCHAR(100), dn.FromTime, 101) + ' '  + convert(VARCHAR(8), dn.FromTime, 14) +' </div></td></tr>
		<tr><td class="cellheader">To Date</td><td><div class="forcewrap"> '+CONVERT(VARCHAR(100), dn.ToTime, 101) + ' '  + convert(VARCHAR(8), dn.ToTime, 14) +' </div></td></tr>
		<tr><td class="cellheader">Reason</td><td><div class="forcewrap"> '+TATR.TypeName+' </div></td></tr>
		</tbody></table></div>
	    
		<br />
		 <br />
	    <a href="https://arcflow.accesshealthcare.co/arc_flow/ProfileSetUpTest.aspx" target="_blank">Please click on this link to take action</a>.
	'

	from ADM_DownTimeNoWorkHours dn
	inner join ADM_Customer cus (nolock) on dn.CustomerId=cus.CustomerId
		inner join ADM_MasterTypes(nolock) TATR on TATR.typeid=dn.ReasonId      
	inner join ADM_MasterTypes(nolock) mt on mt.TypeId=dn.TypeId      
	inner join ARC_REC_ATHENA..ARC_REC_USER_INFO usr (nolock) on dn.CreatedBy=usr.USERID
	where dn.RowId=@DNRowId
	
	Set @MailBody = @HeaderQuery + @BodyContent + @BodyFooter
    set @FROM_MAILID='mail.support@accesshealthcare.co'
    
    SET @CC=REPLACE(@CC,'shaji.ravi@accesshealthcare.co','')
    SET @RECIPIENTS=REPLACE(@RECIPIENTS,'shaji.ravi@accesshealthcare.co','')
	

    if exists(select 1 from ADM_DownTimeNoWorkHours where RowId=@DNRowId) and isnull(@BodyContent,'')!=''
		Exec ARC_REC_ATHENA..SP_INS_ARC_REC_MAIL_TRAN @FROM_MAILID = @FROM_MAILID,@RECIPIENTS = @RECIPIENTS, @CC = @CC
		,@SUBJECT_TEXT = @Subject,@BODY =@MailBody,@ISHTML = 'Y',@FilePath = ''
End






GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_DowntimeNoworkhoursMailNotification] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_DowntimeNoworkhoursMailNotification] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_DowntimeNoworkhoursMailNotification] TO [DB_DMLSupport]
    AS [dbo];

