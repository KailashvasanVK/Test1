﻿CREATE Procedure ADM_ServiceGroupCreation(@GroupName varchar(50),@CreatedBy int,@EntryFactor float,@QcFactor float)
As
Begin
/*
Created by : mohamedsafiyu.a
Created on : 10/27/2015
Purpose : To create service group/bucket for profile.
*/
Insert into ADM_SERVICE(ServiceName,ServiceAcmName,Description,FieldType,Status,CreatedBy,CreatedDt,SplitReq)
Select top 1 @GroupName,'','Offline','T',1,@CreatedBy ,GETDATE(),1 from ADM_Service
Where ServiceName <> @GroupName

Declare @ServiceId int = IDENT_CURRENT('adm_service')
Insert into ADM_CustomerServices(CustomerId	,ServiceId	,Price	,CreatedBy	,CreatedDt	
,FunctionalityId	,Paymode	,EffectiveFrom	
,FteCount	,FtePrice	,HrsValue	,HrsPrice	
,HrsFteCount	,MonTargetTran	,MonPrice	
,DayTargetTran	,DayPrice	
,DayWorkMode	,AprStatus	
,ApprovedBy	,ApprovedDt	,Code	,GroupName 
)
Select 
CustomerId	,@ServiceId ServiceId	,Price	,@CreatedBy  CreatedBy	,GETDATE()
,FunctionalityId	,Paymode	,EffectiveFrom	
,FteCount	,FtePrice	,HrsValue	,HrsPrice	
,HrsFteCount	,MonTargetTran	,MonPrice	
,DayTargetTran	,DayPrice	
,DayWorkMode	,AprStatus	
,ApprovedBy	,ApprovedDt	,Code	,GroupName 
from ADM_CustomerServices as cus
inner join ADM_Service as s on s.ServiceId = @ServiceId
where cus.serviceid = 397
and cus.ServiceId <> @ServiceId 

Insert into ADM_ServiceGroup(ServiceId,ServiceGroupId,CreatedBy,CreatedDt,ClientId)
Select sg.ServiceId,@ServiceId ServiceGroupId,@CreatedBy CreatedBy,getdate()CreatedDt,cl.ClientId 
from ADM_ServiceGroup as sg
inner join ADM_Client as cl on cl.CustomerId = 25
where sg.ClientId = 4904 and ServiceGroupId = 373
and not exists (select 1 from ADM_ServiceGroup where servicegroupid = @ServiceId)

Insert into ADM_FactorWaterTown(
ServiceGroupId
,EntryPayment,EntrySelfPosting,EntryCollection,EntryExceptionPosting,EntryPatientCreation
,QcPayment,QcSelfPosting,QcCollection,QcExceptionPosting,QcPatientCreation
,EffectiveFrom,EffectiveTo,Status,CreatedBy,CreatedDt
)
values(@ServiceId,@EntryFactor,@EntryFactor,@EntryFactor,@EntryFactor,@EntryFactor
,@QcFactor,@QcFactor,@QcFactor,@QcFactor,@QcFactor
,GETDATE(),null,1,1,GETDATE()
)
End




GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ServiceGroupCreation] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ServiceGroupCreation] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ServiceGroupCreation] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ServiceGroupCreation] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ServiceGroupCreation] TO [DB_DMLSupport]
    AS [dbo];

