﻿CREATE  Procedure TRN_kOFF_pManualEntryAllocationSearch   
      (  
            @UserId int=0,  
            @Cmpkey varchar(5)='',  
            @Action varchar(50)='',  
            @BatchIDs varchar(max)='',  
            @CreatedBy int=0,  
            @ServiceId int =0,  
            @ClientId int =0,  
            @Batchno varchar(50),  
            @PageNo int,  
            @SearchStr varchar(100) = '',    
            @SearchPattern varchar(4) = '=' /** = or % **/    
            ,@pPageSize int = 0    
            ,@pPageNumber int = 1   
            ,@payerID int = 0  
            ,@DateMode varchar(1)=''  
            ,@FromDate  varchar(20)=''    
            ,@ToDate  varchar(20)=''
            ,@LocationId int=1       --added by mallikarjun.nam   
      )  
      As  
      Begin  
      Set Transaction Isolation Level Read uncommitted;
 
      /*  
      CreatedBy : kathirvana.kand  
      CreatedDt : 09/30/2014  
      Purpose   : Toload the Pending batches for the manuall allocation   
      */  
        
      /*Declare   @UserId int=0,  
            @Cmpkey varchar(5)='OFF',  
            @Action varchar(50)='',  
            @BatchIDs varchar(max)='',  
            @CreatedBy int=0,  
            @ServiceId int =0,  
            @ClientId int =0,  
            @Batchno varchar(50),  
            @PageNo int,  
            @SearchStr varchar(100) = '',    
            @SearchPattern varchar(4) = '=' /** = or % **/    
            ,@pPageSize int = 0    
            ,@pPageNumber int = 1   
            ,@payerID int = 0  
            ,@DateMode varchar(1)='D'  
            ,@FromDate  varchar(20)='2015-02-28'    
            ,@ToDate  varchar(20)='2015-02-28'   
      */  
      declare @FromScanDate as datetime,  
      @ToScanDate as datetime,  
      @FromDownloadDate as datetime,  
      @ToDownloadDate as datetime  
        
      if(@DateMode = 'D')  
      begin  
            set  @FromScanDate  = convert(date,'1900-01-01')  
            set @ToScanDate  = DateAdd(day, 1, GETDATE())  
            set @FromDownloadDate = @FromDate  
            set @ToDownloadDate =@ToDate  
      END  
      ELSE IF (@DateMode = 'S')  
      Begin  
            set  @FromScanDate  = @FromDate  
            set @ToScanDate  = @ToDate  
            set @FromDownloadDate =  convert(date,'1900-01-01')  
            set @ToDownloadDate = DateAdd(day, 1, GETDATE())  
      END  
           /* Code written by mallikarjun.nam  */       
           if OBJECT_ID('tempdb..#UserLocation') is not null drop table #UserLocation
			 Create table #UserLocation( locationid int,LocationName varchar(50))
			 insert into  #UserLocation(locationId,LocationName)
			 exec ADM_GetUserLocation @userid,@LocationId		
            
	 
        
            if OBJECT_ID('tempdb..#PendingBatches') is not null drop table #PendingBatches           
            create Table #PendingBatches(chkpendingbatches varchar(max),BatchNo varchar(50),Service varchar(50),Client varchar(50),[Scan Date] varchar(50),[Download date] varchar(20)  
            ,Pages int ,PageFrom int,PageTo int,Status varchar(75), PayerName varchar(75),RowId int identity)  
              
           if OBJECT_ID('tempdb..#PendingBatchesResult') is not null drop table #PendingBatchesResult  
          create Table #PendingBatchesResult(chkpendingbatches varchar(max),BatchNo varchar(50),Service varchar(50),Client varchar(50),[Scan Date] varchar(50),[Download date] varchar(20)  
            ,Pages int ,PageFrom int,PageTo int,Status varchar(75),PayerName varchar(75),[RowId~Hide] int)  
              
          insert into #PendingBatches(chkpendingbatches,BatchNo,Service,Client,[Scan Date],[Download date],Pages,PageFrom,PageTo ,Status,PayerName)  
            select '<input type="checkbox"  class="chkpendingbatches" id='+cast(q.BatchProcessId as varchar)+' />' as chkpendingbatches  
            , q.BatchNo as BatchNo,ser.ServiceName as Service,cli.ClientAcmName as Client,  
            convert(varchar,bat.ScanDate,101) as [Scan Date],convert(varchar,bat.CreatedDt,101) AS [Download date],bat.PgCount as Pages,  
            q.PageFrom,q.PageTo,
            dbo.TRN_kOFF_fnGetBatchCurrentStatus(bat.BatchId) as Status               
            ,(select PayerName from ADM_PayerName_View where PayerId = bat.PayerId) as PayerName  
            from TRN_kOFF_tBatchQueue q  
            inner join TRN_kOFF_tBatches  bat on  bat.BatchId = q.BatchId  and bat.status=1 and bat.UploadDt is null   
            inner join #UserLocation as loc on isnull(bat.LocationId,1)=loc.LocationId -- code added by mallikarjun
            and bat.PgCount = case when ISNULL(@PageNo,0) <> 0 then @PageNo else bat.PgCount end  
            and bat.ClientId = case when ISNULL(@ClientId,0) <> 0 then @ClientId else bat.ClientId end  
            and bat.ServiceId =  case when ISNULL(@ServiceId,0) <> 0 then @ServiceId else bat.ServiceId  end  
            and bat.BatchNo  Like case when ISNULL(@Batchno,'') <> ''  then '' + @Batchno + '%' else bat.BatchNo end  
              
            AND  DATEADD(day, DATEDIFF(day, 0, bat.CreatedDt), 0) between  @FromDownloadDate  and @ToDownloadDate    
            AND  DATEADD(day, DATEDIFF(day, 0, ScanDate), 0)  between  @FromScanDate and  @ToScanDate   
              
          and ISNULL(bat.PayerId, 0 ) = (case  when ISNULL(@payerID, 0 ) <> 0 then @payerID else  ISNULL(bat.PayerId, 0 ) end)  
            inner join ADM_Service ser on ser.ServiceId = q.ServiceId  
            inner join ADM_Client cli on cli.ClientId = q.ClientId              
            where q.StatusId in (0,2,16) and q.Assigned=0   
            and  not exists ( select BatchProcessId from  TRN_kOFF_tManualAllocation where  BatchProcessId = q.BatchProcessId and status=1 and AllocationMode='E')         
            
            order by  bat.CreatedDt              
              
                    
            --Exec FilterTable   
            --@DbName = 'tempdb'  
      --   ,@TblName = '#PendingBatches'   
            --,@SearchStr =  @SearchStr  
            --,@SearchPattern = @SearchPattern  
            --,@OrderStr = ''         
        
              
            Insert into #PendingBatchesResult  
            Exec FilterTable   
            @DbName = 'tempdb'  
          ,@TblName = '#PendingBatches'   
            ,@SearchStr =  @SearchStr  
            ,@SearchPattern = @SearchPattern  
            ,@OrderStr = ''  
  
            DECLARE @FirstId int, @FirstRow int    
            SET @FirstRow =((@pPageNumber - 1) *(@pPageSize)+1)  
            SET ROWCOUNT @FirstRow    
            SELECT   @FirstId = [RowId~Hide]     
            FROM    #PendingBatchesResult  
            ORDER BY [RowId~Hide]  
            SET ROWCOUNT @pPageSize  
  
            SELECT *  
            FROM     #PendingBatchesResult    
            WHERE    [RowId~Hide] >= @FirstId    
            ORDER BY [RowId~Hide]  
            SET ROWCOUNT 0    
            Select Count(*) RowsCount from #PendingBatches          
              
      ENd 


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pManualEntryAllocationSearch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pManualEntryAllocationSearch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pManualEntryAllocationSearch] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pManualEntryAllocationSearch] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pManualEntryAllocationSearch] TO [DB_DMLSupport]
    AS [dbo];

