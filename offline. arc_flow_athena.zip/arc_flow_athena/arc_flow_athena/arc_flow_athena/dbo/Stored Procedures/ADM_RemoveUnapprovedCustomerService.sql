﻿CREATE Procedure ADM_RemoveUnapprovedCustomerService
@CustomerId  int
,@ServiceId varchar(200)
As
/*
To Remove the unapproved Services  from customerService
*/
Begin
DELETE from ARC_FLOW_Athena..ADM_CustomerServices  Where AprStatus != 1 
and CustomerId  = @CustomerId and ServiceId in (select items from fnSplitString(@ServiceId , ','))
End 


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_RemoveUnapprovedCustomerService] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_RemoveUnapprovedCustomerService] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_RemoveUnapprovedCustomerService] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_RemoveUnapprovedCustomerService] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_RemoveUnapprovedCustomerService] TO [DB_DMLSupport]
    AS [dbo];

