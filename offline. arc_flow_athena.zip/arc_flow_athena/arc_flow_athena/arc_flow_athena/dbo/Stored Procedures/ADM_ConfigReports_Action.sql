﻿CREATE Procedure ADM_ConfigReports_Action
@Action  varchar(100) = '',
@UserId int = 0 ,
@Customerid int = 0,
@ReportName varchar(75)=''
As
/*
exec ADM_ConfigReports_Action 'GetActiveCustomer',975
exec ADM_ConfigReports_Action @Action=N'GetFieldName',@UserId=NULL,@Customerid=51,@ReportName=N'Tracking Reports'
*/
/*
 * Purpose : To get the Active customer using userid 
 */
Begin
if (@Action ='GetActiveCustomer')
	Begin
	 Select distinct(ADMC.InternalName ) as InternalName, ADMC.CustomerId
	 From ARC_FLOW_Athena..ADM_Customer  ADMC
	 inner join ARC_FLOW_Athena..ADM_AccessCutomers  ADMAC on ADMAC.CustomerId = ADMC.CustomerId
	 Where  Status = 1 and isnull(ADMC.CmpKey,'') <> '' --  and ADMAC.UserId = @UserId
	 order by InternalName
	End
else if (@Action ='GetFieldName')
	Begin
	Select * from 
	(
	/*********************  Default Fields  *************************************/
	Select DefFld.ReportName,0 as ServiceId,DefFld.FieldName as DefaultValue
	,isnull(CusFlds.FieldDisplayText,'') as CustomizedText
	,DefFld.CtrlType,isnull(DefFld.CtrlValue,'') as  CtrlValue
	,DefFld.DisplayOrder as DefDisplayOrder,isnull(CusFlds.DisplayOrder,0) as CustomizedDisplayOrder
	from ADM_ConfigReports	as DefFld
	left join ADM_ConfigReports as CusFlds on CusFlds.ReportName = @ReportName and CusFlds.CustomerId = @Customerid and CusFlds.FieldName = DefFld.FieldName 
	Where DefFld.customerid  = 0 and DefFld.ReportName = @ReportName and DefFld.CtrlType = 'GCOL'
	Union all
	/*********************  Service Fields  *************************************/
	Select @ReportName as ReportName,Ser.ServiceId,Ser.ServiceName as DefaultValue
	,isnull(CusFlds.FieldDisplayText,'') as CustomizedText
	,Case when ser.FieldType = 'T' then 'TService' When Ser.FieldType = 'I' then 'IService' else '' end as CtrlType ,'' as CtrlValue 
	,99999 as DefDisplayOrder,isnull(CusFlds.DisplayOrder,99999) as CustomizedDisplayOrder
	from ADM_Service as Ser
	inner join 
	(
	Select ServiceId from ADM_ClientServices
	Where ClientId in (Select ClientId from ADM_Client Where CustomerId =  @CustomerId)
	Group by ServiceId
	) as CusSer on CusSer.ServiceId = Ser.ServiceId 
	left join ADM_ConfigReports as CusFlds on CusFlds.ReportName = @ReportName and CustomerId = @CustomerId and CusFlds.FieldName = Ser.ServiceName and CusFlds.CtrlType in ('TService','IService')

	/*********************  Param Fields  *************************************/
	union all
	Select DefFld.ReportName,0 as ServiceId,DefFld.FieldName as DefaultValue
	,isnull(CusFlds.FieldDisplayText,'') as CustomizedText
	,DefFld.CtrlType,isnull(CusFlds.CtrlValue,'') as  CtrlValue
	,DefFld.DisplayOrder as DefDisplayOrder,isnull(CusFlds.DisplayOrder,0) as CustomizedDisplayOrder
	from ADM_ConfigReports	as DefFld
	left join ADM_ConfigReports as CusFlds on CusFlds.ReportName = @ReportName and CusFlds.CustomerId = @Customerid and CusFlds.FieldName = DefFld.FieldName 
	Where DefFld.customerid  = @Customerid and DefFld.ReportName = @ReportName and DefFld.CtrlType = 'Param'
	) x Order by x.CustomizedDisplayOrder,x.DefDisplayOrder,x.CtrlType	
End
Else if (@Action = 'GetSelectedService')
	Begin
		Select  CReportId,ReportName,FieldName,FieldDisplayText,DisplayOrder,
		CustomerId From ADM_ConfigReports	ADMCR
		inner join ARC_REC_Athena..ARC_REC_USER_INFO ARUI on   ARUI.LastCustomerId = ADMCR.CustomerId 
		Where USERID  = @UserId and ReportName = @ReportName and  FieldName != '' 
	End
Else if (@Action ='GetInboxDefaultValues')
	begin
		Select  ADMCR.FieldName,ADMCR.CtrlValue From ADM_ConfigReports ADMCR
		inner join ARC_REC_Athena..ARC_REC_USER_INFO ARUI on   ARUI.LastCustomerId = ADMCR.CustomerId 
		Where USERID = @UserId and  ADMCR.ReportName =@ReportName and CtrlType  ='Param' 
	End 
Else if (@Action ='ILogClassification')
	begin		
		Select  ILC.ClassifyId,ILC.ClassifyName  from ADM_IssueLogClassification  ILC
		inner join ARC_REC_Athena..ARC_REC_USER_INFO ARUI on   ARUI.LastCustomerId = ILC.CustomerId 
		Where arui.USERID  = @UserId 
	End 
Else if (@Action ='ILogStatus')
/* To load the ilogStatus checkbox in  flow inboxConfig */
	begin		
		Select ILog_Status,StatusCaption from  ARC_FLOW_Athena..ADM_ILogStatus  where ILog_Status in (0,1,3,4,5)
	End 	
Else if (@Action ='ILogStatusSearch') 
/* To load the ilogStatus checkbox in  Exteranet inbox search */
	begin		
		-- Select ILog_Status,StatusCaption from  ARC_FLOW_Athena..ADM_ILogStatus  where ILog_Status in (0,1,3,4,5)
		Select ILog_Status,StatusCaption from  ADM_ILogStatusView  where ILog_Status in (0,1,3,4,5)  and customerId  =@Customerid 
	End 
	Else if (@Action ='CustomerName')   
/* To get Customer Name using Id in inbox  Handled/Held at Customer end  in Dropdown */  
 begin     
	--select  internalname as CustomerName  from  ADM_Customer ADMC  Where CustomerId =@Customerid
	Select ILog_Status,StatusCaption  from ADM_ILogStatusView  where customerid = @Customerid and ilog_status in (1,2,3)
 End 
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ConfigReports_Action] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ConfigReports_Action] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ConfigReports_Action] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ConfigReports_Action] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ConfigReports_Action] TO [DB_DMLSupport]
    AS [dbo];

