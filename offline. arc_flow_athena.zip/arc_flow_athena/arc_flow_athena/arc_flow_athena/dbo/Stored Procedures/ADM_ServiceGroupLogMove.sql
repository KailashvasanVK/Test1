﻿CREATE Procedure [dbo].[ADM_ServiceGroupLogMove]          
(          
@ClientId int          
)          
As          
Begin 
 /*   
    Purpose      :moving the  servicesGroups into servicesGroupslog table   if exist for the same ClientId 
    Created By   : Kathiravan        
    Created Date : 29 may 2013        
    Impact to    :ClientCreation.aspx        
 */          
Insert into ADM_ServiceGroupLog(ServiceId,ServiceGroupId,CreatedBy,CreatedDt,ClientId)          
Select ServiceId,ServiceGroupId,CreatedBy,CreatedDt,ClientId from ADM_ServiceGroup where ClientId = @ClientId    
Delete From  ADM_ServiceGroup where ClientId = @ClientId    
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ServiceGroupLogMove] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ServiceGroupLogMove] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ServiceGroupLogMove] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ServiceGroupLogMove] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ServiceGroupLogMove] TO [DB_DMLSupport]
    AS [dbo];

