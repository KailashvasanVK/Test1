﻿CREATE Procedure ADM_LoadWIPSetupDetails
@CustomerId int
,@SearchStr varchar(100) = ''  
,@SearchPattern varchar(4) = '%' /** = or % **/
as
begin
 /* ADM_LoadWIPSetupDetails  94,'','%'*/
 declare @qry varchar(max)
  set @qry='select wi.WipName,ser.ServiceName,cli.ClientAcmName into #WipList from ADM_Wipsetup  wi 
 inner join ADM_Service ser on ser.ServiceId = wi.ServiceId
 inner join ADM_Client cli on cli.ClientId = wi.ClientId 
 where wi.Active=1 and wi.CustomerId='+CONVERT(varchar,@CustomerId)+'
 
	Exec FilterTable
	@DbName = ''tempdb''  
	,@TblName = ''#WipList''  
	,@SearchStr = '''+@SearchStr+'''  
	,@SearchPattern = '''+@SearchPattern+'''
	,@OrderStr = '''' 
 
 ' 
 exec(@qry)
end



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_LoadWIPSetupDetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_LoadWIPSetupDetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_LoadWIPSetupDetails] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_LoadWIPSetupDetails] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_LoadWIPSetupDetails] TO [DB_DMLSupport]
    AS [dbo];

