﻿CREATE Procedure [dbo].[ADM_MaxNoGet]
(
@TableName varchar(75)
,@ColName varchar(50)
)
as
begin
/*
Purpose			: Getting max no for requesting table and column
Created By		: Safiyullah
Created Date	: 9 Apr 2013
Impact to		: 
*/

declare @qry varchar(500)
set @qry = ' select isnull(MAX('+ @ColName+ '),0)+1 from ' + @TableName
exec(@qry)
end


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_MaxNoGet] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_MaxNoGet] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_MaxNoGet] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_MaxNoGet] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_MaxNoGet] TO [DB_DMLSupport]
    AS [dbo];

