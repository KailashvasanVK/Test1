﻿CREATE Procedure CUR_kMWest_BatchImportAncillaryService
As
Begin
/*
Author : Mohamed Safiyullah
Purpose : Auto batch creation for ancillary service
*/
	Declare @DownloadDate as Date = getdate()
	if DATENAME(WEEKDAY,@DownloadDate) <> 'Saturday' and DATENAME(WEEKDAY,@DownloadDate) <> 'Sunday' 
	Begin
	Select * into #tmpBatchesAns from 
	(
		Select DATEADD(D,-1,@DownloadDate)as ScanDate
		,ClientName + '-AS-' + Substring(Convert(varchar,@DownloadDate,101),4,2) + '-' + Substring(Convert(varchar,@DownloadDate,101),1,2) + '-' + Substring(Convert(varchar,@DownloadDate,101),7,4)  as Batchno
		,ClientId,286 As ServiceId,2 BatchType,1777 as CreatedBy,Convert(datetime,CONVERT(varchar,@DownloadDate) + ' 09:00:00') as CreatedDt,0 Priority
		,10 PgCount,'' FName,1 Status,2 Qtype,GETDATE() CreatedOn
		from 
		(
		Select SG.ClientId,Case when Cli.ClientAcmName = 'NS1/CSP' then 'NS1' else Cli.ClientAcmName end ClientName from ADM_ServiceGroup as SG
		inner join ADM_Client as Cli on Cli.ClientId = SG.ClientId and Cli.CustomerId = 5 
		Where SG.ServiceGroupId = 286
		Group by SG.ClientId ,Cli.ClientAcmName
		)x
	)tempBat
	Where not exists (Select 1 from TRN_kMWEST_tBatches Where Batchno = tempBat.Batchno)
	
	Insert into TRN_kMWEST_tBatches(ScanDate,BatchNo,ClientId,ServiceId,BatchType,CreatedBy,CreatedDt,Priority,PgCount,FName,status,QType,CreatedOn)
	Select ScanDate,BatchNo,ClientId,ServiceId,BatchType,CreatedBy,CreatedDt,Priority,PgCount,FName,status,QType,CreatedOn 
	from #tmpBatchesAns
	
	insert into TRN_kMWEST_tBatchQueue(BatchId,BatchNo,PageFrom,PageTo,Assigned,ClientId,ServiceId,StatusId,Comment,CreatedBy,CreatedDt,QType)
	select bat.BatchId,bat.BatchNo,1,bat.PgCount,0,bat.ClientId,bat.ServiceId,0,'',bat.CreatedBy,bat.CreatedDt,bat.QType 
	from TRN_kMWEST_tbatches as bat
	inner join #tmpBatchesAns tmp on tmp.Batchno= bat.BatchNo 	
	where bat.ServiceId = 286  and bat.CreatedBy=1777--and CONVERT(date,bat.ScanDate)= DATEADD(D,-1,@DownloadDate)

	insert into TRN_kMWEST_tBatchFlow
	(BatchId,BatchProcessId,CreatedDt,CreatedBy,StatusId,Comments,Ref_FlowId)
	select que.BatchId,que.BatchProcessId,que.CreatedDt,que.CreatedBy,0,'',0 
	from TRN_kMWEST_tbatches bat
	inner join TRN_kMWEST_tBatchQueue que on bat.BatchId =  que.BatchId 
	inner join #tmpBatchesAns tmp on tmp.Batchno = bat.BatchNo 
	where  bat.ServiceId =286 and bat.CreatedBy=1777 -- CONVERT(date,bat.ScanDate)=DATEADD(D,-1,@DownloadDate) 

	Update TRN_kMWEST_tBatchQueue set FlowId = (Select MAX(flowid) from TRN_kMWEST_tBatchFlow Where BatchProcessId = que.BatchProcessId)
	from TRN_kMWEST_tBatchQueue  as Que
	inner join TRN_kMWEST_tBatches  bat on bat.BatchId =que.BatchId and bat.ServiceId =286 --and CONVERT(date,bat.ScanDate)=DATEADD(D,-1,@DownloadDate)
	inner join #tmpBatchesAns tmp on tmp.Batchno = bat.BatchNo 
	and  bat.CreatedBy=1777
	End
End





GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUR_kMWest_BatchImportAncillaryService] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUR_kMWest_BatchImportAncillaryService] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUR_kMWest_BatchImportAncillaryService] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUR_kMWest_BatchImportAncillaryService] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUR_kMWest_BatchImportAncillaryService] TO [DB_DMLSupport]
    AS [dbo];

