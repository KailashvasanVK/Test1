﻿
CREATE PROCEDURE pIndexing_GetCount              
@userinfo varchar(50)   
As        
Begin    
  
Declare @UserCnt int=0              
Declare @PendingCnt int=0         
       
Select @UserCnt = COUNT(id) from batchIndex_TrackBatches (nolock)  Where userinfo = @userinfo and  Convert(Date, CompletedDate, 101) = Convert(Date, GETDATE(), 101)   
           
Select @PendingCnt=Count(BatchId) from TRN_kOFF_tBatches (nolock) Where status=3 and ServiceId<>363              
              
SELECT @UserCnt as UserCount,@PendingCnt as Pending     
    
End  
  
  

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[pIndexing_GetCount] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexing_GetCount] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexing_GetCount] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[pIndexing_GetCount] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexing_GetCount] TO [DB_DMLSupport]
    AS [dbo];

