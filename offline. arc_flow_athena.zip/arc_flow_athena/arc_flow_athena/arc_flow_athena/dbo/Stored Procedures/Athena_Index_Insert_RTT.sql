﻿CREATE Proc  Athena_Index_Insert_RTT(@batchno varchar(20),@NPI varchar(30),@TaxID varchar(30),@Payeeno varchar(30),@DollarAmt money)            
as            
/*This SP willl Update the batch for indexing the batch for TaxID,NPI,Dollaramt and Payeeno*/            
/*Created by Noor at Sep 04,2014*/            
            
If exists(Select Batchid from trn_koff_tbatches where uploaddt  is null and serviceid=363 and status=3 and batchno=@batchno)            
            
Begin             
            
      Update arc_athena..BatchMaster set Dollaramt=@Dollaramt,NPIID=ltrim(rtrim(@NPI)),TaxID=ltrim(rtrim(@TaxID)),PAYEENUMBER=ltrim(rtrim(@Payeeno)) Where Batchnum=@Batchno            
      Update trn_koff_tbatches set Status=1 where Batchno=@batchno and Status=3          
      Update batchIndex_TrackBatches_RT set cstatus=1,CompletedDate=GETDATE() where batchnum=@batchno           
            
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_Insert_RTT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_Insert_RTT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_Insert_RTT] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_Insert_RTT] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_Insert_RTT] TO [DB_DMLSupport]
    AS [dbo];

