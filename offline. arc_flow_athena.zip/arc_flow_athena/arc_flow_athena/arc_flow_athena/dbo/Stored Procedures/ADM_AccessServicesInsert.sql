﻿CREATE Procedure [dbo].[ADM_AccessServicesInsert]   
@UserId int ,   
@CustomerId int,   
@ServiceId int,   
@processTarget int,      
@QcTarget int,      
@QaTarget int,      
@CreatedBy  int    
As   
/*   
Created by : Karthik Ic   
Created on : 20 May 2013   
Impact to  : ProfileSetup.aspx   
Purpose    : To save the user customer wise service details.   
*/  
Begin  
Insert into ADM_AccessServices(UserId,CustomerId,ServiceId,CreatedBy)  
Select @UserId,@CustomerId,@ServiceId,@CreatedBy  
  
--if(select COUNT(*) from ADM_AccessFunctionality where UserId = @UserId and Functionality = 'P') > 0  
--begin  
 if not exists(Select  top 1 'x' from ADM_AccessTarget where Userid = @UserId and ServiceId = @ServiceId and CustomerId = @CustomerId )  
 Begin  
 insert into ADM_AccessTarget(Userid,CustomerId,ServiceId,ProcessTargetId,QcTargetId,CreatedBy,CreatedDt)  
 Select @UserId,@CustomerId,@ServiceId,@processTarget,@QcTarget,@CreatedBy,GETDATE()  
 End          
--end    
  
--if(select COUNT(*) from ADM_AccessFunctionality where UserId = @UserId and Functionality = 'A') > 0    
--begin    
  
  if not exists(Select  top 1 'x' from ADM_AccessTargetQC where Userid = @UserId and ServiceId = @ServiceId and CustomerId = @CustomerId  )   
 Begin   
 insert into ADM_AccessTargetQC(Userid,CustomerId,ServiceId,QualityTargetId,CreatedBy ,CreatedDt)          
 Select @UserId,@CustomerId,@ServiceId,@QaTarget,@CreatedBy,GETDATE()   
 End  
--End
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_AccessServicesInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessServicesInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessServicesInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_AccessServicesInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessServicesInsert] TO [DB_DMLSupport]
    AS [dbo];

