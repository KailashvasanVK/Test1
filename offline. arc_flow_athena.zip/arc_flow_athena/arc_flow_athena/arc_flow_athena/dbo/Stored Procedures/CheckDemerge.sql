﻿--arc_flow_athena..CheckDemerge 'M10019A6762'
CREATE Proc  CheckDemerge(@Parentbatch varchar(20))
as
--select * from arc_flow_athena..trn_koff_tbatchs where status=20
select * from arc_athena..paymentdetailmaster where batchnum in (select childbatchno from mergebatchdetails where
parentbatchno =@Parentbatch)
select * from arc_athena..batchexception where batchnum in (select childbatchno  from  mergebatchdetails where
parentbatchno =@Parentbatch)
select * from arc_athena..patientpostingmaster where batchnum in (select childbatchno  from  mergebatchdetails where
parentbatchno =@Parentbatch)

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CheckDemerge] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CheckDemerge] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CheckDemerge] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CheckDemerge] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CheckDemerge] TO [DB_DMLSupport]
    AS [dbo];

