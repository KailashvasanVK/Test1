﻿Create Proc Athena_Index_BackUp                                         
@userinfo varchar(50)                                     
as                                          
/*This SP willl pick the batch for indexing the batch for TaxID,NPI,Dollaramt and Payeeno*/                                          
/*Create By Ramakrishnang. Aug 7th 2014,Modified by Noor Oct 23,2014                                
to assign multiple user*/                                          
                                          
Declare @Batchno varchar(20),@rowcnt int                                          
                    
GetBatch:                                       
        
SELECT @Batchno=batchnum from batchIndex_TrackBatches  a inner join trn_koff_tbatches  b on a.batchnum=b.BatchNo where userinfo=@userinfo and cstatus=0  and b.status=3                                        
                                    
if(@Batchno is not null)                                    
begin                                    
      SELECT @Batchno as BatchNo                                    
      return                                    
End                                    
ELSE                                    
BEGIN                                    
                                          
select Top 1 @Batchno=Batchno from trn_koff_tbatches  
where uploaddt  is null and serviceid<>363 and status=3  and BatchNo not  in(    
select batchnum from   batchIndex_TrackBatches  where CompletedDate is null )                                      
order by ScanDate asc, PgCount  desc                                     
                             
if(@Batchno is not null)                                    
begin                                        
--insert into batchIndex_TrackBatches (batchnum,userinfo,cstatus)values(@Batchno,@userinfo,0)                                        
                        
Insert into batchIndex_TrackBatches (batchnum,userinfo,cstatus)                        
SELECT @Batchno,@userinfo,0 WHERE NOT EXISTS(SELECT 1 FROM batchIndex_TrackBatches where batchnum=@Batchno)                      
      
SELECT @rowcnt=@@ROWCOUNT        
                    
IF(@rowcnt=0)        
Begin                    
GOTO GetBatch                       
End      
                        
End                                        
SELECT @Batchno as BatchNo                                    
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_BackUp] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_BackUp] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_BackUp] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_BackUp] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_BackUp] TO [DB_DMLSupport]
    AS [dbo];

