﻿CREATE proc DBD_TV_GENERATE_TP_FORECASTVOLUME_ACHIEVED
as
begin

Declare @fromdate date=convert(date,DATEADD(mm, DATEDIFF(mm, 0, getdate()), 0))
       ,@todate date= convert(date,getdate())
       ,@sql varchar(max)

declare @customerid int=15,@tempCmpKey varchar(10)='OFF'

if OBJECT_ID('tempdb..#tblPrd') is not null drop table #tblPrd  
Create Table #tblPrd(CustomerId int,Lobid int, FunctionalityId int,Serviceid int,FromDate date, ToDate date,TransCount int)
Set @sql='
insert into #tblPrd(CustomerID,FunctionalityId,LobId,ServiceID,FromDate,TransCount)
Select   '+convert(varchar,@customerid)+' as CustomerID,
usr.functionality_id as FunctionalityId,
lob.id as lobid,
ser.ServiceId as ServiceId
,convert(date,DATEADD(mm, DATEDIFF(mm, 0, trn.CreatedDt), 0)) as MonthStartDate
, Sum(TransValue) as TransCount 
from arc_flow_athena..TRN_k'+@tempCmpKey+'_tBatchTransact trn
inner join arc_flow_athena..TRN_k'+@tempCmpKey+'_tBatches bat on bat.BatchId=trn.BatchId and bat.status=1
inner join arc_flow_athena..ADM_Service ser on ser.ServiceId=trn.ServiceId and ser.FieldType=''T''
inner join arc_rec_athena..ARC_REC_USER_INFO usr on trn.CreatedBy=usr.USERID
inner join arc_rec..ARC_REC_USER_INFO usri on usri.nt_username=usr.nt_username
left join  arc_rec..arc_rec_lob_info lob on usri.LOB=lob.ID
where  CONVERT(date,trn.CreatedDt) between '''+Convert(varchar,@fromdate)+''' and '''+Convert(varchar,@todate)+'''
group by lob.id,ser.ServiceId,usr.functionality_id,DATEADD(mm, DATEDIFF(mm, 0, trn.CreatedDt), 0)
order by DATEADD(mm, DATEDIFF(mm, 0, trn.CreatedDt), 0) 

update #tblPrd set ToDate=DATEADD (dd, -1, DATEADD(mm, DATEDIFF(mm, 0, FromDate) + 1, 0))

'
exec(@sql)

select b.CustomerId, b.Lobid, b.Serviceid, b.FromDate, b.ToDate, 0, b.TransCount, 1, 0, getdate(), 'Offline',  b.FunctionalityId
from #tblPrd b Left join DBD_TV_VOLUMEFORECAST a on  a.customerid=b.CustomerId 
and a.lobid=b.Lobid 
and a.functionalityid=b.FunctionalityId
and ISNULL(a.servicegroupid,0)=ISNULL(b.Serviceid,0)
and a.fromdate=b.FromDate and a.todate=b.ToDate
where a.CustomerID is null

/*

select * from #tblPrd where lobid=2 order by customerid 
select * from DBD_TV_VOLUMEFORECAST  where lobid=2 order by customerid 

*/

update a set achieved=b.TransCount from DBD_TV_VOLUMEFORECAST  a join
#tblPrd b on a.customerid=b.CustomerId 
and a.lobid=b.Lobid 
and a.functionalityid=b.FunctionalityId
and ISNULL(a.servicegroupid,0)=ISNULL(b.Serviceid,0)
and a.fromdate=b.FromDate and a.todate=b.ToDate

insert into DBD_TV_VOLUMEFORECAST (CustomerID, LOBID, ServiceGroupID, FromDate, ToDate, ForeCast, Achieved, Active, createdby, createddt, applicationtype, FunctionalityId)
select b.CustomerId, b.Lobid, b.Serviceid, b.FromDate, b.ToDate, 0, b.TransCount, 1, 0, getdate(), 'Offline',  b.FunctionalityId
from #tblPrd b Left join DBD_TV_VOLUMEFORECAST a on  a.customerid=b.CustomerId 
and a.lobid=b.Lobid 
and a.functionalityid=b.FunctionalityId
and ISNULL(a.servicegroupid,0)=ISNULL(b.Serviceid,0)
and a.fromdate=b.FromDate and a.todate=b.ToDate
where a.CustomerID is null

end


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[DBD_TV_GENERATE_TP_FORECASTVOLUME_ACHIEVED] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[DBD_TV_GENERATE_TP_FORECASTVOLUME_ACHIEVED] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[DBD_TV_GENERATE_TP_FORECASTVOLUME_ACHIEVED] TO [DB_DMLSupport]
    AS [dbo];

