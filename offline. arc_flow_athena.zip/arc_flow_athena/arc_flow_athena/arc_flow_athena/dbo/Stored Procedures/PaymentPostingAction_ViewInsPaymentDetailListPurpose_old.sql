﻿CREATE  Proc [dbo].[PaymentPostingAction_ViewInsPaymentDetailListPurpose_old]                                          
@BatchNum varchar(30)=NULL,@Status int=NULL                                          
as                                          
Begin                                           
                             
Select                               
clm.InvoiceID as InvoiceId,                              
clm.PatientLastName as LastName,                              
clm.PatientFirstName as FirstName,                              
clm.PatientMiddleName as MiddleName,                                                      
pymnt.MemberIdPymnt as MemberId,                               
clms.FromDOS as FromDOS,                              
clms.ToDOS as ToDOS,                              
clms.ProcedureCode as ProcCode,                              
clms.Modifier1 as Modifier1,                               
clms.Modifier2 as Modifier2,                              
clms.Modifier3 as Modifier3,                               
convert(varchar,clms.AmountBilled) as AmountBilled,                              
clms.UnitsBilled,                              
checkNo as CheckNo,                              
convert(varchar,pymnt.CheckAmt) as CheckAmt,                              
pymnt.CheckDate,                              
pymnt.insPackageID,                              
insms.InsPackageName,              
insms.InsRollupID,                                                                                                  
case insms.InsRollupID when 0 then 'Non-ListedInsurane' else 'Listed Insurance' end as Insurance,                                    
--clms.AmountBilled,                              
convert(decimal(9,2),insrespamt) as insrespamt,                               
case pymnt.pymtAmt when 0.00 then '' else CONVERT(varchar,pymnt.pymtAmt) end as PaymentAmnt ,                                                                                             
case coPayTrAmt when 0.00 then '' else CONVERT(varchar,coPayTrAmt) end as copayTrAmt,                                                                                                                            
case coInsTrAmt when 0.00 then '' else CONVERT(varchar,coInsTrAmt) end as coInsTrAmt ,                                                                                                                            
case dedTrAmt when 0.00 then '' else CONVERT(varchar,dedTrAmt) end as dedTrAmt,                                                                                                                            
case contrAdjAmt when 0.00 then '' else CONVERT(varchar,contrAdjAmt) end as contrAdjAmt,                                     
-convert(decimal(9,2),((pymtAmt + coPayTrAmt+coInsTrAmt +dedTrAmt +otherTrAmt +globalTrAmt +contrAdjAmt +capitationAmt +managedCareAmt +otherAdjAmt)                            
-amountbilled)) as 'Balance',                                     
                                                            
remiReCode as remitcode,                              
pymnt.pageNo,                              
clm.ICN as ICN,                                                                                                                            
case otherTrAmt when 0.00 then '' else CONVERT(varchar,otherTrAmt) end as otherTrAmt,                                                                                                                            
case InterestAmt when 0.00 then '' else CONVERT(varchar,InterestAmt) end as InterestAmt,                                                                                                                            
case globalTrAmt when 0.00 then '' else CONVERT(varchar,globalTrAmt) end as globalTrAmt,                                           
case capitationAmt when 0.00 then '' else CONVERT(varchar,capitationAmt) end as capitationAmt,                                                                                                                            
case managedCareAmt when 0.00 then '' else CONVERT(varchar,managedCareAmt) end as managedCareAmt,                                                                            
case otherAdjAmt when 0.00 then '' else CONVERT(varchar,otherAdjAmt) end as otherAdjAmt,                                                                                       
clm.PatientID as PatientId,  isnull(cop.Crossoverinsurance,'') Crossoverinsurance,                             
--clms.InsRespAmt,                              
clm.claimid as ClaimId,                              
clms.ChargeID as ChargeId,                              
pymnt.Id as ID,                              
DOB,pymnt.TypeOfInsurance,            
case clms.Status when 0 then 'Sent By Client' when 1 then 'New Patient' when 2 then 'Insurance Added' when 3 then 'Added CPT' end as AddedStatus                          
from PaymentDetailMaster (nolock) pymnt                             
inner join ClaimServiceDetailMaster (nolock) clms on pymnt.chargeID=clms.ChargeID                                                                                                     
inner join ClaimDetailMaster (nolock) clm  on clms.ClaimID=clm.ClaimID                               
inner join InsurancePackageMaster (nolock) insms  on pymnt.insPackageID=insms.InsPackageID          
left join CrossOverPayer (nolock) cop on cop.ClaimID=clm.ClaimID   and cop.batchnum =pymnt.batchnum                                                                                   
where pymnt.batchnum=@batchnum  
and  clm.status=(case when @status is null then clm.status else @status end)                                                                   
order by pymnt.pageno,pymnt.Id                                         
                                       
End         


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[PaymentPostingAction_ViewInsPaymentDetailListPurpose_old] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[PaymentPostingAction_ViewInsPaymentDetailListPurpose_old] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[PaymentPostingAction_ViewInsPaymentDetailListPurpose_old] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[PaymentPostingAction_ViewInsPaymentDetailListPurpose_old] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[PaymentPostingAction_ViewInsPaymentDetailListPurpose_old] TO [DB_DMLSupport]
    AS [dbo];

