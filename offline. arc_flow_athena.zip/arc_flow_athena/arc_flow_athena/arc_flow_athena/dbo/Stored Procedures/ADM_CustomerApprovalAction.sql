﻿CREATE Procedure ADM_CustomerApprovalAction
@SearchStr varchar(100) = '',  
@SearchPattern varchar(4) = '=' /** = or % **/   
As
Begin
declare @Qry varchar(max)
	if OBJECT_ID('tempdb..#CustomerApproval') is not null drop table #CustomerApproval
	Create table #CustomerApproval(FullName	varchar(100),	InternalName	varchar(50)
	,CreatedBy	varchar(50),CreatedDt	varchar(25),Action varchar(max))
	set @Qry  = '
	Insert into #CustomerApproval (FullName,InternalName,CreatedBy,CreatedDt,Action)
	Select	ADMC.FullName,ADMC.InternalName,ARUI.NT_USERNAME 
	,convert( varchar(21),ADMC.CreatedDt,101) as CreatedDt,''' +
	'<div><div style="float: left;padding-top:6px;" title ="Click here to View ''+' + ' ADMC.FullName ' + '+'' details">
        <a id="Edit" onclick="OpenApprovalDialog('' +' + 'cast(ADMC.CustomerId as varchar ' + ')+''  );">
       <span  class="ui-icon ui-icon-pencil IconBackGround" ></span></a></div><div style="float: left;">&nbsp;</div></div>''' + ' as Action
	from ARC_FLOW_Athena..ADM_Customer ADMC
	inner join ARC_REC_Athena..ARC_REC_USER_INFO ARUI on ARUI.USERID =ADMC.CreatedBy
	Where ADMC.AprStatus in(2,3)'
	set @Qry   += 'order by CustomerId' 
	print(@Qry )
	exec (@Qry )

	Exec FilterTable  
	@DbName = 'tempdb'  
	,@TblName = '#CustomerApproval'  
	,@SearchStr = @SearchStr  
	,@SearchPattern = @SearchPattern  
	,@OrderStr = ''
	if OBJECT_ID('tempdb..#CustomerApproval') is not null drop table #CustomerApproval   
end


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_CustomerApprovalAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_CustomerApprovalAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_CustomerApprovalAction] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_CustomerApprovalAction] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_CustomerApprovalAction] TO [DB_DMLSupport]
    AS [dbo];

