﻿
CREATE Procedure iEOB_pConsolidatedReport  
(  
@FromDate varchar(50) = NULL,  
@ToDate varchar(50) = NULL,  
@PayerName varchar(100) = NULL   
)  
As  
/*                  
Created By     : Gobinath.M                              
Created Date   : 2018-09-03  
Purpose        : To show the Payer wise OverAll Report  
Ticket/SCR ID  :                
TL Verified By : Ramakrishnan.G                
                
Implemented On :    
Implemented On :   
Reviewed by    :    
Reviewed On    :         
*/                 
Begin  
  
/*iEOB Payers for All ServiceID*/        
IF OBJECT_ID('Tempdb..#BatchList') is not null drop table #BatchList        
Select Convert(Date,UploadDate) AS UploadDate, tb.BatchNo, tb.ServiceID, pm.PayerName, tb.ScanDate, tb.PgCount        
into  #BatchList        
From ARC_Flow_Athena..TRN_koff_tBatches(nolock) tb  
inner join batchMaster (nolock) b on b.batchnum=tb.Batchno   
inner join Arc_flow_Athena..adm_payerName(nolock) d on d.payerid=tb.payerid  
Inner join ARC_Athena..iEOB_tPayerAllocation (nolock) pm on pm.PayerID = d.PayerID  
inner join Arc_Flow_athena..adm_service(nolock) ser on ser.serviceid =tb.serviceid  
where Convert(Date,UploadDate) between Convert(date,@fromdate)  and  Convert(Date,@Todate)  
and ULStatus =1  
  
/*All Payers and All ServiceID*/   
IF OBJECT_ID('Tempdb..#OverAllBatchList') is not null drop table #OverAllBatchList        
Select Convert(Date,UploadDate) AS UploadDate, tb.BatchNo, tb.ServiceID, d.PayerName, tb.ScanDate, tb.PgCount        
into  #OverAllBatchList        
From ARC_Flow_Athena..TRN_koff_tBatches(nolock) tb  
inner join batchMaster (nolock) b on b.batchnum=tb.Batchno   
inner join Arc_flow_Athena..adm_payerName(nolock) d on d.payerid=tb.payerid   
inner join Arc_Flow_athena..adm_service(nolock) ser on ser.serviceid =tb.serviceid  
where Convert(Date,UploadDate) between Convert(date,@fromdate)  and  Convert(Date,@Todate)  
and ULStatus = 1  
   
/*Over ALl ADP Contribution*/        
IF OBJECT_ID('Tempdb..#OverAlltemp') is not null drop table #OverAlltemp                
Select tb.BatchNo, SUM(CreatedPtnCnt) + SUM(PaymentInsCnt) + SUM(ExceptionCnt) + SUM(PtnPostingCnt) + SUM(ColPostingCnt) As Payment into #OverAlltemp    
from  #OverAllBatchList tb  
Inner join ARC_Athena..BatchLogInformation(nolock) bLog on bLog.BatchNum = tb.BatchNo  
where tb.ServiceID in (418)  
Group by tb.BatchNo  
   
/*Over ALl Volume Contribution without iEOB and ADP*/        
IF OBJECT_ID('Tempdb..#OverAlltempVolume') is not null drop table #OverAlltempVolume                
Select tb.BatchNo, SUM(CreatedPtnCnt) + SUM(PaymentInsCnt) + SUM(ExceptionCnt) + SUM(PtnPostingCnt) + SUM(ColPostingCnt) As Payment into #OverAlltempVolume    
from #OverAllBatchList tb        
Inner join ARC_Athena..BatchLogInformation(nolock) bLog on bLog.BatchNum = tb.BatchNo        
Where tb.ServiceID not in (418, 452)        
Group by tb.BatchNo   
    
/*ADP Contribution*/        
IF OBJECT_ID('Tempdb..#temp') is not null drop table #temp                
Select tb.BatchNo, SUM(CreatedPtnCnt) + SUM(PaymentInsCnt) + SUM(ExceptionCnt) + SUM(PtnPostingCnt) + SUM(ColPostingCnt) As Payment into #temp        
from #BatchList tb        
Inner join ARC_Athena..BatchLogInformation(nolock) bLog on bLog.BatchNum = tb.BatchNo        
Where tb.ServiceID in (418)        
Group by tb.BatchNo  
        
IF OBJECT_ID('Tempdb..#temp1') is not null drop table #temp1              
Select distinct a.BatchNo, SUM(a.Payment) As Payment into #temp1        
from (        
Select Distinct a.Batchnum  As BatchNo, COUNT(id) As Payment        
from ARC_Athena..PaymentDetailMaster(nolock) a        
Inner join #temp t on t.BatchNo = a.BatchNum  Where a.OCRStatus = 0          
group by a.Batchnum        
Union All        
Select b.BatchNum, CASE WHEN b.Total >= 0 THEN Total ELSE 0 END AS Payment from (  
Select Total = SUM(a.B) - SUM(a.T), a.BatchNum From (  
Select COUNT(ID) AS T, 0 As B, BatchNum from ARC_Athena..BatchException_ocr(nolock) o  
Inner join #temp t on t.BatchNo = o.BatchNum Group by BatchNum UNION ALL  
Select 0 As T, COUNT(ID) As B, BatchNum from ARC_Athena..BatchException(nolock) b  
Inner join #temp t on t.BatchNo = b.BatchNum Group by BatchNum)a group by a.BatchNum) b  
Union All        
Select Distinct pymnt.Batchnum As BatchNo, COUNT(distinct(clm.ClaimID)) As Payment        
from ARC_Athena..PaymentDetailMaster(nolock) pymnt        
inner join ARC_Athena..ClaimServiceDetailMaster(nolock) csd on pymnt.chargeID=csd.ChargeID                            
inner join ARC_Athena..ClaimDetailMaster(nolock) clm on csd.ClaimID =clm.ClaimID        
Inner join #temp t on t.BatchNo = pymnt.BatchNum        
Where clm.Status=1 and pymnt.OCRStatus = 0        
group by pymnt.Batchnum        
)a Group by a.BatchNo        
        
/*iEOB Contribution*/        
IF OBJECT_ID('Tempdb..#iEOBtemp') is not null drop table #iEOBtemp                
Select  tb.BatchNo, SUM(CreatedPtnCnt) + SUM(PaymentInsCnt) + SUM(ExceptionCnt) + SUM(PtnPostingCnt) + SUM(ColPostingCnt) As Payment  into #iEOBtemp        
from #BatchList tb        
Inner join ARC_Athena..BatchLogInformation(nolock) bLog on bLog.BatchNum = tb.BatchNo        
Where tb.ServiceID in (452, 453)          
Group by tb.BatchNo  
         
IF OBJECT_ID('Tempdb..#iEOBtemp1') is not null drop table #iEOBtemp1              
Select distinct a.BatchNo, SUM(a.Payment) As Payment into #iEOBtemp1        
from (        
Select Distinct a.Batchnum  As BatchNo, COUNT(id) As Payment        
from ARC_Athena..PaymentDetailMaster(nolock) a        
Inner join #iEOBtemp t on t.BatchNo = a.BatchNum Where a.OCRStatus = 0           
group by a.Batchnum        
Union All        
Select b.BatchNum, CASE WHEN b.Total >= 0 THEN Total ELSE 0 END AS Payment from (        
Select Total = SUM(a.B) - SUM(a.T), a.BatchNum From (        
Select COUNT(ID) AS T, 0 As B, BatchNum from ARC_Athena..BatchException_ocr(nolock) o      
Inner join #iEOBtemp t on t.BatchNo = o.BatchNum Group by BatchNum UNION ALL         
Select 0 As T, COUNT(ID) As B, BatchNum from ARC_Athena..BatchException(nolock) b        
Inner join #iEOBtemp t on t.BatchNo = b.BatchNum Group by BatchNum)a group by a.BatchNum) b        
Union All        
Select Distinct pymnt.Batchnum As BatchNo, COUNT(distinct(clm.ClaimID)) As Payment        
from ARC_Athena..PaymentDetailMaster(nolock) pymnt        
inner join ARC_Athena..ClaimServiceDetailMaster(nolock) csd on pymnt.chargeID=csd.ChargeID                            
inner join ARC_Athena..ClaimDetailMaster(nolock) clm on csd.ClaimID =clm.ClaimID        
Inner join #iEOBtemp t on t.BatchNo = pymnt.BatchNum        
Where clm.Status=1 and pymnt.OCRStatus = 0        
group by pymnt.Batchnum        
)a Group by a.BatchNo   
   
   
 IF OBJECT_ID('Tempdb..#Final') is not null drop table #Final   
SELECT RANK() OVER (ORDER BY BatchNo Asc) AS Ranking, z.UploadDate, z.BatchNo, z.ServiceID, z.ScanDate,  z.PayerName, SUM(OverAllADPContribution)  As OverAllADPContribution, SUM(OverAllManualContribution) As OverAllManualContribution,   
SUM(TotalContribution) AS TotalContribution, SUM(ManualContribution) As ManualContribution,  
SUM(ADPContribution) As ADPContribution, SUM(ADPManualContribution) As ADPManualContribution,   
SUM(iEOBContribution) As iEOBContribution, SUM(iEOBManualContribution) As iEOBManualContribution,  
SUM([<6 Trans]) AS '<6 Trans', SUM([>=6 Trans]) As '>=6 Trans' into #Final  
FROM (    
      
Select e.UploadDate, e.BatchNo, e.ServiceID,  e.ScanDate, e.PayerName,  SUM(TotalContribution) As TotalContribution, SUM(ManualContribution) As ManualContribution,  
SUM(ADPContribution) As ADPContribution,  SUM(ADPManualContribution) As ADPManualContribution, 0 As OverAllADPContribution, 0 As OverAllManualContribution,        
SUM(iEOBContribution) As iEOBContribution, SUM(iEOBManualContribution) As iEOBManualContribution,  
SUM([<6 Trans]) AS '<6 Trans', SUM([>=6 Trans]) As '>=6 Trans'  
From (  
  
/*Scan Date wise*/      
SELECT c.UploadDate, c.BatchNo, c.ServiceID, CONVERT(varchar(15), c.ScanDate) As ScanDate, c.PayerName, SUM(TotalContribution) As TotalContribution, SUM(ManualContribution) As ManualContribution, SUM(ADPContribution) As ADPContribution,    
SUM(ADPManualContribution) As ADPManualContribution, 0 As OverAllADPContribution, 0 As OverAllManualContribution,       
SUM(iEOBContribution) As iEOBContribution, SUM(iEOBManualContribution) As iEOBManualContribution,   
'<6 Trans' = SUM(ManualContribution) + SUM(iEOBContribution) + SUM(ADPContribution) + SUM(iEOBManualContribution) + SUM(ADPManualContribution), 0 As '>=6 Trans'   
from (   
       
/*Total Contribution*/      
Select tb.BatchNo, SUM(CreatedPtnCnt) + SUM(PaymentInsCnt) + SUM(ExceptionCnt) + SUM(PtnPostingCnt) +  SUM(ColPostingCnt) As TotalContribution,        
0 As ManualContribution, 0 As ADPContribution, 0 As ADPManualContribution, 0 As OverAllADPContribution, 0 As OverAllManualContribution,  
0 As iEOBContribution, 0 As iEOBManualContribution from #BatchList tb        
Inner join ARC_Athena..BatchLogInformation(nolock) bLog on bLog.BatchNum = tb.BatchNo          
Group by tb.BatchNo   
UNION ALL  
/*ManualContribution*/   
Select tb.BatchNo, 0 As TotalContribution, ManualContribution = SUM(CreatedPtnCnt) + SUM(PaymentInsCnt) + SUM(ExceptionCnt) + SUM(PtnPostingCnt) +  SUM(ColPostingCnt),        
0 As ADPContribution, 0 As ADPManualContribution, 0 As OverAllADPContribution, 0 As OverAllManualContribution,  
0 As iEOBContribution, 0 As iEOBManualContribution from #BatchList tb        
Inner join ARC_Athena..BatchLogInformation(nolock) bLog on bLog.BatchNum = tb.BatchNo Where tb.ServiceID not in (418, 452)          
Group by tb.BatchNo  
UNION ALL    
/*ADP Contribution*/        
Select t.BatchNo, 0 As TotalContribution, 0 As ManualContribution, ADPContribution = SUM(t.Payment) -  SUM(t1.Payment), 0 As ADPManualContribution,    
0 As OverAllADPContribution, 0 As OverAllManualContribution,  
0 As iEOBContribution, 0 As iEOBManualContribution from #temp t        
Inner join #temp1 t1 on t1.BatchNo = t.BatchNo Group by t.BatchNo  
UNION ALL  
Select  BatchNo, 0 As TotalContribution, 0 As ManualContribution, ADPContribution = Payment, 0 As ADPManualContribution,   
0 As OverAllADPContribution, 0 As OverAllManualContribution,  
0 As iEOBContribution, 0 As iEOBManualContribution from #temp Where BatchNo not in (Select BatchNo from #temp1)  
UNION ALL    
/*ADP Manual Contribution*/  
Select BatchNo, 0 As TotalContribution, 0 As ManualContribution, 0 As ADPContribution, ADPManualContribution = Payment,   
0 As OverAllADPContribution, 0 As OverAllManualContribution,  
0 As iEOBContribution, 0 As iEOBManualContribution from #temp1  
UNION ALL   
/*iEOB Contribution*/         
Select t.BatchNo, 0 As TotalContribution, 0 As ManualContribution, 0 As ADPContribution, 0 As ADPManualContribution,   
0 As OverAllADPContribution, 0 As OverAllManualContribution,  
iEOBContribution = SUM(t.Payment) -  SUM(t1.Payment), 0 As iEOBManualContribution from #iEOBtemp t        
Inner join #iEOBtemp1 t1 on t1.BatchNo = t.BatchNo Group by t.BatchNo        
UNION ALL        
Select  BatchNo, 0 As TotalContribution, 0 As ManualContribution, 0 As ADPContribution, 0 As ADPManualContribution,    
0 As OverAllADPContribution, 0 As OverAllManualContribution,  
iEOBContribution = Payment, 0 As iEOBManualContribution from #iEOBtemp Where BatchNo not in (Select BatchNo from #iEOBtemp1)  
UNION ALL  
/*iEOB Manual Contribution*/  
Select  BatchNo, 0 As TotalContribution, 0 As ManualContribution, 0 As ADPContribution, 0 As ADPManualContribution,    
0 As OverAllADPContribution, 0 As OverAllManualContribution,  
0 As iEOBContribution, iEOBManualContribution = Payment from #iEOBtemp1   
)b  
  
Inner join #BatchList c on c.BatchNo = b.BatchNo Where c.PgCount <6 Group by  c.UploadDate, c.ScanDate,  c.PayerName, c.BatchNo, c.ServiceID  
       
UNION ALL  
      
SELECT c.UploadDate, c.BatchNo, c.ServiceID, CONVERT(varchar(15), c.ScanDate) As ScanDate,c.PayerName  , SUM(TotalContribution) As TotalContribution, SUM(ManualContribution) As ManualContribution, SUM(ADPContribution) As ADPContribution,    
SUM(ADPManualContribution) As ADPManualContribution, 0 As OverAllADPContribution,  0 As OverAllManualContribution,      
SUM(iEOBContribution) As iEOBContribution,  SUM(iEOBManualContribution) As iEOBManualContribution,   
0 As '<6 Trans', '>=6 Trans' = SUM(ManualContribution) + SUM(iEOBContribution) + SUM(ADPContribution) + SUM(iEOBManualContribution) + SUM(ADPManualContribution) from (  
   
/*Total Contribution*/        
Select tb.BatchNo, SUM(CreatedPtnCnt) + SUM(PaymentInsCnt) + SUM(ExceptionCnt) + SUM(PtnPostingCnt) +  SUM(ColPostingCnt) As TotalContribution,        
0 As ManualContribution, 0 As ADPContribution, 0 As ADPManualContribution, 0 As OverAllADPContribution, 0 As OverAllManualContribution,   
0 As iEOBContribution, 0 As iEOBManualContribution from #BatchList tb        
Inner join ARC_Athena..BatchLogInformation(nolock) bLog on bLog.BatchNum = tb.BatchNo   
Group by tb.BatchNo         
UNION ALL  
/*ManualContribution*/   
Select tb.BatchNo, 0 As TotalContribution, ManualContribution = SUM(CreatedPtnCnt) + SUM(PaymentInsCnt) + SUM(ExceptionCnt) + SUM(PtnPostingCnt) +  SUM(ColPostingCnt),        
0 As ADPContribution, 0 As ADPManualContribution, 0 As OverAllADPContribution, 0 As OverAllManualContribution,  
0 As iEOBContribution, 0 As iEOBManualContribution from #BatchList tb        
Inner join ARC_Athena..BatchLogInformation(nolock) bLog on bLog.BatchNum = tb.BatchNo Where tb.ServiceID not in (418, 452)          
Group by tb.BatchNo  
UNION ALL        
/*ADP Contribution*/        
Select t.BatchNo, 0 As TotalContribution, 0 As ManualContribution, ADPContribution = SUM(t.Payment) -  SUM(t1.Payment), 0 As ADPManualContribution,    
0 As OverAllADPContribution, 0 As OverAllManualContribution,  
0 As iEOBContribution, 0 As iEOBManualContribution from #temp t        
Inner join #temp1 t1 on t1.BatchNo = t.BatchNo Group by t.BatchNo  
UNION ALL  
Select  BatchNo, 0 As TotalContribution, 0 As ManualContribution, ADPContribution = Payment, 0 As ADPManualContribution,   
0 As OverAllADPContribution, 0 As OverAllManualContribution,  
0 As iEOBContribution, 0 As iEOBManualContribution from #temp Where BatchNo not in (Select BatchNo from #temp1)  
UNION ALL    
/*ADP Manual Contribution*/  
Select BatchNo, 0 As TotalContribution, 0 As ManualContribution, 0 As ADPContribution, ADPManualContribution = Payment,   
0 As OverAllADPContribution, 0 As OverAllManualContribution,  
0 As iEOBContribution, 0 As iEOBManualContribution from #temp1  
UNION ALL   
/*iEOB Contribution*/         
Select t.BatchNo, 0 As TotalContribution, 0 As ManualContribution, 0 As ADPContribution, 0 As ADPManualContribution,   
0 As OverAllADPContribution, 0 As OverAllManualContribution,  
iEOBContribution = SUM(t.Payment) -  SUM(t1.Payment), 0 As iEOBManualContribution from #iEOBtemp t        
Inner join #iEOBtemp1 t1 on t1.BatchNo = t.BatchNo Group by t.BatchNo        
UNION ALL        
Select  BatchNo, 0 As TotalContribution, 0 As ManualContribution, 0 As ADPContribution, 0 As ADPManualContribution,    
0 As OverAllADPContribution, 0 As OverAllManualContribution,  
iEOBContribution = Payment, 0 As iEOBManualContribution from #iEOBtemp Where BatchNo not in (Select BatchNo from #iEOBtemp1)  
UNION ALL  
/*iEOB Manual Contribution*/  
Select  BatchNo, 0 As TotalContribution, 0 As ManualContribution, 0 As ADPContribution, 0 As ADPManualContribution,    
0 As OverAllADPContribution, 0 As OverAllManualContribution,  
0 As iEOBContribution, iEOBManualContribution = Payment from #iEOBtemp1   
)b      
Inner join #BatchList c on c.BatchNo = b.BatchNo Where c.PgCount >=6 Group by  c.UploadDate, c.ScanDate , c.PayerName, c.BatchNo, c.ServiceID  
)e Group by e.UploadDate, e.ScanDate, e.PayerName, e.BatchNo, e.ServiceID    
    
UNION ALL     
/*______________________________________________________________________________________________________________________________________________________________*/    
/*Scan Date wise*/      
SELECT c.UploadDate, c.BatchNo, c.ServiceID, CONVERT(varchar(15), c.ScanDate) As ScanDate, c.PayerName, 0 As TotalContribution, 0 As ManualContribution,   
0 As ADPContribution, 0 As ADPManualContribution, SUM(OverAllADPContribution) AS OverAllADPContribution,       
SUM(OverAllManualContribution) AS OverAllManualContribution, 0 As iEOBContribution, 0 As iEOBManualContribution, 0 AS '<6 Trans', 0 As '>=6 Trans' from (  
Select  BatchNo, 0 As TotalContribution, 0 As ManualContribution, 0 As ADPContribution,  0 As ADPManualContribution, OverAllADPContribution = Payment,   
0 As OverAllManualContribution, 0 As iEOBContribution, 0 As iEOBManualContribution from #OverAlltemp  
UNION ALL  
Select  BatchNo, 0 As TotalContribution, 0 As ManualContribution, 0 As ADPContribution, 0 As ADPManualContribution, 0 As OverAllADPContribution,   
OverAllManualContribution = Payment, 0 As iEOBContribution, 0 As iEOBManualContribution from #OverAlltempVolume   
)b        
Inner join #OverAllBatchList c on c.BatchNo = b.BatchNo Group by c.UploadDate, c.ScanDate, c.PayerName, c.BatchNO, c.ServiceID  
/*_______________________________________________________________________________________________________________________________________________________________*/    
   
)z  Group by z.ScanDate, z.PayerName, z.BatchNO, z.ServiceID , z.UploadDate  
    
SELECT   UploadDate, ServiceID,  p.PayerName, SUM(OverAllADPContribution)  As OverAllADPContribution, SUM(OverAllManualContribution) As OverAllManualContribution,   
SUM(TotalContribution) AS TotalContributionForiEOBPayers, SUM(ManualContribution) As ManualContribution,  
SUM(ADPContribution) As ADPContribution, SUM(ADPManualContribution) As ADPManualContribution,   
SUM(iEOBContribution) As iEOBContribution, SUM(iEOBManualContribution) As iEOBManualContribution,  
SUM([<6 Trans]) AS '<6 Trans', SUM([>=6 Trans]) As '>=6 Trans'  From #Final t  
inner join arc_flow_athena..adm_payername p on p.PayerName = t.PayerName   
Group by   UploadDate,  ServiceID, p.PayerName Order by UploadDate asc  
   
IF OBJECT_ID('Tempdb..#ADPClaim') is not null drop table #ADPClaim        
IF OBJECT_ID('Tempdb..#iEOBClaim') is not null drop table #iEOBClaim        
IF OBJECT_ID('Tempdb..#iEOBtemp1') is not null drop table #iEOBtemp1        
IF OBJECT_ID('Tempdb..#iEOBtemp') is not null drop table #iEOBtemp        
IF OBJECT_ID('Tempdb..#temp1') is not null drop table #temp1        
IF OBJECT_ID('Tempdb..#temp') is not null drop table #temp        
IF OBJECT_ID('Tempdb..#BatchList') is not null drop table #BatchList   
IF OBJECT_ID('Tempdb..#A') is not null drop table #A       
  
  
End


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOB_pConsolidatedReport] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[iEOB_pConsolidatedReport] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOB_pConsolidatedReport] TO [DB_DMLSupport]
    AS [dbo];

