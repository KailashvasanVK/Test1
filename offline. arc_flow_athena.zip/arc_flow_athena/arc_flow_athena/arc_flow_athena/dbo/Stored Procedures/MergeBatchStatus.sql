﻿CREATE Proc MergeBatchStatus (@Batchnum varchar(20))  
  
as  
select Posteddt,Auditeddt,Uploaddt,status from arc_flow_athena..trn_koff_tbatches where batchno=@Batchnum  
select  a.batchno,Posteddt,Auditeddt,Uploaddt,a.Status as '.flow Status',c.ulstatus ,b.payment,b.selfpay,b.exception from arc_flow_athena..trn_koff_tbatches a   
inner join arc_flow_athena..mergebatchdetails b on a.batchno=b.childbatchno  
inner join arc_athena..batchmaster c on c.batchnum=b.childbatchno  
where b.parentbatchno=@Batchnum  
if exists (select * from Arc_Athena..MergeExtractLog where batchnum='S54720A1' and Process='BatchLog-Completed')  
begin  
 Select 'Extarct Without anyissue. Waiting for Upload' as 'Status'  
end  
else  
Begin  
 Select 'Issue\Not yet extracted' as 'Status'  
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[MergeBatchStatus] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MergeBatchStatus] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MergeBatchStatus] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[MergeBatchStatus] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MergeBatchStatus] TO [DB_DMLSupport]
    AS [dbo];

