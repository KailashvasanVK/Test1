﻿ 
CREATE Proc Trn_kOFF_BatchReEnterTransaction_Merge      
@Batchnum varchar(30)=''      
as      
/*Created By     : Noor                    
Created Date   : 2018-11-21      
Purpose        : When batch transactions are edited by other user(using Batchsplit,Reset,Incomplete) then need to regenerate in .flow production for this batch to address transaction mismatch.       
Ticket/SCR ID  : SCR 1499             
TL Verified By : Ramakrishnan.G                    
Reviewd by     : <DBA Name>                      
Implemented by : Narayana	                         
Implemented On : 2018-11-28         
       
*/       
Begin      
--DECLARE @Batchnum varchar(30)='S613824A1'  
DECLARE @BatchId int=0      
SELECT @BatchId=Batchid from trn_koff_tbatches where Batchno=@Batchnum and Status=1      
if object_id('tempdb..#tmptbatchTransactSubmitLogHistoy') is not null drop table #tmptbatchTransactSubmitLogHistoy      
Create table #tmptbatchTransactSubmitLogHistoy      
(MergeBatchno varchar(30), BatchNo varchar(30),BatchId int, BatchProcessId int,TransCnt int,      
CompletedPageNo int,CreatedBy int,TransServiceId int,isQCEntry int,BatchServiceId int,CreatedDate datetime)      
-- select batchnum,count(id) from paymentdetailmaster group by batchnum having count(batchnum)>10order by 1 descwhere batchnum=' 5448332A7598'      
/*      
ServiceId TransServiceName      
358 Payment      
359 Collection      
360 Exception Posting      
361 Self Posting      
364 Patient Creation      
*/      
      
DECLARE @isBatchTransModified int=0      
if(@BatchId>0)      
BEGIN      
If(SELECT count(BatchId) FROM TRN_kOFF_tBatchModified(nolock) where BatchID=@BatchId and ModifyMode='RP' ) > 0      
BEGIN      
SET @isBatchTransModified = 1      
END      
IF(SELECT count(BatchId) FROM trn_koff_tbatchqueue(nolock) where BatchId=@BatchId)  > 1      
BEGIN      
SET @isBatchTransModified = 1      
END      
END      
--set @isBatchTransModified=1      
if(@isBatchTransModified=1)      
BEGIN      
      
--DECLARE @Batchnum varchar(30)='S594100A1'      
            
       
if object_id('tempdb..#MergeBatchInfoDtls') is not null drop table #MergeBatchInfoDtls      
select ChildBatchNo, ParentBatchNo,  StartpgNo, EndPgNo, Id into #MergeBatchInfoDtls                                                        
from Arc_Flow_Athena..MergeBatchDetails  (nolock) where parentbatchno=@Batchnum         
            
      
insert into #tmptbatchTransactSubmitLogHistoy(MergeBatchno,BatchNo, BatchProcessId,TransCnt,CreatedBy,TransServiceId,isQCEntry)      
select ParentBatchNo,mb.childbatchno,processid,count(pm.id), createdby,358,0   from  #MergeBatchInfoDtls mb left join  arc_athena..PaymentDetailMaster(nolock) pm      
on pm.batchnum=mb.childbatchno where ParentBatchNo=@BatchNum group by ParentBatchNo,mb.childbatchno,processid,createdby--, isnull(isqcentry,0)      
      
insert into #tmptbatchTransactSubmitLogHistoy(MergeBatchno,BatchNo, BatchProcessId,TransCnt,CreatedBy,TransServiceId,isQCEntry)      
SELECT ParentBatchNo,batchnum,ProcessId,count(CPId), createdby,359,0  From #MergeBatchInfoDtls mb left join arc_athena.dbo.CollectionPostingMaster(nolock) col       
on col.batchnum=mb.childbatchno where ParentBatchNo=@BatchNum  group by ParentBatchNo,batchnum,processid,createdby--,isnull(isqcentry,0)         
       
 insert into #tmptbatchTransactSubmitLogHistoy(MergeBatchno,BatchNo, BatchProcessId,TransCnt,CreatedBy,TransServiceId,isQCEntry)      
select ParentBatchNo,batchnum,processid,count(TransCnt) ,createdby,360,isnull(IsQCEntry,0)   from(            
SELECT ParentBatchNo,batchnum,processid,modifiedby as createdby ,be.id as TransCnt,isnull(IsQCEntry,0) as isqcentry       
From  #MergeBatchInfoDtls mb left join arc_athena.dbo.BatchException(nolock) be on mb.childbatchno=be.batchnum      
  where ParentBatchNo=@BatchNum --and isnull(isqcentry,0)                  
union all      
SELECT ParentBatchNo,be.batchnum,be.processid,modifiedby as createdby ,be.id as TransCnt,0 as isqcentry From #MergeBatchInfoDtls mb left join arc_athena.dbo.BatchException(nolock) be        
on be.batchnum=mb.childbatchno  inner join arc_athena.dbo.refundrequestline(nolock) rf on be.batchnum=rf.batchnum and be.id=rf.rletterid       
where ParentBatchNo=@BatchNum --and isnull(isqcentry,0)in(0,1)      
 ) a     group by ParentBatchNo,batchnum,processid,createdby,isnull(IsQCEntry,0)             
       
 insert into #tmptbatchTransactSubmitLogHistoy(MergeBatchno,BatchNo, BatchProcessId,TransCnt,CreatedBy,TransServiceId,isQCEntry)           
SELECT ParentBatchNo,batchnum,processid,count(pat.id), createdby,361,0   From #MergeBatchInfoDtls mb left join arc_athena.dbo.PatientPostingMaster(nolock) pat      
on pat.batchnum=mb.childbatchno where ParentBatchNo=@BatchNum group by ParentBatchNo,batchnum,processid,createdby--,isnull(isqcentry,0)                                
      
insert into #tmptbatchTransactSubmitLogHistoy(MergeBatchno,BatchNo, BatchProcessId,TransCnt,CreatedBy,TransServiceId,isQCEntry)      
Select ParentBatchNo,pymnt.batchnum,processid,count(distinct csd.ClaimID), createdby,364,0   from #MergeBatchInfoDtls mb       
left join arc_athena.dbo.PaymentDetailMaster(nolock) pymnt on pymnt.batchnum=mb.childbatchno inner join                         
arc_athena.dbo.ClaimServiceDetailMaster(nolock) csd on pymnt.chargeID=csd.ChargeID                         
inner join arc_athena.dbo.ClaimDetailMaster(nolock) clm on csd.ClaimID =clm.ClaimID                         
where ParentBatchNo=@BatchNum  and clm.Status =1      
group by ParentBatchNo,pymnt.batchnum,processid,createdby --,isnull(isqcentry,0)      

/*      
select * from #MergeBatchInfoDtls mb left join #tmptbatchTransactSubmitLogHistoy tbl on tbl.batchno=mb.ChildBatchNo inner join arc_flow_athena.dbo.trn_koff_tbatchqueue tbq      
on tbl.batchno=tbq.batchno where mb.ParentBatchNo='S594100A1'      
      
select * from #MergeBatchInfoDtls mb left join #tmptbatchTransactSubmitLogHistoy tbl on tbl.batchno=mb.ChildBatchNo inner join arc_flow_athena.dbo.trn_koff_tbatchqueue tbq      
on tbl.batchno=tbq.batchno where tbl.MergeBatchno='S594100A1'      
 */     
Update tbl set tbl.BatchServiceId=tbq.Serviceid,tbl.batchprocessid=tbq.batchprocessid,CompletedPageNo=PageTo from  #tmptbatchTransactSubmitLogHistoy tbl inner join arc_flow_athena.dbo.trn_koff_tbatchqueue tbq      
on tbl.batchno=tbq.batchno  Where tbl.MergeBatchno=@BatchNum      
      
Insert into arc_flow_athena.dbo.TRN_koff_tbatchTransactReEnterTrans(CustomerId,BatchNo,BatchId, BatchProcessId,TransCnt      
,CompletedPageNo,CreatedBy,TransServiceId,BatchServiceId,isQCEntry,CreatedDate,Comments)      
select 25,tbq.batchno,tbq.batchid,tbq.batchprocessid,tbl.TransCnt,tbq.PageTo,tbl.CreatedBy,tbl.TransServiceid,tbq.Serviceid,isQCEntry,getdate(),'ReEnterProduction' from     
#tmptbatchTransactSubmitLogHistoy tbl inner join arc_flow_athena.dbo.trn_koff_tbatchqueue(nolock) tbq      
on tbl.batchno=tbq.batchno  where tbl.MergeBatchno=@BatchNum --and isnull(isQcentry,0) in (0,1)      
      
--select * from #tmptbatchTransactSubmitLogHistoy      
/*Insert Existing information*/      
Insert into TRN_kOFF_tBatchTransactLog(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,UpdatedBy,UpdatedDt,isQcEntry)              
 select BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,CreatedBy,getdate(),isQcEntry from TRN_kOFF_tBatchTransact where BatchId=@BatchID              
       
/*Delete existing information and Insert new information*/      
      
DELETE TRN_kOFF_tBatchTransact WHERE batchid in(SELECT tb.batchId FROM trn_koff_tbatches tb inner join mergebatchdetails mb on mb.childbatchno=tb.batchno where parentbatchno=@BatchNum)     
      
Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry,LocationId,ShiftId,FactorTrans)         
SELECT distinct BatchProcessId,CompletedPageNo,TransServiceId,TransCnt,Case isqcentry when 1 then '' else '' end as InfoValue,tbR.CreatedBy,getdate(),tb.BatchId,      
tbR.BatchServiceId,tb.ClientId,isQCEntry,(Select LocationId from ARC_REC_ATHENA..ARC_REC_User_Info(nolock) where UserId = tbR.CreatedBy) as LocationId,      
(Select Top 1 SHIFT_ID from ARC_REC_ATHENA.dbo.ARC_REC_SHIFT_TRAN(nolock) where USERID = tbR.CreatedBy and Effect_DATE <= GETDATE() Order by Effect_DATE desc) as ShiftId,      
 Case isQCEntry when 1 then (SELECT QCPayment FROM ADM_FactorWaterTown(nolock) Where ServiceGroupId = tbR.BatchServiceId and CONVERT(date,getdate()) between EffectiveFrom and isnull(EffectiveTo,GETDATE()))      
 when 0 then (SELECT EntryPayment FROM ADM_FactorWaterTown(nolock) Where ServiceGroupId = tbR.BatchServiceId and CONVERT(date,getdate()) between EffectiveFrom and isnull(EffectiveTo,GETDATE())) end as FactorTrans       
   FROM TRN_koff_tbatchTransactReEnterTrans(nolock) tbR inner join trn_koff_tbatches(nolock) tb on tbR.batchno=tb.batchno       
 where tb.batchid in(SELECT tb.batchId FROM trn_koff_tbatches(nolock) tb inner join mergebatchdetails(nolock) mb on mb.childbatchno=tb.batchno where parentbatchno=@BatchNum) and isnull(TransCnt,0)>0  --'121865A11284'      
      
      
End      
END 

GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Trn_kOFF_BatchReEnterTransaction_Merge] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Trn_kOFF_BatchReEnterTransaction_Merge] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Trn_kOFF_BatchReEnterTransaction_Merge] TO [DB_DMLSupport]
    AS [dbo];

