﻿
CREATE proc MergeDSB_ReadyBatches @scandate varchar(10)=null ,@Minpagecount varchar(5)=null,@Maxpagecount int,@ClientName varchar(10)= Null,@serviceid varchar(10)=null                                                         
as         
                           
begin       
      
Declare @qury nvarchar(Max)                                       
                     
                                                       
create table #MergeSubclients                                              
(                                                
ID  int IDENTITY (1, 1) NOT NULL,                                                
Batchcount int,                                                
SubClient varchar(10),                                    
PgCount int                                              
)           
              
set @qury='insert into #MergeSubclients(batchcount,Subclient,pgcount)                                      
select Count(a.total) as total,Client,sum(pgcount)  from(                                        
SELECT a.BatchNo,PgCount,                                        
SUBSTRING(a.BatchNo,CHARINDEX(''A'',a.BatchNo)+1,(LEN(a.BatchNo)-CHARINDEX(''A'',a.BatchNo))+1) As Client,                                        
ROW_NUMBER() OVER (PARTITION BY SUBSTRING(a.BatchNo,CHARINDEX(''A'',a.BatchNo)+1,(LEN(a.BatchNo)-CHARINDEX(''A'',a.BatchNo))+1) ORDER BY a.BatchNo DESC) AS total                                        
FROM TRN_kOFF_tBatches a                 
Inner join TRN_kOFF_tBatchQueue bq on a.batchno=bq.batchno                
inner join ARC_Athena..batchMaster b on a.batchno=b.batchnum                 
Where status=1 and bq.assigned=0 and bq.statusid=0 and  a.ClientID not in (select Clientid from ExcludeFormerge)'                    
                           
set @qury+=' and a.PgCount <= cast('''+@Minpagecount+'''as int)'                                 
                              
if @scandate <>''                              
                 
Set @qury += ' and convert(varchar,a.scandate,101) = '''+@scandate+''''                               
                               
if @ClientName <> ''                              
                              
Set @qury += ' and SUBSTRING(a.BatchNo,CHARINDEX(''A'',a.BatchNo)+1,(LEN(a.BatchNo)-CHARINDEX(''A'',a.BatchNo))+1)='''+@ClientName+''''                               
                              
if @serviceid <>''                              
                              
Set @qury += ' and a.serviceid = cast('''+@serviceid+'''as int)'                                      
                             
set @qury +=  'and  a.UploadDt is  null  and b.ULStatus is null )a  group by a.Client having sum(a.pgcount)>'+ CAST(@Maxpagecount as varchar(10))                            
                                
Print @qury                              
exec(@qury)    
                            
     select * from #MergeSubclients                          
End  


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[MergeDSB_ReadyBatches] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MergeDSB_ReadyBatches] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MergeDSB_ReadyBatches] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[MergeDSB_ReadyBatches] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MergeDSB_ReadyBatches] TO [DB_DMLSupport]
    AS [dbo];

