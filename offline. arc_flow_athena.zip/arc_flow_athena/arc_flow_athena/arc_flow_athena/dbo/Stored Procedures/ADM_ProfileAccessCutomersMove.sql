﻿
   CREATE Procedure  ADM_ProfileAccessCutomersMove  
@UserIdCollection varchar(max) = ''  
As  
/*  
Created by : Karthik Ic  
Created on : 15 May 2013  
Impact to  : ProfileSetup.aspx  
Purpose    : To move  all data from log table and delete the data from userCustomer table.  
*/  
Begin  
--- move the customer details  
Insert into ADM_AccessCutomerslog (UserId,CustomerId,CreatedBy,CreatedDt,AccCustomerId)  
Select UserId,CustomerId,CreatedBy,CreatedDt,AccCustomerId From  ADM_AccessCutomers Where UserId in (select items from fnSplitString(@UserIdCollection,','))  
Delete from ADM_AccessCutomers Where UserId in (select items from fnSplitString(@UserIdCollection,','))  

End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ProfileAccessCutomersMove] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileAccessCutomersMove] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileAccessCutomersMove] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ProfileAccessCutomersMove] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileAccessCutomersMove] TO [DB_DMLSupport]
    AS [dbo];

