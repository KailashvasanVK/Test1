﻿CREATE Procedure ADM_CustomerInsert 
(                
@CustomerId int                
,@FinName varchar(75)                
,@FinEmailId varchar(100)                
,@FinPhone1 varchar(20)                
,@FinPhone2 varchar(20)                
,@FinFax varchar(20)                
,@ContractStartDt date                
,@ContractEndDt date                
,@Discount decimal(5,2)                
,@TAT int                
,@Quality decimal(5,2)                
,@CreatedBy int              
,@CustomerAddress  varchar(500)            
,@FullName  varchar(100)            
,@InternalName varchar(50)            
)                
As   
/*  
Purpose           : To save the customer details   
Created By        : Karthik ic  
Created Date      : 27 March 2013    
Impact to    : CustomerCreation.aspx                    
*/   
Begin
Declare @MsgHeader varchar(50)=''
Declare @MsgContent varchar(max) =''
Declare @FromMail varchar(100)
Declare @ToMail varchar(100)
if ISNULL(@CustomerId,0) = 0
	Begin /** New Insertion **/
	Insert into ADM_Customer(FinName,FinEmailId,FinPhone1,FinPhone2,FinFax
	,ContractStartDt,ContractEndDt ,Discount,TAT,Quality,Status,CreatedBy,CustomerAddress,FullName,InternalName,CreatedDt,AprStatus)
	Select @FinName,@FinEmailId,@FinPhone1,@FinPhone2,@FinFax
	,@ContractStartDt,@ContractEndDt,@Discount,@TAT,@Quality,1,@CreatedBy,@CustomerAddress,@FullName,@InternalName,GETDATE(),2
	set @MsgHeader = @FullName + ' details has been added.'
	End
Else
	Begin /** Modified **/
	/** Check if any changes in customer profile **/
	if (Select COUNT(*) from ADM_Customer
	Where CustomerId = @CustomerId
	and FinName = @FinName and FinEmailId = @FinEmailId and FinPhone1 = @FinPhone1 and FinPhone2 = @FinPhone2 and FinFax = @FinFax
	and ContractStartDt = @ContractStartDt and ContractEndDt = @ContractEndDt
	and Discount = @Discount and TAT = @TAT and Quality = @Quality and CustomerAddress = @CustomerAddress and FullName = @FullName and InternalName = @InternalName	) = 0
		Begin /** if changes found need to move log **/
		Insert into ADM_CustomerLog( CustomerId,FinName,FinEmailId,FinPhone1,FinPhone2,FinFax
		,ContractStartDt,ContractEndDt ,Discount,TAT,Quality,Status,CreatedBy,CustomerAddress,FullName,InternalName,CreatedDt,AprStatus,ApprovedBy,ApprovedDt)
		Select CustomerId,FinName,FinEmailId,FinPhone1,FinPhone2,FinFax
		,ContractStartDt,ContractEndDt,Discount,TAT,Quality,Status,CreatedBy,CustomerAddress,FullName,InternalName,CreatedDt,AprStatus,ApprovedBy,ApprovedDt
		from ADM_Customer where CustomerId = @CustomerId
		Update ADM_Customer Set AprStatus = 3,CreatedBy = @CreatedBy,CreatedDt = GETDATE(),FinName = @FinName ,FinEmailId = @FinEmailId 
		,FinPhone1 = @FinPhone1 ,FinPhone2 = @FinPhone2 ,FinFax = @FinFax,ContractStartDt = @ContractStartDt ,ContractEndDt = @ContractEndDt
		,Discount = @Discount ,TAT = @TAT ,Quality = @Quality ,CustomerAddress = @CustomerAddress ,FullName = @FullName ,InternalName = @InternalName
		Where CustomerId = @CustomerId		
		End
	Else
		Update ADM_Customer Set AprStatus = 3 Where CustomerId = @CustomerId		
	End
	set @MsgHeader = @FullName + ' details has been modified.'

Declare @AppPath varchar(100) 
select  @AppPath  = CtlValue from ADM_SoftControl where CtlID = 'AppPath'
Set @MsgContent = '<p>  ' +  @MsgHeader + ' Kindly <a href="'+@AppPath+'CustomerApproval.aspx"> Click here </a> to review. </p> </br></br> <p>        ** This is an auto-generated email. Please do not reply to this email.**    </p>' 
Select @FromMail = NT_USERNAME + '@accesshealthcare.co',@ToMail =REPORTING_TO + '@accesshealthcare.co' from ARC_REC_Athena..ARC_REC_USER_INFO Where USERID =@CreatedBy
--exec ARC_REC_Athena..SP_INS_ARC_REC_MAIL_TRAN @FROM_MAILID = @FromMail,@RECIPIENTS = @ToMail,@CC = '',@SUBJECT_TEXT = @MsgHeader,@BODY = @MsgContent,@ISHTML = 'Y'
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_CustomerInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_CustomerInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_CustomerInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_CustomerInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_CustomerInsert] TO [DB_DMLSupport]
    AS [dbo];

