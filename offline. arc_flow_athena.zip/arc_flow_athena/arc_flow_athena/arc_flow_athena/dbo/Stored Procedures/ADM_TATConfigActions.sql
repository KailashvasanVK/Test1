﻿CREATE Procedure [dbo].[ADM_TATConfigActions]       
(      
@Action varchar(100)='',     
@CustomerId INT=0,      
@ClientId INT=0,      
@ServiceId INT=0,      
@TatDuration INT=0, 
@EffectiveFrom varchar(50)='',    
@CreatedBy INT=0,      
@TatId int=0    
--@FID INT OUTPUT         
    
)      
AS      
BEGIN      
IF(@Action ='InsertTAT')          
 BEGIN      
  INSERT INTO ADM_TAT(CustomerId,ClientId,ServiceId,TAT_Duration,EffectiveFrom,CreatedBy)      
  Select @CustomerId,@ClientId,@ServiceId,@TatDuration,convert(varchar,@EffectiveFrom,101),@CreatedBy    
-- SELECT @FID = IDENT_CURRENT('ADM_Factor')     
 END      
ELSE IF(@Action ='SelectTATDetails')      
 BEGIN      
 select ser.ServiceId,c.ClientId,t.TATId as TATId,ser.ServiceName,c.ClientAcmName as ClientName,t.TAT_Duration,    
  CONVERT(varchar,t.EffectiveFrom,101) as EffectiveFrom,CONVERT(varchar,t.EffectiveTo,101) as EffectiveTo,    
  case when t.Status=0 then 'Inactive' when t.Status=1 then 'Active' end as Status from ADM_TAT t      
  inner join ADM_Client c on c.ClientId=t.ClientId      
  inner join ADM_Service ser on ser.ServiceId=t.ServiceId where t.CustomerId=@CustomerId   
 END      
ELSE IF(@Action='UpdateTAT')      
 BEGIN      
   Update ADM_TAT set Status=0,EffectiveTo=DATEADD(DAY,-1,CONVERT(varchar,@EffectiveFrom,101)),UpdatedBy=@CreatedBy,UpdatedDt=GETDATE()  where TATId=@TatId           
   INSERT INTO ADM_TAT(CustomerId,ClientId,ServiceId,TAT_Duration,EffectiveFrom,CreatedBy)      
   VALUES(@CustomerId,@ClientId,@ServiceId,@TatDuration,convert(varchar,@EffectiveFrom,101),@CreatedBy)          
       
 END       
END



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_TATConfigActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_TATConfigActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_TATConfigActions] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_TATConfigActions] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_TATConfigActions] TO [DB_DMLSupport]
    AS [dbo];

