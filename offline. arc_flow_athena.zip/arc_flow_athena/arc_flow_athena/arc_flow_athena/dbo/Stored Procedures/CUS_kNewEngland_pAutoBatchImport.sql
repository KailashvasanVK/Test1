﻿CREATE Procedure  CUS_kNewEngland_pAutoBatchImport
(
 @pFileName varchar(200) = ''
,@pPageCount int = 0
,@pCmpKey varchar(5)=''
,@pScanDate date=''
,@pBatchNo varchar(50)=''          
)
As
Begin
        Declare @FilePath varchar(250)=''
		--declare @batcchno varchar(75) = 'EALCHG12311301'
		Declare @Subclient varchar(15)='';
		declare @FileType varchar(3) ='';
		set @Subclient =(select LEFT(@pBatchNo, 3))
		set @FileType =(select Substring(@pBatchNo,4,3))
		Declare @ServiceId int = 0
		Declare @ClientId int = 0
		Declare @IsCodingClient int = 0
		set @ClientId = (select ClientId from ADM_Client where ClientAcmName =@Subclient and CustomerId=7)		
		
		if (@Subclient = 'ESP' or @Subclient = 'FAB' or @Subclient = 'JJB' or @Subclient = 'MIM' or @Subclient = 'MMA' or @Subclient = 'PSS' or @Subclient = 'SHA')
			Set @IsCodingClient = 1
		
		if(@IsCodingClient=1 and @FileType='CHG')			
				set @ServiceId=7 /** Coding **/			
		else if(@IsCodingClient=1 and @FileType='SUR')	 			
				set @ServiceId=7 /** Coding **/	
	    else if(@IsCodingClient=1 and @FileType='FER')
	            set @ServiceId=7 /** Coding **/	
		else if(@FileType='CHG')			
			   set @ServiceId=1 /** charge **/			
        else if(@FileType='PMT')
        	   set @ServiceId=5 /** payment **/			
        else if(@FileType='DEM')
        	   set @ServiceId=1 /** charge **/	
        else if((select LEFT(@pBatchNo,6))='SHFSUR')
          Begin
             set @ClientId = (select ClientId from ADM_Client where ClientName ='SHF')
             set @ServiceId=7 /** Coding **/		
          End			   
		else if(@FileType='SUR')
        	   set @ServiceId=1 /** charge **/
        else if((select LEFT(@pBatchNo,6))='SHAFER')
			  Begin
				 set @ClientId = (select ClientId from ADM_Client where ClientName ='SHF')
				 set @ServiceId=7 /** Coding **/		
			  End	    
       else if((select LEFT(@pBatchNo,7))='SEVINOR')
          Begin
             set @ClientId = (select ClientId from ADM_Client where ClientName ='PSS')
             set @ServiceId=7 /** Coding **/		
          End
       	        
         
  if(@ClientId <>0 and @ServiceId <>0)
   begin       
       set @FilePath =(select 'New England\TP\'+REPLACE(convert(varchar,GETDATE(),101),'/','')+'\'+@pBatchNo+'.PDF')
	   Exec TRN_pBatchesInsert @CmpKey ='NwEng',@ScanDate=@pScanDate,@BatchNo=@pBatchNo,@FileName =@pFileName,@ClientId =@ClientId,@ServiceId=@ServiceId
							   ,@BatchType=1,@CreatedBy=1777,@PageCount=@pPageCount,@BatchFullName=@FilePath
    End
End









GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kNewEngland_pAutoBatchImport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kNewEngland_pAutoBatchImport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kNewEngland_pAutoBatchImport] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kNewEngland_pAutoBatchImport] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kNewEngland_pAutoBatchImport] TO [DB_DMLSupport]
    AS [dbo];

