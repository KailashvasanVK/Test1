﻿CREATE Procedure ADM_ErrorRebuttalMailNotification
As
BEgin

    Declare @TraingTeamReceipts varchar(100)
    /*Training team group email id,Req Ticket Id:388980*/
    Set @TraingTeamReceipts='WATERTOWN_TRAINING_DE';
     
	if OBJECT_ID('tempdb..#RebuttalUsers') is not null drop table #RebuttalUsers
	Create Table #RebuttalUsers(UserId int,MailUser varchar(200),Supervisor varchar(200)
	,Cmpkey varchar(100),Customer varchar(100),Functionality varchar(100),LastActionTakenBy varchar(100),LastActionDate Date,LastActionStatus varchar(100),WITHINTAT int,OUTTAT int)
	
	/*Get entry associates users list*/

	Declare  @Cmpkey varchar(5) ='AHS',@SessionUserId int=6312,@SelectedUserId int=0,@BatchProcessId int=0
	Declare @Query varchar(max),@sqlWhere varchar(max)
	Declare @tempCmpKey varchar(5),@tempCustomer varchar(100),@tempSessionUserId int,@tempSelectedUserId int,@tempBatchProcessId int,@tempsqlWhere varchar(max) 
	,@tmpFunctionality varchar(100)
	Declare @CC varchar(500),@RECIPIENTS varchar(500),@FROM_MAILID varchar(100)
	/*get rebuttal action pending user list for all customers*/
		Insert into #RebuttalUsers(Cmpkey,Customer,UserId,MailUser,Supervisor,Functionality,LastActionTakenBy,LastActionDate,LastActionStatus,WITHINTAT,OUTTAT)
		Select distinct x.Cmpkey,x.Customer,usr.USERID,
		Case when UserAction='Training Team/Ops Manager' then @TraingTeamReceipts else  x.MailUser end as MailUser
		,Case when usr.Reporting_To='shaji.ravi' then '' else usr.Reporting_To end as Supervisor
		,fun.JobTitle as Functionality
		,LastActionTakenBy,x.[Date],x.LastActionStatus ,x.WITHINTAT,x.OUTTAT		
		from (
			Select 'OFF' as Cmpkey,'ATHENA' as Customer
			,case when UserAction='Entry user' then usrentry.NT_USERNAME
			when UserAction='Entry Supervisor' then usrentry.REPORTING_TO
			when UserAction='Qc User' then usr.NT_USERNAME
			when UserAction='Qc Supervisor' then usr.REPORTING_TO
			when UserAction='Training Team/Ops Manager' then usrentry.REPORTING_TO 
			when UserAction='Quality Manager' then usr.NT_USERNAME
			else '' End as MailUser
			,case when reb.StatusId =0 then '' else  usr.NT_USERNAME end as LastActionTakenBy
			,CONVERT(Date,reb.CreatedOn) as [Date]
			,mst.StatusCaption as LastActionStatus			
			,case when DATEDIFF(HOUR,flow.CreatedOn,getdate())<48 then 1 else 0 end as WITHINTAT
			,case when DATEDIFF(HOUR,flow.CreatedOn,getdate())>=48 then 1 else 0 end as OUTTAT
			,UserAction
			from TRN_kOFF_tBatchErrorRebuttalFlow (nolock) flow
			inner join TRN_kOFF_tBatchErrorRebuttal (nolock)  reb on flow.ErrRebId=reb.ErrRebId and flow.StatusId=reb.StatusId
			inner join ADM_RebuttalStatusMaster (nolock)  mst on reb.StatusId=mst.StatusId
			inner join ARC_REC_ATHENA..ARC_REC_USER_INFO (nolock)  usr on flow.CreatedBy=usr.USERID
			inner join ARC_REC_ATHENA..ARC_REC_USER_INFO (nolock)  usrentry on reb.ErrorDoneBy=usrentry.USERID
			where reb.StatusId not in(3,9,12,16,20,7,14,19)
		)x 
		inner join ARC_REC_ATHENA..ARC_REC_USER_INFO usr on x.MailUser=usr.NT_USERNAME
		inner join ARC_REC_ATHENA..HR_Functionality fun on fun.FunctionalityId=usr.Functionality_Id		
	
	
	 if OBJECT_ID('tempdb..#MailUsers') is not null drop table #MailUsers
	 Select distinct Cmpkey,Customer,UserId,Functionality into #MailUsers from #RebuttalUsers
	 Declare @Subject varchar(500),@MailBody varchar(max)	 
	 Declare @HeaderQuery varchar(max)
	 Set @Subject='Audit feedback/Error rebuttal pending action - Team - Athena Payment posting'
		Set @HeaderQuery ='
		<html><head><style type="text/css">
		table.hovertable {font-family: verdana,arial,sans-serif;font-size:11px;color:#333333;
		border-width: 1px;border-color: #999999;border-collapse: collapse;}
		table.hovertable th {background-color:#c3dde0;border-width: 1px;padding: 8px;
		border-style: solid;border-color: #a9c6c9;}
		table.hovertable tr {background-color:#d4e3e5;}
		table.hovertable td {border-width: 1px;padding: 8px;
		border-style: solid;border-color: #a9c6c9;}
		</style></head><body>
		
		Hi ,
		<br><br>
		'
		Set @HeaderQuery +='
			This is to notify that below mentioned audit feedback/error rebuttal records are pending for action. 
			<br><br>
			<table class="hovertable">
			<tr><th></th><th></th><th></th><th   colspan="3">Total Feedback pending for action</th></tr>
			<tr><th>Date</th><th>Last Action taken by</th><th>Last Action Status</th><th>Within TAT</th><th>Out of TAT</th><th>Total</th></tr>
			'
			
	   Declare @BodyFooter varchar(max)
		Set @BodyFooter = '
		</br> 
		 Please <a target="_blank" href="https://arcflow.accesshealthcare.co/arc_flow/RebuttalProcess.aspx">Click here</a> to take action.     
		 </br></br>
		 Regards,
		 </br>
		 Arc.rebuttal. 
		</br>
		<div>
		<img width="300px" height="70px" src="https://www.accesshealthcare.co/appimages/arc_flow.png"alt="" />
		</div><div>** This is an auto-generated email. Please do not reply to this email.**</div></body></html>' 
     Declare @CheckUserId int=0
	Declare curreb cursor 
	for Select distinct Cmpkey,UserId,0 as SelectedUserId,0 as BatchProcessId,Customer,Functionality from #MailUsers 
	open curreb
	While 1=1
	Begin
		fetch next from curreb into @tempCmpKey,@tempSessionUserId,@tempSelectedUserId,@tempBatchProcessId,@tempCustomer,@tmpFunctionality
		if @@FETCH_STATUS=-1 break;
		/*
			 --if(@CheckUserId=0 or @tempSessionUserId<>@CheckUserId)
			 --begin
			 --  Set @Subject= 'Audit feedback/Error rebuttal pending action - ' + @tempCustomer + ' - '+@tmpFunctionality	
			 --  Set @CheckUserId=@tempSessionUserId
			 --end
		*/	 		
			Declare @MailContent varchar(max)	
			Set @MailContent ='
			Select 
			''<tr><td>''+Isnull( Convert(varchar,LastActionDate),'''')+''</td>
			<td>''+LastActionTakenBy+''</td>
			<td>''+LastActionStatus+''</td>
			<td>''+Convert(varchar,WITHINTAT)+''</td>
			<td>''+Convert(varchar,OUTTAT)+''</td>
			<td>''+Convert(varchar,(WITHINTAT+OUTTAT))+''</td>			
			</tr>''
			from #RebuttalUsers where  UserId=' + CONVERT(varchar,@tempSessionUserId) + ' order by LastActionDate'
					
			
			if OBJECT_ID('tempdb..#tmpDynData') is not null drop table #tmpDynData
			Create table #tmpDynData (Data varchar(max))
			insert into #tmpDynData
			exec(@MailContent)
			Set @MailContent=''
			Select @MailContent=COALESCE(@MailContent + ' ', '') + Data from #tmpDynData
			Set @MailBody = @HeaderQuery + @MailContent +'</table>' + @BodyFooter
                      
			set @FROM_MAILID='mail.rebuttal@accesshealthcare.com'
			Set @CC= (Select top 1  Supervisor + '@accesshealthcare.com' from #RebuttalUsers  where UserId=@tempSessionUserId)
			Set @RECIPIENTS = (Select top 1  MailUser + '@accesshealthcare.com' from #RebuttalUsers where UserId=@tempSessionUserId)
			Set @CC=@CC+ ';sakkaravarth.k@accesshealthcare.com;jayanthi.yogesh@accesshealthcare.com;nithyamoorth.s@accesshealthcare.com;mallikarjun.nam@accesshealthcare.com;'
			
			/*
			--Set @CC= 'manishankar.pal@accesshealthcare.co'
			--Set @RECIPIENTS = 'mallikarjun.nam@accesshealthcare.com'
			*/
			if(select COUNT(*) from #MailUsers where UserId=@tempSessionUserId)>0
				Exec ARC_REC_ATHENA..SP_INS_ARC_REC_MAIL_TRAN @FROM_MAILID = @FROM_MAILID,@RECIPIENTS = @RECIPIENTS, @CC = @CC,@SUBJECT_TEXT = @Subject,@BODY =@MailBody,@ISHTML = 'Y',@FilePath = ''
			 
	End
	close curreb
	deallocate curreb
	
	if OBJECT_ID('tempdb..#tmpDynData') is not null drop table #tmpDynData
	if OBJECT_ID('tempdb..#tmpUsers') is not null drop table #tmpUsers
	if OBJECT_ID('tempdb..#RebuttalErros') is not null drop table #RebuttalErros
	if OBJECT_ID('tempdb..#RebuttalUsers') is not null drop table #RebuttalUsers
	 
End



GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ErrorRebuttalMailNotification] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ErrorRebuttalMailNotification] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ErrorRebuttalMailNotification] TO [DB_DMLSupport]
    AS [dbo];

