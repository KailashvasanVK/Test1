﻿CREATE Procedure TRN_KOFF_pDirectUploadSearch    
(      
 @Action varchar(100)='',      
 @CmpKey varchar(20),       
 @Userid int,        
 @ClientID  int=0,     
 @ServiseID   int=0,  
 @BatchNO nvarchar(50)='',         
 @ToDate  varchar(75)='',     
 @FromDate  varchar(75)='',    
 @SearchStr varchar(100) = '',  
 @DateMode varchar(5)='',    
 @payerID int = 0,  
 @SearchPattern varchar(4) = '=', /** = or % **/        
 @LocationId int=1       --added by mallikarjun.nam        
)         
AS  
BEGIN  
Set Transaction Isolation level Read Uncommitted;        
 /*        
  purpose :To select the Batch details by custmerId        
  createdBy: Bhuvaneswari       
  CreatedDt: 23/July/2013        
  ipmact to :MangeUpload.aspx  
  
  Modified By : Kathiravan.kand  
  Modified Dt : 02/28/2015  
  Purpoder    : Payer name added in filer   
  
  Modified By : mallikarjun.nam        
  Modified Dt : 2015-01-07         
  Purpoder    : Batch Comments are added        
    
  Modified By : mallikarjun.nam  
  Modified Dt : 2016-05-03  
  Purpoder    : Allowing direct upload for only Skip audit Qc users proccessed batches  
                and Showing only QC pending batches ,Refer SCR #841  
    
  Modified By : mallikarjun.nam  
  Modified Dt : 2016-06-06  
  Purpoder    : To exception automation bucket from direct upload  
  Ticket Id :147880,147148  
    
  Implemented By : Hemanath  
  Implemented On :2016-06-06  
    
  Modified By : mallikarjun.nam  
  Modified Dt : 2016-08-22  
  Purpoder    : To restrict duplicate entries in report  
  Ticket Id :160007  
    
  Implemented By : Narayana  
  Implemented On :2016-08-22  
  
   Modified By : mallikarjun.nam  
  Modified Dt : 2018-03-19  
  Purpoder    : To restrict duplicate entries in report  
  Ticket Id :160007  
    
  Implemented By : Narayana  
  Implemented On :2018-03-19  
    
*/   
/*  
  Declare @Action varchar(100)='SearchBatches',      
  @CmpKey varchar(20)='OFF',       
  @Userid int=3498,        
  @ClientID  int=0,     
  @ServiseID   int=0,  
  @BatchNO nvarchar(50)='220125A7363',         
  @ToDate  varchar(75)='2017-11-07',     
  @FromDate  varchar(75)='2017-11-05',    
  @SearchStr varchar(100) = '',  
  @DateMode varchar(5)='D',    
  @payerID int = 0,  
  @SearchPattern varchar(4) = '=', /** = or % **/        
  @LocationId int=0    
  */  
  declare @CustomerId as int         
  select @CustomerId = CustomerId from ADM_Customer where CmpKey = @CmpKey      
    
   declare @FromScanDate as datetime,  
   @ToScanDate as datetime,  
   @FromDownloadDate as datetime,  
   @ToDownloadDate as datetime  
        
if(@DateMode = 'D')  
    BEGIN  
    set  @FromScanDate  = convert(date,'1900-01-01')  
    set @ToScanDate  = DateAdd(day, 1, GETDATE())  
    set @FromDownloadDate =  convert(date,@FromDate)  
    set @ToDownloadDate = convert(date,@ToDate)  
    END  
      ELSE IF (@DateMode = 'S')  
    BEGIN  
    set  @FromScanDate  =  convert(date,@FromDate)  
    set @ToScanDate  =  convert(date,@ToDate)  
    set @FromDownloadDate =  convert(date,'1900-01-01')  
    set @ToDownloadDate = DateAdd(day, 1, GETDATE())  
    END  
      
      
      
    /* Code written by mallikarjun.nam  */       
        
  if OBJECT_ID('tempdb..#UserLocation') is not null drop table #UserLocation     
  Create table #UserLocation( locationid int,LocationName varchar(50))        
    
  insert into  #UserLocation(locationId,LocationName)        
  exec ADM_GetUserLocation @userid,@LocationId        
   
 if OBJECT_ID('tempdb..#QCManBatchIds') is not null drop table #QCManBatchIds  
  select distinct bat.BatchId into #QCManBatchIds  
  from TRN_kOFF_tBatches (nolock) bat  
  inner join TRN_kOFF_tBatchflow (nolock) flow  on bat.BatchId=flow.BatchId and flow.StatusId=6  
  inner join ADM_QCAuditSkipUsers (nolock) qcaudit on qcaudit.UserId=flow.CreatedBy and qcaudit.Status=1  
  inner join #UserLocation as loc on bat.LocationId=loc.LocationId /* code added by mallikarjun  */      
  where bat.PostedDt is not null and bat.Status = 1 and AuditedDt is null and bat.UploadDt is null    
  AND  DATEADD(day, DATEDIFF(day, 0, bat.CreatedDt), 0) between  @FromDownloadDate  and @ToDownloadDate  
  AND  DATEADD(day, DATEDIFF(day, 0, ScanDate), 0)  between  @FromScanDate and  @ToScanDate  
  AND ISNULL(bat.PayerId, 0 ) = (case when ISNULL(@payerID,0) <> 0 then @payerID else  ISNULL(bat.PayerId,0) end)  
  AND  bat.ClientId = case when isnull(@ClientID,0) <> 0 then @ClientID  else bat.ClientId   END  
  AND bat.ServiceId = case when isnull(@ServiseID,0) <> 0 then @ServiseID else bat.ServiceId  END  
  AND bat.BatchNO = case when isnull(@BatchNO,'') <> '' then @BatchNO  else bat.BatchNO end 
  AND not exists (select 1 from TRN_kOFF_tBatchQueue where BatchId=bat.BatchId and StatusId=7)/*Added by mallikarjun.nam for SCR841*/ 
  AND not exists (select 1 from TRN_kOFF_tHeldBatches  (nolock) where BatchId=bat.BatchId and ReleaseDate is null)/*Added by mallikarjun.nam for SCR841*/  
  /*and not exists (Select 1 from ADM_DirectUploadExceptional (nolock) Where ServiceId = bat.ServiceId and Status = 1)  */
    
      
      
 if OBJECT_ID('tempdb..#DirectUpload') is not null drop table #DirectUpload      
 select (Case when isnull(tmp.BatchId,0)>0 then '' else x.chk end) as chkbatches  
,BatchNo,ClientId as [ClientId ~Hide],ClientAcmName,ServiceId as [ServiceId ~Hide],ServiceName,PgCount,  
convert(varchar,DownloadDt,101 ) as DownloadDt,convert(varchar,ScanDate,101 ) as ScanDate,  
UI.NT_USERNAME AssignedBy  
,UI.REPORTING_TO [Supervisor]  
/*--,sup.NT_USERNAME [Supervisor]*/  
,(select SUM(TransValue) from TRN_kOFF_tBatchTransact (nolock) where BatchId = x.BatchId) as TransCount,  
StatusCaption as Status ,PayerName  
,flow.Comments  as Comments  
/*,case when held.BatchId is not null then held.HeldComment  else flow.Comments end as Comments*/  
into #DirectUpload  
from  
(  
  select  '<input type="checkbox" class="chkbatches" id="' + cast(bat.BatchId as varchar)+'">' as chk,bat.BatchId,bat.BatchNo,bat.ScanDate,bat.CreatedDt as DownloadDt  
  ,bat.ClientId,cli.ClientAcmName,bat.ServiceId,ser.ServiceName,bat.PgCount,  
  /*--(select top 1  dbo.TRN_kOFF_fnGetBatchCurrentStatus(cast(bat.BatchId as varchar)) from TRN_kOFF_tBatches) AS StatusCaption,  */    
  dbo.TRN_kOFF_fnGetBatchCurrentStatus(bat.BatchId) as StatusCaption,  
  (Select top 1 flowid from trn_kOFF_tbatchflow (nolock) where BatchId = bat.BatchId and StatusId = 6  order by flowid desc) as FlowId,  
  (select PayerName from ADM_PayerName_View (nolock) where PayerId = bat.PayerId) as PayerName--,q.BatchProcessId   
  from TRN_kOFF_tBatches (nolock) bat  
  /*--inner join TRN_kOFF_tBatchQueue (nolock) q on q.BatchId =  bat.BatchId  */    
  inner join ADM_Client (nolock) cli on cli.ClientId = bat.ClientId and cli.CustomerId = @CustomerId  
  inner join ADM_Service (nolock) ser on ser.ServiceId = bat.ServiceId   
  inner join #UserLocation as loc on bat.LocationId=loc.LocationId /* code added by mallikarjun  */  
  where bat.PostedDt is not null and bat.Status = 1 and AuditedDt is null and bat.UploadDt is null    
  AND  DATEADD(day, DATEDIFF(day, 0, bat.CreatedDt), 0) between  @FromDownloadDate  and @ToDownloadDate  
  AND  DATEADD(day, DATEDIFF(day, 0, ScanDate), 0)  between  @FromScanDate and  @ToScanDate  
  AND ISNULL(bat.PayerId, 0 ) = (case when ISNULL(@payerID,0) <> 0 then @payerID else  ISNULL(bat.PayerId,0) end)  
  AND  bat.ClientId = case when isnull(@ClientID,0) <> 0 then @ClientID  else bat.ClientId   END  
  AND bat.ServiceId = case when isnull(@ServiseID,0) <> 0 then @ServiseID else bat.ServiceId  END  
  AND bat.BatchNO = case when isnull(@BatchNO,'') <> '' then @BatchNO  else bat.BatchNO end 
  AND not exists (select 1 from TRN_kOFF_tBatchQueue where BatchId=bat.BatchId and StatusId=7)/*Added by mallikarjun.nam for SCR841*/ 
  AND not exists(select 1 from TRN_kOFF_tHeldBatches (nolock) where BatchId=bat.BatchId and ReleaseDate is null)/*Added by mallikarjun.nam for SCR841*/  
  /*and not exists (Select 1 from ADM_DirectUploadExceptional (nolock) Where ServiceId = bat.ServiceId and Status = 1)  */
    
)x   
 left join TRN_kOFF_tBatchFlow (nolock) as flow on flow.FlowId = x.FlowId   
 left join ARC_REC_Athena..ARC_REC_USER_INFO (nolock)  UI on UI.USERID = flow.CreatedBy  
 left join #QCManBatchIds tmp on tmp.BatchId=x.BatchId  
   
  
 Exec FilterTable  
 @DbName = 'tempdb'  
,@TblName = '#DirectUpload'  
,@SearchStr = @SearchStr  
,@SearchPattern = @SearchPattern  
,@OrderStr = ''  
  
if OBJECT_ID('tempdb..#DirectUpload') is not null drop table #DirectUpload   
if OBJECT_ID('tempdb..#UserLocation') is not null drop table #UserLocation   
if OBJECT_ID('tempdb..#QCManBatchIds') is not null drop table #QCManBatchIds  
END 


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_KOFF_pDirectUploadSearch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_KOFF_pDirectUploadSearch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_KOFF_pDirectUploadSearch] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_KOFF_pDirectUploadSearch] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_KOFF_pDirectUploadSearch] TO [DB_DMLSupport]
    AS [dbo];

