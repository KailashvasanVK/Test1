﻿CREATE Procedure  CUS_kGreen_tBatchInfoValuesInsert
(
@BatchNum varchar(50)
,@SubClient varchar(50)
,@Accountno varchar(50) 
,@PTLastName  varchar(50) 
,@PTFirstName varchar(50) 
,@POS   varchar(50) 
,@AdmitDt  varchar(50) 
,@DOS  varchar(50) 
,@PeromingDoc  varchar(50) 
,@CreatedBy varchar(50) 
)
as
  Begin
     select * from ADM_Service 
  End	



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kGreen_tBatchInfoValuesInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kGreen_tBatchInfoValuesInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kGreen_tBatchInfoValuesInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kGreen_tBatchInfoValuesInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kGreen_tBatchInfoValuesInsert] TO [DB_DMLSupport]
    AS [dbo];

