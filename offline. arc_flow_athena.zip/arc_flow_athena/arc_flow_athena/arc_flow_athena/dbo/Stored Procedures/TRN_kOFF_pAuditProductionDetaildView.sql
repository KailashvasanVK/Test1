﻿
CREATE Procedure TRN_kOFF_pAuditProductionDetaildView  
(
	@FromDate date ='2015-01-01',
	@ToDate date = '2015-01-20',	
	@CmpKey varchar(5)= 'OFF',
	@UserId int =3598,
	@RptType varchar(1) ='T',
	@BatchServiceId int = 0,
	@SearchStr varchar(100) = ''  ,
	@SearchPattern varchar(4) = '=' /** = or % **/  
)
As
begin
/*
		Created By : Kathiravan.kand	
		Created Dt : 26/12/2014
		Purpose    : to get the consolidated production details
*/
	/*Declare @FromDate date ='2015-01-01'
	Declare @ToDate date = '2015-01-10'
	--Declare @CustomerId int  = 25
	Declare @CmpKey varchar(5)= 'OFF'
	Declare @UserId int =  3500 --3598 
	Declare @RptType varchar(1) ='T'
	Declare @batchSErviceId int = 0
	Declare	@SearchStr varchar(100) = ''  
	Declare @SearchPattern varchar(4) = '=' /** = or % **/  */
 
    Declare @qry varchar(max) = ''
	Declare @Supervisor varchar(50)=''	
	Declare @CustomerId int  
	if(ISNULL(@UserId,0)) <> 0 
		select @Supervisor = NT_USERNAME  from ARC_REC_Athena..ARC_REC_USER_INFO  where USERID = @UserId and AHS_PRL = 'Y' and ACTIVE =1
	   Select @CustomerId =  CustomerId  from ADM_customer where CmpKey = @CmpKey  

	if OBJECT_ID('tempdb..#ProdRptAssociateWiseTrans') is not null drop table #ProdRptAssociateWiseTrans
	if OBJECT_ID('tempdb..#ProdRptAssociateWiseTransQc') is not null drop table #ProdRptAssociateWiseTransQc
	if OBJECT_ID('tempdb..#Associate_Target') is not null drop table #Associate_Target
	if OBJECT_ID('tempdb..#Associate_ErrorTarget') is not null drop table #Associate_ErrorTarget
	if OBJECT_ID('tempdb..#UserCustomerList') is not null drop table #UserCustomerList
	if OBJECT_ID('tempdb..#ProdRptResult') is not null drop table #ProdRptResult
	
	if OBJECT_ID('tempdb..#AssociateEntryErrorCount') is not null drop table #AssociateEntryErrorCount
		Create Table #AssociateEntryErrorCount(FTE_Id int,ErrCount int)
	if OBJECT_ID('tempdb..#AssociateQCErrorCount') is not null drop table #AssociateQCErrorCount
	    Create Table #AssociateQCErrorCount(FTE_Id int,ErrCount int,BatchNo varchar(75))
    if OBJECT_ID('tempdb..#EntryAssociateQCedTransCount') is not null drop table #EntryAssociateQCedTransCount
	     Create Table #EntryAssociateQCedTransCount(FTE_Id int,TransCount int) 
	
	 
	Create table #UserCustomerList(UserId int,Active int,Nt_UserName varchar(50),REPORTING_TO varchar(50))	
	insert into #UserCustomerList(UserId,Active,Nt_UserName,REPORTING_TO)
	select  distinct ucust.UserId,ui.ACTIVE,ui.NT_USERNAME,ui.REPORTING_TO from ARC_REC_Athena..ARC_REC_UserCustomer ucust 
	inner join ARC_REC_Athena..ARC_REC_USER_INFO ui  on ui.USERID = ucust.UserId and ui.REPORTING_TO = case when @Supervisor <> '' then @Supervisor else REPORTING_TO end
	where  ucust.CustomerID =@CustomerId 
 

	Create Table #ProdRptAssociateWiseTrans(funt varchar(20),NtName varchar(75),UserId int,ClientId int,ServiceId int,ServiceName varchar(50),EntryTransCnt int,
	QcTransCnt int,EntryFactorPer decimal(10,2),QcFactorPer decimal(10,2),EntryDate date,BatchServiceId int,EntryBatchCount int,QcBatchCount int,Error decimal,ErrorPer decimal,BatchId int,ErrTgt decimal(16,2),BatchProcessId int ) 

	Create Table #ProdRptAssociateWiseTransQc(funt varchar(20),NtName varchar(75),UserId int,ClientId int,ServiceId int,ServiceName varchar(50),EntryTransCnt int,
	QcTransCnt int,EntryFactorPer decimal(10,2),QcFactorPer decimal(10,2),EntryDate date,BatchServiceId int,EntryBatchCount int,QcBatchCount int,Error decimal,ErrorPer decimal,BatchId int,ErrTgt decimal(16,2),BatchProcessId int )  
	 
	Insert into #ProdRptAssociateWiseTransQC(funt,NtName,UserId,ClientId,ServiceId,ServiceName,EntryTransCnt,EntryFactorPer,QcFactorPer,
	EntryDate,BatchServiceId,EntryBatchCount,QcBatchCount,BatchId,BatchProcessId)
	Select batTrans.fun,NtName,UserId,ClientId,batTrans.ServiceId,ServiceName,sum(ProTransCnt) as EntryTransCnt	 
	,(Select FactorValue from ADM_Factor as fact Where fact.CustomerId = @CustomerId and fact.ClientId = batTrans.ClientId 
	and fact.ServiceId = batTrans.ServiceId and EntryDate between fact.EffectiveFrom and Cast(isnull(fact.EffectiveTo,getdate()) as DATE)
	and fact.FactorType = 1
	) EntryFactor
	,(Select FactorValue from ADM_Factor as fact Where fact.CustomerId = @CustomerId and fact.ClientId = batTrans.ClientId
	and fact.ServiceId = batTrans.ServiceId and EntryDate between fact.EffectiveFrom and Cast(isnull(fact.EffectiveTo,getdate()) as DATE)
	and fact.FactorType = 2
	) QcFactor 
	,EntryDate,BatchServiceId ,EntryBatchCount,0,batTrans.BatchId as BatchId,batTrans.BatchProcessId  
	from 
	(
		Select 'Audit' as fun ,ui.NT_UserName as NtName,batTrans.FTE_Id as UserId,que.ClientId,batTrans.ServiceId,ser.ServiceName
		,Sum(TransValue) as ProTransCnt,0 as EntryBatchCount
		,Cast(getdate() as date) as EntryDate,que.ServiceId as BatchServiceId,que.BatchProcessId,que.BatchId
		from TRN_kOFF_tBatchQCMaster as batTrans
		inner join TRN_kOFF_tBatchQCComments qc on qc.BatchProcessId = batTrans.BatchProcessId
		inner join TRN_kOFF_tBatchQueue as que on que.BatchProcessId = batTrans.BatchProcessId  and que.ServiceId =  case when isnull(@BatchServiceId,0) <> 0 then @BatchServiceId 
		else que.ServiceId end
		inner join ADM_Service as ser on ser.ServiceId = batTrans.ServiceId and ser.FieldType = 'T'
		inner join ARC_REC_Athena..ARC_REC_User_Info as ui on ui.userid = batTrans.CreatedBy  --and REPORTING_TO =case when ISNULL(@Supervisor,'') <> '' then @Supervisor else  ui.REPORTING_TO end
		Where Cast(batTrans.CreatedDt as date) Between @FromDate and @ToDate and  batTrans.CreatedBy = @UserId
		Group by ui.NT_USERNAME,batTrans.FTE_Id,que.ClientId,batTrans.ServiceId,ser.ServiceName,batTrans.TransValue, que.ServiceId,que.BatchProcessId,que.BatchId
	)batTrans
	Group by  batTrans.fun,batTrans.NtName,UserId,ClientId,batTrans.ServiceId,ServiceName,EntryDate,BatchServiceId,EntryBatchCount,batTrans.BatchProcessId,batTrans.BatchId	
 
 
	insert into #AssociateEntryErrorCount(FTE_Id,ErrCount)
	select cm.FTE_Id, sum(isnull(ErrCount,0)) as ErrCount from TRN_kOFF_tBatchQCTran trn 
	inner join TRN_kOFF_tBatchQCComments cm on cm.BatchProcessId =  trn.BatchProcessId and CAST(cm.CreatedDt as date) between @FromDate and @ToDate 
	inner join TRN_kOFF_tBatchQueue as que on que.BatchProcessId = cm.BatchProcessId-- and que.ServiceId = @batchSErviceId
	Where exists (Select 1 from #ProdRptAssociateWiseTrans where UserId = cm.FTE_Id )
	Group by cm.FTE_Id 
		
	insert into #AssociateQCErrorCount(FTE_Id,ErrCount,BatchNo)
	select cm.FTE_Id, sum(isnull(ErrCount,0)) as ErrCount,que.BatchNo from TRN_kOFF_tBatchQCTran trn 
	inner join TRN_kOFF_tBatchQCComments cm on cm.BatchProcessId =  trn.BatchProcessId and CAST(cm.CreatedDt as date) between @FromDate and @ToDate 
	inner join TRN_kOFF_tBatchQueue as que on que.BatchProcessId = cm.BatchProcessId-- and que.ServiceId = @batchSErviceId
	Where exists (Select 1 from #ProdRptAssociateWiseTransQC where UserId = cm.FTE_Id )
	Group by cm.FTE_Id,que.BatchNo
	
	insert into #EntryAssociateQCedTransCount(FTE_Id,TransCount) 
	 select cm.FTE_Id, sum(TransValue) as QcedTrans from TRN_kOFF_tBatchQCMaster mas 
	inner join TRN_kOFF_tBatchQCComments cm on cm.BatchProcessId =  mas.BatchProcessId and CAST(cm.CreatedDt as date) between @FromDate and @ToDate 
	inner join TRN_kOFF_tBatchQueue as que on que.BatchProcessId = cm.BatchProcessId-- and que.ServiceId = @batchSErviceId
	Where exists (Select 1 from    #ProdRptAssociateWiseTrans  where UserId = cm.FTE_Id )
	Group by cm.FTE_Id 
	
	update  ulist
	set ulist.Active = 1
	from #UserCustomerList ulist 
	left join #ProdRptAssociateWiseTrans trn on trn.UserId = ulist.UserId
	
	update  ulist
	set ulist.Active = 1
	from #UserCustomerList ulist 
	left join #ProdRptAssociateWiseTransQc trn on trn.UserId = ulist.UserId 
	
	update  #ProdRptAssociateWiseTransQc  set  QcTransCnt = 0 
	
	select  distinct tgt.UserId,isnull(sum(tgt.ProductionTarget),0) as ProductionTarget  into #Associate_Target 
	from ADM_AssociateTarget tgt
	inner  join 	
	(select distinct UserId from  #ProdRptAssociateWiseTrans 
	) tmp on tmp.UserId = tgt.UserId -- and tmp.BatchServiceId  =  tgt.ServiceId
	where  tgt.EntryDate  between @FromDate and @ToDate and tgt.IsWorkingDay =1   
	group by tgt.UserId	 
	
	select distinct acc.UserId ,isnull(acc.ErrorPercentage,0) as ErrorTarget
	into  #Associate_ErrorTarget   from ADM_AccessTarget acc
	where UserId =@UserId group  by acc.ErrorPercentage, acc.UserId

	Declare @EntryServiceCollection varchar(max)
	Set @EntryServiceCollection = (Select 
	',Sum(Case when ServiceId = '+Convert(varchar,ServiceId)+' then EntryTransCnt else 0 end) as ['+ServiceName +']'
	from #ProdRptAssociateWiseTrans as t where funt = 'Entry' Group by ServiceId,t.ServiceName Order by t.ServiceName
	for xml path('')
	) 
	
	Set @EntryServiceCollection = ISNULL(@EntryServiceCollection,'')

	Declare @QcServiceCollection varchar(max)
	Set @QcServiceCollection = (Select 
	',Sum(Case when t.ServiceId = '+Convert(varchar,ServiceId)+' then EntryTransCnt else 0 end) as ['+ServiceName +']'
	from #ProdRptAssociateWiseTransQc as t where funt = 'Audit' Group by ServiceId,t.ServiceName Order by t.ServiceName
	for xml path('')
	)
	Set @QcServiceCollection = ISNULL(@QcServiceCollection,'')	 	 

	Set @qry = '

	Select Convert(varchar,ROW_NUMBER() over(order by [batchNo])) as [SNo]
	,x.*
	into #ProdRptResult
	from
	(
	Select  ''<a href="PdfViewer.aspx?file=''+bat.FName+''" target="_newtab"> ''+'+'bat.batchNo'+'+''</a>'' as batchNo
	' + @QcServiceCollection +  '
	,isnull((select ErrCount from #AssociateQCErrorCount where FTE_Id =t.UserId and BatchNo = bat.batchNo),0) as Error
	,sum(EntryTransCnt)as [Total Raw Trans]
	from  #ProdRptAssociateWiseTransQc as t  
	inner join TRN_KOFF_tbatches bat on bat.BatchId = t.batchId 
	Group by t.UserId,t.funt,t.Batchid,bat.batchNo,bat.FName 
	)x

	select * from #ProdRptResult  
	
	if OBJECT_ID(''tempdb..#ProdRptAssociateWiseTrans'') is not null drop table #ProdRptAssociateWiseTrans
	if OBJECT_ID(''tempdb..#ProdRptAssociateWiseTransQc'') is not null drop table #ProdRptAssociateWiseTransQc
	if OBJECT_ID(''tempdb..#Associate_Target'') is not null drop table #Associate_Target
	if OBJECT_ID(''tempdb..#Associate_ErrorTarget'') is not null drop table #Associate_ErrorTarget
	if OBJECT_ID(''tempdb..#ProdRptResult'') is not null drop table #ProdRptResult'
	print (@qry)
	exec (@qry)
 End	
	
	
	
	 
	 





GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pAuditProductionDetaildView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pAuditProductionDetaildView] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pAuditProductionDetaildView] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pAuditProductionDetaildView] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pAuditProductionDetaildView] TO [DB_DMLSupport]
    AS [dbo];

