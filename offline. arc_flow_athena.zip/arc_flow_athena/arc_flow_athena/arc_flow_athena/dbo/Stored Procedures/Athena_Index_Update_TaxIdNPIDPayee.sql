﻿CREATE  Proc Athena_Index_Update_TaxIdNPIDPayee(@NPI varchar(30)=NULL,@TaxID varchar(30)=NULL,@Payeeno varchar(30)=NULL,@SubClient varchar(12)=NULL,@NtUserName varchar(100)=NULL)    
as    
/*    
Update information if not available    
Aug 17,2015    
*/    
BEGIN    
IF NOT EXISTS(SELECT 1 FROM Arc_Athena..NPI_Automation where NPI=@NPI and Subclient=@SubClient)    
BEGIN    
IF(@NPI <> '' or @NPI is not NULL)  
INSERT INTO Arc_Athena..NPI_Automation(NPI,Subclient,CreatedBy,CreatedDate)Values(@NPI,@SubClient,@NtUserName,GETDATE())    
END    
IF NOT EXISTS(SELECT 1 FROM Arc_Athena..TaxID_Automation where TaxID =@TaxID  and Subclient=@SubClient)    
IF(@TaxID <> '' or @TaxID is not NULL)  
BEGIN    
INSERT INTO Arc_Athena..TaxID_Automation(TaxID,Subclient,CreatedBy,CreatedDate)Values(@TaxID,@SubClient,@NtUserName,GETDATE())    
END    
IF NOT EXISTS(SELECT 1 FROM Arc_Athena..Payee_Automation where Payee =@Payeeno  and Subclient=@SubClient)    
BEGIN    
IF(@Payeeno <> '' or @Payeeno is not NULL)  
INSERT INTO Arc_Athena..Payee_Automation(Payee,Subclient,CreatedBy,CreatedDate)Values(@Payeeno,@SubClient,@NtUserName,GETDATE())    
END    
END

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_Update_TaxIdNPIDPayee] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_Update_TaxIdNPIDPayee] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_Update_TaxIdNPIDPayee] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_Update_TaxIdNPIDPayee] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_Update_TaxIdNPIDPayee] TO [DB_DMLSupport]
    AS [dbo];

