﻿CREATE Procedure [dbo].[ADM_GetClientsServices]      
As      
begin      
    
/*      
Purpose           : To get occupied services by clients  
Created By        : Bhuvaneswari      
Created Date      : 30 Mar 2013      
Impact to         : ClientsServiceConfiguration.aspx      
*/    
    
    
 select ServiceId,ServiceName,ServiceAcmName,Description from ADM_Service where ServiceId in (      
 select DISTINCT(ServiceId) from ADM_ClientServices where [Status] = 1) and [Status] = 1
 
end


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_GetClientsServices] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetClientsServices] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetClientsServices] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_GetClientsServices] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetClientsServices] TO [DB_DMLSupport]
    AS [dbo];

