﻿CREATE Procedure TRN_kOFF_pBatchProcessSubmit
(            
@pCustomerId int            
,@pBatchProcessId int            
,@pStatus varchar(1) /* (C)omplete/(H)eld/(I)ncomplete */            
,@pComments varchar(max)            
,@pWF_ServiceId int            
,@pCreatedBy int            
)            
as            
Begin    
Begin Transaction    
Begin Try    
    
Declare @pCmpKey varchar(5)    
  Select @pCmpKey = CmpKey from ADM_Customer where CustomerId = @pCustomerId    
    
Declare @BatchId int,@FlowIdCompletedProcess int,@FlowId int,@BatchNo varchar(50),@ServiceId int,@ClientId int,@Qtype int,@EndPageNo int,@FromPageNo int,@EntryPageCount int,@BatchPageCount int    
,@ScanDate date    
,@BatchFName varchar(200)    
,@BatchNoOrginal varchar(50)    
,@BatchType int    
      
Declare @NewProcessPgFrom int            
Declare @PendingProcessId int            
Select @BatchId = BatchId,@BatchNo = BatchNo,@ServiceId = ServiceId,@ClientId = ClientId,@Qtype = QType,@EndPageNo = PageTo,@FromPageNo = PageFrom    
from TRN_kOFF_tBatchQueue with (updlock) where BatchProcessId = @pBatchProcessId      
Select @BatchPageCount = PgCount,@ScanDate = ScanDate,@BatchFname = FName,@BatchNoOrginal = BatchNo,@BatchType = BatchType    
from TRN_kOFF_tBatches with (updlock) where BatchId = @BatchId    
    
if (Select Count(*) from TRN_kOFF_tBatchFlow    
Where BatchProcessId = @pBatchProcessId And StatusId = 6) > 0    
 begin    
     RAISERROR('Entry already completed',16,1)    
     Return    
 end    
     
 begin    
  Select @EntryPageCount = (Select isnull(MAX(PageNo),0)    
   from (    
   Select Max(PageNo) as PageNo from TRN_kOFF_tBatchTransactMirror  where BatchProcessId = @pBatchProcessId /*@pBatchProcessId*/            
   Union all            
   Select MAX(PageNo) as PageNo from TRN_kOFF_tBatchIssueLogMirror where BatchProcessId = @pBatchProcessId /*@pBatchProcessId*/    
   )x      
   )      
  Insert into ADM_BatchTransactMirror(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,UpdatedBatchProcessId,ExtTransValue,ExtInfoValue,CmpKey)            
  Select BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,UpdatedBatchProcessId,ExtTransValue,ExtInfoValue,'OFF'          
  from TRN_kOFF_tBatchTransactMirror Where BatchProcessId = @pBatchProcessId /*@pBatchProcessId*/       
  and ISNULL(UpdatedBatchProcessId,0) = 0             
            
  /** Inserting new trans value from mirror to main */            
  Delete from TRN_kOFF_tBatchTransact Where BatchProcessId = @pBatchProcessId /*@pBatchProcessId*/      
  Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry)            
  Select BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,@BatchId,@ServiceId,@ClientId,0 as isQcEntry            
  from TRN_kOFF_tBatchTransactMirror Where BatchProcessId = @pBatchProcessId /*@pBatchProcessId*/       
  and ISNULL(UpdatedBatchProcessId,0) = 0      
            
  Delete from TRN_kOFF_tBatchTransactSummary Where BatchProcessId = @pBatchProcessId /*@pBatchProcessId*/      
  /** Inserting summary trans value from transact to summary */            
  Insert into TRN_kOFF_tBatchTransactSummary(BatchProcessId,ServiceId,TransValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId)            
  Select BatchProcessId,ServiceId,Sum(TransValue) as TransValue,@pCreatedBy  /*@pCreatedBy*/,GETDATE(),@BatchId,@ServiceId,@ClientId      
  from TRN_kOFF_tBatchTransact            
  Where BatchProcessId = @pBatchProcessId /*@pBatchProcessId*/ and TransValue <> 0    
  Group by BatchProcessId,ServiceId      
        
   /** Deleting inserted transaction */            
   Delete from TRN_kOFF_tBatchTransactMirror where BatchProcessId = @pBatchProcessId /*@pBatchProcessId*/           
        
  Insert into TRN_kOFF_tBatchFlow(BatchProcessId,BatchId,CreatedBy,CreatedDt,StatusId,Comments,Ref_FlowId)                 
  Select @pBatchProcessId,@BatchId,@pCreatedBy,GETDATE(),6,@pComments,0     
     
if (Select COUNT(*) from TRN_kOFF_tDirectUpload where Batchid = @BatchId and Status = 1) > 0    
 Begin    
 if (Select COUNT(*) from TRN_kOFF_tBatchFlow Where BatchId = @BatchId and StatusId = 13) = 0
	 Begin
	 Insert into TRN_kOFF_tBatchFlow(BatchProcessId,BatchId,CreatedBy,CreatedDt,StatusId,Comments,Ref_FlowId)                 
	 Select @pBatchProcessId,@BatchId,@pCreatedBy,GETDATE(),13,@pComments,0     
	 End
 Select @FlowId = IDENT_CURRENT('TRN_kOFF_tBatchFlow')    
 Update TRN_kOFF_tBatchQueue Set FlowId = @FlowId,StatusId = 13,Comment = @pComments,Assigned=0 where BatchProcessId = @pBatchProcessId       
 update TRN_kOFF_tBatches set PostedDt = getdate(), UploadDt = GETDATE()  where BatchId =   @BatchId           
 End    
Else    
 Begin    
 Declare @SMEMinTrans int = 0    
 Declare @SMEMaxTrans int = 0    
 Select @SMEMinTrans = MinTrans ,@SMEMaxTrans  = MaxTrans from ADM_SMEToolReRouteTrans    
 Declare @TotalEntryTrans int = (Select Sum(TransValue) from TRN_kOFF_tBatchTransact where BatchProcessId = @pBatchProcessId)    
    if @ServiceId <> 356 /* Payer 3 */ and @ServiceId <> 370 /* Payer 4 */ and @ServiceId <> 363 /* RT */ and (@TotalEntryTrans <= @SMEMinTrans or (@TotalEntryTrans >= @SMEMaxTrans and @SMEMaxTrans <> 0))    
  Begin /* ReRoute to SME */    
  Insert into TRN_kOFF_tBatchFlow(BatchProcessId,BatchId,CreatedBy,CreatedDt,StatusId,Comments,Ref_FlowId)                 
  Select @pBatchProcessId,@BatchId,@pCreatedBy,GETDATE(),20,@pComments,0     
  Select @FlowId = IDENT_CURRENT('TRN_kOFF_tBatchFlow')    
  Update TRN_kOFF_tBatchQueue Set FlowId = @FlowId,StatusId = 20,Comment = @pComments,Assigned=0 where BatchProcessId = @pBatchProcessId      
  update TRN_kOFF_tBatches  set PostedDt = GETDATE()  where BatchId = @BatchId     
  End    
 else    
  Begin    
  Select @FlowId = IDENT_CURRENT('TRN_kOFF_tBatchFlow')    
  Update TRN_kOFF_tBatchQueue Set FlowId = @FlowId,StatusId = 6,Comment = @pComments,Assigned=0 where BatchProcessId = @pBatchProcessId      
  update TRN_kOFF_tBatches  set PostedDt = GETDATE()  where BatchId = @BatchId     
  End    
    End     
 End    
    
Commit Transaction    
End Try    
Begin Catch    
Rollback transaction    
End catch    
End



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pBatchProcessSubmit] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchProcessSubmit] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchProcessSubmit] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pBatchProcessSubmit] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchProcessSubmit] TO [DB_DMLSupport]
    AS [dbo];

