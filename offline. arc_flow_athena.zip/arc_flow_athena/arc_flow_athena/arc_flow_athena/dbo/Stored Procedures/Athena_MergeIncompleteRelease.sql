﻿

CREATE Proc [dbo].[Athena_MergeIncompleteRelease]  (@Status int,@scandate varchar(10))                                  
as                                     
begin         
      
/*                                
                            
Cretaed By     : Leela.T                            
Created Date   : 2017-04-10                             
Purpose        : Check  and release the Locked MergeBatches                             
Ticket/SCR ID  : 1195                           
TL Verified By : Udhayaganesh                       
             
Modified By :Leela.T      
Modified Purpose : Update the status if its partically Merged       
Modified Date   :2017-05-24             
                         
Implemented by : Udhdyaganesh.p                  
Implemented On : 10-April-2017                    
                            
Reviewd by     : Udhdyaganesh.p                           
Implemented On : 10-April-2017                                   
      
Implemented by : Narayana                  
Implemented On : 25-May-2017                    
                            
*/                                                    
                                  
DECLARE @BatchCount INT                          
IF(OBJECT_ID('tempdb.dbo.#Batchdets')is not null)                                                                            
DROP TABLE #Batchdets                                   
CREATE TABLE #Batchdets (Batchno VARCHAR(30))                                  
                                  
INSERT INTO #Batchdets                            
SELECT trn.batchno  FROM  trn_koff_tbatches (NOLOCK) trn                                  
LEFT JOIN mergebatchdetails (NOLOCK) mrg on trn.batchno=mrg.childbatchno                                                 
WHERE trn.status=99  and LEFT(batchno,1) NOT IN('M','S')                               
and trn.serviceid = CASE @Status WHEN 88 THEN  418 ELSE trn.Serviceid END              
and trn.serviceid <> CASE @Status WHEN 1 THEN 418 END                                         
and mrg.childbatchno is null  and CONVERT(DATE,trn.scandate)=CONVERT(DATE,@scandate)                                
SELECT @BatchCount=COUNT(Batchno) FROM #Batchdets                                  
                                  
IF (@BatchCount>0)       
BEGIN                                 
UPDATE trn_koff_tbatches SET STATUS=@Status WHERE BatchNo in (SELECT Batchno FROM #Batchdets)                                                              
DELETE FROM #Batchdets               
END                         
                          
INSERT INTO #Batchdets                                 
SELECT  DISTINCT ParentBatchNo  FROM mergebatchdetails(NOLOCK)  Mrg   
left join TRN_kOFF_tBatches(NOLOCK) trn  on mrg.ParentBatchNo=trn.batchno WHERE trn.batchno is null and                               
CONVERT(DATE,trn.scandate)=CONVERT(DATE,@scandate)  
SELECT @BatchCount=COUNT(Batchno) FROM #Batchdets                                       
                                  
IF (@BatchCount>0)                                  
BEGIN                                  
UPDATE trn SET STATUS=@Status FROM mergebatchdetails mrg inner join TRN_kOFF_tBatches trn                                  
ON mrg.childbatchno=trn.batchno WHERE ParentBatchNo in (SELECT batchno FROM #Batchdets)                                   
                                  
DELETE FROM mergebatchdetails WHERE ParentBatchNo in (SELECT Batchno FROM #Batchdets)                                
                                                    
END      
                              
DROP TABLE #Batchdets                                  
SELECT @BatchCount               
END      


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_MergeIncompleteRelease] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_MergeIncompleteRelease] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_MergeIncompleteRelease] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_MergeIncompleteRelease] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_MergeIncompleteRelease] TO [DB_DMLSupport]
    AS [dbo];

