﻿--ADM_GetClientsByServiceId 1,35
CREATE Procedure [dbo].[ADM_GetClientsByServiceId]      
      @ServiceId int,    
      @CustomerId int      
As      
begin    
/*  
  
Purpose           : To get clients who are all under the services  
  
Created By        : Bhuvaneswari  
  
Created Date      : 30 Mar 2013  
  
Impact to         : ClientsServiceConfiguration.aspx  
  
*/  
    
select c.ClientId,c.ClientName,Isnull(p.Price,0) as Price     
from ADM_ClientServices cs  
left join ADM_ClientServicePrice P on cs.ClientId = p.ClientId and cs.ServiceId = p.ServiceId    
inner join ADM_Client c on cs.ClientId = c.ClientId      
inner join ADM_Customer Cu on c.CustomerId = cu.CustomerId    
where cs.ServiceId  = @ServiceId and cu.CustomerId = @CustomerId     
end


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_GetClientsByServiceId] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetClientsByServiceId] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetClientsByServiceId] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_GetClientsByServiceId] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetClientsByServiceId] TO [DB_DMLSupport]
    AS [dbo];

