﻿CREATE Procedure [dbo].[ADM_ErrClassifySubMove]
@ClassifyId int 
As
/*
    Purpose		 : Move the Error sub classify data ADM_ErrClassifySub,ADM_ErrClassifyGroup from while update
    Created By   : Karthik IC  
    Created Date : 12 June 2013  
    Impact to    : ErrorClassification.aspx  
*/
Begin
If exists(select top 1 'x' from ADM_ErrClassifySub where SubClassifyId = @ClassifyId )
Begin
Insert into ADM_ErrClassifySublog  (SubClassifyId,SubClassifyName,Status,CreatedBy,CreatedDt )
Select SubClassifyId,SubClassifyName,Status,CreatedBy,CreatedDt from ADM_ErrClassifySub where SubClassifyId = @ClassifyId
Delete from ADM_ErrClassifySub where SubClassifyId = @ClassifyId
End
If exists(select top 1 'x' from ADM_ErrClassifyGroup where SubClassifyId = @ClassifyId )
Begin
Insert into ADM_ErrClassifyGrouplog  (ClassifyGroupId,ClassifyId,SubClassifyId,CreatedBy,CreatedDt )
Select ClassifyGroupId,ClassifyId,SubClassifyId,CreatedBy,CreatedDt from ADM_ErrClassifyGroup where SubClassifyId = @ClassifyId
Delete from ADM_ErrClassifyGroup where SubClassifyId = @ClassifyId
End
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ErrClassifySubMove] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ErrClassifySubMove] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ErrClassifySubMove] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ErrClassifySubMove] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ErrClassifySubMove] TO [DB_DMLSupport]
    AS [dbo];

