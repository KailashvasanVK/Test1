﻿CREATE Procedure [dbo].[ADM_ClientcreationActions]                  
@Action   varchar(75),                
@ClientId INT,                  
@CustomerId INT ,                
@ClientName varchar(50)                     
                  
AS                    
 /*                  
    Created By   : Kathiravan                  
    Created Date : 30 March 2013                  
    Impact to    :ClientCreation.aspx                  
 */                      
 BEGIN                  
                    
IF(@Action ='SelectInfoServices')                
 BEGIN                
  /*Purpose:To load a Infoservices*/                
  SELECT ServiceId,ServiceName FROM ADM_Service  WHERE Status = 1   and FieldType='I' order by ServiceName               
    END                 
ELSE IF(@Action='SelectTransServicesByCustId')          
BEGIN          
--Select distinct Ser.ServiceId,Ser.ServiceName,Ser.ServiceAcmName,Ser.Description  from ADM_ServiceGroup serGroup
--inner join ADM_Service as ser on ser.ServiceId = serGroup.ServiceGroupId and ser.FieldType = 'T' 
--inner join ADM_CustomerServices as cs on cs.ServiceId= ser.ServiceId and cs.CustomerId=@CustomerId
--Order by ser.ServiceName

Select Distinct Ser.ServiceId,Ser.ServiceName,Ser.ServiceAcmName,Ser.Description from ADM_Service as Ser            
inner join ADM_CustomerServices as cs on cs.ServiceId= ser.ServiceId          
where Ser.Status = 1  and Ser.FieldType = 'T' and cs.CustomerId=@CustomerId          
Order by Ser.ServiceName          
END          
      
ELSE IF(@Action='SelectAllTransServices')          
/*Purpose:To load all Transaction service for the customer */      
BEGIN          
Select Distinct Ser.ServiceId,Ser.ServiceName from ADM_Service as Ser            
inner join ADM_CustomerServices as cs on cs.ServiceId= ser.ServiceId          
where Ser.Status = 1  and Ser.FieldType = 'T'     
Order by Ser.ServiceName          
END          
      
ELSE IF(@Action='Clientcreationview')                  
 BEGIN                
  /*Purpose:To load a client details */                
  SELECT ClientId,ClientName,ClientAcmName,InternalName As CustomerName,t1.CustomerId  as CustomerId FROM ADM_Client t1                    
  LEFT JOIN   ADM_Customer t2 ON t2.CustomerId=t1.CustomerId                    
  WHERE t1.Status = 1 and  t1.CustomerId=@CustomerId            
    END                
                
ELSE IF (@Action='ClientDetailsGetByClientId')                
 BEGIN                  
     /*Purpose :To get a client details by ClientId*/                              
	SELECT CL.ClientName,CL.ClientAcmName,CL.CustomerId                  
	-- (SELECT COUNT(*) FROM ADM_ClientServices WHERE ClientId=@ClientId and ISNULL(Price,0)<>0)as Priceconfig                  
	FROM ADM_Client as CL  WHERE cl.ClientId = @ClientId                          

	select cs.ServiceId,ser.ServiceName,cs.DataType FROM ADM_ClientServices as cs                          
	INNER JOIN ADM_Service as ser on ser.ServiceId = cs.ServiceId                          
	WHERE cs.ClientId = @ClientId                          

	select sg.ServiceGroupId,gs.ServiceName as GroupName,sg.ServiceId,cs.ServiceName as ServiceName                           
	FROM ADM_ServiceGroup as sg                          
	INNER JOIN ADM_Service as gs on gs.ServiceId = sg.ServiceGroupId                          
	INNER JOIN ADM_Service as cs on cs.ServiceId = sg.ServiceId                          
	WHERE sg.ClientId = @ClientId                         
	order by sg.ServiceGroupId,sg.gid            

	Select Distinct Ser.ServiceId,Ser.ServiceName,Ser.ServiceAcmName,Ser.Description from ADM_Service as Ser            
	inner join ADM_ClientServices as cs on cs.ServiceId= ser.ServiceId          
	where Ser.Status = 1  and Ser.FieldType = 'T' and cs.ClientId=@ClientId         
	Order by Ser.ServiceName                
 END                 
ELSE IF(@Action='GetClientCountByCustomerId')                
   BEGIN                
    /*Purpose :To check  Existing Client Template(ConfigurationDetails) existance by CustomerId*/                        
     SELECT (SELECT ISNULL(COUNT(ClientId),0) FROM ADM_Client WHERE CustomerId =@CustomerId) as NumberOf_clients                 
   END                
                
ELSE IF(@Action ='ClientNameCheck')                 
 BEGIN                       
  /*Purpose :Check ClientName existance in Database*/     
  IF EXISTS (SELECT TOP 1 ClientName  FROM ADM_Client  WHERE  ClientName=@ClientName and CustomerId =@CustomerId )                      
   BEGIN                      
   SELECT 1                      
   END                  
  ELSE                      
   BEGIN                      
   SELECT 2                      
   END                        
 END                 
                    
ELSE  IF (@Action ='ClientAcmNameCheck')                  
 BEGIN                    
  /*Purpose :Check ClientAcmName existance in Database*/                     
 IF EXISTS (SELECT TOP 1 ClientAcmName  FROM ADM_Client  WHERE  ClientAcmName=@ClientName and CustomerId =@CustomerId )                      
  BEGIN                      
   SELECT 1                      
  END                      
 ELSE                      
  BEGIN                      
   SELECT 2                      
  END                        
 END                  
ELSE IF(@Action ='GetClientByCustomerId')                
 BEGIN                
 /*Purpose :To get a client details by CustomerId*/                 
 SELECT ClientId,ClientName FROM ADM_Client WHERE CustomerId=@ClientId and Status = 1                      
 END                
                           
 END






GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ClientcreationActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ClientcreationActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ClientcreationActions] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ClientcreationActions] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ClientcreationActions] TO [DB_DMLSupport]
    AS [dbo];

