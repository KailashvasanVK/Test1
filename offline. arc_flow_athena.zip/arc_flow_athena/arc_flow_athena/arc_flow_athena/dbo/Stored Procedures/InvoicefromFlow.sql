﻿CREATE Proc InvoicefromFlow 
as

declare @fromdate date = '2014-08-01'
declare @todate date = '2014-08-31'

if object_id('tempdb..#tmp') is not null drop table #tmp
select BatchProcessId,BatchId,Convert(int,0) as Valid
into #tmp
from ARC_Flow_Athena..TRN_kOFF_tBatchQueue
where batchid in (
select batchid from ARC_Flow_Athena..TRN_kOFF_tBatchQueue where Convert(date,createdDt) between @fromdate and @todate and serviceid = 355
group by batchid having count(*)>1
)

update #tmp set Valid = 1
from #tmp as t
inner join 
(
Select max(BatchProcessId) as bp,batchid
from #tmp
group by batchid
)x on x.bp = t.BatchProcessId


if object_id('tempdb..#tmpMonthTrans') is not null drop table #tmpMonthTrans
Select Convert(date,trn.CreatedDt) as TranDate,ser.ServiceName ,Sum(TransValue) as Tranaction 
into #tmpMonthTrans
from ARC_Flow_Athena..TRN_kOFF_tBatchTransact as trn
inner join ARC_Flow_Athena..ADM_Service as ser on ser.ServiceId = trn.ServiceId
where Convert(date,trn.createdDt) between @fromdate and @todate and BatchServiceid = 355
and isnull(batchprocessId,0) not in (Select isnull(BatchProcessId,0) from #tmp where valid <> 1)
Group by ser.ServiceName,Convert(date,trn.CreatedDt)


if object_id('tempdb..#tmpResult') is not null drop table #tmpResult
Select Distinct TranDate into #tmpResult from #tmpMonthTrans Order by TranDate

Select Convert(varchar,TranDate,101) as Trandate
,(Select Sum(Tranaction) from #tmpMonthTrans Where Trandate = t.TranDate and ServiceName = 'OffLine Collection') as [Collection]
,(Select Sum(Tranaction) from #tmpMonthTrans Where Trandate = t.TranDate and ServiceName = 'OffLine Exception Posting') as [Exception Posting]
,(Select Sum(Tranaction) from #tmpMonthTrans Where Trandate = t.TranDate and ServiceName = 'Offline Patient Creation') as [Patient Creation]
,(Select Sum(Tranaction) from #tmpMonthTrans Where Trandate = t.TranDate and ServiceName = 'OffLine Pmt') as [Pmt]
,(Select Sum(Tranaction) from #tmpMonthTrans Where Trandate = t.TranDate and ServiceName = 'OffLine Self Posting') as [Self Posting]
,(Select Sum(Tranaction) from #tmpMonthTrans Where Trandate = t.TranDate) as [Total]
from #tmpResult as t
union all
Select 'Total'
,(Select Sum(Tranaction) from #tmpMonthTrans Where ServiceName = 'OffLine Collection') as [Collection]
,(Select Sum(Tranaction) from #tmpMonthTrans Where ServiceName = 'OffLine Exception Posting') as [Exception Posting]
,(Select Sum(Tranaction) from #tmpMonthTrans Where ServiceName = 'Offline Patient Creation') as [Patient Creation]
,(Select Sum(Tranaction) from #tmpMonthTrans Where ServiceName = 'OffLine Pmt') as [Pmt]
,(Select Sum(Tranaction) from #tmpMonthTrans Where ServiceName = 'OffLine Self Posting') as [Self Posting]
,(Select Sum(Tranaction) from #tmpMonthTrans) as [Total]

Select trn.BatchId as InvoicedBatches
from ARC_Flow_Athena..TRN_kOFF_tBatchTransact as trn
inner join ARC_Flow_Athena..ADM_Service as ser on ser.ServiceId = trn.ServiceId
where Convert(date,trn.createdDt) between @fromdate and @todate and BatchServiceid = 355
Group by trn.BatchId

if object_id('tempdb..#tmp') is not null drop table #tmp
if object_id('tempdb..#tmpMonthTrans') is not null drop table #tmpMonthTrans
if object_id('tempdb..#tmpResult') is not null drop table #tmpResult



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[InvoicefromFlow] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[InvoicefromFlow] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[InvoicefromFlow] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[InvoicefromFlow] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[InvoicefromFlow] TO [DB_DMLSupport]
    AS [dbo];

