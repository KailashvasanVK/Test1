﻿Create Procedure ADM_ManualAllocationUserList 
( 
@Action Varchar(75), 
@ServiceId int = 0, 
@Customerid int = 0, 
@UserId int = 0 , 
@LocationID int =1
) 
As 
--ADM_ProfileAction @action = 'VerifyCustomer',@UserIdCollection = '3' 
Begin 
Declare @ErrMsg varchar(max) 
If @Action = 'GetTeamMembers'  
Begin 
	if OBJECT_ID('tempdb..#AssociateList') is not null drop table #AssociateList
	Create Table #AssociateList(UserId int,Name varchar(100))
		if (@userid = 335) 	--   NT_USERNAME = manigandan.j
			Begin  
			Insert into #AssociateList(UserId,Name) 		
			Select UserId,NT_USERNAME + ' (' + ui.EMPCODE + ')' as Name  from ARC_REC_Athena..ARC_REC_USER_INFO as ui
			Where -- Ui.Reporting_To = (Select Nt_UserName from ARC_REC_Athena..arc_Rec_user_info where userid = @UserId)	and 
			Ui.Active = 1 and Ui.Ahs_Prl = 'Y' and FUNCTIONALITY_ID in (1,2) and isnull(Ui.LocationID,1)=@LocationID				
		End 
		else if (@userid != 335)
		Begin  
			Insert into #AssociateList(UserId,Name) 
			Select UserId,NT_USERNAME + ' (' + ui.EMPCODE + ')' as Name  from ARC_REC_Athena..ARC_REC_USER_INFO as ui
			Where Ui.CLIENT_ID = 25 /*(Select Nt_UserName from ARC_REC_Athena..arc_Rec_user_info where userid = @UserId)*/
			and Ui.Active = 1 and Ui.Ahs_Prl = 'Y' and Ui.LocationID=@LocationID	

			if (Select COUNT(*) from ARC_FLOW_Athena..ADM_AccessFunctionality Where UserId = @UserId and Functionality = 'B') > 0
			Begin
				Insert into #AssociateList(UserId,Name) 
				Select Ui.UserId,ui.NT_USERNAME + ' (' + ui.EMPCODE + ')' as Name  from ARC_REC_Athena..ARC_REC_USER_INFO as ui
				Where Ui.Reporting_To in (Select REPORTING_TO from ARC_REC_Athena..arc_Rec_user_info where userid = @UserId)
				and Ui.Active = 1 and Ui.Ahs_Prl = 'Y' and Ui.LocationID=@LocationID	
				and exists (select 1 from ARC_REC_Athena..ARC_REC_UserCustomer where USERID = ui.USERID and CustomerID in (Select CustomerID from ARC_REC_Athena..ARC_REC_UserCustomer where USERID = @UserId))
			End 
		End 
	Select distinct UserId,Name from #AssociateList  group by UserId,Name Order by Name
End 

End 





GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ManualAllocationUserList] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ManualAllocationUserList] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ManualAllocationUserList] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ManualAllocationUserList] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ManualAllocationUserList] TO [DB_DMLSupport]
    AS [dbo];

