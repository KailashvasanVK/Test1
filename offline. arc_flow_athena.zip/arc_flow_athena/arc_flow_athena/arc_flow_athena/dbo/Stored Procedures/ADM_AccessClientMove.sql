﻿
CREATE  procedure  [dbo].[ADM_AccessClientMove]  
@UserId int,  
@CustomerId int  
As  
/*  
Created by : Karthik Ic  
Created on : 20 May 2013  
Impact to  : ProfileSetup.aspx  
Purpose    : To move  all data from log table and delete the data from customer wise client details table.  
Modified by : Kathiravan.kand
*/  
Begin  
if exists(Select top 1 'x' from ADM_AccessClient Where UserId=@UserId and CustomerId = @CustomerId)  
	Begin  
	/* Original Procedure start  */
		--Insert into ADM_AccessClientLog (UserId,ClientId,ServiceId,CreatedBy,CreatedDt,AccClientId,CustomerId)  
		--Select UserId,ClientId,ServiceId,CreatedBy,CreatedDt,AccClientId,CustomerId From  ADM_AccessClient Where UserId=@UserId  
		--Delete from ADM_AccessClient Where UserId=@UserId  and CustomerId = @CustomerId
	/* Original Procedure end  */
	 
	Delete from ADM_AccessClient Where UserId=@UserId  and CustomerId = @CustomerId

	End  
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_AccessClientMove] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessClientMove] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessClientMove] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_AccessClientMove] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessClientMove] TO [DB_DMLSupport]
    AS [dbo];

