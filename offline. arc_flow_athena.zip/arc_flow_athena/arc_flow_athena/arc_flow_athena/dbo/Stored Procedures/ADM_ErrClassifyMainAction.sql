﻿CREATE Procedure [dbo].[ADM_ErrClassifyMainAction]              
@Action varchar(50),            
@ClassifyId int = null,            
@SubClassifyId int =null,        
@ClassifyName varchar(100) = null,  
@Query varchar(max) = null,  
@Sort varchar(max) = null,
@displayStart int=0,    
@displayLength int =0,    
@RecCount int =0       
As  
/*                  
    Created By   : Karthik IC              
    Created Date : 12 June 2013              
    Impact to    : ErrorClassification.aspx              
*/              
Begin               
if @Action = 'GetClassification'              
/* Purpose : Get the main classify details */              
Begin              
 Select  ClassifyId,ClassifyName,status from  ADM_ErrClassifyMain               
 where ClassifyId = (case when @ClassifyId is null  then ClassifyId else @ClassifyId end )            
 order by ClassifyName               
End            
if @Action = 'GetSubClassification'              
/* Purpose : Get the sub classify details */              
Begin              
Select  SubClassifyId,SubClassifyName,status from  ADM_ErrClassifysub            
where SubClassifyId = (case when @SubClassifyId is null then SubClassifyId else @SubClassifyId end )            
order by SubClassifyName               
End               
if @Action = 'GetClassificationGroup'              
/* Purpose : Get the Group classify details using sub classify*/              
Begin              
Select  ClassifyId,SubClassifyId from  ADM_ErrClassifyGroup            
where SubClassifyId = (case when @SubClassifyId is null then SubClassifyId else @SubClassifyId end )            
and  ClassifyId = (case when @ClassifyId is null  then ClassifyId else @ClassifyId end )            
order by ClassifyId            
End           
if @Action = 'ValidateMainClassify'        
/* Purpose : To validate the Main Classify data is existing or not */        
Begin        
if exists(Select ClassifyName from  ADM_ErrClassifyMain Where ClassifyName = @ClassifyName and ClassifyId <> @ClassifyId)        
begin        
Select 1 as result -- Main Classify Exists        
End        
else         
begin         
Select 0 as result -- Main Classify Not exist        
End        
End  
if @Action = 'ValidateSubClassify'  
/* Purpose : To validate the Sub Classify data is existing or not */  
Begin  
if exists(Select SubClassifyName from  ADM_ErrClassifysub Where SubClassifyName = @ClassifyName and SubClassifyId <> @ClassifyId)  
begin  
Select 1 as result -- Main Classify Exists  
End   
else  
begin  
Select 0 as result -- Main Classify Not exist  
End  
End  
if @Action = 'GetClassifyDataToDisplay'  
/* purpose : To select all the error classification details */  
--Begin  
--Declare  @Qry varchar(max)  
--Set @Qry  ='Select  ClassifyName,SubClassifyName,status,Action from (  
--Select   AECM.ClassifyName , AECS.SubClassifyName ,  
--(case when AECM.Status = 0 then '+ '''InActive''' +'  
--   when AECS.Status = 0 then '+ '''InActive''' +' else  ' + '''Active''' + ' end )  as Status,   
--(case when AECM.ClassifyName  IS null  then '' ' + ' '' else ' +  
--''' <div style ="width:100%;"> <div style="float: left;padding-top:6px;" title="Click here to edit the ''' + ' + AECM.ClassifyName + '''+ '" ><a href ="#" class ="lnk" onclick= "return showDialog(&#39;Edit&#39;,&#39;Main&#39;,''' +'+  CONVERT (varchar(25)
--, AECM.ClassifyId)  + ''' + ');" ><span class="ui-icon ui-icon-pencil IconBackGround"></span></a></div><div style="float: left;">&nbsp;&nbsp;</div> ''' +' end)    
--+(case when AECS.SubClassifyName  IS null  then '' ' + ' '' else ' + '''<div style="float: left;padding-top:6px;" title ="Click here to edit the ''' + ' + AECS.SubClassifyName + '''+ '"><a href ="#" class ="lnk"  onclick= "return showDialog(&#39;Edit&#39;
--,&#39;Sub&#39;,'''+ '+  CONVERT (varchar(25), AECS.SubClassifyId)  + ''' + ');" ><span class="ui-icon ui-icon-document IconBackGround"></span></a></div></div> ''' + ' end)  as Action   
--from  ADM_ErrClassifyMain AECM   
--left join ADM_ErrClassifyGroup  AECG on AECG.ClassifyId =  AECM.ClassifyId   
--left join ADM_ErrClassifySub AECS on AECG.SubClassifyId =  AECS.SubClassifyId ) as tblclassify'        
--if(@Query<>'')  
--Set @qry += ' Where '+@Query+''  
--If(@Sort<>'')  
--Set @qry += ' '+@Sort+''  
---- Print ( @qry)        
--Exec  (@qry)  
--End  
Begin  
Declare  @Qry varchar(max)  
if @Sort = '' set @Sort = ' order by ClassifyName asc'  
if OBJECT_ID('tempdb..#TempClassify') is not null drop table #TempClassify  
  
Create table #TempClassify(  
 RowNumber int    
 ,ClassifyName varchar(50)  
 ,SubClassifyName varchar(50)  
 ,status varchar(10)  
 ,Action varchar(max))  
  
  
Set @Qry  ='  
insert into #TempClassify(RowNumber,ClassifyName,SubClassifyName ,status ,Action)  
SELECT ROW_NUMBER() OVER                            
 ('+@Sort+' )  AS RowNumber ,ClassifyName,SubClassifyName,status,Action from (  
Select   AECM.ClassifyName , AECS.SubClassifyName ,  
(case when AECM.Status = 0 then '+ '''InActive''' +'  
   when AECS.Status = 0 then '+ '''InActive''' +' else  ' + '''Active''' + ' end )  as Status,  
(case when AECM.ClassifyName  IS null  then '' ' + ' '' else ' +  
''' <div style ="width:100%;"> <div style="float: left;padding-top:6px;" title="Click here to edit the ''' + ' + AECM.ClassifyName + '''+ '" ><a href ="#" class ="lnk" onclick= "return showDialog(&#39;Edit&#39;,&#39;Main&#39;,''' +'+  CONVERT (varchar(25)

  
, AECM.ClassifyId)  + ''' + ');" ><span class="ui-icon ui-icon-pencil IconBackGround"></span></a></div><div style="float: left;">&nbsp;&nbsp;</div> ''' +' end)  
+(case when AECS.SubClassifyName  IS null  then '' ' + ' '' else ' +  
'''<div style="float: left;padding-top:6px;" title ="Click here to edit the ''' + ' + AECS.SubClassifyName + '''+ '"><a href ="#" class ="lnk"  onclick= "return showDialog(&#39;Edit&#39;,&#39;Sub&#39;,'''+ '+  CONVERT (varchar(25), AECS.SubClassifyId)  + 

  
''' + ');" ><span class="ui-icon ui-icon-document IconBackGround"></span></a></div></div> ''' + ' end)  as Action  
from  ADM_ErrClassifyMain AECM  
left join ADM_ErrClassifyGroup  AECG on AECG.ClassifyId =  AECM.ClassifyId  
left join ADM_ErrClassifySub AECS on AECG.SubClassifyId =  AECS.SubClassifyId and AECG.ClassifyId =  AECM.ClassifyId ) as tblclassify'  
if(@Query<>'')  
Set @qry += ' Where '+@Query+''  
If(@Sort<>'')  
begin  
Set @qry += ' '+@Sort+''  
End    
Print ( @qry)  
Exec  (@qry)  
  
SELECT @RecCount = COUNT(*) FROM #TempClassify             
        if @displayLength=-1 set @displayLength = @RecCount        
   Exec('select ClassifyName,SubClassifyName ,status ,Action from #TempClassify where RowNumber between '+@displayStart+' and '+@displayLength+'    
    SELECT RecCount = COUNT(*) FROM #TempClassify ')    
End 
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ErrClassifyMainAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ErrClassifyMainAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ErrClassifyMainAction] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ErrClassifyMainAction] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ErrClassifyMainAction] TO [DB_DMLSupport]
    AS [dbo];

