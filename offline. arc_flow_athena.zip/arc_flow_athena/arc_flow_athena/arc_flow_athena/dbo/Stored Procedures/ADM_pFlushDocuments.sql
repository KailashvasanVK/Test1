﻿CREATE Procedure ADM_pFlushDocuments
As
Begin
Delete from DocumentInfo Where docid in (Select docid from docs where docDate <= Convert(date,GETDATE()-7))
Delete from pges where pgeDate <= Convert(date,GETDATE()-7)
Delete from pdfs Where pdfDate <= Convert(date,GETDATE()-7)
Delete from docs where docDate <= Convert(date,GETDATE()-7)
End



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pFlushDocuments] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pFlushDocuments] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pFlushDocuments] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pFlushDocuments] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pFlushDocuments] TO [DB_DMLSupport]
    AS [dbo];

