﻿CREATE Proc dbo.DBD_TV_BatchStatus_Job

As

Declare @Sql varchar(max)='', @CmpKey Varchar(50)='OFF', @CustomerId int=15
Declare @RptDate date = convert(varchar,getdate(), 101)

Create table #BatchStatusRpt1(BatchStatus varchar(50),BatchCnt int,ServiceId int, CustomerId int)


	set @Sql='Insert into #BatchStatusRpt1(BatchStatus,CustomerId,BatchCnt,ServiceId)
	Select ''Completed'' as BatchStatus,'+convert(varchar,@CustomerId)+',Count(bat.BatchId) as BatchCnt ,ser.ServiceId
	from ARC_FLOW_ATHENA.dbo.TRN_k'+@CmpKey+'_tBatches as bat
	inner join ARC_FLOW_ATHENA.dbo.ADM_Service as ser on ser.ServiceId = bat.ServiceId
	Where Cast(bat.UploadDt as date) = '''+convert(varchar, @RptDate, 101)+'''
	and bat.status = 1
	Group by ser.ServiceId

	Insert into #BatchStatusRpt1(BatchStatus,CustomerId,BatchCnt,ServiceId)
	Select ''HeldToday'' as BatchStatus,'+convert(varchar,@CustomerId)+',COUNT(bat.BatchId) as BatchCnt,ser.ServiceId
	from ARC_FLOW_ATHENA.dbo.TRN_k'+@CmpKey+'_tHeldBatches as held
	inner join ARC_FLOW_ATHENA.dbo.TRN_k'+@CmpKey+'_tBatches as bat on held.BatchId = bat.BatchId and bat.status = 1
	inner join ARC_FLOW_ATHENA.dbo.ADM_Service as ser on ser.ServiceId = bat.ServiceId	
	Where cast(held.HeldDate as date) = '''+convert(varchar, @RptDate, 101)+'''  
	Group by ser.ServiceId

	Insert into #BatchStatusRpt1(BatchStatus,CustomerId,BatchCnt,ServiceId)
	Select ''Pending'' as BatchStatus,'+convert(varchar,@CustomerId)+',Count(bat.BatchId) as BatchCnt ,ser.ServiceId
	from ARC_FLOW_ATHENA.dbo.TRN_k'+@CmpKey+'_tBatches as bat
	inner join ARC_FLOW_ATHENA.dbo.ADM_Service as ser on ser.ServiceId = bat.ServiceId
	Left Join ARC_FLOW_ATHENA.dbo.TRN_k'+@CmpKey+'_tHeldBatches H on H.BatchId=bat.BatchId and H.ReleaseDate is null
	Where bat.UploadDt is null and H.BatchId is null
	and bat.status = 1 
	Group by ser.ServiceId' 

	exec(@Sql)


if exists (Select * from #BatchStatusRpt1 )
begin
	Delete from dbo.DBD_TV_Customer_BatchStatus
		--126 -Operations - Payments Posting Data Entry
	insert into DBD_TV_Customer_BatchStatus(CustomerId, FunctionalityId, BatchStatus, BatchCnt, CreatedDt)
	Select a.CustomerId, 126 as FunctionalityId, a.BatchStatus, sum(a.BatchCnt) BatchCnt, getdate() 
	from #BatchStatusRpt1 a inner join ARC_FLOW_ATHENA.dbo.ADM_Service b on a.ServiceId=b.ServiceId 
	group by a.CustomerId,  a.BatchStatus
	
end	

GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[DBD_TV_BatchStatus_Job] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[DBD_TV_BatchStatus_Job] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[DBD_TV_BatchStatus_Job] TO [DB_DMLSupport]
    AS [dbo];

