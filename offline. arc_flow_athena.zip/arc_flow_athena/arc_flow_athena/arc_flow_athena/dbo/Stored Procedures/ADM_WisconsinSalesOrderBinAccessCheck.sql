﻿CREATE Procedure  ADM_WisconsinSalesOrderBinAccessCheck
(
@UserId int,
@CustomerId int
)
as
Begin
     select COUNT(*) as AccCount from ADM_AccessServices  where  UserId =@UserId and ServiceId=193
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_WisconsinSalesOrderBinAccessCheck] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_WisconsinSalesOrderBinAccessCheck] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_WisconsinSalesOrderBinAccessCheck] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_WisconsinSalesOrderBinAccessCheck] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_WisconsinSalesOrderBinAccessCheck] TO [DB_DMLSupport]
    AS [dbo];

