﻿CREATE proc Athena_ReleaseMergeBatch (@scandate varchar(10), @MergeBatchno As [dbo].[MergeBatchList] Readonly)      
as      
begin      
update trn_koff_tbatches set status=1 where SUBSTRING(BatchNo,CHARINDEX('A',BatchNo)+1,(LEN(BatchNo)-CHARINDEX('A',BatchNo))+1)
in (select BatchNo from @mergeBatchno) and ScanDate=@scandate and status=99   and BatchNo not in 
 (select childbatchno from mergebatchdetails)
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_ReleaseMergeBatch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_ReleaseMergeBatch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_ReleaseMergeBatch] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_ReleaseMergeBatch] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_ReleaseMergeBatch] TO [DB_DMLSupport]
    AS [dbo];

