﻿CREATE Proc [dbo].[ADPMerge_GetFileDetails] @Batchno varchar(30)      
  as       
 begin      
       
   /*                            
                        
Cretaed By     : Leela.T                        
Created Date   : 2017-03-29                          
Purpose        : Get the PDF File Path              
Ticket/SCR ID  : 1195                       
TL Verified By : Udhayaganesh                   
                    
                     
Implemented by : Udhdyaganesh.p              
Implemented On : 10-April-2017                
                        
Reviewd by     : Udhdyaganesh.p                       
Implemented On : 10-April-2017                          
                        
*/      
 select Replace(Fname,'\\fs-ib','\\fs-cbe') from trn_koff_tbatches where batchno=@Batchno     
       
 End    

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADPMerge_GetFileDetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_GetFileDetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_GetFileDetails] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADPMerge_GetFileDetails] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_GetFileDetails] TO [DB_DMLSupport]
    AS [dbo];

