﻿-- DefaultCustomerCheck 1451
CREATE Procedure DefaultCustomerCheck
	@USERID int
As
BEGIN
	/*  original 
			select ISNULL(LastCustomerId,0) from ARC_REC_Athena..ARC_REC_USER_INFO where USERID=@USERID and ACTIVE=1 */
	/* Changes 
		Declare @SupervicerUserId int
		set @SupervicerUserId = (select USERID from ARC_REC_Athena..ARC_REC_USER_INFO where NT_USERNAME=(select REPORTING_TO from ARC_REC_Athena..ARC_REC_USER_INFO  where USERID=@Userid and  ACTIVE=1))     
		if(select COUNT(*) from ADM_AccessFunctionality  where Functionality='B' and UserId=@USERID)>0
		Begin
		Update ARC_REC_Athena..ARC_REC_USER_INFO set LastCustomerId = (select LastCustomerId from  ARC_REC_Athena..ARC_REC_USER_INFO where USERID=@SupervicerUserId and ACTIVE=1)
		End    
		select ISNULL(LastCustomerId,0) from ARC_REC_Athena..ARC_REC_USER_INFO where USERID=@USERID and ACTIVE=1  
	*/
	Declare @LastCustomerId int
	select @LastCustomerId = ISNULL(LastCustomerId,0) from ARC_REC_Athena..ARC_REC_USER_INFO where USERID=@USERID and ACTIVE=1  
	select ISNULL(@LastCustomerId,0) as LastCustomerId,ISNULL(CmpKey,'') as CmpKey  from  ADM_Customer  where CustomerId =@LastCustomerId
END



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[DefaultCustomerCheck] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[DefaultCustomerCheck] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[DefaultCustomerCheck] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[DefaultCustomerCheck] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[DefaultCustomerCheck] TO [DB_DMLSupport]
    AS [dbo];

