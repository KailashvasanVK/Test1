﻿CREATE Proc Athena_MergeSCChkBatch @scandate varchar(10)=null ,@Minpagecount varchar(5)=null,@Maxpagecount int,@serviceid varchar(10)=null                        
 as    
 /*Created on :10/21/2015  
   Created by:Leela.T  
   Purpose :Check Available Batches for Ready to Subclient Merge*/  
begin    
Declare @BatchCount int,@ParentBatchid int ,    
@ParentBatchNo varchar(30),@Batchclientid int,@count int=0,@pgcount int,                
@Chk int=0,@StartPgNo int, @EndPgNo int,@Fname varchar(300)                
,@dollaramt money ,@BatchNo varchar(50), @qury nvarchar(Max) ,@Batchclinetid int                
                
create table #BatchCountDetails                                                  
 (                                                               
                                                                                                                                
BatchCount    int ,    
pgcount int                                                                                                                                                                                                                                              
    
)                 
                
                
create table #MergeBatchDetails                                            
 (                                                        
BatchNo   Varchar(15),                                                                                                                                    
PageCount   int,                                                
Fname varchar(300) ,                                          
status int,                          
dollarAmt Money                                           
)                  
                
delete from  #BatchCountDetails                
                
set @qury='insert into #BatchCountDetails                
select count(a.batchno),Sum(pgcount) from trn_koff_tbatches(nolock) a inner join ARC_Athena..batchMaster(nolock) b on a.BatchNo=b.batchnum                   
 Inner join TRN_kOFF_tBatchQueue(nolock) bq on a.batchno=bq.batchno where bq.BatchNo not in (select ChildBatchNo from mergebatchdetails(nolock))                
 and status=1 and  bq.assigned=0 and bq.statusid=0 and a.postedDt is null and a.UploadDt is  null  and b.ULStatus is null and                 
     a.ClientID not in (select Clientid from ExcludeFormerge(nolock)) and '             
 set @qury+=' PgCount <= cast('''+@Minpagecount+'''as int)'                   
                 
 if @scandate <>''                                  
                                  
Set @qury += ' and convert(varchar,scandate,101) = '''+@scandate+''''                 
                   
if @serviceid <>''                                  
                                  
Set @qury += ' and a.serviceid = cast('''+@serviceid+'''as int)'                    
                
                
Print @qury                
exec (@qury)       
    
select * from #BatchCountDetails      
    
    
drop table  #BatchCountDetails    
drop table #MergeBatchDetails    
 End  

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_MergeSCChkBatch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_MergeSCChkBatch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_MergeSCChkBatch] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_MergeSCChkBatch] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_MergeSCChkBatch] TO [DB_DMLSupport]
    AS [dbo];

