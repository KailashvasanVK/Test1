Text
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

CREATE Procedure [dbo].[ADM_pDownTimeNoWorkHours]
(           
 @TypeId int=null ,        
 @CustomerId int=null,        
 @ServicegroupId varchar(max)=null ,        
 @ServicegroupName varchar(max)=null ,        
 @SubClientId varchar(max)=null,        
 @SubClientName varchar(max)=null,        
 @FromTime datetime=null,        
 @ToTime datetime=null,        
 @ReasonId varchar(max)=null,        
 @IsEffectProduction bit=null,        
 @UserId varchar(max)=null,        
 @Createdby int=null,        
 @Action varchar(10)=null,        
 @RowId int=null,  
 @ApprovalStatus tinyint=0,
@Comments varchar(500)=null,
@Timezone varchar(100)='IST'
)        
As        
Begin        
     
 /* 
 Declare @TypeId int=32,
@CustomerId int=1,        
 @ServicegroupId varchar(max)='6,5' ,        
 @SubClientId varchar(max)='121341,110726,110649',        
 @FromTime datetime='02/15/2018 08:12:32',        
 @ToTime datetime='02/15/2018 08:12:32',        
 @ReasonId int =1,        
 @IsEffectProduction bit=1,        
 @UserId varchar(max)='14,10',        
 @Createdby int=4,        
 @Action varchar(10)='update',        
 @RowId int=14
*/

 if LEN(@ServicegroupId)=0 Set @ServicegroupId='0'        
 if LEN(@SubClientId)=0 Set @SubClientId='0'        
 if LEN(@UserId)=0 Set @UserId='0'        
  IF OBJECT_ID('TEMPDB..#SERVICEGROUP') IS NOT NULL DROP TABLE #SERVICEGROUP                
 Select items as ServiceGroupId,@CustomerId as CustomerId into #ServiceGroup from dbo.fnSplitString(@ServicegroupId,',')        
 IF OBJECT_ID('TEMPDB..#SUBCLIENT') IS NOT NULL DROP TABLE #SUBCLIENT        
 Select items as SubClientId,@CustomerId as CustomerId into #SubClient from dbo.fnSplitString(@SubClientId,',')        
 IF OBJECT_ID('TEMPDB..#USERIDS') IS NOT NULL DROP TABLE #USERIDS        
 Select items as UserId,@CustomerId as CustomerId into #UserIds from dbo.fnSplitString(@UserId,',')        
   
 IF OBJECT_ID('TEMPDB..#ReportHierarchy') IS NOT NULL DROP TABLE #ReportHierarchy        
 Create Table #ReportHierarchy(UserId int,Name varchar(100),UserName varchar(100),FunctionName varchar(100),Level tinyint)  
     
 if @Action='select'        
 Begin        
 
 Declare @MonthStartDate Date= (DATEADD(month, DATEDIFF(month, 0, GETDATE()), 0))
Set @MonthStartDate = DATEADD(month, DATEDIFF(month, 0, GETDATE()), 0)
   
 Insert into #ReportHierarchy(UserId,Name,UserName,FunctionName,Level)  
 EXEC ARC_REC_ATHENA..ARC_REC_ReportingHierarchy @Createdby --12540   
   
 Insert into #ReportHierarchy(UserId,Name,UserName,FunctionName,Level)  
 Select @Createdby,'','','',1  
   
  Select dnw.RowId,mt.TypeName,mt.TypeId,cus.InternalName as Customer,        
 CONVERT(VARCHAR(10), FromTime, 101) + ' '  + convert(VARCHAR(8), FromTime, 14) as FromTime,        
 CONVERT(VARCHAR(10), ToTime, 101) + ' '  + convert(VARCHAR(8), ToTime, 14) as ToTime        
 
 ,STUFF((SELECT distinct ', ' + CAST(subClasify.TypeName AS VARCHAR(100)) [text()]        
   FROM ADM_MasterTypes subClasify(nolock) where  TypeId in (Select items from dbo.fnSplitString(dnw.ReasonId,','))
   FOR XML PATH(''), TYPE).value('.','NVARCHAR(MAX)'),1,2,' ') Reason        
 ,dnw.ReasonId,
Case when isnull(dnw.IsEffectProduction,0)=0 then 'No' else 'Yes' end  as IsEffectProduction    
  ,STUFF((SELECT distinct ', ' + CAST(ServiceGroupId AS VARCHAR(100)) [text()]        
   FROM ADM_DownTimeNoWorkHoursTran trn (nolock)        
   WHERE DnRowId = dnw.RowId         
   FOR XML PATH(''), TYPE)        
  .value('.','NVARCHAR(MAX)'),1,2,' ') ServiceGroupId        
   ,'' as SubclientName    
   ,0 as SubClientId        
   ,STUFF((SELECT distinct ', ' + CAST(ServiceName AS VARCHAR(100)) [text()]        
   FROM ADM_DownTimeNoWorkHoursTran innerdnw(nolock)        
   Inner join ADM_Service(nolock) sg on sg.ServiceId=innerdnw.ServiceGroupId        
   WHERE DnRowId = dnw.RowId         
   FOR XML PATH(''), TYPE)        
  .value('.','NVARCHAR(MAX)'),1,2,' ')     as ServieGroupName      
  ,STUFF((SELECT distinct ', ' + CAST(UserId AS VARCHAR(100)) [text()]        
   FROM ADM_DownTimeNoWorkHoursTran innerdnw (nolock)        
   WHERE DnRowId = dnw.RowId        
   FOR XML PATH(''), TYPE)        
  .value('.','NVARCHAR(MAX)'),1,2,' ') UserId        
             
  ,STUFF((SELECT distinct ', ' + CAST(usr.NT_USERNAME AS VARCHAR(100)) [text()]        
   FROM ADM_DownTimeNoWorkHoursTran innerdnw(nolock)        
   inner join ARC_REC_ATHENA..arc_rec_user_info(nolock) usr on usr.USERID=innerdnw.UserId        
   WHERE DnRowId = dnw.RowId        
   FOR XML PATH(''), TYPE)        
  .value('.','NVARCHAR(MAX)'),1,2,' ') UserName        
  ,isnull(dnw.Comments,'') as Comments
  ,case when (Convert(Date,FromTime)>=@MonthStartDate and dnw.Createdby=@Createdby and ISNULL(dnw.StatusId,0)=0)  then 1 else 0 end editbuttonvisible        
  ,case when (Convert(Date,FromTime)>=@MonthStartDate and dnw.Createdby=@Createdby and ISNULL(dnw.StatusId,0)=0) then 1 else 0 end deletebuttonvisible        
  
  ,(Case when ((select count(*) from #ReportHierarchy where UserId=dnw.Createdby)>0 and isnull(dnw.StatusUpdatedBy,0)=0 and dnw.Createdby<>@Createdby)  
   then 1 else 0 end) as Approvalction       
  ,case when ISNULL(dnw.StatusId,0)=0 then 'Waiting for approval'  
  when ISNULL(dnw.StatusId,0)=2 then 'Rejected'  
   else 'Approved' end as ApprovalStatus    
  ,isnull((select Nt_userName from ARC_REC_ATHENA..ARC_REC_USER_INFO usr  where usr.UserId=dnw.StatusUpdatedBy),'') as ApprovedBy  
  ,isnull(CONVERT(VARCHAR(10), dnw.StatusUpdatedOn, 101) + ' '  + convert(VARCHAR(8),dnw.StatusUpdatedOn, 14),'') as ApprovedDate  
     
 from  ADM_DownTimeNoWorkHours(nolock) dnw        
 inner join ADM_Customer (nolock) cus on dnw.CustomerId=cus.CustomerId        
 --inner join ADM_TATReason(nolock) TATR on TATR.ReasonId=dnw.ReasonId        
 inner join ADM_MasterTypes(nolock) mt on mt.TypeId=dnw.TypeId        
 Where dnw.CustomerId=@CustomerId  and dnw.Active=1  
 and dnw.Createdby in (Select UserId from #ReportHierarchy)  
 order by dnw.CreatedDt desc        
   
   
 End        
 else if @Action='add'        
 Begin        
  if object_Id('tempdb..#DownTime') is not null drop table #DownTime        
  Select ServiceGroupId,sg.CustomerId,UserId,@FromTime as FromTime,@ToTime as ToTime
  ,@ReasonId as ReasonId,@TypeId as TypeId        
  ,@Createdby as CreatedBy,@IsEffectProduction as IsEffectProduction,@Comments as Comments
  into #DownTime from #ServiceGroup sg        
  inner join #SubClient sc on sg.CustomerId=sc.CustomerId         
  inner join #UserIds usr on  sg.CustomerId=usr.CustomerId         
        
       if  exists(select * from ADM_DownTimeNoWorkHours dn        
  inner join ADM_DownTimeNoWorkHoursTran (nolock) trn on dn.RowId=trn.DNRowId        
  inner join #DownTime tdn on         
  dn.TypeId=tdn.TypeId and dn.CustomerId=tdn.CustomerId and trn.ServicegroupId=tdn.ServicegroupId
   and trn.userid=tdn.userid
   and dn.FromTime=tdn.FromTime and dn.ToTime=tdn.ToTime and dn.Active=1
  )        
  select '0' as result; 
  Else        
  Begin        
  Insert into ADM_DownTimeNoWorkHours(TypeId,CustomerId,FromTime,ToTime,ReasonId,IsEffectProduction,Createdby,CreatedDt,Active,StatusId,Comments,DisplayTimezone)
  Select distinct TypeId,CustomerId,FromTime ,ToTime ,ReasonId,IsEffectProduction,Createdby,getdate(),1,@ApprovalStatus,Comments,@Timezone from #DownTime
        
  Declare @DnRowId int        
  Set @DnRowId= SCOPE_IDENTITY()        
  Insert into ADM_DownTimeNoWorkHoursTran(DNRowId,ServiceGroupId,UserId)        
  Select  @DnRowId,ServiceGroupId,UserId from #DownTime        
  select '1' as result        
  END        
  /*if  exists(select * from ADM_DownTimeNoWorkHours where Type=@Type and CustomerId=@CustomerId and ServicegroupId=@ServicegroupId and SubClientId=@SubClientId and FromTime=@FromTime and ToTime=@ToTime)        
  return ;        
  Else        
 Begin        
  Insert into ADM_DownTimeNoWorkHours(Type,CustomerId,ServicegroupId,SubClientId,FromTime,ToTime,ReasonId,IsEffectProduction,UserId,Createdby,CreatedDt,status)        
  Select @Type ,@CustomerId ,@ServicegroupId ,@SubClientId ,@FromTime ,@ToTime ,@ReasonId ,@IsEffectProduction ,@UserId ,@Createdby,getdate(),1          
  End        
  */        
  EXEC ADM_DowntimeNoworkhoursMailNotification @DnRowId  
 End        
 else  if @Action='update'        
 Begin        
      
 Update ADM_DownTimeNoWorkHours set TypeId=isnull(@TypeId,TypeId) ,CustomerId=isnull(@CustomerId,CustomerId) ,FromTime=isnull(@FromTime,FromTime)        
 ,ToTime=isnull(@ToTime,ToTime) ,ReasonId=isnull(@ReasonId,ReasonId) ,IsEffectProduction=isnull(@IsEffectProduction,IsEffectProduction)        
 ,ModifiedBy=@Createdby,ModifiedDt=Getdate(),Comments=@Comments,DisplayTimezone=@Timezone
where RowId=@RowId        
 if object_Id('tempdb..#UpdateDownTime') is not null drop table #UpdateDownTime        
 Select @RowId as RowId,ServiceGroupId,SubClientId,UserId        
 into #UpdateDownTime from #ServiceGroup sg        
 inner join #SubClient sc on sg.CustomerId=sc.CustomerId         
 inner join #UserIds usr on  sg.CustomerId=usr.CustomerId                
 
 Delete from ADM_DownTimeNoWorkHoursTran where DNRowId=@RowId             
 Insert into ADM_DownTimeNoWorkHoursTran(DNRowId,ServiceGroupId,UserId,Active)        
 Select  @RowId,ServiceGroupId,UserId,1 from #UpdateDownTime td        

  select '1' as result        

 End        
 else  if @Action='delete'        
 Begin        
 Update ADM_DownTimeNoWorkHours set Active=0,ModifiedBy=@Createdby where RowId=@RowId        
 End        
 else if @Action='approval'   
 Begin  
   
  Update ADM_DownTimeNoWorkHours set StatusId=@ApprovalStatus,StatusUpdatedBy=@Createdby,StatusUpdatedOn=GETDATE(),ApprovalComments=@Comments where RowId=@RowId    
  EXEC ADM_DowntimeNoworkhoursMailNotification @DnRowId  
 End  
      
 IF OBJECT_ID('TEMPDB..#SERVICEGROUP') IS NOT NULL DROP TABLE #SERVICEGROUP        
 IF OBJECT_ID('TEMPDB..#SUBCLIENT') IS NOT NULL DROP TABLE #SUBCLIENT        
 IF OBJECT_ID('TEMPDB..#USERIDS') IS NOT NULL DROP TABLE #USERIDS        
End 

