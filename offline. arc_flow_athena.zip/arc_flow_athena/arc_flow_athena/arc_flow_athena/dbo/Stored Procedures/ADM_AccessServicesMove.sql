﻿CREATE Procedure  [dbo].[ADM_AccessServicesMove]  
@UserId int,  
@CustomerId int   
As  
/*  
Created by : Karthik Ic   
Created on : 20 May 2013  
Impact to  : ProfileSetup.aspx  
Purpose    : To move  all data from log table and delete the data from customer wise client details table.  
*/  
Begin  
--if exists(Select top 1 'x' from ADM_AccessServices Where UserId=@UserId and CustomerId  = @CustomerId )  
--Begin  
Insert into ADM_AccessServicesLog (UserId,CustomerId,ServiceId,CreatedBy,CreatedDt,AccServiceId)      
Select UserId,CustomerId,ServiceId,CreatedBy,CreatedDt,AccServiceId From  ADM_AccessServices Where UserId=@UserId and CustomerId =@CustomerId  
Delete from ADM_AccessServices Where UserId=@UserId and CustomerId = @CustomerId  
--End
--if exists(Select top 1 'x' from ADM_AccessTarget  Where UserId=@UserId and CustomerId  = @CustomerId )  
--Begin
--Delete from ADM_AccessTarget   Where UserId=@UserId and CustomerId = @CustomerId  
--End  
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_AccessServicesMove] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessServicesMove] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessServicesMove] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_AccessServicesMove] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessServicesMove] TO [DB_DMLSupport]
    AS [dbo];

