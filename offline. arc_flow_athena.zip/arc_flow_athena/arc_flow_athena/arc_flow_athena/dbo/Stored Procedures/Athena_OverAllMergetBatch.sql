﻿CREATE procedure Athena_OverAllMergetBatch(                                                     
 @Actions varchar(20) =null                                                  
,@scandate varchar(10)=null                                           
,@Minpagecount varchar(5)=null                                          
,@Maxpagecount int=0                                          
,@serviceid varchar(10)=null                                         
,@Percentlvl int =0               
,@LocationID varchar(10) =0)                                          
as                                      
                                                             
begin                                           
/*                                              
                                          
Created By     : Leela.T                                          
Created Date   : 2016-06-01                                            
Purpose        : Logical Merge for Enterprise and Sub Client                                          
                                        
                                      
Modified No     : 001                                       
Modified by     : Leela.T                                      
Modified Prpose : add the Client id Condition from adm_client Table                                      
Modified Date   : 2016-06-09                                      
TL Verified By : <Ramki>                                       
                                    
                                     
Modified No     : 002                                       
Modified by     : Leela.T                                      
Modified Prpose : add Temp table for Enterprise Client                                    
Modified Date   : 2016-06-17                                      
TL Verified By : <Ramki>                                     
                                          
                                       
Modified No     : 003                                       
Modified by     : Leela.T                                      
Modified Prpose : add  EDS Client  Merge Condition                                   
Modified Date   : 2017-05-24                                   
TL Verified By  :        
      
Modified No     : 004                                       
Modified by     : Leela.T                                      
Modified Prpose : Location wise Merge Creation                                   
Modified Date   : 2017-08-17                                   
TL Verified By  :                                           
                         
Modified No     : 005                                      
Modified by     : Leela.T                                      
Modified Prpose : Include Pageno @ condition                                  
Modified Date   : 2017-08-21                                   
TL Verified By  :     
                      
Implemented by : Azzaz Badusha.a                                       
Implemented On : 2016-06-20                                      
Ticket ID    : 148833                                        
                                          
*/                                          
                                     
Declare @BatchCount int,@ParentBatchid int ,                                                                
@ParentBatchNo varchar(30),@Batchclientid int,@count int=0,@pgcount int,                                                                
@Chk int=0,@StartPgNo int, @EndPgNo int,@Fname varchar(300)                                                                
,@dollaramt money ,@BatchNo varchar(50), @qury nvarchar(Max) ,@Batchclinetid int                
,@pdfPath varchar(500)                                                                
                             
                          
if(object_id('tempdb.dbo.#BatchCountDetails')is not null)                                                          
drop table #BatchCountDetails                                   
create table #BatchCountDetails                                  
(BatchCount int)                                                                 
                                      
if(object_id('tempdb.dbo.#BatchDetails')is not null)                                                                    
drop table #BatchDetails                                                                    
create table #BatchDetails                                                                                     
(BatchNo   varchar(30))                                            
                                     
if(object_id('tempdb.dbo.#MergeBatchDetails')is not null)                                                          
drop table #MergeBatchDetails                                                
create table #MergeBatchDetails                                                                      
(                                        
 BatchNo   Varchar(15)                                                                                                        
,PageCount   int                                                                          
,Fname varchar(300)                                      
,status int                                                                          
,dollarAmt Money                   
)                                                                  
                                      
                                     
if(object_id('tempdb.dbo.#EntClient')is not null)                                       
drop table #EntClient                                                                   
create table #EntClient                                           
(Subclient   varchar(10))                                        
                           
                                    
if (@Actions='Enterprise')                                    
begin                          
 insert into  #EntClient                                        
 select distinct SubClient from ARC_ATHENA..SubClient_Info sub where sub.status=1 and Category like '%Enterprise%'                          
End                          
else if (@Actions='EDS Merge')                           
begin                           
  insert into  #EntClient                                        
  select distinct SubClient from ARC_ATHENA..SubClient_Info sub where sub.status=1                                   
End                                    
                 
                     
select @pdfpath=pdfpath from arc_athena..GetPDFPathByLocation where LocID=@LocationID             
              
                                    
set @qury='insert into #BatchCountDetails                                                                
select count(a.batchno) from trn_koff_tbatches a inner join ARC_Athena..batchMaster b on a.BatchNo=b.batchnum                                                                   
Inner join TRN_kOFF_tBatchQueue bq on a.batchno=bq.batchno                                            
Inner join ADM_Client adm on adm.ClientId=a.ClientId and CustomerId=25 and adm.status=1                               
left join mergebatchdetails mrg on mrg.childbatchno=a.batchno    
left join trn_koff_theldbatches (nolock) hld on a.batchid=hld.batchid                              
left join TRN_kOFF_tBatchResetLog Rp on RP.batchno= a.batchno'                                     
                                     
if @Actions<>'SubClientMerge'                                                                          
set @qury+=  ' Inner join #EntClient sub on adm.ClientName=sub.SubClient '                                       
                                      
set @qury+=' where  mrg.childbatchno is null and a.status=1 and bq.assigned=0  and Rp.Batchno is null                                  
and bq.statusid=0 and a.postedDt is null and a.UploadDt is null   and (hld.Batchid is null or hld.ReleaseDate is not null)                                    
and b.ULStatus is null and a.PgCount <>1 and '                                                 
                                        
set @qury+=' a.PgCount <= cast('''+@Minpagecount+'''as int)'                                          
                                                
if @Actions='SubClientMerge'                                                  
set @qury+= ' and a.ClientID not in (select Clientid from ExcludeFormerge) '                                         
                                          
if @scandate <>''                                                                                    
Set @qury += ' and a.scandate= '''+@scandate+''''                                                                             
                                          
if @serviceid <>''                                                                   
Set @qury += ' and a.serviceid = cast('''+@serviceid+'''as int) '                   
                  
--if @serviceid ='362'                                                     
--Set @qury += ' and a.PgCount <>2 '                     
                                        
exec (@qury)                                                          
set @qury=''                          
                                    
select @BatchCount=Batchcount from #BatchCountDetails                           
select @BatchCount=@BatchCount- ROUND(((@batchcount*@Percentlvl)/100),0)                            
                                                             
if(@BatchCount<20)                                                  
begin                                                   
return                                                  
End                                                             
                             
                                        
set @qury='insert into #Batchdetails                                         
select top '+ CONVERT(VARCHAR,@BatchCount) +' a.batchno from TRN_kOFF_tBatches a                  
Inner join TRN_kOFF_tBatchQueue bq on a.batchno=bq.batchno                                                          
inner join ARC_Athena..batchMaster b on a.BatchNo=b.batchnum                                         
Inner join ADM_Client adm on adm.ClientId=a.ClientId and CustomerId=25 and adm.status=1                              
left join mergebatchdetails mrg on mrg.childbatchno=a.batchno    
left join trn_koff_theldbatches (nolock) hld on a.batchid=hld.batchid                                 
left join TRN_kOFF_tBatchResetLog Rp on RP.batchno= a.batchno '                                    
                                      
if @Actions<>'SubClientMerge'                                                                          
set @qury+=  ' Inner join #EntClient sub on adm.ClientName=sub.SubClient '                                       
                                      
set @qury+=' where  mrg.childbatchno is null and a.status=1 and bq.assigned=0 and Rp.Batchno is null                                  
and bq.statusid=0 and a.postedDt is null and a.UploadDt is null and (hld.Batchid is null or hld.ReleaseDate is not null)                                    
and b.ULStatus is null and a.PgCount <>1 and '                                                  
                                        
set @qury+=' a.PgCount <= cast('''+@Minpagecount+'''as int)'                                                                                                  
                                                
if @Actions='SubClientMerge'                       
set @qury+= ' and a.ClientID not in (select Clientid from ExcludeFormerge) '                                         
                                          
if @scandate <>''                                                                                    
Set @qury += ' and a.scandate = '''+@scandate+''''                                                        
                                          
if @serviceid <>''                                                                   
Set @qury += ' and a.serviceid = cast('''+@serviceid+'''as int) '                     
                                         
--if @serviceid ='362'                                                                   
--Set @qury += ' and a.PgCount <>2 '                                                                            
                                                
exec (@qury)                                                                   
set @qury=''                                                                     
                                          
set @qury='update TRN_kOFF_tBatches set status=99 where BatchNo in (select batchno from #Batchdetails)'                                                                                           
exec (@qury)                                                                          
set @qury=''                                                                                         
                                          
                                          
/*********************** Parent Batch Creation ************************/                                                
insert into Athena_ChildBatchgeneration                                                                 
select MAX(Batchid)+1 from athena_childBatchGeneration                                                                 
select @Batchclientid=MAX(Batchid) from athena_childBatchGeneration                     
INSERT INTO Athena_ParentBatchGeneration(ParentBatch) values (Convert(varchar(10),@Batchclientid) )                                                                                                        
set @ParentBatchid = SCOPE_IDENTITY()                                                                                                        
set @ParentBatchNo='S' + Convert(varchar(10),@ParentBatchid) + 'A1'                                                                 
 /************************ Insert the Child Batch in Temporary  Table  ************************/                                            
insert into #MergeBatchDetails(batchno , pagecount,Fname,status,dollarAmt)                                      
select c.batchno,pgcount,'\\' +@pdfpath+SUBSTRING(a.Fname,CHARINDEX('\',a.Fname,3),LEN(a.Fname)) ,0,b.dollarAmt from trn_koff_tbatches a                                    
inner join Arc_Athena..batchMaster b on a.BatchNo=b.batchnum                                      
inner join #BatchDetails c on c.BatchNo=b.batchnum                                    
left join mergebatchdetails mrg on a.BatchNo=mrg.ChildBatchNo                                    
where ChildBatchNo is null and ScanDate=convert(varchar,@scandate,101)                                                                       
and a.status=99  and ServiceId=cast(@serviceid as int)                                                                  
  /***************************Logically Batches are Merge ************************/                                           
declare @CurMergeBatch cursor                                                                                                            
set  @CurMergeBatch  = cursor fast_forward for                                                                                                       
              
select batchno, pagecount,Fname,dollaramt from #MergeBatchDetails where status=0                                                                                                         
                                               
open  @CurMergeBatch                          
                                                                                                             
fetch next from @CurMergeBatch into                                                                                                       
@BatchNo,@PgCount ,@Fname,@dollaramt                                                                                                       
                                          
while(@@fetch_status<>-1)                                               
Begin                                           
                                          
set @count=@count+@pgcount                                                                                                                          
if(@Count>=@Maxpagecount)                                                                  
begin                                                             
Set @Count=0                                                                                                    
Set @Chk=0                                                                                            
select @Count=SUM(pagecount) from #MergeBatchDetails where status=0                              
if(@Count<40)                                                   
begin                                                                                       
update TRN_kOFF_tBatches set status=1 where BatchNo in(                                                         
select BatchNo from #MergeBatchDetails where status=0)                                                                                      
Goto NextSubClient                             
End                                                                 
                                       
set @count=0                                                                                    
set @count=@count+@pgcount                                                                                                        
                                          
insert into Athena_ChildBatchgeneration                                                                 
select MAX(Batchid)+1 from athena_childBatchGeneration                                                                  
select @Batchclientid=MAX(Batchid) from athena_childBatchGeneration                              
INSERT INTO Athena_ParentBatchGeneration(ParentBatch) values (Convert(varchar(10),@Batchclientid) )                                                                                                        
set @ParentBatchid = SCOPE_IDENTITY()                                                                                                        
set @ParentBatchNo='S' + Convert(varchar(10),@ParentBatchid) + 'A1'                                                                                                       
                                                  
                                          
if (@Chk=0)                                                                                                    
begin                                                     
Set @Chk=1                                                                                                    
set @StartPgNo=1                                                                                                    
set @EndPgNo=@PgCount                                                                                                    
End                                                                                                      
else                             
begin                                                                     
set @StartPgNo=@EndPgNo+1                                                                                                    
set @EndPgNo= @startpgno + (@PgCount-1)                                                                     
End                                                     
End                                                                                                    
                                          
else                                                                                                     
begin                                                                   
if (@Chk=0)                                              
begin                                                                                                    
Set @Chk=1                                                                 
set @StartPgNo=1                                                                                                    
set @EndPgNo=@PgCount                                                                                                                  
End                                               
                                          
else                                                                     
begin                                                                                                   
set @StartPgNo=@EndPgNo+1                                                                                                    
set @EndPgNo= @startpgno + (@PgCount-1)                
End                                                                                                      
end                                                                                                    
                                          
INSERT INTO MergeBatchDetails(ParentBatchNo,childBatchNo,StartPgNo,EndpgNo,TotalPages,status,Fname,dollaramt)                                                                     
values(@ParentBatchNo,@BatchNo,@StartPgNo,@EndPgNo,@PgCount,1,@Fname ,@dollaramt)                                                                               
update #MergeBatchDetails set status=1 where BatchNo=@BatchNo                                                                                          
                                           
fetch next from @CurMergeBatch  into                                                                                    
@BatchNo,@PgCount,@Fname,@dollaramt                                                                 
                                             
End                                                                                                       
                                          
NextSubClient:                                      
                                            
close @CurMergeBatch                            
deallocate @CurMergeBatch                                                                                          
                                               
if(object_id('tempdb.dbo.#MergeBatchDetails')is not null)drop table #MergeBatchDetails                                                 
if(object_id('tempdb.dbo.#BatchDetails')is not null)drop table #BatchDetails                                                 
if(object_id('tempdb.dbo.#BatchCountDetails')is not null)drop table #BatchCountDetails                                       
if(object_id('tempdb.dbo.#EntClient')is not null)drop table #EntClient                                       
End 

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_OverAllMergetBatch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_OverAllMergetBatch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_OverAllMergetBatch] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_OverAllMergetBatch] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_OverAllMergetBatch] TO [DB_DMLSupport]
    AS [dbo];

