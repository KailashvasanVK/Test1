﻿  CREATE Procedure TRN_kOFF_pBatchProcessSubmitV1_HeldBatches_Selfpay          
(          
@pBatchProcessId int          
,@pStatus varchar(1) /* (C)omplete/(H)eld/(I)ncomplete */          
,@pCompletedPageNo int /** This should be mandatory if status is incomplete / held **/          
,@pComments varchar(max)          
,@pCreatedBy int          
,@pPayment int /** Payment (358) transaction count */          
,@pCollection int /** Collection (359) transaction count */          
,@pExceptionPosting int /** ExceptionPosting (360) transaction count */          
,@pSelfPosting int /** SelfPosting (361) transaction count */          
,@pPatientPosting int /** PatientPosting (364) transaction count */          
,@pHoldComments varchar(max) = ''          
)          
as          
Begin       
      
/*              
  Created By     : Noor ,Mallika     
  Created Date   : 2016-07-26         
  Purpose        : Held the Batch for Selfpay project    
Ticket/SCR ID  :  1237   
TL Verified By : Ramakrishnan.G                    
                    
Implemented by : Ganesh Tanneru                    
Implemented On :  09-Jun-2017       
 Ticket : 259614
 Purpose : to exclude held batches in allocation  
 Date : 12/26/2017         
        
 */         
 Declare @CreatedDt datetime = getdate()          
Declare @BatchId int,@PageFrom int,@ServiceId int,@ClientId int,@PageTo int          
Select @BatchId = BatchId ,@PageFrom = PageFrom,@PageTo = PageTo, @ServiceId = ServiceId,@ClientId = ClientId          
from TRN_kOFF_tBatchQueue Where BatchProcessId = @pBatchProcessId          
Declare @LocationId int = (Select LocationId from ARC_REC_ATHENA..ARC_REC_User_Info where UserId = @pCreatedBy)          
Declare @ShiftId int = (Select Top 1 SHIFT_ID from ARC_REC_ATHENA..ARC_REC_SHIFT_TRAN where USERID = @pCreatedBy and Effect_DATE <= GETDATE() Order by Effect_DATE desc)      
 Begin Transaction          
Begin Try          
if @pStatus = 'H'           
 Begin          
  Insert into TRN_kOFF_tBatchFlow (BatchId,BatchProcessId,CreatedBy,CreatedDt,StatusId,Comments)          
  Select @BatchId,@pBatchProcessId,@pCreatedBy,@CreatedDt,17,@pHoldComments + ' : ' + @pComments          
  from TRN_kOFF_tBatches as Bat          
  Where BatchId = @BatchId and not Exists (Select 1 from TRN_kOFF_tHeldBatches Where BatchId = Bat.BatchId and ReleaseDate is null)            
  Insert into TRN_kOFF_tHeldBatches(BatchId,HeldDate,HeldBy,HeldComment)          
  Select @BatchId,getdate() as HeldDate,@pCreatedBy as HeldBy,@pHoldComments + ' : ' + @pComments          
  from TRN_kOFF_tBatches as Bat          
  Where BatchId = @BatchId and not Exists (Select 1 from TRN_kOFF_tHeldBatches Where BatchId = Bat.BatchId and ReleaseDate is null)          
  Update TRN_kOFF_tBatchQueue Set StatusId = 17,Assigned = 0 Where BatchProcessId = @pBatchProcessId  
  
  Update TRN_kOFF_tmanualAllocation set status=0 where BatchProcessId=@pBatchProcessId /*Update Held batch detail Dec 20,2017 Ticket : 259614*/ 
  
 End          
Commit Transaction          
Select ''          
End Try          
Begin Catch          
Rollback transaction          
return Error_Message()          
End catch          
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pBatchProcessSubmitV1_HeldBatches_Selfpay] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchProcessSubmitV1_HeldBatches_Selfpay] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchProcessSubmitV1_HeldBatches_Selfpay] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pBatchProcessSubmitV1_HeldBatches_Selfpay] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchProcessSubmitV1_HeldBatches_Selfpay] TO [DB_DMLSupport]
    AS [dbo];

