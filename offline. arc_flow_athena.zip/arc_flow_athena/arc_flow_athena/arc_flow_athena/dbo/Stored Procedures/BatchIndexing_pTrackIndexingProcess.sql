﻿

CREATE PROCEDURE BatchIndexing_pTrackIndexingProcess   
(   
@BatchNo varchar(30) = NULL,   
@ScanDate varchar(50) = NULL,   
@PayorServiceId int = NULL,   
@CheckDate varchar(50) = NULL,   
@ntusername varchar(100) = NULL   
)   
AS   
BEGIN   
/*       
BatchIndexing : To Track the Indexing Batches CheckDate, ScanDate, PayerID       
Created Date : 02/10/2016       
*/

--INSERT INTO Arc_Flow_Athena..BatchIndexing_tIndexingProcessed(BatchNo, ScanDate, PayorServiceId, CheckDate, ntusername, CreatedDate, ServiceID)   
--VALUES(@BatchNo, @ScanDate, @PayorServiceId, @CheckDate, @ntusername, GETDATE(), @ServiceID)   

UPDATE Arc_Flow_Athena..BatchIndexing_tIndexingProcessed SET CheckDate = @CheckDate WHERE BatchNo = @BatchNo

END
GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[BatchIndexing_pTrackIndexingProcess] TO [AdpService]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[BatchIndexing_pTrackIndexingProcess] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[BatchIndexing_pTrackIndexingProcess] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[BatchIndexing_pTrackIndexingProcess] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[BatchIndexing_pTrackIndexingProcess] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[BatchIndexing_pTrackIndexingProcess] TO [DB_DMLSupport]
    AS [dbo];

