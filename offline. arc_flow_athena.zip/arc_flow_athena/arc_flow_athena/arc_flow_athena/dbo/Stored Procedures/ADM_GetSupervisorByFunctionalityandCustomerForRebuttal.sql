Text
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
CREATE Procedure ADM_GetSupervisorByFunctionalityandCustomerForRebuttal
(    
       @CustomerId int,  
       @FunctionalityId int,
       @UserId int
)  
As  
Begin   
   /*
	Declare @CustomerId int=25,  
	@FunctionalityId int=194,
	@UserId int= 3663
	*/
	Declare @DesigHeadCount varchar(5)
	
/*
  --Set @DesigHeadCount=(Select top 1de.HeadCountName from ARC_REC_ATHENA..HR_Designation de
  --inner join ARC_REC_ATHENA..ARC_REC_USER_INFO ui on de.DesigId=ui.DESIGNATION_ID
  --where ui.USERID=@UserId and ui.ACTIVE=1 and de.Status=1)
  */
  
  if object_ID('tempdb..#tmpTrainingTeamFun') is not null drop table #tmpTrainingTeamFun
  Create Table #tmpTrainingTeamFun(FunctionalityId int)
  
  Insert into #tmpTrainingTeamFun(FunctionalityId) values(@FunctionalityId)
  
  if @FunctionalityId=194 /*In Training team functionality user login both payment posting team supervisors and training team supervisors should load*/
   Insert into #tmpTrainingTeamFun(FunctionalityId) values(126)
  
  
  Select @DesigHeadCount= de.HeadCountName,@FunctionalityId=Functionality_ID from ARC_REC_ATHENA..HR_Designation de
  inner join ARC_REC_ATHENA..ARC_REC_USER_INFO ui on de.DesigId=ui.DESIGNATION_ID
  where ui.USERID=@UserId and ui.ACTIVE=1 and de.Status=1
   
  if object_ID('tempdb..#tmpUsrs') is not null drop table #tmpUsrs
  Create Table #tmpUsrs(UserId int,Supervisor varchar(100))
  
  IF(SUBSTRING(@DesigHeadCount,1,1)=3)
  Begin
	insert into #tmpUsrs(UserId,Supervisor)
	Select ui.UserID,ui.NT_USERNAME as Supervisor from ARC_REC_ATHENA..ARC_REC_USER_INFO  ui  where USERID=@UserId
	union
	--insert into #tmpUsrs(UserId,Supervisor)
	select ui.UserID,ui.NT_USERNAME as Supervisor
	from ARC_REC_ATHENA..ARC_REC_USER_INFO  ui  
	inner join ARC_REC_ATHENA..HR_Designation desgi on desgi.DesigId =  ui.DESIGNATION_ID and HeadCountName=@DesigHeadCount
	inner join ARC_REC_ATHENA..ARC_REC_UserCustomer cust  on  cust.UserId = ui.USERID and cust.CustomerID = @CustomerId   
	Where ui.FUNCTIONALITY_ID in(select FunctionalityId from #tmpTrainingTeamFun)
	/*
	Where ui.FUNCTIONALITY_ID=(case when @FunctionalityId = 194 then 126 else @FunctionalityId end) 
	*/
	and ui.ACTIVE=1 and ui.AHS_PRL = 'Y'        
  End
  Else IF(SUBSTRING(@DesigHeadCount,1,1)=2)
  Begin 
     insert into #tmpUsrs(UserId,Supervisor)
     Select ui.UserID,ui.NT_USERNAME as Supervisor from ARC_REC_ATHENA..ARC_REC_USER_INFO  ui  where USERID=@UserId
     union
     select ui.UserID,ui.NT_USERNAME as Supervisor
     from ARC_REC_ATHENA..ARC_REC_USER_INFO  ui  
     inner join  ARC_REC_ATHENA..ARC_REC_USER_INFO  rpt on ui.REPORTING_TO=rpt.NT_USERNAME  
     inner join ARC_REC_ATHENA..ARC_REC_UserCustomer cust  on  cust.UserId = ui.USERID and cust.CustomerID = @CustomerId   
     Where ui.FUNCTIONALITY_ID in(select FunctionalityId from #tmpTrainingTeamFun)
     /*
     Where ui.FUNCTIONALITY_ID =(case when @FunctionalityId = 194 then 126 else @FunctionalityId end) 
     */
     and ui.ACTIVE=1 and ui.AHS_PRL = 'Y' and rpt.USERID=@UserId
  End
  Else 
  Begin
   insert into #tmpUsrs(UserId,Supervisor)
   Select ui.UserID,ui.NT_USERNAME as Supervisor from ARC_REC_ATHENA..ARC_REC_USER_INFO  ui  where USERID=@UserId
   End
  Select distinct tmp.UserId,Supervisor from #tmpUsrs tmp 
  inner join  ARC_REC_ATHENA..ARC_REC_USER_INFO ui  on  tmp.Supervisor = ui.REPORTING_TO 
  where exists (select 1 from TRN_kOFF_tBatcherrorrebuttalflow flow where (flow.CreatedBy=ui.UserId or flow.Createdby=tmp.UserId))

End 

