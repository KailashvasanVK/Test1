﻿CREATE proc Athena_EnterpriseMergetBatch(                                         
@scandate varchar(10)=null  
,@Minpagecount varchar(5)=null           
,@Maxpagecount int          
,@serviceid varchar(10)=Null           
,@Percentlvl int )          
    as  
    begin                       
            
/*                
            
Created By     : Leela.T            
Created Date   : 2016-06-01              
Purpose        : Logical Merge for Enterprise and Sub Client            
 TL Verified By : <Ramki>         
  
*/            
            
Declare @BatchCount int,@ParentBatchid int ,                                  
@ParentBatchNo varchar(30),@Batchclientid int,@count int=0,@pgcount int,                                  
@Chk int=0,@StartPgNo int, @EndPgNo int,@Fname varchar(300)                                  
,@dollaramt money ,@BatchNo varchar(50), @qury nvarchar(Max) ,@Batchclinetid int                                  
               
if(object_id('tempdb.dbo.#BatchCountDetails')is not null)                            
drop table #BatchCountDetails                  
create table #BatchCountDetails                                                                    
(                                                                                                                                                                                                               
BatchCount    int                                                                                                                                                                                                                                              
)                                   
        
if(object_id('tempdb.dbo.#BatchDetails')is not null)                                      
drop table #BatchDetails                                      
create table #BatchDetails                                                                              
(                                                                                                                                                                                                                         
BatchNo   varchar(40)                                                                                                                                                                                                                                          
)          
            
if(object_id('tempdb.dbo.#MergeBatchDetails')is not null)                            
drop table #MergeBatchDetails                  
create table #MergeBatchDetails                                                              
(                                                                          
BatchNo   Varchar(15),                                                                                                                                                      
PageCount   int,                                                                  
Fname varchar(300) ,                                                            
status int,                                            
dollarAmt Money                                                             
)                                    
        
      
    
if(object_id('tempdb.dbo.#EntClient')is not null)                                      
drop table #EntClient                                     
create table #EntClient             
(                                                                             
Subclient   varchar(10)                                                                                                                                                                                                                                        
)          
   
insert into  #EntClient          
select SubClient from ARC_ATHENA..SubClient_Info sub where sub.status=1 and Category like '%Enterprise%'      

set @qury='insert into #BatchCountDetails                       
select count(a.batchno) from trn_koff_tbatches a inner join ARC_Athena..batchMaster b on a.BatchNo=b.batchnum                                     
Inner join TRN_kOFF_tBatchQueue bq on a.batchno=bq.batchno         
left join mergebatchdetails mrg on mrg.childbatchno=a.batchno      
Inner join ADM_Client adm on adm.ClientId=a.ClientId and CustomerId=25 and adm.status=1                                             
 Inner join #EntClient sub on adm.ClientName=sub.SubClient        
where  mrg.childbatchno is null and a.status=1 and bq.assigned=0      
and bq.statusid=0 and a.postedDt is null and a.UploadDt is null        
and b.ULStatus is null and PgCount <>1 and '                   
          
set @qury+=' PgCount <= cast('''+@Minpagecount+'''as int)'                                                                           
            
if @scandate <>''                                                      
Set @qury += ' and convert(varchar,scandate,101) = '''+@scandate+''''                                                     
            
if @serviceid <>''                                     
Set @qury += ' and a.serviceid = cast('''+@serviceid+'''as int) '                                     
          
exec (@qury)                            
set @qury=''                                    
            
select @BatchCount=Batchcount from #BatchCountDetails                                  
if(@batchcount<20)                    
begin                     
return                    
End                               
            
select @BatchCount=@BatchCount- ROUND(((@batchcount*@Percentlvl)/100),0)                                    
          
set @qury='insert into #Batchdetails           
select top '+ CONVERT(VARCHAR,@BatchCount) +' a.batchno from TRN_kOFF_tBatches a                        
Inner join TRN_kOFF_tBatchQueue bq on a.batchno=bq.batchno         
left join mergebatchdetails mrg on mrg.childbatchno=a.batchno                        
inner join ARC_Athena..batchMaster b on a.BatchNo=b.batchnum           
Inner join ADM_Client adm on adm.ClientId=a.ClientId and CustomerId=25 and adm.status=1      
 Inner join #EntClient sub on adm.ClientName=sub.SubClient        
where  mrg.childbatchno is null and a.status=1 and bq.assigned=0      
and bq.statusid=0 and a.postedDt is null and a.UploadDt is null        
and b.ULStatus is null and PgCount <>1 and '                    
          
set @qury+=' PgCount <= cast('''+@Minpagecount+'''as int)'                                                                    
          
if @scandate <>''                                                      
Set @qury += ' and convert(varchar,scandate,101) = '''+@scandate+''''                                                     
            
if @serviceid <>''                                     
Set @qury += ' and a.serviceid = cast('''+@serviceid+'''as int) '                                                            
                                      
exec (@qury)                                     
set @qury=''                                       
            
set @qury='update TRN_kOFF_tBatches set status=99 where BatchNo in (select batchno from #Batchdetails)'                                                             
exec (@qury)                                            
set @qury=''                                                           
            
            
/*********************** Parent Batch Creation ************************/                  
insert into Athena_ChildBatchgeneration                                   
select MAX(Batchid)+1 from athena_childBatchGeneration                                   
select @Batchclientid=MAX(Batchid) from athena_childBatchGeneration        
INSERT INTO Athena_ParentBatchGeneration(ParentBatch) values (Convert(varchar(10),@Batchclientid) )                                                   
                       
set @ParentBatchid = SCOPE_IDENTITY()                                               
set @ParentBatchNo='S' + Convert(varchar(10),@ParentBatchid) + 'A1'                                                                                                                     
 /************************ Insert the Child Batch in Temporary  Table  ************************/              
insert into #MergeBatchDetails(batchno , pagecount,Fname,status,dollarAmt)                                    
select c.batchno,pgcount,'\\fs-ib'+SUBSTRING(a.Fname,CHARINDEX('\',a.Fname,3),LEN(a.Fname)),0,b.dollarAmt from trn_koff_tbatches a      
 inner join Arc_Athena..batchMaster b on a.BatchNo=b.batchnum        
 inner join #BatchDetails c on c.BatchNo=b.batchnum      
left join mergebatchdetails mrg on a.BatchNo=mrg.ChildBatchNo      
where ChildBatchNo is null and convert(varchar,ScanDate,101)=convert(varchar,@scandate,101)                                         
and a.status=99  and ServiceId=cast(@serviceid as int)                                    
  /***************************Logically Batches are Merge ************************/             
declare @CurMergeBatch cursor                                                                              
set  @CurMergeBatch  = cursor fast_forward for                                                                         
                     
select batchno, pagecount,Fname,dollaramt from #MergeBatchDetails where status=0                                                                           
                 
open  @CurMergeBatch                                                                                                                                                    
                                                                               
fetch next from @CurMergeBatch into                                                                         
@BatchNo,@PgCount ,@Fname,@dollaramt                                                                         
            
while(@@fetch_status<>-1)                                                                           
Begin                                          
            
set @count=@count+@pgcount                                                                                            
if(@Count>=@Maxpagecount)                                    
begin                                                                      
Set @Count=0                                                                      
Set @Chk=0                                                              
select @Count=SUM(pagecount) from #MergeBatchDetails where status=0                                                                                                    
if(@Count<40)                     
begin                                                         
update TRN_kOFF_tBatches set status=1 where BatchNo in(                           
select BatchNo from #MergeBatchDetails where status=0)                                                        
Goto NextSubClient                                                            
End                                   
         
set @count=0                                                      
set @count=@count+@pgcount                                                                          
            
insert into Athena_ChildBatchgeneration                                   
select MAX(Batchid)+1 from athena_childBatchGeneration                                    
select @Batchclientid=MAX(Batchid) from athena_childBatchGeneration                                    
INSERT INTO Athena_ParentBatchGeneration(ParentBatch) values (Convert(varchar(10),@Batchclientid) )                                                             
set @ParentBatchid = SCOPE_IDENTITY()                                                                          
set @ParentBatchNo='S' + Convert(varchar(10),@ParentBatchid) + 'A1'           
                    
            
if (@Chk=0)                                                                      
begin                                                                      
Set @Chk=1                                                                      
set @StartPgNo=1                                                                      
set @EndPgNo=@PgCount                                                                      
End                                                                        
else                                                                      
begin                                        
set @StartPgNo=@EndPgNo+1                                                                      
set @EndPgNo= @startpgno + (@PgCount-1)                                       
End                                                                     
End                                                                      
            
else                                                                       
begin                                     
if (@Chk=0)                                                                      
begin                                                                      
Set @Chk=1                                                       
set @StartPgNo=1                                                                      
set @EndPgNo=@PgCount                                                                                    
End                 
            
else                                       
begin                                                                     
set @StartPgNo=@EndPgNo+1                                                                      
set @EndPgNo= @startpgno + (@PgCount-1)                                                                      
End                                                                        
end                                                                      
            
INSERT INTO MergeBatchDetails(ParentBatchNo,childBatchNo,StartPgNo,EndpgNo,TotalPages,status,Fname,dollaramt)                                                                      
values(@ParentBatchNo,@BatchNo,@StartPgNo,@EndPgNo,@PgCount,1,'\\fs-ib'+SUBSTRING(@Fname,CHARINDEX('\',@Fname,3),LEN(@Fname)),@dollaramt)                                                                         
update #MergeBatchDetails set status=1 where BatchNo=@BatchNo                                                            
             
fetch next from @CurMergeBatch  into                                                                         
@BatchNo,@PgCount,@Fname,@dollaramt                                   
               
End                                                                         
            
NextSubClient:                                    
              
close @CurMergeBatch                                      
deallocate @CurMergeBatch                                                            
                 
if(object_id('tempdb.dbo.#MergeBatchDetails')is not null)drop table #MergeBatchDetails                   
if(object_id('tempdb.dbo.#BatchDetails')is not null)drop table #BatchDetails                   
if(object_id('tempdb.dbo.#BatchCountDetails')is not null)drop table #BatchCountDetails         
if(object_id('tempdb.dbo.#EntClient')is not null)drop table #EntClient         
End        
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_EnterpriseMergetBatch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_EnterpriseMergetBatch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_EnterpriseMergetBatch] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_EnterpriseMergetBatch] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_EnterpriseMergetBatch] TO [DB_DMLSupport]
    AS [dbo];

