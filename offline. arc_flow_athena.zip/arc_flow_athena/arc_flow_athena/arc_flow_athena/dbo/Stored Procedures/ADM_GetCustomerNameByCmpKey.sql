﻿CREATE Procedure  ADM_GetCustomerNameByCmpKey
(
 @Cmpkey varchar(5)=''
)
As
Begin
/*ADM_GetCustomerNameByCmpKey 'WISCO'*/
      Select InternalName,REPLACE(convert(varchar,GETDATE(),101),'/','') as CurrentDate,convert(varchar,dbo.FormatTimeZone(GETDATE(),'EST'),101) as ESTTime 
      from ADM_Customer  where CmpKey=@Cmpkey
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_GetCustomerNameByCmpKey] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetCustomerNameByCmpKey] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetCustomerNameByCmpKey] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_GetCustomerNameByCmpKey] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetCustomerNameByCmpKey] TO [DB_DMLSupport]
    AS [dbo];

