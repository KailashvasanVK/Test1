﻿CREATE Procedure  CUS_kWISCO_pBatchImportAction
(
@CreatedBy int = 1777
,@SystemUserId int = 1777
,@DownLoadDate datetime=''
,@ScanDate date =''
,@BatchType int = 3 /* No document */
,@ErrMsg varchar(max)=''
,@CustomerId int = 23 /** Wisconsin customerid **/
,@ServiceIdSalesOrder int = 193 /** Sales Order Service **/
,@WIPILogClassifyId int = 0 /** Have to replace **/
,@WIPIdDefault int = 1
,@FName varchar(50)=''
,@serviceId int=193
)
as
 BEGIN 
	--	declare @DownLoadDate datetime=''
	--	declare @ScanDate datetime=''
	set @DownLoadDate = Convert(varchar,convert(date,getdate())) + ' 9:00:00'
	set @ScanDate = DATEADD(DD,-1,@DownLoadDate) 
	--declare @CreatedBy int =1777
	--	declare @ServiceIdSalesOrder int= 168
	--	declare @serviceId int=168
	--	declare @CustomerId int= 94
	if(select COUNT(*)  from TRN_kWISCO_tBatches  where convert(date,CreatedDt) = CONVERT(date,getdate()) and CreatedBy =1777 and ServiceId=193)>0
	begin 
	    RAISERROR('Batch already downloaded',16,1)
     Return
	End

	Update CUS_kWISCO_tBatchImportTable Set ClientId = ci.ClientId,ServiceId = @serviceId
	,BatchNo = CONVERT(varchar,t.SO_Number) + '_' + ci.ClientAcmName
	,ReqBatchNo = CONVERT(varchar,t.SO_Number) + '_' + ci.ClientAcmName
	from CUS_kWISCO_tBatchImportTable as t
	inner join ADM_Client as ci on ci.CustomerId = @CustomerId and ci.ClientAcmName = t.NickName


	Update CUS_kWISCO_tBatchImportTable set DuplicateCount = (Select COUNT(BatchGroupNo) from TRN_kWISCO_tBatches where BatchGroupNo = tBat.BatchNo)
	from CUS_kWISCO_tBatchImportTable tBat

	Update CUS_kWISCO_tBatchImportTable Set ReqBatchNo = BatchNo + '_' + Convert(varchar,DuplicateCount)
	Where DuplicateCount <> 0

	Insert into TRN_kWISCO_tBatches(ScanDate,BatchNo,ClientId,ServiceId,BatchType,CreatedBy,CreatedDt,Priority,PgCount,FName,status,QType,CreatedOn,BatchGroupNo)
	select distinct @ScanDate,ReqBatchNo,ClientId,ServiceId,3,@CreatedBy,@DownLoadDate,0,1,'',1,2,GETDATE(),BatchNo from CUS_kWISCO_tBatchImportTable 

	insert into TRN_kWISCO_tBatchQueue(BatchId,BatchNo,PageFrom,PageTo,Assigned,ClientId,ServiceId,StatusId,Comment,CreatedBy,CreatedDt,QType)
	select BatchId,BatchNo,1,PgCount,0,ClientId,ServiceId,0,'',CreatedBy,CreatedDt,QType 
	from TRN_kWISCO_tbatches where ServiceId = @ServiceIdSalesOrder and ScanDate=CONVERT(varchar,@ScanDate,101)--and CreatedDt =CONVERT(varchar,@DownLoadDate,101)

	insert into TRN_kWISCO_tBatchFlow(BatchId,BatchProcessId,CreatedDt,CreatedBy,StatusId,Comments,Ref_FlowId)
	select que.BatchId,que.BatchProcessId,que.CreatedDt,que.CreatedBy,0,'',0 
	from TRN_kWISCO_tbatches bat
	inner join TRN_kWISCO_tBatchQueue que on bat.BatchId =  que.BatchId 
	where bat.ScanDate=CONVERT(varchar,@ScanDate,101) and bat.ServiceId =@ServiceIdSalesOrder-- and  bat.CreatedDt =CONVERT(varchar,@DownLoadDate,101)

	Update TRN_kWISCO_tBatchQueue set FlowId = (Select MAX(flowid) from TRN_kWISCO_tBatchFlow Where BatchProcessId = que.BatchProcessId)
	from TRN_kWISCO_tBatchQueue  as Que
	inner join TRN_kWISCO_tBatches  bat on bat.BatchId =que.BatchId and bat.ServiceId =@ServiceIdSalesOrder and bat.ScanDate=CONVERT(varchar,@ScanDate,101)
	-- and bat.CreatedDt=CONVERT(varchar,@DownLoadDate,101) 

END



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kWISCO_pBatchImportAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kWISCO_pBatchImportAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kWISCO_pBatchImportAction] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kWISCO_pBatchImportAction] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kWISCO_pBatchImportAction] TO [DB_DMLSupport]
    AS [dbo];

