﻿CREATE Proc Athena_Index_temp                                                          
@userinfo varchar(50)                                                       
as                                                            
/*This SP willl pick the batch for indexing the batch for TaxID,NPI,Dollaramt and Payeeno*/                                                            
/*Create By Ramakrishnang. Aug 7th 2014,Modified by Noor Oct 23,2014                                                  
to assign multiple user*/                                                            
                                                            
Declare @Batchno varchar(20),@rowcnt int                 
Declare @InsuranceName varchar(Max)                                                        
                                      
GetBatch:           
          
SELECT top 1 @Batchno=batchnum from batchIndex_TrackBatches  a                 
inner join trn_koff_tbatches  b  on a.batchnum=b.BatchNo           
where userinfo=@userinfo and cstatus=0  and b.status=3                                                          
          
--SELECT top 1 @Batchno=batchnum from batchIndex_TrackBatches  a                 
--inner join trn_koff_tbatches  b on a.batchnum=b.BatchNo where userinfo=@userinfo and cstatus=0  and b.status=3                                                          
--and batchno in (select batch from arc_athena..CBO_Payerinfo)            
                                                      
if(@Batchno is not null)                                                      
begin                                                      
      SELECT @Batchno as BatchNo                
      SELECT @InsuranceName = ISNULL((Select PayerName from ADM_PayerName (nolock) Where PayerName IN              
                              (SELECT PAYMENTBATCHROUTE from arc_athena..CBO_Payerinfo (nolock)             
                              Where Batch=@Batchno )),0)              
            
SELECT @InsuranceName As PayerName                                                                                    
      Return                                                      
End                                                      
ELSE                                                      
BEGIN                                                      
                                                            
----select Top 1 @Batchno=Batchno from trn_koff_tbatches   (nolock)                  
----where uploaddt  is null and serviceid<>363 and status=3  and BatchNo not  in(                      
----select batchnum from   batchIndex_TrackBatches  (nolock) where CompletedDate is null )                                                        
----order by ScanDate asc, PgCount  desc                  
----------select Top 1  @Batchno =Batchno from trn_koff_tbatches   (nolock)   a                
----------left outer join batchIndex_TrackBatches  b on a.batchno=b.batchnum                 
----------where uploaddt  is null and serviceid<>363 and status=3  and b.batchnum is null                
----------and batchno in (select batch from arc_athena..CBO_Payerinfo)            
----------order by ScanDate asc, PgCount  desc                                                       
             
             
   select Top 1  @Batchno=Batchno from trn_koff_tbatches  a   
left outer join batchIndex_TrackBatches  b on a.batchno=b.batchnum  
left outer join arc_athena..CBO_Payerinfo ap on ap.Batch=a.BatchNo           
where  b.batchnum is null and a.uploaddt  is null and a.serviceid<>363 and a.status=3  
--and batchno in (select batch from arc_athena..CBO_Payerinfo)            
order by  a.Priority desc ,ScanDate asc, PgCount  desc          
          
                                                  
                                               
if(@Batchno is not null)                                                      
begin              
--insert into batchIndex_TrackBatches (batchnum,userinfo,cstatus)values(@Batchno,@userinfo,0)                                                          
                                          
Insert into batchIndex_TrackBatches (batchnum,userinfo,cstatus)                                          
SELECT @Batchno,@userinfo,0 WHERE NOT EXISTS(SELECT 1 FROM batchIndex_TrackBatches where batchnum=@Batchno)                                        
                      
SELECT @InsuranceName = ISNULL((Select PayerName from ADM_PayerName (nolock) Where PayerName IN              
                              (SELECT PAYMENTBATCHROUTE from arc_athena..CBO_Payerinfo (nolock) Where Batch=@Batchno)),0)              
Print @InsuranceName                                               
--Print 'donw'            
--SELECT @rowcnt=@@ROWCOUNT                          
                                      
--IF(@rowcnt=0)                          
IF NOT EXISTS (SELECT 1 FROM batchIndex_TrackBatches where batchnum=@Batchno)                         
Begin                                      
GOTO GetBatch                                         
End                        
                                          
End                                                          
SELECT @Batchno as BatchNo                
SELECT @InsuranceName As PayerName                                       
END 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_temp] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_temp] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_temp] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_temp] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_temp] TO [DB_DMLSupport]
    AS [dbo];

