﻿CREATE Procedure Automation_ProcessingReport_SendMailReport  
as  
begin  
declare @xml varchar(max),@body varchar(Max),                                         
@From_Mailid varchar(100),                                            
@REcipients varchar(500),                                            
@CC varchar(1000),                                            
@Subject varchar(100),                                            
@ishtml varchar(5) 
 
if object_id('tempdb.dbo.#TempbatchList') is not null drop table tempdb.dbo.#TempbatchList 
 
create table #TempbatchList (UserName varchar(max),BatchNo varchar(max),	pgCount int,MaxPageProcessed int,	
PaymentTrans int,CreationTrans int,	ExceptionTrans	int, PatientPosting int,CollectionPosting int)

insert into #TempbatchList(UserName,BatchNo,pgCount,MaxPageProcessed,PaymentTrans,CreationTrans,ExceptionTrans,PatientPosting,CollectionPosting)
exec Automation_ProcessingReport
  
         
SET @xml = CAST((select                  
UserName AS 'td',''                                   
,BatchNo AS 'td',''                                   
,pgCount AS 'td',''  
,MaxPageProcessed AS 'td',''  
,PaymentTrans  AS 'td',''  
,CreationTrans AS 'td',''                                   
,ExceptionTrans AS 'td',''  
,PatientPosting AS 'td',''  
,CollectionPosting  AS 'td','' 
from #TempbatchList  
          
FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))             
          
--select @xml           
          
SET @body ='<html><head><title>Access Healthcare</title>                      
   <style type=text/css>                       
   .general{    FONT-FAMILY:VERDANA,ARIAL;FONT-SIZE:8pt;}                      
   .general1{    FONT-FAMILY:VERDANA,ARIAL;FONT-SIZE:14pt;}                      
   .general2{    FONT-FAMILY:VERDANA,ARIAL;FONT-SIZE:12pt;}                      
   .titleTR {     FONT-FAMILY:VERDANA,ARIAL;    FONT-SIZE:8pt; color: #FFFFFF; font-weight:bold; background-color:#003366; height:20;}                      
   tr {      FONT-FAMILY:VERDANA,ARIAL;    FONT-SIZE:8pt; background-color:#F0F0FF ; height:20;}                      
   </style>                       
</head><body>                                    
                                    
<table  border=0 cellspacing=1 cellpadding=1 width=75% align=center  >                                    
<tr class=''titletr''  bgcolor=#1457a7  align=center color=#FFFFFF height=''20''>  
                                     
<th>UserName</th>  
<th>BatchNo</th>                                    
<th>pgCount</th>  
<th>MaxPageProcessed</th>  
<th>PaymentTrans</th>  
<th>CreationTrans</th>  
<th>ExceptionTrans</th>                                    
<th>PatientPosting</th>  
<th>CollectionPosting</th>  
 </tr>'                                        
                                     
SET @body = @body + @xml +'<tr class=''titletr''   bgcolor=#1457a7  align=center color=#FFFFFF height=''20''><th colspan=''12''>&nbsp;</th></tr></table></br>                                    
<table>               
</body></html>'                   
                       		           
set @From_Mailid='dump@accesshealthcare.com'                                            
set @REcipients='karthick.radhak@accesshealthcare.com;devendran.pandu@accesshealthcare.com;WATERTOWN-APPSUPPORTUSERS@accesshealthcare.com;DL-WTP@accesshealthcare.com;mirza.karim@accesshealthcare.com;sathish.v@accesshealthcare.com;akashprabupr.r@accessheathcare.com;nithya.g2@accesshealthcare.com;rahini.subburam@accesshealthcare.com'                                           
set @CC='ramakrishnan.go@accesshealthcare.com;mirza.karim@accesshealthcare.com;karthick.radhak@accesshealthcare.com;satheesh.seetha@accesshealthcare.com;abdulriaz.jm@accesshealthcare.com;dl_dba@accesshealthcare.com'
set @Subject= 'Bigger Batch details'                          
set @ishtml='Y'     

if exists (select * from #TempbatchList)
begin 
INSERT INTO ARC_Rec_Athena.dbo.Arc_Rec_Mail_Tran(FROM_MAILID,RECIPIENTS,SUBJECT_Text,BODY,ISHTML,CC)                                            
VALUES(@FROM_MAILID,@RECIPIENTS,@SUBJECT,@body,@ISHTML,@CC)  
end
else 
begin

INSERT INTO ARC_Rec_Athena.dbo.Arc_Rec_Mail_Tran(FROM_MAILID,RECIPIENTS,SUBJECT_Text,BODY,ISHTML,CC)                                            
VALUES(@FROM_MAILID,@RECIPIENTS,@SUBJECT,'<html><p align="center"><font color="green"><b><br/><br/>Currently there is no bigger batches available.<br/><br/><br/><br/></b></font></p></html> ',@ISHTML,@CC)  
end
End                       




GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Automation_ProcessingReport_SendMailReport] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Automation_ProcessingReport_SendMailReport] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Automation_ProcessingReport_SendMailReport] TO [DB_DMLSupport]
    AS [dbo];

