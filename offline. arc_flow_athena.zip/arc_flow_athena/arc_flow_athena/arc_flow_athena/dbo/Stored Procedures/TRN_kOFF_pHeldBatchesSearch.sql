﻿
Create Procedure TRN_kOFF_pHeldBatchesSearch  
    @CmpKey varchar(20)='',    
    @Userid int=7,   
    @ClientId  int=0,   
    @ServiceId  int=0,    
    @BatchNO varchar(75)='',    
    @ToDate  varchar(75)='',   
    @FromDate  varchar(75)='',    
    @StatusId int=3,      
    @Query varchar(max)='',      
    @Sort varchar(max)='',   
    @displayStart int=0,   
    @displayLength int =50,  
    @DateMode varchar(5)='',
	@SearchStr varchar(100) = '', 
	@payerID  int = 0  ,
	@SearchPattern varchar(4) = '=' /** = or % **/     
      
as    
Begin       
	/*     
		purpose   :  To select the helded Batch details by custmerId     
		createdBy : Bhuvaneswari   
		CreatedDt : 11/July/2013     
		ipmact to :HeldBatches.aspx     
	*/
	/*  
		Declare @CmpKey varchar(20)='',    
		@Userid int=0,   
		@ClientId  int=0,   
		@ServiceId  int=0,    
		@BatchNO varchar(75)='',    
		@ToDate  varchar(75)='2015-02-20',   
		@FromDate  varchar(75)='2015-02-28',    
		@StatusId int=17,      
		@Query varchar(max)='',      
		@Sort varchar(max)='',   
		@displayStart int=0,   
		@displayLength int =50,  
		@DateMode varchar(5)='D',
		@SearchStr varchar(100) = '', 
		@payerID  int = 0  ,
		@SearchPattern varchar(4) = '=' /** = or % **/  
  */
	declare @FromScanDate as datetime,
			@ToScanDate as datetime,
			@FromDownloadDate as datetime,
			@ToDownloadDate as datetime

	if(@DateMode = 'D')
	begin
			set  @FromScanDate  = convert(date,'1900-01-01')
			set @ToScanDate  = DateAdd(day, 1, GETDATE())
			set @FromDownloadDate =  convert(date,@FromDate)
			set @ToDownloadDate = convert(date,@ToDate)
	END
	ELSE IF (@DateMode = 'S')
	Begin
			set  @FromScanDate  =  convert(date,@FromDate)
			set @ToScanDate  =  convert(date,@ToDate)
			set @FromDownloadDate =  convert(date,'1900-01-01')
			set @ToDownloadDate = DateAdd(day, 1, GETDATE())
	END 
  
  
  	declare @CustomerId as int     
	select @CustomerId = CustomerId from ADM_Customer where CmpKey = @CmpKey   
  
   select Distinct bat.BatchId as [BatchId~Hide],bat.BatchNo,ClientAcmName as Client,s.ServiceName,bat.PgCount as TotalPages,  
  CONVERT(varchar,bat.ScanDate,101) as ScanDate,CONVERT(varchar,bat.CreatedDt,101) as DownloadDate,(REPLACE(bat.FName,'\','/')) as [FileURL~Hide]  
  ,(Select ' ' + Ui.NT_USERNAME + ' : ' + Flow.Comments from TRN_kOFF_tBatchQueue as Q  
  inner join TRN_kOFF_tBatchFlow as Flow on Flow.FlowId = Q.FlowId  
  inner join ARC_Rec_Athena..ARC_REC_USER_INFO as ui on ui.USERID = Flow.CreatedBy  
  Where Q.BatchId = Bat.BatchId and Q.StatusId = @StatusId  
  for xml path('')  
  ) as BatchComment  ,(select PayerName from ADM_PayerName_View where PayerId = bat.PayerId) as PayerName   
  
  ,case when @StatusId = 3 then        
  '<a  href="#" title="Held Batch" onclick="HeldBatches('+ convert(varchar,bat.BatchId) + ' ,'' '
  +CONVERT(varchar,bat.BatchNo)+' '','+CONVERT(varchar,bat.PgCount)+','+  convert(varchar,@StatusId)    +','''+( REPLACE(bat.FName,'\','/'))+''')">     
  <span class="ui-icon ui-icon-newwin"></span></a>'     
  when @StatusId = 17 then '<a  href="#" title="Held Batch"         
  onclick="HeldBatches('+ convert(varchar,bat.BatchId) + ','' '+CONVERT(varchar,bat.BatchNo)
  +' '','+CONVERT(varchar,bat.PgCount)+','+  convert(varchar,@StatusId)    +','''+(REPLACE(bat.FName,'\','/'))+''')">     
  <span class="ui-icon ui-icon-newwin"></span></a>' else '' end as [Action]
	from TRN_kOFF_tBatches  bat     
	inner join TRN_kOFF_tBatchQueue batq on batq.BatchId = bat.BatchId   and bat.status = @StatusId   
	inner join ADM_BatchStatusMaster as bm on bm.StatusId = batq.StatusId 
	inner join ADM_Client c on c.ClientId= batq.ClientId 
	inner join ADM_Service s on  s.ServiceId = batq.ServiceId  	
	inner  join ADM_Service ser on ser.ServiceId  =  bat.ServiceId and ser.Status =1 
	--inner join ADM_FileServer as fs on fs.FacilityId = 1 and fs.CustomerId=@CustomerId  where bat.status=1 
	AND  DATEADD(day, DATEDIFF(day, 0, bat.CreatedDt), 0) between  @FromDownloadDate  and @ToDownloadDate  
    AND  DATEADD(day, DATEDIFF(day, 0, ScanDate), 0)  between  @FromScanDate and  @ToScanDate 
	AND exists (select 1 from TRN_kOFF_tBatchQueue q where q.BatchId = bat.BatchId and q.StatusId = 3)     
	AND batq.ClientId = case when @ClientId <> 0 then @ClientId  else batq.ClientId  end 
	AND  batq.ServiceId  = case when @ServiceId <> 0 then @ServiceId  else  batq.ServiceId  end 
	AND batq.BatchNo = case when @BatchNO <> '' then @BatchNO  else  batq.BatchNo  end 
	and ISNULL(bat.PayerId, 0 ) = (case  when ISNULL(@payerID, 0 ) <> 0 then @payerID else  ISNULL(bat.PayerId, 0 ) end)	
	and  exists (Select 1 from TRN_kOFF_tHeldBatches Where BatchId = case when @StatusId = 17 then bat.BatchId else 0 end and ReleaseDate is null)
	and  exists (Select 1 from TRN_kOFF_tBatchQueue  Where BatchId = case when @StatusId = 3 then bat.BatchId else 0 end)	  
End 

 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pHeldBatchesSearch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pHeldBatchesSearch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pHeldBatchesSearch] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pHeldBatchesSearch] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pHeldBatchesSearch] TO [DB_DMLSupport]
    AS [dbo];

