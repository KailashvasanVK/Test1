﻿CREATE  proc ScanDateSendMail(@folderdate varchar(50), @body varchar(max))                          
as                          
begin                          
/* Created by :Leela.T created on 8th Oct 2014                          
Requested by: ramki,                          
Purpose: Send mail for detail Remit Process*/                          
declare                          
@From_Mailid varchar(100),                          
@REcipients varchar(500),                          
@CC varchar(1000),                          
@Subject varchar(100),                          
@ishtml varchar(5)                          
                          
                          
set @From_Mailid='dump@accesshealthcare.co'                          
set @REcipients='ramakrishnan.go@accesshealthcare.co ,mohan.nagarajan@accesshealthcare.co,sathyanaraya.l@accesshealthcare.co'                         
set @CC='daisy.ks@accesshealthcare.co, peter.ponnurang@accesshealthcare.co,vijayaraj.gnana@accesshealthcare.co,muthu.B@accesshealthcare.co,                          
johnmarytere.ls@accesshealthcare.co,ramesh.raju@accesshealthcare.co,leela.thangavel@accesshealthcare.co,noormohamed.h@accesshealthcare.co,          
aliakbar.sibbak@accesshealthcare.co,balaji.j1@accesshealthcare.co,rajkumar.balasu@accesshealthcare.co,santhoshkuma.b@accesshealthcare.co,      
senthilkumar.m2@accesshealthcare.co,raja.m1@accesshealthcare.co,herojirao.premn@accesshealthcare.co,gobinath.m@accesshealthcare.co,mohamedsafiyu.a@accesshealthcare.co,kathiravan.kand@accesshealthcare.co'      
                         
set @Subject= @folderdate                          
set @ishtml='Y'                          
INSERT INTO ARC_Rec_Athena..Arc_Rec_Mail_Tran(FROM_MAILID,RECIPIENTS,SUBJECT_Text,BODY,ISHTML,CC)                          
VALUES(@FROM_MAILID,@RECIPIENTS,@SUBJECT,@BODY,@ISHTML,@CC)                          
End      

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ScanDateSendMail] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ScanDateSendMail] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ScanDateSendMail] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ScanDateSendMail] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ScanDateSendMail] TO [DB_DMLSupport]
    AS [dbo];

