﻿
CREATE procedure  [dbo].[ADM_ProfileAccessClientMove]  
@UserIdCollection varchar(max),  
@CustomerId int  ,
@ServiceId int
As  
/*  
Created by : karthick .M7
Created on : 03 03 2015    
Impact to  : ProfileSetup.aspx    
Purpose    : To save the user client wise service details.   
Modified by : Kathiravan.kand
*/  
Begin  


if exists(Select top 1 'x' from ADM_AccessClient Where  CustomerId = @CustomerId and   UserId  in (select items from fnSplitString(@UserIdCollection,','))   )
	Begin  
	
		Insert into ADM_AccessClientLog (UserId,ClientId,ServiceId,CreatedBy,CreatedDt,AccClientId,CustomerId)  
		Select UserId,ClientId,ServiceId,CreatedBy,CreatedDt,AccClientId,CustomerId From  ADM_AccessClient Where UserId in (select cast(items as int) from fnSplitString(@UserIdCollection,',')) and CustomerId = @CustomerId
		Delete from ADM_AccessClient Where ServiceId = @ServiceId and   CustomerId = @CustomerId and UserId  in (select cast(items as int) from fnSplitString(@UserIdCollection,','))  

	End  
End



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ProfileAccessClientMove] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileAccessClientMove] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileAccessClientMove] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ProfileAccessClientMove] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileAccessClientMove] TO [DB_DMLSupport]
    AS [dbo];

