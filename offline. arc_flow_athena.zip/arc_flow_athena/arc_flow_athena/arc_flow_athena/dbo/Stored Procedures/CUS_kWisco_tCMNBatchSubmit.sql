﻿CREATE Procedure  CUS_kWisco_tCMNBatchSubmit
(
@SONumber varchar(50),
@ClientId int,
@ServicId int,
@TransValue int,
@InfoValue varchar(50),
@CreatedBy int,
@ScanDate date,
@Downloaddate date,
@Comments varchar(max),
@Action varchar(100),
@serviceParam varchar(max)
)
as
  Begin
  
  if(@Action ='InsertSOBINBatch')
 Begin
 
		Declare @BatchId int =0
		Declare @BatchProcessId int =0
		Declare @BatchServiceId int = 348 /* CMN - 348*/
		
       if(select 1 from TRN_kAHS_tBatches where BatchNo =@SONumber and ServiceId =@BatchServiceId) > 0 
        begin
          RAISERROR('Bath already exists',16,1)
          return
        End

		Select x.ServiceId,x.ServiceValue,Ser.FieldType into #BatchServiceValues from 
		(
		Select left(ITEMS,CHARINDEX('#split#',ITEMS) - 1) as ServiceId
		,right(ITEMS,len(ITEMS) - (CHARINDEX('#split#',ITEMS) + 6))   as ServiceValue    
		FROM dbo.MySplit(@serviceParam, '#deli#') as tmp
		)x 
		inner join ADM_Service as Ser on Ser.ServiceId = x.ServiceId  	     
 
    --if(select COUNT(*) from TRN_kAHS_tBatches where BatchNo =@SONumber and ServiceId =@BatchServiceId) =0
    --begin  	    
		Insert into TRN_kAHS_tBatches(ScanDate,BatchNo,ClientId,ServiceId,BatchType,CreatedBy,CreatedDt,Priority,PgCount,FName,status,QType,CreatedOn)
		select distinct @ScanDate,@SONumber,@ClientId,@BatchServiceId,3,@CreatedBy,@DownLoadDate,0,1,'',1,2,GETDATE() 

		set @BatchId = IDENT_CURRENT('TRN_kAHS_tBatches') 

		insert into TRN_kAHS_tBatchQueue(BatchId,BatchNo,PageFrom,PageTo,Assigned,ClientId,ServiceId,StatusId,Comment,CreatedBy,CreatedDt,QType)
		select @BatchId,BatchNo,1,PgCount,0,ClientId,ServiceId,6,@Comments,CreatedBy,CreatedDt,QType 
		from TRN_kAHS_tbatches where BatchId = @BatchId --and  ServiceId =@ServicId

		set @BatchProcessId = IDENT_CURRENT('TRN_kAHS_tBatchQueue') 

		insert into TRN_kAHS_tBatchFlow(BatchId,BatchProcessId,CreatedDt,CreatedBy,StatusId,Comments,Ref_FlowId)
		select @BatchId,@BatchProcessId,GETDATE(),@CreatedBy,0,'',0 
		union all 
		select @BatchId,@BatchProcessId,GETDATE(),@CreatedBy,1,'',0 
		union all 
		select @BatchId,@BatchProcessId,GETDATE(),@CreatedBy,6,@Comments,0		

		Update TRN_kAHS_tBatchQueue set FlowId = (Select MAX(flowid) from TRN_kAHS_tBatchFlow Where BatchProcessId = @BatchProcessId)
		where BatchProcessId =@BatchProcessId

		insert into TRN_kAHS_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,CreatedBy,CreatedDt,BatchId,BatchServiceId)
		select @BatchProcessId,1,ServiceId,ServiceValue,@CreatedBy,GETDATE(),@BatchId,@BatchServiceId from #BatchServiceValues where FieldType='T'
		
		insert into TRN_kAHS_tBatchTransact(BatchProcessId,PageNo,ServiceId,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId)
		select @BatchProcessId,1,ServiceId,ServiceValue,@CreatedBy,GETDATE(),@BatchId,@BatchServiceId from #BatchServiceValues where FieldType='I'

		insert into TRN_kAHS_tBatchTransactSummary(BatchProcessId,ServiceId,TransValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId)
		select @BatchProcessId,ServiceId,ServiceValue,@CreatedBy,GETDATE(),@BatchId,@BatchServiceId,@ClientId from #BatchServiceValues where FieldType='T'
		
    --End
  End
Else if (@Action ='ValidateSOBINBatch')
   begin
          if(select 1 from TRN_kAHS_tBatches  where BatchNo =@SONumber and ClientId= @ClientId) > 0 -- and ServiceId =@BatchServiceId
            begin
                RAISERROR('Batch already exists',16,1)
              -- select 'EXIST'
             end
          --else
          --       select 'NOTEXIST'
          
   End 
  End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kWisco_tCMNBatchSubmit] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kWisco_tCMNBatchSubmit] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kWisco_tCMNBatchSubmit] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kWisco_tCMNBatchSubmit] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kWisco_tCMNBatchSubmit] TO [DB_DMLSupport]
    AS [dbo];

