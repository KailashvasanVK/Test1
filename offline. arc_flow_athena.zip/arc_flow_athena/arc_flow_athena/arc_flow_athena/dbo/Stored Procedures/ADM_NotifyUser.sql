﻿--  ADM_NotifyUser 975,16
CREATE Procedure ADM_NotifyUser
(
	@UserId int,
	@CustomerId int
 )
as
BEGIN
	Declare @Err varchar(max)
	declare @Acnt int =( select COUNT(*) from ARC_FLOW_Athena..ADM_AccessFunctionality where Functionality = 'A' and UserId = @UserId)
	declare @Pcnt int =( select COUNT(*) from ARC_FLOW_Athena..ADM_AccessFunctionality where Functionality = 'P' and UserId = @UserId) 
	create table  #tempTest  (ServiceCustomer varchar(50)) 
	insert into #tempTest   (ServiceCustomer ) 
	Select cus.InternalName + ' - '  + ser.ServiceName 
	from ADM_AccessClient as acl
	inner join ADM_Customer as cus on cus.CustomerId = acl.CustomerId
	inner join ADM_Service as ser on ser.ServiceId = acl.ServiceId and ser.Status = 1 
	Where acl.UserId =@UserId and acl.CustomerId=@CustomerId and @Pcnt > 0
	and not exists (select 1 from ADM_AccessTarget where CustomerId = acl.CustomerId and UserId = acl.UserId and ServiceId = acl.ServiceId
	and isnull(ProcessTargetId,0) <> 0
	and isnull(QcTargetId,0) <> 0
	and isnull(PTLevelId,0) <> 0
	and isnull(QCLevelId,0) <> 0)
	union 
	Select cus.InternalName + ' - '  + ser.ServiceName 
	from ADM_AccessClient as acl
	inner join ADM_Customer as cus on cus.CustomerId = acl.CustomerId
	inner join ADM_Service as ser on ser.ServiceId = acl.ServiceId and ser.Status = 1 
	Where acl.UserId =@UserId and acl.CustomerId=@CustomerId and @Acnt > 0 
	and not exists (select 1 from ADM_AccessTargetQC where CustomerId = acl.CustomerId and UserId = acl.UserId and ServiceId = acl.ServiceId
	and isnull(QualityTargetId,0) <> 0
	and isnull(QALevelId,0) <> 0)
	group by cus.InternalName,ser.ServiceName
	Set @Err = 
	( 
	select ServiceCustomer  from #tempTest 
	for xml path('p'))
	select  'Please set target for below services ' + @Err
	if OBJECT_ID('tempdb..#tempTest') is not null drop table #tempTest 
	
END






GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_NotifyUser] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_NotifyUser] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_NotifyUser] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_NotifyUser] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_NotifyUser] TO [DB_DMLSupport]
    AS [dbo];

