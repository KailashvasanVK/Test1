﻿Create Proc FlowData(@Scandate datetime)
as
select * from arc_flow_athena..trn_koff_tbatches(nolock) a 
inner join batchmaster (nolock)b on a.batchno=b.batchnum where a.ScanDate= @Scandate 

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[FlowData] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[FlowData] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[FlowData] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[FlowData] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[FlowData] TO [DB_DMLSupport]
    AS [dbo];

