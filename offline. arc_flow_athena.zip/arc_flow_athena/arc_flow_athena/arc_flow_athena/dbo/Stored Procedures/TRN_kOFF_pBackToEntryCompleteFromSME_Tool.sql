﻿Create procedure TRN_kOFF_pBackToEntryCompleteFromSME_Tool(@BatchNo varchar(75),@Comments varchar(300),@CreatedBy int)
As
Begin
Declare @BatchId int,@BatchProcessId int,@FlowId int,@BatchServiceId int,@StatusId int
Select @BatchId = BatchId, @BatchProcessId = BatchProcessId,@BatchServiceId = ServiceId,@StatusId = StatusId 
from TRN_kOff_tBatchQueue where BatchNo = @BatchNo
if @StatusId = 20
	Begin
	Insert into TRN_kOFF_tBatchFlow(BatchProcessId,BatchId,CreatedBy,CreatedDt,StatusId,Comments,Ref_FlowId)             
	Select @BatchProcessId,@BatchId,@CreatedBy,GETDATE(),6,@Comments,0 
	Select @FlowId = IDENT_CURRENT('TRN_kOFF_tBatchFlow')
	Update TRN_kOFF_tBatchQueue Set FlowId = @FlowId,StatusId = 6,Comment = '',Assigned=0 where BatchProcessId = @BatchProcessId
	End
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pBackToEntryCompleteFromSME_Tool] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBackToEntryCompleteFromSME_Tool] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBackToEntryCompleteFromSME_Tool] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pBackToEntryCompleteFromSME_Tool] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBackToEntryCompleteFromSME_Tool] TO [DB_DMLSupport]
    AS [dbo];

