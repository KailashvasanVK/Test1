﻿CREATE Procedure  DBD_TV_GENERATE_HOURLY_PRODUCTIONANDQUALITY_JOB  
As
       
begin   

Set nocount on  
SET ANSI_WARNINGS OFF
           
Declare @Qry varchar(max)        
Declare @CmpKey varchar(5) = 'OFF'        
Declare @CustomerId int = 15 

declare @fromDate date=null
declare @toDate date=null  

    
declare @fromDateTime datetime=null
declare @toDateTime datetime=null  

DECLARE  @FromTime TIME='8:00:00',@ToTime TIME='07:59:59',@ProcessDate DATE    
DECLARE @minDateTime AS DATETIME;    
DECLARE @maxDateTime AS DATETIME;

SET @ProcessDate= dateadd (D,(case when CONVERT(time,GETDATE())< CONVERT(time,@FromTime ) then -1 
when CONVERT(time,GETDATE()) > CONVERT(time,@ToTime) then 0 else 0 end)    
,CONVERT(date,GETDATE()))

set @fromDate=@ProcessDate
set @toDate=@ProcessDate    

select @minDateTime=dateadd(DAY,0,(convert(datetime,cast(GETDATE() as DATE),103))+cast(@FromTime as datetime)),    
@maxDateTime=dateadd(DAY,1,(convert(datetime,cast(GETDATE() as DATE),103))+cast(@ToTime as datetime))    
                 
set @fromDateTime =@minDateTime  
set @toDateTime =@maxDateTime  


IF OBJECT_ID('tempdb..#tempTime') is not null Drop table #tempTime;    

WITH Dates_CTE    
AS (SELECT @minDateTime AS Dates    
UNION ALL    
SELECT Dateadd(hh, 1, Dates)    
FROM   Dates_CTE    
WHERE  Dates < @maxDateTime)    
SELECT  *    
into #tempTime FROM   Dates_CTE    
OPTION (MAXRECURSION 0)


if OBJECT_ID('tempdb..#tblfinalproduction') is not null drop table #tblfinalproduction    
create table #tblfinalproduction(rptdate date, RptDateHour int,CustomerId int,BatchServiceId int,Userid int,
RawTrans int, TotalBatches int,BatchesCompleted int, BatchesHeld int,FactorValue decimal(18,2),Target int,QAAcheived decimal(18,2),
ErrorFound int, ErrorFoundAudited int,ErrorDone int, ErrorDoneAudited int,datasource varchar(100),datatype varchar(100)
)
/***********************************************************Target************************************************/          
          
if OBJECT_ID('tempdb..#ProdRptAssociateTarget') is not null drop table #ProdRptAssociateTarget          
Create Table #ProdRptAssociateTarget          
(UserId int,DayTarget Decimal(10,2),ActDayTarget Decimal(10,2),CustomerId int,RptDate date,BatchServiceId int)          
Declare @trnQry varchar(max)          
if OBJECT_ID('tempdb..#AssTgt_DateWiseProcessed') is not null drop table #AssTgt_DateWiseProcessed          
Create Table #AssTgt_DateWiseProcessed(CmpKey varchar(5), UserId int,BatchServiceId int,ProcessedHrs decimal(10,2)
,EntryDate date,PD_Target decimal(10,2),ActTarget decimal(10,2),IsWorkingDay int)          
Set @qry = '          
Insert into #AssTgt_DateWiseProcessed(CmpKey,UserId,BatchServiceId,ProcessedHrs,EntryDate,PD_Target,ActTarget)          
Select '''+@CmpKey+''' as CmpKey, trn.UserId,trn.BatchServiceId, isnull(SUM(trn.ProcessedHrs),0) as ProcessedHrs,trn.EntryDate          
,CAST(Null as decimal(10,2)) PD_Target,CAST(Null as decimal(10,2)) as ActTarget          
from          
(          
Select flow.CreatedBy as UserId,batq.ServiceId as BatchServiceId,DATEDIFF(MINUTE,MIN(flow.CreatedDt),
Max(flow.CreatedDt))/60.0 as ProcessedHrs           
,Cast(Max(flow.CreatedDt) as date) as EntryDate          
from ARC_FLOW_ATHENA.dbo.TRN_k'+@CmpKey+'_tBatchFlow (nolock) as flow          
inner join ARC_FLOW_ATHENA.dbo.TRN_k'+@CmpKey+'_tBatchQueue (nolock) as batQ on batq.BatchProcessId = flow.BatchProcessId          
inner join ARC_FLOW_ATHENA.dbo.TRN_k'+@CmpKey+'_tBatches (nolock) as bat on bat.BatchId = batQ.BatchId and bat.Status = 1 
Where flow.CreatedDt Between '''+CAST(@fromDateTime as varchar)+''' and '''+CAST(@toDateTime as varchar)+'''          
and flow.StatusId in (1,6,7,12,13)          
Group by flow.BatchProcessId,flow.CreatedBy,batq.ServiceId          
)trn          
Group by trn.UserId,trn.BatchServiceId,EntryDate          
'    
Exec (@qry)   
   
if OBJECT_ID('tempdb..#AssTgt_AssociateTargetDetails') is not null drop table #AssTgt_AssociateTargetDetails          
Create Table #AssTgt_AssociateTargetDetails(CmpKey varchar(5),UserId int,ServiceId int,EntryDate date,ProductionTarget decimal(10,2),IsWorkingDay int,WorkDaysCount int,EntryStartDate date)          
          
Insert into #AssTgt_AssociateTargetDetails(CmpKey,UserId,ServiceId,EntryDate,ProductionTarget,IsWorkingDay,WorkDaysCount,EntryStartDate)          
Select CmpKey,UserId,ServiceId,EntryDate,ProductionTarget,IsWorkingDay,WorkDaysCount,EntryStartDate
 from ARC_FLOW_ATHENA.dbo.ADM_AssociateTarget          
Where EntryDate  between @fromDate and @toDate    

    
Set @qry = '          
Insert into #AssTgt_DateWiseProcessed(CmpKey,UserId,BatchServiceId,ProcessedHrs,EntryDate)          
Select CmpKey,UserId,ServiceId,8,EntryDate from #AssTgt_AssociateTargetDetails  as ass          
where not exists (select 1 from #AssTgt_DateWiseProcessed where UserId = ass.UserId and EntryDate = ass.EntryDate 
and BatchServiceId = ass.ServiceId)          
and not exists (select 1 from #AssTgt_DateWiseProcessed where UserId = ass.UserId and EntryDate = ass.EntryDate)          
'          
Exec (@qry)      

        
Update #AssTgt_DateWiseProcessed Set PD_Target = isnull(aTgt.ProductionTarget,0),ActTarget = isnull(aTgt.ProductionTarget,0)          
,IsWorkingDay = aTgt.IsWorkingDay          
from #AssTgt_DateWiseProcessed as Procd          
inner join #AssTgt_AssociateTargetDetails aTgt on aTgt.UserId = Procd.UserId and aTgt.EntryDate = Procd.EntryDate 
 and aTgt.ServiceId = Procd.BatchServiceId          
      
if OBJECT_ID('tempdb..#AssTgt_TotalProductionHour') is not null drop table #AssTgt_TotalProductionHour          
Select trn.UserId,trn.EntryDate, isnull(SUM(trn.ProcessedHrs),0) TotalProdHrs          
into #AssTgt_TotalProductionHour          
from #AssTgt_DateWiseProcessed as trn          
Group by trn.UserId,trn.EntryDate          
Having COUNT(batchServiceId) > 1     

Update trn Set           
PD_Target = isnull(( isnull(trn.ProcessedHrs,0) * (isnull(trn.PD_Target,0)/Case when isnull(dualProd.TotalProdHrs,0) <> 0 then isnull(dualProd.TotalProdHrs,0) else 1 end))
,PD_Target)
from #AssTgt_DateWiseProcessed as trn          
inner join #AssTgt_TotalProductionHour as dualProd on dualProd.UserId = trn.UserId and dualProd.EntryDate = trn.EntryDate          
where trn.EntryDate<'2018-07-01'

/***********************************************************Production************************************************/        
if OBJECT_ID('tempdb..#TmpUsersProduction') is not null drop table #TmpUsersProduction        
Create table #TmpUsersProduction(RptDate date,RptDateHour int,UserId int,RawTrans int,TotalBatches int,BatchesCompleted int
, BatchesHeld int,FactorValue decimal(9,2),ErrorDone int,ErrorDoneAudited int,ErrorFound int,ErrorFoundAudited int,CustomerId int,
BatchServiceId int)        
        

Set @Qry = '        
if OBJECT_ID(''tempdb..#TmpProduction'') is not null drop table #TmpProduction        
if OBJECT_ID(''tempdb..#tmpcustproduction'') is not null drop table #tmpcustproduction      

Create table #TmpProduction(RptDate date,RptDateHour int,UserId int,RawTrans int,TotalBatches int,BatchesCompleted int, BatchesHeld int,FactorValue decimal(10,2),BatchServiceId int)        

select * into  #tmpcustproduction from
(
Select CONVERT(date,batTrans.CreatedDt)RptDate
,datepart(hour,batTrans.CreatedDt) as RptDateHour
,batTrans.CreatedBy UserId      
,bat.batchid  
,TransValue as RawTrans
,TransValue * (Select top 1 EntryPayment from ADM_FactorWaterTown (nolock) as fact Where fact.ServiceGroupId = bat.ServiceId	
	and CONVERT(date,batTrans.CreatedDt) between fact.EffectiveFrom and Cast(isnull(fact.EffectiveTo,getdate()) as DATE)	
	) TransValue,bat.ServiceId        
from ARC_FLOW_ATHENA.dbo.TRN_k'+@CmpKey+'_tBatchTransact (nolock) as batTrans        
inner join ARC_FLOW_ATHENA.dbo.TRN_k'+@CmpKey+'_tBatches  (nolock) as bat on bat.BatchId = batTrans.BatchId and bat.status = 1        
where batTrans.CreatedDt between '''+Convert(varchar,@fromDateTime)+''' and '''+Convert(varchar,@toDatetime)+''' and batTrans.TransValue > 0        
Union all        
Select CONVERT(date,qCom.CreatedDt) as RptDate
,datepart(hour,qCom.CreatedDt) as RptDateHour
,qCom.CreatedBy UserId 
,bat.batchid  
,TransValue as RawTrans
,TransValue * (Select top 1 QcPayment from ADM_FactorWaterTown (nolock) as fact Where fact.ServiceGroupId = bat.ServiceId	
	and CONVERT(date,qCom.CreatedDt) between fact.EffectiveFrom and Cast(isnull(fact.EffectiveTo,getdate()) as DATE)	
	) TransValue
,bat.ServiceId        
from ARC_FLOW_ATHENA.dbo.TRN_k'+@CmpKey+'_tBatchQCComments  (nolock) as qCom        
inner join ARC_FLOW_ATHENA.dbo.TRN_k'+@CmpKey+'_tBatchQCMaster  (nolock) as qcMaster on qcMaster.BatchProcessId = QCom.BatchProcessId and qcMaster.TransValue > 0        
inner join ARC_FLOW_ATHENA.dbo.TRN_k'+@CmpKey+'_tBatches  (nolock) as bat on bat.BatchId = qcom.BatchId and bat.status = 1        
where qCom.CreatedDt between '''+Convert(varchar,@fromDateTime)+''' and '''+Convert(varchar,@toDatetime)+''' 
)a


Insert into #TmpProduction(RptDate,RptDateHour,UserId,RawTrans,FactorValue,BatchServiceId)    
Select RptDate,RptDateHour,UserId,sum(RawTrans) as RawTrans,SUM(TransValue) as TransValue, ServiceId        
from         
(        
 select RptDate,RptDateHour,UserId,RawTrans,TransValue,ServiceId from #tmpcustproduction       
)x Group by RptDate,RptDateHour,UserId,ServiceId

     
update a set a.TotalBatches=b.TotalBatches
from #TmpProduction a join
(
select rptdate,userid,serviceid,count(distinct batchid) as TotalBatches  from #tmpcustproduction
group by RptDate,userid,serviceid
)b
  on a.RptDate=b.RptDate and a.userid=b.userid
and a.BatchServiceId=b.serviceid


update a set a.BatchesCompleted=b.BatchesCompleted
from #TmpProduction a join
(
select a.rptdate,a.userid,a.serviceid,count(distinct a.batchid) as BatchesCompleted  from #tmpcustproduction a
inner join ARC_FLOW_ATHENA.dbo.TRN_k'+@CmpKey+'_tBatches  (nolock) as bat on bat.BatchId=a.batchid
where bat.Uploaddt is not null
group by  a.RptDate,a.userid,a.serviceid
)b
on a.RptDate=b.RptDate and a.userid=b.userid
and a.BatchServiceId=b.serviceid



update a set a.BatchesHeld=b.BatchesHeld
from #TmpProduction a join
(
select a.rptdate,a.userid,a.serviceid,count(distinct a.batchid) as BatchesHeld  from #tmpcustproduction a
inner join ARC_FLOW_ATHENA.dbo.TRN_k'+@CmpKey+'_tHeldBatches  (nolock) as bat on bat.BatchId=a.batchid
where bat.ReleaseDate is null
group by a.RptDate,a.userid,a.serviceid
)b
  on a.RptDate=b.RptDate and a.userid=b.userid
and a.BatchServiceId=b.serviceid


        
if OBJECT_ID(''tempdb..#TmpErrors'') is not null drop table #TmpErrors        
Create table #TmpErrors(RptDate date,RptDateHour int,FteId int,Errors int,QcId int,BatchServiceId int)        
Insert into #TmpErrors(RptDate,RptDateHour,FteId,Errors,QcId,BatchServiceId)        
Select CONVERT(date,qCom.CreatedDt) as RptDate,datepart(hour,qCom.CreatedDt) as RptDateHour
,  qCom.FTE_Id,COUNT(*) as ErrCount,qcom.CreatedBy,bat.ServiceId        
from ARC_FLOW_ATHENA.dbo.TRN_k'+@CmpKey+'_tBatchQCTran  (nolock) as qTran         
inner join ARC_FLOW_ATHENA.dbo.TRN_k'+@CmpKey+'_tBatchQCComments  (nolock) as qCom on qCom.BatchProcessId = qTran.BatchProcessId and CONVERT(date,qCom.CreatedDt) between '''+Convert(varchar,@fromDate)+''' and '''+Convert(varchar,@toDate)+'''        
inner join ARC_FLOW_ATHENA.dbo.TRN_k'+@CmpKey+'_tBatches  (nolock) as bat on bat.BatchId = qcom.BatchId and bat.status = 1        
Group by CONVERT(date,qCom.CreatedDt),datepart(hour,qCom.CreatedDt),qCom.FTE_Id,qcom.CreatedBy,bat.ServiceId         
        
if OBJECT_ID(''tempdb..#TmpAuditedTransaction'') is not null drop table #TmpAuditedTransaction        
Create table #TmpAuditedTransaction(RptDate date,RptDateHour int,FteId int,AuditedTrans int,QcId int,BatchServiceId int)        
Insert into #TmpAuditedTransaction(RptDate,RptDateHour,FteId,AuditedTrans ,QcId,BatchServiceId)        
Select CONVERT(date,qCom.CreatedDt) as RptDate
,datepart(hour,qCom.CreatedDt) as RptDateHour
,qCom.FTE_Id,SUM(qMaster.TransValue) as AuditedTrans,qcom.CreatedBy,bat.ServiceId        
from ARC_FLOW_ATHENA.dbo.TRN_k'+@CmpKey+'_tBatchQCComments  (nolock) qCom         
inner join ARC_FLOW_ATHENA.dbo.TRN_k'+@CmpKey+'_tBatchQCMaster  (nolock) as qMaster on qMaster.BatchProcessId = qCom.BatchProcessId and qMaster.TransValue > 0        
inner join ARC_FLOW_ATHENA.dbo.TRN_k'+@CmpKey+'_tBatches  (nolock) as bat on bat.BatchId = qcom.BatchId and bat.status = 1        
Where qCom.CreatedDt between '''+Convert(varchar,@fromDateTime)+''' and '''+Convert(varchar,@toDatetime)+'''         
Group by CONVERT(date,qCom.CreatedDt),datepart(hour,qCom.CreatedDt) ,qCom.FTE_Id,qcom.CreatedBy,bat.ServiceId    
    
select FTEid userid, rptdate,RptDateHour, BatchServiceId into #tmpUsers from #TmpErrors   
union        
select FTEid, rptdate,RptDateHour, BatchServiceId from #TmpAuditedTransaction        
union        
select UserId, rptdate,RptDateHour, BatchServiceId from #TmpProduction        
        
Insert into #TmpUsersProduction(RptDate,RptDateHour,userId,RawTrans,TotalBatches,BatchesCompleted , BatchesHeld ,FactorValue,ErrorDone,ErrorDoneAudited,ErrorFound,ErrorFoundAudited,CustomerId,BatchServiceId)        
        
Select prod.RptDate,prod.RptDateHour, prod.UserId,prod1.RawTrans,prod1.TotalBatches,prod1.BatchesCompleted,prod1.BatchesHeld,prod1.FactorValue        
,(Select isnull(SUM(Errors),0) from #TmpErrors where FteId = prod.UserId and RptDate = prod.RptDate and 
BatchServiceId = prod.BatchServiceId and RptDateHour=prod.RptDateHour) as ErrorDone        
,(Select isnull(SUM(AuditedTrans),0) from #TmpAuditedTransaction where FteId = prod.UserId  and RptDate = prod.RptDate
 and BatchServiceId = prod.BatchServiceId  and RptDateHour=prod.RptDateHour) as ErrorDoneAudited        
,(Select isnull(SUM(Errors),0) from #TmpErrors where QcId = prod.UserId  and RptDate = prod.RptDate  and 
BatchServiceId = prod.BatchServiceId  and RptDateHour=prod.RptDateHour) as ErrorFound        
,(Select isnull(SUM(AuditedTrans),0) from #TmpAuditedTransaction where QcId = prod.UserId  and RptDate = prod.RptDate 
 and BatchServiceId = prod.BatchServiceId  and RptDateHour=prod.RptDateHour) as ErrorFoundAudited        
,'+Convert(varchar,@CustomerId)+' as CustomerId        
,prod.BatchServiceId        
from #tmpUsers as prod left join #TmpProduction as prod1 on prod.UserId=prod1.UserId and prod1.RptDate = prod.RptDate and 
prod1.BatchServiceId = prod.BatchServiceId     and prod1.RptDateHour=prod.RptDateHour    
        
'      
--print  @Qry 
exec( @Qry)

/* Start here Newly added code for calculate target based on achieved fact production*/
if OBJECT_ID('tempdb..#AssTgt_FactProductionTarget') is not null drop table #AssTgt_FactProductionTarget
Select x.UserId,x.BatchServiceId,x.RptDate,FactorValue, (FactorValue/TotalFactProduction) as FactPrdTarget 
into #AssTgt_FactProductionTarget 
from  #TmpUsersProduction x
inner join 
(
	Select UserId,RptDate,sum(FactorValue) as TotalFactProduction from #TmpUsersProduction where RptDate>='2018-07-01'
	group by  UserId,RptDate

)y on x.UserId=y.UserId and x.RptDate=y.RptDate
where x.RptDate>='2018-07-01'

update trn set trn.PD_Target= CONVERT(decimal(10,2),FactPrdTarget*ActTarget)
from #AssTgt_DateWiseProcessed trn
inner join  #AssTgt_FactProductionTarget prd on prd.UserId=trn.UserId and prd.BatchServiceId=trn.BatchServiceId
 and  prd.RptDate=trn.EntryDate

update trn set trn.PD_Target= 0
--select * 
from #AssTgt_DateWiseProcessed trn
left join  #AssTgt_FactProductionTarget prd on prd.UserId=trn.UserId 
and prd.BatchServiceId=trn.BatchServiceId and  prd.RptDate=trn.EntryDate
inner join (Select distinct userid, RptDate from #AssTgt_FactProductionTarget) p 
on trn.UserId=p.userid and trn.EntryDate=p.RptDate
where prd.userid is null 

/*For non production associates who are all having mutliple services*/
if OBJECT_ID('tempdb..#MultipleServiceNoPrdn') is not null drop table #MultipleServiceNoPrdn
select trn.UserId, trn.EntryDate, count(trn.BatchServiceId) as TotalServices into #MultipleServiceNoPrdn
from #AssTgt_DateWiseProcessed trn
left join  #AssTgt_FactProductionTarget prd on prd.UserId=trn.UserId 
--and prd.BatchServiceId=trn.BatchServiceId 
and  prd.RptDate=trn.EntryDate
where prd.UserId is null and trn.EntryDate>='2018-07-01'
group by trn.UserId, trn.EntryDate having count(trn.BatchServiceId)>1 


update trn set trn.PD_Target= CONVERT(decimal(10,2),PD_Target/TotalServices)
from #AssTgt_DateWiseProcessed trn
inner join  #MultipleServiceNoPrdn prd on prd.UserId=trn.UserId and  prd.EntryDate=trn.EntryDate

/* Start here Newly added code for calculate target based on achieved fact production*/   

Set @qry = '         
Insert into #ProdRptAssociateTarget(UserId,DayTarget,ActDayTarget,CustomerId,RptDate,BatchServiceId)          
Select UserId          
,Convert(decimal(10,2),Sum(case when IsWorkingDay = 1 then PD_Target else 0 end)) as DayTarget          
,Convert(decimal(10,2),Sum(case when IsWorkingDay = 1 then ActTarget else 0 end)) as ActDayTarget          
,15,aTgt.EntryDate,BatchServiceId          
from #AssTgt_DateWiseProcessed as aTgt          
Group by aTgt.UserId,aTgt.EntryDate,BatchServiceId          
'          
Exec (@qry)     


delete from #tblfinalproduction where customerid=@CustomerId and rptDate=@ProcessDate

insert into #tblfinalproduction(rptdate,RptDateHour,CustomerId,BatchServiceId,Userid,RawTrans,TotalBatches
,BatchesCompleted , BatchesHeld 
,FactorValue,Target,ErrorFound,ErrorFoundAudited,ErrorDone,ErrorDoneAudited)
select distinct rptdate,RptDateHour,CustomerId,BatchServiceId,Userid,RawTrans,TotalBatches,BatchesCompleted , BatchesHeld 
,FactorValue,Target,ErrorFound,ErrorFoundAudited,ErrorDone,ErrorDoneAudited from
(      
Select distinct prod.RptDate,prod.RptDateHour,Tgt.CustomerId 
,prod.BatchServiceId    ,prod.UserId     
,prod.RawTrans   
,prod.TotalBatches
,prod.BatchesCompleted 
,prod.BatchesHeld 
,prod.FactorValue
,Tgt.DayTarget
,Round(ISNULL(Tgt.DayTarget,0),0) as Target        
,Convert(Decimal(9,2),case when ROUND(isnull(tgt.DayTarget,0),0) = 0 then prod.FactorValue 
else (prod.FactorValue / ROUND(tgt.DayTarget,0))*100 end) as ProdAcheived        
,prod.ErrorFound,prod.ErrorFoundAudited,prod.ErrorDone,prod.ErrorDoneAudited        
from #TmpUsersProduction  as prod        
inner join #ProdRptAssociateTarget as Tgt on Tgt.UserId = prod.UserId and Tgt.CustomerId = prod.CustomerId 
and Tgt.RptDate = prod.RptDate and tgt.BatchServiceId = prod.BatchServiceId        
inner join ARC_FLOW_ATHENA..adm_customer as cus on cus.CustomerId = prod.CustomerId        
 ) a      

if OBJECT_ID('tempdb..#TmpUsersProduction') is not null drop table #TmpUsersProduction        
if OBJECT_ID('tempdb..#ProdRptAssociateTarget') is not null drop table #ProdRptAssociateTarget        
if OBJECT_ID('tempdb..#AssTgt_DateWiseProcessed') is not null drop table #AssTgt_DateWiseProcessed        
if OBJECT_ID('tempdb..#AssTgt_AssociateTargetDetails') is not null drop table #AssTgt_AssociateTargetDetails        
if OBJECT_ID('tempdb..#AssTgt_TotalProductionHour') is not null drop table #AssTgt_TotalProductionHour        


--if OBJECT_ID('tempdb..#DBD_TV_CUSTOMER_SHIFTTIME') is not null drop table #DBD_TV_CUSTOMER_SHIFTTIME
--if OBJECT_ID('tempdb..#DBD_TV_CUSTOTMER_HOURLYPRODUCTION') is not null drop table #DBD_TV_CUSTOTMER_HOURLYPRODUCTION
--if OBJECT_ID('tempdb..#DBD_TV_USER_HOURLYPRODUCTION') is not null drop table #DBD_TV_USER_HOURLYPRODUCTION
--if OBJECT_ID('tempdb..#DBD_TV_CUSTOTMER_DAYWISEPRODUCTION') is not null drop table #DBD_TV_CUSTOTMER_DAYWISEPRODUCTION


--CREATE TABLE #DBD_TV_CUSTOTMER_DAYWISEPRODUCTION(
--	[rowid] [int] IDENTITY(1,1) NOT NULL,
--	[customerid] [int] NULL,	[lobid] [int] NULL,
--	[batchserviceid] [int] NULL,	[processdate] [date] NULL,
--	[TotalAduited] [int] NULL,	[TotalError] [int] NULL,
--	[TotalQualityPercentage] [decimal](18, 2) NULL,	[TotalProductionTarget] [int] NULL,
--	[TotalProduction] [decimal](18, 2) NULL,	[ProductionPercentage] [decimal](18, 2) NULL,
--	[status] [int] NULL,	[createdby] [int] NULL,	[createddt] [date] NULL,
--	[FunctionalityId] [int] NULL,	[TotalBatches] [int] NULL,	[BatchesCompleted] [int] NULL,	[BatchesHeld] [int] NULL
--) ON [PRIMARY]


--CREATE TABLE #DBD_TV_CUSTOTMER_HOURLYPRODUCTION(
--	[rowid] [int] IDENTITY(1,1) NOT NULL,
--		[customerid] [int] NULL,	[lobid] [int] NULL,	[batchserviceid] [int] NULL,
--	[productionhour] [datetime] NULL,	[productiontarget] [decimal](18, 2) NULL,
--	[productionachieved] [decimal](18, 2) NULL,	[productionpercentage] [decimal](18, 2) NULL,
--	[totalproductionusers] [int] NULL,	[status] [int] NULL,	[createdby] [int] NULL,
--	[createddt] [date] NULL,	[TotalBatches] [int] NULL,	[RawTrans] [int] NULL,
--	[ErrorDone] [int] NULL,	[ErrorDoneAudited] [int] NULL,	[QAAchieved] [decimal](9, 2) NULL,
--	[FunctionalityId] [int] NULL,	[BatchesCompleted] [int] NULL,	[BatchesHeld] [int] NULL
--) ON [PRIMARY]



--CREATE TABLE #DBD_TV_USER_HOURLYPRODUCTION(
--	[rowid] [int] IDENTITY(1,1) NOT NULL,	[userid] [int] NULL,
--	[associateName] [varchar](100) NULL,	[customerid] [int] NULL,
--	[clientid] [int] NULL,	[lobid] [int] NULL,
--	[batchserviceid] [int] NULL,	[productionhour] [datetime] NULL,
--	[productiontarget] [decimal](18, 2) NULL,	[productionachieved] [decimal](18, 2) NULL,
--	[productionpercentage] [decimal](18, 2) NULL,	[totalproductionusers] [int] NULL,
--	[totaltarget] [int] NULL,	[slot] [int] NULL,	[shiftTime] [time](7) NULL,
--	[status] [int] NULL,	[createdby] [int] NULL,	[createddt] [date] NULL,
--	[updatedby] [int] NULL,	[updateddt] [date] NULL,	[TotalBatches] [int] NULL
--	,	[RawTrans] [int] NULL,	[ErrorDone] [int] NULL,	[ErrorDoneAudited] [int] NULL,
--	[QAAchieved] [decimal](9, 2) NULL,	[FunctionalityId] [int] NULL,	[BatchesCompleted] [int] NULL,
--	[BatchesHeld] [int] NULL) ON [PRIMARY]

	delete from DBD_TV_CUSTOTMER_HOURLYPRODUCTION 
	delete from DBD_TV_USER_HOURLYPRODUCTION
	delete from DBD_TV_CUSTOTMER_DAYWISEPRODUCTION where processdate=convert(date,GETDATE())

	
	if OBJECT_ID('tempdb..#tblproduction') is not null drop table #tblproduction    
    select distinct *  into #tblproduction from #tblfinalproduction order by Userid,RptDateHour
    
     
   	INSERT INTO DBD_TV_CUSTOTMER_HOURLYPRODUCTION(ProductionHour,CustomerId,FunctionalityId, lobid)    
	SELECT distinct TT.Dates,p.customerid,ui.FUNCTIONALITY_ID, ui.lob FROM #tempTime TT,#tblproduction   P
	join arC_reC_athena..arc_reC_user_info u on p.userid=u.userid
	join arc_rec..arc_reC_user_info ui on ui.nt_username=u.nt_username
	 WHERE ui.ACTIVE=1 
		       
    INSERT INTO DBD_TV_CUSTOTMER_DAYWISEPRODUCTION(ProcessDate,CustomerId,FunctionalityId,lobid)    
    SELECT distinct getdate(),p.customerid,ui.FUNCTIONALITY_ID, ui.LOB 
	FROM #tblproduction   P 
	join arC_reC_athena..arc_reC_user_info u on p.userid=u.userid
	join arc_rec..arc_reC_user_info ui on ui.nt_username=u.nt_username
	 WHERE ui.ACTIVE=1 
	
	
   	IF OBJECT_ID('tempdb..#tblUserDetails') is not null Drop table #tblUserDetails 
   	
    SELECT X.USERID,Z.SHIFT_NAME,Y.NT_USERNAME,Z.SHIFT_FROM,Z.SHIFT_TO,Y.CustomerId,Y.FunctionalityId, Y.LOB,
    Y.BatchServiceID,Y.RptDateHour  into #tblUserDetails  FROM 
    (select MAX(TID) TID ,userid from arc_rec_athena..arc_rec_shift_tran group by USERID) s
    join  arc_rec_athena..arc_rec_shift_tran X    on X.TID=s.TID  and X.USERID=s.USERID
    INNER JOIN arc_rec_athena..arc_rec_shift_info Z on X.SHIFT_ID=Z.SHIFT_ID     
    INNER JOIN(        
    SELECT u.USERID,u.NT_USERNAME,ui.FUNCTIONALITY_ID  as FunctionalityId, ui.LOB,pm.CustomerId,PM.BatchServiceID
    ,PM.RptDateHour from 
    --arc_rec_athena..ARC_REC_UserCustomer uc    inner join 
    #tblproduction pm 
    --on pm.CustomerId=uc.CustomerID      and pm.userid=uc.userid
    join arC_reC_athena..arc_reC_user_info u on pm.userid=u.userid
	join arc_rec..arc_reC_user_info ui on ui.nt_username=u.nt_username
	 WHERE  u.USERID=pm.UserId and  ui.ACTIVE=1	 
    GROUP BY u.USERID,u.NT_USERNAME,pm.CustomerId ,ui.FUNCTIONALITY_ID, ui.LOB, PM.BatchServiceID,PM.RptDateHour
    ) Y ON  X.USERID=Y.USERID
    
    /*
    select * from #tblproduction where userid=417
    select * from #tblUserDetails where userid=417 order by rptdatehour
	*/
    
    
   	IF OBJECT_ID('tempdb..#mainTemp') is not null Drop table #mainTemp   
	CREATE TABLE #mainTemp(Dates datetime,UserId int,SHIFT_NAME VARCHAR(100),NT_USERNAME varchar(100)
	,CustomerId INT,FunctionalityId int, LOBID INT,BatchServiceID INT,RptDateHour int,
	shiftfrom INT, shiftto INT)   
		
		
	/* get associate daily target details -start */
    /* INSERT INTO #mainTemp(Dates,UserId,SHIFT_NAME,NT_USERNAME,SHIFT_FROM,SHIFT_TO,CustomerId,LOBID,BatchServiceID,RptDateHour) */
   
   INSERT INTO #mainTemp(Dates,UserId,SHIFT_NAME,shiftfrom,shiftto,NT_USERNAME,CustomerId,FunctionalityId,LOBID,BatchServiceID,RptDateHour)
   SELECT DISTINCT  x.Dates , y.userid,y.SHIFT_NAME
   ,DATEPART(HOUR, y.SHIFT_FROM),DATEPART(HOUR, y.SHIFT_To),
   y. NT_USERNAME,y.customerid,y.FunctionalityId,y.lob,y.BatchServiceID
   ,DATEPART(HOUR, x.dates) rptdatehour
   FROM #tempTime x , #tblUserDetails y  
    /*on  DATEPART(HOUR, x.dates)=y.rptdatehour  
   where y.USERID>0  */   
    order by userid,dates
    
    /*select * from #mainTemp where UserId=417 order by BatchServiceID,RptDateHour*/

   IF OBJECT_ID('tempdb..#tblusertarget') is not null Drop table #tblusertarget   
	
    SELECT DISTINCT x.Dates,x.UserId,x.NT_USERNAME
    ,(case when DATEPART(HOUR,x.Dates)<x.shiftfrom then 0 when DATEPART(HOUR,x.Dates) >x.shiftto then 0 else isnull((sm.[Target]*1.0/9),0) end) [Target]
    ,convert(decimal(9,2),0) as factorvalue 
    ,x.CustomerId,X.FunctionalityId,X.LOBID, x.BatchServiceID
    ,(case when DATEPART(HOUR,x.Dates)<x.shiftfrom then 0 when DATEPART(HOUR,x.Dates) >x.shiftto then 0 else isnull(sm.[target],0) end) 
     as TotalTarget   
    ,(case when DATEPART(HOUR,x.Dates)<x.shiftfrom then 0 when DATEPART(HOUR,x.Dates) >x.shiftto then 0 else isnull(sm.totalbatches,0) end) as TotalBatches
   ,(case when DATEPART(HOUR,x.Dates)<x.shiftfrom then 0 when DATEPART(HOUR,x.Dates) >x.shiftto then 0 else isnull(sm.batchescompleted,0) end) as BatchesCompleted
    ,(case when DATEPART(HOUR,x.Dates)<x.shiftfrom then 0 when DATEPART(HOUR,x.Dates) >x.shiftto then 0 else isnull(sm.batchesheld,0) end) as BatchesHeld
   
   ,convert(decimal(9,2),0) as Rawtrans 
   ,convert(decimal(9,2),0) as ErrorDone
   ,convert(decimal(9,2),0) as ErrorDoneAudited 
     into #tblusertarget
     from #mainTemp x    
     left join #tblproduction sm  
    on x.CustomerId=sm.CustomerId    and sm.userid=x.UserId   
    AND   sm.BatchServiceID=x.BatchServiceID
  /*and  x.RptDateHour=sm.RptDateHour */
    
   /*select * from #tblusertarget where UserId=417 order by BatchServiceID*/

 	
    update  a set
    a.factorvalue=isnull(b.factorvalue,0)
    ,a.Rawtrans=b.Rawtrans
    ,a.ErrorDone=b.ErrorDone
    ,a.ErrorDoneAudited=b.ErrorDoneAudited
     from #tblusertarget a
    join
    (select SM.rptdatehour,x.LOBID,x.FunctionalityId, x.UserId,x.customerid,x.batchserviceid,factorvalue,
    sm.TotalBatches
    ,sm.BatchesCompleted
    ,sm.BatchesHeld
     ,isnull(sm.Rawtrans,0)Rawtrans,isnull(sm.ErrorDone,0)ErrorDone,isnull(sm.ErrorDoneAudited,0) ErrorDoneAudited
  from  	 #mainTemp x    
      join #tblproduction sm  
    on x.CustomerId=sm.CustomerId    and sm.userid=x.UserId   
    AND   sm.BatchServiceID=x.BatchServiceID     
     ) b on a.CustomerId=b.customerid and a.FunctionalityId=b.FunctionalityId and
      isnull(A.lobid,0)=isnull(B.lobid,0) and a.batchserviceid=b.batchserviceid
     and a.userid=b.userid and datepart(hour,a.dates)=b.rptdatehour
    	
	/* here Totaltarget, TotalTarget  is for the customer,lob,batchserviceid not based on the report hour */
	 
    INSERT INTO DBD_TV_USER_HOURLYPRODUCTION(ProductionHour,UserId,AssociateName
    ,ProductionTarget,productionachieved,CustomerId,FunctionalityId,LOBID,BatchServiceID,TotalTarget,TotalBatches,BatchesCompleted , BatchesHeld ,Rawtrans
    ,ErrorDone,ErrorDoneAudited)   
      select  Dates,UserId,NT_USERNAME,Target,factorvalue,CustomerId,FunctionalityId,LOBID,BatchServiceID,Totaltarget,TotalBatches,BatchesCompleted , BatchesHeld ,
    Rawtrans,ErrorDone,ErrorDoneAudited from  #tblusertarget 
         
    /* Update Total Production and Quality Details For the Customer And LOB */
    
    
    UPDATE A SET ProductionTarget=B.ProductionTarget,productionachieved=b.productionachieved,
    productionpercentage= case when b.ProductionTarget=0 then b.productionachieved else
    (((b.productionachieved*1.0)/b.ProductionTarget)*100.00) end
    ,totalproductionusers=B.Usercount 
    ,ErrorDone=B.ErrorDone
    ,ErrorDoneAudited=B.ErrorDoneAudited
    ,RawTrans=B.RawTrans
        FROM DBD_TV_CUSTOTMER_HOURLYPRODUCTION A    
    INNER JOIN (    
    select  A.CustomerId,A.FunctionalityId, A.LOBID, count(distinct A.userid) as Usercount,SUM(b.ProductionTarget )ProductionTarget
    ,SUM(b.productionachieved )productionachieved
    ,SUM(b.RawTrans) as RawTrans
    ,SUM(b.ErrorDone) as ErrorDone
    ,SUM(b.ErrorDoneAudited) as ErrorDoneAudited
    ,A.ProductionHour
    from DBD_TV_USER_HOURLYPRODUCTION A    
    inner join DBD_TV_USER_HOURLYPRODUCTION B on B.UserId  =A.UserId     
    where A.CustomerId=b.customerid   and A.FunctionalityId=b.FunctionalityId   AND A.lobid=B.lobid
    --AND a.ProductionHour >=B.ProductionHour  
    AND a.ProductionHour =B.ProductionHour     
    GROUP BY A.CustomerId,A.FunctionalityId, A.lobid,A.ProductionHour) B ON a.customerid=B.CustomerId   
    And A.FunctionalityId=B.FunctionalityId AND isnull(A.lobid,0)=isnull(B.lobid,0)
    WHERE A.ProductionHour=B.ProductionHour    
     
     
    /* Update Total Batches For the Customer And LOB */
	update a set a.TotalBatches=b.TotalBatches,a.BatchesCompleted=b.BatchesCompleted,a.BatchesHeld=b.BatchesHeld
	from DBD_TV_CUSTOTMER_HOURLYPRODUCTION a join
	(
	select customerid ,FunctionalityId,lobid,SUM(totalbatches)totalbatches ,SUM(batchescompleted)batchescompleted 
	,SUM(batchesheld)batchesheld from (
	select distinct customerid,FunctionalityId,lobid, userid,batchserviceid,max(isnull(totalbatches,0)) as totalbatches  
	,max(isnull(batchescompleted,0)) as batchescompleted  
	,max(isnull(batchesheld,0)) as batchesheld  
	from DBD_TV_USER_HOURLYPRODUCTION
	group by  customerid,FunctionalityId,lobid,userid,batchserviceid
	)x  group by  customerid,FunctionalityId,lobid
	)b    on a.customerid=b.customerid

    SET ROWCOUNT 0    
           
            
    UPDATE  DP  SET
    TotalProductionTarget=HP.TotalProductionTarget
    ,TotalProduction=HP.TotalProduction
    ,ProductionPercentage=HP.ProductionPercentage
    ,TotalAduited=HP.TotalAudited
    ,TotalError=HP.TotalError
    ,TotalQualityPercentage=HP.TotalQualityPercentage  
     ,TotalBatches=HP.TotalBatches
     ,BatchesCompleted=HP.BatchesCompleted
     ,BatchesHeld=HP.BatchesHeld from
    (select  customerid,FunctionalityId,LOBID,
     sum(HP.ProductionTarget)TotalProductionTarget
    ,SUM(HP.productionachieved )TotalProduction,
    case when sum(HP.ProductionTarget)=0 then
    SUM(HP.productionachieved) else (((SUM(HP.productionachieved)*1.0)/nullif(sum(HP.ProductionTarget),0))*100.1) end
    ProductionPercentage,
     sum(HP.ErrorDone)TotalError
    ,SUM(HP.ErrorDoneAudited)TotalAudited
   ,dbo.fnQualityCalculation(0,0,sum(HP.ErrorDone),SUM(HP.ErrorDoneAudited ),1,0.5) as TotalQualityPercentage   
    ,SUM(HP.TotalBatches)TotalBatches
    ,SUM(HP.BatchesCompleted)BatchesCompleted
    ,SUM(HP.BatchesHeld) BatchesHeld, convert(date, ProductionHour) as ProcessDate  
    from DBD_TV_CUSTOTMER_HOURLYPRODUCTION HP
    group by customerid,FunctionalityId,LOBID, convert(date, ProductionHour) )HP join 
   DBD_TV_CUSTOTMER_DAYWISEPRODUCTION  DP on  DP.customerid=HP.customerid And DP.FunctionalityId=HP.FunctionalityId
    AND isnull(DP.lobid,0)=isnull(HP.LOBID,0) and DP.ProcessDate=HP.ProcessDate
   

         
DELETE FROM DBD_TV_USER_HOURLYPRODUCTION WHERE RowId IN(  
SELECT MIN(RowId) from DBD_TV_USER_HOURLYPRODUCTION  
group by ProductionHour,UserId,CustomerId,FunctionalityId,lobid,batchserviceid  
having COUNT('a')>1)  

--select *  from DBD_TV_CUSTOTMER_HOURLYPRODUCTION  where productionhour<=GETDATE() order by productionhour,productiontarget
--select *  from DBD_TV_USER_HOURLYPRODUCTION where productionhour<=GETDATE()
--select * from DBD_TV_CUSTOTMER_DAYWISEPRODUCTION where processdate=convert(date,GETDATE()) 	

end


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[DBD_TV_GENERATE_HOURLY_PRODUCTIONANDQUALITY_JOB] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[DBD_TV_GENERATE_HOURLY_PRODUCTIONANDQUALITY_JOB] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[DBD_TV_GENERATE_HOURLY_PRODUCTIONANDQUALITY_JOB] TO [DB_DMLSupport]
    AS [dbo];

