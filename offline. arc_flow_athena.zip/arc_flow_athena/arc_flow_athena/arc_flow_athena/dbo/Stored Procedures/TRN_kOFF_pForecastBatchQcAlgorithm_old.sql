﻿CREATE Procedure TRN_kOFF_pForecastBatchQcAlgorithm_old(@BatchId int,@CreatedBy int,@BatchProcessId int)  
As  
Begin 
	/***************************************************************************************************
	Created Date         :   2016-07-26 
	Created By           :   mallikarjun.nam
	Description          :   For Random Qc alogothim
	SCR/Ticket#          :   155811
	****************************************************************************************************
	SUMMARY OF CHANGES
	Modified Date        Modified By          SCR/Ticket#   Comments
	------------------- -------------------  -----------   ------------------------------------------------------------
	2017-06-23         Mallikarjun.Nam       214304	 
	2019-05-15         mallikarjun.nam       390414	 For restrcting to run for the particular user
	***************************************************************************************************/
	
	/*
	Declare @BatchId int=4827391,@CreatedBy int=5505,@BatchProcessId int=4827896
	*/
     Set transaction isolation level read uncommitted
     /*Service buckets are excluded from the random qc algorithim */
     
     /*For testing job in live disable this option for single user tempararly*/
     Declare @UserId int=0
     Set @UserId=(Select UserId from arc_rec_athena..arc_rec_user_info where nt_username ='selvakumar.p1')
     
     if(@CreatedBy=@UserId)
        return;
     else if(select count(batchid) from TRN_kOFF_tBatches bat where BatchId=@BatchId 
     and exists (Select 1 from ADM_DirectUploadExceptional excp where excp.ServiceId =bat.ServiceId and excp.Status=1))>0
     return
     else if(select count(CtlValue) from ADM_SoftControl where CtlValue='Y' and CtlID='ForecastQCAlgorithm')>0
	 Begin	 
	 
	 
	 
		Declare @ProcessCount int,@DirUpload int = 0,@NewUser int=0,@isMergeBatch int=0
		,@IsbatchAudited int,@CurrentTime int,@ShiftMaxTime int,@RandomNo int=0,@ShiftId int

		,@UserTodayEntryCompletedBatchCount int=0,@UserTodayEntryCompletedBatchTransCount int=0
		,@BatchTransCount int=0,@IsUserInDayShift int=0,@NT_UserName Varchar(100)
		,@QcDate date,@DayStartTime datetime ,@DayEndTime datetime ,@MaxQcUserTransCount int=0
        
        Set @MaxQcUserTransCount=isnull((select CtlValue from ADM_SoftControl where CtlID='UMTRANS'),100)
        
		Set @CurrentTime= Datepart(hh,getdate())
		if(@CurrentTime<8)
		   Set @QcDate = cast((dateadd(dd,-1,getdate())) as date)
		else   
		   Set @QcDate = cast(getdate() as date)  


		set @DayStartTime=  Convert(varchar,Convert(Date,@QcDate)) + ' 08:00'
		set @DayEndTime= Convert(varchar,Convert(Date,DATEADD(DD,1, @QcDate))) + ' 07:59'

		/*Check if current batch is merge batch or not  */
		select @isMergeBatch=count(bat.BatchId) from TRN_kOFF_tBatches bat 
		where bat.BatchId=@BatchId and Left(BatchNo,1) in ('M','S') and bat.status in(1,99)

		/*Check user processed batch is audited or not for the day  */					
		select @IsbatchAudited=count(distinct qcM.BatchId) from TRN_kOFF_tRandomAuditBatches qcM
		inner join TRN_kOFF_tBatches bat on qcM.BatchId=bat.BatchId and bat.status in(1,99)
		and Left(BatchNo,1) in ('M','S')
		where FTE_Id=@CreatedBy and cast(qcM.QCDate as date)=@QcDate
		and not exists (select 1 from TRN_kOFF_tDirectUpload where BatchId=bat.BatchId and status=1)

		select @NT_UserName=Nt_UserName from ARC_REC_ATHENA..ARC_REC_USER_INFO where UserId=@CreatedBy

		Set @ShiftId= isnull((select top 1 ShiftId from AMD_UserShift where Nt_UserName=@NT_UserName and  Effect_DATE<= @QcDate order by TID desc),1)

		if(@ShiftId=1)
			set @ShiftMaxTime =(select CtlValue from ADM_SoftControl where CtlID='GSMTIME')
		else
		
			set @ShiftMaxTime =(select CtlValue from ADM_SoftControl where CtlID='NSMTIME')


		Set @RandomNo=(Select top 1 BatchRandomNo from TRN_kOFF_tRandomAuditBatches where QCDate=@QcDate and FTE_ID=@CreatedBy)
		if(isnull(@RandomNo,0)=0)
		   Set @RandomNo =(select ABS(Checksum(NewID()) % 3)+1)

		/*Get User Entry Completed batch count for the day */
		select @UserTodayEntryCompletedBatchCount=count(distinct flow.batchid) from TRN_kOFF_tBatchFlow flow
		inner join TRN_kOFF_tBatches bat on flow.BatchId=bat.BatchId and Left(BatchNo,1) in ('M','S') and bat.status in(1,99) 
		where flow.CreatedBy=@CreatedBy and flow.StatusId=6 
		and flow.CreatedDt between @DayStartTime and @DayEndTime
		

		select @BatchTransCount=isnull(sum(trn.TransValue),0) from TRN_kOFF_tBatchTransact trn 
		inner join TRN_kOFF_tBatches bat on trn.BatchId=bat.BatchId and bat.status in(1,99)
		where trn.BatchId=@BatchId and trn.BatchProcessId=@BatchProcessId


		/*Get User Entry Completed batch trans count for the day */
		select @UserTodayEntryCompletedBatchTransCount=isnull(sum(TransCount),0) from TRN_kOFF_tRandomAuditBatches qc 
		inner join TRN_kOFF_tBatches bat on qc.BatchId=bat.BatchId and bat.status in(1,99) and TransCount>0
		where qc.FTE_Id=@CreatedBy and cast(qc.QCDate as date)=@QcDate
			
		/* These users entry completed batches must go to audit     For SCR#841*/
		 Select @NewUser = (Select COUNT(*) 
		 from TRN_kOFF_tBatchFlow as flow
		 inner join ADM_QCAuditSkipUsers as NewUsers on NewUsers.UserId = flow.CreatedBy and NewUsers.Status = 1
		 Where BatchId = @BatchId and StatusId = 6)
		      
		 if (@NewUser > 0)
			 update TRN_kOFF_tDirectUpload set status=0,UpdatedBy=1777,UpdatedDt=getdate(),Comments='Release from Direct upload by system' where BatchId = @BatchId and Status = 1
		 else 
		    if(@isMergeBatch>0) /* If current batch is merge batch then validate already batch audited for this user entry processed batches*/ 
				Begin
					if(@IsbatchAudited=0)
						if(@ShiftMaxTime<=DATEPART(hh,getdate()))
							EXEC TRN_kOFF_pUpdateRandomAuditBatches @BatchId,@BatchProcessId,@CreatedBy,0,@RandomNo,@QcDate
						else if(@UserTodayEntryCompletedBatchCount=@RandomNo)
							EXEC TRN_kOFF_pUpdateRandomAuditBatches @BatchId,@BatchProcessId,@CreatedBy,0,@RandomNo,@QcDate
						else /*If Random number not matching move to DU*/
							EXEC TRN_kOFF_pBatchMoveToDirectUpload @BatchId,@BatchProcessId,@CreatedBy,'RandomNo not matched,Direct upload by system',@RandomNo,@QcDate
					else
					 EXEC TRN_kOFF_pBatchMoveToDirectUpload @BatchId,@BatchProcessId,@CreatedBy,'Already This user procesed batch is Audited,Direct upload by system',@RandomNo,@QcDate
				End
				Else if(@ShiftMaxTime<=DATEPART(hh,getdate()))/*If shif end time is closed then move to qc bucket*/
				   EXEC TRN_kOFF_pUpdateRandomAuditBatches @BatchId,@BatchProcessId,@CreatedBy,@BatchTransCount,@RandomNo,@QcDate
				else if(@MaxQcUserTransCount>=@UserTodayEntryCompletedBatchTransCount)
				   EXEC TRN_kOFF_pUpdateRandomAuditBatches @BatchId,@BatchProcessId,@CreatedBy,@BatchTransCount,@RandomNo,@QcDate
				else
				  EXEC TRN_kOFF_pBatchMoveToDirectUpload @BatchId,@BatchProcessId,@CreatedBy,'Entry Trans count reached max trans count for the day, Direct upload by the system',@RandomNo,@QcDate
  End
  Else return
End



GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pForecastBatchQcAlgorithm_old] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pForecastBatchQcAlgorithm_old] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pForecastBatchQcAlgorithm_old] TO [DB_DMLSupport]
    AS [dbo];

