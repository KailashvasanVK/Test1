﻿
CREATE Proc Athena_CheckAvailMergebatch  @Actions varchar(20),@scandate varchar(10)=null ,@Minpagecount varchar(5)=null,@Maxpagecount int,@serviceid varchar(10)=null                              
 as          
      
/*            
        
Cretaed By     : Leela.T        
Created Date   : 2016-06-01          
Purpose        : Check Available Batches for Merge        
Ticket/SCR ID  : <>        
TL Verified By : <Ramki>      
    
Modified by    :Leela.T    
Modified on    :2016-06-02      
Modified ID    :001    
Purpose        : Create Temp Table    
    
Modified by    :Leela.T    
Modified on    :2016-06-09     
Modified ID    :002    
Purpose        : add the EnterPrise Merge   
     
     
Implemented by : Hemanath.a      
Implemented On : 2016-06-09      
        
Reviewd by     :        
Implemented On :       
        
*/         
begin          
Declare @qury nvarchar(Max)                   
      
if(object_id('tempdb.dbo.#BatchCountDetails')is not null)      
drop table #BatchCountDetails                      
create table #BatchCountDetails                                                        
(                                                                                                                                                                                                      
BatchCount    int ,          
pgcount int                                                                                                                                                                                                                                                    
  
)                       
            
    
set @qury='insert into #BatchCountDetails                      
select count(a.batchno),Sum(pgcount) from trn_koff_tbatches(nolock) a inner join ARC_Athena..batchMaster(nolock) b on a.BatchNo=b.batchnum                         
Inner join TRN_kOFF_tBatchQueue(nolock) bq on a.batchno=bq.batchno
left join trn_koff_theldbatches (nolock) hld on a.batchid=hld.batchid  
where bq.BatchNo not in (select ChildBatchNo from mergebatchdetails(nolock)) and (hld.Batchid is null or hld.ReleaseDate is not null)                        
and status=1 and  bq.assigned=0 and bq.statusid=0 and a.postedDt is null and a.UploadDt is  null  and b.ULStatus is null and '                   
set @qury+=' PgCount <= cast('''+@Minpagecount+'''as int)'                         
    
if @Actions='EDS Merge'                                  
set @qury+=  ' and a.ClientID in  (select clientid  from arc_athena..SubClient_Info  where status=1)'             
if @Actions='SubclientMerge'          
set @qury+=  ' and a.ClientID not in (select Clientid from ExcludeFormerge) '        
    
if @scandate <>''                                        
Set @qury += ' and convert(varchar,scandate,101) = '''+@scandate+''''                       
    
if @serviceid <>''                                        
Set @qury += ' and a.serviceid = cast('''+@serviceid+'''as int)'                          
    
                      
exec (@qury)             
    
select * from #BatchCountDetails           
drop table  #BatchCountDetails          
    
end  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_CheckAvailMergebatch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_CheckAvailMergebatch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_CheckAvailMergebatch] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_CheckAvailMergebatch] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_CheckAvailMergebatch] TO [DB_DMLSupport]
    AS [dbo];

