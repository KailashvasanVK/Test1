﻿CREATE proc SemiAutoMerge_pCheckAvailService (@MergeType varchar(20),@Scandate varchar(10),@pgcount varchar(5))                
as                 
begin      

/*                          
                      
Created By     : Leela.T                      
Created Date   : 09-May-2018                    
Purpose        : Check the Service wise Available Batches for Merge                      
Ticket/SCR ID  : <>  293008                    
TL Verified By : <>                    
   
Modified By     : Leela.T                      
Modified Date   : 24-Sep-2019                    
Purpose         : Added Invoice table Conditions in echoOCR Batches  
               
Implemented by : Karmegan.c                   
Implemented On :  10-05-2018                
*/                
Declare @StrCmd varchar(max) 
      
if(object_id('tempdb.dbo.#BatchCountDetails')is not null)                                                                      
drop table #BatchCountDetails                                                            
create table #BatchCountDetails                                                                                  
( 
 SelectService varchar(20)                                                   
,ServiceName   Varchar(100)                                                                                                                    
,LastMergeddt   Datetime                                                                                      
,BatchCount int                                                  
,Pagecount int        
,Status Varchar(20)                                                                                                      
)             
            
if(object_id('tempdb.dbo.#EDSClient')is not null)                                                   
drop table #EDSClient                                                                               
create table #EDSClient                                                       
(Subclient   varchar(10))             
            
 if (@MergeType='EDS Merge')                                       
begin                                       
insert into  #EDSClient                                                    
select distinct SubClient from ARC_ATHENA..SubClient_Info sub where sub.status=1                                               
End                    
 --+ '''Selectservice'''+' , ''Pending''  as Process          
Set @StrCmd='Insert into #BatchCountDetails ' 
Set @StrCmd+= 'Select ' + '''Selectservice'''+',ServiceName  ,LastMergeddt,Count(BatchCount) BatchCount,  Sum(PageCount) PageCount, ''Pending''  as Process  From ('             
Set @StrCmd+='select distinct Replace(ServiceName,''' + @MergeType + ''' + ''-'','''') as ServiceName ,sch.LastMergeddt LastMergeddt, tbat.batchno BatchCount,pgcount as PageCount
from trn_koff_tbatches(nolock) tbat                              
inner join ARC_Athena..batchMaster(nolock) bm on tbat.BatchNo=bm.batchnum                                                                   
inner join TRN_kOFF_tBatchQueue(nolock) bq on tbat.batchno=bq.batchno                                           
inner join ADM_Client(nolock) adm on adm.ClientId=tbat.ClientId and adm.CustomerId=25 and adm.status=1
left join arc_athena..Invoice_tAutomationBatchQueue(Nolock) tAbq on  tAbq.BatchNo=bm.batchnum  and tAbq.StatusId=2 
left join arc_athena..Entry_InvoiceAutomation(Nolock) inv on  inv.BatchNo=bm.batchnum                       
inner join Merge_tStatusofMerged(nolock) sch on sch.childserviceid=tbat.serviceid and sch.Mergestatus =0'             
Set @StrCmd=@StrCmd +'and sch.servicename like  ''%' + @MergeType+'%'''            
Set @StrCmd=@StrCmd + ' left join mergebatchdetails (nolock) mrg on mrg.childbatchno=tbat.batchno                         
left join trn_koff_theldbatches (nolock) hld on tbat.batchid=hld.batchid  '             
if(@MergeType<>'SubclientMerge')          
begin            
Set @StrCmd=@StrCmd +  'inner join #EDSClient sub on adm.ClientName=sub.SubClient '            
End     
Set @StrCmd=@StrCmd + ' where mrg.childbatchno is null and tbat.status=1 and bq.assigned=0 and bq.statusid=0                    
and tbat.serviceid not in(418,452) and (hld.Batchid is null or hld.ReleaseDate is not null)                            
and tbat.postedDt is null and tbat.UploadDt is null and bm.ULStatus is null and tbat.PgCount > 1'            
            
Set @StrCmd=@StrCmd + ' and tbat.PgCount <= cast('''+ @pgcount +'''as int)'            
Set @StrCmd=@StrCmd + '   and convert(date,tbat.scandate)= '''+@scandate+''''   
if( @MergeType='SubclientMerge')            
begin            
Set @StrCmd=@StrCmd +  ' and tbat.ClientID not in (select Clientid from ExcludeFormerge) '            
End                        
Set @StrCmd=@StrCmd + ')a group by ServiceName ,LastMergeddt order by LastMergeddt asc'            
exec(@StrCmd)                  
Select * from #BatchCountDetails          
End 


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SemiAutoMerge_pCheckAvailService] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[SemiAutoMerge_pCheckAvailService] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SemiAutoMerge_pCheckAvailService] TO [DB_DMLSupport]
    AS [dbo];

