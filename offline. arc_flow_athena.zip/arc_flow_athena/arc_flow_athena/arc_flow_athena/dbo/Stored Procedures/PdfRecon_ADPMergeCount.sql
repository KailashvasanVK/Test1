﻿CREATE proc PdfRecon_ADPMergeCount @Folderdetails MergeFolder Readonly     
as     
Begin    
    
/* 
Cretaed By     : Leela.T        
Created Date   : 2017-04-25       
Purpose        : Get the ADP MergeBatches count for         
Ticket/SCR ID  : <203209>    
        
        
Implemented by :  Ganesh. tanneru       
Implemented On :  26-04-2017    

Implemented by :  udhayaganesh.p       
Implemented On : 09-May-2017
        
*/

Select  Convert(date,downloaddate) downloaddate, Count(batchno) 'ADPMerge Count' from Trn_koff_tbatches (nolock) trn 
inner join arc_athena..batchmaster bat on trn.batchno =bat.batchnum     
where  Serviceid=444 
and Convert(date,downloaddate) in (select Convert(date, DateAdd(dd,1,FolderName )) from @Folderdetails)      
group by Convert(date,downloaddate)       

  
    
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[PdfRecon_ADPMergeCount] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[PdfRecon_ADPMergeCount] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[PdfRecon_ADPMergeCount] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[PdfRecon_ADPMergeCount] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[PdfRecon_ADPMergeCount] TO [DB_DMLSupport]
    AS [dbo];

