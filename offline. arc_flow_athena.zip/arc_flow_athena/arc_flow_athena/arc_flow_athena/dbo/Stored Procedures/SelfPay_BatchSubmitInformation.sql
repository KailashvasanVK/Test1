﻿CREATE Proc SelfPay_BatchSubmitInformation   
                 @AssignedTo int=0,  
                 @BatchProcessId int=0,  
                 @ServiceId int=0,  
                 @EntryPayment int=0,  
                  @EntrySelfPosting int=0,  
                  @EntryCollection int=0,  
                  @EntryExceptionPosting int=0,  
                  @EntryPatientCreation int=0,  
                  @QcPayment int=0,  
                  @QcSelfPosting int=0,  
                  @QcCollection int=0,  
                  @QcExceptionPosting int=0,  
                  @QcPatientCreation int=0,  
                  @EntryFactor varchar(10)='',  
                  @QcFactor varchar(10)='',  
                  @Status int=1,  
                  @CreatedBy int=0,                    
                  @ModifiedBy int=1,                    
                  @Comments varchar(500)=''  
as  
/*            
                
Created By     : Noor            
Created Date   : 2017-02-22   
Purpose        : Submit batch         
Ticket/SCR ID  :  1237 
TL Verified By : Ramakrishnan.G                  
                  
Implemented by : Ganesh Tanneru                  
Implemented On :  09-Jun-2017            
            
Reviewd by     : <DBA Name>            
Implemented On :                       
  
*/     
Begin  
Insert into arc_flow_athena.dbo.TRN_kOFF_tManualAllocattionBatchesAutoSubmit(AssignedTo,BatchProcessId,ServiceId,  
                 EntryPayment, EntrySelfPosting,EntryCollection,EntryExceptionPosting,EntryPatientCreation,  
                  QcPayment,QcSelfPosting,QcCollection,QcExceptionPosting,QcPatientCreation,EntryFactor,  
                  QcFactor,Status,CreatedBy,CreatedDt,ModifiedBy,ModifiedDt,Comments)Values(@AssignedTo,@BatchProcessId,@ServiceId,  
                 @EntryPayment,@EntrySelfPosting,@EntryCollection,@EntryExceptionPosting,@EntryPatientCreation,  
                  @QcPayment,@QcSelfPosting,@QcCollection,@QcExceptionPosting,@QcPatientCreation,@EntryFactor,  
                  @QcFactor,@Status,@CreatedBy,getdate(),@ModifiedBy,getdate(),@Comments)  
End  

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[SelfPay_BatchSubmitInformation] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SelfPay_BatchSubmitInformation] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SelfPay_BatchSubmitInformation] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[SelfPay_BatchSubmitInformation] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SelfPay_BatchSubmitInformation] TO [DB_DMLSupport]
    AS [dbo];

