﻿CREATE Procedure [dbo].[ADM_IssueLogFieldActions]    
     @ACTION VARCHAR(50)=''    
     ,@CmpKey varchar(50)=''  
     ,@FIELD_ID INT=0    
     ,@SERVICE_ID INT=0    
     ,@FIELDNAME VARCHAR(500)=''         
     ,@CONTROLTYPE VARCHAR(2)=''               
     ,@ACTIVE_STATUS INT=0                  
     ,@CREATED_BY INT=0   
     ,@DDL_ITEM VARCHAR(500)=''                 
         
AS    
    
    
BEGIN    
    
/*                      
Purpose           : To Perform IssuelogField services                
Created By        : Bhuvaneswari                      
Created Date      : 25 Apr 2013                      
Impact to         : Field.aspx                      
*/      

declare @CUSTOMER_ID as int
select @CUSTOMER_ID = CustomerId from ADM_Customer where CmpKey = @CmpKey                 
IF @ACTION = 'GET_FIELDSERVICES_BYFIELDID'    
BEGIN    
-- To get all assigned services by fieldid    
    
if( select COUNT(*) from ADM_IssuelogField where FieldId = @FIELD_ID and Status = 1) > 0    
begin    
SELECT S.FIELDID,S.SERVICEID,SI.SERVICENAME,SI.SERVICEACMNAME FROM ADM_ISSUELOGFIELDSERVICES S                
INNER JOIN ADM_SERVICE SI ON S.SERVICEID = SI.SERVICEID AND SI.STATUS = 1               
WHERE S.FIELDID = @FIELD_ID      
end    
END    
ELSE IF @ACTION = 'GET_FIELDS_BYCUSTOMER'    
BEGIN           
-- To get all assigned field by customerid    
SELECT I.FIELDID,I.FIELDNAME,I.CUSTOMERID,C.INTERNALNAME as CUSTOMERNAME,I.CONTROLTYPE,I.[STATUS] FROM ADM_ISSUELOGFIELD I      
INNER JOIN ADM_CUSTOMER AS C ON I.CUSTOMERID = C.CUSTOMERID      
WHERE I.CUSTOMERID = @CUSTOMER_ID                 
--AND [STATUS] = 1  -- TO ACTIVATE/DEACTIVATE FIELDS I.E) UNCONSIDER STATUS COLUMN.      
END    
ELSE IF @ACTION = 'INSERT_ISSUELOGFIELD'    
BEGIN    
-- To insert issuelog field    
  INSERT INTO ADM_ISSUELOGFIELD(CUSTOMERID,FIELDNAME,CONTROLTYPE,[STATUS],CREATEDBY,CREATEDDT)                  
  SELECT @CUSTOMER_ID,@FIELDNAME,@CONTROLTYPE,@ACTIVE_STATUS,@CREATED_BY,GETDATE()                   
  SELECT SCOPE_IDENTITY() AS INSID                  
END    
ELSE IF @ACTION = 'UPDATE_ISSUELOGFIELD'    
BEGIN    
-- To update issuelog field    
   INSERT INTO ADM_ISSUELOGFIELDLOG(FIELDID,CUSTOMERID,FIELDNAME,CONTROLTYPE,[STATUS],CREATEDBY,CREATEDDT)                  
   SELECT FIELDID,CUSTOMERID,FIELDNAME,CONTROLTYPE,[STATUS],CREATEDBY,CREATEDDT FROM ADM_ISSUELOGFIELD WHERE FIELDID = @FIELD_ID      
                    
   UPDATE ADM_ISSUELOGFIELD SET              
   FIELDNAME = @FIELDNAME,                
   CONTROLTYPE = @CONTROLTYPE,      
   [STATUS] = @ACTIVE_STATUS,                  
   CREATEDBY = @CREATED_BY,                  
   CREATEDDT = GETDATE()                  
   WHERE FIELDID = @FIELD_ID          
               
   IF @ACTIVE_STATUS > 0           
     BEGIN          
    INSERT INTO ADM_ISSUELOGFIELDSERVICESLOG(ID,FIELDID,SERVICEID,CREATEDBY,CREATEDDT)              
    SELECT ID,FIELDID,SERVICEID,CREATEDBY,CREATEDDT FROM ADM_ISSUELOGFIELDSERVICES WHERE FIELDID = @FIELD_ID                
               
    DELETE FROM ADM_ISSUELOGFIELDSERVICES WHERE FIELDID = @FIELD_ID      
      
      
     INSERT INTO ADM_IssuelogFieldDDLog(ID,FIELDID,ItemValue,CREATEDBY,CREATEDDT)              
    SELECT ID,FIELDID,ITEMVALUE,CREATEDBY,CREATEDDT FROM ADM_IssuelogFieldDD WHERE FIELDID = @FIELD_ID                
               
    DELETE FROM ADM_ISSUELOGFIELDDD WHERE FIELDID = @FIELD_ID    
      
     END          
END    
ELSE IF @ACTION = 'UPDATE_ISSUELOGFIELD_STATUS'    
BEGIN    
    
-- To Activate/deactivate field    
  INSERT INTO ADM_ISSUELOGFIELDLOG(FIELDID,CUSTOMERID,FIELDNAME,CONTROLTYPE,[STATUS],CREATEDBY,CREATEDDT)                    
  SELECT FIELDID,CUSTOMERID,FIELDNAME,CONTROLTYPE,[STATUS],CREATEDBY,CREATEDDT FROM ADM_ISSUELOGFIELD WHERE FIELDID = @FIELD_ID      
                     
  UPDATE ADM_ISSUELOGFIELD SET            
  [STATUS] = @ACTIVE_STATUS,                    
  CREATEDBY = @CREATED_BY,                    
  CREATEDDT = GETDATE()                    
  WHERE FIELDID = @FIELD_ID      
    
END    
ELSE IF @ACTION = 'INSERT_ISSUELOGFIELD_SERVICE'    
BEGIN    
-- To insert field services    
 INSERT INTO ADM_ISSUELOGFIELDSERVICES(FIELDID,SERVICEID,CREATEDBY,CREATEDDT)            
 SELECT @FIELD_ID,@SERVICE_ID,@CREATED_BY,GETDATE()           
END    
ELSE IF @ACTION = 'GET_CUSTOMER_BYKey'    
BEGIN    
    
IF @CUSTOMER_ID > 0     
BEGIN    
 SELECT CU.CUSTOMERID, CU.INTERNALNAME AS CUSTOMERNAME, CU.FULLNAME, CU.FINNAME, CU.FINEMAILID, CU.FINPHONE1, CU.FINPHONE2, CU.FINFAX,              
 CU.CONTRACTSTARTDT, CU.CONTRACTENDDT, CU.DISCOUNT, CU.TAT, CU.QUALITY, CU.STATUS, CU.CREATEDBY, CU.CREATEDDT,              
 CU.CUSTOMERADDRESS, CU.FULLNAME, CU.INTERNALNAME, CU.EXTERNALNAME,(SELECT ISNULL(COUNT(CLIENTID),0) FROM ADM_CLIENT WHERE CUSTOMERID = CU.CUSTOMERID) AS NUMBEROF_CLIENTS              
 FROM ADM_CUSTOMER CU                        
 WHERE CU.STATUS = 1  AND CU.CUSTOMERID = @CUSTOMER_ID                
END    
ELSE    
BEGIN    
 SELECT CU.CUSTOMERID, CU.INTERNALNAME AS CUSTOMERNAME, CU.FULLNAME, CU.FINNAME, CU.FINEMAILID, CU.FINPHONE1, CU.FINPHONE2, CU.FINFAX,              
  CU.CONTRACTSTARTDT, CU.CONTRACTENDDT, CU.DISCOUNT, CU.TAT, CU.QUALITY, CU.STATUS, CU.CREATEDBY, CU.CREATEDDT,              
   CU.CUSTOMERADDRESS, CU.FULLNAME, CU.INTERNALNAME, CU.EXTERNALNAME,(SELECT ISNULL(COUNT(CLIENTID),0) FROM ADM_CLIENT WHERE CUSTOMERID = CU.CUSTOMERID) AS NUMBEROF_CLIENTS              
 FROM ADM_CUSTOMER CU              
               
 WHERE CU.STATUS = 1           
END    
END    
ELSE IF @ACTION = 'INSERT_FIELDDDL_ITEM'  
BEGIN  
-- To insert field drop down items    
 INSERT INTO ADM_IssuelogFieldDD(FieldId,ItemValue,CREATEDBY,CREATEDDT)            
 SELECT @FIELD_ID,@DDL_ITEM,@CREATED_BY,GETDATE()       
END  
ELSE IF @ACTION = 'GET_FIELDDDLITEMS_BYFIELDID'    
BEGIN    
-- To get all assigned services by fieldid    
    
if( select COUNT(*) from ADM_IssuelogField where FieldId = @FIELD_ID and Status = 1) > 0    
begin    
SELECT ItemValue from  ADM_IssuelogFieldDD where FieldId = @FIELD_ID  
end    
END    
END


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_IssueLogFieldActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_IssueLogFieldActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_IssueLogFieldActions] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_IssueLogFieldActions] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_IssueLogFieldActions] TO [DB_DMLSupport]
    AS [dbo];

