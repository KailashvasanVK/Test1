﻿CREATE Proc [MovetoSelfpay]
--Declare @BatchNo varchar(50) = 'a'
--Declare @NewServiceId int = 357
--Declare @BatchId int = (Select BatchId from TRN_kOFF_tBatches where BatchNo = @BatchNo)
--Update TRN_kOFF_tBatches Set ServiceId = @NewServiceId  where BatchId = @BatchId
--Update TRN_kOFF_tBatchQueue Set ServiceId = @NewServiceId where BatchId = @BatchId 

as

Select batchid,batchno,batchtotal into #CTotal from arc_athena..batchtotal a 
inner join arc_flow_athena..trn_koff_tbatches c on c.batchno=a.batchnum
where c.status=3 and  a.batchtotal is not null  

Update a set dollaramt=b.batchtotal from arc_athena..batchmaster a inner join #CTotal b on a.batchnum=b.batchno
where a.dollaramt is null and b.batchtotal  is not null

Update tb  set ServiceId = 357 , Status =1 From  arc_flow_athena..TRN_kOFF_tBatches  tb Inner join #CTotal Ct on tb.batchid=ct.batchid where tb.status=3
Update tb  set ServiceId = 357 From  arc_flow_athena..TRN_kOFF_tBatchQueue  tb Inner join #CTotal Ct on tb.batchid=ct.batchid 



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[MovetoSelfpay] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MovetoSelfpay] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MovetoSelfpay] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[MovetoSelfpay] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MovetoSelfpay] TO [DB_DMLSupport]
    AS [dbo];

