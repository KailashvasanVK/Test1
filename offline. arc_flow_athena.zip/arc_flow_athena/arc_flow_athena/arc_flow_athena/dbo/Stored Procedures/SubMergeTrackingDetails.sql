﻿create proc [dbo].[SubMergeTrackingDetails] @processdate varchar(10),@Scandate varchar(10),@serviceid int, @Description varchar(3000),@TypeofMerge varchar(20)  
as   
  
begin 


/*      
  
Cretaed By     : Leela.T  
Created Date   : 2016-06-02    
Purpose        : Merge batches Tracking   
Ticket/SCR ID  : <>  
TL Verified By : <Ramki>  
 
Implemented by : 
Implemented On :  
  
Reviewd by     :  
Implemented On : 
*/

insert into Athena_SubMergeTracking (Procesdate,scandate,serviceid,Description,TypeofMerge)  
values(@processdate,@Scandate,@serviceid,@Description,@TypeofMerge)  
  
End  


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[SubMergeTrackingDetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SubMergeTrackingDetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SubMergeTrackingDetails] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[SubMergeTrackingDetails] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SubMergeTrackingDetails] TO [DB_DMLSupport]
    AS [dbo];

