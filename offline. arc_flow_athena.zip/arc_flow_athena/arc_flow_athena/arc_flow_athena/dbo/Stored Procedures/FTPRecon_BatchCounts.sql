﻿CREATE Proc FTPRecon_BatchCounts          
as          
/*Created by:Leela.T          
created on:11/09/2015          
purpose:Get the Batches count from  Flow for FTP reconcilation          
Requested by:Ramki

Created by:Leela.T          
created on:10/16/2017          
purpose: Segregate  the Ascension Batch Count          
Requested by:Ramki

*/          
begin      
Declare @inc int,@PendingCount bigint  ,@AscenBatchcount   bigint   
      
create table #FileCount(       
id int identity (1,1)      
,downloaddate varchar(11)      
,Batchcount int 
,AscenBatchcount bigint     
,UploadPending bigint  
 
)      
set @inc =0      
while(@inc<=6)      
  begin      
IF NOT EXISTS(select downloaddate from batchMaster where convert(date,downloaddate) =convert(date,GETDATE()-@inc))      
insert into #FileCount values(convert(varchar(10),GETDATE()-@inc,101),0,0)      
else      
begin      
insert into #FileCount (downloaddate,Batchcount)      
select  convert(varchar(10),downloaddate,101)  , COUNT(batchnum)as BatchCnt from batchMaster(nolock) bat 
inner join ARC_Flow_Athena..trn_koff_tbatches (nolock) trn  on bat.batchnum=trn.BatchNo
left join us_flow_athena..trn_koff_tbatches (nolock) ustrn on trn.BatchNo=ustrn.BatchNo
where downloaddate= convert(date,GETDATE()-@inc)  and ustrn.BatchNo is  null          
 and LEFT(batchnum,1) not in ('M','S') and trn.ServiceId<>363 group by downloaddate      
    
select  @PendingCount=COUNT(batchnum) from batchMaster(nolock) bat inner join ARC_Flow_Athena..trn_koff_tbatches(nolock)  trn    
on bat.batchnum=trn.BatchNo where downloaddate= convert(date,GETDATE()-@inc)  and ULStatus is  null         
 and LEFT(batchnum,1) not in ('M','S') and ServiceId<>363 and status<>0     
      
      
select  @AscenBatchcount= COUNT(ctxtrn.BatchNo)  from batchMaster(nolock) bat 
inner join ARC_Flow_Athena..trn_koff_tbatches (nolock) trn  on bat.batchnum=trn.BatchNo
inner join us_flow_athena..trn_koff_tbatches (nolock) ctxtrn on trn.BatchNo=ctxtrn.BatchNo
where downloaddate= convert(date,GETDATE()-@inc)           
 and LEFT(batchnum,1) not in ('M','S') and trn.ServiceId<>363 group by downloaddate 
 
update #FileCount set UploadPending=@PendingCount,AscenBatchcount=@AscenBatchcount where downloaddate=convert(varchar(10),GETDATE()-@inc,101)    
end      
set @inc=@inc+1      
End       
 select downloaddate,batchcount,isnull(AscenBatchcount,0),isnull(UploadPending,0) from #FileCount      
 drop table #FileCount      
end     

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[FTPRecon_BatchCounts] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[FTPRecon_BatchCounts] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[FTPRecon_BatchCounts] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[FTPRecon_BatchCounts] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[FTPRecon_BatchCounts] TO [DB_DMLSupport]
    AS [dbo];

