﻿CREATE  proc iEOBMerge_pMail(@ErrorState varchar(10), @ErrorMsg varchar(max),@scandate iEOBMerge_Batchtype readonly)                    
as                    
begin               
            
            
/*                  
              
Cretaed By     : Leela.T              
Created Date   : 2016-07-27                 
Purpose        : Merge Batch count & Percentage Details             
Ticket/SCR ID  : <249774>              
TL Verified By : <Ramki>              
      
Implemented by : Ganesh Tanneru                            
Implemented On : 14-Nov-17             
              
Reviewd by     :               
Implemented On :               
              
*/              
               
              
 Declare @Bodymsg varchar(max)            
,@Rowid int            
,@inc int            
,@date varchar(10)                                                                                                                                                                                                                                             

,@TemplateName varchar(100)            
,@ReceivedCnt int             
,@Mergecount int            
,@ChildCount int            
,@MergePrecent float            
,@NonMergeCount int            
,@NonMergePrecent float            
            
if (@ErrorState='false'  )      
begin      
if(object_id('tempdb.dbo.#Tempcount')is not null)                              
drop table #Tempcount                   
create table #Tempcount                                                                      
(                                                                                                                                                                                                                 
 scandate varchar(10)                                                                                                                                                                                                                                          

,TemplateName varchar(100)            
,Mergecount int            
,ChildCount int            
)                                     
            
if(object_id('tempdb.dbo.#Receivecnt')is not null)                              
drop table #Receivecnt                    
create table #Receivecnt                                                                      
(                                                                                                                                                                                                                 
 scandate varchar(10)                                                                                                                                                                                                                                          

,TemplateName varchar(100)                  
,ReceivedCnt int             
)              
            
                                   
if(object_id('tempdb.dbo.#MergeList')is not null)                              
drop table #MergeList                   
create table #Mergelist                                                                      
(              
 id int identity (1,1)                                                                                                                                                                                                               
,scandate varchar(10)                                                                                                                                                                                                                                          

,TemplateName varchar(100)           
,ReceivedCnt int             
,Mergecount int            
,ChildCount int            
,MergePrecent float            
,NonMergeCount int            
,NonMergePrecent float                 
)                                     
      
insert into #Tempcount                
select CONVERT(varchar,trn.ScanDate,101) , ttemp.TemplateName as TemplateName , count(distinct parentbatchno),COUNT(childbatchno)  from  TRN_kOFF_tBatches(nolock)trn                     
inner join mergebatchdetails (nolock) mrg on trn.BatchNo=mrg.Childbatchno inner join arc_athena..iEOB_tAutoIdentifyTemplate ttemp  on  ttemp.BatchNo=mrg.childbatchno-- and ttemp.statusid=5                
where  CONVERT(varchar,trn.ScanDate,101) in (select CONVERT(varchar,ScanDate,101) from @scandate) and  trn.serviceid=452 and LEFT(trn.batchno,1) not in ('M','S') group by trn.ScanDate, ttemp.TemplateName                     
                    
insert into #Receivecnt                     
select CONVERT(varchar,trn.ScanDate,101),ttemp.TemplateName as TemplateName ,COUNT(trn.batchno)  from  trn_koff_tbatches trn              
inner join arc_athena..iEOB_tAutoIdentifyTemplate ttemp  on  ttemp.BatchNo= trn.batchno  --and ttemp.statusid=5              
where  CONVERT(varchar,ScanDate,101)in (select CONVERT(varchar,ScanDate,101) from @scandate)  and LEFT(trn.batchno,1) not in ('M','S')       
and trn.pgcount between 2 and 20     and  trn.serviceid=452      
group by ttemp.TemplateName,trn.Scandate              
              
insert into #Mergelist               
select a.scandate,a.TemplateName,ReceivedCnt,a.Mergecount,a.ChildCount, Round(CAST(a.ChildCount as float)/CAST(ReceivedCnt as float) * 100,2), (ReceivedCnt-a.Childcount),            
Round(CAST((ReceivedCnt-a.Childcount) as float)/CAST(ReceivedCnt as float) * 100,2)from #Tempcount a inner join #Receivecnt b              
on a.TemplateName=b.TemplateName  and a.scandate=b.scandate order by TemplateName asc              
            
insert into #Mergelist            
select null,'Total' ,SUM(ReceivedCnt),SUM(Mergecount),SUM(childcount), ROUND(CAST(sum(ChildCount) as float)/CAST(sum(ReceivedCnt) as float) * 100,2),            
(sum(NonMergeCount)),Round(CAST(sum(NonMergeCount) as float)/CAST(sum(ReceivedCnt) as float) * 100,2)            
from #Mergelist             
            
            
select @Rowid=COUNT(id) from #Mergelist            
if(@Rowid>0)            
begin            
set @Bodymsg='Hi All,'                        
set @Bodymsg=@Bodymsg+' <br> <br>                       
<Table  border=1> <tr bgcolor=Purple>'                        
set @Bodymsg=@Bodymsg+'<th> <font color=White> Scandate  </font> </th> <th> <font color=White> Template Name </font> </th>            
<th> <font color=White>Received  Batches </font> </th> <th> <font color=White> Merge Batches </font> </th>            
<th> <font color=White> Child Batches </font> </th> <th> <font color=White> Merge Percent </font> </th>            
<th> <font color=White> Non MergeBatches </font> </th> <th> <font color=White> Non MergePercent</font> </th></tr>'                        
    set @inc=1                    
while(@Rowid!=0)                        
begin                        
select @date=scandate,@TemplateName=TemplateName,@ReceivedCnt=ReceivedCnt,@Mergecount=Mergecount,@ChildCount=ChildCount,@MergePrecent=MergePrecent,@NonMergeCount=NonMergeCount,@NonMergePrecent=NonMergePrecent  from #Mergelist   where id=@inc             


set @Bodymsg=@Bodymsg+'<tr>'                        
set @Bodymsg=@Bodymsg+'<td align=right>' + isnull(@date,'')  + '</td>'                        
set @Bodymsg=@Bodymsg+'<td align=right>' + @TemplateName + '</td>'                       
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@ReceivedCnt as varchar)+ '</td>'            
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@Mergecount as varchar) + '</td>'            
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@ChildCount  as varchar)+ '</td>'            
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@MergePrecent as varchar) + '</td>'            
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@NonMergeCount as varchar) + '</td>'            
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@NonMergePrecent as varchar) + '</td> </tr>'            
            
set @Rowid=@Rowid-1     
delete from #Mergelist where  id=@inc              
set @inc=@inc+1                    
End                        
                        
set @Bodymsg=@Bodymsg +'</Table><br><br><br> Thanks <br><br><b> ** This is Auto generated Mail ** '                        
End      
 End      
       
 else if(@ErrorState='true'     )      
 begin      
 set @Bodymsg=@ErrorMsg      
 End      
            
EXEC msdb.dbo.sp_send_dbmail                                        
@profile_name = 'DBAMail',                                                                                                                                                               
@recipients='DL-WTP@accesshealthcare.co;mirza.karim@accesshealthcare.co;ramakrishnan.go@accesshealthcare.co;leela.thangavel@accesshealthcare.co;            
dl_dba@accesshealthcare.co',                                                                       
@subject='EchoPay Merge Batch Details',                                                  
@body = @Bodymsg ,                                                                                            
@body_format  = 'HTML'                 
            
drop table #Tempcount              
drop Table #Receivecnt            
drop table #Mergelist              
              
End


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOBMerge_pMail] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[iEOBMerge_pMail] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOBMerge_pMail] TO [DB_DMLSupport]
    AS [dbo];

