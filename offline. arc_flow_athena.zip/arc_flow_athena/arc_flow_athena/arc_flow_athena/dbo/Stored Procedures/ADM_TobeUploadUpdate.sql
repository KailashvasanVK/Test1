﻿CREATE Procedure  ADM_TobeUploadUpdate(@RowId int)
As
Begin
Update ADM_ToBeUploadTran Set Status = 1 Where RowId = @RowId
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_TobeUploadUpdate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_TobeUploadUpdate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_TobeUploadUpdate] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_TobeUploadUpdate] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_TobeUploadUpdate] TO [DB_DMLSupport]
    AS [dbo];

