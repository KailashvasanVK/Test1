﻿CREATE  Procedure [dbo].[ADM_AccessClientInsert]    
@UserId int ,    
@ClientId int,  
@ServiceId int,  
@CreatedBy  int,
@CustomerId int      
As    
/*    
Created by : Karthik Ic    
Created on : 20 May 2013    
Impact to  : ProfileSetup.aspx    
Purpose    : To save the user client wise service details.  
Modified by : Kathiravan.kand
*/    
Begin  
/* Original Procedure start  */
    --Insert into ADM_AccessClient(UserId,ClientId,ServiceId,CreatedBy,CustomerId)    
	--Select @UserId,@ClientId,@ServiceId,@CreatedBy,@CustomerId
	
/* Original Procedure end  */
  
IF @ClientId = 0 /*To Insert all client Test */
		BEGIN
			Insert into ADM_AccessClient(UserId,ClientId,ServiceId,CreatedBy,CustomerId)    
			Select @UserId,ClientId,@ServiceId,@CreatedBy,@CustomerId
			from ADM_Client where CustomerId = @CustomerId
		END
	ELSE
		BEGIN
			Insert into ADM_AccessClient(UserId,ClientId,ServiceId,CreatedBy,CustomerId)    
			Select @UserId,@ClientId,@ServiceId,@CreatedBy,@CustomerId
		END
End
 

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_AccessClientInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessClientInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessClientInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_AccessClientInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessClientInsert] TO [DB_DMLSupport]
    AS [dbo];

