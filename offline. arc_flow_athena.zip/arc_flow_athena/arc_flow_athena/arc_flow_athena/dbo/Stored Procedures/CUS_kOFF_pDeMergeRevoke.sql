﻿Create Procedure CUS_kOFF_pDeMergeRevoke(@BatchNo varchar(20))
As
Begin
/** DeMerge Revoke **/
--Declare @BatchNo varchar(20) = 'M23407A2207'
if OBJECT_ID('tempdb..#ChildBatches') is not null drop table #ChildBatches
Select q.BatchId,q.BatchProcessId into #ChildBatches 
from TRN_kOFF_tBatchQueue as q
inner join trn_koff_tbatches as b on b.BatchId = q.BatchId and b.status = 20
inner join MergeBatchDetails  as mg on mg.ParentBatchNo = b.BatchNo and mg.ParentBatchNo = @BatchNo

Update b Set UploadDt = null,PostedDt = null,AuditedDt = null,status = 99
from TRN_kOFF_tBatches as b
inner join #ChildBatches as child on child.BatchId = b.BatchId

Update q Set StatusId = 0,Assigned = 0
from TRN_kOFF_tBatchQueue as q
inner join #ChildBatches as child on child.BatchId = q.BatchId

Delete f from 
TRN_kOFF_tBatchFlow as f
inner join #ChildBatches as child on child.BatchId = f.BatchId
where f.StatusId <> 0

Delete f from 
TRN_kOFF_tBatchTransact as f
inner join #ChildBatches as child on child.BatchId = f.BatchId

Delete f from 
TRN_kOFF_tBatchTransactSummary as f
inner join #ChildBatches as child on child.BatchId = f.BatchId

Delete f from 
TRN_kOFF_tBatchQCMaster as f
inner join #ChildBatches as child on child.BatchProcessId = f.BatchProcessId

Delete f from 
TRN_kOFF_tBatchQCTran as f
inner join #ChildBatches as child on child.BatchProcessId = f.BatchProcessId

Delete f from 
TRN_kOFF_tBatchQCComments as f
inner join #ChildBatches as child on child.BatchProcessId = f.BatchProcessId
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kOFF_pDeMergeRevoke] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kOFF_pDeMergeRevoke] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kOFF_pDeMergeRevoke] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kOFF_pDeMergeRevoke] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kOFF_pDeMergeRevoke] TO [DB_DMLSupport]
    AS [dbo];

