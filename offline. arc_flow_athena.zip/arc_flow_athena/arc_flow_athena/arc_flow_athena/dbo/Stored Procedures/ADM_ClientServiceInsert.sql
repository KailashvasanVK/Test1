﻿CREATE Procedure [dbo].[ADM_ClientServiceInsert]     
      @ServiceId int, 
      @Datatype int,      
      @CreatedBy int,
      @ClientId int    
As 
BEGIN    
  
 /*     
 Purpose :Insert client services and Groups into Database      
    Created By   : Kathiravan
    Created Date : 24 April 2013
    Impact to    :ClientCreation.aspx
 */ 
if ISNULL(@ClientId,0) = 0 
 begin
 /* new creation */ 
 SELECT @ClientId =  IDENT_CURRENT('ADM_Client')	
insert into ADM_ClientServicePrice(ClientId,ServiceId,Price,CreatedBy)
Select @ClientId,@ServiceId,Price,@CreatedBy FROM ARC_FLOW_Athena..ADM_CustomerServices as cs
inner Join
(
SELECT cl.CustomerId,cus.ServiceId FROM ARC_FLOW_Athena..ADM_CustomerServices as cus
inner join ARC_FLOW_Athena..ADM_Client as cl on cl.ClientId = @ClientId and cl.CustomerId = cus.CustomerId
Where ServiceId = @ServiceId group by cl.CustomerId,ServiceId having COUNT(*) = 1
)x on x.CustomerId = cs.CustomerId and x.ServiceId = cs.ServiceId
 INSERT INTO ADM_ClientServices(ClientId,ServiceId,DataType,CreatedBy,Status)
 SELECT @ClientId,@ServiceId,@Datatype,@CreatedBy,1
 end
else
 begin
 /* edit mode */
 if not (select COUNT(*) from ADM_ClientServices where ClientId = @ClientId and ServiceId = @ServiceId) > 0
  /** if newly added service **/
  INSERT INTO ADM_ClientServices(ClientId,ServiceId,DataType,CreatedBy,Status)      
  SELECT @ClientId,@ServiceId,@Datatype,@CreatedBy,1  
 else
  /** if existing service move to log and updation made **/
  begin
  /** move to log **/
  INSERT INTO ADM_ClientServicesLog(ClientId,ServiceId,DataType,CreatedBy,CreatedDt,Status,CSId)      
  SELECT ClientId,ServiceId,DataType,CreatedBy,CreatedDt,Status,CSId      
  from ADM_ClientServices where ClientId = @ClientId and ServiceId = @ServiceId
  /** updation **/
  update ADM_ClientServices set DataType = @Datatype where ClientId = @ClientId and ServiceId = @ServiceId
  end 
 end
END


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ClientServiceInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ClientServiceInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ClientServiceInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ClientServiceInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ClientServiceInsert] TO [DB_DMLSupport]
    AS [dbo];

