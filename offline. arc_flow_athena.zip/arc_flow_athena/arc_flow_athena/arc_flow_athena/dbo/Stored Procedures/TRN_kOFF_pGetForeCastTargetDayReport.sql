﻿CREATE procedure  TRN_kOFF_pGetForeCastTargetDayReport    
    (  
     @fromDate Date,  
     @toDate Date,  
     @SearchStr varchar(50) ='',  
  @SearchPattern varchar(50)='='  
    )  
    as  
    begin  
  Set Transaction Isolation level Read uncommitted;
      /*  
 Created By mallikarjun.nam  
 Created Date :04-09-2015  
 Impact : Forecastreport.aspx in .flow.offline (athena application) -Show day wise target achived details report  
   
 Modified by : mallikarjun.nam  
 Modified dt : 2015-10-05  
 Purpose     : previously report getting based on scandate now changed Trans completed date instead of scandate  
   
   
 */  
    --declare @fromDate varchar(20)='2014-12-01',@toDate varchar(20)='2015-08-31'  
     /*gettting @fromDate as starting date of month and @toDate as Last Date of the month  
 --set @fromDate = '01'+ @fromDate  
 --SELECT  @toDate=DATEADD(d, -1, DATEADD(m, DATEDIFF(m, 0, @toDate) + 1, 0))  
   
  --declare @NoOfDays int=DATEDIFF(dd,@fromDate,@toDate)  
  */ 
   declare @LastDayOfMonth varchar(20)=(SELECT DATEADD(d, -1, DATEADD(m, DATEDIFF(m, 0, @toDate) + 1, 0)))  

   
  DECLARE @WORKDAYS INT  
     SELECT @WORKDAYS =(select dbo.TRN_kOFF_fnCalculateWeekDays(@fromDate,@LastDayOfMonth))  
  ---In this CTE Table selecting all the dates @fromDate to @toDate with null values  
     if (OBJECT_ID('tempdb..#tblForeCast') IS NOT NULL)  DROP TABLE #tblForeCast  
        ;with mths as  
  (  
   select convert(date,@fromDate) as SDate,0 as Achieved,0 as YetToAchieved,0 as [Achieved%]   
   union all  
   select DATEADD(dd,1,convert(date,SDate)),0 as Achieved,0 as YetToAchieved,0 as [Achieved%]  from mths  
   where DATEADD(dd,1,convert(date,SDate)) <= convert(date,@toDate)  
   )  
     
   select *  into #tblForeCast from mths  
   option (maxrecursion 32767);  
     
   --Getting Transvalue from trn_kOFF_tbatchTransact and inner join with mths table getting TransDate and Sum(TransValue) etc.  
  if (OBJECT_ID('tempdb..#tblForeCastNew') IS NOT NULL)  DROP TABLE #tblForeCastNew  
    
  select F1.SDate,F1.Achieved,F1.YetToAchieved,F1.[Achieved%] ,Target as Target   
    
  into #tblForeCastNew from #tblForeCast  F1 left outer join  ADM_Forecast F2  
  on datepart(mm, F1.SDate)=F2.Month and datepart(yy, F1.SDate)= F2.Year  
  
  if (OBJECT_ID('tempdb..#tblForeCastFinalReport') IS NOT NULL)  DROP TABLE #tblForeCastFinalReport  
    
   select convert(varchar,SDate,101) as Date,datename(dw,Sdate) as Day  
   ,(case when datename(dw,SDate) IN('Sunday','Saturday') THEN 0 else (isnull(Target,0)/@WORKDAYS) end) as [Day wise Target]   
   ,isnull(Achieved,0)Achieved  
   , (case when datename(dw,SDate) IN('Sunday','Saturday') THEN '0.00%' else  
    (case when  isnull(Target,0)=0 then '0.00%' else  convert(varchar, cast((convert(money,isnull(Achieved,0))/convert(money,isnull(Target,0)/@WORKDAYS)*100)as decimal(18,2))) + '%'  end) end) as [Achieved%]  
   into #tblForeCastFinalReport  
   from(  
   select sum(isnull(TransValue,0)) as Achieved,Target,FF.SDate from #tblForeCastNew FF left outer join   
   (  
   select isnull(TransValue,0)TransValue, convert(date,T.CreatedDt) as TransDate 
   from trn_kOFF_tbatchTransact T
    Inner JOIN trn_kOFF_tbatches B ON T.BatchId= B.BatchID AND B.status=1 and isnull(T.TransValue,0) <>0 and  
   convert(date,T.CreatedDt) between convert(date,@fromDate) and convert(date,@toDate)  
   )as TranTbl ON  FF.SDate =TransDate group by Target,FF.SDate  
   ) as TranSumTbl  order by SDate  
    
   select * into #report from   
   (  
    select Convert(varchar(5),'')ColHead,Date,Day,[Day wise Target] ,Achieved,[Achieved%] from #tblForeCastFinalReport  
    union all   
    select 'G','Total' as Date,null,(select sum([Day wise Target]) from #tblForeCastFinalReport),(select sum(Achieved) from #tblForeCastFinalReport),  
    (CASE WHEN (select sum([Day wise Target]) from #tblForeCastFinalReport)=0 then '0.00%' Else   
    convert(varchar,( convert(money,(select sum(Achieved) from #tblForeCastFinalReport))/convert(money,(select sum([Day wise Target]) from #tblForeCastFinalReport))*100)) + '%'  
    end)  
    )x  
      
    Exec FilterTable    
 @DbName = 'tempdb'    
 ,@TblName = '#report'    
 ,@SearchStr = @SearchStr    
 ,@SearchPattern = @SearchPattern  
 ,@OrderStr = ''  
end  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pGetForeCastTargetDayReport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pGetForeCastTargetDayReport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pGetForeCastTargetDayReport] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pGetForeCastTargetDayReport] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pGetForeCastTargetDayReport] TO [DB_DMLSupport]
    AS [dbo];

