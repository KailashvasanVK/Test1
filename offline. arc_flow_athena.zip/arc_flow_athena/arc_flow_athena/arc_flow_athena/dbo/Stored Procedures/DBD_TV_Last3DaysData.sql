﻿

CREATE Proc dbo.DBD_TV_Last3DaysData
as


       if OBJECT_ID('tempdb..#Production') is not null  drop table #Production  
       if OBJECT_ID('tempdb..#Quality') is not null  drop table #Quality
       if OBJECT_ID('tempdb..#Attendance') is not null  drop table #Attendance

		if OBJECT_ID('tempdb..#Dates') is not null  drop table #Dates
		if OBJECT_ID('tempdb..#Clients') is not null  drop table #Clients
		create table #Dates (ClientId int, DateKey int)
		create table #Clients (ClientId int)
		Declare @ClientId int, @DateKey int

		select @DateKey=DateKey from [LNKTPARFLOW].arc_dashboard.dbo.DimDate where
		 [date]=convert(varchar, dateAdd(m, -1, getdate()), 101)

		insert into #Clients
		select distinct ClientId from [LNKTPARFLOW].arc_dashboard.dbo.FactProductionQuality 
		where active=1 and FactoredProduction>0 and DataSource='tp.offline' and DateKey>=@DateKey 	

		
		select @ClientId=min(ClientId) from #Clients
		while @ClientId is not null
		begin
			insert into #Dates
			select distinct top 3 ClientId, Datekey  from [LNKTPARFLOW].arc_dashboard.dbo.FactProductionQuality 
			where active=1 and FactoredProduction>0 and DataSource='tp.offline' and ClientId=@ClientId order by datekey desc

			select @ClientId=min(ClientId) from #Clients where ClientId>@ClientId
		end

       select a.datekey, a.ClientId, b.LOB, sum(isnull(FactoredProduction,0)) FactoredProduction,
        sum(isnull(ProdTarget,0)) ProdTarget  into #Production
       from [LNKTPARFLOW].arc_dashboard.dbo.FactProductionQuality a inner join 
       arc_rec.dbo.ARC_REC_USER_INFO b on a.UserId=b.USERID
       inner join #Dates c on a.DateKey=c.DateKey and a.clientId=c.ClientId
       where a.Active=1 
       group by a.datekey, a.ClientId, b.LOB

		delete from #Dates 
		delete from #Clients
		 
		insert into #Clients		
		select distinct ClientId from [LNKTPARFLOW].arc_dashboard.dbo.FactQuality where 
		active=1 and ErrorDoneAudited>0 and DataSource='tp.offline'
		and DateKey>=@DateKey

		
		select @ClientId=min(ClientId) from #Clients
		while @ClientId is not null
		begin
			insert into #Dates
			select distinct top 3 @ClientId, Datekey 
			from [LNKTPARFLOW].arc_dashboard.dbo.FactQuality where active=1 and ErrorDoneAudited>0  and
			 DataSource='tp.offline' and ClientId=@ClientId order by datekey desc
			
			select @ClientId=min(ClientId) from #Clients where ClientId>@ClientId
		end

       select a.datekey, a.ClientId, b.LOB, sum(isnull(ErrorDone,0)) ErrorDone, 
       sum(isnull(ErrorDoneAudited,0)) ErrorDoneAudited  into #Quality
       from [LNKTPARFLOW].arc_dashboard.dbo.FactQuality a inner join arc_rec.dbo.ARC_REC_USER_INFO b on a.UserId=b.USERID
       inner join #Dates c on a.DateKey=c.DateKey and a.ClientId=c.ClientId
       where a.Active=1 
       group by a.datekey, a.ClientId, b.LOB

		delete from #Dates 
		delete from #Clients

		insert into #Clients
		select distinct PrimaryClientId  from [LNKTPARFLOW].arc_dashboard.dbo.factAttendance where DateKey>=@DateKey
		and PrimaryClientId=15

		select @ClientId=min(ClientId) from #Clients
		while @ClientId is not null
		begin
			insert into #Dates
			select distinct top 3 @ClientId, Datekey from [LNKTPARFLOW].arc_dashboard.dbo.factAttendance 
			where PrimaryClientId=@ClientId and IsDeclaredOff=0 order by datekey desc

			select @ClientId=min(ClientId) from #Clients where ClientId>@ClientId
		end

       select fa.DateKey,fa.PrimaryClientID ClientId, b.LOB, sum(fa.Present) as Present, 
       count(1) as AttTarget into #Attendance  
       from [LNKTPARFLOW].arc_dashboard.dbo.factAttendance fa inner join
        arc_rec.dbo.ARC_REC_USER_INFO b on fa.UserId=b.USERID
       inner join #Dates c on fa.DateKey=c.DateKey and fa.PrimaryClientId=c.ClientId
       where fa.IsDeclaredOff = 0  
       group by fa.DateKey,fa.PrimaryClientID, b.LOB

       if exists (select * from #Production)
       begin
 delete from DBD_TV_Customer_Last3DaysProduction

              insert into DBD_TV_Customer_Last3DaysProduction(ReportDate,CustomerId,LOBId,FactoredProduction,ProdTarget) 
              select convert(date,convert(varchar(10),datekey)), ClientId,LOB,FactoredProduction,ProdTarget from #Production
       end

       if exists (select * from #Quality)
       begin
              delete from DBD_TV_Customer_Last3DaysQuality

      insert into DBD_TV_Customer_Last3DaysQuality(ReportDate,CustomerId,LOBId,ErrorDone,ErrorDoneAudited) 
              select convert(date,convert(varchar(10),datekey)), ClientId,LOB,ErrorDone,ErrorDoneAudited from #Quality
       end

       if exists (select * from #Attendance)
       begin
              delete from DBD_TV_Customer_Last3DaysAttendance

              insert into DBD_TV_Customer_Last3DaysAttendance(ReportDate,CustomerId,LOBId,Present,AttTarget) 
              select convert(date,convert(varchar(10),datekey)), ClientId,LOB,Present,AttTarget from #Attendance
       end



GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[DBD_TV_Last3DaysData] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[DBD_TV_Last3DaysData] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[DBD_TV_Last3DaysData] TO [DB_DMLSupport]
    AS [dbo];

