﻿CREATE PROCEDURE iEOB_tContributionReport      
(      
@FromDate varchar(50) = NULL,      
@ToDate varchar(50) = NULL      
)      
As      
/*                      
Created By     : Gobinath.M                                  
Created Date   : 2017-20-12                    
Purpose        : To Show the Contribution from iEOB and ADP Trans      
Ticket/SCR ID  :                    
TL Verified By : Ramakrishnan.G                    
                    
Implemented On :                     
Implemented On :        
Reviewed by    :                     
Reviewed On    :        
        
Implemented By :                     
Implemented On :        
*/                     
BEGIN      
      
IF OBJECT_ID('Tempdb..#BatchList') is not null drop table #BatchList
Select tb.BatchNo, tb.ServiceID, LEFT(REPLACE(pm.PayerName, '-',' '), CHARINDEX(' ', REPLACE(pm.PayerName, '-', ' '))) as PayerName, 
tb.ScanDate, tb.PgCount
into  #BatchList
From ARC_Flow_Athena..TRN_koff_tBatches(nolock) tb
Inner join ARC_Athena..iEOB_tPayerAllocation (nolock) pm on pm.PayerID = tb.PayerID
Where CAST(ScanDate As DATE) BETWEEN @FromDate AND @ToDate and tb.status = 1 and tb.ServiceID in (418, 444, 452, 453) and tb.PostedDt IS NOT NULL

/*Over ALl ADP Contribution*/
IF OBJECT_ID('Tempdb..#OverAllBatchList') is not null drop table #OverAllBatchList
Select tb.BatchNo, tb.ServiceID, LEFT(REPLACE(pm.PayerName, '-',' '), CHARINDEX(' ', REPLACE(pm.PayerName, '-', ' '))) as PayerName,
tb.ScanDate, tb.PgCount
into  #OverAllBatchList
From ARC_Flow_Athena..TRN_koff_tBatches(nolock) tb
Inner join ARC_flow_Athena..adm_payername (nolock) pm on pm.PayerID = tb.PayerID
Where CAST(ScanDate As DATE) BETWEEN @FromDate AND @ToDate and tb.status = 1 and tb.ServiceID in (418, 444) and tb.PostedDt IS NOT NULL

/*Over ALl ADP Contribution*/
IF OBJECT_ID('Tempdb..#OverAlltemp') is not null drop table #OverAlltemp
Select tb.BatchNo, SUM(CreatedPtnCnt) + SUM(PaymentInsCnt) + SUM(ExceptionCnt) + SUM(PtnPostingCnt) + SUM(ColPostingCnt) As Payment 
into #OverAlltemp
from #OverAllBatchList tb
Inner join ARC_Athena..BatchLogInformation(nolock) bLog on bLog.BatchNum = tb.BatchNo
Where tb.ServiceID in (418, 444)
Group by tb.BatchNo

/*ADP Contribution*/
IF OBJECT_ID('Tempdb..#temp') is not null drop table #temp
Select tb.BatchNo, SUM(CreatedPtnCnt) + SUM(PaymentInsCnt) + SUM(ExceptionCnt) + SUM(PtnPostingCnt) + SUM(ColPostingCnt) As Payment into #temp
from #BatchList tb
Inner join ARC_Athena..BatchLogInformation(nolock) bLog on bLog.BatchNum = tb.BatchNo
Where tb.ServiceID in (418, 444)
Group by tb.BatchNo

IF OBJECT_ID('Tempdb..#temp1') is not null drop table #temp1
Select distinct a.BatchNo, SUM(a.Payment) As Payment into #temp1
from (
Select Distinct a.Batchnum  As BatchNo, COUNT(id) As Payment
from ARC_Athena..PaymentDetailMaster(nolock) a
Inner join #temp t on t.BatchNo = a.BatchNum  Where a.OCRStatus = 0
group by a.Batchnum
Union All
Select b.BatchNum, CASE WHEN b.Total >= 0 THEN Total ELSE 0 END AS Payment from (
Select Total = SUM(a.B) - SUM(a.T), a.BatchNum From (
Select COUNT(ID) AS T, 0 As B, BatchNum from ARC_Athena..BatchException_ocr(nolock) o
Inner join #temp t on t.BatchNo = o.BatchNum Group by BatchNum UNION ALL
Select 0 As T, COUNT(ID) As B, BatchNum from ARC_Athena..BatchException(nolock) b
Inner join #temp t on t.BatchNo = b.BatchNum Group by BatchNum)a group by a.BatchNum) b
Union All
Select Distinct pymnt.Batchnum As BatchNo, COUNT(distinct(clm.ClaimID)) As Payment
from ARC_Athena..PaymentDetailMaster(nolock) pymnt
inner join ARC_Athena..ClaimServiceDetailMaster(nolock) csd on pymnt.chargeID=csd.ChargeID
inner join ARC_Athena..ClaimDetailMaster(nolock) clm on csd.ClaimID =clm.ClaimID
Inner join #temp t on t.BatchNo = pymnt.BatchNum
Where clm.Status=1 and pymnt.OCRStatus = 0      
group by pymnt.Batchnum
)a Group by a.BatchNo

/*iEOB Contribution*/
IF OBJECT_ID('Tempdb..#iEOBtemp') is not null drop table #iEOBtemp
Select tb.BatchNo, SUM(CreatedPtnCnt) + SUM(PaymentInsCnt) + SUM(ExceptionCnt) + SUM(PtnPostingCnt) + SUM(ColPostingCnt) As Payment  
into #iEOBtemp
from #BatchList tb
Inner join ARC_Athena..BatchLogInformation(nolock) bLog on bLog.BatchNum = tb.BatchNo
Where tb.ServiceID in (452, 453)
Group by tb.BatchNo

IF OBJECT_ID('Tempdb..#iEOBtemp1') is not null drop table #iEOBtemp1
Select distinct a.BatchNo, SUM(a.Payment) As Payment into #iEOBtemp1
from (
Select Distinct a.Batchnum  As BatchNo, COUNT(id) As Payment
from ARC_Athena..PaymentDetailMaster(nolock) a 
Inner join #iEOBtemp t on t.BatchNo = a.BatchNum Where a.OCRStatus = 0
group by a.Batchnum
Union All
Select b.BatchNum, CASE WHEN b.Total >= 0 THEN Total ELSE 0 END AS Payment from (      
Select Total = SUM(a.B) - SUM(a.T), a.BatchNum From (      
Select COUNT(ID) AS T, 0 As B, BatchNum from ARC_Athena..BatchException_ocr(nolock) o
Inner join #iEOBtemp t on t.BatchNo = o.BatchNum Group by BatchNum UNION ALL
Select 0 As T, COUNT(ID) As B, BatchNum from ARC_Athena..BatchException(nolock) b
Inner join #iEOBtemp t on t.BatchNo = b.BatchNum Group by BatchNum)a group by a.BatchNum) b
Union All
Select Distinct pymnt.Batchnum As BatchNo, COUNT(distinct(clm.ClaimID)) As Payment
from ARC_Athena..PaymentDetailMaster(nolock) pymnt
inner join ARC_Athena..ClaimServiceDetailMaster(nolock) csd on pymnt.chargeID=csd.ChargeID
inner join ARC_Athena..ClaimDetailMaster(nolock) clm on csd.ClaimID =clm.ClaimID
Inner join #iEOBtemp t on t.BatchNo = pymnt.BatchNum
Where clm.Status=1 and pymnt.OCRStatus = 0
group by pymnt.Batchnum
)a Group by a.BatchNo

SELECT z.ScanDate, SUM(TotalContribution) AS TotalContribution, SUM(ADPContribution) As ADPContribution, SUM(OverAllADPContribution)  As OverAllADPContribution,  
SUM(iEOBContribution) As iEOBContribution, TotalADPContribution = SUM(ADPContribution) + SUM(iEOBContribution),      
SUM([<6 Trans]) AS '<6 Trans', SUM([>=6 Trans]) As '>=6 Trans',    
'ADPContri.(%)' = ROUND(CAST(SUM(ADPContribution) As Float) / CAST(SUM(TotalContribution) As Float) * 100, 2),      
'iEOBContri.(%)' = ROUND(CAST(SUM(iEOBContribution) As Float) / CAST(SUM(TotalContribution) As Float) * 100, 2) FROM (  
    
Select e.ScanDate, SUM(TotalContribution) As TotalContribution, SUM(ADPContribution) As ADPContribution,  0 As OverAllADPContribution,      
SUM(iEOBContribution) As iEOBContribution, TotalADPContribution = SUM(ADPContribution) + SUM(iEOBContribution),      
SUM([<6 Trans]) AS '<6 Trans', SUM([>=6 Trans]) As '>=6 Trans',    
'ADPContri.(%)' = ROUND(CAST(SUM(ADPContribution) As Float) / CAST(SUM(TotalContribution) As Float) * 100, 2),      
'iEOBContri.(%)' = ROUND(CAST(SUM(iEOBContribution) As Float) / CAST(SUM(TotalContribution) As Float) * 100, 2)    
From (    
/*Scan Date wise*/    
SELECT CONVERT(varchar(15), c.ScanDate) As ScanDate  , SUM(TotalContribution) As TotalContribution, SUM(ADPContribution) As ADPContribution,  0 As OverAllADPContribution,      
SUM(iEOBContribution) As iEOBContribution, '<6 Trans' = SUM(iEOBContribution) + SUM(ADPContribution), 0 As '>=6 Trans' from (      
/*Total Contribution*/    
Select tb.BatchNo, SUM(CreatedPtnCnt) + SUM(PaymentInsCnt) + SUM(ExceptionCnt) + SUM(PtnPostingCnt) +  SUM(ColPostingCnt) As TotalContribution,      
0 As ADPContribution, 0 As OverAllADPContribution, 0 As iEOBContribution from #BatchList tb      
Inner join ARC_Athena..BatchLogInformation(nolock) bLog on bLog.BatchNum = tb.BatchNo        
Group by tb.BatchNo       
UNION ALL      
/*ADP Contribution*/      
Select t.BatchNo, 0 As TotalContribution, ADPContribution = SUM(t.Payment) -  SUM(t1.Payment), 0 As OverAllADPContribution, 0 As iEOBContribution from #temp t      
Inner join #temp1 t1 on t1.BatchNo = t.BatchNo  Group by t.BatchNo    
UNION ALL      
Select  BatchNo, 0 As TotalContribution, ADPContribution = Payment, 0 As OverAllADPContribution, 0 As iEOBContribution from #temp Where BatchNo not in (Select BatchNo from #temp1)        
UNION ALL      
/*iEOB Contribution*/       
Select t.BatchNo, 0 As TotalContribution, 0 As ADPContribution, 0 As OverAllADPContribution, iEOBContribution = SUM(t.Payment) -  SUM(t1.Payment) from #iEOBtemp t      
Inner join #iEOBtemp1 t1 on t1.BatchNo = t.BatchNo Group by t.BatchNo      
UNION ALL      
Select  BatchNo, 0 As TotalContribution, 0 As ADPContribution, 0 As OverAllADPContribution, iEOBContribution = Payment from #iEOBtemp Where BatchNo not in (Select BatchNo from #iEOBtemp1)      
)b      
Inner join #BatchList c on c.BatchNo = b.BatchNo Where c.PgCount <6 Group by  c.ScanDate      
UNION ALL     
SELECT CONVERT(varchar(15), c.ScanDate) As ScanDate  , SUM(TotalContribution) As TotalContribution, SUM(ADPContribution) As ADPContribution,  0 As OverAllADPContribution,      
SUM(iEOBContribution) As iEOBContribution, 0 As '<6 Trans', '>=6 Trans' = SUM(iEOBContribution) + SUM(ADPContribution) from (      
/*Total Contribution*/      
Select tb.BatchNo, SUM(CreatedPtnCnt) + SUM(PaymentInsCnt) + SUM(ExceptionCnt) + SUM(PtnPostingCnt) +  SUM(ColPostingCnt) As TotalContribution,      
0 As ADPContribution, 0 As OverAllADPContribution, 0 As iEOBContribution from #BatchList tb      
Inner join ARC_Athena..BatchLogInformation(nolock) bLog on bLog.BatchNum = tb.BatchNo Group by tb.BatchNo       
UNION ALL      
/*ADP Contribution*/      
Select t.BatchNo, 0 As TotalContribution, ADPContribution = SUM(t.Payment) -  SUM(t1.Payment), 0 As OverAllADPContribution, 0 As iEOBContribution from #temp t      
Inner join #temp1 t1 on t1.BatchNo = t.BatchNo Group by t.BatchNo      
UNION ALL      
Select  BatchNo, 0 As TotalContribution, ADPContribution = Payment, 0 As OverAllADPContribution, 0 As iEOBContribution from #temp Where BatchNo not in (Select BatchNo from #temp1)        
UNION ALL      
/*iEOB Contribution*/       
Select t.BatchNo, 0 As TotalContribution, 0 As ADPContribution, 0 As OverAllADPContribution, iEOBContribution = SUM(t.Payment) -  SUM(t1.Payment) from #iEOBtemp t      
Inner join #iEOBtemp1 t1 on t1.BatchNo = t.BatchNo Group by t.BatchNo      
UNION ALL      
Select  BatchNo, 0 As TotalContribution, 0 As ADPContribution, 0 As OverAllADPContribution, iEOBContribution = Payment from #iEOBtemp Where BatchNo not in (Select BatchNo from #iEOBtemp1)      
)b      
Inner join #BatchList c on c.BatchNo = b.BatchNo Where c.PgCount >=6    
Group by  c.ScanDate )e Group by  e.ScanDate   
  
UNION ALL  
  
/*______________________________________________________________________________________________________________________________________________________________*/  
Select e.ScanDate, 0 As TotalContribution, 0 As ADPContribution, SUM(OverAllADPContribution) As OverAllADPContribution,  
0 As iEOBContribution, 0 As TotalADPContribution, 0 AS '<6 Trans', 0 As '>=6 Trans', 0 As 'ADPContri.(%)',      
0 As 'iEOBContri.(%)'  
From (  
/*Scan Date wise*/    
SELECT CONVERT(varchar(15), c.ScanDate) As ScanDate  , 0 As TotalContribution, 0 As ADPContribution, SUM(OverAllADPContribution) AS OverAllADPContribution,     
0 As iEOBContribution, 0 AS '<6 Trans', 0 As '>=6 Trans' from (     
/*ADP Contribution*/  
Select  BatchNo, 0 As TotalContribution, 0 As ADPContribution, OverAllADPContribution = Payment, 0 As iEOBContribution from #OverAlltemp   
)b      
Inner join #OverAllBatchList c on c.BatchNo = b.BatchNo Where c.PgCount <6 Group by  c.ScanDate  
UNION ALL     
SELECT CONVERT(varchar(15), c.ScanDate) As ScanDate  , 0 As TotalContribution, 0 As ADPContribution, SUM(OverAllADPContribution) As OverAllADPContribution,        
SUM(iEOBContribution) As iEOBContribution, 0 As '<6 Trans', 0 As '>=6 Trans' from (      
/*ADP Contribution*/  
Select  BatchNo, 0 As TotalContribution, 0 As ADPContribution, OverAllADPContribution = Payment, 0 As iEOBContribution from #OverAlltemp  
)b      
Inner join #OverAllBatchList c on c.BatchNo = b.BatchNo Where c.PgCount >=6
Group by  c.ScanDate )e Group by  e.ScanDate   
/*_______________________________________________________________________________________________________________________________________________________________*/  
  
)z  Group by z.ScanDate   
    
Select e.ScanDate, e.PayerName, SUM(TotalContribution) As TotalContribution, SUM(ADPContribution) As ADPContribution,      
SUM(iEOBContribution) As iEOBContribution, TotalADPContribution = SUM(ADPContribution) + SUM(iEOBContribution),      
SUM([<6 Trans]) AS '<6 Trans', SUM([>=6 Trans]) As '>=6 Trans',    
'ADPContri.(%)' = ROUND(CAST(SUM(ADPContribution) As Float) / CAST(SUM(TotalContribution) As Float) * 100, 2),      
'iEOBContri.(%)' = ROUND(CAST(SUM(iEOBContribution) As Float) / CAST(SUM(TotalContribution) As Float) * 100, 2) from (    
/*Payerwise*/      
SELECT CONVERT(varchar(15), c.ScanDate) As ScanDate  ,c.PayerName , SUM(TotalContribution) As TotalContribution, SUM(ADPContribution) As ADPContribution,      
SUM(iEOBContribution) As iEOBContribution, '<6 Trans' = SUM(iEOBContribution) + SUM(ADPContribution), 0 As '>=6 Trans'  from (      
/*Total Contribution*/      
Select tb.BatchNo, SUM(CreatedPtnCnt) + SUM(PaymentInsCnt) + SUM(ExceptionCnt) + SUM(PtnPostingCnt) +  SUM(ColPostingCnt) As TotalContribution,      
0 As ADPContribution, 0 As iEOBContribution from #BatchList tb      
Inner join ARC_Athena..BatchLogInformation(nolock) bLog on bLog.BatchNum = tb.BatchNo        
Group by tb.BatchNo       
UNION ALL      
/*ADP Contribution*/      
Select t.BatchNo, 0 As TotalContribution, ADPContribution = SUM(t.Payment) -  SUM(t1.Payment), 0 As iEOBContribution from #temp t      
Inner join #temp1 t1 on t1.BatchNo = t.BatchNo      
Group by t.BatchNo      
UNION ALL      
Select  BatchNo, 0 As TotalContribution, ADPContribution = Payment, 0 As iEOBContribution from #temp Where BatchNo not in (Select BatchNo from #temp1)        
UNION ALL      
/*iEOB Contribution*/       
Select t.BatchNo, 0 As TotalContribution, 0 As ADPContribution, iEOBContribution = SUM(t.Payment) -  SUM(t1.Payment) from #iEOBtemp t      
Inner join #iEOBtemp1 t1 on t1.BatchNo = t.BatchNo      
Group by t.BatchNo      
UNION ALL      
Select  BatchNo, 0 As TotalContribution, 0 As ADPContribution, iEOBContribution = Payment from #iEOBtemp Where BatchNo not in (Select BatchNo from #iEOBtemp1)      
)b      
Inner join #BatchList c on c.BatchNo = b.BatchNo Where c.PgCount <6  Group by c.ScanDate, c.Payername    
    
UNION ALL    
SELECT CONVERT(varchar(15), c.ScanDate) As ScanDate  ,c.PayerName , SUM(TotalContribution) As TotalContribution, SUM(ADPContribution) As ADPContribution,      
SUM(iEOBContribution) As iEOBContribution, 0 As '<6 Trans', '>=6 Trans' = SUM(iEOBContribution) + SUM(ADPContribution)  from (      
/*Total Contribution*/      
Select tb.BatchNo, SUM(CreatedPtnCnt) + SUM(PaymentInsCnt) + SUM(ExceptionCnt) + SUM(PtnPostingCnt) +  SUM(ColPostingCnt) As TotalContribution,      
0 As ADPContribution, 0 As iEOBContribution from #BatchList tb      
Inner join ARC_Athena..BatchLogInformation(nolock) bLog on bLog.BatchNum = tb.BatchNo   Group by tb.BatchNo       
UNION ALL      
/*ADP Contribution*/      
Select t.BatchNo, 0 As TotalContribution, ADPContribution = SUM(t.Payment) -  SUM(t1.Payment), 0 As iEOBContribution from #temp t      
Inner join #temp1 t1 on t1.BatchNo = t.BatchNo  Group by t.BatchNo      
UNION ALL      
Select  BatchNo, 0 As TotalContribution, ADPContribution = Payment, 0 As iEOBContribution from #temp Where BatchNo not in (Select BatchNo from #temp1)        
UNION ALL      
/*iEOB Contribution*/       
Select t.BatchNo, 0 As TotalContribution, 0 As ADPContribution, iEOBContribution = SUM(t.Payment) -  SUM(t1.Payment) from #iEOBtemp t      
Inner join #iEOBtemp1 t1 on t1.BatchNo = t.BatchNo  Group by t.BatchNo      
UNION ALL      
Select  BatchNo, 0 As TotalContribution, 0 As ADPContribution, iEOBContribution = Payment from #iEOBtemp Where BatchNo not in (Select BatchNo from #iEOBtemp1)      
)b      
Inner join #BatchList c on c.BatchNo = b.BatchNo Where c.PgCount >=6  Group by c.ScanDate, c.Payername)e    
Group by e.ScanDate, e.Payername Order by e.ScanDate asc  
    
/*iEOBClaim Temp*/      
IF OBJECT_ID('Tempdb..#iEOBClaim') is not null drop table #iEOBClaim      
Select id, pymnt.batchnum As PymntBatch,insPackageID,pymnt.chargeID As PymntChargeID,checkNo,pymtAmt,coPayTrAmt,coInsTrAmt,dedTrAmt,      
otherTrAmt,globalTrAmt,contrAdjAmt,capitationAmt,managedCareAmt,otherAdjAmt,remiReCode,pageNo,InterestAmt,InsStatus,OCRStatus,      
ProcessID,CreatedDate,ModifiedBy,ModifiedDate,CreatedBy,CheckAmt,CheckDate,ErsMemberId,MemberIdPymnt,TypeOfInsurance,      
LocationId,isNewRemit,IsQCEntry, csd.ChargeID,csd.ClaimID As ServiceClaimID ,FromDOS,ToDOS,ProcedureCode,Modifier1      
Modifier2,Modifier3,AmountBilled,UnitsBilled,csd.Status As ServiceStatus,InsRespAmt,ParentChargeID, clm.* into #iEOBClaim      
from  #iEOBtemp t      
Inner join ARC_Athena..PaymentDetailMaster(nolock) pymnt on t.BatchNo = pymnt.BatchNum And pymnt.OCRStatus = 0      
inner join ARC_Athena..ClaimServiceDetailMaster(nolock) csd on pymnt.chargeID=csd.ChargeID      
inner join ARC_Athena..ClaimDetailMaster(nolock) clm on csd.ClaimID =clm.ClaimID      
      
/*iEOB Contribution Details*/      
Select distinct c.PayerName, SUM(a.Payment) As ValidTrans, SUM(Exception) As Exception, SUM(Creation) As CreationTrans, SUM(Claim) As ClaimCount       
from (       
Select Distinct t.PymntBatch  As BatchNo, COUNT(t.id) As Payment, 0 As Exception, 0 As Creation, 0 As Claim      
from  #iEOBClaim t Where t.Status=0       
Group by t.PymntBatch      
Union All      
Select b.BatchNum, 0 As Payment, CASE WHEN b.Total >= 0 THEN Total ELSE 0 END AS Exception, 0 As Creation, 0 As Claim from (      
Select Total = SUM(a.B) - SUM(a.T), a.BatchNum From (      
Select COUNT(ID) AS T, 0 As B, BatchNum from ARC_Athena..BatchException_ocr(nolock) o      
Inner join #iEOBtemp t on t.BatchNo = o.BatchNum Group by BatchNum UNION ALL       
Select 0 As T, COUNT(ID) As B, BatchNum from ARC_Athena..BatchException(nolock) b      
Inner join #iEOBtemp t on t.BatchNo = b.BatchNum Group by BatchNum)a group by a.BatchNum) b      
Union All      
Select Distinct  t.PymntBatch As BatchNo, 0 As Payment, 0 As Exception, COUNT(t.ClaimID) As Creation, 0 As Claim      
from #iEOBClaim t Where t.Status=1       
group by t.PymntBatch      
Union All      
Select Distinct t.PymntBatch As BatchNo, 0 As Payment, 0 As Exception, 0 As Creation, COUNT(distinct(t.ClaimID)) As Claim      
from #iEOBClaim t Where t.Status=1      
group by t.PymntBatch      
)a       
Inner join #BatchList c on c.BatchNo = a.BatchNo  Group by c.PayerName       
       
/*ADPClaim Temp*/      
IF OBJECT_ID('Tempdb..#ADPClaim') is not null drop table #ADPClaim      
Select id, pymnt.batchnum As PymntBatch,insPackageID,pymnt.chargeID As PymntChargeID,checkNo,pymtAmt,coPayTrAmt,coInsTrAmt,dedTrAmt,      
otherTrAmt,globalTrAmt,contrAdjAmt,capitationAmt,managedCareAmt,otherAdjAmt,remiReCode,pageNo,InterestAmt,InsStatus,OCRStatus,      
ProcessID,CreatedDate,ModifiedBy,ModifiedDate,CreatedBy,CheckAmt,CheckDate,ErsMemberId,MemberIdPymnt,TypeOfInsurance,      
LocationId,isNewRemit,IsQCEntry, csd.ChargeID,csd.ClaimID As ServiceClaimID ,FromDOS,ToDOS,ProcedureCode,Modifier1      
Modifier2,Modifier3,AmountBilled,UnitsBilled,csd.Status As ServiceStatus,InsRespAmt,ParentChargeID, clm.* into #ADPClaim      
from #temp t      
Inner join ARC_Athena..PaymentDetailMaster(nolock) pymnt on t.BatchNo = pymnt.BatchNum And pymnt.OCRStatus = 0      
inner join ARC_Athena..ClaimServiceDetailMaster(nolock) csd on pymnt.chargeID=csd.ChargeID      
inner join ARC_Athena..ClaimDetailMaster(nolock) clm on csd.ClaimID =clm.ClaimID      
      
/*ADP Contribution*/       
Select distinct c.PayerName, SUM(a.Payment) As ValidTrans, SUM(Exception) As Exception, SUM(Creation) As CreationTrans, SUM(Claim) As ClaimCount       
from (      
Select Distinct t.PymntBatch  As BatchNo, COUNT(t.id) As Payment, 0 As Exception, 0 As Creation, 0 As Claim      
from #ADPClaim t Where t.Status=0       
group by t.PymntBatch      
Union All      
Select b.BatchNum, 0 As Payment, CASE WHEN b.Total >= 0 THEN Total ELSE 0 END AS Exception, 0 As Creation, 0 As Claim from (      
Select Total = SUM(a.B) - SUM(a.T), a.BatchNum From (      
Select COUNT(ID) AS T, 0 As B, BatchNum from ARC_Athena..BatchException_ocr(nolock) o      
Inner join #temp t on t.BatchNo = o.BatchNum Group by BatchNum UNION ALL       
Select 0 As T, COUNT(ID) As B, BatchNum from ARC_Athena..BatchException(nolock) b      
Inner join #temp t on t.BatchNo = b.BatchNum Group by BatchNum)a group by a.BatchNum) b      
Union All      
Select Distinct t.PymntBatch As BatchNo, 0 As Payment, 0 As Exception, COUNT(t.ClaimID) As Creation, 0 As Claim      
from #ADPClaim t Where t.Status=1       
group by t.PymntBatch      
Union All      
Select Distinct t.PymntBatch As BatchNo, 0 As Payment, 0 As Exception, 0 As Creation, COUNT(distinct(t.ClaimID)) As Claim      
from #ADPClaim t Where t.Status=1       
group by t.PymntBatch      
)a       
Inner join #BatchList c on c.BatchNo = a.BatchNo  Group by c.PayerName      
      
IF OBJECT_ID('Tempdb..#ADPClaim') is not null drop table #ADPClaim      
IF OBJECT_ID('Tempdb..#iEOBClaim') is not null drop table #iEOBClaim      
IF OBJECT_ID('Tempdb..#iEOBtemp1') is not null drop table #iEOBtemp1      
IF OBJECT_ID('Tempdb..#iEOBtemp') is not null drop table #iEOBtemp      
IF OBJECT_ID('Tempdb..#temp1') is not null drop table #temp1      
IF OBJECT_ID('Tempdb..#temp') is not null drop table #temp      
IF OBJECT_ID('Tempdb..#BatchList') is not null drop table #BatchList      
      
END

GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOB_tContributionReport] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[iEOB_tContributionReport] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOB_tContributionReport] TO [DB_DMLSupport]
    AS [dbo];

