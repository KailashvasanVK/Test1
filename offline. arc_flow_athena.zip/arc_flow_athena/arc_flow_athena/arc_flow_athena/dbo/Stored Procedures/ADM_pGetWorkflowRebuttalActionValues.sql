﻿Create Procedure ADM_pGetWorkflowRebuttalActionValues
As 
Begin
Select StatusId,WorkflowStatusId,RebuttalAction from ADM_RebuttalActionValues where Status=1
End

GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pGetWorkflowRebuttalActionValues] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pGetWorkflowRebuttalActionValues] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pGetWorkflowRebuttalActionValues] TO [DB_DMLSupport]
    AS [dbo];

