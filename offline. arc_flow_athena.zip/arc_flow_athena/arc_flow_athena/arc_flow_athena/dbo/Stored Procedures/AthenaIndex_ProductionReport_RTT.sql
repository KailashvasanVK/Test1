﻿
CREATE PROC AthenaIndex_ProductionReport_RTT        
@gDate datetime=NULL        
as        
/*
This is Created for RT batches production
CreatedDate : May 20,2015

*/
BEGIN        
SELECT batchnum,userinfo,Case cstatus when 0 then 'InComplete' when 1 then 'Completed' End as Status FROM batchIndex_TrackBatches_RT  WHERE CONVERT(varchar,CompletedDate,103)=convert(varchar,@gDate,103)     
Union       
SELECT batchnum,userinfo,Case cstatus when 0 then 'InComplete' when 1 then 'Completed' End as Status FROM batchIndex_TrackBatches_RT WHERE CompletedDate is null    
END




    

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AthenaIndex_ProductionReport_RTT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AthenaIndex_ProductionReport_RTT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AthenaIndex_ProductionReport_RTT] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AthenaIndex_ProductionReport_RTT] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AthenaIndex_ProductionReport_RTT] TO [DB_DMLSupport]
    AS [dbo];

