﻿CREATE Procedure [dbo].[ADM_QaTargetTranInsert]    
(    
 @TargetId INT,    
 @Fromday INT,    
 @Today INT,    
 @TargetPercent INT,    
 @CreatedBy INT    
)    
As     
BEGIN    
	/*                        
		Purpose           : insert QaTarget details into ADM_QatargetTran table                    
		Created By        : Kathiravan                        
		Created Date      :15 may 2013       
		Impact to         : ProcessTarget.aspx                        
	*/     
    
	INSERT INTO ADM_QatargetTran(TargetId,Fromday,Today,TargetPercent,CreatedBy)    
	SELECT @TargetId,@Fromday,@Today,@TargetPercent,@CreatedBy       
END


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_QaTargetTranInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_QaTargetTranInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_QaTargetTranInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_QaTargetTranInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_QaTargetTranInsert] TO [DB_DMLSupport]
    AS [dbo];

