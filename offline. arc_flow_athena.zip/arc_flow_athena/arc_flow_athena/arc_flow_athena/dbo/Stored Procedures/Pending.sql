﻿
CREATE   Proc Pending (@Scandate varchar(20))    
as    
select count(batchno) as cnt ,    
case     
 when status=0 then 'Held'    
 when status=1 then 'Entry'     
     when status=3 then 'Index'    
     when status=99 then 'ChildMerge' else 'Issue'  end as 'Status'    
 from arc_flow_athena..trn_koff_tbatches  where scandate=@Scandate   and left(batchno,1)<>'m'  
--and left(batchno,1)='m'    
group by status   
  
select count(b.batchno) as 'Status99butnoentry' from mergebatchdetails a right outer join arc_flow_athena..trn_koff_tbatches  b on b.batchno=a.childbatchno   
where  b.status=99  and b.scandate=@Scandate and left(batchno,1)<>'m'  
and a.childbatchno is null  
  
select count(distinct b.batchno) as 'Mergebatchount' , count(a.childbatchno) as 'childcount' from mergebatchdetails a   
inner join arc_flow_athena..trn_koff_tbatches  b on b.batchno=a.parentbatchno   
where  b.status=1  and b.scandate=@Scandate and left(batchno,1)='m'   
  
select count(batchno) as'batchcnt',servicename , case     
 when a.status=0 then 'Held'    
 when a.status=1 then 'Entry'     
     when a.status=3 then 'Index'    
     when a.status=99 then 'Merge'  else 'Issue'   
       
     end as 'Status'   from trn_koff_tbatches a   
     inner join ADM_Service b on a.serviceid=b.serviceid where scandate=@Scandate   
group by servicename,a.status   
   
 select count(batchno) as 'Parentbatchcnt',scandate ,''as'waitinggforDemerge' from trn_koff_tbatches where status=20   
 group by scandate  
   
 select count(a.batchno), case when a.status=0 then 'Held'    
 when a.status=1 then 'Active'     
     when a.status=3 then 'Index'    
     when a.status=99 then 'Child-InMerge'  else 'Issue' end as 'Flowstatus' ,  
 case when ulstatus =1 then 'Uploaded' else 'YettoUpload' end as 'uploadstatus' from trn_koff_tbatches a   
 inner join arc_athena..batchmaster b on a.batchno=b.batchnum  
 where a.scandate=@Scandate and left(a.batchno,1)<>'m'  
 group by ulstatus,a.status  
   
   select distinct batchnum as 'NegativePageno' from arc_athena..paymentdetailmaster where pageno<0 
select distinct batchnum as 'NegativePageno'  from arc_athena..batchexception where pagenum<'0'

-- select *  from mergebatchdetails a right outer join arc_flow_athena..trn_koff_tbatches  b on b.batchno=a.childbatchno   
--where  b.status=99  and b.scandate='06/13/2015'  
--and a.childbatchno is null  
  
--select * from arc_flow_athena..trn_koff_tbatches where batchno in(  
--select *--distinct parentbatchno   
-- from arc_flow_athena..trn_koff_tbatches a inner join mergebatchdetails b on a.batchno=b.childbatchno where scandate='06/13/2015'   and left(batchno,1)<>'m'  
-- and a.status=99  
--)  
  
  
--select *--count(distinct b.batchno) as 'Mergebatchount' , count(a.childbatchno) as 'childcount'   
--from mergebatchdetails a   
--inner join arc_flow_athena..trn_koff_tbatches  b on b.batchno=a.parentbatchno   
--where  b.status=1  and b.scandate='06/13/2015' and left(batchno,1)='m'   
--select * from mergebatchdetails where childbatchno='8620319A1926'  
--select * from mergebatchdetails where parentbatchno='M11711A1926'  
--update  trn_koff_tbatches set status=99 where batchno='M11711A1926' and status=1  
--select * from trn_koff_tbatches where batchno in (  
--select childbatchno from mergebatchdetails where parentbatchno='M11711A1926')  
  
--M11711A1926  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Pending] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Pending] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Pending] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Pending] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Pending] TO [DB_DMLSupport]
    AS [dbo];

