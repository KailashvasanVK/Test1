﻿CREATE procedure iEOBMerge_pMergeBatch_posted (                 
 @scandate varchar(10)=null     
,@PayerName varchar(100)=null                       
,@Maxpagecount int              
,@serviceid varchar(10)=null          
 )                
as                                       
begin              
          
          
/*                                    
                                
Cretaed By     : Leela.T                                
Created Date   : 2017-01-31                                
Purpose        : Merge the batchtes based on Trans posted                            
Ticket/SCR ID  :                                
TL Verified By :              
          
*/          
                
Declare @BatchCount int,@ParentBatchid int ,@Rowcount int,                                      
@ParentBatchNo varchar(30),@Batchclientid int,@count int=0,@pgcount int,                                      
@Chk int=0,@StartPgNo int, @EndPgNo int,@Fname varchar(300)                                      
,@dollaramt money ,@BatchNo varchar(50), @qury varchar(Max) ,@Batchclinetid int               
     
          
          
if(object_id('tempdb.dbo.#BatchDetails')is not null)                                
drop table #BatchDetails                                
create table #BatchDetails                                                                        
(                                                                                                                                                                                                                   
BatchNo  varchar(50)                                                                                                                                                                                                                                           
)                                       
              
if(object_id('tempdb.dbo.#MergeBatchDetails')is not null)                                
drop table #MergeBatchDetails                      
create table #MergeBatchDetails                                                                  
(                                                                              
BatchNo   Varchar(15),                                                                                                                                                          
PageCount   int,                                                                      
Fname varchar(300) ,                                                                
status int,                                                
dollarAmt Money                                                                 
)           
          
          
set @qury='Insert into #BatchDetails                                                             
select distinct trn.BatchNo from trn_koff_tbatches(nolock) trn                   
inner join trn_koff_tbatchqueue (nolock) bq on trn.batchno=bq.batchno             
inner join Arc_Athena..Batchmaster (nolock) bat on bat.batchnum=trn.batchno             
inner join arc_athena..iEOB_tAutomationBatchQueue(nolock) tque on tque.batchno=bat.Batchnum  and tque.statusid in (20 ,5)
inner join adm_payerName (nolock) pyr on pyr.Payerid=trn.Payerid           
inner join Arc_Athena..Semiocr_paymentposting(nolock)  pymt on pymt.BatchNo = tque.BatchNo   and pymt.isposted=1           
left join mergebatchdetails (nolock) mrg on trn.batchno=mrg.childbatchno             
left join TRN_kOFF_tBatchResetLog Rp on RP.batchno= trn.batchno               
left join trn_koff_theldbatches (nolock) hld on trn.batchid=hld.batchid                    
where trn.status=88 and trn.posteddt is null  and  bq.assigned=0                             
and bq.statusid=0 and  trn.UploadDt is null and left(trn.batchno,1) not in (''M'',''S'') and mrg.childbatchno is null        
and bat.ULStatus is null and bat.uploaddate is null and PgCount between 2 and 20 and RP.batchno is null     
and (hld.Batchid is null or hld.ReleaseDate is not null)  and     
not exists (select payerid from  iEOBMerge_tExcludePayer exld  where exld.payerid= trn.payerid and exld.status=1 )  '                       
          
if @scandate <>''                                                             
Set @qury += ' and convert(varchar,trn.scandate,101) = '''+@scandate+''''                                                         
                
if @serviceid <>''                                         
Set @qury += ' and  trn.serviceid = cast('''+@serviceid+'''as int) '                         
         
if  @PayerName <>''                 
set @qury += ' and   pyr.PayerName= ''' +@PayerName+''''                   
          
exec (@qury)                      
                
set @qury=''            
Insert into iEOBMerge_tBatchStatus
Select Batchno,Statusid from  arc_athena..iEOB_tAutomationBatchQueue where BatchNo in (Select Batchno from  #BatchDetails)
     
update TRN_kOFF_tBatches set status=99 where BatchNo in (Select Batchno from  #BatchDetails)             
update arc_athena..iEOB_tAutomationBatchQueue set statusid=99 where BatchNo in (Select Batchno from  #BatchDetails)            
                 
          
insert into Athena_ChildBatchgeneration                                       
select MAX(Batchid)+1 from athena_childBatchGeneration                                      
                
select @Batchclientid=MAX(Batchid) from athena_childBatchGeneration                                      
                
INSERT INTO Athena_ParentBatchGeneration(ParentBatch) values (Convert(varchar(10),@Batchclientid) )                                                                              
set @ParentBatchid = SCOPE_IDENTITY()                                                                              
set @ParentBatchNo='S' + Convert(varchar(10),@ParentBatchid) + 'A1'                                                           
                  
delete from #MergeBatchDetails                                                                              
                
insert into #MergeBatchDetails(batchno , pagecount,Fname,status,dollarAmt)                                        
select distinct a.batchno,pgcount,'\\fs-ib'+SUBSTRING(Fname,CHARINDEX('\',Fname,3),LEN(Fname)),0,b.dollarAmt   
from trn_koff_tbatches a               
inner join Arc_Athena..batchMaster b on a.BatchNo=b.batchnum          
inner join arc_athena..iEOB_tAutomationBatchQueue(nolock) tque on tque.batchno=b.Batchnum  and tque.statusid=99      
inner join adm_payerName (nolock) pyr on pyr.Payerid=a.Payerid             
inner join Arc_Athena..Semiocr_paymentposting(nolock) pymt on pymt.BatchNo = tque.BatchNo   and pymt.isposted=1              
where a.BatchNo not in (select ChildBatchNo from mergebatchdetails)  and pyr.PayerName=@PayerName                
and convert(varchar,ScanDate,101)=convert(varchar,@scandate,101) and a.BatchNo in (Select Batchno from  #BatchDetails)                                           
and a.status=99  and ServiceId=cast(@serviceid as int) and         
not exists (select payerid from  iEOBMerge_tExcludePayer exld  where exld.payerid= a.payerid and exld.status=1 )             
  
Select @Rowcount=@@rowcount         
           
if(@Rowcount>1)      
          
declare @CurMergeBatch cursor                                                                                  
set  @CurMergeBatch  = cursor fast_forward for                                                                             
                         
select batchno, pagecount,Fname,dollaramt from #MergeBatchDetails where status=0                                                                               
                     
open  @CurMergeBatch            
                                                                                   
fetch next from @CurMergeBatch into                                                                             
@BatchNo,@PgCount ,@Fname,@dollaramt                                                                 
               
while(@@fetch_status<>-1)                           
Begin                                              
                
set @count=@count+@pgcount                                                                                              
                
if(@Count>=@Maxpagecount)                                        
begin                                                                          
Set @Count=0                                                                          
Set @Chk=0                                                                  
select @Count=SUM(pagecount),@BatchCount=Count(Batchno) from #MergeBatchDetails where status=0                                                         
                                                    
if(@BatchCount<2 or @Count<4)                         
begin                                                            
                
update TRN_kOFF_tBatches set status=88 where BatchNo in(                 
select BatchNo from #MergeBatchDetails where status=0)                                                          
update que set que.StatusId=bs.Statusid  
From  ARC_Athena..iEOB_tAutomationBatchQueue que 
inner join #MergeBatchDetails Mrg    on Mrg.Batchno=que.Batchno
inner join iEOBMerge_tBatchStatus bs on Mrg.Batchno=bs.Batchno  where Mrg.status=0           
Goto NextSubClient                        
                
End                       
          
set @count=0                                                          
set @count=@count+@pgcount                                                                              
             
                
insert into Athena_ChildBatchgeneration                                       
select MAX(Batchid)+1 from athena_childBatchGeneration                                      
                
select @Batchclientid=MAX(Batchid) from athena_childBatchGeneration                                      
                
INSERT INTO Athena_ParentBatchGeneration(ParentBatch) values (Convert(varchar(10),@Batchclientid) )                                                                              
set @ParentBatchid = SCOPE_IDENTITY()                                                                              
set @ParentBatchNo='S' + Convert(varchar(10),@ParentBatchid) + 'A1'                                                                             
if (@Chk=0)                                                                          
begin                                                                          
Set @Chk=1                                                                          
set @StartPgNo=1                                                                          
set @EndPgNo=@PgCount    
  
End                                                                          
                
else                                                                          
begin                                            
set @StartPgNo=@EndPgNo+1                                                                          
set @EndPgNo= @startpgno + (@PgCount-1)  
                                                                         
End                                                                         
End                                                                          
                
else                                                                         
             
begin                                       
                
if (@Chk=0)            
begin                                                                          
Set @Chk=1                                                           
set @StartPgNo=1                                                                          
set @EndPgNo=@PgCount                                                                                        
End                                      
                
else               
                
begin                                                                         
set @StartPgNo=@EndPgNo+1             
set @EndPgNo= @startpgno + (@PgCount-1)                                                                          
End                                                                          
                
end                                                                      
   
                
INSERT INTO MergeBatchDetails(ParentBatchNo,childBatchNo,StartPgNo,EndpgNo,TotalPages,status,Fname,dollaramt)                                                                          
values(@ParentBatchNo,@BatchNo,@StartPgNo,@EndPgNo,@PgCount,13,'\\fs-ib'+SUBSTRING(@Fname,CHARINDEX('\',@Fname,3),LEN(@Fname)),@dollaramt)                                                                             
update #MergeBatchDetails set status=1 where BatchNo=@BatchNo          
             
insert into ARC_Athena..iEOB_tAutomationBatchFlow                                                           
select BatchId,BatchProcessId,99,'Childbatch',1111,getdate() from  arc_athena..iEOB_tAutomationBatchQueue where batchno=@BatchNo             
                
fetch next from @CurMergeBatch  into                                                                             
@BatchNo,@PgCount,@Fname,@dollaramt                                       
                   
End                           
                
NextSubClient:                                        
                  
close @CurMergeBatch                                        
deallocate @CurMergeBatch                                                              
                
End 

GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOBMerge_pMergeBatch_posted] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[iEOBMerge_pMergeBatch_posted] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOBMerge_pMergeBatch_posted] TO [DB_DMLSupport]
    AS [dbo];

