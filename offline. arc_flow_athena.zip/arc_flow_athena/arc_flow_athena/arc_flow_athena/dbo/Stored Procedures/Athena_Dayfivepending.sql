﻿CREATE Proc Athena_Dayfivepending  (@date date)                 
as                   
 begin 
 /*            
  
Cretaed By     : Leela.T        
Created Date   : 2016-07-20          
Purpose        : Day 5 Pending Batch Count Details        
Ticket/SCR ID  : <>        
TL Verified By : <Ramki>  */
select 'IndexPending'  as  'status',count(batchid) as 'cnt'  from trn_koff_tbatches (nolock) 
where posteddt is null and serviceid<>363 and status=3 and scandate=@date                   
union                
select 'EntryPending' as  'status' ,count(batchid) as 'Count' from trn_koff_tbatches (nolock)
where posteddt is null and serviceid<>363 and status in (1,99) and scandate=@date and LEFT(batchno,1) not in('M','S')                                    
union                                       
select 'Merge Pending' as 'status' ,COUNT(batchno) as 'Count' from trn_koff_tbatches (nolock) a                     
inner join arc_athena..batchmaster(nolock) b on a.batchno=b.batchnum                       
where posteddt is null  and status=1 and LEFT(batchno,1) ='M'and scandate=@date                             
union                 
select 'SubclientMerge Pending' as 'status',COUNT(batchno) as 'count' from trn_koff_tbatches (nolock) a                     
inner join arc_athena..batchmaster(nolock) b on a.batchno=b.batchnum  
inner join serviceDets c on a.ServiceId=c.Parentserviceid
where posteddt is null  and a.status=1 and LEFT(batchno,1) ='S'   and serviceName like '%SubClient%'   
and scandate=@date   
union
 select 'EnterPriseMerge Pending' as 'status',COUNT(batchno) as 'count' from trn_koff_tbatches (nolock) a                     
inner join arc_athena..batchmaster(nolock) b on a.batchno=b.batchnum  
inner join serviceDets c on a.ServiceId=c.Parentserviceid
where posteddt is null  and a.status=1 and LEFT(batchno,1) ='S'   and serviceName like '%Enterprise%'   
and scandate=@date                               
union                      
select 'QCPending'  as  'status', count(batchid) as 'count'  from trn_koff_tbatches (nolock)
where posteddt is not null and UploadDt is null and serviceid<>363 and status=1                    
and scandate=@date and LEFT(batchno,1) not in('M','S')                            
union  
select 'Merge QC'  as  'status', count(batchid) as 'count'  from trn_koff_tbatches (nolock)
where posteddt is not null and UploadDt is null and serviceid<>363 and status=1                    
and scandate=@date and LEFT(batchno,1)='M'                            
union             
select 'SubclientMerge QC'  as  'status', count(batchid) as 'count'  from trn_koff_tbatches a (nolock)
inner join serviceDets c on a.ServiceId=c.Parentserviceid
where posteddt is not null and UploadDt is null and serviceid<>363 and a.status=1                    
and scandate=@date and LEFT(batchno,1)='S'  and serviceName like '%SubClient%'   
union             
select 'Enterprise Merge QC'  as  'status', count(batchid) as 'count'  from trn_koff_tbatches a (nolock)
inner join serviceDets c on a.ServiceId=c.Parentserviceid
where posteddt is not null and UploadDt is null and serviceid<>363 and a.status=1                    
and scandate=@date and LEFT(batchno,1)='S'  and serviceName like '%Enterprise%'                
union             
select 'UploadPending'  as  'status' ,count(batchid) as 'Count' from trn_koff_tbatches (nolock) a                     
inner join arc_athena..batchmaster(nolock) b on a.batchno=b.batchnum   where                       
 UploadDt is not null and ulstatus is null and serviceid<>363 and status=1                    
and scandate=@date                   
          
 End         
                    

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Dayfivepending] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Dayfivepending] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Dayfivepending] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Dayfivepending] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Dayfivepending] TO [DB_DMLSupport]
    AS [dbo];

