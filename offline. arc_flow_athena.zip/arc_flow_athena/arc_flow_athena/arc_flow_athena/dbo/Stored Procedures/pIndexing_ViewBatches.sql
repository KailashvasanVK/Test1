﻿CREATE PROCEDURE pIndexing_ViewBatches              
(              
@UserInfo varchar(50)              
)     
with recompile           
As   
/*    
Created by : Gobi  
Created dt : 2017-02-10    
Purpose : Batch allocated in indexing  
  
Implemented by: Ganesh Tanneru  
Implemented date:14-02-2017  
*/                
Begin               
              
SELECT  distinct BatchID, BatchNo, tb.ScanDate AS ScanDate, b.BATCHTOTAL As DollarAmount,ISNULL(Adm.PayerId , 0) As InsuranceName,                        
'' AS TaxID, '' AS NPID, '' AS PayeeNo,  FName,'' As CheckDate, 0 As Complete,               
SubClient = SUBSTRING(tb.BatchNo,CHARINDEX('A',tb.BatchNo)+1,(LEN(tb.BatchNo)-CHARINDEX('A',tb.BatchNo))+1),       
CASE WHEN tb.pgCount in (3,2) Then '2' ELSE  '' End As Page, '' As PageNo       
from dbo.POFF_Batchindex trb                
Inner join TRN_kOFF_tBatches (nolock) tb on tb.BatchNo = trb.batchnum                          
Left join  Arc_Athena..CBO_Payerinfo (nolock) cb on cb.Batch = tb.BatchNo                              
Left join  ADM_PayerName Adm on Adm.PayerName = cb.PAYMENTBATCHROUTE                              
Left join  ARC_Athena..BatchTotal b on b.batchNum = tb.BatchNo                              
Where  trb.userinfo = @UserInfo--'gobinath.m'            
              
END

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[pIndexing_ViewBatches] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexing_ViewBatches] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexing_ViewBatches] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[pIndexing_ViewBatches] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexing_ViewBatches] TO [DB_DMLSupport]
    AS [dbo];

