﻿CREATE Procedure  CUS_kPacific_pAutoBatchImport
(
 @pFileName varchar(200) = ''
,@pPageCount int = 0
,@pCmpKey varchar(5)=''
,@pScanDate date=''
,@pBatchNo varchar(50)=''          
)
As
Begin

	--declare @batchnoWithouClint varchar(75) = substring(@pBatchNo,CHARINDEX('_',@pBatchNo)+1,100)
	Declare @Subclient varchar(15)='';
	declare @FileType varchar(1) ='';
	Declare @FilePath varchar(250)='';
	
    set @Subclient =(select LEFT(@pBatchNo, 4))	
	Declare @ServiceId int = 0
	Declare @ClientId int = 0
	set @ClientId = (select ClientId from ADM_Client where ClientName =@Subclient and CustomerId=10)
	
	if(select CHARINDEX('CHG',@pBatchNo))> 0
       begin
            set @ServiceId = 1          
        End
    else if(select CHARINDEX('CORR',@pBatchNo))> 0  
         begin
            set @ServiceId = 173       
         End
    else
      begin 
            set @ServiceId = 5   
      End
         
  if(@ClientId <>0 and @ServiceId <>0)
   begin       
       set @FilePath =(select 'PACIFIC\TP\'+REPLACE(convert(varchar,GETDATE(),101),'/','')+'\'+@pBatchNo+'.PDF')
	   Exec TRN_pBatchesInsert @CmpKey ='PACIF',@ScanDate=@pScanDate,@BatchNo=@pBatchNo,@FileName =@pFileName,@ClientId =@ClientId,@ServiceId=@ServiceId
							   ,@BatchType=1,@CreatedBy=1777,@PageCount=@pPageCount,@BatchFullName=@FilePath
    End
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kPacific_pAutoBatchImport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kPacific_pAutoBatchImport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kPacific_pAutoBatchImport] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kPacific_pAutoBatchImport] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kPacific_pAutoBatchImport] TO [DB_DMLSupport]
    AS [dbo];

