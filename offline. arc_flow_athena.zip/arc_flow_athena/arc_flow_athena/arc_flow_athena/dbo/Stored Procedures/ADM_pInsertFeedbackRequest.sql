﻿CREATE Procedure  ADM_pInsertFeedbackRequest
(
	@BatchNo varchar(50),
	@ServiceId int,
	@ClientId int,
	@PageNo int,
	@Ticket varchar(50),
	@ClinicCode varchar(50),
	@AHSIncorrectNote varchar(800),
	@IncorrectActionTaken varchar(800),
	@ActiontobeTaken varchar(800),
	@ClientComments varchar(800),
	@AHSPMSUser varchar(75),
	@DateofBilling date=null,
	@CreatedBy int,
	@CustomerId int
)
as
BEGIN
     insert into ADM_FeedbackRequest(BatchNo,ServiceId,ClientId,PageNo,Ticket,ClinicCode,AHSIncorrectNote,IncorrectActionTaken,ActiontobeTaken,ClientComments,AHSPMSUser,DateofBilling,CreatedBy,CustomerId)
     select @BatchNo,@ServiceId,@ClientId,@PageNo,@Ticket,@ClinicCode,@AHSIncorrectNote,@IncorrectActionTaken,@ActiontobeTaken,@ClientComments,@AHSPMSUser,@DateofBilling,@CreatedBy,@CustomerId
END 


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pInsertFeedbackRequest] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pInsertFeedbackRequest] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pInsertFeedbackRequest] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pInsertFeedbackRequest] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pInsertFeedbackRequest] TO [DB_DMLSupport]
    AS [dbo];

