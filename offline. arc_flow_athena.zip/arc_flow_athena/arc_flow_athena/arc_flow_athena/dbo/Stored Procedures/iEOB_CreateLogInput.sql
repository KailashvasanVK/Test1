﻿Create Proc iEOB_CreateLogInput 
@Batchno varchar(30)  
/*  
CreatedBy:Noor  
CreatedDate : Nov 23,2017  
Purpose : Create Log Detail  
*/  
as  
Begin  
IF(SELECT count(id) FROM iEOB_PdfOCRTracker(nolock) WHERE Batchno=@Batchno)=0
BEGIN
INSERT INTO iEOB_PdfOCRTracker(Batchno,Inputs,Outputs,InputsDate) values(@Batchno,1,0,getdate())
END
ELSE
SELECT '' as Available where 1<>1
End  

GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOB_CreateLogInput] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[iEOB_CreateLogInput] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOB_CreateLogInput] TO [DB_DMLSupport]
    AS [dbo];

