﻿CREATE Proc [dbo].[Athena_CheckscandateAvailMergebatch]            
 as                    
                
/*                      
                  
Cretaed By     : Leela.T                  
Created Date   :  2017-05-23                   
Purpose        : Check the scandate wise Available Batches for Merge                  
Ticket/SCR ID  : <>                  
TL Verified By : <>                
  
Modified By     : Leela.T                  
Modified Date   :  2019-09-24                   
Purpose         : added invoice table for echoOCR Batches             
              
Implemented by : Narayana                
Implemented On : 25-May-2017                 
*/                   
begin            
Select Scandate, Count(BatchCount) As BatchCount ,sum(PageCount) As PageCount  from (                                                
select distinct a.Scandate, a.batchno As BatchCount,PgCount as PageCount from trn_koff_tbatches(nolock) a
inner join ARC_Athena..batchMaster(nolock) b on a.BatchNo=b.batchnum                                               
Inner join TRN_kOFF_tBatchQueue(nolock) bq on a.batchno=bq.batchno                       
Inner join ADM_Client(nolock) adm on adm.ClientId=a.ClientId and CustomerId=25 and adm.status=1
inner join Merge_tStatusofMerged mer on mer.childserviceid=a.serviceid and mergestatus=0
left join arc_athena..Invoice_tAutomationBatchQueue(Nolock) tAbq on  tAbq.BatchNo=b.batchnum  and tAbq.StatusId=2 
left join arc_athena..Entry_InvoiceAutomation(Nolock) inv on inv.BatchNo=b.batchnum          
left join mergebatchdetails (nolock) mrg on mrg.childbatchno=a.batchno     
left join trn_koff_theldbatches (nolock) hld on a.batchid=hld.batchid             
where  mrg.childbatchno is null and a.status=1 and bq.assigned=0 and bq.statusid=0    
and a.serviceid not in(418,452) and (hld.Batchid is null or hld.ReleaseDate is not null)        
and a.postedDt is null and a.UploadDt is null and b.ULStatus is null and PgCount > 1          
and  PgCount <=9  and convert(date,a.scandate) between  convert(date,getdate()-7) and   convert(date,getdate())  
)a group by Scandate

End



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_CheckscandateAvailMergebatch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_CheckscandateAvailMergebatch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_CheckscandateAvailMergebatch] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_CheckscandateAvailMergebatch] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_CheckscandateAvailMergebatch] TO [DB_DMLSupport]
    AS [dbo];

