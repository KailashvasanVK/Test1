﻿Create Proc ARC_AUTO_CORRESPONDENCE_LETTER
(@BatchNo varchar(max))
/*

Sample : Exec ARC_AUTO_CORRESPONDENCE_LETTER '160165A448,160162A448,160167A448'
*/
as 
Begin
SELECT @BATCHNO=REPLACE(REPLACE(REPLACE(@BATCHNO,CHAR(9),''),CHAR(10),''),CHAR(13),'') 

create table #temp
(
BatchNo Varchar(100)
)

insert into   #temp (BatchNo) 
Select Batchno  from trn_koff_tbatches  where  status =3 and  
BatchNo in 
(select items from dbo.fnSplitString(@BatchNo,','))

select count(BatchNo) as NoofBatches from #temp

update trn_koff_tbatches set serviceid=411,payerid=807,status=1 where status =3 and batchno in 
(select BatchNo from #temp)

 update trn_koff_tbatchqueue set serviceid=411 where batchno in 
(select BatchNo from #temp)

Update ARC_ATHENA.dbo.batchmaster set dollaramt =0 where batchnum in 
(select BatchNo from #temp)
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_AUTO_CORRESPONDENCE_LETTER] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_AUTO_CORRESPONDENCE_LETTER] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_AUTO_CORRESPONDENCE_LETTER] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_AUTO_CORRESPONDENCE_LETTER] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_AUTO_CORRESPONDENCE_LETTER] TO [DB_DMLSupport]
    AS [dbo];

