﻿CREATE Procedure TRN_kOFF_pManualAllocationEntryReleaseSearch    
(    
 @UserId int=0,    
 @AssignedTo int =0,    
 @Cmpkey varchar(5)='',    
 @Action varchar(50)='',    
 @BatchIDs varchar(max)='',    
 @CreatedBy int=0,    
 @ServiceId int =0,    
 @ClientId int =0,    
 @Batchno varchar(50),      
 @SearchStr varchar(100) = '',      
 @SearchPattern varchar(4) = '=' /** = or % **/      
 ,@pPageSize int = 0      
 ,@pPageNumber int = 1     
 ,@DateMode varchar(1)=''    
 ,@FromDate  varchar(20)=''      
 ,@payerID  int = 0      
 ,@ToDate  varchar(20)='',
 @LocationId int=1       --added by mallikarjun.nam     
)    
As    
Begin 
Set Transaction isolation level read uncommitted;   
    
 /*    
  Createdby: Kathirvan.kand    
  CreatedDt: 01/10/2014    
 */     
 /*Declare @UserId int=0,    
 @AssignedTo int =0,    
 @Cmpkey varchar(5)='',    
 @Action varchar(50)='',    
 @BatchIDs varchar(max)='',    
 @CreatedBy int=0,    
 @ServiceId int =0,    
 @ClientId int =0,    
 @Batchno varchar(50),      
 @SearchStr varchar(100) = '',      
 @SearchPattern varchar(4) = '=' /** = or % **/      
 ,@pPageSize int = 0      
 ,@pPageNumber int = 1     
 ,@DateMode varchar(1)='D'    
 ,@FromDate  varchar(20)='2015-02-28'      
 ,@payerID  int = 0      
 ,@ToDate  varchar(20)='2015-02-28' */    
      
      
      
 declare @FromScanDate as datetime,    
 @ToScanDate as datetime,    
 @FromDownloadDate as datetime,    
 @ToDownloadDate as datetime    
      
 if(@DateMode = 'D')    
 begin    
  set @FromScanDate  = convert(date,'1900-01-01')    
  set @ToScanDate  = DateAdd(day, 1, GETDATE())    
  set @FromDownloadDate = @FromDate    
  set @ToDownloadDate =@ToDate    
 END    
 ELSE IF (@DateMode = 'S')    
 Begin    
  set @FromScanDate  = @FromDate    
  set @ToScanDate  = @ToDate    
  set @FromDownloadDate =  convert(date,'1900-01-01')    
  set @ToDownloadDate = DateAdd(day, 1, GETDATE())    
 END    
      
 if OBJECT_ID('tempdb..#UserLocation') is not null drop table #UserLocation
 Create table #UserLocation( locationid int,LocationName varchar(50))
 insert into  #UserLocation(locationId,LocationName)
 exec ADM_GetUserLocation @userid,@LocationId    
      
 if OBJECT_ID('tempdb..#AssignedBatches') is not null drop table #AssignedBatches         
 create Table #AssignedBatches(chkAssignedbatches varchar(max),BatchNo varchar(50),Service varchar(50),Client varchar(50),[Scan Date] varchar(50),[Download date] varchar(20)    
 ,Pages int,PageFrom int,PageTo int ,Status varchar(75),AssignedTo varchar(50),PayerName varchar(50),RowId int identity,Location varchar(100))    
    
 if OBJECT_ID('tempdb..#AssignedBatchesResult') is not null drop table #AssignedBatchesResult    
 create Table #AssignedBatchesResult(chkAssignedbatches varchar(max),BatchNo varchar(50),Service varchar(50),Client varchar(50),[Scan Date] varchar(50),[Download date] varchar(20)    
 ,Pages int,PageFrom int,PageTo int ,Status varchar(75),AssignedTo varchar(50),PayerName varchar(50),[RowId~Hide] int,Location varchar(100))    
    
 insert into #AssignedBatches(chkAssignedbatches,BatchNo,Service,Client,[Scan Date],[Download date],Pages,PageFrom,PageTo ,Status,AssignedTo,PayerName,Location)    
 select '<input type="checkbox"  class="chkAssignedbatches" id='+cast(que.BatchProcessId as varchar)+' />' as chkAssignedbatches     
 ,bat.BatchNo,ser.ServiceName as Service,cli.ClientAcmName as Client ,bat.ScanDate as [Scan Date],bat.CreatedDt as [Download date],    
 bat.PgCount,que.PageFrom,que.PageTo ,dbo.TRN_kOFF_fnGetBatchCurrentStatus(bat.BatchId) as Status,ui.NT_USERNAME as AssignedTo,    
 (select PayerName from ADM_PayerName_View where PayerId = bat.PayerId) as PayerName  
 ,loc.LocationName as Location
 from  TRN_kOFF_tManualAllocation mbat     
 inner join TRN_kOFF_tBatchQueue que  on que.BatchProcessId =  mbat.BatchProcessId and que.StatusId in (0,2,16)
 inner join TRN_kOFF_tBatches bat  on bat.BatchId  = que.BatchId and bat.status=1 and bat.PostedDt is null     
 inner join #UserLocation as loc on isnull(bat.LocationId,1)=loc.LocationId -- code added by mallikarjun
 AND  DATEADD(day, DATEDIFF(day, 0, bat.CreatedDt), 0) between  @FromDownloadDate  and @ToDownloadDate      
 AND  DATEADD(day, DATEDIFF(day, 0, ScanDate), 0)  between  @FromScanDate and  @ToScanDate     
        
 and bat.ClientId = case when ISNULL(@ClientId,0) <> 0 then @ClientId else bat.ClientId end    
 and bat.ServiceId =  case when ISNULL(@ServiceId,0) <> 0 then @ServiceId else bat.ServiceId  end    
 and bat.BatchNo  = case when ISNULL(@Batchno,'') <> ''  then  @Batchno else bat.BatchNo end    
 inner join ADM_Service ser on ser.ServiceId = bat.ServiceId and ser.Status=1    
 inner join ADM_Client cli on cli.ClientId  = bat.ClientId and cli.Status=1    
 inner join  ARC_Rec_Athena..ARC_REC_USER_INFO ui  on ui.USERID =  mbat.AssignedTo    
 where mbat.AllocationMode='E' and mbat.Status=1     
 and mbat.AssignedTo = case when ISNULL(@AssignedTo,0) <> 0 then @AssignedTo else mbat.AssignedTo end    
 and ISNULL(bat.PayerId, 0 ) = (case  when ISNULL(@payerID, 0 ) <> 0 then @payerID else  ISNULL(bat.PayerId, 0 ) end)    
 --and bat.PgCount = case when ISNULL(@PageNo,0) <> 0 then @PageNo else bat.PgCount end    
 order by  bat.CreatedDt     
    
 Insert into #AssignedBatchesResult    
 Exec FilterTable     
 @DbName = 'tempdb'    
 ,@TblName = '#AssignedBatches'     
 ,@SearchStr =  @SearchStr    
 ,@SearchPattern = @SearchPattern    
 ,@OrderStr = ''    
    
 DECLARE @FirstId int, @FirstRow int      
 SET @FirstRow =((@pPageNumber - 1) *(@pPageSize)+1)    
 SET ROWCOUNT @FirstRow      
 SELECT   @FirstId = [RowId~Hide]       
 FROM    #AssignedBatchesResult    
 ORDER BY [RowId~Hide]    
 SET ROWCOUNT @pPageSize     
    
 SELECT *    
 FROM     #AssignedBatchesResult      
 WHERE    [RowId~Hide] >= @FirstId      
 ORDER BY [RowId~Hide]    
 SET ROWCOUNT 0      
 Select Count(*) RowsCount from #AssignedBatches    
End 

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pManualAllocationEntryReleaseSearch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pManualAllocationEntryReleaseSearch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pManualAllocationEntryReleaseSearch] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pManualAllocationEntryReleaseSearch] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pManualAllocationEntryReleaseSearch] TO [DB_DMLSupport]
    AS [dbo];

