﻿CREATE proc Athena_MergeBatches @scandate varchar(10)=null ,@Minpagecount varchar(5)=null,@Maxpagecount int,@ClientName varchar(10)= Null,@serviceid varchar(10)=null                                                     
as                        
begin                        
Declare @qury nvarchar(Max),                                                       
@toprec varchar(15)=20,                
@LoopCount                               
int,                                                      
@BatchNo Varchar(15), @PgCount int,                                                      
@Client varchar(10),@ParentBatchid int,                                                      
@StartPgNo int, @EndPgNo int,  @Chk int,                                                    
@ParentBatchNo Varchar(20),@SubClient varchar(8),                                                      
@Count int,@Mergequry nvarchar(1000),@Fname varchar(300),                                  
@BatchCount int                                  
              
/*Declare @scandate varchar(10),        
@Minpagecount varchar(5),        
@Maxpagecount   int,              
@ClientName  Varchar(20),        
@serviceid  varchar(5)             
Set @scandate='03/07/2015'        
set @Minpagecount=10        
set @Maxpagecount=100        
Set @ClientName='9697'          
set @serviceid=355    */   



/*      
  
Cretaed By     : Leela.T  
Created Date   : 2015-03-09     
Purpose        : Batches are Logically Merged   
Ticket/SCR ID  : <>  
TL Verified By : <Ramki>  


Mod ID          :001
Modified by     : Leela.T
Modified date   :2016-10-25  
Request Type    : Restrict Single Page Batch for Merge
TL Verified By  : Ramakrishnan.G  
  
  
  
Implemented by : Udhayaganesh  
Implemented On : 19-04-2014  
  
Reviewd by     : Udhayaganesh  
Implemented On : 19-04-2014  
  
*/                                          
                                                      
create table #SubClientDetails                                          
 (                                                       
Id  int IDENTITY (1, 1) NOT NULL,                 
SubClient     varchar(10),                                                                                                                            
BatchCount    int,                                                                                                                                  
PageCount   int                                                                                                    
                                                                                                                                 
)                                                                                                                                  
                                                      
create table #MergeBatchDetails                                          
 (                 
SNo int IDENTITY (1, 1) NOT NULL,                                                           
BatchNo   Varchar(15),                                                                                                                                  
PageNo  int,                                              
SubClient varchar(10)                                        
)                                                
                                             
create table #MergeSubclients                                          
(                                            
ID  int IDENTITY (1, 1) NOT NULL,                                            
Batchcount int,                                            
SubClient varchar(10),                                
PgCount int                                          
)                                    
                                  
--create table #ProcessBatchCount                                                            
--(                                  
--Value int                                  
--)                                  
                                                      
 /*                                        
drop table #MergeBatchDetails                                                    
drop table #SubClientDetails                                            
drop table #mergesubclients                                            
  */                                  
                                       
begin                  
                
set @qury='insert into #MergeSubclients(batchcount,Subclient,pgcount)                                  
select Count(a.total) as total,Client,sum(pgcount)  from(                                    
SELECT a.BatchNo,PgCount,                                    
SUBSTRING(a.BatchNo,CHARINDEX(''A'',a.BatchNo)+1,(LEN(a.BatchNo)-CHARINDEX(''A'',a.BatchNo))+1) As Client,                                    
ROW_NUMBER() OVER (PARTITION BY SUBSTRING(a.BatchNo,CHARINDEX(''A'',a.BatchNo)+1,(LEN(a.BatchNo)-CHARINDEX(''A'',a.BatchNo))+1) ORDER BY a.BatchNo DESC) AS total                                    
FROM TRN_kOFF_tBatches a             
Inner join TRN_kOFF_tBatchQueue bq on a.batchno=bq.batchno            
inner join ARC_Athena..batchMaster b on a.batchno=b.batchnum             
Where status=1 and bq.assigned=0 and bq.statusid=0 and a.ClientID not in (select Clientid from ExcludeFormerge) and a.PgCount <>1 '                
                       
set @qury+=' and a.PgCount <= cast('''+@Minpagecount+'''as int)'                             
                          
if @scandate <>''                          
             
Set @qury += ' and convert(varchar,a.scandate,101) = '''+@scandate+''''                           
                           
if @ClientName <> ''                          
                          
Set @qury += ' and SUBSTRING(a.BatchNo,CHARINDEX(''A'',a.BatchNo)+1,(LEN(a.BatchNo)-CHARINDEX(''A'',a.BatchNo))+1)='''+@ClientName+''''                           
                          
if @serviceid <>''                          
                          
Set @qury += ' and a.serviceid = cast('''+@serviceid+'''as int)'                                  
                         
set @qury +=  'and  a.UploadDt is  null  and b.ULStatus is null )a  group by a.Client having sum(a.pgcount)>'+ CAST(@Maxpagecount as varchar(10))                        
                        
exec(@qury)                          
                          
End                           
  set @qury=''                                      
Select @LoopCount=COUNT(*) from #MergeSubclients                           
                                          
while (@LoopCount >0)                                    
begin                                    
select @BatchCount=count(a.batchno) from TRN_kOFF_tBatches  a             
Inner join TRN_kOFF_tBatchQueue bq on a.batchno=bq.batchno where a.PgCount<=@Minpagecount and                                   
ScanDate=@scandate and a.ServiceId=@serviceid and a.status=1 and  bq.assigned=0 and bq.statusid=0  and                          
SUBSTRING(a.BatchNo,CHARINDEX('A',a.BatchNo)+1,(LEN(a.BatchNo)-CHARINDEX('A',a.BatchNo))+1)=(select subclient from #MergeSubclients where ID=@LoopCount)                            
                      
 select @BatchCount=@BatchCount- ROUND(((@batchcount*10)/100),0)                 
                 
set @qury='update TRN_kOFF_tBatches set  status=99 where BatchNo in(                                 
select top '+ CONVERT(VARCHAR,@BatchCount) +' a.batchno from TRN_kOFF_tBatches  a             
Inner join TRN_kOFF_tBatchQueue bq on a.batchno=bq.batchno           
where a.status=1 and bq.assigned=0 and bq.statusid=0 and a.ClientID not in (select Clientid from ExcludeFormerge) and  a.PgCount <>1 '                          
set @qury+='and a.PgCount <= cast('''+@Minpagecount+'''as int)'                             
        
If @scandate <>''                          
Set @qury += ' and convert(varchar,a.scandate,101) = '''+@scandate+''''                           
        
If @serviceid <>''                          
Set @qury += ' and a.serviceid = cast('''+@serviceid+'''as int)'                             
Set @qury += ' and SUBSTRING(a.BatchNo,CHARINDEX(''A'',a.BatchNo)+1,(LEN(a.BatchNo)-CHARINDEX(''A'',a.BatchNo))+1)=(select subclient from #MergeSubclients where ID='+ CAST(@LoopCount as varchar(10)) + ')'                          
                           
Set @qury+=' )'                          
Exec(@qury)                          
    
 insert into #SubClientDetails(SubClient,BatchCount,PageCount)                
 SELECT SUBSTRING(BatchNo,CHARINDEX('A',BatchNo)+1,(LEN(BatchNo)-CHARINDEX('A',BatchNo))+1) as subclient,COUNT(batchno) as Batchcount,SUM(pgcount) as 'page count'                
 from  trn_koff_tbatches where PgCount <=@Minpagecount                                 
 and SUBSTRING(BatchNo,CHARINDEX('A',BatchNo)+1,(LEN(BatchNo)-CHARINDEX('A',BatchNo))+1) =(select subclient from #MergeSubclients where ID=@LoopCount)                
 and ScanDate=@scandate and status=99 and ServiceId=@serviceid and BatchNo not in (select childbatchno from mergebatchdetails)         
 group by SUBSTRING(BatchNo,CHARINDEX('A',BatchNo)+1,(LEN(BatchNo)-CHARINDEX('A',BatchNo))+1)                 
                      
set @LoopCount=@LoopCount-1                         
                     
                            
 End                
select * from #SubClientDetails                        
drop table #SubClientDetails                                            
drop table #mergesubclients                               
  End  
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_MergeBatches] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_MergeBatches] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_MergeBatches] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_MergeBatches] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_MergeBatches] TO [DB_DMLSupport]
    AS [dbo];

