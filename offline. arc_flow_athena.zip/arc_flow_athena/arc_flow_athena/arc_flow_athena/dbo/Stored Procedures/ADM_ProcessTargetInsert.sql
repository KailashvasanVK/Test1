﻿CREATE Procedure [dbo].[ADM_ProcessTargetInsert]  
(  
 @TargetName VARCHAR(30),  
 @CreatedBy INT,  
 @Status INT,  
 @TargetId INT OUTPUT  
   
)  
AS   
BEGIN  
 /*                      
 Purpose           : insert Process Target details into ADM_ProcessTarget table                  
 Created By        : Kathiravan                      
 Created Date      :15 may 2013     
 Impact to         : ProcessTarget.aspx                      
  */     
	INSERT INTO ADM_ProcessTarget(TargetName,CreatedBy,Status)  
	SELECT @TargetName,@CreatedBy,@Status  
	SELECT @TargetId = IDENT_CURRENT('ADM_ProcessTarget')  
END


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ProcessTargetInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProcessTargetInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProcessTargetInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ProcessTargetInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProcessTargetInsert] TO [DB_DMLSupport]
    AS [dbo];

