﻿CREATE PROCEDURE pIndexing_PayerUpdation     
(                                                   
@BatchNo varchar(30)='',    
@PayorServiceId int=0,    
@ScanDate Date=NULL,    
@ntusername varchar(100)='',     
@AutomationType int = 1    
)                                            
as                                                    
Begin                              
/*                
To Update Bucket info and Payor Info                
CreatedDate : Aug 31,2015              
ModifiedDate : Oct 025,2015,Purpose to avoid to update service id 385-Inpatient Queue            
*/                        
                            
BEGIN TRY                                                  
                                            
Update Arc_Flow_Athena..TRN_kOFF_tBatches set PayerId=@PayorServiceId where BatchNo=@BatchNo                                            
--new                    
DECLARE @ServiceId int=0     
--Automation     
If(@AutomationType = 0)      
BEGIN              
 SELECT @ServiceId = 418   
               
      Update Arc_Flow_Athena..TRN_kOFF_tBatches set serviceid=@ServiceId where BatchNo=@BatchNo   --and serviceid not in(356,385,394,419)                                          
      Update Arc_Flow_Athena..TRN_kOFF_tBatchQueue set serviceid=@ServiceId where BatchNo=@BatchNo   --and serviceid not in(356,385,394,419)     
   
END 
     
ELSE IF(@AutomationType = 1)      
BEGIN      
      SELECT @ServiceId= PayorBucketServiceId  FROM Athena_Index_RouteToPayorWithBucketInfo WHERE PayorServiceId=@PayorServiceId  
      IF(@ServiceId>0)                
            BEGIN                
                  Update Arc_Flow_Athena..TRN_kOFF_tBatches set serviceid=@ServiceId where BatchNo=@BatchNo   and serviceid not in(356,385,394,419)                                          
                  Update Arc_Flow_Athena..TRN_kOFF_tBatchQueue set serviceid=@ServiceId where BatchNo=@BatchNo   and serviceid not in(356,385,394,419)                
            END  
END               
                       
END TRY                            
                            
BEGIN CATCH                            
Insert into tblTrack_Athena_Index_BatchWithPayorInfo(ErrorMessage,trackedate,batchno)                            
SELECT ERROR_MESSAGE(),GETDATE(),@BatchNo                            
END CATCH                            
                              
End   

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[pIndexing_PayerUpdation] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexing_PayerUpdation] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexing_PayerUpdation] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[pIndexing_PayerUpdation] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexing_PayerUpdation] TO [DB_DMLSupport]
    AS [dbo];

