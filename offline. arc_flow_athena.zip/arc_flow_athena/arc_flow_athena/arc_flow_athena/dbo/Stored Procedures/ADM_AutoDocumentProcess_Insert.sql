﻿CREATE Procedure ADM_AutoDocumentProcess_Insert  
(  
@Action varchar(100),  
@ADPName  varchar(100),  
@ServiceId int,  
@CustomerId int,  
@ILogClassifyId int,  
@Script varchar(MAX),  
@CreatedBy int, 
@ADPId int,
@Params varchar(MAX),
@Pid int out       
)  
as  
Begin  
/*     
    Purpose :Insert AutoDocumentProcess  and  Params insert
    Created By   : Kathiravan          
    Created Date : 03 oct 2013          
    Impact to    :AutoDocumentProcess.aspx          
 */   
if(@Action ='InsertAutoDocumentProcess')  
 BEGIN  
    INSERT INTO ADM_AutoDocumentProcess(ADPName,ServiceId,CustomerId,ILogClassifyId,Script,CreatedBy,CreatedDt)  
    select @ADPName,@ServiceId,@CustomerId,@ILogClassifyId,@Script,@CreatedBy,GETDATE() 
    set @Pid = isnull(IDENT_CURRENT('ADM_AutoDocumentProcess'),0)  
 END  
if(@Action ='InsertAutoDocumentProcessParams')
 BEGIN
    INSERT INTO ADM_AutoDocumentProcessParams(ADPId,Params,CreatedBy,CreatedDt)  
    select @ADPId,@Params,@CreatedBy,GETDATE()
 END
 if(@Action='GetILogClassificationByServiceId')
 BEGIN
	select iLog.ClassifyId,iLog.ClassifyName from ADM_AutoDocumentProcess  as doc
	LEFT JOIN ADM_IssueLogClassification as iLog on iLog.ClassifyId=doc.ILogClassifyId
	where doc.ServiceId=@ServiceId and doc.CustomerId=@CustomerId
 END
End





GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_AutoDocumentProcess_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AutoDocumentProcess_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AutoDocumentProcess_Insert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_AutoDocumentProcess_Insert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AutoDocumentProcess_Insert] TO [DB_DMLSupport]
    AS [dbo];

