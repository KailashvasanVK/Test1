﻿




CREATE  Proc Athena_Index_InsertBatchWithPayorInfo (                                 
@BatchNo varchar(30)='',@PayorServiceId int=0,@ScanDate Date=NULL,@ntusername varchar(100)=''   )                          
as                                  
Begin            
          
BEGIN TRY                                
                          
Update ARC_Flow_Athena..TRN_kOFF_tBatches set PayerId=@PayorServiceId where BatchNo=@BatchNo                          
--new                          
if Exists (SELECT 1 from Athena_Index_RouteToPayor where PayorServiceId= @PayorServiceId and PayorName='OfflinePayor3' )                     
                          
Begin                           
 Update ARC_Flow_Athena..TRN_kOFF_tBatches set serviceid=357 where BatchNo=@BatchNo  and serviceid<>356                         
 Update ARC_Flow_Athena..TRN_kOFF_tBatchQueue set serviceid=357 where BatchNo=@BatchNo  and serviceid<>356                         
End                
              
Else if Exists (SELECT 1 from Athena_Index_RouteToPayor where PayorServiceId= @PayorServiceId and PayorName='OfflinePayor4' )                     
                          
Begin                           
 Update ARC_Flow_Athena..TRN_kOFF_tBatches set serviceid=370 where BatchNo=@BatchNo  and serviceid<>356                         
 Update ARC_Flow_Athena..TRN_kOFF_tBatchQueue set serviceid=370 where BatchNo=@BatchNo  and serviceid<>356                         
End                 
Else if Exists (SELECT 1 from Athena_Index_RouteToPayor where PayorServiceId= @PayorServiceId and PayorName='OfflinePayor5' )                     
   /*      
   Route batch to OfflinePayor5, ServiceId 374-select * from ADM_Service where ServiceId=374      
   CreatedDate: June 26,2015      
   Mailed by Ramesh, June 24,2015      
   */                       
Begin                           
 Update ARC_Flow_Athena..TRN_kOFF_tBatches set serviceid=374 where BatchNo=@BatchNo  and serviceid<>356                         
 Update ARC_Flow_Athena..TRN_kOFF_tBatchQueue set serviceid=374 where BatchNo=@BatchNo  and serviceid<>356                         
End    
Else if Exists (SELECT 1 from Athena_Index_RouteToPayor where PayorServiceId= @PayorServiceId and PayorName='OffLineSelfPay' )                     
   /*      
   Route batch to Offline SelfPay, ServiceId 362-select * from ADM_Service where ServiceId=362    
   CreatedDate: June 29,2015      
   Mailed by Ramesh, June 24,2015      
   */                       
Begin                           
 Update ARC_Flow_Athena..TRN_kOFF_tBatches set serviceid=362 where BatchNo=@BatchNo  and serviceid<>356                         
 Update ARC_Flow_Athena..TRN_kOFF_tBatchQueue set serviceid=362 where BatchNo=@BatchNo  and serviceid<>356                         
End    
Else if Exists (SELECT 1 from Athena_Index_RouteToPayor where PayorServiceId= @PayorServiceId and PayorName='Offline - Medicare' )                     
   /*      
   Route batch to Offline - Medicare bucket, ServiceId 379-select * from ADM_Service where ServiceId=379    
   CreatedDate: June 29,2015      
   Mailed by Vignesh Baskar, Aug 08,2015      
   */                       
Begin                           
 Update ARC_Flow_Athena..TRN_kOFF_tBatches set serviceid=379 where BatchNo=@BatchNo  and serviceid<>356                         
 Update ARC_Flow_Athena..TRN_kOFF_tBatchQueue set serviceid=379 where BatchNo=@BatchNo  and serviceid<>356                         
End        
Else if Exists (SELECT 1 from Athena_Index_RouteToPayor where PayorServiceId= @PayorServiceId and PayorName='OfflineMedicaid' )                     
   /*      
   Route batch to OfflineMedicaid bucket, ServiceId 380-select * from ADM_Service where ServiceId=380    
   CreatedDate: Aug 25,2015      
   Mailed by Vignesh Baskar, Aug 25,2015      
   */                       
Begin                           
 Update ARC_Flow_Athena..TRN_kOFF_tBatches set serviceid=380 where BatchNo=@BatchNo  and serviceid<>356                         
 Update ARC_Flow_Athena..TRN_kOFF_tBatchQueue set serviceid=380 where BatchNo=@BatchNo  and serviceid<>356                         
End    
          
  --  Check if record already available.        
if Exists (SELECT 1 from Athena_Index_BatchWithPayorInfo where  BatchNo=@BatchNo)        
BEGIN        
      UPDATE Athena_Index_BatchWithPayorInfo SET PayorServiceId = @PayorServiceId, ScanDate = @ScanDate,CreatedDate=GETDATE() Where BatchNo = @BatchNo        
END        
ELSE        
BEGIN        
      INSERT INTO Athena_Index_BatchWithPayorInfo(BatchNo,PayorServiceId,ScanDate,ntusername,CreatedDate)Values(@BatchNo,@PayorServiceId,@ScanDate,@ntusername,GETDATE())          
 END    
        
             
END TRY          
          
BEGIN CATCH          
Insert into tblTrack_Athena_Index_BatchWithPayorInfo(ErrorMessage,trackedate,batchno)          
SELECT ERROR_MESSAGE(),GETDATE(),@BatchNo          
END CATCH          
            
End                



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_InsertBatchWithPayorInfo] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_InsertBatchWithPayorInfo] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_InsertBatchWithPayorInfo] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_InsertBatchWithPayorInfo] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_InsertBatchWithPayorInfo] TO [DB_DMLSupport]
    AS [dbo];

