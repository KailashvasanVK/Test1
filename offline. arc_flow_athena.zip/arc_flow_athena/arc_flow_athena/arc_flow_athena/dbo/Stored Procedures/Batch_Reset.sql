﻿CREATE Procedure [dbo].[Batch_Reset] (@BNo varchar(30))          
as           
Begin 
/*   
Declare @BatchId int = (Select BatchId from TRN_kOff_tBatches where Batchno = @Bno)  
Declare @TopBatchProcessId int = (Select top 1 BatchProcessId from TRN_kOFF_tBatchQueue where BatchId= @BatchId)  
Declare @AssignedBy varchar(100) = isnull((Select nt_username from ARC_Rec_Athena..arc_rec_user_info where userid = (Select top 1 Assigned from TRN_kOFF_tBatchQueue where BatchNo = @BNo)),'')
Declare @msg varchar(1000) = ''
if @AssignedBy <> ''
Begin
	Set @msg = 'Batch assigned by ' + @AssignedBy + ' Please ask him to release/complete.'
	PRINT @msg
End
else IF  EXISTS (SELECT 1 FROM ARC_Athena..batchMaster where batchnum=@BNo and ULStatus is NULL)
	BEGIN    
	  
	delete from TRN_kOFF_tBatchTransactMirror where BatchProcessId = @TopBatchProcessId
	delete from TRN_kOFF_tBatchTransactSummary where BatchProcessId = @TopBatchProcessId
	delete from TRN_kOFF_tBatchTransact where BatchProcessId = @TopBatchProcessId
	  
	delete from  TRN_kOFF_tBatchQCComments where BatchProcessId = @TopBatchProcessId
	delete from  TRN_kOFF_tBatchQCTran where BatchProcessId = @TopBatchProcessId
	delete from  TRN_kOFF_tBatchQCMaster where BatchProcessId = @TopBatchProcessId
	  
	delete  from TRN_kOff_tBatchFlow where BatchId  = @BatchId and StatusId <> 0  
	  
	Update TRN_kOFF_tBatchQueue Set StatusId = 0,Assigned = 0,FlowId=(select MAX(flowid) from TRN_kOff_tBatchFlow where BatchId=@BatchId)   
	Where BatchId = @BatchId  
	Update TRN_koff_tBatches set PostedDt=Null,AuditedDt=NULL,UploadDt =NULL  where  BatchNo =@BNo          
	End
ELSE
	BEGIN
	PRINT 'Check whether Remit generated for this Batch '
	End 
*/
Select ''
End



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Batch_Reset] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Batch_Reset] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Batch_Reset] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Batch_Reset] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Batch_Reset] TO [DB_DMLSupport]
    AS [dbo];

