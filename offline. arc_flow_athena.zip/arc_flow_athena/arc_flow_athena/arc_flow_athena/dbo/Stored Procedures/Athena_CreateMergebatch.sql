﻿CREATE proc Athena_CreateMergebatch ( @ClientName varchar(7),@Maxpagecount  int,@scandate varchar(10),@serviceid int )              
  
as                  
Begin         
  
/*        
  
Cretaed By     : Leela.T    
Created Date   : 2015-03-09       
Purpose        : Batches are Logically Merged     
Ticket/SCR ID  : <>    
TL Verified By : Ramakrishnan.G    
  
Modified BY    : Leela.T    
Modified Date  : 2014-11-19    
Mod ID                          :001    
Request Type    : Process improvement by IT>    
Purpose         : Merge process will only refer Chennai FTP server. Previously few batches were referring CBE.    
TL Verified By : Ramakrishnan.G    
  
  
  
Implemented by : <>    
Implemented On :     
  
Reviewd by     : <>    
Implemented On :      
  
  
*/    
  
  
Declare @qury varchar(Max)                                                
,@toprec varchar(15)=20    
,@LoopCount int    
,@PgCount int    
,@batchno varchar(50)                                              
,@Client varchar(10)    
,@ParentBatchid int                                               
,@StartPgNo int    
,@EndPgNo int    
,@Chk int                                             
,@ParentBatchNo Varchar(20)                                               
,@Count int    
,@Mergequry varchar(1000)    
,@Fname varchar(300)                           
,@BatchCount int,@dollaramt money     
  
  
  
  
if(object_id('tempdb.dbo.#MergeBatchDetails')is not null)                    
drop table #MergeBatchDetails                           
  
create table #MergeBatchDetails                                    
(                                                
BatchNo   Varchar(15)                                                                                                                           
,PageCount   int                                     
,Fname varchar(300)                                 
,status int                  
,dollarAmt Money                                   
)                    
  
  
INSERT INTO Athena_ParentBatchGeneration(ParentBatch) values (@clientName)                                                
set @ParentBatchid = SCOPE_IDENTITY()                                                
set @ParentBatchNo='M' + Convert(varchar(10),@ParentBatchid) + 'A' + @clientName                                                
Print @ParentBatchNo                         
  
Insert into #MergeBatchDetails(batchno , pagecount,Fname,status,dollarAmt)                                                      
Select batchno,pgcount,'\\fs-ib'+SUBSTRING(a.Fname,CHARINDEX('\',a.Fname,3),LEN(a.Fname)) ,0,b.dollarAmt from trn_koff_tbatches(nolock) a inner join ARC_Athena..batchMaster(nolock) b              
on a.BatchNo=b.batchnum where BatchNo not in (select ChildBatchNo from mergebatchdetails(nolock)) and convert(varchar,ScanDate,101)=convert(varchar,@scandate,101)               
and SUBSTRING(a.BatchNo,CHARINDEX('A',a.BatchNo)+1,(LEN(a.BatchNo)-CHARINDEX('A',a.BatchNo))+1)=@ClientName         
and status=99          
and ServiceId=@serviceid          
  
set @Count=0                                            
set @Chk=0                                            
  
  
/*select * from #MergeBatchDetails */                                            
  
Declare @CurMergeBatch cursor                                                    
Set  @CurMergeBatch  = cursor fast_forward for                                               
  
Select batchno, pagecount,Fname,dollaramt from #MergeBatchDetails where status=0                                                 
  
Open  @CurMergeBatch                                                                                                                          
                                     
Fetch next from @CurMergeBatch into                                               
@BatchNo,@PgCount ,@Fname,@dollaramt                                               
                               
While(@@fetch_status<>-1)                                                 
Begin                       
  
Set @count=@count+@pgcount                                                
  
if(@Count>=@Maxpagecount)                     
  
begin                                            
Set @Count=0                                            
Set @Chk=0                   
select @Count=SUM(pagecount) from #MergeBatchDetails where status=0                                
  
  
If(@Count<(@Maxpagecount-Floor(@Maxpagecount*0.2)))                                  
Begin                              
  
Update TRN_kOFF_tBatches set status=1 where BatchNo in(                              
select BatchNo from #MergeBatchDetails where status=0)           
  
Goto NextSubClient                                
  
End          
  
Set @count=0                            
Set @count=@count+@pgcount                                                
  
  
INSERT INTO Athena_ParentBatchGeneration(ParentBatch) values (@clientName)                                                
set @ParentBatchid = SCOPE_IDENTITY()                                                
set @ParentBatchNo='M' + Convert(varchar(10),@ParentBatchid) + 'A' + @clientName                                                
Print @ParentBatchNo                                             
  
if (@Chk=0)                                            
begin                                            
Set @Chk=1                                            
set @StartPgNo=1                                            
set @EndPgNo=@PgCount                                            
End                                            
  
else                                            
begin                                            
set @StartPgNo=@EndPgNo+1                                            
set @EndPgNo= @startpgno + (@PgCount-1)                                            
End                                           
End                                            
  
Else                                           
  
Begin                                            
If (@Chk=0)                                            
Begin                                            
Set @Chk=1                                            
Set @StartPgNo=1                                            
Set @EndPgNo=@PgCount                                            
End                                            
Else                                            
Begin                                           
Set @StartPgNo=@EndPgNo+1                                            
Set @EndPgNo= @startpgno + (@PgCount-1)                                            
End                                            
  
End                                            
INSERT INTO MergeBatchDetails(ParentBatchNo,childBatchNo,StartPgNo,EndpgNo,TotalPages,status,Fname,dollaramt)                                            
values(@ParentBatchNo,@BatchNo,@StartPgNo,@EndPgNo,@PgCount,1,'\\fs-ib'+SUBSTRING(@Fname,CHARINDEX('\',@Fname,3),LEN(@Fname)),@dollaramt)          
  
update #MergeBatchDetails set status=1 where BatchNo=@BatchNo                                  
Select * from  #MergeBatchDetails where BatchNo=@BatchNo                                 
  
fetch next from @CurMergeBatch   into                        
@BatchNo,@PgCount,@Fname,@dollaramt                                                
End                   
  
NextSubClient:                                            
close @CurMergeBatch                                               
deallocate @CurMergeBatch                                
  
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_CreateMergebatch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_CreateMergebatch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_CreateMergebatch] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_CreateMergebatch] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_CreateMergebatch] TO [DB_DMLSupport]
    AS [dbo];

