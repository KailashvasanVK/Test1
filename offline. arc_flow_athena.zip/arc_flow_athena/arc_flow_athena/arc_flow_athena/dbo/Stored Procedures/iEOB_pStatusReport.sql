﻿
CREATE PROCEDURE iEOB_pStatusReport
(
@FromDate varchar(50),  
@ToDate varchar(50)  
)  
As  
/*       
Created By: Gobinath.M      
Created Date   : 2017-11-14      
Purpose  : To Show the iEOB Production in Status Board    
Ticket/SCR ID  : 250064      
TL Verified By : Ramakrishnan.G       
Implemented By : Ganesh Tanneru     
Implemented On : 2017-11-15   
     
*/    
Begin  
 
IF OBJECT_ID('Tempdb..#tempStatusBoard') is not null drop table #tempStatusBoard  
SELECT aq.*, tb.ScanDate, pm.PayerName As Payer INTO #tempStatusBoard FROM ARC_Athena..SemiOCR_PaymentPosting (nolock) aq  
Inner join ARC_Athena..iEOB_tAutomationBatchQueue (nolock) tbQ on tbQ.BatchNo = aq.BatchNo --And  aq.IsPosted = 3
Inner join ARC_Flow_Athena..TRN_kOff_tBatches (nolock) tb on tb.BatchNo = tbQ.BatchNo
Inner join ARC_Flow_Athena..Adm_PayerName(nolock) pm on pm.PayerID = tb.PayerID
WHERE CONVERT(Date, tb.ScanDate) BETWEEN CONVERT(Date, @FromDate) AND CONVERT(Date, @ToDate) And tbQ.StatusID = 5 

SELECT a.BATCHNO, a.ScanDate, a.Payer,
SUM(a.TotalTagged) As TOTALTAGGED, 
SUM(a.CreationTrans) As CREATION, 
SUM(a.ACTUALTRANS) As ACTUALTRANS,
SUM(a.Secondary) As SECONDARY,
SUM(a.BilledAmount) As BILLEDAMOUNT, 
SUM(a.Insurance) As INSURANCE, 
SUM(a.CPT) As CPT,
SUM(a.[DOS/Dump]) As [DUMP],
POSTED = SUM(a.ACTUALTRANS) -  SUM(a.CreationTrans) - SUM(a.Secondary) - SUM(a.BilledAmount) - SUM(a.Insurance) - SUM(a.CPT) - SUM(a.[DOS/Dump]),
SUM(a.ManualPosted) As MANUALENTRY, 
SUM(a.CreationTrans) As CREATIONTRANS, 
SUM(a.Exception) As EXCEPTION
FROM (
Select BatchNo, ScanDate, Payer, COUNT(id) As TotalTagged, 0 As Creation, 0 As ActualTrans, 0 As Secondary, 0 As BilledAmount, 0 As Insurance, 0 As CPT, 0 As [DOS/Dump], 0 As Total, 0 As Posted 
,0 As ManualPosted, 0 As CreationTrans, 0 As Exception
from #tempStatusBoard 
Group by BatchNo, ScanDate, Payer
UNION ALL
Select BatchNo, ScanDate, Payer, 0 As TotalTagged, 0 As Creation, COUNT(id) As ActualTrans, 0 As Secondary, 0 As BilledAmount, 0 As Insurance, 0 As CPT, 0 As [DOS/Dump], 0 As Total, 0 As Posted 
,0 As ManualPosted, 0 As CreationTrans, 0 As Exception
from #tempStatusBoard 
Group by BatchNo, ScanDate, Payer
UNION ALL
Select BatchNo, ScanDate, Payer, 0 As TotalTagged, 0 As Creation, 0 As ActualTrans, COUNT(id) As Secondary, 0 As BilledAmount, 0 As Insurance, 0 As CPT, 0 As [DOS/Dump], 0 As Total, 0 As Posted 
,0 As ManualPosted, 0 As CreationTrans, 0 As Exception
from #tempStatusBoard Where Status = 2
Group by BatchNo, ScanDate, Payer 
UNION ALL
Select BatchNo,ScanDate, Payer,  0 As TotalTagged, 0 As Creation, 0 As ActualTrans, 0 As Secondary, COUNT(id) As BilledAmount, 0 As Insurance, 0 As CPT, 0 As [DOS/Dump], 0 As Total, 0 As Posted 
,0 As ManualPosted, 0 As CreationTrans, 0 As Exception
from #tempStatusBoard Where Status = 3
Group by BatchNo,ScanDate, Payer 
UNION ALL
Select BatchNo,ScanDate, Payer,  0 As TotalTagged, 0 As Creation, 0 As ActualTrans, 0 As Secondary, 0 As BilledAmount,  COUNT(id) As Insurance, 0 As CPT, 0 As [DOS/Dump], 0 As Total, 0 As Posted 
,0 As ManualPosted, 0 As CreationTrans, 0 As Exception
from #tempStatusBoard Where Status = 5
Group by BatchNo, ScanDate, Payer 
UNION ALL
Select BatchNo, ScanDate, Payer,  0 As TotalTagged, 0 As Creation, 0 As ActualTrans, 0 As Secondary, 0 As BilledAmount, 0 As Insurance,  COUNT(id) As CPT, 0 As [DOS/Dump], 0 As Total, 0 As Posted 
,0 As ManualPosted, 0 As CreationTrans, 0 As Exception
from #tempStatusBoard Where Status = 6
Group by BatchNo, ScanDate, Payer 
UNION ALL
Select BatchNo, ScanDate, Payer,  0 As TotalTagged, 0 As Creation, 0 As ActualTrans, 0 As Secondary, 0 As BilledAmount, 0 As Insurance, 0 As CPT,  COUNT(id) As [DOS/Dump], 0 As Total, 0 As Posted 
,0 As ManualPosted, 0 As CreationTrans, 0 As Exception
from #tempStatusBoard Where Status = 9
Group by BatchNo, ScanDate, Payer
UNION ALL
Select BatchNum As BatchNo, ScanDate, Payer,  0 As TotalTagged, 0 As Creation, 0 As ActualTrans, 0 As Secondary, 0 As BilledAmount, 0 As Insurance, 0 As CPT,  0 As [DOS/Dump], 0 As Total, 0 As Posted
,COUNT(distinct p.id) As ManualPosted, 0 As CreationTrans, 0 As Exception 
from ARC_Athena..PaymentDetailMaster p
Inner join #tempStatusBoard t on t.BatchNo = p.BatchNum And t.IsPosted = 3
Where OCRStatus = 0
Group by BatchNum, ScanDate, Payer
UNION ALL
Select  pymnt.BatchNum As BatchNo, ScanDate, Payer, 0 As TotalTagged, 0 As Creation, 0 As ActualTrans, 0 As Secondary, 0 As BilledAmount, 0 As Insurance, 0 As CPT,  0 As [DOS/Dump], 0 As Total, 0 As Posted 
,0 As ManualPosted, COUNT(distinct(clm.ClaimID)) As CreationTrans, 0 As Exception  
From ARC_Athena..PaymentDetailMaster (nolock) pymnt
Inner join #tempStatusBoard t on t.BatchNo = pymnt.BatchNum And t.IsPosted = 3
inner join ARC_Athena..ClaimServiceDetailMaster (nolock) csd on pymnt.chargeID=csd.ChargeID                    
inner join ARC_Athena..ClaimDetailMaster (nolock) clm on csd.ClaimID =clm.ClaimID
WHERE  clm.Status=1                    
group by  pymnt.BatchNum, ScanDate, Payer
                 
UNION ALL
Select BatchNum As BatchNo, ScanDate, Payer, 0 As TotalTagged, 0 As Creation, 0 As ActualTrans, 0 As Secondary, 0 As BilledAmount, 0 As Insurance, 0 As CPT,  0 As [DOS/Dump], 0 As Total, 0 As Posted 
,0 As ManualPosted, 0 As CreationTrans, COUNT(distinct e.ID) As Exception 
from ARC_Athena..BatchException e
Inner join #tempStatusBoard t on t.BatchNo = e.BatchNum  And t.IsPosted = 3
Group by BatchNum, ScanDate,Payer  
)a
Group by a.BatchNo, a.ScanDate, a.Payer

End
GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOB_pStatusReport] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[iEOB_pStatusReport] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOB_pStatusReport] TO [DB_DMLSupport]
    AS [dbo];

