﻿CREATE PROCEDURE pIndexing_BatchAllocation_N           
(               
@UserInfo varchar(30)              
)              
As          
/*                  
Created By     : Gobinath.M                              
Created Date   : 2015-07-21                
Purpose        : To Assign the batches in Indexing Application                              
Ticket/SCR ID  :                
TL Verified By : Ramakrishnan.G                
                
Implemented On :                 
Implemented On : 28-April-2016            
Reviewed by    : Ganesh               
Reviewed On    : 28-April-2016      
Modified On    : To include Condition Pgcount <6
    
Implemented By: Narayana    
ticket id:209302         
*/                 
            
Begin               
 BEGIN TRY          
           
            DECLARE                   
            @UserCount Int,              
            @Target Int,            
            @ActualTarget Int               
        
            SET @UserCount = (Select COUNT(id) from batchIndex_TrackBatches Where userinfo = @UserInfo and cstatus = 0 and CompletedDate Is NULL)              
            SET @ActualTarget = (SELECT [Target] FROM tBatchIndexing_Target Where UserName = @UserInfo)            
            SET @Target = @ActualTarget - @UserCount;             
        
            INSERT INTO batchIndex_TrackBatches (batchnum,userinfo,cstatus)                             
            SELECT  TOP (@Target) Batchno, @UserInfo,0  from trn_koff_tbatches (nolock)  a   
            /*--inner join  ARC_ATHENA.dbo.batchtotal bt (nolock) on bt.batchnum = a.BatchNo    */                         
            Where uploaddt  is null and serviceid<>363 and status=3  And PgCount <6
            and NOT EXISTS (SELECT top 1 Batchnum              
            From batchIndex_TrackBatches Where Batchnum =  a.BatchNo)  Order by  a.Priority desc ,ScanDate asc, PgCount  desc         
                     
        SELECT ErrorNumber = 0;        
        
END TRY         
BEGIN CATCH        
    SELECT ERROR_NUMBER() AS ErrorNumber        
END CATCH        
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[pIndexing_BatchAllocation_N] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexing_BatchAllocation_N] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexing_BatchAllocation_N] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[pIndexing_BatchAllocation_N] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexing_BatchAllocation_N] TO [DB_DMLSupport]
    AS [dbo];

