﻿CREATE Procedure TRN_kOFF_pConsolidatedProductionReport    
(    
 @FromDate date ='2015-01-01',    
 @ToDate date = '2015-01-10',     
 @CmpKey varchar(5)= 'OFF',    
 @UserId int =0,    
 @RptType varchar(1) ='T',    
 @BatchServiceId int = 0,    
 @SearchStr varchar(100) = ''  ,    
 @SearchPattern varchar(4) = '=' /** = or % **/      
)    
As    
begin    
  /*   Created By : Kathiravan.kand     
  Created Dt : 26/12/2014    
  Purpose    : to get the consolidated production details    
  
  Modified By     : mallikarjun.nam
  Created Date   : 2016-05-26   
  Ticket/SCR ID  : 146753
  TL Verified By : Safi
                 
  Implemented by : <Implementaion person Name>
  Implemented On : 19-04-2014
*/    
/*
  Declare @FromDate date ='10/01/2018'
  Declare @ToDate date = '10/31/2018'     
  Declare @CmpKey varchar(5)= 'OFF'    
  Declare @UserId int =0--2936 ,1973    
  Declare @RptType varchar(1) ='T'    
  Declare @batchSErviceId int = 0    
  Declare @SearchStr varchar(100) = ''      
  Declare @SearchPattern varchar(4) = '=' /** = or % **/     
*/
 Set Transaction isolation level read uncommitted;
    
 Declare @qry varchar(max) = ''    
 Declare @Supervisor varchar(50)=''     
 Declare @CustomerId int      
 if(ISNULL(@UserId,0)) <> 0     
  select @Supervisor = NT_USERNAME  from ARC_REC_Athena..ARC_REC_USER_INFO  where USERID = @UserId and AHS_PRL = 'Y' and ACTIVE =1    
  Select @CustomerId =  CustomerId  from ADM_customer where CmpKey = @CmpKey         
       
    
 if OBJECT_ID('tempdb..#ProdRptAssociateWiseTrans') is not null drop table #ProdRptAssociateWiseTrans    
 if OBJECT_ID('tempdb..#ProdRptAssociateWiseTransQc') is not null drop table #ProdRptAssociateWiseTransQc    
 if OBJECT_ID('tempdb..#Associate_Target') is not null drop table #Associate_Target    
 if OBJECT_ID('tempdb..#Associate_ErrorTarget') is not null drop table #Associate_ErrorTarget    
 if OBJECT_ID('tempdb..#UserCustomerList') is not null drop table #UserCustomerList    
     
 if OBJECT_ID('tempdb..#AssociateEntryErrorCount') is not null drop table #AssociateEntryErrorCount    
 Create Table #AssociateEntryErrorCount(FTE_Id int,ErrCount int,ErrInReview int)    
 if OBJECT_ID('tempdb..#AssociateQCErrorCount') is not null drop table #AssociateQCErrorCount    
 Create Table #AssociateQCErrorCount(FTE_Id int,ErrCount int,ErrInReview int)    
 if OBJECT_ID('tempdb..#EntryAssociateQCedTransCount') is not null drop table #EntryAssociateQCedTransCount    
 Create Table #EntryAssociateQCedTransCount(FTE_Id int,TransCount int)     
     
 Create table #UserCustomerList(UserId int,Active int,Nt_UserName varchar(50),REPORTING_TO varchar(50),UserType int)     
 insert into #UserCustomerList(UserId,Active,Nt_UserName,REPORTING_TO,UserType)    
 select  distinct ucust.UserId,ui.ACTIVE,ui.NT_USERNAME,ui.REPORTING_TO,0 from ARC_REC_Athena..ARC_REC_UserCustomer ucust     
 inner join ARC_REC_Athena..ARC_REC_USER_INFO ui  on ui.USERID = ucust.UserId and ui.REPORTING_TO = case when @Supervisor <> '' then @Supervisor else REPORTING_TO end    
 where  ucust.CustomerID =@CustomerId       
    
 Create Table #ProdRptAssociateWiseTrans(funt varchar(20),NtName varchar(75),UserId int,ClientId int,ServiceId int,ServiceName varchar(50),EntryTransCnt int,    
 QcTransCnt int,EntryFactorPer decimal(10,2),QcFactorPer decimal(10,2),EntryDate date,BatchServiceId int,EntryBatchCount int,QcBatchCount int,Error decimal,ErrorPer decimal,BatchId int,ErrTgt decimal(16,2),BatchProcessId int )     
    
 Create Table #ProdRptAssociateWiseTransQc(funt varchar(20),NtName varchar(75),UserId int,ClientId int,ServiceId int,ServiceName varchar(50),EntryTransCnt int,    
 QcTransCnt int,EntryFactorPer decimal(10,2),QcFactorPer decimal(10,2),EntryDate date,BatchServiceId int,EntryBatchCount int,QcBatchCount int,Error decimal,ErrorPer decimal,BatchId int,ErrTgt decimal(16,2),BatchProcessId int )     
     
 Insert into #ProdRptAssociateWiseTrans(funt,NtName,UserId,ClientId,ServiceId,ServiceName,EntryTransCnt,EntryFactorPer,QcFactorPer,    
 EntryDate,BatchServiceId,EntryBatchCount,QcBatchCount,BatchId,BatchProcessId)    
 Select   batTrans.fun,NtName,UserId,ClientId,batTrans.ServiceId,ServiceName,sum(ProTransCnt) as EntryTransCnt,     
 (Select FactorValue from ADM_Factor as fact Where fact.CustomerId = @CustomerId and fact.ClientId = batTrans.ClientId     
 and fact.ServiceId = batTrans.ServiceId and EntryDate between fact.EffectiveFrom and Cast(isnull(fact.EffectiveTo,getdate()) as DATE)    
 and fact.FactorType = 1    
 ) EntryFactor    
 ,(Select FactorValue from ADM_Factor as fact Where fact.CustomerId = @CustomerId and fact.ClientId = batTrans.ClientId    
 and fact.ServiceId = batTrans.ServiceId and EntryDate between fact.EffectiveFrom and Cast(isnull(fact.EffectiveTo,getdate()) as DATE)    
 and fact.FactorType = 2    
 ) QcFactor     
 ,EntryDate,BatchServiceId ,EntryBatchCount,0     
 ,batTrans.BatchId as BatchId     
 ,batTrans.BatchProcessId     
 from    
 (    
  Select 'Entry'as fun,ui.NT_UserName as NtName,batTrans.CreatedBy as UserId,batTrans.ClientId,batTrans.ServiceId,ser.ServiceName    
  ,Sum(TransValue) as ProTransCnt,(select distinct count(batTrans.BatchId)) as EntryBatchCount,    
  Cast(batTrans.CreatedDt as date) as EntryDate,batTrans.BatchServiceId,batTrans.BatchProcessId, batTrans.BatchId     
  from TRN_kOFF_tBatchTransact as batTrans     
  inner join TRN_kOFF_tBatches as bat on bat.batchid = batTrans.batchid and bat.Status = 1     
  inner join ADM_Service as ser on ser.ServiceId = batTrans.ServiceId and ser.FieldType = 'T'    
  inner join ARC_REC_Athena..ARC_REC_User_Info as ui on ui.userid = batTrans.CreatedBy and REPORTING_TO =case when ISNULL(@Supervisor,'') <> '' then @Supervisor else ui.REPORTING_TO end    
  Where Cast(batTrans.CreatedDt as date) Between @FromDate and @ToDate and batTrans.TransValue > 0 and bat.ServiceId =  case when isnull(@BatchServiceId,0) <> 0 then @BatchServiceId else bat.ServiceId end    
  Group by ui.NT_UserName,batTrans.CreatedBy,batTrans.ClientId,batTrans.ServiceId,ser.ServiceName,batTrans.CreatedDt,batTrans.BatchServiceId,batTrans.BatchId ,    
  batTrans.BatchProcessId,batTrans.BatchId
 )batTrans
Group by  batTrans.fun,batTrans.NtName,UserId,ClientId,batTrans.ServiceId,ServiceName,EntryDate,BatchServiceId,EntryBatchCount,batTrans.BatchProcessId,batTrans.BatchId    
    
 Insert into #ProdRptAssociateWiseTransQC(funt,NtName,UserId,ClientId,ServiceId,ServiceName,EntryTransCnt,EntryFactorPer,QcFactorPer,    
 EntryDate,BatchServiceId,EntryBatchCount,QcBatchCount,BatchId,BatchProcessId)    
 Select batTrans.fun,NtName,UserId,ClientId,batTrans.ServiceId,ServiceName,sum(ProTransCnt) as EntryTransCnt      
 ,(Select FactorValue from ADM_Factor as fact Where fact.CustomerId = @CustomerId and fact.ClientId = batTrans.ClientId     
 and fact.ServiceId = batTrans.ServiceId and EntryDate between fact.EffectiveFrom and Cast(isnull(fact.EffectiveTo,getdate()) as DATE)    
 and fact.FactorType = 1    
 ) EntryFactor    
 ,(Select FactorValue from ADM_Factor as fact Where fact.CustomerId = @CustomerId and fact.ClientId = batTrans.ClientId    
 and fact.ServiceId = batTrans.ServiceId and EntryDate between fact.EffectiveFrom and Cast(isnull(fact.EffectiveTo,getdate()) as DATE)    
 and fact.FactorType = 2    
 ) QcFactor     
 ,EntryDate,BatchServiceId ,EntryBatchCount,0    
 ,batTrans.BatchId as BatchId,batTrans.BatchProcessId      
 from     
 (    
  Select 'Audit' as fun ,ui.NT_UserName as NtName,batTrans.CreatedBy as UserId,que.ClientId,batTrans.ServiceId,ser.ServiceName    
  ,Sum(TransValue) as ProTransCnt,0 as EntryBatchCount    
  ,Cast(getdate() as date) as EntryDate,que.ServiceId as BatchServiceId,que.BatchProcessId,que.BatchId    
  from TRN_kOFF_tBatchQCMaster as batTrans    
  inner join TRN_kOFF_tBatchQCComments qc on qc.BatchProcessId = batTrans.BatchProcessId    
  inner join TRN_kOFF_tBatchQueue as que on que.BatchProcessId = batTrans.BatchProcessId  and que.ServiceId =  case when isnull(@BatchServiceId,0) <> 0 then @BatchServiceId else que.ServiceId end    
  inner join TRN_kOFF_tBatches as bat on bat.batchid = que.batchid and bat.Status = 1     
  inner join ADM_Service as ser on ser.ServiceId = batTrans.ServiceId and ser.FieldType = 'T'    
  inner join ARC_REC_Athena..ARC_REC_User_Info as ui on ui.userid = batTrans.CreatedBy and REPORTING_TO =case when ISNULL(@Supervisor,'') <> '' then @Supervisor else  ui.REPORTING_TO end    
  Where Cast(batTrans.CreatedDt as date) Between @FromDate and @ToDate    
  Group by ui.NT_USERNAME,batTrans.CreatedBy,que.ClientId,batTrans.ServiceId,ser.ServiceName,batTrans.TransValue, que.ServiceId,que.BatchProcessId,que.BatchId    
 )batTrans    
 Group by  batTrans.fun,batTrans.NtName,UserId,ClientId,batTrans.ServiceId,ServiceName,EntryDate,BatchServiceId,EntryBatchCount,batTrans.BatchProcessId,batTrans.BatchId     

  
  /*Start - Code written by mallikarjun.nam*/
  if(select count(userId) from #UserCustomerList usrL
      where  exists (select 1 from TRN_kOFF_tBatchQCComments cm where cm.FTE_Id=usrl.UserId and CAST(cm.CreatedDt as date) between @FromDate and @ToDate)
      and not exists(select 1 from #ProdRptAssociateWiseTrans  where usrL.UserId=UserId))>0    
  Begin    
       Insert into #ProdRptAssociateWiseTrans(NtName,UserId,funt,ClientId,ServiceId,ServiceName,EntryTransCnt,EntryFactorPer,QcFactorPer,    
       EntryDate,BatchServiceId,EntryBatchCount,QcBatchCount,BatchId,BatchProcessId)   
       select distinct usrL.Nt_UserName,userId,'Entry'as fun,bat.ClientId,qcM.ServiceId,ser.ServiceName,0 as [EntryTransCnt]
      ,(Select FactorValue from ADM_Factor as fact Where fact.CustomerId = @CustomerId and fact.ClientId = bat.ClientId     
       and fact.ServiceId = qcM.ServiceId and cast(getdate() as date) between fact.EffectiveFrom and Cast(isnull(fact.EffectiveTo,getdate()) as DATE)    
       and fact.FactorType = 1    
       ) EntryFactor    
       ,(Select FactorValue from ADM_Factor as fact Where fact.CustomerId = @CustomerId and fact.ClientId = bat.ClientId    
       and fact.ServiceId = qcM.ServiceId and cast(getdate() as date) between fact.EffectiveFrom and Cast(isnull(fact.EffectiveTo,getdate()) as DATE)    
       and fact.FactorType = 2    
       ) QcFactor   
       ,getdate() as EntryDate
      ,bat.ServiceId
      ,0 as [EntryBatchCount]
      ,count(distinct qcm.BatchId),bat.BatchId,que.BatchProcessId from #UserCustomerList usrL
      inner join TRN_kOFF_tBatchQCComments cm on cm.FTE_Id=usrl.UserId and CAST(cm.CreatedDt as date) between @FromDate and @ToDate
      inner join TRN_kOFF_tBatchQueue as que on que.BatchProcessId = cm.BatchProcessId-- and que.ServiceId = @batchSErviceId    
       inner join TRN_kOFF_tBatches as bat on bat.batchid = que.batchid and bat.Status =1
      inner join TRN_kOFF_tBatchQCMaster as qcM on qcM.BatchProcessId = cm.BatchProcessId 
       inner join ADM_Service as ser on qcM.ServiceId = ser.ServiceId
      and not exists(select 1 from #ProdRptAssociateWiseTrans  where usrL.UserId=UserId)  
      group by   usrL.Nt_UserName,userId,bat.ClientId,qcM.ServiceId,ser.ServiceName
      ,bat.PostedDt,bat.ServiceId,bat.BatchId,que.BatchProcessId 
 End
  /*End - Code written by mallikarjun.nam*/    
      
 insert into #AssociateEntryErrorCount(FTE_Id,ErrCount,ErrInReview)    
 select cm.FTE_Id
 , sum(isnull(ErrCount,0)) as ErrCount
 /*,case when RebuttalStatus=1 then Sum(isnull(trn.ErrCount,0)) else 0 end ErrDone  */
 ,case when isnull(RebuttalStatus,2)=2 then Sum(isnull(trn.ErrCount,0)) else 0 end ErrInReview
 from TRN_kOFF_tBatchQCTran trn     
 inner join TRN_kOFF_tBatchQCComments cm on cm.BatchProcessId =  trn.BatchProcessId and CAST(cm.CreatedDt as date) between @FromDate and @ToDate     
 inner join TRN_kOFF_tBatchQueue as que on que.BatchProcessId = cm.BatchProcessId-- and que.ServiceId = @batchSErviceId    
 inner join TRN_kOFF_tBatches as bat on bat.batchid = que.batchid and bat.Status = 1     
 Where exists (Select 1 from #ProdRptAssociateWiseTrans where UserId = cm.FTE_Id )    
 Group by cm.FTE_Id,RebuttalStatus   
    
 insert into #AssociateQCErrorCount(FTE_Id,ErrCount,ErrInReview)    
 select cm.FTE_Id,sum(isnull(ErrCount,0)) as ErrCount
 /*,case when RebuttalStatus=1 then Sum(isnull(trn.ErrCount,0)) else 0 end ErrDone  */
 ,case when isnull(RebuttalStatus,2)=2 then Sum(isnull(trn.ErrCount,0)) else 0 end ErrInReview 
 from TRN_kOFF_tBatchQCTran trn     
 inner join TRN_kOFF_tBatchQCComments cm on cm.BatchProcessId =  trn.BatchProcessId and CAST(cm.CreatedDt as date) between @FromDate and @ToDate     
 inner join TRN_kOFF_tBatchQueue as que on que.BatchProcessId = cm.BatchProcessId-- and que.ServiceId = @batchSErviceId    
 inner join TRN_kOFF_tBatches as bat on bat.batchid = que.batchid and bat.Status = 1     
 Where exists (Select 1 from #ProdRptAssociateWiseTransQC where UserId = cm.FTE_Id )    
 Group by cm.FTE_Id,RebuttalStatus   

 insert into #EntryAssociateQCedTransCount(FTE_Id,TransCount)     
 select cm.FTE_Id, sum(TransValue) as QcedTrans from TRN_kOFF_tBatchQCMaster mas     
 inner join TRN_kOFF_tBatchQCComments cm on cm.BatchProcessId =  mas.BatchProcessId and CAST(cm.CreatedDt as date) between @FromDate and @ToDate     
 inner join TRN_kOFF_tBatchQueue as que on que.BatchProcessId = cm.BatchProcessId-- and que.ServiceId = @batchSErviceId    
 inner join TRN_kOFF_tBatches as bat on bat.batchid = que.batchid and bat.Status = 1     
 Where exists (Select 1 from #ProdRptAssociateWiseTrans  where UserId = cm.FTE_Id )    
 Group by cm.FTE_Id     
    
 update  ulist    
 set ulist.Active = 1,ulist.UserType= 1     
 from #UserCustomerList ulist     
 inner join #ProdRptAssociateWiseTrans trn on trn.UserId = ulist.UserId    
    
 update  ulist    
 set ulist.Active = 1,ulist.UserType =2     
 from #UserCustomerList ulist     
 inner join #ProdRptAssociateWiseTransQc trn on trn.UserId = ulist.UserId    
    
 update  ulist    
 set ulist.Active = 1,ulist.UserType =3     
 from #UserCustomerList ulist     
 inner join #ProdRptAssociateWiseTrans trn on trn.UserId = ulist.UserId    
 inner join #ProdRptAssociateWiseTransQc trnqc on trnqc.UserId = ulist.UserId    
 update  #ProdRptAssociateWiseTransQc  set  QcTransCnt = 0     
    
    
 /*select  distinct tgt.UserId,isnull(sum(tgt.ProductionTarget),0) as ProductionTarget  into #Associate_Target     
 from ADM_AssociateTarget tgt    
 inner  join      
 (select distinct UserId from  #ProdRptAssociateWiseTrans) tmp on tmp.UserId = tgt.UserId     
 where  tgt.EntryDate between @FromDate and @ToDate and tgt.IsWorkingDay =1       
 group by tgt.UserId*/    
    
 Select UserId,SUM(ProductionTarget) as ProductionTarget    
 into #Associate_Target     
 From    
 (    
 SELECT UserId,EntryDate,Max(ProductionTarget)ProductionTarget      
 from ADM_AssociateTarget tgt    
 Where EntryDate between @FromDate and @ToDate and tgt.IsWorkingDay =1       
 and exists (Select 1 from #ProdRptAssociateWiseTrans Where UserId = tgt.UserId)    
 group by userid,EntryDate    
 )x    
 Group by UserId    
    
 select distinct acc.UserId ,--isnull(acc.ErrorPercentage,0)     
 1 as ErrorTarget    
 into  #Associate_ErrorTarget   from ADM_AccessTarget acc    
 inner join (select distinct UserId from #ProdRptAssociateWiseTrans) tmp on tmp.UserId = acc.UserId      
 group  by acc.ErrorPercentage,acc.UserId     
     
    
 Declare @EntryServiceCollection varchar(max)     
 Declare @InsertServiceColumns varchar(max)    
 Declare @SumEntryServiceCollection varchar(max)    
 if OBJECT_ID('tempdb..#ProdResult') is not null drop table #ProdResult    
 Create table #ProdResult(SNo int,[Process Type] varchar(75),[Associate] varchar(75),[Batch Count] varchar(max)    
 ,[Total Raw Trans] int,[Factor Total] decimal(25,2),[Target] int,[QcTrans Count] int,[Error] int,[Error Target] decimal(25,2),    
 [Error achived] decimal(25,2),[Production %] decimal(25,2),[ColHead] varchar(5),ResultType int,ErrorInReview int)     
     
 Declare @tColname varchar(100)    
 Declare cur cursor for     
 Select ServiceName from (    
 Select ServiceName from #ProdRptAssociateWiseTrans    
 union    
 Select ServiceName from #ProdRptAssociateWiseTransQc    
 ) as t Group by t.ServiceName Order by t.ServiceName    
 OPen cur     
 while 1=1    
 begin    
 fetch next from cur into @tColName    
 if @@FETCH_STATUS = -1 break    
 Set @qry = ' Alter table #ProdResult Add [' + @tColname + '] int '    
 Exec (@qry)    
 end    
 close cur    
 Deallocate cur    
     
 Set @EntryServiceCollection = (Select     
 ',Sum(Case when ServiceId = '+Convert(varchar,ServiceId)+' then EntryTransCnt else 0 end) as ['+ServiceName +']'    
 from (Select ServiceId,ServiceName from #ProdRptAssociateWiseTrans    
 union    
 Select ServiceId,ServiceName from #ProdRptAssociateWiseTransQc    
 ) as t Group by ServiceId,t.ServiceName Order by t.ServiceName    
 for xml path('')    
 )      
     
 Set @SumEntryServiceCollection = (Select     
 ',Sum(['+ServiceName +'])'    
 from (Select ServiceId,ServiceName from #ProdRptAssociateWiseTrans    
 union    
 Select ServiceId,ServiceName from #ProdRptAssociateWiseTransQc    
 ) as t Group by ServiceId,t.ServiceName Order by t.ServiceName    
 for xml path('')    
 )       
      
 set @InsertServiceColumns = (Select     
 ',['+ServiceName +'] '    
 from (Select ServiceId,ServiceName from #ProdRptAssociateWiseTrans    
 union    
 Select ServiceId,ServiceName from #ProdRptAssociateWiseTransQc    
 ) as t Group by ServiceId,t.ServiceName Order by t.ServiceName    
 for xml path('')    
 )      
     
 Set @EntryServiceCollection = ISNULL(@EntryServiceCollection,'')    
 Set @InsertServiceColumns = ISNULL(@InsertServiceColumns,'')        
     
 Set @Qry = '     
 insert into #ProdResult(SNo,[Process Type],[Associate],[Batch Count]'+@InsertServiceColumns+',[Total Raw Trans],    
 [Factor Total],[Target],[QcTrans Count],[Error],[ErrorInReview],[Error Target],[Error achived],[Production %],[ColHead],ResultType)    
 Select Convert(varchar,ROW_NUMBER() over(order by [Associate])) as [SNo]    
 ,x.*     
 ,case when [Target] > 0.00 then  Convert(Decimal(10,2),((x.[Factor Total]/[Target])*100)) else 0 end  as [Production %]     
 ,Convert(varchar(5),'''') as [ColHead]    
 ,0     
 from    
 (    
  Select ''Entry'' as [Process Type]    
  ,ucust.Nt_UserName as [Associate]     
  ,case when (select count(distinct batchId) from #ProdRptAssociateWiseTrans  where UserId =convert(varchar(500),ucust.UserId)) > 0     
  then ''<a href="#" Onclick="return OpenSubReport(''+'+'cast(ucust.UserId  as varchar)+''' + ',' + ''' +cast(1 as varchar)'+'+'')">''+'+'(select convert(varchar(50), count( distinct  batchId ))    
  from #ProdRptAssociateWiseTrans  where UserId =convert(varchar(500),ucust.UserId ))'+'+''</a>'' else convert(varchar,0) end as [Batch Count]       
  ' + @EntryServiceCollection +  '      
  ,isnull(sum(EntryTransCnt),0)as [Total Raw Trans]     
  ,isnull(Sum(EntryTransCnt * EntryFactorPer),0) as [Factor Total]     
  ,isnull((select top 1 isnull(ProductionTarget,0) from #Associate_Target d where d.UserId = ucust.UserId),0.00)  as [Target]     
  ,isnull((select top 1 isnull(TransCount,0) from #EntryAssociateQCedTransCount   c where c.FTE_Id = ucust.UserId),0) as [QcTrans Count]    
  ,(select top 1 isnull(ErrCount,0) from #AssociateEntryErrorCount  c where c.FTE_Id = ucust.UserId)  as [Error]
  ,(select top 1 isnull(ErrInReview,0) from #AssociateEntryErrorCount  c where c.FTE_Id = ucust.UserId)  as [ErrorInReview]
  ,(select top 1 isnull(ErrorTarget,0) from #Associate_ErrorTarget d where d.UserId = ucust.UserId)  as [Error Target]      
  ,case when (select top 1 isnull(TransCount,0) from #EntryAssociateQCedTransCount c where c.FTE_Id = ucust.UserId) > 0 then    
  Convert(Decimal(25,2),((select top 1  isnull(ErrCount,0) from #AssociateEntryErrorCount  e where e.FTE_Id = ucust.UserId)/    
  CONVERT(decimal(25,2),(select top  1  isnull(TransCount,0) from #EntryAssociateQCedTransCount tt where tt.FTE_Id = ucust.UserId)))*100.0)  else 0.00 end as [Error achived]       
  from #UserCustomerList ucust     
  left join #ProdRptAssociateWiseTrans as t on t.UserId = ucust.UserId    
  where ucust.Active =1 and ucust.UserType in (1,3)    
  Group by ucust.Nt_UserName ,ucust.UserId,t.funt    
 )x    
  '    
     
 exec (@qry)    
 Set @Qry = '     
 if( select COUNT(*)  from #ProdResult where [Process Type] =''Entry'' )> 0    
 begin     
   insert into #ProdResult(SNo,[Process Type],[Associate],[Batch Count]'+@InsertServiceColumns+',[Total Raw Trans],[Factor Total],[Target],[QcTrans Count],[Error],    
   [ErrorInReview],[Error Target],[Error achived],[Production %],[ColHead],ResultType)    
    
   select ''''     
   ,''Entry'' as [Process Type]    
   ,''Grand Total'' as [Associate]    
   ,(select convert(varchar(50), count( distinct  batchId )) from #ProdRptAssociateWiseTrans ) as [Batch Count]    
   ' + @SumEntryServiceCollection +  '    
   ,sum( isnull([Total Raw Trans],0)) as  [Total Raw Trans]    
   ,sum(isnull([Factor Total],0) ) as [Factor Total]     
   ,sum(isnull([Target],0)) as [Target]    
   ,sum(isnull([QcTrans Count],0)) as [QcTrans Count]    
   ,sum(isnull([Error],0)) as [Error] 
   ,sum(isnull([ErrorInReview],0)) as [ErrorInReview]    
   ,sum(isnull([Error Target],0)) as [Error Target]     
   ,sum(isnull([Error achived],0)) as [Error achived]      
   ,sum(isnull([Production %],0)) as [Production %]    
   ,Convert(varchar(5),''G'') as [ColHead]    
   ,1 as ResultType    
   from #ProdResult where [Process Type] =''Entry''       
 end    
 '    
 exec (@qry)    
 Set @Qry = '      
 insert into #ProdResult(SNo,[Process Type],[Associate],[Batch Count]'+@InsertServiceColumns+',[Total Raw Trans],    
 [Factor Total],[Target],[QcTrans Count],[Error],[ErrorInReview],[Error Target],[Error achived],[Production %],[ColHead],ResultType)    
    
 Select Convert(varchar,ROW_NUMBER() over(order by [Associate])) as [SNo]    
 ,x.*    
 ,case when [Target] > 0.00  then  Convert(Decimal(10,2),((x.[Factor Total]/[Target])*100)) else 0 end  as [Production %]     
 ,Convert(varchar(5),'''') as [ColHead]    
 ,2    
 from    
 (    
  Select ''Audit'' as [Process Type]    
  ,ucust.Nt_UserName as [Associate]       
  ,case when (select count(distinct batchId) from #ProdRptAssociateWiseTransQC  where UserId =convert(varchar(500),ucust.UserId)) > 0     
  then ''<a href="#" Onclick="return OpenSubReport(''+'+'cast(ucust.UserId  as varchar)+''' + ',' + ''' +cast(2 as varchar)'+'+'')">''+'+'(select convert(varchar(50), count( distinct  batchId ))     
  from #ProdRptAssociateWiseTransQc  where UserId =convert(varchar(500),ucust.UserId ))'+'+''</a>'' else convert(varchar,0) end as [Batch Count]     
  ' + @EntryServiceCollection +  '      
  ,sum(EntryTransCnt)as [Total Raw Trans]     
  ,Sum(EntryTransCnt * EntryFactorPer) as [Factor Total]       
  ,(select top 1 isnull(ProductionTarget,0) from #Associate_Target d where d.UserId = ucust.UserId)  as [Target]    
  ,sum(QcTransCnt) as [QcTrans Count]     
  ,(select top 1 isnull(ErrCount,0) from #AssociateQCErrorCount  c where c.FTE_Id = ucust.UserId)  as [Error]   
  ,(select top 1 isnull(ErrInReview,0) from #AssociateQCErrorCount  c where c.FTE_Id = ucust.UserId)  as [ErrorInReview]       
  ,(select top 1 isnull(ErrorTarget,0) from #Associate_ErrorTarget d where d.UserId = ucust.UserId)  as [Error Target]     
  ,case when sum(EntryTransCnt)> 0 then    
  Convert(Decimal(25,2),((select (isnull(ErrCount,0)) from #AssociateQCErrorCount aqc where aqc.FTE_Id =ucust.UserId )/    
  CONVERT(decimal(25,2),sum(EntryTransCnt)))*100 ) else 0 end as [Error achived]    
  from #UserCustomerList ucust     
  left join #ProdRptAssociateWiseTransQc as t on t.UserId = ucust.UserId       
  where ucust.Active =1 and ucust.UserType in (2,3)    
  Group by ucust.Nt_UserName ,ucust.UserId,t.funt    
 )x    
 '    
     
  exec (@qry)    
 Set @Qry = '
  if( select COUNT(*)  from #ProdResult where [Process Type] =''Audit'' )> 0    
  begin    
   insert into #ProdResult(SNo,[Process Type],[Associate],[Batch Count]'+@InsertServiceColumns+',[Total Raw Trans],    
   [Factor Total],[Target],[QcTrans Count],[Error],[ErrorInReview],[Error Target],[Error achived],[Production %],[ColHead],ResultType)    
   
   select ''''     
   ,''Entry'' as [Process Type]    
   ,''Grand Total'' as [Associate]    
   ,(select convert(varchar(50), count( distinct  batchId )) from #ProdRptAssociateWiseTransQC ) as [Batch Count]    
   ' + @SumEntryServiceCollection +  '    
   ,sum( isnull([Total Raw Trans],0)) as  [Total Raw Trans]    
   ,sum(isnull([Factor Total],0) ) as [Factor Total]     
   ,sum(isnull([Target],0)) as [Target]    
   ,sum(isnull([QcTrans Count],0)) as [QcTrans Count]    
   ,sum(isnull([Error],0)) as [Error]  
   ,sum(isnull([ErrorInReview],0)) as [ErrorInReview]      
   ,sum(isnull([Error Target],0)) as [Error Target]     
   ,sum(isnull([Error achived],0)) as [Error achived]      
   ,sum(isnull([Production %],0)) as [Production %]    
   ,Convert(varchar(5),''G'') as [ColHead]    
   ,3 as ResultType    
   from #ProdResult  where [Process Type] =''Audit''     
 end'     
  exec (@qry)    
  
  
  Set @qry = 'select SNo,[Process Type],[Associate],[Batch Count]'+@InsertServiceColumns+',[Total Raw Trans],    
  [Factor Total],[Target],[QcTrans Count],[Error],[ErrorInReview],[Error Target],[Error achived],[Production %],[ColHead]     
  into #ConsolProductionRptResult    
  from  #ProdResult order by ResultType      
  
      
 Exec FilterTable               
 @DbName = ''tempdb''        
 ,@TblName = ''#ConsolProductionRptResult''        
 ,@SearchStr = '''+ @SearchStr +'''    
 ,@SearchPattern ='''+ @SearchPattern +'''        
 ,@OrderStr = ''''      
          
 if OBJECT_ID(''tempdb..#ConsolProductionRptResult'') is not null drop table #ConsolProductionRptResult          
 if OBJECT_ID(''tempdb..#ProdRptAssociateWiseTrans'') is not null drop table #ProdRptAssociateWiseTrans    
 if OBJECT_ID(''tempdb..#ProdRptAssociateWiseTransQc'') is not null drop table #ProdRptAssociateWiseTransQc    
 if OBJECT_ID(''tempdb..#Associate_Target'') is not null drop table #Associate_Target    
 if OBJECT_ID(''tempdb..#Associate_ErrorTarget'') is not null drop table #Associate_ErrorTarget    
 if OBJECT_ID(''tempdb..#ProdResult'') is not null drop table #ProdResult'    
     
 exec (@qry)    
End 

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pConsolidatedProductionReport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pConsolidatedProductionReport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pConsolidatedProductionReport] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pConsolidatedProductionReport] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pConsolidatedProductionReport] TO [DB_DMLSupport]
    AS [dbo];

