﻿Create procedure  [dbo].[ADM_LoginWinAuthentication]      
(      
@UserName varchar(100),
@UserId int
)      
As      
Begin    
if( isnull(@UserName,'')<>'')
Begin
	if( select COUNT(userid) from ARC_REC_ATHENA..ARC_REC_USER_INFO (nolock)  usr where NT_USERNAME =@UserName)>0
	Begin
	Select 'Logged-in Successfully' as Result, 1 as StatusId, usr.USERID,usr.FIRSTNAME + ' '+  usr.LASTNAME as FullName,
	case when CustomerId=15 then 25 else CustomerId end as CustomerId,InternalName as CustomerName,usrlob.LOB,usr.LOB as LobId,cus.CmpKey as DBPrefix
	from ARC_REC_ATHENA..ARC_REC_USER_INFO (nolock)  usr
	inner join ADM_Customer (nolock) cus on usr.CLIENT_ID=cus.CustomerId
	left join ARC_REC_ATHENA..ARC_REC_LOB_INFO (nolock)  usrlob on isnull(usr.LOB,1)=usrlob.Id
	where NT_USERNAME =@UserName and usr.ACTIVE=1
	End
	else
	Begin
	Select 'Logged-in failed' as Result,2 as StatusId, 0 as USERID, ' '  as FullName,0 as CustomerId,'' as CustomerName,'0' as  LOB,'' as DBPrefix
	End
End
Else
Begin
	if(select COUNT(userid) from ARC_REC_ATHENA..ARC_REC_USER_INFO (nolock)  usr where USERID =@UserId)>0
	Begin
	Select 'Logged-in Successfully' as Result, 1 as StatusId, usr.USERID,usr.FIRSTNAME + ' '+  usr.LASTNAME as FullName,
	case when CustomerId=15 then 25 else CustomerId end as CustomerId,InternalName as CustomerName,usrlob.LOB,usr.LOB as LobId,cus.CmpKey as DBPrefix
	from ARC_REC_ATHENA..ARC_REC_USER_INFO (nolock)  usr
	inner join ADM_Customer (nolock)  cus on usr.CLIENT_ID=cus.CustomerId
	left join ARC_REC_ATHENA..ARC_REC_LOB_INFO (nolock)  usrlob on isnull(usr.LOB,1)=usrlob.Id
	where usr.userid =@UserId and usr.ACTIVE=1
	End
	else
	Begin
	Select 'Logged-in failed' as Result,2 as StatusId, 0 as USERID, ' '  as FullName,0 as CustomerId,'' as CustomerName,'0' as  LOB,'' as DBPrefix
	End	   
End
End



GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_LoginWinAuthentication] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_LoginWinAuthentication] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_LoginWinAuthentication] TO [DB_DMLSupport]
    AS [dbo];

