﻿CREATE Procedure CUS_kWISCO_pBatchImport
(
	@SO_Number varchar(50),
	@SO_Branch_Office varchar(150),
	@Insurance_Pri_Payor varchar(150),
	@Patient_ID varchar(50),
	@WIP_State varchar(100) ,
	@WIP_Assigned_To varchar(100),
	@WIP_Date_Needed varchar(50),
	@WIP_Days_In_State varchar(10),
	@WIP_Completed varchar(10),
	@SO_User_3 varchar(50),
	@SO_User_4 varchar(50),
	@NickName varchar(100),
	@ServiceId int
)
as
BEGIN
    --insert into  CUS_kWISCO_tBatchImportTable([SO_Number],[SO_Branch Office],[Insurance_Pri Payor],[Patient_ID],[WIP_State]
    --            ,[WIP_Assigned To],[WIP_Date Needed],[WIP_Days In State],[WIP_Completed],[SO_User 3],[SO_User 4],[NickName],ServiceId)
    --select @SO_Number,@SO_Branch_Office,@Insurance_Pri_Payor,@Patient_ID,@WIP_State,@WIP_Assigned_To,@WIP_Date_Needed,
    --             @WIP_Days_In_State,@WIP_Completed,@SO_User_3,@SO_User_4,@NickName,@ServiceId  
                 
    insert into  CUS_kWISCO_tBatchImportTable([SO_Number],[SO_Branch Office],[Patient_ID],[NickName],ServiceId)
    select @SO_Number,@SO_Branch_Office,@Patient_ID,@NickName,@ServiceId        
    
END



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kWISCO_pBatchImport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kWISCO_pBatchImport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kWISCO_pBatchImport] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kWISCO_pBatchImport] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kWISCO_pBatchImport] TO [DB_DMLSupport]
    AS [dbo];

