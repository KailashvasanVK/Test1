﻿CREATE Procedure  ADM_GetKnowlInfo --'KnolPath',94
(
@CtlID varchar(25),
@CustomerId int
)
as
begin
 
 select CtlValue ,(select Client_Name from ARC_REC_Athena..ARC_FIN_CLIENT_INFO where  Client_Id=@CustomerId) AS CustomerName
 from ADM_SoftControl  where CtlID=''+@CtlID+''
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_GetKnowlInfo] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetKnowlInfo] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetKnowlInfo] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_GetKnowlInfo] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetKnowlInfo] TO [DB_DMLSupport]
    AS [dbo];

