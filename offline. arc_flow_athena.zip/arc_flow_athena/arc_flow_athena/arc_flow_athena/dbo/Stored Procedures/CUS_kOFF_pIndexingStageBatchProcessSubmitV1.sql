﻿CREATE Procedure CUS_kOFF_pIndexingStageBatchProcessSubmitV1  
(  
@BatchNo varchar(100)  
,@AssignedTo int  
)  
As  
Begin  
/*  
Created by : mallikarjun.nam   
Created dt : 2017-02-10  
Purpose : Batch Entry completed status at Indexing pahse  
*/  
      Declare @BatchId int  
             ,@FactorExceptionPosting float /** ExceptionPosting (360) transaction count */      
             ,@LocationId int  
             ,@ShiftId int  
             ,@ServiceId int  
  
      Select @BatchId=batchId,@ServiceId=ServiceId from trn_koff_tbatches where batchno=@BatchNo and status=1  
        
      Set @LocationId  =(Select LocationId from arc_rec_athena.dbo.arc_rec_User_Info where UserId=@AssignedTo)  
      Set @ShiftId = (Select Top 1 SHIFT_ID from ARC_REC_ATHENA.dbo.ARC_REC_SHIFT_TRAN where USERID = @AssignedTo and Effect_DATE <= GETDATE() Order by Effect_DATE desc)  
      Set @FactorExceptionPosting=(Select EntryExceptionPosting from ADM_FactorWaterTown   
      Where ServiceGroupId = @ServiceId and CONVERT(date,getdate()) between EffectiveFrom and isnull(EffectiveTo,GETDATE()))  
  
      /*Validating whether curent batch is already allocated to any user or not*/  
      if(Select  count(BatchId) from TRN_kOFF_tBatchqueue(nolock) where BatchId=@BatchId and Statusid=0)>0  
      Begin  
            Update TRN_kOFF_tBatchqueue Set Statusid=1,Assigned=@AssignedTo where BatchId=@BatchId and Statusid=0  
            Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry,LocationId,ShiftId,FactorTrans)  
            Select BatchProcessId,1,360,1,null,@AssignedTo,getdate(),BatchId,ServiceId,ClientId,0,@LocationId,@ShiftId,@FactorExceptionPosting from  TRN_kOFF_tBatchqueue where BatchId=@BatchId  
                    
            Insert into TRN_kOFF_tBatchFlow(BatchId,BatchProcessId,CreatedBy,CreatedDt,StatusId,Comments)      
            Select BatchId,BatchProcessId,@AssignedTo,getdate(),1,'Batch Assigned' from  TRN_kOFF_tBatchqueue where BatchId=@BatchId  
                  
            Insert into TRN_kOFF_tBatchFlow(BatchId,BatchProcessId,CreatedBy,CreatedDt,StatusId,Comments)      
            Select BatchId,BatchProcessId,@AssignedTo,getdate(),6,'Entry Completed' from  TRN_kOFF_tBatchqueue where BatchId=@BatchId  
                     
            Update TRN_kOFF_tBatchqueue Set Statusid=6,Assigned=0 where BatchId=@BatchId and Statusid=1
            Update trn_koff_tbatches Set PostedDt=getdate() where BatchId=@BatchId   
                  
            /*Validate Direct upload*/  
            if(select count(*) from TRN_kOFF_tDirectupload where BatchId=@BatchId and Status=1)>0  
            Begin  
                  Update TRN_kOFF_tBatchqueue Set Statusid=13,Assigned=0 where BatchId=@BatchId and Statusid=6  
                    
                  Insert into TRN_kOFF_tBatchFlow(BatchId,BatchProcessId,CreatedBy,CreatedDt,StatusId,Comments)      
                  Select BatchId,BatchProcessId,@AssignedTo,getdate(),13,'Batch direct uploaded by System' from  TRN_kOFF_tBatchqueue where BatchId=@BatchId  
                    
                  Update trn_koff_tbatches Set UploadDt=getdate() where BatchId=@BatchId  
            End  
      End  
End  

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kOFF_pIndexingStageBatchProcessSubmitV1] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kOFF_pIndexingStageBatchProcessSubmitV1] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kOFF_pIndexingStageBatchProcessSubmitV1] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kOFF_pIndexingStageBatchProcessSubmitV1] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kOFF_pIndexingStageBatchProcessSubmitV1] TO [DB_DMLSupport]
    AS [dbo];

