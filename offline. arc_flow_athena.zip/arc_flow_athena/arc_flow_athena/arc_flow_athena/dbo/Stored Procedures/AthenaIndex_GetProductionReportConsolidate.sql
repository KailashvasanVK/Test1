﻿  
/*    
Purpose : Get Consolidate production by User _ BatchIndexing  
Created Date : Apr 06,2015    
exec AthenaIndex_GetProductionReportConsolidate '2014/11/14'  
 */    
CREATE Proc AthenaIndex_GetProductionReportConsolidate  
@gDate datetime=NULL    
as    
BEGIN    
  
/*  
---Get Incomplete batch info  
*/  
SELECT b.userinfo,ISNULL(completed,0) Completed,ISNULL(InComplete,0) InComplete from  
(  
select userinfo,count(userinfo) Completed  from batchIndex_TrackBatches(nolock)   
 where   CompletedDate is not null and CONVERT(varchar,CompletedDate,103)=convert(varchar,@gDate,103)  
group by userinfo)a  right join  
(select userinfo,count(userinfo) InComplete  from batchIndex_TrackBatches(nolock)   
 where  CompletedDate is null --and CONVERT(varchar,CompletedDate,103)=convert(varchar,@gDate,103)  
group by userinfo)b on a.userinfo=b.userinfo  
  
Union  
  
---Get Complete batch info  
SELECT a.userinfo,ISNULL(completed,0) Completed,ISNULL(InComplete,0) InComplete from  
(  
select userinfo,count(userinfo) Completed  from batchIndex_TrackBatches(nolock)   
 where  CompletedDate is not null and CONVERT(varchar,CompletedDate,103)=convert(varchar,@gDate,103)  
group by userinfo)a  left join  
(select userinfo,count(userinfo) InComplete  from batchIndex_TrackBatches(nolock)   
 where  CompletedDate is null --and CONVERT(varchar,CompletedDate,103)=convert(varchar,@gDate,103)  
group by userinfo)b on a.userinfo=b.userinfo  
  
END  


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AthenaIndex_GetProductionReportConsolidate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AthenaIndex_GetProductionReportConsolidate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AthenaIndex_GetProductionReportConsolidate] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AthenaIndex_GetProductionReportConsolidate] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AthenaIndex_GetProductionReportConsolidate] TO [DB_DMLSupport]
    AS [dbo];

