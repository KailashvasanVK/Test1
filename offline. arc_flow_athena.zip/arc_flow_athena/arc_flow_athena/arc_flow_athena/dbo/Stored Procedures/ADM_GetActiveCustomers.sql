﻿CREATE procedure [dbo].[ADM_GetActiveCustomers]          
     @CustomerId int=0              
As                
Begin                
/*                  
Purpose           : To get active customer list              
Created By        : Bhuvaneswari                  
Created Date      : 1 Apr 2013                  
Impact to         : Field.aspx,ProfileSetup.aspx ,ClientCreation.aspx,UserCustomer,FlowHeader                   
*/               
if(@CustomerId > 0)        
begin         
select cu.CustomerId, cu.InternalName CustomerName, cu.FullName, cu.FinName, cu.FinEmailId, cu.FinPhone1, cu.FinPhone2, cu.FinFax,            
 cu.ContractStartDt, cu.ContractEndDt, cu.Discount, cu.TAT, cu.Quality, cu.Status, cu.CreatedBy, cu.CreatedDt,            
  cu.CustomerAddress, cu.FullName, cu.InternalName, cu.ExternalName,(select ISNULL(COUNT(ClientId),0) from ADM_Client where CustomerId = cu.CustomerId) as NumberOf_clients            
from ADM_Customer cu            
            
where cu.Status = 1  and cu.CustomerId = @CustomerId and ISNULL(cmpkey,'') <> ''          
end        
else        
begin        
select cu.CustomerId, cu.InternalName CustomerName, cu.FullName, cu.FinName, cu.FinEmailId, cu.FinPhone1, cu.FinPhone2, cu.FinFax,            
 cu.ContractStartDt, cu.ContractEndDt, cu.Discount, cu.TAT, cu.Quality, cu.Status, cu.CreatedBy, cu.CreatedDt,            
  cu.CustomerAddress, cu.FullName, cu.InternalName, cu.ExternalName,(select ISNULL(COUNT(ClientId),0) from ADM_Client where CustomerId = cu.CustomerId) as NumberOf_clients            
from ADM_Customer cu            
            
where cu.Status = 1  and ISNULL(cmpkey,'') <> ''  
end        
end

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_GetActiveCustomers] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetActiveCustomers] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetActiveCustomers] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_GetActiveCustomers] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetActiveCustomers] TO [DB_DMLSupport]
    AS [dbo];

