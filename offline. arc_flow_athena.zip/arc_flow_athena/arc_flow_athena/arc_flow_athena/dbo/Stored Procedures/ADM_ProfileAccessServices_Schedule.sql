﻿CREATE Procedure [dbo].[ADM_ProfileAccessServices_Schedule]   
 As   
/*   
Created by : Karthik M7   
Created on : 19 Nov 2015   
Impact to  : ProfileSetup.aspx   
Purpose    : To save the user customer wise service details.   
*/  
Begin  
Set transaction isolation level read uncommitted

	IF ( (select count(*)  from [ADM_AccessServicesSchedule]) > 0)
	BEGIN

		declare @CurrentDateTime as datetime =  getdate()
		IF OBJECT_ID('tempdb..#TempServices') IS NOT NULL DROP TABLE #TempServices
		CREATE TABLE #TempServices ([UserId] [int] NULL,[CustomerId] [int] NULL)


		insert into #TempServices ([UserId],[CustomerId])
		select distinct UserId,CustomerId from [ADM_AccessServicesSchedule] where ScheduledDt <=  @CurrentDateTime


		Insert into ADM_AccessServicesLog (UserId,CustomerId,ServiceId,CreatedBy,CreatedDt,AccServiceId)      
		Select ACSER.UserId,ACSER.CustomerId,ServiceId,CreatedBy,CreatedDt,AccServiceId 
		From  ADM_AccessServices ACSER
		INNER JOIN #TempServices TempACSER
		ON TempACSER.USERID = ACSER.USERID and TempACSER.CustomerId  = ACSER.CustomerId 
				

		DELETE ACSER FROM [ADM_AccessServices] ACSER
		INNER JOIN #TempServices TempACSER
		ON TempACSER.USERID = ACSER.USERID and TempACSER.CustomerId  = ACSER.CustomerId 


		Insert into ADM_AccessServices(UserId,CustomerId,ServiceId,CreatedDt,CreatedBy)  
		select UserId,CustomerId,ServiceId,getdate(),CreatedBy 
		from  [ADM_AccessServicesSchedule]  where  ScheduledDt <=  @CurrentDateTime 


		insert into ADM_AccessTarget(Userid,CustomerId,ServiceId,ProcessTargetId,QcTargetId,PTLevelId,QCLevelId,CreatedBy,CreatedDt) 
		select Userid,CustomerId,ServiceId,0,0,0,0,CreatedBy,GETDATE()   
		from [ADM_AccessServicesSchedule] a 
		where  a.ScheduledDt <=  @CurrentDateTime 
		and  not exists (select 'X' from ADM_AccessTarget where Userid = CAST(a.Userid as int) and ServiceId = CAST(a.ServiceId as int) and CustomerId = a.CustomerId )  


		insert into ADM_AccessTargetQC(Userid,CustomerId,ServiceId,QualityTargetId,QALevelId,CreatedBy ,CreatedDt)  
		Select Userid,CustomerId,ServiceId,0,0,CreatedBy,GETDATE() 
		from [ADM_AccessServicesSchedule] a 
		where  a.ScheduledDt <=  @CurrentDateTime 
		and not exists (select 'X' from ADM_AccessTargetQC where Userid = CAST(a.Userid as int) and ServiceId = CAST(a.ServiceId as int) and CustomerId = a.CustomerId ) 



		INSERT Into ADM_AccessServicesScheduleLog(UserId,CustomerId,ServiceId,ScheduledDt,CreatedBy,CreatedDt,LogCreatedDt,StatusInfo)
		SELECT   ACTG.USERID, ACTG.CustomerId , ServiceId,ScheduledDt,CreatedBy,CreatedDt,GETDATE(),'Scheduled' FROM  [ADM_AccessServicesSchedule] ACTG where  ScheduledDt <=  @CurrentDateTime 


		delete from  [ADM_AccessServicesSchedule] where  ScheduledDt <=  @CurrentDateTime
			
	END
END

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ProfileAccessServices_Schedule] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileAccessServices_Schedule] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileAccessServices_Schedule] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ProfileAccessServices_Schedule] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileAccessServices_Schedule] TO [DB_DMLSupport]
    AS [dbo];

