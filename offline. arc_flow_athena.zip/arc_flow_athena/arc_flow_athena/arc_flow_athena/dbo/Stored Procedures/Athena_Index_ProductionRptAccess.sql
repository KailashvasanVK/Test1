﻿
/*Created At Nov 12,2014
Batch Indexing Application
By Noor
*/

Create Proc Athena_Index_ProductionRptAccess  
@NtUsername varchar(200)  
as  
Begin  
IF exists(SELECT 1 From BatchIndexUserProductionAccess where NtUsername=@NtUsername)  
SELECT 1 as Status  
ELSE  
SELECT 0 as Status  
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_ProductionRptAccess] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_ProductionRptAccess] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_ProductionRptAccess] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_ProductionRptAccess] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_ProductionRptAccess] TO [DB_DMLSupport]
    AS [dbo];

