﻿CREATE proc Merge_GetTrackDetails (@MergeType varchar(30),@LogStatus varchar(30),@SystemIP varchar(20))      
as       
begin      
Declare @Status varchar(20)      
Select top 1 @Status=LogStatus  from Merge_LoginTrack where mergeType=@MergeType order by LoginDateTime desc  
      
if(isnull(@Status,'')<>'LogIn')  
insert into Merge_LoginTrack values (@MergeType,@LogStatus,getdate(),@SystemIP)      
Select @Status      
End      
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Merge_GetTrackDetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Merge_GetTrackDetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Merge_GetTrackDetails] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Merge_GetTrackDetails] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Merge_GetTrackDetails] TO [DB_DMLSupport]
    AS [dbo];

