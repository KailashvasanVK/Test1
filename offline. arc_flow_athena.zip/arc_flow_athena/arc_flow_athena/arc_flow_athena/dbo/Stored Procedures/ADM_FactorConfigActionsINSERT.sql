﻿
CREATE Procedure [dbo].[ADM_FactorConfigActionsINSERT]   
(  
@Action varchar(100)='', 
@CustomerId INT=0,  
@ClientId INT=0,  
@ServiceId INt=0,  
@FactorName varchar(100)='',  
@FactorValue Decimal(9,2)=0,  
@EffectiveFrom varchar(50)='',
@CreatedBy INT=0,  
@FactorId int=0,
@FactorType int,
@FID INT OUTPUT     

)  
AS  
BEGIN  
IF(@Action ='InsertFactor')      
 BEGIN  
  INSERT INTO ADM_Factor(CustomerId,ClientId,ServiceId,FactorName,FactorValue,EffectiveFrom,CreatedBy,FactorType)  
  Select @CustomerId,@ClientId,@ServiceId,@FactorName,@FactorValue,convert(varchar,@EffectiveFrom,101),@CreatedBy,@FactorType
SELECT @FID = IDENT_CURRENT('ADM_Factor') 
 END  
 END


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_FactorConfigActionsINSERT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_FactorConfigActionsINSERT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_FactorConfigActionsINSERT] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_FactorConfigActionsINSERT] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_FactorConfigActionsINSERT] TO [DB_DMLSupport]
    AS [dbo];

