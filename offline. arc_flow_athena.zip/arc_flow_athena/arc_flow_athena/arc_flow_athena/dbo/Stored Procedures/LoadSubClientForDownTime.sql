﻿
Create Procedure [dbo].[LoadSubClientForDownTime]    
(    
 @CustomerId int,    
 @UserId int,    
 @ServicegroupId varchar(max),
 @SubClientIds  varchar(max)
)    
As    
Begin    
 /*       
    Declare @CustomerId int=16,    
 @UserId int=6312,    
 @ServicegroupId varchar(max)    
   */     
if ISNULL(@SubClientIds,'')=''
Begin
 if OBJECT_ID('tempdb..#ServiceIds') is not null drop table #ServiceIds    
 Select items as ServiceId into #ServiceIds from dbo.fnSplitString(@ServicegroupId,',')        
 Select distinct cl.ClientId,cl.ClientAcmName from ADM_AccessClient (nolock)  acl    
 inner join ADM_Client (nolock)  cl on acl.ClientId=cl.ClientId and cl.CustomerId=@CustomerId    
 inner join  ADM_ServiceGroup (nolock)  sg on sg.ClientId=acl.ClientId    
 inner join #ServiceIds tmp on tmp.ServiceId =sg.ServiceGroupId    
 where acl.UserId=@UserId and acl.CustomerId=@CustomerId     
 End
 Else
 Begin
 if OBJECT_ID('tempdb..#SubClientIds') is not null drop table #SubClientIds    
 Select items as ClientId into #SubClientIds from dbo.fnSplitString(@SubClientIds,',')        
 Select distinct cl.ClientId,cl.ClientAcmName 
 from ADM_Client cl 
 inner join #SubClientIds tmp on tmp.ClientId =cl.ClientId    
 
 End
     
End 


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[LoadSubClientForDownTime] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[LoadSubClientForDownTime] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[LoadSubClientForDownTime] TO [DB_DMLSupport]
    AS [dbo];

