﻿CREATE Procedure [dbo].[ADM_CustomerClients]    
@CustomerId AS INT    
AS     
BEGIN    
 /*     
    Purpose :select  the  client details baes on the  CustomerId  
    Created By   : Kathiravan          
    Created Date : 27 April 2013          
    Impact to    :ClientCreation.aspx          
 */   
  SELECT ClientId,ClientName,ClientAcmName FROM ADM_Client WHERE CustomerId=@CustomerId and Status = 1 order by ClientAcmName 
END


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_CustomerClients] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_CustomerClients] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_CustomerClients] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_CustomerClients] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_CustomerClients] TO [DB_DMLSupport]
    AS [dbo];

