﻿create proc ReleaseBatches  @MergeBatchno As [dbo].[MergeBatchList] Readonly   
  
as  
begin  
update trn_koff_tbatches set status=1 where batchno in (select BatchNo from @mergeBatchno)  
  
End  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ReleaseBatches] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ReleaseBatches] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ReleaseBatches] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ReleaseBatches] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ReleaseBatches] TO [DB_DMLSupport]
    AS [dbo];

