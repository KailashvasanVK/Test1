﻿CREATE PROCEDURE pIndexing_BatchAllocation
( 
@UserInfo varchar(30)
)
As
Begin 
 
BEGIN TRANSACTION

DECLARE
@BatchNo varchar(30),  
@Status Int, 
@UserCount Int,
@Target Int

SET @Status = 0

SET @UserCount = (Select COUNT(id) from batchIndex_TrackBatches Where userinfo = @UserInfo and cstatus = 0 and CompletedDate Is NULL)

SET @Target = 30 - @UserCount;

DECLARE Perform_Cursor CURSOR FOR 


SELECT Top (@Target) Batchno from trn_koff_tbatches  a           
Left outer join batchIndex_TrackBatches  b on a.batchno=b.batchnum               
Left outer join arc_athena..CBO_Payerinfo ap on ap.Batch=a.BatchNo         
Where uploaddt  is null and serviceid<>363 and status=3  and b.batchnum is null    
Order by  a.Priority desc ,ScanDate asc, PgCount  desc 

OPEN Perform_Cursor  

FETCH Next FROM Perform_Cursor INTO @BatchNo 
WHILE @@FETCH_STATUS = 0
BEGIN 
 
Insert into batchIndex_TrackBatches (batchnum,userinfo,cstatus)                                        
SELECT @BatchNo,@UserInfo,0 WHERE NOT EXISTS(SELECT 1 FROM batchIndex_TrackBatches where batchnum=@BatchNo)  
 
FETCH next FROM Perform_Cursor 
INTO @BatchNo;
END;

CLOSE Perform_Cursor; 

DEALLOCATE Perform_Cursor;

SELECT  BatchID, BatchNo, tb.ScanDate AS ScanDate, b.BATCHTOTAL As DollarAmount,ISNULL(Adm.PayerId , 0) As InsuranceName,        
'' AS TaxID, '' AS NPID, '' AS PayeeNo,  FName, 0 As Complete, SubClient = SUBSTRING(tb.BatchNo,CHARINDEX('A',tb.BatchNo)+1,(LEN(tb.BatchNo)-CHARINDEX('A',tb.BatchNo))+1)   
from batchIndex_TrackBatches trb
Inner join TRN_kOFF_tBatches (nolock) tb on tb.BatchNo = trb.batchnum          
Left join  Arc_Athena..CBO_Payerinfo (nolock) cb on cb.Batch = tb.BatchNo              
Left join ADM_PayerName Adm on Adm.PayerName = cb.PAYMENTBATCHROUTE              
Left join  ARC_Athena..BatchTotal b on b.batchNum = tb.BatchNo              
Where  trb.cstatus = 0 and trb.CompletedDate IS NULL and trb.userinfo = @UserInfo

COMMIT TRANSACTION 

End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[pIndexing_BatchAllocation] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexing_BatchAllocation] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexing_BatchAllocation] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[pIndexing_BatchAllocation] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexing_BatchAllocation] TO [DB_DMLSupport]
    AS [dbo];

