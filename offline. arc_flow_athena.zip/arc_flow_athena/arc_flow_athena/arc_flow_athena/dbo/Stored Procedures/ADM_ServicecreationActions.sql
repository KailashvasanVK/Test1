﻿CREATE Procedure [dbo].[ADM_ServicecreationActions]              
@ServiceName   varchar(75)='',          
@Action   varchar(75)=''           
           
AS                
 /* Purpose      :  To check service name already exist in DB               
     Created By   : Kathiravan              
    Created Date  : 17 apirl 2013              
    Impact to     :ServiceCreation.aspx              
 */                  
 BEGIN                
 IF(@Action ='ServiceNameCheck')           
 BEGIN              
      if exists (SELECT top 1 ServiceName  FROM ADM_Service  WHERE  ServiceName=@ServiceName)            
      begin            
       SELECT 1            
      End            
      else            
      begin            
       SELECT 2            
      end              
  END     
  ELSE IF(@Action='ServiceCreationView')    
 Begin          
 Select ServiceId,ServiceName,ServiceAcmName,Description,case when FieldType = 'I' then 'Info Field' else 'Trans Field' end as FieldType           
 from ADM_Service   where Status = 1  order by ServiceName       
 End                
 END


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ServicecreationActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ServicecreationActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ServicecreationActions] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ServicecreationActions] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ServicecreationActions] TO [DB_DMLSupport]
    AS [dbo];

