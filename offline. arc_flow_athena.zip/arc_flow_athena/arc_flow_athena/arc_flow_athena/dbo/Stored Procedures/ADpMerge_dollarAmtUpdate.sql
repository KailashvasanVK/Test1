﻿ 
CREATE  proc [dbo].[ADpMerge_dollarAmtUpdate]             
as                
begin                
       
 /*                          
                      
Cretaed By     : Leela.T                      
Created Date   : 2017-03-29                        
Purpose        : Update the dollar Amt               
Ticket/SCR ID  : 1195                   
TL Verified By : Ramki               
                
                 
Implemented by : Udhdyaganesh.p          
Implemented On : 10-April-2017            
                    
Reviewd by     : Udhdyaganesh.p                   
Implemented On : 10-April-2017                        
                      
*/   
             
declare @Rowcount int,@dollarAmt Float,@batchno varchar(20) ,  @Batchid  bigint,@Pgcount int , @Processid int            
                
create table #ParentBatches                
(Id  int IDENTITY (1, 1) NOT NULL,                                                                                                  
BatchNo   Varchar(20))                  
   insert into #ParentBatches(BatchNo)                
   select distinct parentbatchno from  ARC_Flow_Athena.dbo.MergeBatchDetails where status=5                
                
   select @Rowcount=@@ROWCOUNT                
                   
   while(@Rowcount>0)                
   begin                
   select @batchno = batchno from #ParentBatches where id=@Rowcount                
             
   select @Batchid =Batchid ,@Pgcount=PgCount from ARC_Flow_Athena..TRN_kOFF_tBatches(nolock) where batchno=@batchno      
        
   select @dollarAmt=SUM(dollaramt) from ARC_Athena..batchMaster where                
   batchnum in (select ChildBatchNo from ARC_Flow_Athena..MergeBatchDetails where ParentBatchNo=@batchno)                
                   
   Update ARC_Athena..batchMaster set dollarAmt= @dollaramt where batchnum=@batchno                
                 
   Update  ARC_Flow_Athena..TRN_kOFF_tBatches set status=88, Locationid=4 where batchno=@batchno                
                
   Update ARC_Flow_Athena..MergeBatchDetails  set status=6 where parentbatchno=@batchno   
     
   update ARC_Flow_Athena..TRN_kOFF_tBatches set payerid=  (Select top 1 payerid from mergebatchdetails mrg inner join TRN_kOFF_tBatches trn  
   on trn.batchno=mrg.childbatchno where parentbatchno=@batchno) where batchno=@batchno  
     
   insert into ARC_Athena..SemiOcr_tAutomationBatchQueue values (@Batchid,@Batchno,@pgcount,0,1111,getdate())  
   select @processid=SCOPE_IDENTITY()    
     
   insert into ARC_Athena..SemiOcr_tAutomationBatchFlow values ( @Batchid,@processid,getdate(),1111,0,Null)  
                  
   set @Rowcount=@Rowcount-1                
   End                
                                                                                                      
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADpMerge_dollarAmtUpdate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADpMerge_dollarAmtUpdate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADpMerge_dollarAmtUpdate] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADpMerge_dollarAmtUpdate] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADpMerge_dollarAmtUpdate] TO [DB_DMLSupport]
    AS [dbo];

