﻿
	Create procedure ADM_GetUserLocation
	(
		@UserId int,
		@LocationId int=0
	)
	as
	begin      
	
	  /*
	   Created By :mallikarjun.nam	
	   Created Dt :2016-02-29
	   Purpose : To Search Batches in Location wise in .Manage Tile for all tabs
	  */
	  if OBJECT_ID('tempdb..#LocationIds') is not null drop table #LocationIds
		Create table #LocationIds( locationid int,LocationName varchar(50))
		if(isnull(@LocationId,0))=0
		begin 
		  insert into  #LocationIds(locationId,LocationName)
		  select uloc.locationId as locationId,locM.LocationName 
		  from (
			 select isnull(locationId,1) as locationId  from ARC_REC_Athena..ARC_REC_USER_INFO usr where USERID=@UserId and ACTIVE=1
			 union All
			 select locationId from ARC_REC_Athena..HR_LOCATIONACESS where  USERID=@UserId and ACTIVE=1 
	   		 and  locationId not in (select isnull(locationId,1) locationId from ARC_REC_Athena..ARC_REC_USER_INFO where USERID=@UserId and ACTIVE=1)
		  )uloc inner join ARC_REC_Athena..HR_LocationMaster locM on uloc.locationid=locM.LocationID
		end
		else 
		begin	
		 insert into  #LocationIds(locationId,LocationName)select  LocationID,LocationName from ARC_REC_Athena..HR_LocationMaster where locationid=@LocationId and Active=1
		end      
		select * from #LocationIds
		if OBJECT_ID('tempdb..#LocationIds') is not null drop table #LocationIds
		--select uloc.locationId,locM.LocationName  from (
		
	 --	   select locationId  from ARC_REC_Athena..ARC_REC_USER_INFO usr where USERID=@UserId and ACTIVE=1
		--   union All
		--   select locationId from ARC_REC_Athena..HR_LOCATIONACESS where  USERID=@UserId and ACTIVE=1 
		--   and  locationId not in (select locationId locationId from ARC_REC_Athena..ARC_REC_USER_INFO where USERID=@UserId and ACTIVE=1)
		
		-- )uloc inner join ARC_REC_Athena..HR_LocationMaster locM on uloc.locationid=locM.LocationID
	 end



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_GetUserLocation] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetUserLocation] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetUserLocation] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_GetUserLocation] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetUserLocation] TO [DB_DMLSupport]
    AS [dbo];

