﻿CREATE Procedure CUS_kWISCO_pBatchFlush
As
Begin
       --delete from CUS_kWISCO_tBatchImportTable
       truncate table CUS_kWISCO_tBatchImportTable
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kWISCO_pBatchFlush] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kWISCO_pBatchFlush] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kWISCO_pBatchFlush] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kWISCO_pBatchFlush] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kWISCO_pBatchFlush] TO [DB_DMLSupport]
    AS [dbo];

