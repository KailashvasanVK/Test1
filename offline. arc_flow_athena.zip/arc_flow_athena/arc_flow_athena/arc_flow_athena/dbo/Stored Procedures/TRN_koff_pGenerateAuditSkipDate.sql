﻿  
CREATE Proc TRN_koff_pGenerateAuditSkipDate    
as    
/*    
SCR         :1844   
Created By  :Noor 
CreatedDate :08/11/2018     
Purpose     : Mark date in table by userwise to skip the audit    
Executed By :Narayana
*/    
Begin    
    
If object_id('tempdb..#Userid') is not null drop table #Userid    
If object_id('tempdb..#tmpUserId') is not null drop table #tmpUserId    
Create table #Userid    
(    
Id int identity(1,1),    
Userid int    
)    
      
SELECT  distinct ai.userid into #tmpUserId from arc_flow_athena.dbo.ADM_AccessFunctionality(nolock) af inner join arc_rec_athena..arc_rec_user_info(nolock) ai    
on af.userid=ai.userid where functionality in('P','A') and ai.lastcustomerid=25 and ACTIVE=1 and ai.userid not in(SELECT Userid FROM arc_flow_athena.dbo.ADM_QCAuditSkipUsers(nolock) WHERE status=1)   
INSERT INTO #Userid(UserId)      
SELECT Userid from  #tmpUserId order by newid()  
--Take backup    
Insert into trn_koff_tQCRandomAuditLogicLog(UserId,PresentDay,ToAudit,Audited,SkipDate,CreatedDate,PresentDayUpdate,isSkip,RandomNo,ModifiedDate)    
SELECT UserId,PresentDay,ToAudit,Audited,SkipDate,CreatedDate,PresentDayUpdate,isSkip,RandomNo,getdate() FROM trn_koff_tQCRandomAuditLogic (nolock)     
    
TRUNCATE table trn_koff_tQCRandomAuditLogic    
    
    
/*Assign skip to Audit Date*/    
    
DECLARE @Rowid int=0,@Skipdate varchar(30)='',@TotCount int=0,@CntId int=5,@Divide int=0,@PresentUpdateDate varchar(30)=''    
SELECT @Rowid=COUNT(ID) from #Userid           
select  @Skipdate=DATEADD(dd, -(DATEPART(dw, getdate())-2), getdate())     
select @TotCount=count(userid) from #Userid    
SELECT @Divide=@TotCount/5    
select @PresentUpdateDate=DATEADD(dd, -(DATEPART(dw, getdate())-1), getdate())    
    
DECLARE @StRec int=1,@EndRec int=0    
SET @EndRec=@Divide    
while(@CntId!=0)      
BEGIN    
If(@CntId=1)    
SET @EndRec=@TotCount    
    
Insert into trn_koff_tQCRandomAuditLogic(Userid,SkipDate,PresentDayUpdate,CreatedDate)    
SELECT Userid,convert(date,@Skipdate),@PresentUpdateDate,getdate() from #Userid where Id between @StRec and @EndRec    
SET @Skipdate=DateAdd(day,1,@Skipdate)    
SET @StRec=@EndRec + 1    
SET @EndRec=@EndRec + @Divide    
SET @CntId=@CntId - 1  
END    
drop table #Userid
drop table #tmpUserId
END 


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_koff_pGenerateAuditSkipDate] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_koff_pGenerateAuditSkipDate] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_koff_pGenerateAuditSkipDate] TO [DB_DMLSupport]
    AS [dbo];

