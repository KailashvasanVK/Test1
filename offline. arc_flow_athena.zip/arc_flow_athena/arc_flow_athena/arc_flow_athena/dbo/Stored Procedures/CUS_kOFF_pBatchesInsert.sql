﻿CREATE Procedure CUS_kOFF_pBatchesInsert            
(            
 @CustomerId int = 25   
,@ScanDate date            
,@BatchNo varchar(50)      
,@FileName varchar(500)=''                  
,@ClientId int=0                    
,@ServiceId int=0                   
,@BatchType int=1 /* (1) PDF (2) TIF (3) DOC */            
,@CreatedBy int                    
,@PageCount int=1                              
,@BatchFullName varchar(200) = '' -- For File name from front end [OPTIONAL PARAM]            
,@Qtype int = 2 /** General Process */       
,@DownloadDate date      
,@BatchStatus int       
,@Priority int      
,@LocationId int = 1      
)                    
As                    
Begin                
            
  /*                 
    Purpose      :Insert Batched into  tBatches  table              
    Created By   :Safiy                      
    Created Date : 26 April 2013                      
    Impact to    :ManualBatchCreation.aspx               
    Modified on 08/21/2014      
    Modified by Mohamed Safiyullah      
    Modified - @Scandate param value      
    Modified on 09/04/2014      
    Modified by Mohamed Safiyullah      
    Modified - BatchStatus default as 3 for indexing      
      
    --M001  
    Modified by Ramakrishnan.G      
    Modified on 07/15/2016      
    Purpose: Code modified to have a entry in the batchmovement folder/ This is required to move the imported pDF to the new IB server  
      
      
   */
   Set @CreatedBy=1777      
Declare @CrDate datetime              
if @ScanDate is null      
 SET @ScanDate=CONVERT(date,getdate())          
if(isnull(@DownloadDate,null) is not null)            
 set @CrDate = Convert(datetime,Convert(varchar,@DownloadDate,101) + ' 09:00:00')               
else      
 set @CrDate = Convert(datetime,Convert(varchar,GETDATE(),101) + ' 09:00:00')               
Set @BatchNo = LTRIM(RTRIM(@BatchNo))            
      
Declare @FName varchar(max)            
if(@BatchFullName = '~empty~')            
    set @FName = ''            
else if(@BatchFullName <>'')            
    set @FName = @BatchFullName            
 else            
    set @FName = 'Athena'+'\'+ replace(convert(varchar, DATEADD(Day,1,@Scandate),101),'/','') +'\' +@FileName             
    --set @FName = @CustomerName+'\'+ @FileName             
Declare @BatchId int,@BatchProcessId int,@FlowId int      
if (Select COUNT(*) from TRN_kOFF_tBatches(nolock) Where BatchNo = @BatchNo and ServiceId = @ServiceId) = 0      
 Begin      
  Begin Transaction          
   Begin Try          
   Insert into TRN_kOFF_tBatches(ScanDate,BatchNo,ClientId,ServiceId,BatchType,CreatedBy,CreatedDt,PgCount,FName,Qtype,CreatedOn,WFBatchId,Status,Priority,LocationId)            
   values (@ScanDate,@BatchNo,@ClientId,@ServiceId,@BatchType,@CreatedBy,@CrDate,@PageCount,@FName,@Qtype,GETDATE(),0,@BatchStatus,@Priority,@LocationId)           
   Select @BatchId = SCOPE_IDENTITY() /* IDENT_CURRENT('TRN_kOFF_tBatches')*/      
   Insert into TRN_kOFF_tBatchQueue(BatchId,BatchNo,PageFrom,PageTo,Assigned,ClientId,ServiceId,StatusId,Comment,CreatedBy,CreatedDt,QType,WF_ProcessId,Ref_ILogId)      
   Values(@BatchId,@BatchNo,1,@PageCount,0,@ClientId,@ServiceId,0,'',@CreatedBy,@CrDate,@Qtype,0,0)      
   Select @BatchProcessId = SCOPE_IDENTITY() /*IDENT_CURRENT('TRN_kOFF_tBatchQueue')*/      
   Insert into TRN_kOFF_tBatchFlow(BatchId,BatchProcessId,CreatedDt,CreatedBy,StatusId,Comments,Ref_FlowId)      
   values(@BatchId,@BatchProcessId,@CrDate,@CreatedBy,0,'',0)      
   Select @FlowId = SCOPE_IDENTITY() /*IDENT_CURRENT('TRN_kOFF_tBatchFlow')*/      
         
/*M001  
Begin  
*/  
      If (left(@BatchNo,1) =('M') or left(@BatchNo,1) =('S'))  
   Begin  
      Insert into ARC_Athena..ScanFileMovementLog(scandate,FileType,Batchnum,PathName,CHNPlacedStatus, CBEPlacedstatus)          
      values (@ScanDate,'MergeFiles',@BatchNo,@FName,0,0)  
   End       
   
/*M001  
END  
*/  
   
   /*    
   Update TRN_kOFF_tBatchQueue Set FlowId = @FlowId Where BatchId = @BatchId and BatchProcessId = @BatchProcessId      
       
   */       Commit Transaction          
   End 
try          
  Begin Catch          
   Rollback transaction          
  End catch          
 End      
End       
      



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kOFF_pBatchesInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kOFF_pBatchesInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kOFF_pBatchesInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kOFF_pBatchesInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kOFF_pBatchesInsert] TO [DB_DMLSupport]
    AS [dbo];

