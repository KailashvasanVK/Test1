﻿CREATE Procedure [dbo].[ADM_IssuelogCuttingPages]
as
Begin
	select ID,BatchId,PageNo,[FileName] FROM ADM_IssuelogPages WHERE STATUS = 0	and ISNULL(ErrLog,'') = '' Order by Id
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_IssuelogCuttingPages] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_IssuelogCuttingPages] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_IssuelogCuttingPages] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_IssuelogCuttingPages] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_IssuelogCuttingPages] TO [DB_DMLSupport]
    AS [dbo];

