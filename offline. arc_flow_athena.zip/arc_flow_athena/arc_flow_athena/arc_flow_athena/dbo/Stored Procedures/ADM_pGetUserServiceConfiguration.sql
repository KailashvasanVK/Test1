﻿CREATE Procedure ADM_pGetUserServiceConfiguration 
(
@CustomerId INT , 
@Userid  int = 0
)
As
/*,
Created by : Karthik M7
Created on : 20 FEB 2015.
Modified by : Kathiravan.kand
*/

-- Purpose : To get functionality details for the user --
Begin

if OBJECT_ID('tempdb..#SelectedServiceInfo') is not null drop table #SelectedServiceInfo 
Create Table #SelectedServiceInfo(ServiceId int,ServiceName varchar(max),IsSelected bit,ROrder int)

insert into #SelectedServiceInfo(ServiceId ,ServiceName ,IsSelected,ROrder)
Select ServiceGroupId as [ServiceId],Ser.ServiceName,0,999 from ADM_ServiceGroup as SG
inner join ADM_Client as Ci on ci.ClientId = SG.ClientId and ci.CustomerId = @CustomerId
inner join ADM_Service as Ser on Ser.ServiceId = SG.ServiceGroupId and Ser.FieldType='T'   and Ser.Status =1
/*Where Exists (Select 1 from ADM_AccessServices where  CustomerId = @CustomerId and ServiceId = Sg.ServiceGroupId)*/
Group by SG.ServiceGroupId,Ser.ServiceName
order by Ser.ServiceName
	
IF (@Userid <> 0 )
BEGIN
	UPDATE #SelectedServiceInfo 
	SET
	IsSelected = 1,
	ROrder = OrderID
	FROM
	#SelectedServiceInfo t
	INNER JOIN
	(select ROW_NUMBER() OVER(ORDER BY AccServiceId) AS OrderID,  ServiceId  from ADM_AccessServices where UserId  = @Userid) a
	ON a.ServiceId  = t.ServiceId
END
	
select * from #SelectedServiceInfo  order by ServiceName asc
if OBJECT_ID('tempdb..#SelectedServiceInfo') is not null drop table #SelectedServiceInfo 
End





GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pGetUserServiceConfiguration] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pGetUserServiceConfiguration] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pGetUserServiceConfiguration] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pGetUserServiceConfiguration] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pGetUserServiceConfiguration] TO [DB_DMLSupport]
    AS [dbo];

