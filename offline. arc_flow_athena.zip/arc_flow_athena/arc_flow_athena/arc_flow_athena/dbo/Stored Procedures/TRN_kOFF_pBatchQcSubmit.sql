﻿CREATE Procedure [dbo].[TRN_kOFF_pBatchQcSubmit]
(      
@CustomerId int 
,@BatchProcessId int   
,@Comments varchar(max)
,@CreatedBy int      
)      
as      
Begin  
	
Begin Transaction    
Begin Try    

    if (Select COUNT(*) from TRN_kOFF_tBatchQCMaster where BatchProcessId = @BatchProcessId) = 0
    Begin
    Exec [TRN_pQCPagesInitiation] 25,@BatchProcessId,@CreatedBy
    End
    if (Select COUNT(*) from TRN_kOFF_tBatchQCMaster where BatchProcessId = @BatchProcessId) = 0
    Begin
    return
    End
	Declare @CmpKey varchar(5)  
	Declare @FlowId int    
	Select @CmpKey = CmpKey from ADM_Customer where CustomerId = @CustomerId      
	 
	if (Select Count(*) from TRN_kOFF_tBatchFlow Where BatchProcessId = @BatchProcessId And StatusId = 12) > 0
	 begin
		 RAISERROR('Qc already completed',16,1)
	 end
	  
	/** Log maintance for edited trans and info **/
	Insert into TRN_kOFF_tBatchTransactLog(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry,UpdatedBy,UpdatedDt)
	Select BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry,@CreatedBy  UpdatedBy,GETDATE() UpdatedDt
	from TRN_kOFF_tBatchTransact as tr
	Where tr.BatchProcessId = @BatchProcessId  and tr.isQcEntry = 0
	and exists (select 1 from TRN_kOFF_tBatchQCMaster Where BatchProcessId = tr.BatchProcessId and PageNo = tr.PageNo)
	and exists (select 1 from
			(
			/** select Updated trans **/
			Select BatchProcessId,PageNo,ServiceId from TRN_kOFF_tBatchTransactMirror
			Where BatchProcessId = @BatchProcessId  and isnull(UpdatedBatchProcessId,0) <> 0 and ExtTransValue <> 0 and TransValue <> ExtTransValue
			Union
			/** select Updated infos **/
			Select BatchProcessId,PageNo,ServiceId from TRN_kOFF_tBatchTransactMirror
			Where BatchProcessId = @BatchProcessId  and isnull(UpdatedBatchProcessId,0) = 0 and ExtInfoValue <> '''' and InfoValue <> ExtInfoValue
			) x Where BatchProcessId = tr.BatchProcessId and PageNo = tr.PageNo and ServiceId = tr.ServiceId)
	/** Update with orginal transact for edited trans and info **/
	Update tr Set TransValue = x.TransValue,InfoValue = x.InfoValue
	from TRN_kOFF_tBatchTransact as tr
	inner join
			(
			/** select Updated trans **/
			Select BatchProcessId,PageNo,ServiceId,TransValue,InfoValue from TRN_kOFF_tBatchTransactMirror
			Where BatchProcessId = @BatchProcessId  and isnull(UpdatedBatchProcessId,0) <> 0 and ExtTransValue <> 0 and TransValue <> ExtTransValue
			Union
			/** select Updated infos **/
			Select BatchProcessId,PageNo,ServiceId,TransValue,InfoValue from TRN_kOFF_tBatchTransactMirror
			Where BatchProcessId = @BatchProcessId  and isnull(UpdatedBatchProcessId,0) = 0 and ExtInfoValue <> '''' and InfoValue <> ExtInfoValue
			) x on x.BatchProcessId = tr.BatchProcessId and x.PageNo = tr.PageNo and x.ServiceId = tr.ServiceId
	Where tr.BatchProcessId = @BatchProcessId  and tr.isQcEntry = 0
	and exists (select 1 from TRN_kOFF_tBatchQCMaster Where BatchProcessId = tr.BatchProcessId and PageNo = tr.PageNo)


	Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry)
	Select tr.BatchProcessId,tr.PageNo,tr.ServiceId,tr.TransValue,tr.InfoValue,tr.CreatedBy,tr.CreatedDt
	,que.BatchId,que.ServiceId as BatchServiceId,que.ClientId
	,1 isQcEntry
	from
	(
	/** New Trans **/
	Select BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,1 isQcEntry from TRN_kOFF_tBatchTransactMirror
	Where BatchProcessId = @BatchProcessId  and ISNULL(UpdatedBatchProcessId,0) = 0 and TransValue <> 0
	union
	/** New info **/
	Select BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,1 isQcEntry from TRN_kOFF_tBatchTransactMirror
	Where BatchProcessId = @BatchProcessId  and ISNULL(UpdatedBatchProcessId,0) = 0 and InfoValue <> '''' and ExtInfoValue = ''''
	) tr
	inner join TRN_kOFF_tBatchQueue as que on que.BatchProcessId = tr.BatchProcessId

	/** Inserting updated diff (negative) value **/
	Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry,QcDeductTrans)
	Select tr.BatchProcessId,tr.PageNo,tr.ServiceId,tr.TransValue - tr.ExtTransValue as TransValue,'''' as InfoValue
	,tr.CreatedBy,tr.CreatedDt,que.BatchId,que.ServiceId as BatchServiceId,que.ClientId,1 isQcEntry,1 QcDeductTrans
	from TRN_kOFF_tBatchTransactMirror as tr
	inner join TRN_kOFF_tBatchQueue as que on que.BatchProcessId = tr.BatchProcessId
	Where tr.BatchProcessId = @BatchProcessId  and ExtTransValue > 0 and (tr.TransValue - tr.ExtTransValue) < 0
	and exists (select 1 from TRN_kOFF_tBatchQCMaster Where BatchProcessId = tr.BatchProcessId and PageNo = tr.PageNo)

	/** Summary Log and New Summary **/
	Insert into TRN_kOFF_tBatchTransactSummaryLog(BatchProcessId,ServiceId,TransValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,EntryOrder)
	Select BatchProcessId,ServiceId,TransValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId
	,(Select MAX(EntryOrder) + 1 from TRN_kOFF_tBatchTransactSummaryLog) as EntryOrder
	from TRN_kOFF_tBatchTransactSummary Where BatchProcessId = @BatchProcessId 

	Delete from TRN_kOFF_tBatchTransactSummary Where BatchProcessId = @BatchProcessId 
	Delete from TRN_kOFF_tBatchTransactMirror Where BatchProcessId = @BatchProcessId 

	Insert into TRN_kOFF_tBatchTransactSummary(BatchProcessId,ServiceId,TransValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId)
	Select tr.BatchProcessId,tr.ServiceId,Sum(tr.TransValue) as TransValue
	,tr.CreatedBy,CAST(tr.CreatedDt as date) as CreatedDt 
	,que.BatchId,que.ServiceId as BatchServiceId,que.ClientId
	from TRN_kOFF_tBatchTransact as tr
	inner join TRN_kOFF_tBatchQueue as que on que.BatchProcessId = tr.BatchProcessId
	Where tr.BatchProcessId = @BatchProcessId  and tr.TransValue > 0
	Group by tr.BatchProcessId,tr.ServiceId,tr.CreatedBy,CAST(tr.CreatedDt as date),que.BatchId,que.ServiceId,que.ClientId

	Insert into TRN_kOFF_tBatchQCComments(BatchProcessId,Comments,CreatedBy,CreatedDt,FTE_Id,BatchId)
	Select Top 1 @BatchProcessId ,@Comments,@CreatedBy ,GETDATE()
	,CreatedBy as FTE_Id,BatchId
	from TRN_kOFF_tBatchFlow Where BatchProcessId = @BatchProcessId  and StatusId = 6
	Order by FlowId desc

	Declare @BatchId int,@FlowIdCompletedProcess int
	Select @BatchId = BatchId from TRN_kOFF_tBatchQueue Where BatchProcessId = @BatchProcessId 
	/** Inserting process completion status to Flow */

	Insert into TRN_kOFF_tBatchFlow(BatchProcessId,BatchId,CreatedBy,CreatedDt,StatusId,Comments,Ref_FlowId)             
	Select @BatchProcessId,@BatchId,@CreatedBy,GETDATE(),12,@Comments,0 

	if (Select COUNT(*) from TRN_kOFF_tBatchFlow Where BatchId = @BatchId and StatusId = 13) = 0
		Begin
		Insert into TRN_kOFF_tBatchFlow(BatchProcessId,BatchId,CreatedBy,CreatedDt,StatusId,Comments,Ref_FlowId)             
		Select @BatchProcessId,@BatchId,@CreatedBy,GETDATE(),13,@Comments,0 
		End
	
	Select @FlowId = IDENT_CURRENT('TRN_kOFF_tBatchFlow')             
	Update TRN_kOFF_tBatchQueue Set FlowId = @FlowId,StatusId = 13,Comment = @Comments,Assigned=0 where BatchProcessId = @BatchProcessId 	
	update TRN_kOFF_tBatches  set UploadDt = GETDATE(), AuditedDt = GETDATE()  where BatchId =   @BatchId 	     
	Select ''
Commit Transaction    
End Try    
Begin Catch    
Rollback transaction
End catch    
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pBatchQcSubmit] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchQcSubmit] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchQcSubmit] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pBatchQcSubmit] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchQcSubmit] TO [DB_DMLSupport]
    AS [dbo];

