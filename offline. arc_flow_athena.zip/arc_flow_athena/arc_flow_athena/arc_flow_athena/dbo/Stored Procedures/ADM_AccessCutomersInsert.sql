﻿CREATE Procedure [dbo].[ADM_AccessCutomersInsert]
@UserId int ,
@CustomerId int ,
@CreatedBy  int 
As
/*
Created by : Karthik Ic
Created on : 15 May 2013
Impact to  : ProfileSetup.aspx
Purpose    : To save the user and customer details
*/
Begin
Insert into ADM_AccessCutomers(UserId,CustomerId,CreatedBy)
Select @UserId,@CustomerId,@CreatedBy 
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_AccessCutomersInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessCutomersInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessCutomersInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_AccessCutomersInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessCutomersInsert] TO [DB_DMLSupport]
    AS [dbo];

