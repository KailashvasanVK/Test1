﻿CREATE procedure [dbo].[TRN_KOFF_pBatchHistorySearch]            
 @UserId int  ,             
 @CustomerId INT=0,             
 @ClientId INT=0,              
 @Cmpkey varchar(20)='',            
 @ServiceId int='',            
 @BatchNO varchar(75)='',             
 @ToDate  varchar(75)='',               
 @FromDate  varchar(75)='',             
 @DateMode varchar(5)='',            
 @SearchStr varchar(100) = '',              
 @payerID int = 0,            
 @SearchPattern varchar(4) = '=', /** = or % **/             
 @LocationId int=1       --added by mallikarjun.nam      
As             
 Begin            
 SET Transaction Isolation level Read uncommitted;         
    declare @FromScanDate as datetime,            
   @ToScanDate as datetime,            
   @FromDownloadDate as datetime,            
   @ToDownloadDate as datetime            
               
 /*            
  Modified By : Kathiravan.kand            
  Modified Dt : 02/28/2015            
  Purpoder    : Payer name added in filer                   
 */         
  /*            
  Modified By : mallikarjun.nam            
  Modified Dt : 2016-01-07        
  Purpoder    : Batch Comments are add      
 */                
            
 /* Declare @Action varchar(50),            
  @UserId int  ,             
  @CustomerId INT=25,             
  @ClientId INT=0,              
  @Cmpkey varchar(20)='OFF',            
  @ServiceId int=355,            
  @BatchNO varchar(75)='994410A707',             
  @ToDate  varchar(75)='',               
  @FromDate  varchar(75)='',             
  @DateMode varchar(5)='D',               
  @BatchId int = 0,            
  @SearchStr varchar(100) = '',              
  @payerID int = 0,            
  @SearchPattern varchar(4) = '=' /** = or % **/            
  */            
 if (isnull(@FromDate,'') ='' or isnull(@ToDate,'') ='')            
 begin            
   set  @FromScanDate  = convert(date,'1900-01-01')            
   set @ToScanDate  = DateAdd(day, 1, GETDATE())            
   set @FromDownloadDate =  convert(date,'1900-01-01')            
   set @ToDownloadDate = DateAdd(day, 1, GETDATE())            
 end            
   else if(@DateMode = 'D')            
 begin            
  set  @FromScanDate  = convert(date,'1900-01-01')            
  set @ToScanDate  = DateAdd(day, 1, GETDATE())            
  set @FromDownloadDate =  convert(date,@FromDate)            
  set @ToDownloadDate = convert(date,@ToDate)            
 END            
 ELSE IF (@DateMode = 'S')            
 Begin            
  set  @FromScanDate  =  convert(date,@FromDate)            
  set @ToScanDate  =  convert(date,@ToDate)            
  set @FromDownloadDate =  convert(date,'1900-01-01')            
  set @ToDownloadDate = DateAdd(day, 1, GETDATE())            
 END            
       
       
  /* Code written by mallikarjun.nam  */             
      
          if OBJECT_ID('tempdb..#UserLocation') is not null drop table #UserLocation      
   Create table #UserLocation( locationid int,LocationName varchar(50))      
   insert into  #UserLocation(locationId,LocationName)      
   exec ADM_GetUserLocation @userid,@LocationId      
       
   Create index NCIDX_Locationin on #UserLocation(locationId)    
  
     
		if OBJECT_ID('tempdb..#Tempbatch') is not null drop table #Tempbatch    
		
		Create table #Tempbatch(BatchId	int, ScanDate	date, BatchNo	varchar(50), ClientId	int, ServiceId	int, BatchType	tinyint,
			CreatedBy	int, CreatedDt	datetime, Priority	int, PgCount	int, FName	varchar(200), UploadDt	datetime, PostedDt	datetime,
			AuditedDt	datetime,status	int, WFBatchId	int, QType	int, CreatedOn	datetime, isDummy	int, BatchGroupNo	varchar(75), 
			PayerId	int, ProcessedMin	int, HeldMinutes	int, LocationId	int)
		
		/* added by Udhai */     
		if isnull(@BatchNO,'') <> ''
		begin 
			insert into #Tempbatch (BatchId, ScanDate, BatchNo, ClientId, ServiceId, BatchType, CreatedBy, CreatedDt, Priority, PgCount, FName, UploadDt, PostedDt, AuditedDt, status, WFBatchId, QType, CreatedOn, isDummy, BatchGroupNo, PayerId, ProcessedMin, HeldMinutes, LocationId)
			select BatchId, ScanDate, BatchNo, ClientId, ServiceId, BatchType, CreatedBy, CreatedDt, Priority, PgCount, FName, UploadDt,
			PostedDt, AuditedDt, status, WFBatchId, QType, CreatedOn, isDummy, BatchGroupNo, PayerId, ProcessedMin, HeldMinutes, LocationId  
			From TRN_KOFF_tBatches TB 
			where TB.BatchNo=@BatchNO 
			option (recompile)     
		end
		else
		begin 
			insert into #Tempbatch (BatchId, ScanDate, BatchNo, ClientId, ServiceId, BatchType, CreatedBy, CreatedDt, Priority, PgCount, FName, UploadDt, PostedDt, AuditedDt, status, WFBatchId, QType, CreatedOn, isDummy, BatchGroupNo, PayerId, ProcessedMin, HeldMinutes, LocationId)
			select BatchId, ScanDate, BatchNo, ClientId, ServiceId, BatchType, CreatedBy, CreatedDt, Priority, PgCount, FName, UploadDt,
			PostedDt, AuditedDt, status, WFBatchId, QType, CreatedOn, isDummy, BatchGroupNo, PayerId, ProcessedMin, HeldMinutes, LocationId  
			From TRN_KOFF_tBatches TB 
			where ISNULL(tb.PayerId, 0 ) =(case  when ISNULL(@payerID,0) <> 0 then @payerID else  ISNULL(tb.PayerId,0) end)            
			AND TB.ServiceId = @ServiceID 
			AND TB.ClientId = case when isnull(@ClientId,0) <> 0 then @ClientId else   TB.ClientId  END            
			AND  CAST(TB.CreatedDt as date) between @FromDownloadDate  and @ToDownloadDate              
			AND CAST(TB.ScanDate as date) between  @FromScanDate and  @ToScanDate
			option (recompile)     
		end
		

		if OBJECT_ID('tempdb..#TempTrans') is not null drop table #TempTrans

		select T.Batchid, SUM(T.TransValue) TransValue into #TempTrans 
		from TRN_kOFF_tBatchTransact(nolock) T Inner join #Tempbatch tbl on T.BatchId = tbl.BatchId
		group by T.Batchid

		if OBJECT_ID('tempdb..#TempFlow') is not null drop table #TempFlow

		select T.Batchid, max(case when T.StatusId in (1,6,7) then FlowId end) as FlowId, 
		max(case when T.StatusId=6 then T.CreatedBy end) as FTEId  into #TempFlow
		from trn_kOFF_tbatchflow (nolock) T Inner join #Tempbatch tbl on T.BatchId = tbl.BatchId
		group by T.Batchid		
		
		
		if OBJECT_ID('tempdb..#FinalTempBatch') is not null drop table #FinalTempBatch
		
		Select Distinct TB.BatchId, AC.ClientAcmName as ClientName,ser.ServiceName,TB.BatchNo,TB.PgCount as Page ,CONVERT(VARCHAR(10),TB.ScanDate,101) as ScanDate             
		,CONVERT(VARCHAR(10),TB.CreatedDt,101) DownloadDate,TB.CreatedBy as ttt,TB.PostedDt as ProcessedDate    
		,(case when TB.Status=88  then 'Automation Pending' else dbo.TRN_kOFF_fnGetBatchCurrentStatus(TB.BatchId) end) as StatusDescription             
		, '<a href ="#" class ="lnkText" onclick="return showDialog(' +  convert(varchar(10),TB.BatchId)+ ',' + convert(varchar,ser.ServiceId) + ')"  >'+' <span class="ui-icon ui-icon-pencil IconBackGround"             
		title ="Click here to view the Batch History detils"></span>' + '</a>' as Action,            
		PV.PayerName, TF.FlowId, TF.FTEID into #FinalTempBatch      
		From #Tempbatch (nolock)  TB       
		inner join ADM_Client (nolock) AC on AC.ClientId = TB.ClientId             
		inner join ADM_Service (nolock) ser on ser.ServiceId = Tb.ServiceId            
		inner join #UserLocation as loc on isnull(TB.LocationId,1)=loc.LocationId -- code added by mallikarjun      
		Left Join #TempFlow TF on TF.Batchid=TB.Batchid
		Left join ADM_PayerName_View PV on PV.PayerId=TB.PayerId
		where TB.Status in(0,1,88)            		
		AND ISNULL(tb.PayerId, 0 ) =(case  when ISNULL(@payerID,0) <> 0 then @payerID else  ISNULL(tb.PayerId,0) end)            
		AND TB.ServiceId = case when isnull(@ServiceID,0) <> 0 then @ServiceID else   TB.ServiceId  END            
		AND TB.ClientId = case when isnull(@ClientId,0) <> 0 then @ClientId else   TB.ClientId  END            
		AND  CAST(TB.CreatedDt as date) between @FromDownloadDate  and @ToDownloadDate              
		AND CAST(TB.ScanDate as date) between  @FromScanDate and  @ToScanDate
           
                
		if OBJECT_ID('tempdb..#BatchHistory') is not null drop table #BatchHistory               
		Select ClientName, ServiceName, BatchNo,Page, ScanDate , DownloadDate    
		, (CONVERT(VARCHAR(20), (ProcessedDate),101) +' '+ CONVERT(VARCHAR(12), ProcessedDate ,108)) [Processed Date]      
		, entryuser.NT_USERNAME [EntryBy]      
		, ui.NT_USERNAME as Handledby 
		, T.TransValue as TransCount
		, StatusDescription    
		, PayerName ,action       
		,case when held.BatchId is not null then held.HeldComment  else flow.Comments end as Comments      
		into #BatchHistory            
		from #FinalTempBatch tbl             
		left join #TempTrans T on T.BatchId=tbl.BatchId
		Left join TRN_kOFF_tBatchFlow (nolock) as flow on flow.FlowId = tbl.FlowId            
		Left join ARC_Rec_Athena..ARC_REC_USER_INFO (nolock) UI on UI.USERID = flow.CreatedBy          
		Left join ARC_Rec_Athena..ARC_REC_USER_INFO (nolock) entryuser on entryuser.USERID = tbl.FTEID      
		Left join TRN_kOFF_tHeldBatches held(nolock) ON held.BatchId=tbl.BatchId and held.ReleaseDate is null         
    
       
            
 Exec FilterTable              
 @DbName = 'tempdb'              
 ,@TblName = '#BatchHistory'              
 ,@SearchStr = @SearchStr              
 ,@SearchPattern = @SearchPattern              
 ,@OrderStr = ''            
 if OBJECT_ID('tempdb..#BatchHistory') is not null drop table #BatchHistory              
 if OBJECT_ID('tempdb..#Tempbatch') is not null drop table #UserLocation      
 if OBJECT_ID('tempdb..#UserLocation') is not null drop table #UserLocation          
  
End    
    


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_KOFF_pBatchHistorySearch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_KOFF_pBatchHistorySearch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_KOFF_pBatchHistorySearch] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_KOFF_pBatchHistorySearch] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_KOFF_pBatchHistorySearch] TO [DB_DMLSupport]
    AS [dbo];

