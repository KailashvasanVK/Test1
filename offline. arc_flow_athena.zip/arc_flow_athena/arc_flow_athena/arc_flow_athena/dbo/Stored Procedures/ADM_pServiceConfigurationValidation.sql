﻿
/*START ServiceConfiguration*/


CREATE Procedure ADM_pServiceConfigurationValidation
(@CustomerId INT = 16,@UserIdCollection varchar(max) = '1451')

AS
Begin

Declare @ErrMsg varchar(max) 

if OBJECT_ID('tempdb..#SelectedUsersInfo') is not null drop table #SelectedUsersInfo 
	Create Table #SelectedUsersInfo(UserId int,serviceID varchar(max)) 



insert into  #SelectedUsersInfo (serviceID,UserId) 
		SELECT SUBSTRING(
		(
		SELECT ',' + CAST(ServiceId AS VARCHAR)
		FROM ADM_AccessServices where UserId = items and CustomerId = @CustomerId  order by ServiceId
		FOR XML PATH('')), 2,10000) AS Csv,items
		from dbo.fnSplitString(@UserIdCollection,',')

if	((select COUNT(distinct serviceID) from  #SelectedUsersInfo) > 1 )
BEGIN
		Set @ErrMsg = '0' --Service conflict for selected users
END
ELSE
BEGIN
	
		truncate table #SelectedUsersInfo
		insert into  #SelectedUsersInfo (serviceID,UserId) 
		SELECT SUBSTRING(
		(
		SELECT ',' + CAST(ServiceId AS VARCHAR)
		FROM ADM_AccessServices where UserId = items and CustomerId = @CustomerId  
		FOR XML PATH('')), 2,10000) AS Csv,items
		from dbo.fnSplitString(@UserIdCollection,',')
	
		if	((select COUNT(distinct serviceID) from  #SelectedUsersInfo) > 1 )
		BEGIN
			Set @ErrMsg = '1'  -- Service Order conflict for selected users.Default order selected 
		END
	
END


if OBJECT_ID('tempdb..#SelectedUsersInfo') is not null drop table #SelectedUsersInfo 

Select isnull(@ErrMsg,'') as Result 

END

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pServiceConfigurationValidation] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pServiceConfigurationValidation] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pServiceConfigurationValidation] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pServiceConfigurationValidation] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pServiceConfigurationValidation] TO [DB_DMLSupport]
    AS [dbo];

