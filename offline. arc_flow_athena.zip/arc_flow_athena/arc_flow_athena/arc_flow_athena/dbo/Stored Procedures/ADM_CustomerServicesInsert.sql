﻿CREATE Procedure ADM_CustomerServicesInsert
@CustomerId int
,@CSId int
,@ServiceId int
,@Price decimal(15,5)
,@CreatedBy int
,@CreatedDt datetime
,@FunctionalityId int
,@Paymode varchar(3)
,@EffectiveFrom date
,@FteCount int
,@FtePrice decimal(15,5)
,@HrsValue int
,@HrsPrice decimal(15,5)
,@HrsFteCount int
,@MonTargetTran int
,@MonPrice decimal(15,5)
,@DayTargetTran int
,@DayPrice decimal(15,5)
,@DayWorkMode varchar(25)
,@Code varchar(10)
,@GroupName varchar(30)
as
/*
Purpose		:	Save the customer service wise price details
Created By  :	Karthik Ic
Created On  :	06 may 2013
Impact to   :	CustomerCreation.aspx


*/
Begin
if isnull(@CustomerId,0) = 0
	Begin /* New Customer creation **/
	set @CustomerId =(SELECT IDENT_CURRENT ('ADM_Customer') AS Current_Identity)
	Insert into ADM_CustomerServices(
	CustomerId,ServiceId,Price,CreatedBy,CreatedDt
	,FunctionalityId,Paymode,EffectiveFrom,FteCount
	,FtePrice,HrsValue,HrsPrice,HrsFteCount
	,MonTargetTran,MonPrice,DayTargetTran,DayPrice
	,DayWorkMode,AprStatus,Code,GroupName
	)
	Select 
	@CustomerId,@ServiceId,@Price,@CreatedBy,@CreatedDt
	,@FunctionalityId,@Paymode,@EffectiveFrom,@FteCount
	,@FtePrice,@HrsValue,@HrsPrice,@HrsFteCount
	,@MonTargetTran,@MonPrice,@DayTargetTran,@DayPrice
	,@DayWorkMode,2,@Code,@GroupName
	End
Else
	Begin /** Modified Customer **/	
	if isnull(@CSId,0) = 0
		Begin /** New Service in modified customer **/
		Insert into ADM_CustomerServices(
		CustomerId,ServiceId,Price,CreatedBy,CreatedDt
		,FunctionalityId,Paymode,EffectiveFrom,FteCount
		,FtePrice,HrsValue,HrsPrice,HrsFteCount
		,MonTargetTran,MonPrice,DayTargetTran,DayPrice
		,DayWorkMode,AprStatus,Code,GroupName
		)
		Select 
		@CustomerId,@ServiceId,@Price,@CreatedBy,@CreatedDt
		,@FunctionalityId,@Paymode,@EffectiveFrom,@FteCount
		,@FtePrice,@HrsValue,@HrsPrice,@HrsFteCount
		,@MonTargetTran,@MonPrice,@DayTargetTran,@DayPrice
		,@DayWorkMode,2,@Code,@GroupName
		End
	else
		Begin /** Check if any changes in Service **/		
		if (Select COUNT(*) from ADM_CustomerServices Where CustomerId = @CustomerId and CSId = @CSId 
		And Price = @Price and FunctionalityId = @FunctionalityId
		and Paymode = @Paymode and EffectiveFrom = @EffectiveFrom and FteCount = @FteCount
		and FtePrice = @FtePrice and HrsValue = @HrsValue and HrsPrice = @HrsPrice and HrsFteCount = @HrsFteCount
		and MonTargetTran = @MonTargetTran and MonPrice = @MonPrice and DayTargetTran = @DayTargetTran and DayPrice = @DayPrice
		and DayWorkMode = @DayWorkMode and Code = @Code and GroupName =@GroupName) = 0
			Begin /** if changes found need to move log **/			
			
			Insert into ADM_CustomerServicesLog(
			CustomerId,ServiceId,Price,CreatedBy,CreatedDt
			,FunctionalityId,Paymode,EffectiveFrom,FteCount
			,FtePrice,HrsValue,HrsPrice,HrsFteCount
			,MonTargetTran,MonPrice,DayTargetTran,DayPrice
			,DayWorkMode,AprStatus,ApprovedBy,ApprovedDt,CSId,Code,GroupName)
			Select CustomerId,ServiceId,Price,CreatedBy,CreatedDt
			,FunctionalityId,Paymode,EffectiveFrom,FteCount
			,FtePrice,HrsValue,HrsPrice,HrsFteCount
			,MonTargetTran,MonPrice,DayTargetTran,DayPrice
			,DayWorkMode,AprStatus,ApprovedBy,ApprovedDt,CSId,Code,GroupName
			From ADM_CustomerServices Where CustomerId = @CustomerId and Csid = @CSId
			
			
			Update ADM_CustomerServices Set AprStatus = 3,CreatedBy = @CreatedBy,CreatedDt = GETDATE(),
			CustomerId = @CustomerId,Price = @Price,FunctionalityId = @FunctionalityId,Paymode = @Paymode,EffectiveFrom = @EffectiveFrom,FteCount = @FteCount,
			FtePrice = @FtePrice,HrsValue = @HrsValue,HrsPrice = @HrsPrice,HrsFteCount = @HrsFteCount,MonTargetTran = @MonTargetTran,MonPrice = @MonPrice,
			DayTargetTran = @DayTargetTran,DayPrice = @DayPrice,DayWorkMode = @DayWorkMode ,Code = @Code,GroupName =@GroupName
			Where CustomerId = @CustomerId and CSId = @CSId
			End
		End
	End
End



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_CustomerServicesInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_CustomerServicesInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_CustomerServicesInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_CustomerServicesInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_CustomerServicesInsert] TO [DB_DMLSupport]
    AS [dbo];

