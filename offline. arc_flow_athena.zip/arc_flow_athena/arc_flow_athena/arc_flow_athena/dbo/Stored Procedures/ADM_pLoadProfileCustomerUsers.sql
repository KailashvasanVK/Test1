﻿CREATE Procedure ADM_pLoadProfileCustomerUsers
(
 @CustomerId INT = 16,
 @UserId INT= 1
)
AS
Begin

--Declare @UserLocationId int =(select isnull(LocationID,1) from ARC_REC_ATHENA..ARC_REC_USER_INFO where USERID=@UserId and ACTIVE=1) -- Code added by mallikarjun.nam 
  if OBJECT_ID('tempdb..#UserLocation') is not null drop table #UserLocation
			Create table #UserLocation( locationid int,LocationName varchar(50))
			insert into  #UserLocation(locationId,LocationName)
			exec ADM_GetUserLocation @userid,0


Select ui.EMPCODE,ui.NT_USERNAME,ui.REPORTING_TO ,ui.DOJ,deg.Designation,fun.FunctionName,ui.UserId ,
 SUBSTRING(( select  ',' +  Sc.ServiceName  from ADM_AccessServices ACS
 inner join ADM_Service Sc on ACS.ServiceId = Sc.ServiceId
 where ACS.CustomerId =@CustomerId and ACS.UserId = ui.USERID FOR XML PATH('')), 2,10000) AS Service ,
 SUBSTRING(( select  ',' +  Sc.ServiceName  from ADM_AccessServicesSchedule ACS
 inner join ADM_Service Sc on ACS.ServiceId = Sc.ServiceId
 where ACS.CustomerId =@CustomerId and ACS.UserId = ui.USERID FOR XML PATH('')), 2,10000) +' @ '+
 convert(varchar(19),(select top 1 ScheduledDt from ADM_AccessServicesSchedule  where  CustomerId =@CustomerId and UserId = ui.USERID )) 
 AS ScheduledService 
from ARC_REC_Athena..ARC_REC_USER_INFO as ui 
inner join ARC_REC_Athena ..ARC_REC_UserCustomer cust  on  cust.UserId = ui.USERID and cust.CustomerID = @CustomerId 	
inner join ARC_REC_Athena..HR_Designation deg on deg.DesigId = 	ui.DESIGNATION_ID
inner join ARC_REC_Athena..HR_Functionality fun on fun.FunctionalityId = ui.FUNCTIONALITY_ID 
Where-- Ui.Reporting_To =  (Select Nt_UserName from ARC_REC_Athena..arc_Rec_user_info where userid = @UserId)and
 exists (select 1 from ARC_REC_Athena..ARC_REC_UserCustomer where UserId = ui.USERID and CustomerID = @CustomerId)
and Ui.Active = 1 and Ui.Ahs_Prl = 'Y' and isnull(Ui.LocationID,1) in(select locationid from #UserLocation)--= @UserLocationId -- Code added by mallikarjun.nam 
order by ui.NT_USERNAME
END








GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pLoadProfileCustomerUsers] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pLoadProfileCustomerUsers] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pLoadProfileCustomerUsers] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pLoadProfileCustomerUsers] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pLoadProfileCustomerUsers] TO [DB_DMLSupport]
    AS [dbo];

