﻿CREATE PROC [dbo].[ArchiveLog_ImportChecking] (@Scandate VARCHAR(10),@Actions VARCHAR(15))        
as  
/*        
    
Cretaed By     : Leela.T    
Created Date   : 2016-05-19     
Purpose        : Before Delete the Files cross check its Imported or Not  
Ticket/SCR ID  : <145948>    
TL Verified By : <Ramakrishnan.G  >    
 
Modified by:Leela.T
Modified Date :2016-05-27 
Modified Purpose :Add the Dump Files Details 
TL Verified By : <Ramakrishnan.G  >    
  
    
Implemented by :  Uhayaganesh.p	  
Implemented On :  2016-05-27  
    
Reviewd by     :  Uhayaganesh
Implemented On :   2016-05-27  
    
*/    
        
        
begin      
Declare @path   varchar(200)    
if (@Actions='Scanfiles')      
select count(Batchid) from trn_koff_tbatches(nolock) where convert (date,ScanDate,101)=convert (date,@ScanDate,101) and LEFT(batchno,1) not in('M','S')       
if (@Actions='MergeFiles')    
select count(Batchid) from trn_koff_tbatches(nolock) where convert (date,ScanDate,101)=convert (date,@ScanDate,101) and LEFT(batchno,1)  in('M','S')       
if(@Actions='DumpFile')    
begin    
set @path='\\fs-ib\athenaftp\ClaimDump\' + @Scandate    
select status from  Arc_AThena..CurrentDumpPath where Pathname like '%'+@path+'%' and filetype in ('I','P','C')    
End    
End    


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ArchiveLog_ImportChecking] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ArchiveLog_ImportChecking] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ArchiveLog_ImportChecking] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ArchiveLog_ImportChecking] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ArchiveLog_ImportChecking] TO [DB_DMLSupport]
    AS [dbo];

