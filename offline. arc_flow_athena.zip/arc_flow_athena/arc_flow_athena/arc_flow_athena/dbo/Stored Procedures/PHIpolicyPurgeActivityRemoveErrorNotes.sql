﻿Create Procedure PHIpolicyPurgeActivityRemoveErrorNotes
As
/*
Created By :Mallikarjun
Created On : 23-06-2017
Purpose    : To Remove Error Notes (PHI Purge policy)
Implemented By:Karmegan.C
Implemented On:23-06-2017
*/
Begin

select cl.ClientId into #AscensionClient from ARC_athena..AscensionClient ac
inner join arc_flow_athena..adm_client cl on ac.ContextID = cl.Clientid

/*Non Ascension client - delete error feedback notes */
Update qctran set qctran.ErrNotes=Null
from arc_flow_athena..TRN_koff_tbatchqctran(nolock) qctran
inner join arc_flow_athena..TRN_koff_tbatchqueue(nolock) que on qctran.BatchProcessId = que.BatchProcessId
where not exists (select clientid from #AscensionClient tmp where tmp.ClientId=que.ClientID)
and convert(date,qctran.CreatedDt) < Convert(date,DateAdd(m,-5,getdate()))

/*Ascension client */
Update qctran set qctran.ErrNotes=Null
from arc_flow_athena..TRN_koff_tbatchqctran(nolock) qctran
inner join arc_flow_athena..TRN_koff_tbatchqueue(nolock) que on qctran.BatchProcessId = que.BatchProcessId
where not exists (select clientid from #AscensionClient tmp where tmp.ClientId=que.ClientID)
and convert(date,qctran.CreatedDt) < Convert(date,DateAdd(d,-5,getdate()))

End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[PHIpolicyPurgeActivityRemoveErrorNotes] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[PHIpolicyPurgeActivityRemoveErrorNotes] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[PHIpolicyPurgeActivityRemoveErrorNotes] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[PHIpolicyPurgeActivityRemoveErrorNotes] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[PHIpolicyPurgeActivityRemoveErrorNotes] TO [DB_DMLSupport]
    AS [dbo];

