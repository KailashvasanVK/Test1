﻿CREATE Procedure GetCurrentDate
as
Begin 
/*
 CreatedBy : Kathiravan
 CreatedDt : 02-Feb- 2014
 Purpose    : To load the current date from the server for Delaware autonomous batch crester
*/
   select REPLACE(convert(varchar,GETDATE(),101),'/','') as CurrentDate
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[GetCurrentDate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[GetCurrentDate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[GetCurrentDate] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[GetCurrentDate] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[GetCurrentDate] TO [DB_DMLSupport]
    AS [dbo];

