﻿CREATE Procedure  TRN_ExtranetPendingbathcesReport
(
@pCmpKey varchar(5) = '',
@pServiceId int  = 0,
@pClientId int =0,
@SearchStr varchar(100) = '',
@SearchPattern varchar(4) = '=' /** = or % **/
)
AS
BEGIN
	Declare @qry varchar(max)
	if OBJECT_ID('tempdb..#pendingbatches') is not null drop table #pendingbatches
	Create table #pendingbatches(ScanDate date,[Client] varchar(100))
	Set @qry = '
	Insert into #pendingbatches(ScanDate,Client)
	Select Bat.ScanDate,cli.ClientAcmName [Client]
	from TRN_k'+@pCmpKey+'_tBatches as Bat
	inner join ADM_Client as Cli on Cli.ClientId = Bat.ClientId
	inner join ADM_Service as Ser on Ser.ServiceId = Bat.ServiceId '
	if isnull(@pServiceId,0) <> 0 
	   Set @qry += ' And Ser.ServiceId = '+CONVERT(Varchar,@pServiceId)
	if(ISNULL(@pClientId,0)<>0)
	    Set @qry += ' And Cli.ClientId = '+CONVERT(Varchar,@pClientId)
	Set @qry += ' Where UploadDt is null'
	Exec (@qry)
	if OBJECT_ID('tempdb..#pendingbatchesSummary') is not null drop table #pendingbatchesSummary
	Create Table #pendingbatchesSummary([Result~Hide] int,[ColHead] varchar(5),[ScanDate~Hide] date,ScanDate varchar(50))
	Insert into #pendingbatchesSummary([Result~Hide],ColHead,[ScanDate~Hide],ScanDate)
	Select Convert(int,0) as [Result~Hide],Convert(varchar(5),'') as [ColHead],Convert(date,Scandate) [ScanDate~Hide]
	,Convert(varchar,ScanDate,101)Scandate
	from #pendingbatches group by ScanDate 

	Insert into #pendingbatchesSummary(Scandate,ColHead,[Result~Hide])values('Total','G',2)
	Declare @Client varchar(100)
	Declare cur cursor  for select Client from #pendingbatches group by Client
	open cur
	while 1=1
		  Begin
			  Fetch next from cur into @Client
			  if @@FETCH_STATUS = -1 break
			  set @qry = ' Alter table #pendingbatchesSummary Add [' + @Client + '] int'
			  exec (@qry)
			  set @qry = ' 
			  Update #pendingbatchesSummary Set [' + @Client + '] = (Select COUNT(*) from #pendingbatches Where ScanDate = t.[ScanDate~Hide] and Client = '''+@Client+''')
			  from #pendingbatchesSummary as t Where t.[Result~Hide] = 0
			  Update #pendingbatchesSummary Set [' + @Client + '] = (Select COUNT(*) from #pendingbatches Where Client = '''+@Client+''')
			  from #pendingbatchesSummary as t Where t.[Result~Hide] = 2
			  '
			  exec (@qry)
		  End
	close cur
	DeAllocate cur
--	Select * from #pendingbatchesSummary Order by [Result~Hide],[ScanDate~Hide] 
	
	Exec FilterTable  
      @DbName = 'tempdb'  
      ,@TblName = '#pendingbatchesSummary'  
      ,@SearchStr = @SearchStr  
      ,@SearchPattern = @SearchPattern  
      ,@OrderStr = ''
      if OBJECT_ID('tempdb..#pendingbatchesSummary') is not null drop table #pendingbatchesSummary  

	if OBJECT_ID('tempdb..#pendingbatches') is not null drop table #pendingbatches
	if OBJECT_ID('tempdb..#pendingbatchesSummary') is not null drop table #pendingbatchesSummary
END


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_ExtranetPendingbathcesReport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_ExtranetPendingbathcesReport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_ExtranetPendingbathcesReport] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_ExtranetPendingbathcesReport] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_ExtranetPendingbathcesReport] TO [DB_DMLSupport]
    AS [dbo];

