﻿CREATE procedure [dbo].[ARC_Contract_Offline_GenerateYesterdayInvoice] (@Attdate date =null)
AS  
BEGIN  

if(@Attdate is null)
set @Attdate=getdate()-1

Declare @qry varchar(max)
Declare @CustomerId int

 
 /* Offline Daily Invoice-start */
 
	set @CustomerId=25

	Set @qry = ' Exec dbo.[ARC_Contract_Generate_Offline_DailyInvoice] '+Convert(varchar,@CustomerId)+', '''+Convert(varchar,@AttDate)+''''
	Exec (@qry)

 /* Offline Daily Invoice-start */
  
  
ENd

/* Offline Daily Invoice  -end*/


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Contract_Offline_GenerateYesterdayInvoice] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Contract_Offline_GenerateYesterdayInvoice] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Contract_Offline_GenerateYesterdayInvoice] TO [DB_DMLSupport]
    AS [dbo];

