﻿CREATE Procedure ADM_ConfigReports_Insert
 @ReportName varchar(75) =''
,@FieldName varchar(40) = ''
,@FieldDisplayText varchar(40) = ''
,@DisplayOrder int = 1
,@CustomerId int = 0
,@CtrlType varchar(20) = ''
,@CtrlValue varchar(100)= ''
,@Action varchar(50)
,@ServiceId int = 0
,@CreatedBy int =0
As
/*
 * Purpose : To configure the extranet customer's reports.
 */
Begin
If (@Action = 'InsertCustomizedFields')
	Begin
		Insert into ADM_ConfigReports (ReportName,FieldName,FieldDisplayText,DisplayOrder, CustomerId,CtrlType,CtrlValue,ServiceId,CreatedBy)
		Select @ReportName,@FieldName,@FieldDisplayText,@DisplayOrder,@CustomerId,@CtrlType,@CtrlValue,@ServiceId,@CreatedBy
	End
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ConfigReports_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ConfigReports_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ConfigReports_Insert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ConfigReports_Insert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ConfigReports_Insert] TO [DB_DMLSupport]
    AS [dbo];

