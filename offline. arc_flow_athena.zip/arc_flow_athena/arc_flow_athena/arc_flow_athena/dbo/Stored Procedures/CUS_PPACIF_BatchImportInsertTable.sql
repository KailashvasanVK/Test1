﻿CREATE Procedure CUS_PPACIF_BatchImportInsertTable  
@ScanDate  date  =  null,  
@BatchNo varchar(50) ,  
@ClientName  varchar(50),  
@ServiceName varchar(75)  
as  
/*  
 To insert data into temp table for  North East Coding Batch Import.    
*/  
Begin  
Insert into Temp_CUS_TPACIF_BatchImport  (ScanDate ,BatchNo ,ClientName ,ServiceName)  
Select  (case when isnull(@ScanDate,'') = '' then GETDATE()-1 else @ScanDate end ) ,@BatchNo,@ClientName,@ServiceName   
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_PPACIF_BatchImportInsertTable] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_PPACIF_BatchImportInsertTable] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_PPACIF_BatchImportInsertTable] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_PPACIF_BatchImportInsertTable] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_PPACIF_BatchImportInsertTable] TO [DB_DMLSupport]
    AS [dbo];

