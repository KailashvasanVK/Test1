﻿CREATE Procedure  ADM_GetColumnFilter
	(
	@CustomerId int,
	@ReportName varchar(75)
	)
As
 Begin 
	/*
	ADM_GetColumnFilter 1,@ReportName = 'Extranet Tracking Report' 
	*/
	--select FieldName,FieldDisplayText,isnull(ColumnWidth,'') from ADM_ConfigReports where CustomerId=@CustomerId and IsFilter='Y'
	--Select FieldName,FieldDisplayText,case when isnull (ColumnWidth,0) = 0  then '""' else  cast(ColumnWidth as varchar) + 'px' end  as ColumnWidth 
	--from ADM_ConfigReports where CustomerId =@CustomerId and IsFilter='Y'.
	select FieldName,FieldDisplayText from ADM_ConfigReports where CustomerId=@CustomerId and IsFilter='Y' and ReportName = @ReportName
 End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_GetColumnFilter] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetColumnFilter] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetColumnFilter] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_GetColumnFilter] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetColumnFilter] TO [DB_DMLSupport]
    AS [dbo];

