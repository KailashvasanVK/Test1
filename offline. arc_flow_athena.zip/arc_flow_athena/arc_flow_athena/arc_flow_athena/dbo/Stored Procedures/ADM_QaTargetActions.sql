﻿CREATE Procedure [dbo].[ADM_QaTargetActions]              
(            
 @TargetName VARCHAR(30)='',            
 @Action  VARCHAR(100)='',            
 @TargetId INT=0,          
 @Status INT=0,          
 @CreatedBy INT=0          
)            
AS            
BEGIN                 
IF(@Action ='TargetNameCheck')                
BEGIN                            
/*                        
Purpose           :  1)To check the TargetName in Processtarget              
      2)Select All Targetname and Status Details in Processtarget     
      3)Select Targetdetails by TargetId  
      4)Updating the status into ADM_ProcessTarget  
      5)Updating the ProcessTargetDetails  
Created By        : Kathiravan                        
Created Date      :17 may 2013       
Impact to         : ProcessTarget.aspx                        
*/                              
   IF EXISTS (SELECT TOP 1 TargetName  FROM ADM_QaTarget  WHERE  TargetName=@TargetName)                                
    BEGIN                                
     SELECT 1                                
    END                            
   ELSE                                
    BEGIN                                
     SELECT 2                                
    END              
END                 
 ELSE IF(@Action ='SelectTargetName')                
   BEGIN            
     SELECT TargetId,TargetName,            
     CASE Status  WHEN 1 THEN 'Active' WHEN 0 THEN 'InActive' END   AS Status                                 
     FROM ADM_QaTarget ORDER BY TargetName           
   END             
   ELSE IF(@Action='GetTagetRangeByTargetID')            
   BEGIN            
     SELECT TargetId,Fromday,Today,TargetPercent FROM ADM_QatargetTran WHERE TargetId=@TargetId            
   END            
  ELSE IF(@Action ='UpdateProcessTargetstatus')          
  BEGIN          
      INSERT INTO ADM_QaTargetLog(TargetId,TargetName,CreatedBy,Status)        
      SELECT TargetId,TargetName,CreatedBy,Status frOm ADM_QaTarget        
      UPDATE ADM_QaTarget SET Status=@Status where TargetId=@TargetId           
  END          
    ELSE IF(@Action ='UpdateProcessTarget')          
  BEGIN          
      UPDATE ADM_QaTarget SET TargetName=@TargetName,Status=@Status WHERE TargetId=@TargetId          
  END          
 END


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_QaTargetActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_QaTargetActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_QaTargetActions] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_QaTargetActions] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_QaTargetActions] TO [DB_DMLSupport]
    AS [dbo];

