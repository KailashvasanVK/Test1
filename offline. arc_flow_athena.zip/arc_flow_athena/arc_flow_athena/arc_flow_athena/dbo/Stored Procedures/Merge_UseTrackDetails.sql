﻿
create proc Merge_UseTrackDetails ( @MergeType varchar(30),@LogStatus varchar(30),@SystemIP varchar(20))  
as   
begin  
  /*                        
                    
Cretaed By     : Leela.T                    
Created Date   : 2017-04-10                    
Purpose        : Insert the Application Login Details           
Ticket/SCR ID  : 1195                   
TL Verified By : Udhayaganesh               
                
                 
Implemented by : Udhdyaganesh.p          
Implemented On : 10-April-2017            
                    
Reviewd by     : Udhdyaganesh.p                   
Implemented On : 10-April-2017                   
                    
*/         
insert into Merge_LoginTrack(MergeType,LogStatus,SystemIP) values (@MergeType,@LogStatus,@SystemIP)
  
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Merge_UseTrackDetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Merge_UseTrackDetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Merge_UseTrackDetails] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Merge_UseTrackDetails] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Merge_UseTrackDetails] TO [DB_DMLSupport]
    AS [dbo];

