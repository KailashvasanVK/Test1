﻿CREATE Procedure TRN_kOFF_pMarkBatchCompleted(@BatchId int,@CreatedBy int,@BatchProcessId int)  
As  
Begin  
Declare @ProcessCount int,@DirUpload int = 0,@NewUser int=0
Select @ProcessCount = COUNT(batchid) from TRN_kOFF_tBatchQueue Where BatchId = @BatchId  
if @ProcessCount <= (Select COUNT(batchid) from TRN_kOFF_tBatchFlow Where BatchId = @BatchId and StatusId = 12)  
 Begin  
 /** All the process has been met qc completed. AuditDt should be mark on Batch table **/  
 Update TRN_kOFF_tBatches Set AuditedDt = GETDATE() Where BatchId = @BatchId  
 End

/* These users entry completed batches must go to audit     For SCR#841*/
      Select @NewUser = (Select COUNT(*) 
      from TRN_kOFF_tBatchFlow as flow
      inner join ADM_QCAuditSkipUsers as NewUsers on NewUsers.UserId = flow.CreatedBy and NewUsers.Status = 1
      Where BatchId = @BatchId and StatusId = 6)
      
      if (@NewUser > 0)
            if (Select COUNT(*) from TRN_kOFF_tDirectUpload Where BatchId = @BatchId and Status = 1) > 0
                  update TRN_kOFF_tDirectUpload set status=0,UpdatedBy=1777
                  ,UpdatedDt=getdate()
                  ,Comments='Release from Direct upload by system' where BatchId = @BatchId and Status = 1

Select @DirUpload = COUNT(batchid) from TRN_kOFF_tDirectUpload where BatchId = @BatchId and Status = 1  
if (Select COUNT(batchid) from TRN_kOFF_tBatches Where BatchId = @BatchId and PostedDt is not null and (AuditedDt is not null or @DirUpload >= 1)) > 0  
 Begin  
 /** All the process has been met entry & qc completed.**/  
 if (Select COUNT(*) from TRN_kOFF_tBatchFlow Where BatchId = @BatchId and StatusId = 13) = 0  
  Insert into TRN_kOFF_tBatchFlow (BatchId,BatchProcessId,CreatedBy,CreatedDt,StatusId,Comments)Values(@BatchId,@BatchProcessId,@CreatedBy,GETDATE(),13,'')  
 Update TRN_kOFF_tBatchQueue Set StatusId = 13 Where BatchId = @BatchId  
 Update TRN_kOFF_tBatches Set UploadDt = GETDATE() Where BatchId = @BatchId  
 End  
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pMarkBatchCompleted] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pMarkBatchCompleted] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pMarkBatchCompleted] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pMarkBatchCompleted] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pMarkBatchCompleted] TO [DB_DMLSupport]
    AS [dbo];

