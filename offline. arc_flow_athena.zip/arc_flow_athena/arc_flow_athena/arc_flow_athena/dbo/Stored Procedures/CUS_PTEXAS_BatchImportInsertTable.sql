﻿CREATE Procedure CUS_PTEXAS_BatchImportInsertTable  
@ScanDate  date  = null,
@PageNo int,
@BatchNo varchar(50) ,  
@ClientName  varchar(50),  
@ServiceName varchar(50)  
as  
/*  
 To insert data into temp table for  Texas Batch Import.    
*/  
Begin  
Insert into Temp_CUS_TTEXASBatchCreater (ScanDate ,BatchNo ,ClientName ,ServiceName,PageNo)  
Select case when isnull(@ScanDate,'')= '' then getdate()-1 else @ScanDate end ,@BatchNo,@ClientName,@ServiceName ,@PageNo   
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_PTEXAS_BatchImportInsertTable] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_PTEXAS_BatchImportInsertTable] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_PTEXAS_BatchImportInsertTable] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_PTEXAS_BatchImportInsertTable] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_PTEXAS_BatchImportInsertTable] TO [DB_DMLSupport]
    AS [dbo];

