﻿CREATE Procedure CUS_kOFF_pDeMergeV1  (@Batchnum varchar(20))
As        
Begin        
/*         
358 OffLine Pmt        
361 OffLine Self Posting        
360 OffLine Exception Posting        
359 OffLine Collection        
364 Offline Patient Creation        
*/        
/*
Modified by : mohamedsafiyu.a
Modified On : 10/19/2015
Action : Directly marked status 99 for parent batch. Hence this routine will work for single batch only

Modified by : mohamedsafiyu.a
Modified On : 10/29/2015
Action : Directly marked status 99 for parent batch condition applied on status and uploaddt . Hence this routine will work for single batch only

*/   
   
/*************************************** ParentBatches FTE Info ************************************************/
if OBJECT_ID('Tempdb..#TempParentBatches') is not null drop table #TempParentBatches
Create Table #TempParentBatches(BatchId int,BatchNo varchar(75),ServiceId int,UploadDt datetime,PostedDt datetime,AuditedDt datetime)
Insert into #TempParentBatches(BatchId,BatchNo,ServiceId,UploadDt,PostedDt,AuditedDt)
Select BatchId,BatchNo,ServiceId,UploadDt,PostedDt,AuditedDt from TRN_kOFF_tBatches as Bat where BatchNo = @Batchnum and Bat.status = 20

if OBJECT_ID('Tempdb..#TempParentBathQueue') is not null drop table #TempParentBathQueue
Create Table #TempParentBathQueue(BatchId int,BatchProcessId int)
Insert into #TempParentBathQueue(BatchId,BatchProcessId)
Select q.BatchId,q.BatchProcessId 
from TRN_kOFF_tBatchQueue as q
inner join #TempParentBatches as b on b.BatchId = q.BatchId

if OBJECT_ID('Tempdb..#TempParentBatchFlow') is not null drop table #TempParentBatchFlow
Create Table #TempParentBatchFlow(BatchId int,BatchProcessId int,StatusId int,CreatedBy int,CreatedDt datetime)
Insert into #TempParentBatchFlow(BatchId,BatchProcessId,StatusId,CreatedBy,CreatedDt)
Select flow.BatchId,flow.BatchProcessId,flow.StatusId,flow.CreatedBy,flow.CreatedDt 
from TRN_kOFF_tBatchFlow as flow 
inner join #TempParentBatches as b on b.BatchId = flow.BatchId

if OBJECT_ID('Tempdb..#TempParentBathTransact') is not null drop table #TempParentBathTransact
Create table #TempParentBathTransact(BatchId int,BatchProcessId int,ServiceId int, TransValue int,LocationId int,ShiftId int)
Insert into #TempParentBathTransact(BatchId,BatchProcessId,ServiceId,TransValue,LocationId,ShiftId)
Select t.BatchId,t.BatchProcessId,t.ServiceId,t.TransValue,t.LocationId,t.ShiftId 
from TRN_kOFF_tBatchTransact as t
inner join #TempParentBatches as b on b.BatchId  = t.BatchId

if OBJECT_ID('Tempdb..#TempParentBatchQcMaster') is not null drop table #TempParentBatchQcMaster
Create table #TempParentBatchQcMaster(BatchProcessId int,TransValue int,LocationId int,ShiftId int,QCPercentage decimal(9,2))
Insert into #TempParentBatchQcMaster(BatchProcessId,TransValue,LocationId,ShiftId,QCPercentage)
Select qm.BatchProcessId,qm.TransValue,qm.LocationId,qm.ShiftId,qm.QCPercentage 
from TRN_kOFF_tBatchQCMaster as qm 
inner join #TempParentBathQueue as q on q.BatchProcessId = qm.BatchProcessId

if OBJECT_ID('Tempdb..#TempParentBatchQcComments') is not null drop table #TempParentBatchQcComments
Create table #TempParentBatchQcComments(BatchProcessId int,LocationId int,ShiftId int,CreatedBy int,CreatedDt datetime)
Insert into #TempParentBatchQcComments(BatchProcessId,LocationId,ShiftId,CreatedBy,CreatedDt)
Select qm.BatchProcessId,qm.LocationId,qm.ShiftId,qm.CreatedBy,qm.CreatedDt
from TRN_kOFF_tBatchQCComments as qm 
inner join #TempParentBathQueue as q on q.BatchProcessId = qm.BatchProcessId


if OBJECT_ID('Tempdb..#TempParentBatchQcTran') is not null drop table #TempParentBatchQcTran
Create table #TempParentBatchQcTran(BatchProcessId int,PageNo int,ClassifyId int,SubClassifyId int,CreatedBy int
,CreatedDt datetime,ErrNotes varchar(500),ErrCount int,AcknowledgeBy int,AcknowledgeDt datetime,SubClassifyId2 int
,InvoiceId int,ChargeId int,LocationId int,ShiftId int,CategoryId int,SeverityId int)

Insert into #TempParentBatchQcTran(BatchProcessId,PageNo,ClassifyId,SubClassifyId,CreatedBy,CreatedDt,ErrNotes,ErrCount,AcknowledgeBy,AcknowledgeDt,SubClassifyId2,InvoiceId,ChargeId,LocationId,ShiftId,CategoryId,SeverityId)
Select qt.BatchProcessId,qt.PageNo,qt.ClassifyId,qt.SubClassifyId,qt.CreatedBy,qt.CreatedDt,qt.ErrNotes,qt.ErrCount,qt.AcknowledgeBy,qt.AcknowledgeDt,qt.SubClassifyId2,qt.InvoiceId,qt.ChargeId,qt.LocationId,qt.ShiftId
,qt.CategoryId,qt.SeverityId from TRN_kOFF_tBatchQCTran as qt
inner join #TempParentBatchQcComments as comm on comm.BatchProcessId = qt.BatchProcessId

if OBJECT_ID('Tempdb..#DeMergeBatchesEntry') is not null drop table #DeMergeBatchesEntry       
Select Bat.BatchNo as ParentBatchNo,Bat.BatchId,Flow.CreatedBy,Flow.CreatedDt,isnull(FteStFlow.CreatedDt,Flow.CreatedDt) as AssignedDt
,(Select top 1 LocationId from #TempParentBathTransact Where BatchId = bat.BatchId) LocationId
,(Select top 1 ShiftId from #TempParentBathTransact Where BatchId = bat.BatchId) ShiftId
into #DeMergeBatchesEntry        
from #TempParentBatches as Bat         
left join #TempParentBatchFlow as FteStFlow on FteStFlow.BatchId = Bat.BatchId and FteStFlow.StatusId = 1
inner join #TempParentBatchFlow as Flow on Flow.BatchId = Bat.BatchId and Flow.StatusId = 6        

if OBJECT_ID('Tempdb..#TempMergeBatchDetails') is not null drop table #TempMergeBatchDetails
Create Table #TempMergeBatchDetails(ParentBatchNo varchar(100),ChildBatchNo varchar(100),StartpgNo int
,EndPgNo int,TotalPages int,Payment int,Selfpay int,Exception int,Collection int,NewPt int ,QPayment int,QSelfPay int,QExeption int,QCollection int
,QNewPt int)
Insert into #TempMergeBatchDetails(ParentBatchNo,ChildBatchNo,StartpgNo,EndPgNo,TotalPages,Payment,Selfpay,Exception,Collection,NewPt,QPayment,QSelfPay,QExeption,QCollection,QNewPt )
Select ParentBatchNo,ChildBatchNo,StartpgNo,EndPgNo,TotalPages,Payment,Selfpay,Exception,Collection,NewPt,QPayment,QSelfPay,QExeption,QCollection,QNewPt 
from MergeBatchDetails as mb
Where mb.ParentBatchNo = @BatchNum

if OBJECT_ID('Tempdb..#TempChildBatches') is not null drop table #TempChildBatches
Create table #TempChildBatches(BatchId int,BatchNo varchar(100),PgCount int)
Select child.BatchId,child.BatchNo,child.PgCount from TRN_kOFF_tBatches as child
inner join #TempMergeBatchDetails as mb on mb.ChildBatchNo = child.BatchNo

if OBJECT_ID('Tempdb..#TempChildBatchQueue') is not null drop table #TempChildBatchQueue
Create table #TempChildBatchQueue(BatchId int,BatchProcessId int,BatchNo varchar(75))
Select childq.BatchId,childq.BatchProcessId,childq.BatchNo from TRN_kOFF_tBatchQueue as childq
inner join #TempChildBatches as mb on mb.BatchId = childq.BatchId


Declare @ServiceId int 
Select @ServiceId = ServiceId from TRN_kOFF_tBatches as bat Where BatchNo = @Batchnum
Declare 
@FactorPayment float /** Payment (358) transaction count */    
,@FactorCollection float /** Collection (359) transaction count */    
,@FactorExceptionPosting float /** ExceptionPosting (360) transaction count */    
,@FactorSelfPosting float /** SelfPosting (361) transaction count */    
,@FactorPatientPosting float /** PatientPosting (364) transaction count */ 
,@QcFactorPayment float /** Payment (358) transaction count */    
,@QcFactorCollection float /** Collection (359) transaction count */    
,@QcFactorExceptionPosting float /** ExceptionPosting (360) transaction count */    
,@QcFactorSelfPosting float /** SelfPosting (361) transaction count */    
,@QcFactorPatientPosting float /** PatientPosting (364) transaction count */ 

Select 
@FactorPayment = EntryPayment
,@FactorCollection = EntryCollection
,@FactorExceptionPosting = EntryExceptionPosting
,@FactorSelfPosting = EntrySelfPosting
,@FactorPatientPosting = EntryPatientCreation 
,@QcFactorPayment = QcPayment
,@QcFactorCollection = QcCollection
,@QcFactorExceptionPosting = QcExceptionPosting
,@QcFactorSelfPosting = QcSelfPosting
,@QcFactorPatientPosting = QcPatientCreation 
from ADM_FactorWaterTown 
Where ServiceGroupId = @ServiceId and CONVERT(date,getdate()) between EffectiveFrom and isnull(EffectiveTo,GETDATE())

--Create Table DeMergeBatchesEntry_Log (ParentBatchNo varchar(15), BatchId bigint, CreatedBy int, CreatedDt Datetime , AssignedDt Datetime,ExtractTime datetime)
Insert into DeMergeBatchesEntry_Log  
select ParentBatchNo, BatchId, CreatedBy, CreatedDt, AssignedDt,getdate() from #DeMergeBatchesEntry 
        
/*************************************** ParentBatches QC Info ************************************************/
if OBJECT_ID('Tempdb..#DeMergeBatchesQc') is not null drop table #DeMergeBatchesQc        
Select Bat.BatchNo as ParentBatchNo  
,Bat.BatchId,Flow.CreatedBy,Flow.CreatedDt,FteFlow.CreatedBy as FteId        
,(Select Top 1 QcPercentage from #TempParentBatchQcMaster Where BatchProcessId = Que.BatchProcessId) as QcPerCentage        
,(Select Top 1 LocationId from #TempParentBatchQcComments Where BatchProcessId = Que.BatchProcessId) as LocationId 
,(Select Top 1 ShiftId from #TempParentBatchQcComments Where BatchProcessId = Que.BatchProcessId) as ShiftId
,QcStFlow.CreatedDt as QcAssignedDt   
into #DeMergeBatchesQc
from #TempParentBatches as Bat         
inner join #TempParentBathQueue as Que on Que.BatchId = Bat.BatchId        
inner join #TempParentBatchFlow as QcStFlow on QcStFlow.BatchId = Bat.BatchId and QcStFlow.StatusId = 7        
inner join #TempParentBatchFlow as Flow on Flow.BatchId = Bat.BatchId and Flow.StatusId = 12        
inner join #TempParentBatchFlow as FteFlow on FteFlow.BatchId = Bat.BatchId and FteFlow.StatusId = 6        


Insert into DeMergeBatchesQc_Log 
select  ParentBatchNo ,BatchId,CreatedBy,CreatedDt,FteId,getdate() from #DeMergeBatchesQc
        
/*************************************** Inserting Entry Transaction ************************************************/        
Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,LocationId,ShiftId,FactorTrans)
Select ChildQue.BatchProcessId,ChildBat.PgCount,358,isnull(MergeMast.Payment,0),DeMerge.CreatedBy,DeMerge.CreatedDt,ChildQue.BatchId,ChildQue.ServiceId,ChildQue.ClientId,DeMerge.LocationId,DeMerge.ShiftId,@FactorPayment
from #TempChildBatchQueue as ChildQue        
inner join #TempChildBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId        
inner join #TempMergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo and isnull(MergeMast.Payment,0) > 0        
inner join #DeMergeBatchesEntry as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo        
        
Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,LocationId,ShiftId,FactorTrans)
Select ChildQue.BatchProcessId,ChildBat.PgCount,361,isnull(MergeMast.Selfpay,0),DeMerge.CreatedBy,DeMerge.CreatedDt,ChildQue.BatchId,ChildQue.ServiceId,ChildQue.ClientId,DeMerge.LocationId,DeMerge.ShiftId,@FactorSelfPosting
from #TempChildBatchQueue as ChildQue        
inner join #TempChildBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId        
inner join #TempMergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo and isnull(MergeMast.Selfpay,0) > 0        
inner join #DeMergeBatchesEntry as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo        
        
Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,LocationId,ShiftId,FactorTrans)
Select ChildQue.BatchProcessId,ChildBat.PgCount,360,isnull(MergeMast.Exception,0),DeMerge.CreatedBy,DeMerge.CreatedDt,ChildQue.BatchId,ChildQue.ServiceId,ChildQue.ClientId,DeMerge.LocationId,DeMerge.ShiftId,@FactorExceptionPosting
from #TempChildBatchQueue as ChildQue        
inner join #TempChildBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId        
inner join #TempMergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo and isnull(MergeMast.Exception,0) > 0        
inner join #DeMergeBatchesEntry as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo        
        
Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,LocationId,ShiftId,FactorTrans)
Select ChildQue.BatchProcessId,ChildBat.PgCount,359,isnull(MergeMast.Collection,0),DeMerge.CreatedBy,DeMerge.CreatedDt,ChildQue.BatchId,ChildQue.ServiceId,ChildQue.ClientId,DeMerge.LocationId,DeMerge.ShiftId,@FactorCollection
from #TempChildBatchQueue as ChildQue        
inner join #TempChildBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId        
inner join #TempMergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo and isnull(MergeMast.Collection,0) > 0        
inner join #DeMergeBatchesEntry as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo        
        
Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,LocationId,ShiftId,FactorTrans)
Select ChildQue.BatchProcessId,ChildBat.PgCount,364,isnull(MergeMast.NewPt,0),DeMerge.CreatedBy,DeMerge.CreatedDt,ChildQue.BatchId,ChildQue.ServiceId,ChildQue.ClientId,DeMerge.LocationId,DeMerge.ShiftId,@FactorPatientPosting
from #TempChildBatchQueue as ChildQue        
inner join #TempChildBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId        
inner join #TempMergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo and isnull(MergeMast.NewPt,0) > 0        
inner join #DeMergeBatchesEntry as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo        
        
/*************************************** Inserting QC Master ************************************************/        
Insert into TRN_kOFF_tBatchQCMaster(BatchProcessId,PageNo,CreatedBy,CreatedDt,ServiceId,TransValue,FTE_Id,QCPercentage,LocationId,ShiftId,FactorTrans,BatchId)
Select ChildQue.BatchProcessId,ChildBat.PgCount,DeMerge.CreatedBy,DeMerge.CreatedDt,358,isnull(MergeMast.QPayment,0),DeMerge.FteId,DeMerge.QcPerCentage,DeMerge.LocationId,DeMerge.ShiftId,@QcFactorPayment,ChildBat.BatchId
from #TempChildBatchQueue as ChildQue        
inner join #TempChildBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId        
inner join #TempMergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo and isnull(MergeMast.QPayment,0) > 0        
inner join #DeMergeBatchesQc as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo        
        
Insert into TRN_kOFF_tBatchQCMaster(BatchProcessId,PageNo,CreatedBy,CreatedDt,ServiceId,TransValue,FTE_Id,QCPercentage,LocationId,ShiftId,FactorTrans,BatchId)
Select ChildQue.BatchProcessId,ChildBat.PgCount,DeMerge.CreatedBy,DeMerge.CreatedDt,361,isnull(MergeMast.QSelfpay,0),DeMerge.FteId,DeMerge.QcPerCentage,DeMerge.LocationId,DeMerge.ShiftId,@QcFactorSelfPosting,ChildBat.BatchId
from #TempChildBatchQueue as ChildQue        
inner join #TempChildBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId        
inner join #TempMergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo and isnull(MergeMast.QSelfpay,0) > 0        
inner join #DeMergeBatchesQc as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo        
        
Insert into TRN_kOFF_tBatchQCMaster(BatchProcessId,PageNo,CreatedBy,CreatedDt,ServiceId,TransValue,FTE_Id,QCPercentage,LocationId,ShiftId,FactorTrans,BatchId)
Select ChildQue.BatchProcessId,ChildBat.PgCount,DeMerge.CreatedBy,DeMerge.CreatedDt,360,isnull(MergeMast.QExeption,0),DeMerge.FteId,DeMerge.QcPerCentage,DeMerge.LocationId,DeMerge.ShiftId,@QcFactorExceptionPosting,ChildBat.BatchId
from #TempChildBatchQueue as ChildQue        
inner join #TempChildBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId        
inner join #TempMergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo and isnull(MergeMast.QExeption,0) > 0 
inner join #DeMergeBatchesQc as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo        
        
Insert into TRN_kOFF_tBatchQCMaster(BatchProcessId,PageNo,CreatedBy,CreatedDt,ServiceId,TransValue,FTE_Id,QCPercentage,LocationId,ShiftId,FactorTrans,BatchId)        
Select ChildQue.BatchProcessId,ChildBat.PgCount,DeMerge.CreatedBy,DeMerge.CreatedDt,359,isnull(MergeMast.QCollection,0),DeMerge.FteId,DeMerge.QcPerCentage,DeMerge.LocationId,DeMerge.ShiftId,@QcFactorCollection,ChildBat.BatchId
from #TempChildBatchQueue as ChildQue        
inner join #TempChildBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId        
inner join #TempMergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo and isnull(MergeMast.QCollection,0) > 0        
inner join #DeMergeBatchesQc as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo        
        
Insert into TRN_kOFF_tBatchQCMaster(BatchProcessId,PageNo,CreatedBy,CreatedDt,ServiceId,TransValue,FTE_Id,QCPercentage,LocationId,ShiftId,FactorTrans,BatchId)
Select ChildQue.BatchProcessId,ChildBat.PgCount,DeMerge.CreatedBy,DeMerge.CreatedDt,364,isnull(MergeMast.QNewPt,0),DeMerge.FteId,DeMerge.QcPerCentage,DeMerge.LocationId,DeMerge.ShiftId,@QcFactorPatientPosting,ChildBat.BatchId
from #TempChildBatchQueue as ChildQue        
inner join #TempChildBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId        
inner join #TempMergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo and isnull(MergeMast.QNewPt,0) > 0        
inner join #DeMergeBatchesQc as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo        
/*************************************** Inserting Errors ************************************************/        
Insert into TRN_kOFF_tBatchQCTran(BatchProcessId,PageNo,ClassifyId,SubClassifyId,SubClassifyId2,CreatedBy,CreatedDt,ErrNotes,ErrCount,LocationId,ShiftId,InvoiceId,CategoryId,SeverityId)
Select ChildQue.BatchProcessId        
,(ParentErr.PageNo - MergeMast.StartpgNo)+1 PageNo ,ParentErr.ClassifyId,ParentErr.SubClassifyId,ParentErr.SubClassifyId2,ParentErr.CreatedBy,ParentErr.CreatedDt,ParentErr.ErrNotes,ParentErr.ErrCount,DeMerge.LocationId,DeMerge.ShiftId,InvoiceId
,ParentErr.CategoryId,ParentErr.SeverityId
from #TempChildBatchQueue as ChildQue        
inner join #TempChildBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId        
inner join #TempMergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo        
inner join #DeMergeBatchesQc as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo        
inner join #TempParentBathQueue as ParentQue on ParentQue.BatchId = DeMerge.BatchId        
inner join #TempParentBatchQcTran as ParentErr on ParentErr.BatchProcessId = ParentQue.BatchProcessId  and ParentErr.PageNo between MergeMast.StartpgNo and MergeMast.EndPgNo       
/*************************************** Inserting QC Comments ************************************************/        
Insert into TRN_kOFF_tBatchQCComments(BatchProcessId,Comments,CreatedBy,CreatedDt,FTE_Id,BatchId,FTE_QcPer,LocationId,ShiftId)
Select ChildQue.BatchProcessId,'',DeMerge.CreatedBy,DeMerge.CreatedDt,DeMerge.FteId,ChildQue.BatchId,deMerge.QcPerCentage,DeMerge.LocationId,DeMerge.ShiftId
from #TempChildBatchQueue as ChildQue        
inner join #TempChildBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId        
inner join #TempMergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo        
inner join #DeMergeBatchesQc as DeMerge on DeMerge.ParentBatchNo = MergeMast.ParentBatchNo        
/*************************************** Inserting Entry Assign ************************************************/        
Insert into TRN_kOFF_tBatchFlow(BatchId,BatchProcessId,CreatedDt,CreatedBy,StatusId,Comments)        
Select ChildQue.BatchId,ChildQue.BatchProcessId, ParentEntry.AssignedDt,ParentEntry.CreatedBy,1,''        
from #TempChildBatchQueue as ChildQue        
inner join #TempChildBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId        
inner join #TempMergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo        
inner join #DeMergeBatchesEntry as ParentEntry on ParentEntry.ParentBatchNo = MergeMast.ParentBatchNo        
/*************************************** Inserting Entry Complete ************************************************/        
Insert into TRN_kOFF_tBatchFlow(BatchId,BatchProcessId,CreatedDt,CreatedBy,StatusId,Comments)        
Select ChildQue.BatchId,ChildQue.BatchProcessId, ParentEntry.CreatedDt,ParentEntry.CreatedBy,6,''        
from #TempChildBatchQueue as ChildQue        
inner join #TempChildBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId        
inner join #TempMergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo        
inner join #DeMergeBatchesEntry as ParentEntry on ParentEntry.ParentBatchNo = MergeMast.ParentBatchNo        
/*************************************** Inserting Qc Assign ************************************************/        
Insert into TRN_kOFF_tBatchFlow(BatchId,BatchProcessId,CreatedDt,CreatedBy,StatusId,Comments)        
Select ChildQue.BatchId,ChildQue.BatchProcessId, ParentQc.QcAssignedDt ,ParentQc.CreatedBy,7,''        
from #TempChildBatchQueue as ChildQue        
inner join #TempChildBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId        
inner join #TempMergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo        
inner join #DeMergeBatchesQc as ParentQc on ParentQc.ParentBatchNo = MergeMast.ParentBatchNo        
/*************************************** Inserting Qc Complete ************************************************/        
Insert into TRN_kOFF_tBatchFlow(BatchId,BatchProcessId,CreatedDt,CreatedBy,StatusId,Comments)        
Select ChildQue.BatchId,ChildQue.BatchProcessId, ParentQc.CreatedDt,ParentQc.CreatedBy,12,''        
from #TempChildBatchQueue as ChildQue        
inner join #TempChildBatches as ChildBat on ChildBat.BatchId = ChildQue.BatchId        
inner join #TempMergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = ChildBat.BatchNo        
inner join #DeMergeBatchesQc as ParentQc on ParentQc.ParentBatchNo = MergeMast.ParentBatchNo        
/*************************************** Parent Status Change to 99 ************************************************/        
Update TRN_kOFF_tBatches Set status = 99 Where BatchNo =  @Batchnum and UploadDt is not null
/*
Update TRN_kOFF_tBatches Set status = 99         
from  TRN_kOFF_tBatches as bat        
inner join #DeMergeBatchesEntry as Parent on parent.BatchId = bat.BatchId        
Where bat.status = 20        
*/
/*************************************** Child Status update ************************************************/        
Insert into TRN_kOFF_tBatchFlow(BatchId,BatchProcessId,CreatedDt,CreatedBy,StatusId,Comments)        
Select que.BatchId,que.BatchProcessId, TempParent.AssignedDt ,ISNULL(tempQc.CreatedBy, TempParent.CreatedBy) ,13,''        
from #TempChildBatchQueue as que
inner join #TempMergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = que.BatchNo        
inner join #TempParentBatches as Parent on Parent.BatchNo = MergeMast.ParentBatchNo        
inner join #DeMergeBatchesEntry as TempParent on TempParent.BatchId = Parent.BatchId    
left join #DeMergeBatchesQc as TempQc on TempQc.BatchId = parent.BatchId    

Update TRN_kOFF_tBatchQueue Set StatusId = 13 ,Assigned = 0        
from  TRN_kOFF_tBatchQueue as que        
inner join #TempMergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = que.BatchNo        
inner join #TempParentBatches as Parent on Parent.BatchNo = MergeMast.ParentBatchNo        
inner join #DeMergeBatchesEntry as TempParent on TempParent.BatchId = Parent.BatchId        

  
Update Child Set UploadDt = Parent.UploadDt,PostedDt = parent.PostedDt,AuditedDt = parent.AuditedDt,status = 1   
from TRN_kOFF_tBatches as Child        
inner join #TempMergeBatchDetails as MergeMast on MergeMast.ChildBatchNo = child.BatchNo        
inner join #TempParentBatches as Parent on Parent.BatchNo = MergeMast.ParentBatchNo        
inner join #DeMergeBatchesEntry as TempParent on TempParent.BatchId = Parent.BatchId        
      
if OBJECT_ID('Tempdb..#DeMergeBatchesEntry') is not null drop table #DeMergeBatchesEntry        
if OBJECT_ID('Tempdb..#DeMergeBatchesQc') is not null drop table #DeMergeBatchesQc        
End	

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kOFF_pDeMergeV1] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kOFF_pDeMergeV1] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kOFF_pDeMergeV1] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kOFF_pDeMergeV1] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kOFF_pDeMergeV1] TO [DB_DMLSupport]
    AS [dbo];

