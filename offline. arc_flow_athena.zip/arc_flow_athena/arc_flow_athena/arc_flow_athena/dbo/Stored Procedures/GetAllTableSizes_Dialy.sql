﻿CREATE PROCEDURE GetAllTableSizes_Dialy        
AS        
/*
 Created by : Narayana.N
 Created Date: 03-21-2018
 Perpose: To monitor table grouth   
  
*/       
begin  
set nocount on; 
    
CREATE TABLE #TempTable        
(  
  tableName varchar(100),        
    numberofRows bigint,        
    reservedSize varchar(50),        
    dataSize varchar(50),        
    indexSize varchar(50),        
    unusedSize varchar(50)        
)  
  
DECLARE @TableName VARCHAR(100) ,@SchemaName Varchar(100),@qury varchar(max)       
DECLARE tableCursor  CURSOR        
FOR         
select   SCHEMA_NAME(schema_id) As SchemaName,name    
from sys.tables where type='u'  
OPEN tableCursor        
FETCH NEXT FROM tableCursor  INTO @SchemaName,@TableName       
        
WHILE @@Fetch_Status = 0        
BEGIN        
set @qury  =''  
set @qury  = @qury  + '  
INSERT  #TempTable    
EXEC sp_spaceused ''['+ @SchemaName +'].['+ @TableName+']'''     
exec (@qury  )  
FETCH NEXT FROM tableCursor INTO @SchemaName,@TableName    
END        
        
   
CLOSE tableCursor        
DEALLOCATE tableCursor        
  
--SELECT *FROM #TempTable  order by numberofRows desc      
insert into [LNKENTERPRISE].DBAevents_11.dbo.DialyTableCountDetails  
select @@SERVERNAME, DB_NAME(),*,CONVERT(date, getdate()) from #TempTable   
  
DROP TABLE #TempTable   
  
end  
  
  
  
  
  
  
  
  
  
  


 


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[GetAllTableSizes_Dialy] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[GetAllTableSizes_Dialy] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[GetAllTableSizes_Dialy] TO [DB_DMLSupport]
    AS [dbo];

