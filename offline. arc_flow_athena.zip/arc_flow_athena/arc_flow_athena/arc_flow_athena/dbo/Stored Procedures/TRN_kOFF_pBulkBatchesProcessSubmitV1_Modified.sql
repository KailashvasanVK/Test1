﻿CREATE procedure TRN_kOFF_pBulkBatchesProcessSubmitV1_Modified        
(        
 @AssignedTo int        
)        
AS        
Begin        
            
/*        
Created by : mallikarjun.nam        
Created Dt :2017-02-20        
Purpose : move bulk batches to entry completed status which are auto manual allocated.        
Ticket/SCR ID  :  1237 
TL Verified By : Ramakrishnan.G                  
                  
Implemented by : Ganesh Tanneru                  
Implemented On :  09-Jun-2017        
*/        
         
/*Declare @AssignedTo int=1973*/        
         
Begin Transaction                    
Begin Try                
         
 Declare @LocationId int,@ShiftId int,@PendingBatchCount int        
 Set @LocationId  =(Select LocationId from arc_rec_athena..arc_rec_User_Info(nolock) where UserId=@AssignedTo)        
 Set @ShiftId = (Select Top 1 SHIFT_ID from ARC_REC_ATHENA..ARC_REC_SHIFT_TRAN(nolock) where USERID = @AssignedTo and Effect_DATE <= GETDATE() Order by Effect_DATE desc)        
         
             
 update autosubmit set         
 autosubmit.EntryFactor=(Select EntryExceptionPosting from ADM_FactorWaterTown(nolock)         
 Where ServiceGroupId = autosubmit.ServiceId and CONVERT(date,getdate()) between EffectiveFrom and isnull(EffectiveTo,GETDATE())),        
 autosubmit.QcFactor=(Select QcExceptionPosting from ADM_FactorWaterTown (nolock)        
 Where ServiceGroupId = autosubmit.ServiceId and CONVERT(date,getdate()) between EffectiveFrom and isnull(EffectiveTo,GETDATE()))        
 from TRN_kOFF_tManualAllocattionBatchesAutoSubmit autosubmit where status=1 and AssignedTo=@AssignedTo         
             
             
 IF OBJECT_ID('tempdb..#AllocationBatches') IS NOT NULL DROP TABLE #AllocationBatches        
             
 Select bat.BatchId,bat.ServiceId,bat.ClientId,q.BatchProcessId,t.AssignedTo, EntryPayment,        
 EntrySelfPosting,EntryCollection,EntryExceptionPosting,EntryPatientCreation,EntryFactor into #AllocationBatches from TRN_kOFF_tBatches bat        
 inner join TRN_kOFF_tBatchQueue(nolock) as q on bat.batchid=q.batchid and bat.status=1        
 inner join TRN_kOFF_tManualAllocattionBatchesAutoSubmit(nolock) as t on t.BatchProcessId = q.BatchProcessId         
 and t.status=1 and t.AssignedTo=@AssignedTo         
 Where q.StatusId in (0,16) and q.Assigned = 0      
 and not exists(select 1 from trn_koff_theldbatches (nolock) where batchid=bat.batchid and ReleaseDate is null) /*exclude held batches*/      
            
            
    update  autoSubmit Set status=2,Comments='StatusId :' + Convert(varchar,que.statusid) + 'status:' + convert(varchar,bat.status) + ''        
    from TRN_kOFF_tManualAllocattionBatchesAutoSubmit autoSubmit        
    inner join TRN_kOFF_tBatchQueue que on que.BatchProcessId=autoSubmit.BatchProcessId        
    inner join TRN_kOFF_tBatches bat on bat.batchId=que.batchid        
    where not exists (Select 1 from #AllocationBatches where BatchProcessId=autoSubmit.BatchProcessId)        
                 
 if(select count(batchid) from #AllocationBatches)>0        
 Begin        
  Insert into TRN_kOFF_tBatchFlow(BatchId,BatchProcessId,Comments,CreatedBy,CreatedDt,StatusId)        
  Select q.BatchId,q.BatchProcessId,'Auto manual allocation-Assigned to user',AssignedTo,getdate(),1         
  from #AllocationBatches as q        
              
  Update q Set Assigned = t.AssignedTo,StatusId = 1,FlowId = (Select MAX(FlowId) from TRN_kOFF_tBatchFlow Where BatchProcessId = q.BatchProcessId and StatusId = 1)        
  From TRN_kOFF_tBatchQueue as q        
  inner join #AllocationBatches as t on  t.BatchProcessId = q.BatchProcessId        
  Where q.StatusId in (0,16) and q.Assigned = 0        
               
  /*Transaction Payment:358*/        
 -- if(select isnull(EntryPayment,0) from #AllocationBatches where isnull(EntryPayment,0)>0)>0        
  Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry,LocationId,ShiftId,FactorTrans)        
  Select BatchProcessId,1,358,EntryPayment,'',q.AssignedTo,getdate(),q.batchid,q.ServiceId,q.ClientId,0,@LocationId,@ShiftId,q.EntryFactor       
  from #AllocationBatches as q        
               
  /*Transaction Collection:359*/        
 -- if(select isnull(EntryCollection,0) from #AllocationBatches where isnull(EntryCollection,0)>0)>0        
  Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry,LocationId,ShiftId,FactorTrans)        
  Select BatchProcessId,1,359,EntryCollection,'',AssignedTo,getdate(),batchid,ServiceId,ClientId,0,@LocationId,@ShiftId,EntryFactor        
  from #AllocationBatches        
               
  /*Transaction ExceptionPosting:360*/        
  --if(select isnull(EntryExceptionPosting,0) from #AllocationBatches where isnull(EntryExceptionPosting,0)>0)>0        
  Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry,LocationId,ShiftId,FactorTrans)        
  Select BatchProcessId,1,360,EntryExceptionPosting,'',AssignedTo,getdate(),batchid,ServiceId,ClientId,0,@LocationId,@ShiftId,EntryFactor        
  from #AllocationBatches        
               
  /*Transaction SelfPosting:361*/        
  --if(select isnull(EntrySelfPosting,0) from #AllocationBatches where isnull(EntrySelfPosting,0)>0)>0        
  Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry,LocationId,ShiftId,FactorTrans)        
  Select BatchProcessId,1,361,EntrySelfPosting,'',AssignedTo,getdate(),batchid,ServiceId,ClientId,0,@LocationId,@ShiftId,EntryFactor        
  from #AllocationBatches        
               
  /*Transaction PatientCreation:364*/        
  --if(select isnull(EntryPatientCreation,0) from #AllocationBatches where isnull(EntryPatientCreation,0)>0)>0        
  Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry,LocationId,ShiftId,FactorTrans)        
  Select BatchProcessId,1,364,EntryPatientCreation,'',AssignedTo,getdate(),batchid,ServiceId,ClientId,0,@LocationId,@ShiftId,EntryFactor        
  from #AllocationBatches        
               
  /*Batch moved to entry completed status*/        
  Insert into TRN_kOFF_tBatchFlow(BatchId,BatchProcessId,Comments,CreatedBy,CreatedDt,StatusId)        
  Select q.BatchId,q.BatchProcessId,'Auto manual allocation-Entry Completed',AssignedTo,getdate(),6        
  from #AllocationBatches as q        
               
  Update q Set Assigned = 0,StatusId = 6        
  From TRN_kOFF_tBatchQueue as q        
  inner join #AllocationBatches as t on  t.BatchProcessId = q.BatchProcessId        
  and t.AssignedTo=@AssignedTo         
  Where q.StatusId in (1) and q.Assigned =@AssignedTo        
               
  Update bat Set bat.PostedDt=getdate()        
  from TRN_kOFF_tBatches bat        
  inner join #AllocationBatches as t on bat.batchId=t.BatchId and bat.Status=1        
               
  /*if it is marked as direct upload then batch will move to completed status without audit*/           
  Insert into TRN_kOFF_tBatchFlow(BatchId,BatchProcessId,Comments,CreatedBy,CreatedDt,StatusId)        
  Select q.BatchId,q.BatchProcessId,'Auto manual allocation-direct upload',AssignedTo,getdate(),13        
  from #AllocationBatches as q        
  where exists(select 1 from TRN_kOFF_tDirectupload (nolock) where batchid=q.batchid and status=1)        
                
  Update q Set StatusId = 13        
  From TRN_kOFF_tBatchQueue as q        
  inner join #AllocationBatches as t on  t.BatchProcessId = q.BatchProcessId        
  where exists(select 1 from TRN_kOFF_tDirectupload (nolock) where batchid=t.batchid and status=1)        
               
  Update bat Set bat.UploadDt=getdate()        
  from TRN_kOFF_tBatches bat        
  inner join #AllocationBatches as t on  t.batchid = bat.batchid and bat.Status=1        
  where exists(select 1 from TRN_kOFF_tDirectupload (nolock) where batchid=bat.batchid and status=1)        
 End        
 /* update the staus as 0 - means moved to inactive status after entry process completed*/        
 update ma set ma.status=0        
 from TRN_kOFF_tManualAllocattionBatchesAutoSubmit ma        
 inner join #AllocationBatches abat on ma.BatchProcessId=abat.BatchProcessId        
 where ma.AssignedTo=@AssignedTo and status=1        
 /* update the staus as 0 - For moving inactive staus after batch entry completed*/        
 update ma set ma.status=0        
 from TRN_kOFF_tmanualAllocation ma        
 inner join #AllocationBatches abat on ma.BatchProcessId=abat.BatchProcessId        
 where ma.AssignedTo=@AssignedTo and status=1 and AllocationMode='E'        
         
         
Commit Transaction              
Select ''                
End Try                    
Begin Catch                    
Rollback transaction        
return Error_Message()             
End catch                    
End 

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pBulkBatchesProcessSubmitV1_Modified] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBulkBatchesProcessSubmitV1_Modified] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBulkBatchesProcessSubmitV1_Modified] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pBulkBatchesProcessSubmitV1_Modified] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBulkBatchesProcessSubmitV1_Modified] TO [DB_DMLSupport]
    AS [dbo];

