﻿


/*
CreatedDate:Apr 24,2015
*/
CREATE Proc Athena_Index_GetCountByScanDate_RTT        
AS        
select ScanDate,COUNT(batchid) as Pending from TRN_kOFF_tBatches where status=3  and ServiceId=363      
group by scandate order by ScanDate asc


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_GetCountByScanDate_RTT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_GetCountByScanDate_RTT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_GetCountByScanDate_RTT] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_GetCountByScanDate_RTT] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_GetCountByScanDate_RTT] TO [DB_DMLSupport]
    AS [dbo];

