﻿CREATE Procedure CUS_kOFFClientInsert  
(  
@ClientName varchar(50)  
,@ClientAcmName varchar(50)  
,@SessionUserId int  
)  
As  
Begin  
/*
Created By : Mohamed Safiyullah
Purpose : New client and related configuration done automatically when batch import
*/
Declare @ClientId int = 0
if (Select COUNT(*) from ADM_Client Where CustomerId = 25 and ClientName = @ClientName) = 0
	Begin
	Declare @TemplateClientId int = 584 /* Favorite client name 6762*/  
	Insert into ADM_Client(CustomerId,ClientName,ClientAcmName,CreatedBy,CreatedDt,Status)  
	Select 25,@ClientName,@ClientAcmName,@SessionUserId,GETDATE(),1  
	Select @ClientId = IDENT_CURRENT('ADM_Client')  
	  
	Insert into ADM_ClientServices(ClientId,ServiceId,DataType,CreatedBy,CreatedDt,Status)  
	Select @ClientId,ServiceId,DataType,@SessionUserId,GETDATE(),Status from ADM_ClientServices  
	Where ClientId = @TemplateClientId  
	Insert into ADM_ClientServicePrice(ClientId,ServiceId,Price,CreatedBy,CreatedDt)  
	Select @ClientId,ServiceId,Price,@SessionUserId,GETDATE() from ADM_ClientServicePrice  
	Where ClientId = @TemplateClientId  
	  
	Insert into ADM_ServiceGroup(ServiceId,ServiceGroupId,CreatedBy,CreatedDt,ClientId)  
	Select ServiceId,ServiceGroupId,CreatedBy,CreatedDt,@ClientId from ADM_ServiceGroup  
	Where ClientId = @TemplateClientId  
	
	/** Inserting Clients into User Profile **/
	Insert into ADM_AccessClient(UserId,ClientId,ServiceId,CreatedBy,CreatedDt,CustomerId)
	Select UserId,ClientId,ServiceId,CreatedBy,CreatedDt,CustomerId from
	(
	Select accUsers.UserId,@ClientId as ClientId,accUsers.ServiceId,1777 as CreatedBy,GETDATE() as CreatedDt,25 as CustomerId
	from ADM_AccessServices  as accUsers
	inner join ARC_Rec_Athena..ARC_REC_USER_INFO as ui on ui.USERID = accUsers.UserId and ui.ACTIVE = 1
	Where accUsers.CustomerId = 25 
	group by accUsers.UserId,accUsers.ServiceId
	)x
	Where not exists (Select 1 from ADM_AccessClient Where UserId = x.UserId and ClientId = x.ClientId and ServiceId = x.ServiceId)
	--Insert entry & qc factor
	Insert into ADM_Factor(CustomerId,ClientId,ServiceId,FactorName,FactorValue,FactorType,CreatedBy,CreatedDt,Status,EffectiveFrom)
	select  25 as CustomerId,@ClientId,fac.ServiceId,fac.FactorName,fac.FactorValue,fac.FactorType,1777,getdate(),1,fac.EffectiveFrom
	from ADM_Factor as fac
	where ClientId = @TemplateClientId and EffectiveTo is null and Status = 1
	and not exists (Select 1 from ADM_Factor Where CustomerId = 25 and ClientId = @ClientId and ServiceId = fac.ServiceId)
	select @ClientId,'New' as Mode
	End  
Else
	Select ClientId,'Old' as Mode from ADM_Client where CustomerId = 25 And ClientName = @ClientName
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kOFFClientInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kOFFClientInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kOFFClientInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kOFFClientInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kOFFClientInsert] TO [DB_DMLSupport]
    AS [dbo];

