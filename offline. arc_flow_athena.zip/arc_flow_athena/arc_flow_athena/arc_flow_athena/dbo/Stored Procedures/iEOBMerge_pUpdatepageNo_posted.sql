﻿      
CREATE Proc [dbo].[iEOBMerge_pUpdatepageNo_posted]                
as                    
begin
         
Update pymt set pymt.pageNo= (mrg.StartpgNo + pymt.pageNo) -1 from                   
         
Arc_Athena..SemiOcr_paymentposting  pymt                    
Inner Join arc_flow_athena..MergeBatchDetails  mrg on pymt.batchNo=mrg.ChildBatchNo                    
 and pymt.parentbatchno=mrg.parentbatchno  and mrg.status=14 

End
GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOBMerge_pUpdatepageNo_posted] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[iEOBMerge_pUpdatepageNo_posted] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOBMerge_pUpdatepageNo_posted] TO [DB_DMLSupport]
    AS [dbo];

