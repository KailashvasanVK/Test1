﻿Create Procedure TRN_kOFF_pManualAllocationHistory(@FromDate  date,@toDate date)
As
Begin
/*Declare @FromDate date = '2015-04-01'
Declare @toDate date= '2015-04-06'*/
Select q.BatchNo,q.PageTo as PageSize,asso.NT_USERNAME [AssignedTo],sup.NT_USERNAME [AssignedBy],case when mall.AllocationMode = 'E' then 'Entry' else 'QC' end as [AllocationFor],mall.CreatedDt [AllocatedOn]
from TRN_kOFF_tManualAllocation  as mall
inner join TRN_kOFF_tBatchQueue as q on q.BatchProcessId = mall.BatchProcessId
inner join ARC_Rec_Athena..ARC_REC_USER_INFO as asso on asso.USERID = mall.AssignedTo
inner join ARC_Rec_Athena..ARC_REC_USER_INFO as sup on sup.USERID = mall.CreatedBy
Where CONVERT(Date,mall.CreatedDt ) between @FromDate and @toDate
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pManualAllocationHistory] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pManualAllocationHistory] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pManualAllocationHistory] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pManualAllocationHistory] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pManualAllocationHistory] TO [DB_DMLSupport]
    AS [dbo];

