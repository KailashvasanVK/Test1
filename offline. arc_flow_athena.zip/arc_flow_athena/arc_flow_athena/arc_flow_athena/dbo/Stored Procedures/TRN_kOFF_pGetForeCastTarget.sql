﻿
CREATE procedure TRN_kOFF_pGetForeCastTarget 
(
 @Year int=2015,
 @SearchStr varchar(50) ='',
 @SearchPattern varchar(50)='%'
)
as
begin
SET nocount on;
/*
Created By mallikarjun.nam
Created Date :04-09-2015
Impact : Forecast.aspx in .flow.offline (athena application) for configuring monthly forecast target 
*/
    --declare @Year int=2014
     ----  select 12 months from JAN to DEC by default
       ;with mths(mth,monthname,MonthYear) as
		(
			select 1 as mth, DATENAME(MONTH, cast(@year*100+1 as varchar) + '01')  as monthname ,(1+@Year) as MonthYear
			union all
			select mth+1, DATENAME(MONTH, cast(@year*100+(mth+1) as varchar) + '01'),(mth+1+@Year) from mths where mth<12
		 )
		 
		 ----  get data from ADM_Forecast table and inner join with above  mths table and get target details from adm_forecast table
		 select left(monthname,3) as Month, (case when @Year >(datepart(yy,getdate()))
		  then   
		  '<input type="text"  maxlength="9" style="width: 100%;height:100%" class="ForecostTargetMonthCss" value="'+convert(varchar,isnull(target,0))+'" id="Month_'+convert(varchar,mth)+'" />' 
		  when  @Year=datepart(yy,getdate()) THEN (case when mth<datepart(mm,getdate()) then convert(varchar,isnull(Target,0))  else
		   '<input type="text"  maxlength="9" style="width: 100%;height:100%" class="ForecostTargetMonthCss" value="'+convert(varchar,isnull(Target,0))+'" id="Month_'+convert(varchar,mth)+'" />'  end)
		  
		  else convert(varchar,isnull(Target,0)) end) as Target,  U.NT_UserName as [Created By],Createddt [Created Date]
		 from mths  M left outer join ADM_forecast F ON M.mth=F.MOnth and F.Year=@Year
		  left outer join  ARC_REC_Athena..ARC_REC_USER_INFO U ON F.CreatedBy=U.USERID
	
SET nocount OFF;
end


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pGetForeCastTarget] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pGetForeCastTarget] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pGetForeCastTarget] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pGetForeCastTarget] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pGetForeCastTarget] TO [DB_DMLSupport]
    AS [dbo];

