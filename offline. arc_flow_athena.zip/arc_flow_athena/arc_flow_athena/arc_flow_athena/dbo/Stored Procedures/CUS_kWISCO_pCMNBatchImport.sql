﻿CREATE Procedure CUS_kWISCO_pCMNBatchImport
( 
@SONumber varchar(50)
,@SODetailProcCode varchar(50)
,@InsurancePrimaryPayor varchar(200)
,@CMNForm  varchar(200)
,@CMNKey varchar(50)
,@NickName varchar(100)
,@NTUserName varchar(50)
)
AS 
  Begin 
     
      Insert into  CUS_kWISCO_tCMNBatchImportTable(SONumber,SODetailProcCode,InsurancePrimaryPayor,CMNForm,CMNKey,NickName,NTUserName)
      select @SONumber,@SODetailProcCode,@InsurancePrimaryPayor,@CMNForm,@CMNKey,@NickName,@NTUserName
  end


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kWISCO_pCMNBatchImport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kWISCO_pCMNBatchImport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kWISCO_pCMNBatchImport] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kWISCO_pCMNBatchImport] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kWISCO_pCMNBatchImport] TO [DB_DMLSupport]
    AS [dbo];

