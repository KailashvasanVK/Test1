﻿CREATE Procedure TRN_kOFF_pBatchTATUpdation
As
Begin
Update TRN_kOFF_tBatches with (UPDLOCK) Set ProcessedMin = dbo.ARC_BusinessMinutesServiceBased(CreatedDt,UploadDt,25,ServiceId)
Where UploadDt is not null and ProcessedMin is null

Update trn_koff_tbatches Set HeldMinutes = held.HeldMinutes
from trn_koff_tbatches as bat
inner join
(
Select bat.batchid		    
,Sum(dbo.ARC_BusinessMinutesServiceBased(HeldDate,ReleaseDate,25,bat.ServiceId)) as HeldMinutes
from
TRN_kOFF_tBatches as bat
inner join TRN_kOFF_tHeldBatches as held on held.BatchId = bat.BatchId
Where bat.UploadDt is not null and bat.HeldMinutes is null
group by bat.BatchId
)held on held.batchId = bat.BatchId
Where bat.UploadDt is not null and bat.HeldMinutes is null
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pBatchTATUpdation] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchTATUpdation] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchTATUpdation] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pBatchTATUpdation] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchTATUpdation] TO [DB_DMLSupport]
    AS [dbo];

