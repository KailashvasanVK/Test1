﻿CREATE Procedure ADM_WIPConfigActions
(
	@WipName varchar(100),
	@ServiceId int,
	@ClientId int,
	@CreatedBy int,
	@CustomerId int,
	@Action varchar(75)
)

as
   begin  
   if(@Action ='InsertWip')
        begin
			insert into ADM_Wipsetup(WipName,ServiceId,ClientId,CreatedBy,CreatedDt,Active,CustomerId)
			select @WipName,@ServiceId,@ClientId,@CreatedBy,GETDATE(),1,@CustomerId
        end
   if(@Action='LoadClients')
       begin
		select cl.ClientId,cl.ClientAcmName as ClientName from ADM_ClientServices as cs  
		inner join ADM_Client as cl on cl.CustomerId = @CustomerId and cl.ClientId = cs.ClientId and cs.ServiceId = @ServiceId  
		where not exists (select 1 from ADM_Wipsetup where CustomerId = cl.CustomerId and ClientId = cs.ClientId and ServiceId = cs.ServiceId)  
       End
   End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_WIPConfigActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_WIPConfigActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_WIPConfigActions] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_WIPConfigActions] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_WIPConfigActions] TO [DB_DMLSupport]
    AS [dbo];

