﻿CREATE Procedure ADM_ProfileSetupAction
@Action Varchar(75),
@ServiceId  int  = 0,
@customerid  int = 0,
@userid  int = 0 ,
@SelectedValues varchar(max)= null,
@profileId  int  = 0 
As
/*,
Created by : Karthik Ic
Created on : 10 May 2013.
Impact to  : ProfileSetup.aspx

Modified by : Kathiravan.kand
*/
Begin
if @Action  = 'getServiceWiseClient'
-- Purpose : To get the service wise client details  --
Begin
	/* Original Procedure start  */
		--Select ClientName ,ClientId,AccClientId from 
		--(
		--	Select distinct ClientAcmName as ClientName ,ADMCS.ClientId,isnull(AClient.AccClientId,99999999)AccClientId /* 99999999 - means client yet not config for this user **/
		--	From ADM_ServiceGroup ADMCS /*ADM_ServiceClient change to group **/
		--	inner join ADM_Client ADMC on ADMC.ClientId = ADMCS.ClientId
		--	left join ADM_AccessClient as AClient on AClient.CustomerId = @customerid and AClient.UserId = @profileId and AClient.ServiceId = @ServiceId and AClient.ClientId = ADMCS.ClientId
		--	Where ADMCS.ServiceGroupId = @ServiceId  and ADMC.CustomerId = @customerid  and admc.status  =1
		--)x
	--order by AccClientId,ClientName

	select 'All' ClientName ,0 as  ClientId,0 as AccClientId  
End
Else if @Action = 'getUserFunctionality'
-- Purpose : To get functionality details for the user --
Begin
Select Functionality  from ADM_AccessFunctionality  where UserId = @userid
End
Else if @Action = 'getAllUserinCustomerPriority'
-- Purpose : Validate the selected customer  --
Begin
Select ARUC.CustomerID,ARUC.UserId from ARC_REC_Athena..ARC_REC_UserCustomer ARUC
inner join dbo.fnSplitString(@SelectedValues,',') fnS on fnS.items = ARUC.UserId
 End
Else if @Action = 'ValidateUserWiseClientdetails'
-- Purpose : Validate the selected customer  --
Begin
Select ClientId,UserId,ServiceId from ADM_AccessClient  AAC
inner join dbo.fnSplitString(@SelectedValues,',') fnS on fnS.items = aac.UserId
where CustomerId = @customerid
End

Else if @Action = 'getUserClentService'
-- Purpose : To get user wise service and client to select the client checkbox--
Begin
Select ClientId,ServiceId  from ADM_AccessClient  Where UserId = @userid  and CustomerId  = @customerid
End
/*************************************************************************************************************/ 
Else if @Action = 'getUserAllUserFunctionality'
-- Purpose : To get user wise functionality --
Begin
 Select Functionality,UserId from ADM_AccessFunctionality AAF
 inner join dbo.fnSplitString(@SelectedValues,',') fnS on AAF.UserId  = fnS.items
End
Else if @Action = 'getUserService'
-- Purpose : To get user wise service --
Begin
Select  DISTINCT(AAS.ServiceId) as ServiceId ,AAC.AccClientId    from  ADM_AccessServices    AAS
inner join  ADM_AccessClient AAC on AAS.ServiceId = AAC.ServiceId and AAS.UserId = AAC.UserId and aac.CustomerId = AAS.CustomerId
Where AAS.UserId = @UserId and AAS.CustomerId  = @CustomerId
 order by AAC.AccClientId
End
Else if @Action = 'getUserTarget'
-- Purpose : Get the user wise target  details --
Begin
Select distinct(isnull(procTgt.AccTargetId,0)), isnull(procTgt.AccTargetId,0) as AccTargetId  ,ser.ServiceName
,(Case when isnull(procA.Functionality,'') = '' then '' else procTgtMas.TargetName end) as ProcessTarget

,(Case when isnull(procA.Functionality,'') = '' then '' else procQcTgtMas.TargetName  
+ ' [ '+ cast(cast(isnull(procTgt.ErrorPercentage,0) as int )  as varchar) + '% ]' 
end ) as QcTarget
	/* karthik add error percentage here 01 oct 2013) */
	
,Case when isnull(qcA.Functionality,'') = '' then '' else qcTgtMas.TargetName end as QaTarget
,isnull(qcTgt.AccTargetId,0) as QCAccTargetId
from  
(  
Select UserId,ServiceId,CustomerId from adm_AccessClient
Where CustomerId = @customerid and UserId = @userid
Group by UserId,ServiceId,CustomerId
)x
inner join ADM_Service as ser on ser.ServiceId = x.ServiceId
left join ADM_AccessFunctionality as procA on procA.UserId = x.UserId  and procA.Functionality = 'P'  -- put cmd here karthik
left join ADM_AccessFunctionality as qcA on qcA.UserId = x.UserId  and  qcA.Functionality = 'A'   -- put cmd here kartihk
left join ADM_AccessTarget as procTgt on procTgt.CustomerId = x.CustomerId and procTgt.UserId = x.UserId and procTgt.ServiceId = x.ServiceId
left join ADM_ProcessTarget as procTgtMas on procTgtMas.TargetId = procTgt.ProcessTargetId
left join ADM_QcTarget as procQcTgtMas on procQcTgtMas.TargetId = procTgt.QcTargetId
left join ADM_AccessTargetQC as qcTgt on qcTgt.CustomerId = x.CustomerId and qcTgt.UserId = x.UserId and qcTgt.ServiceId = x.ServiceId
left join ADM_QaTarget as qcTgtMas on qcTgtMas.TargetId = qcTgt.QualityTargetId
Where x.Userid = @userid  and x.customerid =  @customerid and ser.Status  = 1
End
Else if  @Action ='getProcessTarget'
-- Purpose : Get process target value --
Begin
--select  TargetId,TargetName from  ADM_ProcessTarget where Status = 1
Select tgtAdm.TargetId,tgtAdm.TargetName
from ADM_ProcessTargetTran as tgtTran
Inner join ADM_ProcessTarget as tgtAdm on tgtAdm.TargetId = tgtTran.TargetId and tgtAdm.Status = 1
group by tgtAdm.TargetId,tgtAdm.TargetName
End
Else if  @Action ='getQcTarget'
-- Purpose : Get qc[Error] target value --
Begin
--select  TargetId,TargetName from  ADM_QcTarget where Status = 1
Select tgtQcAdm.TargetId ,tgtQcAdm.TargetName
from ADM_QcTargetTran as tgtQcTran
Inner join ADM_QcTarget as tgtQcAdm on tgtQcAdm.TargetId = tgtQcTran.TargetId and tgtQcAdm.Status = 1
group by tgtQcAdm.TargetId ,tgtQcAdm.TargetName
End
Else if  @Action ='getQaTarget'
-- Purpose : Get Quality target value --
Begin
--select  TargetId,TargetName from  ADM_QaTarget where Status = 1
Select tgtQaAdm.TargetId ,tgtQaAdm.TargetName
from ADM_QaTargetTran as tgtQaTran
Inner join ADM_QaTarget as tgtQaAdm on tgtQaAdm.TargetId = tgtQaTran.TargetId and tgtQaAdm.Status = 1
group by tgtQaAdm.TargetId ,tgtQaAdm.TargetName
End 
Else if  @Action ='getProcessTargetDetails'
-- Purpose : Get process target Details to show --
Begin
Select tgtAdm.TargetId,tgtAdm.TargetName,Case when tgtTran.Today = 0 then ' > ' else '' end + Convert(Varchar,tgtTran.Fromday) as [From day]
,Case when tgtTran.Today = 0 then '' else Convert(varchar,tgtTran.Today) end as [To day] ,tgtTran.TargetPercent as [Target]
from ADM_ProcessTargetTran as tgtTran
Inner join ADM_ProcessTarget as tgtAdm on tgtAdm.TargetId = tgtTran.TargetId and tgtAdm.Status = 1
Order by tgtTran.TargetId,tgtTran.PTLevelId
End
Else if  @Action ='getQcTargetDetails'        
-- Purpose : Get Qctarget Details to show --       
Begin        
Select tgtQcAdm.TargetId ,tgtQcAdm.TargetName,Case when tgtQcTran.Today = 0 then ' > ' else '' end + Convert(Varchar,tgtQcTran.Fromday) as [From day]        
,Case when tgtQcTran.Today = 0 then '' else Convert(varchar,tgtQcTran.Today) end as [To day] ,tgtQcTran.TargetPercent as [Target]        
from ADM_QcTargetTran as tgtQcTran        
Inner join ADM_QcTarget as tgtQcAdm on tgtQcAdm.TargetId = tgtQcTran.TargetId and tgtQcAdm.Status = 1        
Order by tgtQcTran.TargetId ,tgtQcTran.QCLevelId      
 End      
 Else if  @Action ='getQaTargetDetails'      
-- Purpose : Get Qatarget Details to show --      
Begin        
Select tgtQaAdm.TargetId ,tgtQaAdm.TargetName ,Case when tgtQaTran.Today = 0 then ' > ' else '' end + Convert(Varchar,tgtQaTran.Fromday) as [From day]        
,Case when tgtQaTran.Today = 0 then '' else Convert(varchar,tgtQaTran.Today) end as [To day] ,tgtQaTran.TargetPercent as [Target]        
from ADM_QaTargetTran as tgtQaTran        
Inner join ADM_QaTarget as tgtQaAdm on tgtQaAdm.TargetId = tgtQaTran.TargetId and tgtQaAdm.Status = 1        
Order by tgtQaTran.TargetId ,tgtQaTran.QALevelId      
End      
Else if  @Action ='getAllTargetvalue' 
-- Purpose : Get all use Target value  for the user based on the customer--       
Begin       
select  AAT.UserId,AAT.CustomerId,AAT.ServiceId,AAT.CreatedBy,AAT.ProcessTargetId,AAT.QcTargetId,AQC.QualityTargetId,AAT.AccTargetId,AAT.CreatedDt from ADM_AccessTarget  AAT       
left join ADM_AccessTargetQC AQc on  AAT.ServiceId = AQC.ServiceId and AAT.UserId = AqC.USerid and AAT.CustomerId =AQC.CustomerId  
inner join dbo.fnSplitString(@SelectedValues,',') fnS on fnS.items = AAT.UserId  
  
where AAT.customerid  = @customerid  
End 
Else if  @Action ='validateUserCustomer'       
-- Purpose : validate the user have the customer --       
Begin       
if exists (Select top 1 'x' from ARC_REC_Athena..ARC_REC_UserCustomer  where UserId  =  @userid ) 
Begin 
select 1 as result --       
End 
else       
Begin 
select 0 as result       
End 
End 
Else if  @Action ='validateCustomerService' 
-- Purpose : validate the customer  have the service --       
Begin       
if exists (Select top 1 'x' from ADM_CustomerServices  where CustomerId = @customerid ) 
Begin 
select 1 as result --       
End 
else       
Begin 
select 0 as result       
End 
End 
Else if  @Action ='validateServiceClient' 
-- Purpose : validate the service have the clinets--       
Begin       
if exists (Select top 1 'x'  From ADM_ClientServices ADMCS    inner join ADM_Client ADMC on ADMC.ClientId = ADMCS.ClientId       
  Where ADMCS.ServiceId = @ServiceId  and ADMC.CustomerId = @customerid  and ADMCS.status = 1 and ADMC.status = 1 )       
Begin 
Select 1 as result       
End 
else 
Begin 
Select 0 as result       
End 
End 
else If @Action = 'getUserWiseReportingPerson'        
-- Purpose : To get user name and functionality based on the login userid --       
Begin        
Select ARUI.UserId,ARUI.FirstName + ' ' + ARUI.LastName as Name,ARUI.EmpCode as EmpCode ,HRF.FunctionName  as FunctionName        
from  ARC_REC_Athena..arc_rec_user_info   ARUI 
inner join ARC_REC_Athena..arc_rec_user_info   TempARUI on TempARUI.nt_username  = ARUI.REPORTING_TO 
inner join ARC_REC_Athena..HR_Functionality  HRF on HRF.FunctionalityId   = ARUI.FUNCTIONALITY_ID and TempARUI.userid <> ARUI.userid       
Where TempARUI.userid =  @userid  and ARUI.ACTIVE = 1 and ARUI.AHS_PRL = 'Y'   and HRF.status =1 
order by ARUI.userid 
End       
else If @Action = 'getReportingWiseUsers'        
-- Purpose : To get reporting associates based on the login userid --       
Begin        
Select ARUI.UserId,ARUI.FirstName + ' ' + ARUI.LastName as Name,ARUI.EmpCode as EmpCode ,HRF.FunctionName  as FunctionName        
from  ARC_REC_Athena..arc_rec_user_info   ARUI 
inner join ARC_REC_Athena..arc_rec_user_info   TempARUI on TempARUI.nt_username  = ARUI.REPORTING_TO 
inner join ARC_REC_Athena..HR_Functionality  HRF on HRF.FunctionalityId   = ARUI.FUNCTIONALITY_ID and TempARUI.userid <> ARUI.userid       
Where TempARUI.userid =  @userid  and ARUI.ACTIVE = 1 and ARUI.AHS_PRL = 'Y'   and HRF.status =1 
order by ARUI.userid 
End       
else If @Action = 'getUserWiseCustomerDetails'        
-- Purpose : To get the customer name and customer id based on the user id for priority --  
Begin 
Select ADMC.InternalName  as CustomerName,ARUC.CustomerID as CustomerId From ARC_REC_Athena..ARC_REC_UserCustomer  ARUC  
inner  join ADM_Customer  ADMC on ADMC.CustomerId = ARUC.CustomerID       
left join ADM_AccessCutomers   AAC on AAC.UserId  = ARUC.userid and aac.CustomerId = ARUC.CustomerID  
Where ARUC.UserId = @Userid  and admc.Status =1        
order by  aac.AccCustomerId,ARUC.UCid  
End       

else If @Action = 'getCustomerWiseUserDetails'
-- Purpose : To get the all active user details for service config and Target config --        
Begin        
--Select distinct(ARUI.UserId) as Userid ,ARUI.FirstName + ' ' + ARUI.LastName as Name From  ARC_REC_Athena..arc_rec_user_info   ARUI
--inner join ARC_REC_Athena..arc_rec_user_info TempARUI on TempARUI.nt_username  = ARUI.REPORTING_TO and TempARUI.userid <> ARUI.userid
--inner join ADM_AccessCutomers  AAC on AAC.UserId = ARUI.userid
--Where TempARUI.userid =  @Userid  and ARUI.ACTIVE = 1 and ARUI.AHS_PRL = 'Y' and AAC.CustomerId = @CustomerId
--Order By ARUI.Userid
if OBJECT_ID('tempdb..#AssociateList') is not null drop table #AssociateList
		 Create Table #AssociateList(UserId int,Name varchar(100))
if (@userid = 335 )--   NT_USERNAME = manigandan.j
	 Begin
		 Insert into #AssociateList(UserId,Name) 
		 Select ui.USERID,NT_USERNAME + ' (' + ui.EMPCODE + ')' as Name 
		 from ARC_REC_Athena..ARC_REC_USER_INFO as ui 
		 Where  -- Ui.Reporting_To = (Select Nt_UserName from ARC_REC_Athena..arc_Rec_user_info where userid = @UserId)		 and 
		  exists (select 1 from ARC_REC_Athena..ARC_REC_UserCustomer where UserId = ui.USERID and CustomerID = @CustomerId) and 
		 Ui.Active = 1 and Ui.Ahs_Prl = 'Y' 	
	 End 
	 Else 
	 Begin   		 
		 Insert into #AssociateList(UserId,Name) 
		 Select ui.USERID,NT_USERNAME + ' (' + ui.EMPCODE + ')' as Name 
		 from ARC_REC_Athena..ARC_REC_USER_INFO as ui 
		 Where CLIENT_ID = 25
		 -- Ui.Reporting_To = (Select Nt_UserName from ARC_REC_Athena..arc_Rec_user_info where userid = @UserId)
		 --and exists (select 1 from ARC_REC_Athena..ARC_REC_UserCustomer where UserId = ui.USERID and CustomerID = @CustomerId)
		 and Ui.Active = 1 and Ui.Ahs_Prl = 'Y' 			 
	 
		 -- if (Select COUNT(*) from ARC_FLOW_Athena..ADM_AccessFunctionality Where UserId = @UserId and Functionality = 'B') > 0
		 --Begin
		 --Insert into #AssociateList(UserId,Name) 
		 --Select ui.USERID,NT_USERNAME + ' (' + ui.EMPCODE + ')' as Name 
		 --from ARC_REC_Athena..ARC_REC_USER_INFO as ui 
		 --Where Ui.Reporting_To in (Select REPORTING_TO from ARC_REC_Athena..arc_Rec_user_info where userid = @UserId)
		 --and exists (select 1 from ARC_REC_Athena..ARC_REC_UserCustomer where UserId = ui.USERID and CustomerID = @CustomerId)
		 --and Ui.Active = 1 and Ui.Ahs_Prl = 'Y'  		 
		 --End 
	End
	Select distinct UserId,Name from #AssociateList  group by UserId,Name
End

--else If @Action = 'getCustomerWiseUserDetailsBackupUser'
---- Purpose : To get the all active user details for service config and Target config [Backup User] -- 
--Begin        
--	--Select distinct(ARUI.UserId) as Userid ,ARUI.FirstName + ' ' + ARUI.LastName as Name
--	--From  ARC_REC_Athena..arc_rec_user_info   ARUI       
--	--inner join ADM_AccessCutomers  AAC on AAC.UserId = ARUI.userid
--	--Where  ARUI.ACTIVE = 1 and ARUI.AHS_PRL = 'Y' 
--	--and AAC.CustomerId =  @CustomerId 
--	--and REPORTING_TO in((Select NT_USERNAME from ARC_REC_Athena..ARC_REC_USER_INFO  Where USERID = @userid)
--	--		,(Select  REPORTING_TO  from ARC_REC_Athena..ARC_REC_USER_INFO  Where USERID = @userid))
--End
End







GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ProfileSetupAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileSetupAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileSetupAction] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ProfileSetupAction] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileSetupAction] TO [DB_DMLSupport]
    AS [dbo];

