﻿CREATE  Procedure [dbo].[TRN_kOFF_pBatchHeldDiscardSearch]        
       @UserId int  ,         
       @CustomerId INT=0,         
       @ClientId  INT = 0,         
       @Cmpkey varchar(20)='',        
       @ServiceId  INT = 0,               
       @BatchNO varchar(75)='',         
       @SearchStr varchar(100) = '',    
       @SearchPattern varchar(4) = '=', /** = or % **/     
       @Action int,  
       @DateMode varchar(1)='',  
       @FromDate  varchar(20)='',   
       @payerID int = 0,    
       @ToDate  varchar(20)='',
       @LocationId int=1       --added by mallikarjun.nam
      
As     
     
Begin  
Set Transaction Isolation Level Read Uncommitted; 
      
 /*DECLARE @UserId int  = 0  ,         
       @CustomerId INT=25,         
       @ClientId  INT = 0,         
       @Cmpkey varchar(20)='OFF',        
       @ServiceId  INT = 0,               
       @BatchNO varchar(75)='',         
       @SearchStr varchar(100) = '',    
       @SearchPattern varchar(4) = '=', /** = or % **/     
       @Action int=0,  
       @DateMode varchar(1)='D',  
       @FromDate  varchar(20)='2015-02-28',  
       @ToDate  varchar(20)='2015-02-28',  
       @payerID int = 0   
 */    
           
  /*
  Modified by :mallikarjun.nam	
  Modified dt:2016-01-07
  Purpose : Batch Comments added to this report
  
  */
 declare @FromScanDate as datetime,  
 @ToScanDate as datetime,  
 @FromDownloadDate as datetime,  
 @ToDownloadDate as datetime  
   
if(@DateMode = 'D')  
 begin  
  set  @FromScanDate  = convert(date,'1900-01-01')  
  set @ToScanDate  = DateAdd(day, 1, GETDATE())  
  set @FromDownloadDate =  convert(date,@FromDate)  
  set @ToDownloadDate = convert(date,@ToDate)  
 END  
 ELSE IF (@DateMode = 'S')  
 Begin  
  set  @FromScanDate  =  convert(date,@FromDate)  
  set @ToScanDate  =  convert(date,@ToDate)  
  set @FromDownloadDate =  convert(date,'1900-01-01')  
  set @ToDownloadDate = DateAdd(day, 1, GETDATE())  
 END  
 

 /* Code written by mallikarjun.nam  */       

          if OBJECT_ID('tempdb..#UserLocation') is not null drop table #UserLocation
			Create table #UserLocation( locationid int,LocationName varchar(50))
			insert into  #UserLocation(locationId,LocationName)
			exec ADM_GetUserLocation @userid,@LocationId  
 
 
  if OBJECT_ID('tempdb..#BatchHeldDiscard') is not null drop table #BatchHeldDiscard    
 Select '<input type="checkbox" class="chkbatches"  id=' + cast(bat.BatchId as varchar)+' />' chkbatches  
  ,bat.BatchId as [BatchId~Hide],bat.BatchNo  
  ,Client.ClientAcmName as Client  
  ,Ser.ServiceName,bat.PgCount as TotalPages  
  ,CONVERT(varchar,bat.ScanDate,101) as ScanDate,CONVERT(varchar,bat.CreatedDt,101) as DownloadDate  
  ,dbo.TRN_kOFF_fnGetBatchCurrentStatus(bat.BatchId) as BatchStatus,  
  (select PayerName from ADM_PayerName_View where PayerId = bat.PayerId) as PayerName
  ,(select top 1 Comments from TRN_kOFF_tBatchFlow where BatchId=bat.BatchId order by FlowId desc) as  Comments   
  into #BatchHeldDiscard  
  from TRN_kOFF_tBatches as bat   
  inner join ADM_Client as Client on Client.ClientId = bat.ClientId and Client.CustomerId = @CustomerId  
  inner join ADM_Service as Ser on Ser.ServiceId = bat.ServiceId  
  inner join #UserLocation as loc on bat.LocationId =loc.LocationId -- code added by mallikarjun
  Where bat.status = 1 and bat.UploadDt is null     
  and ISNULL(bat.PayerId, 0 ) = (case  when ISNULL(@payerID, 0 ) <> 0 then @payerID else  ISNULL(bat.PayerId, 0 ) end)     
  AND  CAST(bat.CreatedDt as date) between @FromDownloadDate  and @ToDownloadDate    
  AND CAST(bat.ScanDate as date) between  @FromScanDate and  @ToScanDate    
  and bat.ClientID = case when isnull(@ClientId,0) <> 0 then @ClientId else bat.ClientID  END  
  and bat.ServiceID = case when isnull(@ServiceID,0) <> 0 then @ServiceID else bat.ServiceID  END  
  and bat.status = case when isnull(@ServiceID,0) <> 0 then 1 else   bat.status  END  
  and Bat.BatchNo = case when isnull(@BatchNO,'') <>'' then @BatchNO else  Bat.BatchNo  END  
  and not exists (Select 1 from TRN_kOFF_tHeldBatches Where BatchId = case when @Action = 17 then bat.BatchId else 0 end and ReleaseDate is null)  
     --AND  1  = case when (@Action=17 AND not exists (Select 1 from TRN_kOff_tHeldBatches Where BatchId = bat.BatchId and ReleaseDate is null))  
     --then 1 else  0  END   
       
  Exec FilterTable    
  @DbName = 'tempdb'    
  ,@TblName = '#BatchHeldDiscard'    
  ,@SearchStr = @SearchStr    
  ,@SearchPattern = @SearchPattern    
  ,@OrderStr = ''  
  if OBJECT_ID('tempdb..#BatchHeldDiscard') is not null drop table #BatchHeldDiscard    
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pBatchHeldDiscardSearch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchHeldDiscardSearch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchHeldDiscardSearch] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pBatchHeldDiscardSearch] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchHeldDiscardSearch] TO [DB_DMLSupport]
    AS [dbo];

