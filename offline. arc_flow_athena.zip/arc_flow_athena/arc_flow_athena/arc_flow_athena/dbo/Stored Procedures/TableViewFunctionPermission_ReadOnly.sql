﻿CREATE PROCedure [dbo].[TableViewFunctionPermission_ReadOnly]                              
as                              
begin                             
                         
if OBJECT_ID('tempdb..#temp') is not null                              
drop table #temp                              
select  Name into #temp from sys.tables where create_date>=GETDATE()-7 and schema_id =1                          
and name not in ('TablePermission','TableViewFunctionPermission')                              
                              
Declare @tc int,@SPName Varchar(100),@sql nvarchar(1500)                              
                              
set @tc=(select COUNT(*) from #temp)                              
                              
While @tc!=0                              
Begin                              
                              
select @SPName=name from  #temp                              
                             
Set @sql='GRANT SELECT ON [dbo].['+@SPName +'] TO [DB_Readonlysupport]'                              
Exec sp_executesql @SQL                              
                            
Set @sql='GRANT VIEW DEFINITION ON [dbo].['+@SPName +'] TO [DB_Readonlysupport]'                              
Exec sp_executesql @SQL               
                           
                              
                              
Delete From #temp where name =@SPName                              
                              
Set @tc =@tc-1                               
End                              
                              
drop table #temp                           
                        
                        
if OBJECT_ID('tempdb..#viewtemp') is not null                          
drop table #viewtemp                          
select  Name into #viewtemp from sys.views where create_date >=GETDATE()-7 and schema_id =1                    
                          
                          
set @tc=(select COUNT(*) from #viewtemp)                          
                          
While @tc!=0                          
Begin                          
                          
select @SPName=name from  #viewtemp                          
                          
Set @sql='GRANT SELECT ON [dbo].['+@SPName +'] TO [DB_Readonlysupport]'                          
Exec sp_executesql @SQL                          
Set @sql='GRANT VIEW DEFINITION ON [dbo].['+@SPName +'] TO [DB_Readonlysupport]'                          
Exec sp_executesql @SQL                          
                          
                          
Delete From #viewtemp where name =@SPName                          
                          
Set @tc =@tc-1                           
End                          
                          
drop table #viewtemp                        
                        
                        
if OBJECT_ID('tempdb..#functemp') is not null                          
drop table #Functemp                          
select  Name into #Functemp from sysobjects where xtype  in('fn')                 
and crdate >=GETDATE()-7                        
                          
                          
set @tc=(select COUNT(*) from #Functemp)                          
                          
While @tc!=0                          
Begin                          
                          
select @SPName=name from  #Functemp                          
                          
Set @sql='GRANT VIEW DEFINITION ON [dbo].['+@SPName +'] TO [DB_Readonlysupport]'                          
Exec sp_executesql @SQL    
  
Set @sql='GRANT EXECUTE ON [dbo].['+@SPName +'] TO [DB_Readonlysupport]'                          
Exec sp_executesql @SQL                        
                         
Delete From #Functemp where name =@SPName                          
                          
Set @tc =@tc-1                           
End                          
                          
drop table #Functemp                        
  
             
if OBJECT_ID('tempdb..#Tfunctemp') is not null                
drop table #Tfunctemp                
select  Name into #Tfunctemp from sysobjects where xtype  in('Tf')       
and crdate >=GETDATE()-7              
                
                
set @tc=(select COUNT(*) from #Tfunctemp)                
                
While @tc!=0                
Begin                
                
select @SPName=name from  #Tfunctemp                
                
Set @sql='GRANT VIEW DEFINITION ON [dbo].['+@SPName +'] TO [DB_Readonlysupport]'                
Exec sp_executesql @SQL                
Set @sql='GRANT REFERENCES ON [dbo].['+@SPName +'] TO [DB_Readonlysupport]'                
Exec sp_executesql @SQL                
                
                
Delete From #Tfunctemp where name =@SPName                
                
Set @tc =@tc-1                 
End                
                
drop table #Tfunctemp                                
                    
if OBJECT_ID('tempdb..#storedProctemp') is not null                      
drop table #storedProctemp                      
select  '['+SCHEMA_NAME(schema_id)+'].['+name+']'                    
AS SchemaName into #storedProctemp from sys.procedures where create_date>=GETDATE()-7         
and schema_id =1 and name not in ('TableViewFunctionPermission')                    
                    
                      
set @tc=(select COUNT(*) from #storedProctemp)                      
                      
While @tc!=0                      
Begin                      
                      
select @SPName=SchemaName from  #storedProctemp                      
                      
Set @sql='GRANT VIEW DEFINITION ON '+@SPName+' TO [DB_Readonlysupport]'                      
                      
Exec sp_executesql @SQL                      
                      
Delete From #storedProctemp where SchemaName =@SPName                      
                      
Set @tc =@tc-1                       
End                       
                        
                        
                           
end  
  
  
  
GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TableViewFunctionPermission_ReadOnly] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TableViewFunctionPermission_ReadOnly] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TableViewFunctionPermission_ReadOnly] TO [DB_DMLSupport]
    AS [dbo];

