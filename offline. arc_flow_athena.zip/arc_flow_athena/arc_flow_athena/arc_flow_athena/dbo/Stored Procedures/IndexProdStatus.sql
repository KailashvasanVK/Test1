﻿Create Proc IndexProdStatus(@CompDate datetime)
as
select count(id),convert(varchar(10),completeddate,101),userinfo from batchIndex_TrackBatches  
where convert(varchar(10),completeddate,101)=@CompDate --'02/24/2015'
group by convert(varchar(10),completeddate,101),userinfo 
order by userinfo,convert(varchar(10),completeddate,101)
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[IndexProdStatus] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[IndexProdStatus] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[IndexProdStatus] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[IndexProdStatus] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[IndexProdStatus] TO [DB_DMLSupport]
    AS [dbo];

