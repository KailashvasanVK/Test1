﻿
CREATE Procedure TRN_kOFF_pBatchMoveToDirectUpload
(
 @BatchId int
 ,@BatchProcessId int
 ,@CreatedBy int
 ,@Comments varchar(max)
 ,@RandomNo int
 ,@QcDate date
)
as
Begin

  /*        
		Cretaed By     : mallikarjun.nam
		Created Date   : 2016-07-26   
		Purpose        : For Random Qc alogothim
		Ticket/SCR ID  : 155811
		TL Verified By : Safi
		 
		Implemented by : Ganesh.Tanneru ,udhayaganesh.p 
  Implemented On : 26-07-2016 ,28-07 -2016
  Reviewd by     : Ganesh.Tanneru  ,udhayaganesh.p 
  Implemented On : 26-07-2016 ,28-07 -2016
	 
	*/
  Insert into TRN_kOFF_tDirectUpload(BatchId,CreatedBy,CreatedDt,Status,Comments)
  select BatchId,1777,getdate(),1,@Comments from  TRN_kOFF_tBatches bat 
  where BatchId=@BatchId and not exists (select 1 from TRN_kOFF_tDirectUpload where batchid=bat.BatchId and status=1)
  Insert into TRN_kOFF_tRandomAuditBatches(BatchId,BatchProcessId,FTE_ID,TransCount,QCDate,CreatedDt,BatchRandomNo)values(@BatchId,@BatchProcessId,@CreatedBy,0,@QcDate,getdate(),@RandomNo)
End



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pBatchMoveToDirectUpload] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchMoveToDirectUpload] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchMoveToDirectUpload] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pBatchMoveToDirectUpload] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchMoveToDirectUpload] TO [DB_DMLSupport]
    AS [dbo];

