﻿
CREATE Proc  AthenaIndex_GetUserInfo_SelectedBatch_RTT    
@BatchNo varchar(50)=NULL    
as    
  
/*    
Purpose : Get User Information for selected batch For RT
Created Date : May 19,2015   
*/    

Begin    
SELECT * from batchIndex_TrackBatches_RT(nolock) where batchnum=@BatchNo     
End  




GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AthenaIndex_GetUserInfo_SelectedBatch_RTT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AthenaIndex_GetUserInfo_SelectedBatch_RTT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AthenaIndex_GetUserInfo_SelectedBatch_RTT] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AthenaIndex_GetUserInfo_SelectedBatch_RTT] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AthenaIndex_GetUserInfo_SelectedBatch_RTT] TO [DB_DMLSupport]
    AS [dbo];

