﻿CREATE Procedure CUS_TWISCO_ERNBatchImportCreateTable  
AS  
/*  
 To create a temp table for  WISCO ERN Batch Import.    
*/  
Begin  
if OBJECT_ID('Temp_CUS_TWISCO_ERNBatchImport') is not null Drop table Temp_CUS_TWISCO_ERNBatchImport  
Create table  Temp_CUS_TWISCO_ERNBatchImport (ScanDate date,BatchNo varchar(50),ClientId int,ClientName varchar(75),ServiceId int,ServiceName varchar(75),Status varchar(50))  
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_TWISCO_ERNBatchImportCreateTable] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_TWISCO_ERNBatchImportCreateTable] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_TWISCO_ERNBatchImportCreateTable] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_TWISCO_ERNBatchImportCreateTable] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_TWISCO_ERNBatchImportCreateTable] TO [DB_DMLSupport]
    AS [dbo];

