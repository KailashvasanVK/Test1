﻿CREATE Procedure ADM_LoadFTEByCustomer
@CustomerId int
As
BEGIN
/*
Created by :Kathiravan.kand
Created Dt0 : 12-Feb-2014
Purpose : to load FTE associated and QA associates by the customer
*/
	select ui.USERID,ui.NT_USERNAME+' '+'('+ui.EMPCODE+')' as NAME from ADM_AccessCutomers acccust
	inner join ARC_REC_Athena..ARC_REC_USER_INFO ui on ui.USERID = acccust.UserId
	where CustomerId=@CustomerId
	union
	select ui.USERID,ui.NT_USERNAME+' '+'('+ui.EMPCODE+')' as NAME from ADM_AccessCutomersLog acccust
	inner join ARC_REC_Athena..ARC_REC_USER_INFO ui on ui.USERID = acccust.UserId
	where CustomerId=@CustomerId
END


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_LoadFTEByCustomer] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_LoadFTEByCustomer] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_LoadFTEByCustomer] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_LoadFTEByCustomer] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_LoadFTEByCustomer] TO [DB_DMLSupport]
    AS [dbo];

