﻿CREATE Procedure CUS_kOFF_pBatchStatus
(@From datetime,@To datetime)
As
Begin
-- Exec CUS_kOFF_pBatchStatus '2014-07-21 11:30:00', '2014-07-25 11:30:00'
--Declare @From datetime = '2014-07-21 11:30:00'
--Declare @To datetime = '2014-07-25 11:30:00'
if OBJECT_ID('tempdb..#tmpBatchStatus') is not null drop table #tmpBatchStatus
Select bat.BatchId,bat.BatchNo,ser.ServiceName as [Service],'Held' as Status 
into #tmpBatchStatus
from TRN_kOFF_tHeldBatches as held
inner join trn_koff_tbatches as bat on bat.BatchId = held.BatchId and bat.status = 1
inner join ADM_Service as Ser on Ser.ServiceId = bat.ServiceId
Where (ReleaseDate is null or ReleaseDate < @From )
Group by bat.BatchId,bat.BatchNo,ser.ServiceName
Union all
Select bat.BatchId,bat.BatchNo,Ser.ServiceName [Service],'Pending' from trn_koff_tbatches as bat
inner join ADM_Service as Ser on Ser.ServiceId = bat.ServiceId
Where UploadDt is null and bat.status = 1
and not exists (Select 1 from TRN_kOFF_tHeldBatches Where BatchId = bat.BatchId and (ReleaseDate is null or ReleaseDate < @From))
Union all
Select bat.BatchId,bat.BatchNo,Ser.ServiceName [Service],'Completed' from trn_koff_tbatches as bat
inner join ADM_Service as Ser on Ser.ServiceId = bat.ServiceId
Where UploadDt between @From and @To and bat.status = 1


Select BatchId,BatchNo,Service,Status from #tmpBatchStatus as Batch
Select 
SUM(Case when Status = 'Completed' then 1 else 0 end) as Completed
,SUM(Case when Status = 'Held' then 1 else 0 end) as Held
,SUM(Case when Status = 'Pending' then 1 else 0 end) as Pending
from #tmpBatchStatus
if OBJECT_ID('tempdb..#tmpBatchStatus') is not null drop table #tmpBatchStatus
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kOFF_pBatchStatus] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kOFF_pBatchStatus] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kOFF_pBatchStatus] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kOFF_pBatchStatus] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kOFF_pBatchStatus] TO [DB_DMLSupport]
    AS [dbo];

