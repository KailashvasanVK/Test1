﻿CREATE Proc MovetoInpatientQ
as
update arc_flow_athena..trn_koff_tbatchQueue set serviceid = 385 where batchno in(
select batchno from arc_flow_athena..trn_koff_tbatches where status=3 and batchno like '%A11284') and serviceid <> 385

update arc_flow_athena..trn_koff_tbatches set serviceid = 385 where status=3 and batchno like '%A11284' and serviceid <> 385

update arc_flow_athena..trn_koff_tbatchQueue set serviceid = 385 where batchno in(
select batchno from arc_flow_athena..trn_koff_tbatches where status=3 and batchno like '%A11938') and serviceid <> 385

update arc_flow_athena..trn_koff_tbatches set serviceid = 385 where status=3 and batchno like '%A11938' and serviceid <> 385

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[MovetoInpatientQ] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MovetoInpatientQ] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MovetoInpatientQ] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[MovetoInpatientQ] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MovetoInpatientQ] TO [DB_DMLSupport]
    AS [dbo];

