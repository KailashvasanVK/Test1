﻿CREATE Procedure [dbo].[TRN_kOFF_pBatchPrioritySearch]           
(           
      @CustomerId INT=0,           
      @ClientID  int=0,              
      @ServiceID   int=0,           
      @BatchNO varchar(75)='',            
      @ToDate  varchar(75)='',           
      @FromDate  varchar(75)='',             
      @Cmpkey varchar(20)='',           
      @Priorityvalue  varchar(75)='',           
      @userid int = 0,        
      @DateMode varchar(5)='',        
      @SearchStr varchar(100) = '',        
      @SearchPattern varchar(4) = '=',        
      @payerID int = 0,
      @PageCount int = 0,
      @LocationId int=1       --added by mallikarjun.nam     
      /** = or % **/           
)  
With Recompile       
AS 
Set Nocount on;        
SET Transaction Isolation level Read uncommitted; 
      /*        
            Declare @CustomerId INT=25,           
            @ClientID  int=0,              
            @ServiceID   int=0,           
            @BatchNO varchar(75)='',            
            @ToDate  varchar(75)='2015-02-28',           
            @FromDate  varchar(75)='2015-02-28',             
            @Cmpkey varchar(20)='OFF',           
            @Priorityvalue  varchar(75)='',           
            @userid int = 0,        
            @DateMode varchar(5)='D',        
            @SearchStr varchar(100) = '',        
            @SearchPattern varchar(4) = '=',        
            @payerID int = 257        
      */        
              
      /*        
         Modified By : Kathiravan.kand        
         Modified Dt : 02/28/2015        
         Purpoder    : Payer name added in filer        
         
         
         
      */ 
      /*
		  Modified By : mallikarjun.nam
		  Modified Dt : 2016-01-07      
		  Purpoder    : Batch comments are add
      */       
            
BEGIN         
          declare @FromScanDate as datetime,        
                  @ToScanDate as datetime,        
                  @FromDownloadDate as datetime,        
                  @ToDownloadDate as datetime        
              
if(@DateMode = 'D')        
      begin        
            set  @FromScanDate  = convert(date,'2019-01-01')        
            set @ToScanDate  = DateAdd(day, 1, GETDATE())        
            set @FromDownloadDate =  convert(date,@FromDate)        
            set @ToDownloadDate = convert(date,@ToDate)        
      END        
      ELSE IF (@DateMode = 'S')        
      Begin        
            set  @FromScanDate  =  convert(date,@FromDate)        
            set @ToScanDate  =  convert(date,@ToDate)        
            set @FromDownloadDate =  convert(date,'2019-01-01')        
            set @ToDownloadDate = DateAdd(day, 1, GETDATE())        
      END        
              
      		/* Code written by mallikarjun.nam  */       
          if OBJECT_ID('tempdb..#UserLocation') is not null drop table #UserLocation
			Create table #UserLocation( locationid int,LocationName varchar(50))
			insert into  #UserLocation(locationId,LocationName)
			exec ADM_GetUserLocation @userid,@LocationId

			 Create index NCIDX_Locationin on #UserLocation(locationId)  
			 
			 
		Create table #Tempbatch(BatchId	int, ScanDate	date, BatchNo	varchar(50), ClientId	int, ServiceId	int, BatchType	tinyint,
			CreatedBy	int, CreatedDt	datetime, Priority	int, PgCount	int, FName	varchar(200), UploadDt	datetime, PostedDt	datetime,
			AuditedDt	datetime,status	int, WFBatchId	int, QType	int, CreatedOn	datetime, isDummy	int, BatchGroupNo	varchar(75), 
			PayerId	int, ProcessedMin	int, HeldMinutes	int, LocationId	int)
		
		/* added by Udhai */     
		if isnull(@BatchNO,'') <> ''
		begin 
			insert into #Tempbatch (BatchId, ScanDate, BatchNo, ClientId, ServiceId, BatchType, CreatedBy, CreatedDt, Priority, PgCount, FName, UploadDt, PostedDt, AuditedDt, status, WFBatchId, QType, CreatedOn, isDummy, BatchGroupNo, PayerId, ProcessedMin, HeldMinutes, LocationId)
			select BatchId, ScanDate, BatchNo, ClientId, ServiceId, BatchType, CreatedBy, CreatedDt, Priority, PgCount, FName, UploadDt,
			PostedDt, AuditedDt, status, WFBatchId, QType, CreatedOn, isDummy, BatchGroupNo, PayerId, ProcessedMin, HeldMinutes, LocationId  
			From TRN_KOFF_tBatches TB 
			where TB.BatchNo=@BatchNO 
			option (recompile)     
		end
		else
		begin 
			insert into #Tempbatch (BatchId, ScanDate, BatchNo, ClientId, ServiceId, BatchType, CreatedBy, CreatedDt, Priority, PgCount, FName, UploadDt, PostedDt, AuditedDt, status, WFBatchId, QType, CreatedOn, isDummy, BatchGroupNo, PayerId, ProcessedMin, HeldMinutes, LocationId)
			select BatchId, ScanDate, BatchNo, ClientId, ServiceId, BatchType, CreatedBy, CreatedDt, Priority, PgCount, FName, UploadDt,
			PostedDt, AuditedDt, status, WFBatchId, QType, CreatedOn, isDummy, BatchGroupNo, PayerId, ProcessedMin, HeldMinutes, LocationId  
			From TRN_KOFF_tBatches TB 
			where ISNULL(tb.PayerId, 0 ) =(case  when ISNULL(@payerID,0) <> 0 then @payerID else  ISNULL(tb.PayerId,0) end)            
			AND TB.ClientId = case when isnull(@ClientId,0) <> 0 then @ClientId else   TB.ClientId  END 
			and TB.ServiceId  = case when @ServiceID <> 0 then @ServiceID else   TB.ServiceId  END           
			AND  CAST(TB.CreatedDt as date) between @FromDownloadDate  and @ToDownloadDate              
			AND CAST(TB.ScanDate as date) between  @FromScanDate and  @ToScanDate
			option (recompile)     
		end
		
  
  
     
 
              
        if OBJECT_ID('tempdb..#BatchPrioritySearch') is not null drop table #BatchPrioritySearch          
                
        SELECT ROW_NUMBER() OVER ( order by ClientAcmName asc )  AS [RowNumber~Hide] ,           
            '<input type="checkbox"   class="chkbatches" id=' + cast(tbl.BatchId as varchar)+' />' as chkbatches,ClientAcmName,             
            ServiceName,BatchNo,Pagecount,ScanDate,DownloadDate
            ,UI.NT_USERNAME AssignedBy,UI.REPORTING_TO [Supervisor]
            ,(select SUM(TransValue) from TRN_kOFF_tBatchTransact  where BatchId = tbl.BatchId) as TransCount,        
            Priority,StatusDescription,PayerName
            ,case when held.BatchId is not null then held.HeldComment  else flow.Comments end as Comments
            into #BatchPrioritySearch  
            from(             
					SELECT '<input type="checkbox"  class="chkbatch" id=' + cast(TB.BatchId as varchar)+' />' as chk,TB.BatchId,             
					cl.ClientAcmName,ser.ServiceName,TB.BatchNo,TB.PgCount as PageCount,CONVERT(varchar,TB.ScanDate,101) as ScanDate             
					,CONVERT(varchar,TB.CreatedDt,101) as DownloadDate,'' as AssignedBy ,        
					case TB.Priority when 10 then 'High' when 9 then 'Medium' when 8 then 'Low' else 'Standard' end as Priority  
					,dbo.TRN_kOFF_fnGetBatchCurrentStatus(TB.BatchId) as StatusDescription ,        
					(Select top 1 FlowId from trn_kOFF_tbatchflow where  batchid = TB.BatchId   order by FlowId desc) as FlowId ,
					(select PayerName from ADM_PayerName_View where PayerId = TB.PayerId) as PayerName,TB.ServiceId        
				    from #Tempbatch as TB with(nolock)                                              
					INNER JOIN ADM_Client as cl on cl.ClientId=TB.ClientId and  cl.CustomerId =@CustomerId                
					INNER JOIN ADM_Service as ser on ser.ServiceId= TB.ServiceId  
					inner join #UserLocation as loc on isnull(TB.LocationId,1)=loc.LocationId    
					Where TB.status = 1  and TB.UploadDt IS NULL        
					and TB.ClientId = case when @ClientID <> 0 then @ClientID else   TB.ClientId   END        
					and TB.ServiceId  = case when @ServiceID <> 0 then @ServiceID else   TB.ServiceId  END        
					and ISNULL(TB.PayerId,0) = (case when ISNULL(@payerID, 0 ) <> 0 then @payerID else  ISNULL(TB.PayerId, 0 ) end)        
					and TB.Priority = case when @Priorityvalue <> -1 then @Priorityvalue else TB.Priority  END         
					and cast(TB.CreatedDt  as date)  between  cast(@FromDownloadDate as date)  and cast(@ToDownloadDate as date)          
					and cast(TB.ScanDate  as date)  between  cast(@FromScanDate as date)  and cast(@ToScanDate as date)          
					and tb.BatchNo = case when @BatchNO <> '' then @BatchNO else  TB.BatchNo  END  
					and TB.PgCount = CASE WHEN ISNULL(@PageCount,0)<>0 then @PageCount else TB.PgCount end 
					 and tb.ScanDate>=dateadd(day,-10,getdate())       
            )tbl        
         left join TRN_kOFF_tBatchFlow as flow on flow.FlowId = tbl.FlowId        
         left join ARC_REC_Athena..ARC_REC_USER_INFO  UI(nolock) on UI.USERID = flow.CreatedBy
         left join TRN_kOFF_tHeldBatches held(nolock) ON held.BatchId=tbl.BatchId and held.ReleaseDate is null
         where not exists (select  1 from TRN_kOFF_tBatchQueue with(nolock) where batchId = tbl.BatchId and statusId = 13)        
     Exec FilterTable          
             
      @DbName = 'tempdb'          
      ,@TblName = '#BatchPrioritySearch'          
      ,@SearchStr = @SearchStr          
      ,@SearchPattern = @SearchPattern          
      ,@OrderStr = ''        
      if OBJECT_ID('tempdb..#BatchPrioritySearch') is not null drop table #BatchPrioritySearch     
	  if OBJECT_ID('tempdb..#Tempbatch') is not null drop table #Tempbatch    
		     
END 


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pBatchPrioritySearch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchPrioritySearch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchPrioritySearch] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pBatchPrioritySearch] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchPrioritySearch] TO [DB_DMLSupport]
    AS [dbo];

