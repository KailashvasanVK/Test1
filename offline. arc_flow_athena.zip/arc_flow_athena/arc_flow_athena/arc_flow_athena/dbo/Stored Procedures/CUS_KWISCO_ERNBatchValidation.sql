﻿CREATE Procedure CUS_KWISCO_ERNBatchValidation
@ClientName  varchar(50) = 'ABC',
@BatchNo varchar(50) = 'ABC_CHG_09012013_0300'
As 
/*
	Validate the batchno,service and clinet from Excel file --karthik
		Service id  :197  -  ServiceName :ERN
*/
Begin
Declare @Result varchar(50) = 'Valid'
	if not exists (Select  ClientId from ADM_client where   ClientAcmName =  @ClientName )
	Begin 
		set @Result  =(Select 'Invalid Client' as Result)
	End
	ELSE if exists(Select  BatchNo from  TRN_kWisco_tBatches  where  BatchNo = @BatchNo and ServiceId =197 )
	Begin 
		set @Result  =(Select 'Invalid BatchNo ')
	End
	select  @Result as Result 
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_KWISCO_ERNBatchValidation] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_KWISCO_ERNBatchValidation] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_KWISCO_ERNBatchValidation] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_KWISCO_ERNBatchValidation] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_KWISCO_ERNBatchValidation] TO [DB_DMLSupport]
    AS [dbo];

