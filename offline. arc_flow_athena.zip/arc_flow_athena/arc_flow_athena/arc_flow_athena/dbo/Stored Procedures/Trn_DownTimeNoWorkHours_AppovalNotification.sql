﻿


CREATE PROCedure [dbo].[Trn_DownTimeNoWorkHours_AppovalNotification]
as
/*
Modified by :Jayanthi
Modified date :2019-07-01
Implemented by :Azzaz
Ticket id:357158 and 355149
*/
begin

Declare @tableStyle varchar(max) = '  
<style type="text/css">  

.clsred
{
background: #FF0000; 
}
.clsamber
{
background: #FFC200; 
}
.clsgreen
{
background: #32CD32; 
}

#box-table  
{  
font-family: "Lucida Sans Unicode", "Lucida Grande", Sans-Serif;  
font-size: 12px;  
text-align: left;  
border-collapse: collapse;  
border-top: 7px solid #9baff1;  
border-bottom: 7px solid #9baff1;  
}  
#box-table th  
{  
font-size: 13px;  
font-weight: bold;  
background: #b9c9fe;  
border-right: 2px solid #9baff1;  
border-left: 2px solid #9baff1;  
border-bottom: 2px solid #9baff1;  
color: #039;  
padding-left:5px;  
padding-right:5px;  
}  
#box-table td  
{  
border-right: 1px solid #aabcfe;  
border-left: 1px solid #aabcfe;  
border-bottom: 1px solid #aabcfe;  
color: #669;  
padding-left:5px;  
padding-bottom:3px;  
padding-top:3px;  
padding-right:5px;  
}  
#box-table td.detailrow-1  
{  
padding-left:15px;  
}  
#box-table tr.subtotal  
{  
font-weight:bold;  
}  
#box-table tr.grandtotal  
{  
font-size: 13px;  
font-weight: bold;  
background: #b9c9fe;  
border-right: 2px solid #9baff1;  
border-left: 2px solid #9baff1;  
border-bottom: 2px solid #9baff1;  
color: #039;  
}  
  
/*  
tr:nth-child(odd) { background-color:#eee; }  
tr:nth-child(even) { background-color:#fff; }   
*/  
</style>  
'  
  
Declare @ColorCodeClass varchar(100)=''
Declare @reporting_header varchar(max) = '  
<table id="box-table">  
<tr>  
<th>ExcludeTarget Date</th>  
<th>Customer</th>  
<th>Service</th>  
<th>Reason</th> 
<th>ExcludeTarget Mins</th>  
<th>Affect Production</th>  
<th>Raised By</th>  
<th>Raised On</th>
<th>Manager</th>
<th>Staus</th>
</tr>  
'  

if object_id('tempdb..#tblPendingApproval') is not null drop table #tblPendingApproval  


select convert(date, dn.fromtime) ExcludeTargetDate 
,c.InternalName as Customer,s.servicename as Service,mtreason.TypeName as Reason,
sum(datediff(Minute,dn.fromtime,dn.totime)) ExcludeTargetMins,
case when dn.IsEffectProduction=1 then 'Yes' else 'No' end As AffectProd,
ui.NT_USERNAME as [RaisedBy] ,convert(date,getdate()-1) as [RaisedOn]
 ,ui.REPORTING_TO As Manager
 ,case when StatusId=0 then 'Pending Approval' when statusid=1 then 'Approved' else 'Rejected' end Status 
, c.customerid
  into #tblPendingApproval 
  from ADM_DownTimeNoWorkHours dn
inner join   ADM_DownTimeNoWorkHourstran dnt on dn.rowid=dnt.dnrowid
inner join adm_service s on s.serviceid=dnt.servicegroupid
join ADM_Customer c on c.CustomerId=dn.CustomerId
join ADM_MasterTypes mt on dn.TypeId=mt.TypeId
join ADM_MasterTypes mtreason on mtreason.TypeId=dn.ReasonId
join ARC_REC_ATHENA..arc_rec_user_info  ui on ui.USERID=dn.Createdby
join ARC_REC_ATHENA..arc_rec_user_info  sup on sup.NT_USERNAME=ui.REPORTING_TO
where sup.ACTIVE=1 and ui.ACTIVE=1
and dn.Active=1 and CONVERT(date, dn.CreatedDt)=convert(date,getdate())
group by c.customerid, c.InternalName,convert(date, dn.fromtime),mtreason.TypeName,dn.IsEffectProduction,
ui.NT_USERNAME, ui.REPORTING_TO, StatusId,s.servicename
order by convert(date, dn.fromtime) asc

declare @Athenareporting_mail varchar(max)='',@Athenareporting_html varchar(max)=''
,@NonAthenareporting_mail varchar(max)='',@NonAthenareporting_html varchar(max)=''
,@to varchar(max)='',@cc varchar(max)=''

set @Athenareporting_mail=''
SELECT @Athenareporting_mail = COALESCE(@Athenareporting_mail,'') + '<tr><td>'+
CONVERT(VARCHAR(200), CONVERT(date,ExcludeTargetDate,101)) + '</td><td>'    +
CONVERT(VARCHAR(200), Customer) + '</td><td>'    +
CONVERT(VARCHAR(200), Service) + '</td><td>'    +
CONVERT(VARCHAR(200), Reason) + '</td><td>'    +
CONVERT(VARCHAR(200), ExcludeTargetMins) + '</td><td>'    +
CONVERT(VARCHAR(200),AffectProd) + '</td><td>'    +
CONVERT(VARCHAR(200),RaisedBy) + '</td><td>'   +
CONVERT(VARCHAR(200),CONVERT(date,RaisedOn,101)) + '</td><td>'   +
CONVERT(VARCHAR(200),Manager) + '</td><td>'   +
CONVERT(VARCHAR(200),Status) + '</td></tr>'   
from  #tblPendingApproval c 
where c.customerid in(25) 


set @Athenareporting_html = @tableStyle + '  
<p>  
Hi All,
 </br></br> 
Athena-Downtime/NoWork Hours request details raised today .</br></br>

<a href=''https://arcflow.accesshealthcare.co/arc_flow/ProductionDTReport.aspx'' title=''Click here to know more details ''>Click on this link for more details</a> 

</p>  
<div style=width:1080px;">  '+@reporting_header+@Athenareporting_mail+'</table></div>  
<br />Thanks,<br /><img src="http://www.accesshealthcare.co/appimages/arc_flow.png" alt="" width="250px" height="65px" />  <br />
** This is an auto-generated email. Please do not reply to this email.**  
' 

select @to=CTL_VALUE  From ARC_REC.dbo.ARC_REC_SOFTCONTROL where CTL_ID ='Dashboard Coverage-Athena' and CTL_TYPE='Email_to'
select @cc=CTL_VALUE  From ARC_REC.dbo.ARC_REC_SOFTCONTROL where CTL_ID ='Dashboard Coverage-Athena_CC' and CTL_TYPE ='Email_CC'


if(@Athenareporting_mail<>'' and @to<>'')
begin
Insert into ARC_REC.dbo.arc_rec_mail_tran(from_mailid,recipients,subject_text,body,ishtml,cc,active)  
Select 'mail.support@accesshealthcare.com'  
,@to
,'Athena-DownTime/NoWork Hours Request Details Notification-'+convert(varchar,convert(date,getdate())) 
,@Athenareporting_html  
,'Y'
,@cc
,1
 
end 

end



GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Trn_DownTimeNoWorkHours_AppovalNotification] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Trn_DownTimeNoWorkHours_AppovalNotification] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Trn_DownTimeNoWorkHours_AppovalNotification] TO [DB_DMLSupport]
    AS [dbo];

