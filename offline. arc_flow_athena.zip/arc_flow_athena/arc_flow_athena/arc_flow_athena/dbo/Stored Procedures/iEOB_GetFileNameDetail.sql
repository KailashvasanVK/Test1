﻿CREATE Proc iEOB_GetFileNameDetail  
@Batchno varchar(30)  
/*  
CreatedBy:Noor  
CreatedDate : Nov 15,2017  
Purpose : To Get pdf file scandate,Payername  
*/  
as  
Begin  
SELECT BatchNo,PayerName,convert(varchar,Scandate) Scandate,fname FROM trn_koff_tbatches(nolock) tb inner join adm_payername(nolock) ap   
on ap.payerid=tb.payerid where BatchNo=@Batchno   
End  

GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOB_GetFileNameDetail] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[iEOB_GetFileNameDetail] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOB_GetFileNameDetail] TO [DB_DMLSupport]
    AS [dbo];

