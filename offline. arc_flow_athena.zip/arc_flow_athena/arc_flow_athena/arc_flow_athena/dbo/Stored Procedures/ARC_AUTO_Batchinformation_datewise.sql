﻿Create Procedure ARC_AUTO_Batchinformation_datewise 
@Customerid int, @Date date

/*Declare @Customerid int=25
Declare @Date date='2019-06-03'*/

as

Begin
Declare @Cmpkey varchar(5)=''
Declare @Qry varchar(max)=''
set @Cmpkey=(Select Cmpkey from ADM_Customer where CustomerId=@Customerid)
set @Qry='
SELECT(
select Count(distinct al.BatchId)  from TRN_k'+@CmpKey+'_tManualAllocation al
inner join trn_k'+@CmpKey+'_tBatches bat on al.BatchId=bat.batchId and bat.Status=1  and al.Status=1 
inner join TRN_k'+@CmpKey+'_tBatchModified batmod on al.BatchId=batmod.BatchId --and batmod.ModifyMode=''EA''
where CONVERT(Date,al.CreatedDt)='''+convert(varchar,@Date)+''' and al.Status=1) as Allocation,

/*Release Allocation*/
(select Count(distinct alr.BatchId) from TRN_k'+@CmpKey+'_tManualAllocation alr
inner join trn_k'+@CmpKey+'_tBatches bat on alr.BatchId=bat.batchId and bat.Status=1  and alr.Status=0
inner join TRN_k'+@CmpKey+'_tBatchModified batmod on alr.BatchId=batmod.BatchId  --and batmod.ModifyMode=''ER''
where CONVERT(Date,alr.CreatedDt)='''+convert(varchar,@Date)+''') as Release,

/*Held*/
(select Count(distinct held.BatchId) as Held from TRN_k'+@CmpKey+'_tHeldBatches held
inner join trn_k'+@CmpKey+'_tBatches bat on held.BatchId=bat.batchId and bat.Status=1
where CONVERT(Date,HeldDate)='''+convert(varchar,@Date)+''' and isNull(ReleaseDate,'''')='''') as Held,

/*HeldRelease*/
(select Count(distinct held.BatchId) as Held from TRN_k'+@CmpKey+'_tHeldBatches held
inner join trn_k'+@CmpKey+'_tBatches bat on held.BatchId=bat.batchId and bat.Status=1
where CONVERT(Date,ReleaseDate)='''+convert(varchar,@Date)+''') as HeldRelease,

/*BatchEdit*/
(select Count(distinct alt.BatchId) as BatchEdit from TRN_k'+@CmpKey+'_tBatchModified alt
inner join trn_k'+@CmpKey+'_tBatches bat on alt.BatchId=bat.batchId and bat.Status=1
where CONVERT(Date,CreaetdDt)='''+convert(varchar,@Date)+''' and ModifyMode=''RP'') as BatchEdit
'
Exec (@Qry)
End

GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_AUTO_Batchinformation_datewise] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_AUTO_Batchinformation_datewise] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_AUTO_Batchinformation_datewise] TO [DB_DMLSupport]
    AS [dbo];

