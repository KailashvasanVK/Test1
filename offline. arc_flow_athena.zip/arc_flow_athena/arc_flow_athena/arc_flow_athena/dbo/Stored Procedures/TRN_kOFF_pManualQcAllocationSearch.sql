﻿
 CREATE Procedure TRN_kOFF_pManualQcAllocationSearch       
(      
    @UserId int=0,      
    @Cmpkey varchar(5)='',      
    @Action varchar(50)='',      
    @BatchIDs varchar(max)='',      
    @CreatedBy int=0,      
    @ServiceId int =0,      
    @ClientId int =0,      
    @Batchno varchar(50),      
    @PageNo int,      
    @SearchStr varchar(100) = '',        
    @SearchPattern varchar(4) = '=' /** = or % **/        
    ,@pPageSize int = 0        
    ,@pPageNumber int = 1       
    ,@DateMode varchar(1)=''      
    ,@payerID int = 0      
    ,@FromDate  varchar(20)=''        
    ,@ToDate  varchar(20)='',  
    @LocationId int=1      --added by mallikarjun.nam    
)      
As     
Begin    
SET Transaction Isolation level Read uncommitted;      
/*      
CreatedBy : kathirvana.kand      
CreatedDt : 09/30/2014      
Purpose   : Toload the entry complted batches for the manuall allocation       
*/      
  --SET TRANSACTION ISOLATION LEVEL READ COMMITTED  
declare @FromScanDate as datetime,      
@ToScanDate as datetime,      
@FromDownloadDate as datetime,      
@ToDownloadDate as datetime      
    
if(@DateMode = 'D')      
begin      
    set  @FromScanDate  = convert(date,'1900-01-01')      
    set @ToScanDate  = DateAdd(day, 1, GETDATE())      
    set @FromDownloadDate = @FromDate      
    set @ToDownloadDate =@ToDate      
END      
ELSE IF (@DateMode = 'S')      
Begin      
    set  @FromScanDate  = @FromDate      
    set @ToScanDate  = @ToDate      
    set @FromDownloadDate =  convert(date,'1900-01-01')      
    set @ToDownloadDate = DateAdd(day, 1, GETDATE())      
END         
    
  /* Code written by mallikarjun.nam  */         

if OBJECT_ID('tempdb..#UserLocation') is not null drop table #UserLocation  
Create table #UserLocation( locationid int,LocationName varchar(50))  
insert into  #UserLocation(locationId,LocationName)  
exec ADM_GetUserLocation @userid,@LocationId  
    
          if OBJECT_ID('tempdb..#PendingPostedBatches') is not null drop table #PendingPostedBatches               
    create Table #PendingPostedBatches(chkpendingbatches varchar(max),BatchNo varchar(50),Service varchar(50),Client varchar(50),[Scan Date] varchar(50),[Download date] varchar(20)      
    ,Pages int,PageFrom int,PageTo int ,Status varchar(75),FTE varchar(50),PayerName varchar(75),TransCount int,RowId int identity)      
          
   if OBJECT_ID('tempdb..#PendingPostedBatchesResult') is not null drop table #PendingPostedBatchesResult      
  create Table #PendingPostedBatchesResult(chkpendingbatches varchar(max),BatchNo varchar(50),Service varchar(50),Client varchar(50),[Scan Date] varchar(50),[Download date] varchar(20)      
    ,Pages int,PageFrom int,PageTo int ,Status varchar(75),FTE varchar(50),PayerName varchar(75),TransCount int,[RowId~Hide] int)      
          
   insert into #PendingPostedBatches(chkpendingbatches,BatchNo,Service,Client,[Scan Date],[Download date],Pages,PageFrom,PageTo ,Status,FTE,PayerName,TransCount)      
    
    select  '<input type="checkbox"  class="chkpendingbatches" id=' + cast(q.BatchProcessId as varchar)+' />' as chkpendingbatches      
    , q.BatchNo as BatchNo,ser.ServiceName as Service,cli.ClientAcmName as Client,      
    convert(varchar,bat.ScanDate,101) as [Scan Date],convert(varchar,bat.CreatedDt,101) AS [Download date],bat.PgCount as Pages, q.PageFrom,q.PageTo,    
    dbo.TRN_kOFF_fnGetBatchCurrentStatus(bat.BatchId) as Status ,      
    (Select Top 1 NT_UserName from ARC_REC_Athena..Arc_REC_User_Info where UserId = (Select Top 1 CreatedBy From TRN_kOFF_tBatchFlow (nolock) Where BatchProcessId = q.BatchProcessId and StatusId = 6   
    Order by FlowId Desc)) as FTE       
    ,(select PayerName from ADM_PayerName_View where PayerId = bat.PayerId) as PayerName
    ,(Select sum(transValue) from trn_koff_tbatchtransact (nolock) trn where bat.BatchId=trn.BatchId) TransCount       
    from TRN_kOFF_tBatchQueue (nolock) q      
    inner join TRN_kOFF_tBatches (NOLOCK)  bat on  bat.BatchId = q.BatchId  and bat.status=1 and bat.UploadDt is null      
    inner join #UserLocation as loc on isnull(bat.LocationId,1)=loc.LocationId -- code added by mallikarjun  
    and bat.PgCount = case when ISNULL(@PageNo,0) <> 0 then @PageNo else bat.PgCount end      
    and bat.ClientId = case when ISNULL(@ClientId,0) <> 0 then @ClientId else bat.ClientId end      
    and bat.ServiceId =  case when ISNULL(@ServiceId,0) <> 0 then @ServiceId else bat.ServiceId  end      
    and bat.BatchNo  = case when ISNULL(@Batchno,'') <> ''  then  @Batchno  else bat.BatchNo end      
    and ISNULL(bat.PayerId, 0 ) = (case  when ISNULL(@payerID, 0 ) <> 0 then @payerID else  ISNULL(bat.PayerId, 0 ) end)      
    AND  DATEADD(day, DATEDIFF(day, 0, bat.CreatedDt), 0) between  @FromDownloadDate  and @ToDownloadDate        
    AND  DATEADD(day, DATEDIFF(day, 0, ScanDate), 0)  between  @FromScanDate and  @ToScanDate       
    inner join ADM_Service ser on ser.ServiceId = q.ServiceId      
    inner join ADM_Client cli on cli.ClientId = q.ClientId                  
    where q.StatusId in (6) and q.PageFrom = 1 and q.Assigned=0 and bat.UploadDt is null and bat.PostedDt is not null      
    and  not exists ( select BatchProcessId from  TRN_kOFF_tManualAllocation (nolock) where  BatchProcessId = q.BatchProcessId and status=1 and AllocationMode='Q')      
    and  not exists ( select BatchId from  TRN_kOFF_tManualAllocation (nolock) where  BatchId = q.BatchId and status=1 and AllocationMode='Q')      
    order by  bat.CreatedDt                
          
    Insert into #PendingPostedBatchesResult      
    Exec FilterTable       
    @DbName = 'tempdb'      
       ,@TblName = '#PendingPostedBatches'       
    ,@SearchStr =  @SearchStr      
    ,@SearchPattern = @SearchPattern      
    ,@OrderStr = ''      

    DECLARE @FirstId int, @FirstRow int        
    SET @FirstRow =((@pPageNumber - 1) *(@pPageSize)+1)      
    SET ROWCOUNT @FirstRow        
    SELECT   @FirstId = [RowId~Hide]         
    FROM    #PendingPostedBatchesResult      
    ORDER BY [RowId~Hide]      
    SET ROWCOUNT @pPageSize      

    SELECT *      
    FROM     #PendingPostedBatchesResult        
    WHERE    [RowId~Hide] >= @FirstId        
    ORDER BY [RowId~Hide]      
    SET ROWCOUNT 0        
    Select Count(*) RowsCount from #PendingPostedBatches      
END     
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pManualQcAllocationSearch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pManualQcAllocationSearch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pManualQcAllocationSearch] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pManualQcAllocationSearch] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pManualQcAllocationSearch] TO [DB_DMLSupport]
    AS [dbo];

