﻿
CREATE PROCEDURE SemiOcr_pAutomationIndexing_New          
(                     
@UserInfo varchar(30)                    
)                    
As      
/*                    
Created By     : Gobinath.M                                
Created Date   : 2016-06-30                 
Purpose        : Allocate the batches to ADP Indexing team for greaterthan 10 pages      
Ticket/SCR ID  :                  
TL Verified By : Ramakrishnan.G                  
                  
Implemented On : Ganesh                 
Implemented On : 2016-06-30            
Reviewed by    : Ganesh                 
Reviewed On    : 28-April-2016        
      
Modified by    : Gobinath.M      
Purpose        : Changed the Order by type       
    
Implemented By: Narayana    
ticket id:209302    
  
Ticket id : 230809  
  
*/                                 
Begin                     
BEGIN TRY                
             
        DECLARE                         
        @UserCount Int,                    
        @Target Int,                  
        @ActualTarget Int                     
          
        SET @UserCount = (Select COUNT(id) from batchIndex_TrackBatches Where userinfo = @UserInfo and cstatus = 0 and CompletedDate Is NULL)                    
        SET @ActualTarget = (SELECT [Target] FROM tBatchIndexing_Target Where UserName = @UserInfo)                  
        SET @Target = @ActualTarget - @UserCount;                   
          
        INSERT INTO batchIndex_TrackBatches (batchnum,userinfo,cstatus)                                   
        SELECT  TOP (@Target) Batchno, @UserInfo,0  from trn_koff_tbatches (nolock)  a          
        INNER JOIN ARC_ATHENA.dbo.batchMaster bm (nolock) on bm.batchnum = a.BatchNo   
        /*--inner join  ARC_ATHENA.dbo.batchtotal bt (nolock) on bt.batchnum = a.BatchNo  */       
        LEFT JOIN adm_payername (nolock) pm on pm.PayerId = a.PayerId          
        Where uploaddt  is null and serviceid<>363 and a.status=3 and PgCount >=6
        and NOT EXISTS (SELECT top 1 Batchnum                    
        From batchIndex_TrackBatches Where Batchnum =  a.BatchNo)  Order by  ScanDate asc, PgCount  desc, bm.dollarAmt desc                
                       
    SELECT ErrorNumber = 0;              
          
END TRY               
BEGIN CATCH              
SELECT ERROR_NUMBER() AS ErrorNumber              
END CATCH              
End   
  
  

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[SemiOcr_pAutomationIndexing_New] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SemiOcr_pAutomationIndexing_New] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SemiOcr_pAutomationIndexing_New] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[SemiOcr_pAutomationIndexing_New] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SemiOcr_pAutomationIndexing_New] TO [DB_DMLSupport]
    AS [dbo];

