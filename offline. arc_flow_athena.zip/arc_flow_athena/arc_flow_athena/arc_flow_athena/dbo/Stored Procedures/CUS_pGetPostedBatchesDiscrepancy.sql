﻿CREATE Procedure  CUS_pGetPostedBatchesDiscrepancy
(
@pScanDate date=''
,@pCmpKey varchar(5)='WISCO'
,@To varchar(200)='kathiravan.kand@accesshealthcare.co,mohamedsafiyu.a@accesshealthcare.co'
,@FailureAlertRecipients varchar(200)=''
)
as
  begin
      Declare @PostedBatchCount int
      Declare @BatchesCount int
      Declare @Sender varchar(50)=''     
      declare @CC varchar(100)=''
      declare @Rec_Subject varchar(100)=''
      declare @Mail_body varchar(max)=''
      declare @CustomerName varchar(50)=''
      Declare @CustomerId int
   --   set @CustomerName = (select InternalName from ADM_Customer   where CmpKey=@pCmpKey and  Status=1)      
      
	 if(ISNULL(@pCmpKey,'') <>'')
	   Begin
			select @CustomerId=CustomerId ,@CustomerName=InternalName from ADM_Customer  where CmpKey =@pCmpKey and  Status=1	
			set @FailureAlertRecipients =(select FailureAlertRecipients from ADM_BatchsFilePath where CustomerId = @CustomerId and ActionType=0)	
	    End
	    
	set @PostedBatchCount = (select COUNT(*) from CUS_kWISCO_tExtranetPostedBatches where ScanDate=''+convert(varchar,@pScanDate)+'')
	set @BatchesCount = (select COUNT(*) from TRN_kWISCO_tBatches where ScanDate=''+convert(varchar,@pScanDate)+'' and CreatedBy=1777 and ServiceId=5)
	set @Sender='mail.support@accesshealthcare.co'
	set @Rec_Subject = 'Batch Discrepany in '+@CustomerName+''      
      
      if(@FailureAlertRecipients='')
        set @FailureAlertRecipients = @To
              
      if(@PostedBatchCount <> @BatchesCount)
      begin    
			SET @Mail_body = '
			<html><body><div style="font-family:verdana;font-size:12px">
			<b>Hi,</b><br />  
			<p> '+isnull(@CustomerName,'')+'  Batches discrepancy details</p>     
			<table BORDER="5">  
			<tr>  
			<td>Customer</td>  
			<td>' +ISNULL(@CustomerName,'') +'</td>  
			</tr>  
			<tr>  
			<td> ScanDate </td>  
			<td>'+ convert(varchar,@pScanDate)+ '</td>  
			</tr>  
			<tr>
			<td>Description</td>
			<td>Today you have discrepany about '+convert(varchar,ABS(@PostedBatchCount - @BatchesCount))+' batches</td>
			</tr>
			</table>
			<br /> <br />Thanks,<br /><img src="http://www.accesshealthcare.co/appimages/arc_support.png" alt="" width="250px" height="65px" />              
			<br>
			** This is an auto-generated email. Please do not reply to this email.**
			</div></body></html>
			'						
			Exec ARC_REC_Athena..SP_INS_ARC_REC_MAIL_TRAN  
			@FROM_MAILID =@Sender, 
			@RECIPIENTS = @FailureAlertRecipients,  
			@CC =@CC,  
			@SUBJECT_TEXT = @Rec_Subject,  
			@BODY =@Mail_body,  
			@ISHTML = 'Y'
      End
  End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_pGetPostedBatchesDiscrepancy] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_pGetPostedBatchesDiscrepancy] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_pGetPostedBatchesDiscrepancy] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_pGetPostedBatchesDiscrepancy] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_pGetPostedBatchesDiscrepancy] TO [DB_DMLSupport]
    AS [dbo];

