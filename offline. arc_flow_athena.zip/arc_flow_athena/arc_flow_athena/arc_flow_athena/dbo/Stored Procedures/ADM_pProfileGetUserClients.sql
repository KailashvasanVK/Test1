﻿
CREATE Procedure ADM_pProfileGetUserClients
(@UserId int,
@CustomerId INT = 25,
@ServiceId INT = 25
)
AS
Begin
			
			declare @UserSelectedCount int ,@TotalServiceCount  int,@UnselctedServiceCount int
			
			SELECT @UserSelectedCount = count(AccClientId)
			FROM ADM_AccessClient aac WHERE  aac.ServiceId=@ServiceId and aac.UserId = @UserId and aac.CustomerId=@CustomerId 
			
			select @TotalServiceCount =count(distinct gp.ClientId) from ADM_ServiceGroup gp
			inner join ADM_Client cli on cli.ClientId = gp.ClientId and cli.Status =1 and CustomerId =@CustomerId
			where gp.ServiceGroupId = @ServiceId
			
			
			select @UnselctedServiceCount = (@TotalServiceCount - @UserSelectedCount)
			
			
			
			
			
			
			IF(@TotalServiceCount = @UserSelectedCount or @UserSelectedCount = 0)
			BEGIN
				select '' as ClientAcmName,'' as ClientId,'' as GroupId
			END
			ELSE
			BEGIN
					select distinct ISNULL(cli.ClientAcmName,'') as ClientAcmName,ISNULL(gp.ClientId,'') as ClientId,--aac.AccClientId ,
						ISNULL(aac.GroupId,1) as GroupId
						from ADM_ServiceGroup gp
						inner join ADM_Client cli on cli.ClientId = gp.ClientId and cli.Status =1 and CustomerId =@CustomerId
						inner Join ADM_AccessClient aac on aac.ServiceId=@ServiceId and aac.UserId = CAST(@UserId as int) and aac.CustomerId=@CustomerId and aac.ClientId =gp.ClientId
						where gp.ServiceGroupId = @ServiceId
						
			END
			
END



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pProfileGetUserClients] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pProfileGetUserClients] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pProfileGetUserClients] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pProfileGetUserClients] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pProfileGetUserClients] TO [DB_DMLSupport]
    AS [dbo];

