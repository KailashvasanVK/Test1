﻿CREATE Procedure ADM_AccessTargetInsert
@ProcessTargetId varchar(5),
@QcTargetId varchar(5),
@AccTargetId  int,
@QcPercentage int,
@CreatedBy int
As
/*
Created by : Karthik Ic
Created on : 24 May 2013.
Impact to  : ProfileSetup.aspx
Purpose    : To update the service wise user target
*/
Begin
Update ADM_AccessTarget set ProcessTargetId = @ProcessTargetId, QcTargetId = @QcTargetId,
 CreatedBy =@CreatedBy, 
 PTLevelId = case when Isnull(PTLevelId,0) = 0 then (select MIN(PTLevelId) from ADM_ProcessTargetTran where TargetId = @ProcessTargetId ) else PTLevelId end,
 QCLevelId = case when Isnull(QCLevelId,0) = 0 then (select MIN(QCLevelId) from ADM_QcTargetTran where TargetId = @QcTargetId ) else QCLevelId end, 
 ErrorPercentage=@QcPercentage,
 EffectiveFrom = case when Effectivefrom IS null then GETDATE() else EffectiveFrom end,
 CreatedDt = GETDATE()
Where AccTargetId =  @AccTargetId
End



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_AccessTargetInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessTargetInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessTargetInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_AccessTargetInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessTargetInsert] TO [DB_DMLSupport]
    AS [dbo];

