﻿
CREATE Proc  BatchIndexing_Update_ControlFieldsByInsurance
/*
Purpose : To Update Fields to Display
CreatedDate: Aug 12,2015
*/
@ID int,@TAXID varchar(9)=NULL ,@NPIID varchar(10)=NULL,@PAYEENUMBER varchar(30)=NULL,@Comments varchar(500)='',@ModifiedBy varchar(50)
AS
Begin
UPDATE BatchIndexingFieldsControlRights SET TAXID=@TAXID,NPIID=@NPIID,PAYEENUMBER=@PAYEENUMBER,Comments=@Comments,ModifiedBy=@ModifiedBy,ModifiedDate=getdate() FROM  BatchIndexingFieldsControlRights WHERE ID=@ID
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[BatchIndexing_Update_ControlFieldsByInsurance] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[BatchIndexing_Update_ControlFieldsByInsurance] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[BatchIndexing_Update_ControlFieldsByInsurance] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[BatchIndexing_Update_ControlFieldsByInsurance] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[BatchIndexing_Update_ControlFieldsByInsurance] TO [DB_DMLSupport]
    AS [dbo];

