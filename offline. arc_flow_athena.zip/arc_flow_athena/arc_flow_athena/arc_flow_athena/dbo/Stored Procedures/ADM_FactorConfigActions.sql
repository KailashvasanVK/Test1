﻿--ADM_FactorConfigActions 35,35,6,'test',200,'05/20/2013','UpdateFactor',10,15      
CREATE Procedure ADM_FactorConfigActions         
(        
@Action varchar(100)='',       
@CustomerId INT=0,        
@ClientId INT=0,        
@ServiceId INt=0,        
@FactorName varchar(100)='',        
@FactorValue Decimal(9,2)=0,        
@EffectiveFrom varchar(50)='',      
@CreatedBy INT=0,        
@FactorId int=0      
--@FID INT OUTPUT           
      
)        
AS        
BEGIN        
IF(@Action ='InsertFactor')            
 BEGIN        
  INSERT INTO ADM_Factor(CustomerId,ClientId,ServiceId,FactorName,FactorValue,EffectiveFrom,CreatedBy)        
  Select @CustomerId,@ClientId,@ServiceId,@FactorName,@FactorValue,convert(varchar,@EffectiveFrom,101),@CreatedBy      
-- SELECT @FID = IDENT_CURRENT('ADM_Factor')       
 END        
ELSE IF(@Action ='SelectFactorEntryDetails')        
 BEGIN        
 select ser.ServiceId,c.ClientId,f.FactorId as FactorId,ser.ServiceName,c.ClientAcmName as ClientName,f.FactorName,      
  CONVERT(varchar,f.EffectiveFrom,101) as EffectiveFrom,CONVERT(varchar,f.EffectiveTo,101) as EffectiveTo,      
  f.FactorValue,case when f.Status=0 then 'Inactive' when f.Status=1 then 'Active' end as Status from ADM_Factor f        
  inner join ADM_Client c on c.ClientId=f.ClientId        
  inner join ADM_Service ser on ser.ServiceId=f.ServiceId  where  f.FactorType=1 and f.CustomerId=@CustomerId   
 END     
 ELSE IF(@Action ='SelectFactorQcDetails')        
 BEGIN        
 select ser.ServiceId,c.ClientId,f.FactorId as FactorId,ser.ServiceName,c.ClientAcmName as ClientName,f.FactorName,      
  CONVERT(varchar,f.EffectiveFrom,101) as EffectiveFrom,CONVERT(varchar,f.EffectiveTo,101) as EffectiveTo,      
  f.FactorValue,case when f.Status=0 then 'Inactive' when f.Status=1 then 'Active' end as Status from ADM_Factor f        
  inner join ADM_Client c on c.ClientId=f.ClientId        
  inner join ADM_Service ser on ser.ServiceId=f.ServiceId  where  f.FactorType=2 and f.CustomerId=@CustomerId     
 END       
ELSE IF(@Action='UpdateFactorEntry')        
 BEGIN    
    if(select EffectiveFrom from ADM_Factor where FactorId=@FactorId) = @EffectiveFrom
    begin
        insert into ADM_FactorLog(FactorId,CustomerId,ClientId,ServiceId,FactorName,FactorValue,EffectiveFrom,EffectiveTo,Status,CreatedBy,CreatedDt,FactorType)
        select FactorId,CustomerId,ClientId,ServiceId,FactorName,FactorValue,EffectiveFrom,EffectiveTo,Status,@CreatedBy,GETDATE(),FactorType from ADM_Factor where FactorId=@FactorId
        Update ADM_Factor  set FactorValue=@FactorValue,FactorName=@FactorName where FactorId=@FactorId 
    end
    else
    begin   
		Update ADM_Factor set Status=0,EffectiveTo=DATEADD(DAY,-1,CONVERT(varchar,@EffectiveFrom,101))  where FactorId=@FactorId  and FactorType=1          
		INSERT INTO ADM_Factor(CustomerId,ClientId,ServiceId,FactorName,FactorValue,EffectiveFrom,CreatedBy,FactorType)        
		VALUES(@CustomerId,@ClientId,@ServiceId,@FactorName,@FactorValue,convert(varchar,@EffectiveFrom,101),@CreatedBy,1)            
   end
         
 END        
 ELSE IF(@Action='UpdateFactorQc')        
 BEGIN   
       if(select EffectiveFrom from ADM_Factor where FactorId=@FactorId)= @EffectiveFrom    
       begin
           insert into ADM_FactorLog(FactorId,CustomerId,ClientId,ServiceId,FactorName,FactorValue,EffectiveFrom,EffectiveTo,Status,CreatedBy,CreatedDt,FactorType)
           select FactorId,CustomerId,ClientId,ServiceId,FactorName,FactorValue,EffectiveFrom,EffectiveTo,Status,@CreatedBy,GETDATE(),FactorType from ADM_Factor where FactorId=@FactorId
           Update ADM_Factor set FactorName=@FactorName,FactorValue=@FactorValue where FactorId=@FactorId
       end
       else
	begin 
		Update ADM_Factor set Status=0,EffectiveTo=DATEADD(DAY,-1,CONVERT(varchar,@EffectiveFrom,101))  where FactorId=@FactorId    and FactorType=2           
		INSERT INTO ADM_Factor(CustomerId,ClientId,ServiceId,FactorName,FactorValue,EffectiveFrom,CreatedBy,FactorType)        
		VALUES(@CustomerId,@ClientId,@ServiceId,@FactorName,@FactorValue,convert(varchar,@EffectiveFrom,101),@CreatedBy,2)            
   end
         
 END        
END



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_FactorConfigActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_FactorConfigActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_FactorConfigActions] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_FactorConfigActions] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_FactorConfigActions] TO [DB_DMLSupport]
    AS [dbo];

