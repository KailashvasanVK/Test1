﻿

CREATE Procedure ADM_pProfileCheckPointSetupActions  
     @QcTargetId int ,
     @UserIdCollection varchar(max),   
     @CmpKey varchar(20),   
     @ServiceId int   
As   
BEGIN   
declare @CustomerId as int   
		  
	declare @CurrentQCLevelId as int   
	declare @TotalTranDays as int    
	
	select @CustomerId = CustomerId from ADM_Customer where CmpKey = @CmpKey   
    
		
		       
	

	if OBJECT_ID('tempdb..#QCTargetTran') is not null drop table #QCTargetTran          
	Create table #QCTargetTran(TargetId int,Fromday int,Today int,TargetPercent decimal(9,2),QCLevelId int,TargetType varchar(50),CurrentTargetLevel varchar(500),AssignedLeveLId int)          
	
	 
	
	if 1 < (select COUNT(items) from fnSplitString(@UserIdCollection,','))      
	begin   
	
		insert into #QCTargetTran(TargetId ,Fromday ,Today ,TargetPercent ,QCLevelId ,TargetType,CurrentTargetLevel,AssignedLeveLId )  
			select qtt.TargetId,qtt.Fromday,qtt.Today,qtt.TargetPercent,qtt.QCLevelId,'QcTarget' as TargetType  
			,'<input type="radio" name="QCTargetCurrentLeavel" id="QCTargetCurrentLeavel_'+ convert(varchar,qtt.QCLevelId) +'"  value="QC_Level_'+ convert(varchar,qtt.QCLevelId) +'"/>'  
			,0
			from ADM_QcTargetTran qtt
		where TargetId = @QcTargetId
		
	
    end  
    ELSE 
    begin
    
    	
			select @CurrentQCLevelId= QCLevelId from ADM_AccessTarget 
			where CustomerId = @CustomerId and userid = CAST(@UserIdCollection as int) and ServiceId = @ServiceId 
    
			select @TotalTranDays = dbo.FN_GetUserTransactionDays(CAST(@UserIdCollection as int)) 
    
			insert into #QCTargetTran(TargetId ,Fromday ,Today ,TargetPercent ,QCLevelId ,TargetType,CurrentTargetLevel,AssignedLeveLId )  
			select qtt.TargetId,qtt.Fromday,qtt.Today,qtt.TargetPercent,qtt.QCLevelId,'QcTarget' as TargetType  
			,case when qtt.Fromday <= @TotalTranDays then '<input type="radio" name="QCTargetCurrentLeavel" id="QCTargetCurrentLeavel_'
			+ convert(varchar,qtt.QCLevelId) +'"  value="QC_Level_'+ convert(varchar,qtt.QCLevelId) +'"' +  
			case when qtt.QCLevelId = @CurrentQCLevelId then ' checked="checked"' else '' end  +'/>'  
			else '' end  
			,isnull(acct.QCLevelId,0)  
			from ADM_QcTargetTran qtt  
			left join ADM_AccessTarget as accT on acct.CustomerId = @CustomerId and acct.ServiceId = @ServiceId and 
			acct.userid = CAST(@UserIdCollection as int)
			and accT.QCLevelId = qtt.QCLevelId          
			inner join ADM_QcTarget qt on qt.TargetId = qtt.TargetId              
			where qt.TargetId = @QcTargetId  -- and (@TotalTranDays between qtt.Fromday and qtt.Today)  
			order by qtt.QCLevelId  
			
			if @CurrentQCLevelId = 0          
			begin          
				-- Creating Radion button checked= true for minimum level          
				update #QCTargetTran set          
				CurrentTargetLevel = '<input type="radio" name="QCTargetCurrentLeavel" id="QCTargetCurrentLeavel_'+ convert(varchar,QCLevelId) +'"  checked="checked"   value="QC_Level_'+ convert(varchar,QCLevelId) +'" />',          
				AssignedLeveLId = QCLevelId          
				where QCLevelId = (select MIN(QCLevelId) from #QCTargetTran)          
			end      

		
		
	--	select @TotalTranDays as TotalTranDays          
    end
    
           
       
    select * from #QCTargetTran --order by QCLevelId desc          
  --  select @TotalTranDays as TotalTranDays        
  
		   select (select NT_USERNAME from ARC_REC_Athena..ARC_REC_USER_INFO where USERID  =CAST(items as int)) as Username ,
		   --dbo.FN_GetUserTransactionDays(CAST(items as int))   as TotalTranDays
		   
		   (select top 1  WorkDaysCount from ADM_AssociateTarget where UserId= CAST(items as int)  and ServiceId = @ServiceId  order by EntryDate desc)   as TotalTranDays
		   
		   from fnSplitString(@UserIdCollection,',')
		   
		   select * from  sys.tables where name like '%adm_assoc%'
		   
		   
		   
      
       
 END  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pProfileCheckPointSetupActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pProfileCheckPointSetupActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pProfileCheckPointSetupActions] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pProfileCheckPointSetupActions] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pProfileCheckPointSetupActions] TO [DB_DMLSupport]
    AS [dbo];

