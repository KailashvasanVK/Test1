﻿CREATE Procedure ADM_CustomerApproval
(
@CustomerId int
,@AprStatus int /* (1)approve (4) Reject **/
,@Comments varchar(1000)
,@ApprovedBy int
)
As
Begin

------- Mail Trans details for Approval 

DECLARE  @Customer varchar(50)
Declare @MsgHeader  varchar(100)
Declare @MsgContent  varchar(500)
Declare @Rec as varchar(1000)

Set @Rec = (Select ntname + '@accesshealthcare.co;' from
(
Select  ARUI.NT_USERNAME as ntname
from ADM_Customer ADMC
inner join ARC_REC_Athena..ARC_REC_USER_INFO ARUI on ARUI.USERID = ADMC.CreatedBy
where AprStatus in(2,3 ) and CustomerId =@CustomerId
union
Select  ARUI.NT_USERNAME   
from ADM_CustomerServices ADMSC
inner join ARC_REC_Athena..ARC_REC_USER_INFO ARUI on ARUI.USERID = ADMSC.CreatedBy 
Where AprStatus in(2,3 ) and CustomerId = @CustomerId
)x for xml path(''))


------- Approve the customer details and price details 
Update ADM_Customer Set AprStatus = @AprStatus,ApprovedBy = @ApprovedBy,ApprovedDt = GETDATE(),Comments = @Comments
Where CustomerId = @CustomerId and AprStatus in (2,3)
Update ADM_CustomerServices Set AprStatus = @AprStatus,ApprovedBy = @ApprovedBy,ApprovedDt = GETDATE()
Where CustomerId = @CustomerId and AprStatus in (2,3)


------- Trigger mail to customer 
Declare @FromMail varchar(100)
Select  @FromMail  = NT_USERNAME + '@accesshealthcare.co' from  ARC_REC_Athena..ARC_REC_USER_INFO Where USERID = @ApprovedBy
Declare @ToMail varchar(100)
Set @ToMail = Substring(@Rec,0,LEn(@Rec))

Select @Customer  = FullName from ADM_Customer where CustomerId = @CustomerId 
Declare @AppPath varchar(100) 
select  @AppPath  = CtlValue from ADM_SoftControl where CtlID = 'AppPath'

Select @MsgHeader  = 'Customer '+ @Customer +' addition/modification has been ' +  case when @AprStatus = 1 then 'approved' else 'rejected' end + '.' 
Set @MsgContent =  '<p>' + @MsgHeader + 'Kindly  <a href="'+@AppPath+'CustomerCreation.aspx"> Click here </a> to review. </br> ' + case when @AprStatus = 1 then '' else 'Reject comments :' + isnull(@Comments,'') end  + '</p> </br></br> <p>



        ** This is an auto-generated email. Please do not reply to this email.**    </p>'
exec ARC_REC_Athena..SP_INS_ARC_REC_MAIL_TRAN @FROM_MAILID = @FromMail,@RECIPIENTS = @ToMail,@CC = '',@SUBJECT_TEXT = @MsgHeader,@BODY = @MsgContent,@ISHTML = 'Y'
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_CustomerApproval] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_CustomerApproval] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_CustomerApproval] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_CustomerApproval] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_CustomerApproval] TO [DB_DMLSupport]
    AS [dbo];

