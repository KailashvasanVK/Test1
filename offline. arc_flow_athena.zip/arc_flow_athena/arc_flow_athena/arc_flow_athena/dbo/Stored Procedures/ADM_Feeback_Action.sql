﻿
CREATE Procedure ADM_Feeback_Action
(
  @UserId int
 ,@CustomerId int
 ,@Action varchar(50)
 ,@FeedbackId int
 ,@Status int
 --,@Result varchar(100) output           
 )
as
 Begin
 /*
 Created By: kathiravan.K
 Created Dt: 07-Feb-2014
 Purpose  : For Feebck actions
 */
 declare @RowAffected as int  
 Declare @qry varchar(max)   
 IF(@Action='LoadFeedbacks')
BEGIN
	select COUNT(*) from ADM_AccessFunctionality where UserId=@UserId AND Functionality='F'

	select fb.ClientComments,ui.UserName as CreatedBy,convert(varchar,fb.CreatedDt,101) as CreatedDt,'Pending' as Status,fb.Status as [Status~Hide],
	'<button id=btnFeedback'+CONVERT(varchar,fb.FeedbackId)+' runat="server" class="Action ui-button  ui-state-default  ui-button-icon-only" style="width:70px;height:20px;margin-left:15px;" onclick="return btnFeedback_Onclick('+CONVERT(varchar,fb.FeedbackId)
+','+CONVERT(varchar,fb.Status)+')">Proceed</button>' as Action			
	from ADM_FeedbackRequest fb
	inner join ADM_AccessCutomers ac on ac.CustomerId = fb.CustomerId 
	left join ARC_REC_Athena..ARC_REC_USER_INFO  ui on ui.USERID = fb.CreatedBy and ACTIVE=1 
	where fb.Status=0 and ac.CustomerId=@CustomerId and ac.UserId=@UserId 
	union
	select fb.ClientComments,ui.UserName as CreatedBy,convert(varchar,fb.CreatedDt,101) as CreatedDt ,'InProgress' as Status,fb.Status as [Status~Hide],
	'<button id=btnFeedback'+CONVERT(varchar,fb.FeedbackId)+' runat="server" class="Action ui-button  ui-state-default  ui-button-icon-only" style="width:70px;height:20px;margin-left:15px;" onclick="return btnFeedback_Onclick('+CONVERT(varchar,fb.FeedbackId)
+','+CONVERT(varchar,fb.Status)+')">Proceed</button>' as Action
	from ADM_FeedbackRequest fb
	inner join ADM_AccessCutomers ac on ac.CustomerId = fb.CustomerId 
	left join ARC_REC_Athena..ARC_REC_USER_INFO  ui on ui.USERID = fb.CreatedBy and ACTIVE=1 
	where fb.Status=1 and ac.CustomerId=@CustomerId and ac.UserId=@UserId  and fb.AssignedTo=@UserId order by [Status~Hide] desc
END
ELSE IF(@Action='LoadFeedbackdetailsbyId')
BEGIN
	select BatchNo,ServiceId,ClientId,PageNo,Ticket,ClinicCode,AHSIncorrectNote,IncorrectActionTaken,ActiontobeTaken,ClientComments,AHSPMSUser,
	case when CONVERT(varchar,DateofBilling) = '1900-01-01' then '' else CAST( DateofBilling as varchar) end as DateofBilling,CustomerId,Status,AssignedTo,AssignedDt,CreatedBy,CreatedDt from ADM_FeedbackRequest 
	where FeedbackId=@FeedbackId and Status=1 and CustomerId=@CustomerId 
END
ELSE IF(@Action='AssignFeedback')
begin   
   Set @qry = 'update ADM_FeedbackRequest set Status=1,AssignedTo='+convert(varchar,@UserId)+',AssignedDt=GETDATE()
			   where CustomerId='+convert(varchar,@CustomerId)+' and FeedbackId='+convert(varchar,@FeedbackId)+'and Status='+CONVERT(varchar,@Status)+''-- and AssignedTo='+CONVERT(varchar,@UserId)+''
   exec(@qry)
	   select @RowAffected = @@ROWCOUNT 
	   if(@RowAffected = 1)
		begin
		 select 'Success'        
		end
	   else
		  begin
			  select 'AlreadyAssigned'     
		  end
   end
 END



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_Feeback_Action] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_Feeback_Action] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_Feeback_Action] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_Feeback_Action] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_Feeback_Action] TO [DB_DMLSupport]
    AS [dbo];

