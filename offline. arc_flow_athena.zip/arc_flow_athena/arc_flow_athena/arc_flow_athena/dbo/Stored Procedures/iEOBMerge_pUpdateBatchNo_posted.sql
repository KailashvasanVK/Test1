﻿CREATE Proc [dbo].[iEOBMerge_pUpdateBatchNo_posted]                    
as                    

begin   

      
/*                                
                            
Cretaed By     : Leela.T                            
Created Date   : 2017-11-13                             
Purpose        : Merge the batchtes based on template                       
Ticket/SCR ID  :                            
TL Verified By :          
      
*/    
update pymt set pymt.Parentbatchno=mrg.Parentbatchno from      
--select * from          
Arc_Athena..SemiOcr_paymentposting  pymt                  
Inner Join Arc_Flow_Athena..MergeBatchDetails mrg on pymt.batchno=mrg.childbatchno and mrg.status=14 
         
     
End



GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOBMerge_pUpdateBatchNo_posted] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[iEOBMerge_pUpdateBatchNo_posted] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOBMerge_pUpdateBatchNo_posted] TO [DB_DMLSupport]
    AS [dbo];

