﻿CREATE Procedure  ADM_GetDiscrepancyBatches
(
 @CmpKey varchar(5)=''
,@ScanDate date=''  
)
AS
Begin
/*
 begin tran
 ADM_GetDiscrepancyBatches 'WISCO','2014-03-28'
 rollback tran
*/
Declare @qry varchar(max)   
Declare @batQry varchar(max) 
Declare @To varchar(75)
Declare @Sender varchar(75)
Declare @Rec_Subject varchar(75)
Declare @CustomerId int
declare @InternalName varchar(50)
declare @CC varchar(75)=''
declare @Mail_body varchar(max)=''


if(ISNULL(''+@CmpKey+'','') <>'')
	select @CustomerId=CustomerId ,@InternalName=InternalName from ADM_Customer  where CmpKey =''+@CmpKey+''
	set @Sender='mail.support@accesshealthcare.co'
	set @To =(select FailureAlertRecipients from ADM_BatchsFilePath where CustomerId = @CustomerId)
	set @Rec_Subject='Batch Discrepancy'
	
if OBJECT_ID ('tempdb..#TempBatchInfo') is not null drop table #TempBatchInfo   
	create table #TempBatchInfo(BatchNo varchar(MAX)) 
	
SET @batQry = '  
     IF EXISTS (SELECT TOP 1 BatchNo  FROM TRN_k'+@CmpKey+'_tDiscrepancyBatches  WHERE  Scandate='''+convert(varchar,@ScanDate,101)+''' and status=1 )	
	 BEGIN
		  Insert into #TempBatchInfo(BatchNo)
	      select BatchNo  from  TRN_k'+@CmpKey+'_tDiscrepancyBatches  where ScanDate ='''+CONVERT(varchar,@ScanDate,101)+''' and status=1 	     
	      
	 END'	 
	PRINT @batQry
	EXEC(@batQry) 
	SET @Mail_body = '<b>Hi,</b><br />  
						<p>  
						'+@InternalName+'  Batches discrepancy details 
						</p>     
						<table BORDER="5">  
							<tr>  
								<td>  
									Customer
								</td>  
								<td>  ' + 
									 @InternalName +'
								</td>  
							</tr>  
							<tr>  
								<td>  
								 BatchNo 
								</td>  
								<td> ' + (select BatchNo from   #TempBatchInfo for xml path('p') )+ '</td>  
							</tr>  
						</table>  <br/>'
				
	SET @qry =' IF EXISTS (SELECT TOP 1 BatchNo  FROM TRN_k'+@CmpKey+'_tDiscrepancyBatches  WHERE  Scandate='''+convert(varchar,@ScanDate,101)+''' and status=1 )	
	 BEGIN
			Exec ARC_REC_Athena..SP_INS_ARC_REC_MAIL_TRAN  
			@FROM_MAILID ='''+@Sender+''',  
			@RECIPIENTS = '''+@To+''',  
			@CC ='''+@CC+''',  
			@SUBJECT_TEXT = '''+@Rec_Subject+''',  
			@BODY = '''+@Mail_body+''',  
			@ISHTML = ''Y''  
	  END'	
	EXEC(@qry)			
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_GetDiscrepancyBatches] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetDiscrepancyBatches] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetDiscrepancyBatches] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_GetDiscrepancyBatches] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetDiscrepancyBatches] TO [DB_DMLSupport]
    AS [dbo];

