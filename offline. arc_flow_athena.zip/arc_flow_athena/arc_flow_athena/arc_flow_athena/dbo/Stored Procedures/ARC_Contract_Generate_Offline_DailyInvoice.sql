CREATE ProcEDURE [dbo].[ARC_Contract_Generate_Offline_DailyInvoice]      
(       
  @CustomerID int=25,       
     @Attdate date    
)      
AS       
BEGIN     
     
/* declare @CustomerID int=25,       
 @Attdate date='2019-02-12'    
    
*/  
Declare @qry varchar(max)    
Declare @CmpKey varchar(50)    
    
IF OBJECT_ID('tempdb..#ARC_InvoiceTransaction') IS NOT NULL Drop table #ARC_InvoiceTransaction    
Create table #ARC_InvoiceTransaction(AttDate Date,CustomerId int,ClientId int, ServiceId int,UserId int,TransCount int,LocationId int)    
      
select @CmpKey=cmpkey    from Adm_Customer (nolock)    cus where cus.customerid=@customerid    
    
if(isnull(@CmpKey,'')<>'')    
begin    
Set @qry = '    
Insert into #ARC_InvoiceTransaction(AttDate,CustomerId,ClientId,ServiceId,UserId,TransCount,LocationId)    
Select  convert(date,ts.CreatedDt)  ,'+Convert(varchar,@CustomerId)+'    
,66270 as ClientId /*Flowcl.ClientId  */  
, case     
when (Flowser.serviceid in(358,359,360,361) and BatSer.Servicename like ''Ascension%'') then 907 --W/O New Patient    
when (Flowser.serviceid in(358,359,360,361) and BatSer.Servicename Not like ''Ascension%'') then 905 --W/O New Patient    
when (Flowser.serviceid in(364) and BatSer.Servicename  like ''Ascension%'') then 908 -- New Patient    
when (Flowser.serviceid in(364) and BatSer.Servicename Not like ''Ascension%'') then 906 -- New Patient    
else Flowser.serviceid end as serviceid    
,ahsUi.Userid as UserId    
,Sum(TransValue) as TransCount     
,isnull(att.attlocationid,ahsUi.locationId)    
from TRN_k'+@CmpKey+'_tBatchTransact(nolock) as ts      
inner join TRN_k'+@CmpKey+'_tBatches  (nolock)as bat on bat.BatchId = ts.BatchId and bat.Status = 1       
inner join ADM_Service (nolock) as Flowser on Flowser.ServiceId = ts.ServiceId  and Flowser.FieldType = ''T''      
inner join ADM_Service (nolock)as BatSer on BatSer.ServiceId = ts.BatchServiceId      
/*inner join ADM_Client  (nolock) as Flowcl on Flowcl.ClientId = ts.ClientId   */  
inner join ARC_REC_Athena.dbo.ARC_REC_User_Info (nolock) as athUser on athUser.UserId = ts.CreatedBy                
inner join ARC_REC..ARC_REC_USER_INFO (nolock) as ahsUi on ahsui.NT_USERNAME = athUser.NT_UserName      
left join ARC_REC..arc_rec_attendance (nolock) as att on att.userid = ahsUi.userid and att.date=  convert(date,ts.CreatedDt)    
Where convert(date,ts.CreatedDt)= '''+Convert(varchar,@Attdate)+''' And ts.TransValue > 0     
Group by  /*Flowcl.ClientId,*/   
Flowser.ServiceId,BatSer.Servicename ,ahsUi.UserId ,isnull(att.attlocationid ,ahsUi.locationid)   
'    
exec(@qry)    
--print (@qry)    
end    
DELETE FROM ARC_Contract_Offline_DailyInvoice       
WHERE AttDate=@Attdate  and CustomerId = @CustomerID     
    
INSERT INTO ARC_Contract_Offline_DailyInvoice( AttDate,[CustomerId] ,ClientId,ServiceId,UserId,TransCount,CreatedDt,LocationId)      
SELECT @AttDate,@CustomerId,ClientId,ServiceId,Userid    
,sum(TransCount) as TransCount  ,getdate(),LocationId    
FROM #ARC_InvoiceTransaction      
GROUP BY Userid ,ClientId,ServiceId,LocationId    
    
IF OBJECT_ID('tempdb..#ARC_InvoiceTransaction') IS NOT NULL Drop table #ARC_InvoiceTransaction    
    
     
end    
