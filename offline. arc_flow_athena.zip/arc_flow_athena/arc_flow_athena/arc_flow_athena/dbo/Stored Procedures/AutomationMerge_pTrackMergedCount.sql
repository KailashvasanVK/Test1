﻿Create Proc AutomationMerge_pTrackMergedCount  
(@ScanDate varchar(10),@Serviceid int,@ParentBatchcount int,@ChildBatchcount int)  
as   
begin 

/*                                    
                                
Cretaed By     : Leela.T                                
Created Date   : 09-May-2018                                      
Purpose        : Track the Mergebatch Count                              
Ticket/SCR ID  : <>                                
TL Verified By : <Ramki>                              
                           
                             
Implemented by : Karmegan.c               
Implemented On :  10-05-2018                          
                                
Reviewd by     :                                
Implemented On :                               
                                
*/ 
insert into AutomationMerge_tTrackMergedDetails(ScanDate,Serviceid,ParentBatchcount,ChildBatchcount,Mergeddt)  
values(@scandate,@Serviceid,@ParentBatchcount,@ChildBatchcount,getdate())  
  
End


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AutomationMerge_pTrackMergedCount] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AutomationMerge_pTrackMergedCount] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AutomationMerge_pTrackMergedCount] TO [DB_DMLSupport]
    AS [dbo];

