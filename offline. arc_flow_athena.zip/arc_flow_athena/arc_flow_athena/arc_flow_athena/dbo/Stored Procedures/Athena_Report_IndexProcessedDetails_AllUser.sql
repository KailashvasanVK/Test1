﻿CREATE Proc Athena_Report_IndexProcessedDetails_AllUser @Fromdate date, @Todate date=null  
as  
begin  
   
/*            
        
Cretaed By     : Leela.T        
Created Date   : 2016-10-20           
Purpose        : Get the Indexing Details for all users in scandate wise  
Ticket/SCR ID  : <>        
TL Verified By : <Ramki>     
   
Implemented  by<>  
Implemented Date <>  
   
*/    
      
   
select ROW_NUMBER() OVER(ORDER BY Bat.id DESC)  as 'S.No',bat.Scandate,Bat.BatchNo,ServiceName  ,
ntusername as UserName,PayerName as RoutedPayer,CreatedDate as Completeddate  
from BatchIndexing_tIndexingProcessed(nolock)  bat  
inner join adm_payerName(nolock) payr on bat.PayorServiceId=payr.payerid  
inner join trn_koff_tbatches(nolock) trn on trn.batchno=bat.batchno
inner join adm_service(nolock) ser on ser.serviceid=trn.serviceid
where bat.scandate=@Fromdate 
   
End  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Report_IndexProcessedDetails_AllUser] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Report_IndexProcessedDetails_AllUser] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Report_IndexProcessedDetails_AllUser] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Report_IndexProcessedDetails_AllUser] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Report_IndexProcessedDetails_AllUser] TO [DB_DMLSupport]
    AS [dbo];

