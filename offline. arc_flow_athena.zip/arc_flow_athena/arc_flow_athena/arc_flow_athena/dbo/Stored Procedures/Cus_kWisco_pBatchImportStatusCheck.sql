﻿CREATE Procedure Cus_kWisco_pBatchImportStatusCheck 
(
@ServiceId int
)
As
 Begin
 --Cus_kWisco_pBatchImportStatusCheck 193
    IF(select COUNT(*) from TRN_kWISCO_tBatches  where ServiceId=@ServiceId and convert(date,CreatedDt) = CONVERT(date,GETDATE())and CreatedBy=1777)= 0
     begin
      select 'Processed' as ImportStatus
     End
    ELSE
      begin
       select 'Not Processed' as ImportStatus
      End
 End



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Cus_kWisco_pBatchImportStatusCheck] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Cus_kWisco_pBatchImportStatusCheck] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Cus_kWisco_pBatchImportStatusCheck] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Cus_kWisco_pBatchImportStatusCheck] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Cus_kWisco_pBatchImportStatusCheck] TO [DB_DMLSupport]
    AS [dbo];

