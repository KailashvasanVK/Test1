﻿CREATE Procedure CUS_PTEXAS_BatchImportCreateTable
AS
/*
To create a temp table for  Texas Batch Import.
*/
Begin
if OBJECT_ID('Temp_CUS_TTEXASBatchCreater') is not null Drop table Temp_CUS_TTEXASBatchCreater
Create table  Temp_CUS_TTEXASBatchCreater (ScanDate date,BatchNo varchar(50),ClientId int,ClientName varchar(75),ServiceId int,ServiceName varchar(75),Status varchar(50),PageNo int)
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_PTEXAS_BatchImportCreateTable] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_PTEXAS_BatchImportCreateTable] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_PTEXAS_BatchImportCreateTable] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_PTEXAS_BatchImportCreateTable] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_PTEXAS_BatchImportCreateTable] TO [DB_DMLSupport]
    AS [dbo];

