﻿Create Procedure ADM_SearchAthenaSupervisors
(
  @SearchSupervisor varchar(100)
)
As
Begin
            /*
               Created Dt : 2016-07-01
               Created By : mallikarjun.nam
               Purpose    : To load Supervisors
               
               Implemented By  :Azzazbadusha.a
               Implemented On  :2016-07-01
               SCR ID          :913
               
               
            */
      
            select USERID,NT_USERNAME as UserName from ADM_Supervisors   
             where  NT_USERNAME like '%'+@SearchSupervisor+'%'  and CLIENT_ID = 25 and   ACTIVE =1 
             
            order by NT_USERNAME
End

    
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_SearchAthenaSupervisors] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_SearchAthenaSupervisors] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_SearchAthenaSupervisors] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_SearchAthenaSupervisors] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_SearchAthenaSupervisors] TO [DB_DMLSupport]
    AS [dbo];

