﻿
/*Created by :LEELA.T on 7/24/2014
Purpose: get customerid and new client id */
CREATE proc ADm_Athena_NewClient_Insert(@clientname varchar(50)) 
as
begin 
Declare @cusid int
select @cusid=[CustomerId] from ADM_Customer where FullName='Athena'
end
begin

select clientid from ADM_Client where ClientName=@clientname and CustomerId=@cusid
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADm_Athena_NewClient_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADm_Athena_NewClient_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADm_Athena_NewClient_Insert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADm_Athena_NewClient_Insert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADm_Athena_NewClient_Insert] TO [DB_DMLSupport]
    AS [dbo];

