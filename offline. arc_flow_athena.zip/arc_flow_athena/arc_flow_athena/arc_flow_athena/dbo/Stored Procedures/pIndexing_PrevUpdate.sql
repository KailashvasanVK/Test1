﻿
CREATE PROCEDURE pIndexing_PrevUpdate  
(  
@batchno varchar(20),  
@NPI varchar(30),  
@TaxID varchar(30),  
@Payeeno varchar(30),  
@DollarAmt money  
)  
As  
Begin  
  UPDATE Arc_Athena..BatchMaster SET Dollaramt=@Dollaramt,NPIID=ltrim(rtrim(@NPI)),TaxID=ltrim(rtrim(@TaxID)),PAYEENUMBER=ltrim(rtrim(@Payeeno)) Where Batchnum = @BatchNo       
END  



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[pIndexing_PrevUpdate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexing_PrevUpdate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexing_PrevUpdate] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[pIndexing_PrevUpdate] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexing_PrevUpdate] TO [DB_DMLSupport]
    AS [dbo];

