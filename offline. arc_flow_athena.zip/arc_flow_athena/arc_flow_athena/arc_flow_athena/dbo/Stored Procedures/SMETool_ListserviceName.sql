﻿Create Proc SMETool_ListserviceName
as
select distinct serviceid into #serviceid from arc_flow_athena..trn_koff_tbatches (nolock) a 
inner join arc_athena..upload_hourly(nolock)  c on c.batchnum=a.batchno

select distinct servicename from adm_service a inner join #serviceid b on a.serviceid=b.serviceid

Drop Table #serviceid 

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[SMETool_ListserviceName] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SMETool_ListserviceName] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SMETool_ListserviceName] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[SMETool_ListserviceName] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SMETool_ListserviceName] TO [DB_DMLSupport]
    AS [dbo];

