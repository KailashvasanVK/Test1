﻿CREATE Procedure  CUS_pExtranetPostedBatchesInsert  
(  
 @CmpKey varchar(5)          
,@ScanDate date   
,@ClientId int=0  
,@DepositId int         
,@DepositDate date  
,@DepositAmount varchar(25)  
,@BatchNo varchar(50)  
,@CreatedBy int=0  
,@CreatedDt datetime  
)  
As  
Begin  
  if OBJECT_ID('tempdb..#batchcheck') is not null drop table #batchcheck  
  create table #batchcheck(Result int)  
  insert into #batchcheck(Result)  
  EXECUTE TRN_pExtranetBatchPostActions @BatchNo,'BatchNoCheck',@CmpKey , @ClientId
    
if (select COUNT(*) from #batchcheck where Result = 1) = 0  
 begin   
  Declare @tBatchesqry varchar(max)   
  set @tBatchesqry =  '          
  Insert into CUS_k'+@CmpKey+'_tExtranetPostedBatches(ScanDate,ClientId,DepositId,DepositDate,DepositAmount,BatchNo,CreatedBy,CreatedDt)  
  Select ''' + convert(varchar,@ScanDate,101) + '''      
  ,' + convert(varchar,@ClientId) + '            
  ,' + convert(varchar,@DepositId) + '     
  ,''' + convert(varchar,@DepositDate,101) + '''    
  ,'''+@DepositAmount+'''  
  ,'''+@BatchNo+'''     
  ,' + convert(varchar,@CreatedBy) + '  
  ,''' +convert(varchar,GETDATE()) + '''   
  '                    
  Exec(@tBatchesqry)  
 End    
    
END 


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_pExtranetPostedBatchesInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_pExtranetPostedBatchesInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_pExtranetPostedBatchesInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_pExtranetPostedBatchesInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_pExtranetPostedBatchesInsert] TO [DB_DMLSupport]
    AS [dbo];

