﻿CREATE PROC Athena_InvoiceRpt_Mail    
AS    
BEGIN    
/*                
            
Cretaed By     : Leela.T            
Created Date   : 2016-11-11               
Purpose        : Daily Invoice Detail for Automail       
Ticket/SCR ID  : <173743>            
TL Verified By : <Ramki>            
            
                        
Modified  Date : 2017-10-30        
Modified By    : Leela.T        
Purpose        : Change the invoice Report tables format Location wise insert the data 
TL Verified By : <>   
           
            
Implemented by : Udhayaganesh.p         
Implemented On :  11/11/2016         
            
Reviewd by     :   udhayaganesh.p          
Implemented On :    11/11/2016            
            
*/       
DECLARE @uploaddate VARCHAR(10) 
,@AppType VARCHAR(15)   
,@Location VARCHAR(10)    
,@NewPat INT    
,@InsPayment INT    
,@SelfPay  INT       
,@Exception INT    
,@Collection  INT    
,@InvoiceTotal INT                   
,@OverTotal  INT    
,@RowCnt INT    
,@Bodymsg VARCHAR(MAX)    
,@MailSubject VARCHAR(30)   
,@TotNewPat INT=0
,@TotInsPayment INT=0
,@TotSelfPay INT=0
,@TotException INT=0
,@TotCollection INT=0
,@TotInvoiceTotal INT=0
, @CurInvoiceData cursor                          
 
 
    
set @Bodymsg='Hi All,'                      
set @Bodymsg=@Bodymsg+' <br> <br>                     
<Table  border=1> <tr bgcolor=Purple>'                      
set @Bodymsg=@Bodymsg+'<th> <font color=White> Uploaddate  </font> </th> <th> <font color=White> AppType </font> </th>  <th> <font color=White> Location </font> </th>          
<th> <font color=White> NewPt </font> </th> <th> <font color=White> InsPayment </font> </th>          
<th> <font color=White> SelfPay </font> </th> <th> <font color=White> Exception </font> </th>          
<th> <font color=White> Collection </font> </th> <th> <font color=White> Total </font> </th></tr>'    

                                                
set  @CurInvoiceData  = cursor fast_forward for
 
Select uploaddate,AppType ,Location ,NewPat ,InsPayment ,SelfPay ,Exception ,Collection  ,InvoiceTotal                   
From  TRN_KOFF_tInvoiceReport(nolock)  where convert(varchar(10),uploaddate ,101) =  convert(varchar(10),getdate()-1  ,101)    

open  @CurInvoiceData                                                                                                                                                                                                                          
fetch next from @CurInvoiceData into                                                                     
@uploaddate,@AppType ,@Location,@NewPat, @InsPayment,@SelfPay,@Exception,@Collection,@InvoiceTotal
if (@InvoiceTotal>0)    
begin 
 while(@@fetch_status<>-1)                                                                       
Begin 

 set @TotNewPat= @TotNewPat + @NewPat
 Set @TotInsPayment=@TotInsPayment+@InsPayment
 set @TotSelfPay=@TotSelfPay+@SelfPay
 set @TotException=@TotException+@Exception
 set @TotCollection=@TotCollection+@Collection
 set @TotInvoiceTotal=@TotInvoiceTotal+@InvoiceTotal
set @Bodymsg=@Bodymsg+'<tr>  '                      
set @Bodymsg=@Bodymsg+'<td align=right> ' + @uploaddate  + '</td>' 
set @Bodymsg=@Bodymsg+'<td align=right>' + @AppType  + '</td>'                        
set @Bodymsg=@Bodymsg+'<td align=right>' + @Location + '</td>'                     
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@NewPat as varchar) + '</td>'          
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@InsPayment as varchar) + '</td>'          
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@SelfPay as varchar)+ '</td>'          
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@Exception as varchar) + '</td>'          
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@Collection as varchar)+ '</td>'          
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@InvoiceTotal as varchar)+ '</td> </tr>'




fetch next from @CurInvoiceData into                                                                     
@uploaddate,@AppType ,@Location,@NewPat, @InsPayment,@SelfPay,@Exception,@Collection,@InvoiceTotal     

 End
 
                                                                            

 
close @CurInvoiceData                                  
deallocate @CurInvoiceData


set @Bodymsg=@Bodymsg+'<tr> <b>'                      
set @Bodymsg=@Bodymsg+'<td align=right>' +''   + '</td>' 
set @Bodymsg=@Bodymsg+'<td align=right>' +  '' + '</td>'                        
set @Bodymsg=@Bodymsg+'<td align=right>  Total </td>'                     
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@TotNewPat as varchar) + '</td>'          
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@TotInsPayment as varchar) + '</td>'          
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@TotSelfPay as varchar)+ '</td>'          
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@TotException as varchar) + '</td>'          
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@TotCollection as varchar)+ '</td>'          
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@TotInvoiceTotal as varchar)+ '</td>  </b> </tr>'

set @Bodymsg=@Bodymsg +'</Table><br><br><br> Thanks <br><br><b> ** This is Auto generated Mail ** <br>'       
set @MailSubject='Invoice Details on '+ @Uploaddate 

declare @recipients varchar(4000)='DL-WTP@accesshealthcare.co;mirza.karim@accesshealthcare.co;ramakrishnan.go@accesshealthcare.co;leela.thangavel@accesshealthcare.co;dl_dba@accesshealthcare.co;azzazbadusha.a@accesshealthcare.co;noormohamed.h@accesshealthcare.co';                          
                      


INSERT INTO ARC_REC_Athena..ARC_REC_MAIL_TRAN(FROM_MAILID,RECIPIENTS,SUBJECT_TEXT,BODY,ISHTML,MAIL_STATUS,Active)
VALUES('Dump@accesshealthcare.co',@RECIPIENTS,@Mailsubject,@Bodymsg,'Y',0,1) 

/*

Code changed by Udhai on 3rd Feb 2018. DB mail is not required.

EXEC msdb.dbo.sp_send_dbmail                                                                                                                                                                                 
@profile_name = 'DBAMail',                                                                                                                                                             
@recipients='DL-WTP@accesshealthcare.co;mirza.karim@accesshealthcare.co;ramakrishnan.go@accesshealthcare.co;leela.thangavel@accesshealthcare.co;dl_dba@accesshealthcare.co;azzazbadusha.a@accesshealthcare.co',                                                

                   
@subject=@Mailsubject,                                                
@body = @Bodymsg ,                                                                                          
@body_format  = 'HTML'
*/       
End    
    
End  
  
  

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_InvoiceRpt_Mail] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_InvoiceRpt_Mail] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_InvoiceRpt_Mail] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_InvoiceRpt_Mail] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_InvoiceRpt_Mail] TO [DB_DMLSupport]
    AS [dbo];

