﻿CREATE Procedure ADM_LoadAthenaSupervisors
(
      @FUNCTIONALITY_ID int,
      @SessionUserId int      
)
As
Begin
            /*
               Modified Dt : 04/01/2015
               MofiedBy    : kathiravan.kand
               Purpose     : To load Supervisors
            */
      
            select USERID,NT_USERNAME from ADM_Supervisors   
             where   FUNCTIONALITY_ID = @FUNCTIONALITY_ID and CLIENT_ID = 25 and   ACTIVE =1 
            order by NT_USERNAME
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_LoadAthenaSupervisors] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_LoadAthenaSupervisors] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_LoadAthenaSupervisors] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_LoadAthenaSupervisors] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_LoadAthenaSupervisors] TO [DB_DMLSupport]
    AS [dbo];

