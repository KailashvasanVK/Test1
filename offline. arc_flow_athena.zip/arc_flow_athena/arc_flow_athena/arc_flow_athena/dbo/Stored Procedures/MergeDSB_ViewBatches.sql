﻿CREATE Proc MergeDSB_ViewBatches @category varchar(20)=null,@fromDate varchar(10)=null, @ToDate  varchar(10)=null,@BatchNo varchar(20)=null      
as      
begin      
Declare @Qury varchar(Max)    
      
create table #MergedBatches(    
ScanDate varchar(10),      
MergeBatch Varchar(20),      
ChildCount int,      
Pgcount int,      
Status varchar(20),      
Transcount varchar(20))      
      
if(@category='All Status' or @BatchNo is not Null)      
begin        
set @Qury='insert into #MergedBatches      
select Convert(varchar,ScanDate,101),BatchNo ,COUNT(childbatchno),pgcount, ''Pending''  ,'''' from TRN_kOFF_tBatches(NOlock) tbat inner join mergebatchdetails(NOlock) Mbat on tbat.BatchNo=mbat.ParentBatchNo      
where LEFT(BatchNo,1)=''M''and tbat.status<>99 and '      
if(@category is not null)      
begin      
set @qury = @Qury + 'Convert(varchar,ScanDate,101) between ''' + @fromDate + ''' and  ''' + @Todate + '''      
and PostedDt is null group by BatchNo,ScanDate,pgcount      
Union'       
End      
else if(@BatchNo is not null)      
begin      
set @qury = @Qury + ' Batchno=''' + @BatchNo + ''' and PostedDt is null group by BatchNo,ScanDate      
Union'      
End      
set @qury = @Qury + ' select Convert(varchar,ScanDate,101),BatchNo,COUNT(childbatchno),pgcount,''Entry Completed'','''' from TRN_kOFF_tBatches (NOlock)tbat inner join mergebatchdetails (NOlock) Mbat       
 on tbat.BatchNo=mbat.ParentBatchNo where LEFT(BatchNo,1)=''M''  and tbat.status<>99 and '      
      
if(@category is not null)      
begin      
set @qury = @Qury + 'Convert(varchar,ScanDate,101) between ''' + @fromDate + ''' and  ''' + @Todate + '''      
and PostedDt is not null and AuditedDt is null and uploaddt is null group by BatchNo,ScanDate,pgcount      
Union'       
End      
else if(@BatchNo is not null)      
begin      
set @qury = @Qury + 'Batchno=''' + @BatchNo + ''' and PostedDt is not null and AuditedDt is null and uploaddt is null  group by BatchNo,ScanDate      
Union '      
End      
set @qury = @Qury + ' select Convert(varchar,ScanDate,101),BatchNo,COUNT(childbatchno),pgcount,''QC Pending'','''' from TRN_kOFF_tBatches (NOlock) tbat inner join mergebatchdetails (NOlock) Mbat       
 on tbat.BatchNo=mbat.ParentBatchNo where LEFT(BatchNo,1)=''M''  and tbat.status<>99 and '      
      
if(@category is not null)      
begin      
set @qury = @Qury + 'Convert(varchar,ScanDate,101) between ''' + @fromDate + ''' and  ''' + @Todate + '''      
and PostedDt is not null and AuditedDt is null group by BatchNo,ScanDate,pgcount      
Union'       
End      
else if(@BatchNo is not null)      
begin      
set @qury = @Qury + 'Batchno=''' + @BatchNo + ''' and PostedDt is not null and AuditedDt is null group by BatchNo      
Union '      
End      
set @qury = @Qury + ' select Convert(varchar,ScanDate,101),tbat.BatchNo,COUNT(childbatchno),sum(Totalpages),''Completed'',SUM(CreatedPtnCnt + PaymentInsCnt + ExceptionCnt + PtnPostingCnt + ColPostingCnt) TotTrans  from TRN_kOFF_tBatches (NOlock) tbat     
  
 inner join  mergebatchdetails  (NOlock) Mbat on tbat.batchno=Mbat.ParentBatchNo       
 inner join ARC_Athena..BatchLogInformation BatL(NOlock)  on Mbat.ParentBatchNo=batl.Batchnum      
where LEFT(BatchNo,1)=''M'' and  tbat.status=99 and '      
      
if(@category is not null)      
begin      
set @qury = @Qury + 'Convert(varchar,ScanDate,101) between ''' + @fromDate + ''' and  ''' + @Todate + '''      
group by BatchNo,ScanDate      
order by BatchNo desc'       
End      
else if(@BatchNo is not null)      
begin      
set @qury = @Qury + 'Batchno=''' + @BatchNo + ''' group by BatchNo,ScanDate   
order by BatchNo desc'      
End      
      
   
set @Qury=@Qury+ ' select Convert(varchar,ScanDate,101),tbat.BatchNo,COUNT(childbatchno),pgcount, ''For Extract'','''', from TRN_kOFF_tBatches (NOlock) tbat inner join  mergebatchdetails (NOlock) Mbat       
on tbat.BatchNo=Mbat.ParentBatchNo  where LEFT(BatchNo,1)=''M''and PostedDt is not null and UploadDt is not null and tbat.status=1 and '
if(@category is not null)      
begin      
set @qury = @Qury + 'Convert(varchar,ScanDate,101) between ''' + @fromDate + ''' and  ''' + @Todate + '''      
group by BatchNo,ScanDate,pgcount      
order by BatchNo desc    
union'   
End      
else if(@BatchNo is not null)      
begin      
set @qury = @Qury + 'Batchno=''' + @BatchNo + ''' group by BatchNo,ScanDate,pgcount     
order by BatchNo desc
union'     
End        

set @Qury=@Qury+ ' select Convert(varchar,ScanDate,101),tbat.BatchNo,COUNT(childbatchno),pgcount, ''In Extract'','''', from TRN_kOFF_tBatches (NOlock) tbat inner join  mergebatchdetails (NOlock) Mbat       
on tbat.BatchNo=Mbat.ParentBatchNo  where LEFT(BatchNo,1)=''M''and  tbat.status=20 and '  
  if(@category is not null)      
begin      
set @qury = @Qury + 'Convert(varchar,ScanDate,101) between ''' + @fromDate + ''' and  ''' + @Todate + '''      
group by BatchNo,ScanDate,pgcount      
order by BatchNo desc
union'      
End      
else if(@BatchNo is not null)      
begin      
set @qury = @Qury + 'Batchno=''' + @BatchNo + ''' group by BatchNo,ScanDate,pgcount     
order by BatchNo desc'      
End 
print @qury      
exec (@qury)      
End     
      
else if(@category='Pending')      
begin       
insert into #MergedBatches      
select Convert(varchar,ScanDate,101), BatchNo ,COUNT(childbatchno),pgcount, 'Pending'  ,'' from TRN_kOFF_tBatches(NOlock) tbat inner join  mergebatchdetails(NOlock) Mbat       
on tbat.BatchNo=Mbat.ParentBatchNo where LEFT(BatchNo,1)='M' and Convert(varchar,ScanDate,101) between Convert(varchar,@fromDate,101) and Convert(varchar,@ToDate,101) and tbat.status<>99      
and PostedDt is null group by BatchNo,ScanDate,pgcount order by BatchNo desc      
End      
      
else if(@category='Entry Completed')      
begin      
insert into #MergedBatches      
select Convert(varchar,ScanDate,101), BatchNo ,COUNT(childbatchno),PgCount, 'Entry Completed'  ,'' from TRN_kOFF_tBatches(NOlock) tbat inner join mergebatchdetails(NOlock) Mbat       
on tbat.BatchNo=Mbat.ParentBatchNo where LEFT(BatchNo,1)='M' and Convert(varchar,ScanDate,101) between Convert(varchar,@fromDate,101) and Convert(varchar,@ToDate,101) and tbat.status<>99      
and PostedDt is not  null group by BatchNo,ScanDate,pgcount order by BatchNo desc      
End      
      
else if(@category='QC Pending')      
begin      
insert into #MergedBatches      
select Convert(varchar,ScanDate,101),BatchNo,COUNT(childbatchno),PgCount,'QC Pending','' from TRN_kOFF_tBatches (NOlock) tbat inner join  mergebatchdetails (NOlock) Mbat       
 on tbat.BatchNo=Mbat.ParentBatchNo  where LEFT(BatchNo,1)='M' and convert(varchar,ScanDate,101) between Convert(varchar,@fromDate,101) and Convert(varchar,@ToDate,101)and tbat.status<>99      
and PostedDt is not null and AuditedDt is null group by BatchNo,ScanDate ,PgCount order by BatchNo desc      
End      
      
else if(@category='Completed')      
begin      
insert into #MergedBatches      
select Convert(varchar,ScanDate,101),tbat.BatchNo,COUNT(childbatchno),PgCount,'Completed',SUM(CreatedPtnCnt + PaymentInsCnt + ExceptionCnt + PtnPostingCnt + ColPostingCnt) TotTrans  from TRN_kOFF_tBatches (NOlock) tbat       
 inner join  mergebatchdetails  (NOlock) Mbat on tbat.batchno=Mbat.ParentBatchNo       
 inner join ARC_Athena..BatchLogInformation BatL(NOlock)  on Mbat.ParentBatchNo=batl.Batchnum      
where LEFT(BatchNo,1)='M' and convert(varchar,ScanDate,101) between Convert(varchar,@fromDate,101) and Convert(varchar,@ToDate,101) and tbat.status=99      
group by BatchNo,ScanDate ,pgcount     
order by BatchNo desc      
End  

else if(@category='For Extract')      
begin      
insert into #MergedBatches   
select Convert(varchar,ScanDate,101),tbat.BatchNo,COUNT(childbatchno),pgcount, 'For Extract','' from TRN_kOFF_tBatches (NOlock) tbat inner join  mergebatchdetails (NOlock) Mbat       
on tbat.BatchNo=Mbat.ParentBatchNo  where LEFT(BatchNo,1)='M' and convert(varchar,ScanDate,101) between Convert(varchar,@fromDate,101) and Convert(varchar,@ToDate,101)     
and PostedDt is not null and UploadDt is not null and tbat.status=1 group by BatchNo,ScanDate,PgCount order by BatchNo desc      
End

else if(@category='In Extract')      
begin      
insert into #MergedBatches   
select Convert(varchar,ScanDate,101),tbat.BatchNo,COUNT(childbatchno),pgcount, 'In Extract','' from TRN_kOFF_tBatches (NOlock) tbat inner join  mergebatchdetails (NOlock) Mbat       
on tbat.BatchNo=Mbat.ParentBatchNo  where LEFT(BatchNo,1)='M' and convert(varchar,ScanDate,101) between Convert(varchar,@fromDate,101) and Convert(varchar,@ToDate,101)     
and tbat.status=20 group by BatchNo,ScanDate,PgCount order by BatchNo desc      
End

select * from #MergedBatches order by MergeBatch asc       
drop table #MergedBatches      
End   





GO
GRANT EXECUTE
    ON OBJECT::[dbo].[MergeDSB_ViewBatches] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MergeDSB_ViewBatches] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MergeDSB_ViewBatches] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[MergeDSB_ViewBatches] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MergeDSB_ViewBatches] TO [DB_DMLSupport]
    AS [dbo];

