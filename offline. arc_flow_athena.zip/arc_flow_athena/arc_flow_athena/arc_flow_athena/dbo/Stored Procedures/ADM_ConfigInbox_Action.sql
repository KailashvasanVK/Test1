﻿CREATE Procedure ADM_ConfigInbox_Action
As
/*
 Dummy procedures to load the new Inbox Search -- karthik
*/
Begin
Select Bat.ScanDate,ser.ServiceName [Service],bat.BatchNo,cli.ClientAcmName Client,ILog.PageNo,bat.UploadDt [Completed Date] 
,ilogh.Comments  ILogComments,ils.StatusCaption Status
,''  [ILog classification]
,'' [classification type]
,'' [customers information fields]


from TRN_kWisco_tBatchIssueLog as ILog 
inner join TRN_kWISCO_tBatches as Bat on Bat.BatchId = ILog.BatchId
Inner join ADM_Service as Ser on ser.ServiceId = bat.ServiceId
Inner join ADM_Client as cli on cli.ClientId = bat.ClientId
Left join TRN_kWISCO_tBatchIssueLogHistory   ILogH on ILogH.ILogId = ILog.ILogId 
	and ilogh.ILogHistId=(Select  top 1(ILogHistId) from ARC_FLOW_Athena..TRN_kWISCO_tBatchIssueLogHistory  
		 Where  ILogId = ILog.ILogId order by ILogHistId desc )
Inner join ADM_ILogStatus  ILS on ILS.ILog_Status = ILog.ILog_Status
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ConfigInbox_Action] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ConfigInbox_Action] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ConfigInbox_Action] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ConfigInbox_Action] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ConfigInbox_Action] TO [DB_DMLSupport]
    AS [dbo];

