﻿CREATE Procedure [dbo].[ADM_ServiceTrans]              
     @CmpKey varchar(50)        
as              
Begin     

declare @CustomerId as int
select @CustomerId = CustomerId from ADM_Customer where CmpKey = @CmpKey   
Select Distinct Ser.ServiceId,Ser.ServiceName,Ser.ServiceAcmName,Ser.Description from ADM_Service as Ser    
inner join ADM_Client as Cli on Cli.CustomerId = @CustomerId        
inner join ADM_ClientServices as CliSer on CliSer.ClientId = cli.ClientId and ser.ServiceId = CliSer.ServiceId        
where Ser.Status = 1  and Ser.FieldType = 'T'        
Order by Ser.ServiceName    
    
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ServiceTrans] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ServiceTrans] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ServiceTrans] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ServiceTrans] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ServiceTrans] TO [DB_DMLSupport]
    AS [dbo];

