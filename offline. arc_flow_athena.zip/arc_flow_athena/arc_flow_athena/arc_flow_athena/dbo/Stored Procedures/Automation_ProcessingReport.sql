﻿CREATE PROCEDURE Automation_ProcessingReport
As
/*                
Created By     : Gobinath.M                            
Created Date   : 2019-03-25              
Purpose        : To Identify the Bigger batches in Manual Entry and routed to Automation
Ticket/SCR ID  :              
TL Verified By : Ramakrishnan.G
              
Implemented On :               
Implemented On : 
Reviewed by    : 
Reviewed On    : 
*/               
BEGIN

IF OBJECT_ID('Tempdb..#temp') is not null drop table #temp
SELECT NT_USERNAME As UserName, bat.PgCount, bat.BatchNo into #temp From ARC_Flow_Athena..trn_kOFF_tbatches(nolock) bat
Inner join ARC_Flow_Athena..trn_kOFF_tbatchqueue(nolock) que on bat.batchid=que.batchid and bat.status=1
Inner join ARC_REC_Athena..ARC_REC_User_Info(nolock) aUser on aUser.UserID = que.Assigned 
Left join ARC_Athena..BatchLogInformation(nolock) bLog on bLog.BatchNum = bat.BatchNo
where bat.UploadDt is null and bat.PostedDt is null and bat.AuditedDt is null and que.statusid=1 and  bat.pgCount > 10
and LEFT(bat.BatchNO, 1) not in ('M','S') And bat.ServiceID not in (418, 452, 453)

IF OBJECT_ID('Tempdb..#tempTrans') is not null drop table #tempTrans
Select UserName, a.BatchNo, a.pgCount, MAX(MaxPageProcessed) As MaxPageProcessed, Percentage = CAST(ROUND(((MAX(MaxPageProcessed)*100.0)/a.pgCount),2) as decimal(5,2)), SUM(PaymentTrans) As PaymentTrans, SUM(CreationTrans) As CreationTrans, 
SUM(ExceptionTrans) As ExceptionTrans, SUM(PatientPosting) As PatientPosting, 
SUM(CollectionPosting) As CollectionPosting into #tempTrans from (
Select UserName, t.BatchNo, t.pgCount, COUNT(id) As PaymentTrans, 0 As PatientPosting, 0 As ExceptionTrans, 0 As CreationTrans, 0 As CollectionPosting, MAX(pageNo) As MaxPageProcessed 
from ARC_Athena..PaymentDetailMaster (nolock) p 
Inner join #temp t on t.BatchNo = p.BatchNum
Group by UserName, t.BatchNo, t.pgCount
UNION ALL     
Select UserName, t.BatchNo, t.pgCount, 0 As PaymentTrans,  COUNT(id) As PatientPosting, 0 As ExceptionTrans, 0 As CreationTrans, 0 As CollectionPosting, MAX(pageNumber) As MaxPageProcessed  
from ARC_Athena..PatientPostingMaster (nolock) pat
Inner join #temp t on t.BatchNo = pat.BatchNum
Group by UserName, t.BatchNo, t.pgCount
UNION ALL           
Select UserName, t.BatchNo, t.pgCount, 0 As PaymentTrans,  0 As PatientPosting, COUNT(id) As ExceptionTrans, 0 As CreationTrans, 0 As CollectionPosting, MAX(pageNum) As MaxPageProcessed 
from ARC_Athena..BatchException (nolock) bE
Inner join #temp t on t.BatchNo = bE.BatchNum
Group by UserName, t.BatchNo, t.pgCount 
UNION ALL
Select  UserName, t.BatchNo, t.pgCount, 0 As PaymentTrans,  0 As PatientPosting, 0 As ExceptionTrans, COUNT(distinct(clm.ClaimID)) As CreationTrans, 0 As CollectionPosting, MAX(pageNo) As MaxPageProcessed 
from ARC_Athena..PaymentDetailMaster (nolock) pymnt
inner join ARC_Athena..ClaimServiceDetailMaster (nolock)  csd on pymnt.chargeID=csd.ChargeID
inner join ARC_Athena..ClaimDetailMaster (nolock) clm on csd.ClaimID =clm.ClaimID
Inner join #temp t on t.BatchNo = pymnt.BatchNum Where clm.Status = 1
Group by UserName, t.BatchNo, t.pgCount
UNION ALL
Select UserName, t.BatchNo, t.pgCount, 0 As PaymentTrans,  0 As PatientPosting, 0 As ExceptionTrans, 0 As CreationTrans, COUNT(CPId) As CollectionPosting, Max(PageNumber) As MaxPageProcessed 
From ARC_Athena..CollectionPostingMaster(nolock) c
Inner join #temp t on t.BatchNo = c.BatchNum
Group by UserName, t.BatchNo, t.pgCount 
)a
Group by UserName, a.BatchNo, a.pgCount

Select UserName, BatchNo,  pgCount, MaxPageProcessed,  PaymentTrans,  CreationTrans,  ExceptionTrans,  PatientPosting,  CollectionPosting from #tempTrans Where Percentage <= 50

END
 
GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Automation_ProcessingReport] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Automation_ProcessingReport] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Automation_ProcessingReport] TO [DB_DMLSupport]
    AS [dbo];

