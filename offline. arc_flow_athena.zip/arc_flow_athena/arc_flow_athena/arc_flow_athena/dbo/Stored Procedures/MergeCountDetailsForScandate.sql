﻿CREATE Proc MergeCountDetailsForScandate(@Scandate datetime)
as
select  count(distinct a.batchno) as 'Childcount',count(distinct d.batchno)  as 'Parent cnt' --,'InProcess' as Status 
,case when a.status=99 and d.status=1 then 'InProcess' 
when a.status=1 and d.status=99 then 'ExtractComplete and yet to upload'
when a.status=99 and d.status=20 then 'ForExtract'
when a.status=99 and d.status=99 then  'Error' 
else 'need to check'
end as Status 
from trn_koff_tbatches a 
inner join arc_athena..batchmaster b on a.batchno=b.batchnum
inner join arc_flow_athena..mergebatchdetails c on c.childbatchno=b.batchnum
inner join  trn_koff_tbatches  d on c.parentbatchno=d.batchno
where d.scandate='11/13/2015' and b.ulstatus is null --and left(a.batchno,1)<>'s'
--and a.status=99 and d.status=1
group by  a.status,d.status

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[MergeCountDetailsForScandate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MergeCountDetailsForScandate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MergeCountDetailsForScandate] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[MergeCountDetailsForScandate] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MergeCountDetailsForScandate] TO [DB_DMLSupport]
    AS [dbo];

