﻿
        
CREATE proc [dbo].[ADPMerge_Mergedcountdetails] (@scandate varchar(10),@fromPage int, @Topage int)                          
as                          
begin                     
                  
                  
/*                        
                    
Cretaed By     : Leela.T                    
Created Date   : 2017-03-29                      
Purpose        : Merge Batch count & Percentage Details                   
Ticket/SCR ID  : 1195                   
TL Verified By : Udhayaganesh               
                
                 
Implemented by : Udhdyaganesh.p          
Implemented On : 10-April-2017            
                    
Reviewd by     : Udhdyaganesh.p                   
Implemented On : 10-April-2017                     
                    
*/                    
                     
Declare                   
 @serviceName varchar(30)                  
,@ReceivedCnt int                   
,@Mergecount int                  
,@ChildCount int                  
,@MergePrecent float                  
,@NonMergeCount int                  
,@NonMergePrecent float                  
                  
                    
if(object_id('tempdb.dbo.#Tempcount')is not null)                                    
drop table #Tempcount                         
create table #Tempcount                                                                            
(                                                                                                                                                                                                                       
 scandate varchar(10)                                                                                                                                                                                                                                           
,serviceName varchar(30)                  
,Mergecount int                  
,ChildCount int                  
)                                           
                  
if(object_id('tempdb.dbo.#Receivecnt')is not null)                                    
drop table #Receivecnt                          
create table #Receivecnt                                                                            
(                                                                                                                                                                                                                       
 scandate varchar(10)                                                                                                                                                                                                                                          
,serviceName varchar(30)                  
,ReceivedCnt int                   
)                    
                  
                                         
if(object_id('tempdb.dbo.#MergeList')is not null)                                    
drop table #MergeList                         
create table #Mergelist                                                                            
(                    
 id int identity (1,1)                                                                                                                                                                                                                     
,scandate varchar(10)                                                                                                                                                                                                                                          
,serviceName varchar(30)                  
,ReceivedCnt int                   
,Mergecount int                  
,ChildCount int                  
,MergePrecent float                  
,NonMergeCount int                  
,NonMergePrecent float                  
                  
)                                           
                 
insert into #Tempcount                       
Select CONVERT(varchar,ScanDate,101) , servicename, count(distinct parentbatchno),COUNT(childbatchno)  from  TRN_kOFF_tBatches(nolock) a                           
inner join mergebatchdetails (nolock) b on a.BatchNo=b.Childbatchno  inner join adm_service(nolock)  s on s.ServiceId=a.ServiceId                                 
where  CONVERT(varchar,ScanDate,101)=CONVERT(varchar,@Scandate,101) and LEFT(batchno,1) not in ('M','S') and a.serviceid=418 group by ScanDate,ServiceName                          
                          
insert into #Receivecnt                           
select Scandate,servicename,COUNT(batchno)  from  trn_koff_tbatches b                      
inner join  adm_service(nolock)  s on s.ServiceId=b.serviceid                       
where  CONVERT(varchar,ScanDate,101)=CONVERT(varchar,@Scandate,101)  and LEFT(batchno,1) not in ('M','S') and b.serviceid=418      
and pgcount between @fromPage and @ToPage group by servicename,Scandate                    
                    
insert into #Mergelist                     
select b.scandate,b.servicename,isnull(ReceivedCnt,0), isnull(a.Mergecount,0),isnull(a.ChildCount,0), isnull(Round(CAST(a.ChildCount as float)/CAST(ReceivedCnt as float) * 100,2),0), isnull((ReceivedCnt-a.Childcount),0),                  
isnull(Round(CAST((ReceivedCnt-a.Childcount) as float)/CAST(ReceivedCnt as float) * 100,2),0)from #Tempcount a right join #Receivecnt b                    
on a.serviceName=b.serviceName  order by serviceName asc                    
                      
            
select * from #Mergelist  

Drop table #Mergelist  
Drop table #Receivecnt
Drop table #Tempcount        
            
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADPMerge_Mergedcountdetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_Mergedcountdetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_Mergedcountdetails] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADPMerge_Mergedcountdetails] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_Mergedcountdetails] TO [DB_DMLSupport]
    AS [dbo];

