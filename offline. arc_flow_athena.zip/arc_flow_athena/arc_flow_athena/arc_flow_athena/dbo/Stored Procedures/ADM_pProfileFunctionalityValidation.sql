﻿

CREATE Procedure ADM_pProfileFunctionalityValidation 
( 
@Customerid int = 0, 
@UserIdCollection varchar(max) = ''
) 
As 
	/*
		Createddby  : Kathiravan.kand
		CreatedDt : 02/20/2015
		Purpose   : Validate the functionality Details for the Selected Users
	*/ 

Begin 
Declare @ErrMsg varchar(max)  
	if OBJECT_ID('tempdb..#SelectedUsersInfo') is not null drop table #SelectedUsersInfo 
	Create Table #SelectedUsersInfo(NtName varchar(75),UserId int,CustomerId int,Functionality varchar(5)) 
	
	Insert into #SelectedUsersInfo(NtName,UserId,CustomerId,Functionality) 
	Select ui.NT_USERNAME,users.items as UserId,isnull(userCus.CustomerID,0) as CustomerId 
	,isnull((Select 'P' from ADM_AccessFunctionality Where UserId = Convert(int,users.items) and functionality = 'P'),'') + 
	isnull((Select 'A' from ADM_AccessFunctionality Where UserId = Convert(int,users.items) and functionality = 'A'),'') as Audit 
	from dbo.fnSplitString(@UserIdCollection,',') as users --1,2,505,3,4 
	inner join ARC_REC_Athena..ARC_REC_USER_INFO as ui on ui.USERID = convert(int,users.items) 
	left join ARC_REC_Athena..ARC_REC_UserCustomer as userCus on userCus.UserId = convert(int,users.items) 
 --Customer availability check 
 if (Select count(*) from #SelectedUsersInfo Where CustomerId = 0)>0 
	Begin  
		Set @ErrMsg = 'Customer allocation missing for mentioned associates. Please contact HR team. </br>' + STUFF((Select ',' + ntName from #SelectedUsersInfo Where CustomerId = 0 for xml path('')),1,1,'')  
	End  
 --functionality check 
  if (Select COUNT(*) as FunctionalityCnt from ( 
	  Select Functionality 
	  From 
	 ( 
		 Select UserId 
		 ,(Select Functionality from #SelectedUsersInfo where UserId = us.UserId Group by Functionality) as Functionality 
		 from #SelectedUsersInfo as us 
		 ) x group by Functionality 
		 ) y 
	 ) > 1 
	 Begin 
		 Set @ErrMsg = 'Functionality conflict. Please select valid associates' 
	End  
	if OBJECT_ID('tempdb..#SelectedUsersInfo') is not null drop table #SelectedUsersInfo 
	Select isnull(@ErrMsg,'') as Result 
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pProfileFunctionalityValidation] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pProfileFunctionalityValidation] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pProfileFunctionalityValidation] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pProfileFunctionalityValidation] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pProfileFunctionalityValidation] TO [DB_DMLSupport]
    AS [dbo];

