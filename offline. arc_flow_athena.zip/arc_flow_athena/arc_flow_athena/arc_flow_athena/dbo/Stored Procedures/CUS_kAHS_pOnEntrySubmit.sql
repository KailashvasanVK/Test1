﻿CREATE Procedure CUS_kAHS_pOnEntrySubmit(@BatchProcessId int,@BatchServiceId int,@FteId int)

As

Begin

if @BatchServiceId = 348 /** CMN **/

      Begin

      Update TRN_kAHS_tProcessedBatches Set QcRequiredStatus = 0 Where BatchProcessId = @BatchProcessId And QcPer <> 100

      Exec CUS_kAHS_pReArrangeQcBucketByFTE @FteId = @FteId

      End

End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kAHS_pOnEntrySubmit] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kAHS_pOnEntrySubmit] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kAHS_pOnEntrySubmit] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kAHS_pOnEntrySubmit] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kAHS_pOnEntrySubmit] TO [DB_DMLSupport]
    AS [dbo];

