﻿CREATE Procedure  CUS_kNWYRK_pAutoBatchCreator
(
 @pFileName varchar(200) = ''
,@pPageCount int = 0
,@pCmpKey varchar(5)=''
,@pScanDate date=''
,@pBatchNo varchar(50)=''          
)
As
Begin

Declare @ServiceId int = 0
Declare @ClientId int = 0

if(left(@pFileName,3) = 'NS_')
	Begin
		Set @ClientId = 3; --NS1
		Set @ServiceId = 7;--Coding
	End
else if(LEFT(@pFileName,3) ='SSG')
   Begin
		Set @ClientId = 6; --SSG
		Set @ServiceId = 7;--Coding
	End
else if(LEFT(@pFileName,4) ='NYP_')
   Begin
      Set @ClientId = 5;--NYP
      if(LEFT(@pFileName,7)='NYP_CHG')       
      	Set @ServiceId = 1;--Charge
      else
        Set  @ServiceId = 5;--Payment
   End
else if(LEFT(@pFileName,7)='CAR_PMT')
   Begin
       Set @ClientId = 2; --NYP
	   Set @ServiceId = 5;--Payment
   End
Else if(LEFT(@pFileName,8)='SPR_BCBS')
   begin
     Set @ClientId = 94;--SPR
     Set @ServiceId = 5;--payment
   End
Else if(LEFT(@pFileName,7)='SPR_DPC')
   begin
     Set @ClientId = 94;--SPR
     Set @ServiceId = 5;--payment
   End
Else if(LEFT(@pFileName,7)='SPR_MCD')
   begin
     Set @ClientId = 94;--SPR
     Set @ServiceId = 5;--payment
   End
 Else if(LEFT(@pFileName,7)='SPR_MCR')
   begin
     Set @ClientId = 94;--SPR
     Set @ServiceId = 5;--payment
   End
Else if(LEFT(@pFileName,4)='SPR_')
   begin
     Set @ClientId = 94;--SPR
     Set @ServiceId = 1;--Charge
   End

Else if(LEFT(@pFileName,4)='SOW_')
  begin
      Set @ClientId = 97;--SOW
	  Set @ServiceId = 5;--Payment
  End
Else if(LEFT(@pFileName,5)='ERMA_')
  begin
      Set @ClientId = 270;--
	  Set @ServiceId = 7;--coding
  End
  if(@ClientId <>0 and @ServiceId <>0)
   begin
	   Exec TRN_pBatchesInsert @CmpKey ='NWYRK',@ScanDate=@pScanDate,@BatchNo=@pBatchNo,@FileName =@pFileName,@ClientId =@ClientId,@ServiceId=@ServiceId
							   ,@BatchType=1,@CreatedBy=1777,@PageCount=@pPageCount
    End
End







GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kNWYRK_pAutoBatchCreator] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kNWYRK_pAutoBatchCreator] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kNWYRK_pAutoBatchCreator] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kNWYRK_pAutoBatchCreator] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kNWYRK_pAutoBatchCreator] TO [DB_DMLSupport]
    AS [dbo];

