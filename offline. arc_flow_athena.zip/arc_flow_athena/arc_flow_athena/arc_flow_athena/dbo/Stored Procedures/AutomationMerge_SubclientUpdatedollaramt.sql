﻿CREATE  proc AutomationMerge_SubclientUpdatedollaramt            
as 
/*
Cretaed By     : Leela.T                  
Created Date   : 09-May-2018                
Purpose        : Update the dollaramt                 
Ticket/SCR ID  : <>                  
TL Verified By : <>                
              
              
Implemented by : Karmegan.c               
Implemented On :  10-05-2018  
*/             
begin              
              
Declare @Rowcount int,@dollarAmt Float,@batchno varchar(20)              
              
create table #ParentBatches              
(Id  int IDENTITY (1, 1) NOT NULL,                                                                                                
BatchNo   Varchar(20))                
                 
 insert into #ParentBatches(BatchNo)              
 select distinct parentbatchno from  ARC_Flow_Athena..MergeBatchDetails where status=17            
                
 select @Rowcount=@@ROWCOUNT              
                 
while(@Rowcount>0)              
begin              
select @batchno = batchno from #ParentBatches where id=@Rowcount     
                           
select @dollarAmt=SUM(dollaramt) from ARC_Athena..batchMaster where batchnum in (            
 select ChildBatchNo from ARC_Flow_Athena..MergeBatchDetails where ParentBatchNo=@batchno)              
             
Update ARC_Athena..batchMaster set dollarAmt= @dollaramt where batchnum=@batchno              
           
Update  ARC_Flow_Athena..TRN_kOFF_tBatches set status=1 where batchno=@batchno              
          
Update ARC_Flow_Athena..MergeBatchDetails  set status=18 where parentbatchno=@batchno              
set @Rowcount=@Rowcount-1              
End              
                                                                                                
End 

GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AutomationMerge_SubclientUpdatedollaramt] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AutomationMerge_SubclientUpdatedollaramt] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AutomationMerge_SubclientUpdatedollaramt] TO [DB_DMLSupport]
    AS [dbo];

