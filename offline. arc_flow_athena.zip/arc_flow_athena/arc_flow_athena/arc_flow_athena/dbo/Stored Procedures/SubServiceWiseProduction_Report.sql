﻿Create Procedure SubServiceWiseProduction_Report
as
begin 

declare @date date=(convert(date,getdate()-15))
declare @date1 varchar(20)=convert(varchar(20),@date)

if OBJECT_ID('tempdb..#tmpCustomers') is not null drop table #tmpCustomers
Create Table #tmpCustomers(CustomerId int,CmpKey varchar(5))
Insert into #tmpCustomers(CustomerId,CmpKey)
Select Cus.CustomerId,CmpKey from ADM_Customer Cus
Where isnull(Cus.CmpKey,'') <> '' and  isnull(Cus.CmpKey,'') <> 'AHS'  

if OBJECT_ID('tempdb..#tmpProductionData') is not null  drop table #tmpProductionData
create table #tmpProductionData(CustomerID int,Userid int,ProdDate date,BatchServiceId int,ServiceId int,Rawtrans bigint) 


Declare @qry varchar(max)
Declare @tempCmpKey varchar(5)
Declare @customerid int
Declare cur Cursor
for select CmpKey,CustomerId from #tmpCustomers (nolock) /*Where isnull(CmpKey,'') <> '' */
open cur
while 1=1
begin
fetch next from cur into @tempCmpKey ,@CustomerId
if @@FETCH_STATUS = -1 break
if OBJECT_ID('TRN_k'+@tempCmpKey+'_tBatches') is not null
Begin

set @qry='
insert into #tmpProductionData(CustomerID , Userid,ProdDate,BatchServiceId,ServiceId,RawTrans)
select '+convert(varchar,@CustomerId)+', bt.CreatedBy,convert(date,bt.CreatedDt)CreatedDt,bt.BatchServiceId, bt.ServiceId
,SUM(isnull(TransValue,0))  As RawTrans from TRN_k'+@tempCmpKey+'_tBatches b join
TRN_k'+@tempCmpKey+'_tBatchTransact bt on bt.BatchId=b.BatchId
where b.status=1 and CONVERT(date,bt.CreatedDt)>='''+@date1+'''
group by bt.CreatedBy,convert(date,bt.CreatedDt),bt.BatchServiceId, bt.ServiceId'
print @qry
Exec (@qry)
End
end
close cur
deallocate cur


select 
pd.ProdDate,ui.FIRSTNAME+' '+ui.LASTNAME as Name ,ui.NT_USERNAME,ui.EmpCode,ui.DOJ,ui.REPORTING_TO as Supervisor,
cus.InternalName as Customer,f.FunctionName ,d.Designation,d.Band,d.Grade,lob.lob 
,lm.LocationName, isnull(s.ServiceName,'') ServiceName,ss.ServiceName AS SubserviceName,
pd.Rawtrans
 from #tmpProductionData pd
join ADM_Service s on pd.BatchServiceId=s.ServiceId
join ADM_Service ss on pd.ServiceId=ss.ServiceId
join ADM_Customer cus on cus.CustomerId=pd.CustomerID
join ARC_REC_AThena..ARC_REC_USER_INFO ui on ui.USERID=pd.Userid
join ARC_REC_AThena..HR_Designation d on d.DesigId=ui.DESIGNATION_ID
join ARC_REC_AThena..ARC_REC_LOB_INFO lob on lob.ID=ui.LOB
join ARC_REC_AThena..HR_LocationMaster lm on lm.LocationID=ui.LocationID
join ARC_REC_AThena..HR_Functionality f on f.FunctionalityId=ui.FUNCTIONALITY_ID  
order by ProdDate asc 
End
GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SubServiceWiseProduction_Report] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[SubServiceWiseProduction_Report] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SubServiceWiseProduction_Report] TO [DB_DMLSupport]
    AS [dbo];

