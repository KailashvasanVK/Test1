﻿

CREATE  Procedure ADM_pProfileClientsByCustomer
(@UserIdCollection varchar(max) = '',
@CustomerId INT = 25,
@ServiceId INT = 25
)
AS
Begin

if ((select COUNT(items)   from fnSplitString(@UserIdCollection,',')) <2 and @UserIdCollection <> '')
	BEGIN
	
		--select * from (
		--Select 'ALL' as ClientAcmName,0 as ClientId,0 as GroupId 
		--UNION ALL
		--select  ac.ClientAcmName,ac.ClientId,ISNULL(b.GroupId,1) AS orederid from ADM_client ac
		--inner join ADM_AccessClient b on ac.ClientId = b.ClientId
		--where ac.CustomerId = @CustomerId and Status =1 and UserId = CAST(@UserIdCollection as int)	) as a
		--order by ClientId
		
		
			--select distinct cli.ClientAcmName,gp.ClientId 
			--from ADM_ServiceGroup gp
			--inner join ADM_AccessClient accli on accli.ClientId = gp.ClientId and CustomerId =@CustomerId
			--INNER JOIN ADM_Client  cli on cli.ClientId = accli.ClientId
			--where gp.ServiceGroupId = @ServiceId and UserId = @use
			
			--select distinct cli.ClientAcmName,gp.ClientId,
		 --  isnull((select top 1 1 from ADM_AccessClient where ServiceId=@ServiceId and UserId = CAST(@UserIdCollection as int) and CustomerId=@CustomerId and ClientId =gp.ClientId),0 )  as selected 
			--from ADM_ServiceGroup gp
			--inner join ADM_Client cli on cli.ClientId = gp.ClientId and cli.Status =1 and CustomerId =@CustomerId
			--where gp.ServiceGroupId = @ServiceId
			
			select * from (
				Select 'ALL' as ClientAcmName,0 as ClientId,0 as GroupId 
				UNION ALL
				select distinct ISNULL(cli.ClientAcmName,'') as ClientAcmName,ISNULL(gp.ClientId,'') as ClientId,--aac.AccClientId ,
			--	CASE  WHEN aac.AccClientId is null or aac.AccClientId = '' THEN 0   WHEN aac.AccClientId > 0 THEN 1 END as selected ,
				ISNULL(aac.GroupId,1) as GroupId
				from ADM_ServiceGroup gp
				inner join ADM_Client cli on cli.ClientId = gp.ClientId and cli.Status =1 and CustomerId =@CustomerId
				Left Join ADM_AccessClient aac on aac.ServiceId=@ServiceId and aac.UserId = CAST(@UserIdCollection as int) and aac.CustomerId=@CustomerId and aac.ClientId =gp.ClientId
				where gp.ServiceGroupId = @ServiceId) a
				order by ClientId
	
	
	END
	ELSE
	BEGIN
			--select * from (
			--Select 'ALL' as ClientAcmName,0 as ClientId,0 as GroupId
			--UNION ALL
			--select ClientAcmName,ClientId,1 as GroupId 
			--from ADM_client  where CustomerId = @CustomerId and Status =1 ) as ac
			--order by ClientId
			select * from (
		
			Select 'ALL' as ClientAcmName,0 as ClientId,0 as GroupId
			UNION ALL
			select distinct cli.ClientAcmName,gp.ClientId,1 as GroupId from ADM_ServiceGroup gp
			inner join ADM_Client cli on cli.ClientId = gp.ClientId and cli.Status =1 and CustomerId =@CustomerId
			where gp.ServiceGroupId = @ServiceId
			) as ac
			order by ClientId
	END

END


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pProfileClientsByCustomer] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pProfileClientsByCustomer] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pProfileClientsByCustomer] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pProfileClientsByCustomer] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pProfileClientsByCustomer] TO [DB_DMLSupport]
    AS [dbo];

