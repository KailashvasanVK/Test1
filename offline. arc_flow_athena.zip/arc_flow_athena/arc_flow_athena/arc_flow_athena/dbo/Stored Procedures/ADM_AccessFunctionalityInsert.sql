﻿CREATE Procedure [dbo].[ADM_AccessFunctionalityInsert]
@UserId int ,
@Functionality varchar(5),
@CreatedBy  int 
As
/*
Created by : Karthik Ic
Created on : 15 May 2013
Impact to  : ProfileSetup.aspx
Purpose    : To save the user and Functionality details
*/
Begin
Insert into ADM_AccessFunctionality(UserId,Functionality,CreatedBy)
Select @UserId,@Functionality,@CreatedBy
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_AccessFunctionalityInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessFunctionalityInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessFunctionalityInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_AccessFunctionalityInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_AccessFunctionalityInsert] TO [DB_DMLSupport]
    AS [dbo];

