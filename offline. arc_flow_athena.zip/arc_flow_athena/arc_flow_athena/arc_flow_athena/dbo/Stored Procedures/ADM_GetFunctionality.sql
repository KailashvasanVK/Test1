﻿
Create Procedure ADM_GetFunctionality
As
begin
/*
   Created By  : kathiravan.kand
   CreteatedDt : 04/01/2015
   Purpose     : get active functinalirt list 
*/
      select FunctionalityId,FunctionName from ARC_REC_athena..HR_Functionality  where Status =1 
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_GetFunctionality] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetFunctionality] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetFunctionality] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_GetFunctionality] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetFunctionality] TO [DB_DMLSupport]
    AS [dbo];

