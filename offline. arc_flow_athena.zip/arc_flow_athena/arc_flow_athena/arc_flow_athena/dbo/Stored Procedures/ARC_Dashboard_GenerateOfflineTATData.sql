﻿
CREATE PROCEDURE ARC_Dashboard_GenerateOfflineTATData(@DateFrom date, @DateTo date)  
as  
  begin       
 /*===============================================================================================                                               
CREATED BY : Leela.T                                     
CREATED DT : 06/13/2017(MM/DD/YYYY)     
Reason: To show the TAT for Pa between the date given                                      
EXEC ARC_Dashboard_GenerateTATData @FROM_DT='03/31/2017',@TO_DT='03/31/2017'   
  
  
Modified BY : Leela.T                                     
Modified date DT : 07/19/2017(MM/DD/YYYY)     
Reason: to add User Name & Service Name in this Report  

Implemented by : Ganesh Tanneru  
Implemented on : 14-Jun-2017  
Ticket/SCR Id : 213823                     
=================================================================================================*/      



 if OBJECT_ID('tempdb..#TATReportHeldBatch') is not null drop table #TATReportHeldBatch      
 Select bat.BatchId  into #TATReportHeldBatch from TRN_kOFF_tBatches as bat      
 inner join TRN_kOFF_tHeldBatches as held on held.BatchId = bat.BatchId     
 and Cast(held.HeldDate as date) between @DateFrom and @DateTo  and ReleaseDate is null    
 Where bat.Status = 1  Group by bat.BatchId    
             
         
if OBJECT_ID('tempdb..#TATReportEndDate') is not null drop table #TATReportEndDate  
create table #TATReportEndDate  
(Batchid int  
,TATDate Varchar(10)  
,clientid int  
,userid int 
,UserName varchar(75) 
,Serviceid int  
,serviceName varchar(100)
,UploadDt Datetime  
,TATEndDate Datetime)  
    
if OBJECT_ID('tempdb..#TblTAT') is not null drop table #TblTAT  
CREATE  TABLE #TblTAT(  
[TATDate] [date] NULL,  
[ClientId] [int] NULL,  
[BatchServiceId] [int] NULL,  
[ServiceName] varchar(100),
[userid] [int] NULL,
[UserName] varchar(75),   
[WithinTAT] [int] NULL,  
[OutofTAT] [int] NULL,  
[Total] [int] NULL,             
[TotalTimeTaken] [int] NULL)  
   
insert into #TATReportEndDate(Batchid,TATDate,clientid,Serviceid,serviceName,UploadDt,TATEndDate)  
select Batchid,Convert(Date,bat.Scandate) as TATDate,15 as ClientId,bat.ServiceId,ser.ServiceName,  
bat.UploadDt  as UploadDt, TATendDate =([dbo].[TRN_kOFF_fnAddWorkingDays](Scandate,3))    
from TRN_koff_tbatches bat (nolock) inner join adm_service ser on ser.serviceid=bat.serviceid    
where Scandate between @DateFrom and @DateTo  and  bat.status=1  and uploaddt is not null  
and not exists (select 1 from #TATReportHeldBatch Where BatchId = bat.BatchId)                                
   
   
update #TATReportEndDate set userid=CreatedBy ,TATEndDate=TATEndDate+ ' 09:29:59:000' from arc_flow_athena.dbo.TRN_kOFF_tBatchflow(Nolock) flw    
inner join #TATReportEndDate(nolock) tat  on  tat.batchid=flw.batchid where  StatusId=6  
   
   
   
update #TATReportEndDate set UserName=Nt_username from arc_rec_athena..arc_rec_user_info(Nolock) inf    
inner join #TATReportEndDate(nolock) tat  on  tat.userid=inf.userid
   
insert into #TblTAT  
Select  TATDate,ClientId,ServiceId,ServiceName,UserId,UserName,Sum(WithinTAT) WithinTAT,Sum(OutOfTAT) OutOfTAT, (Sum(WithinTAT) + Sum(OutOfTAT)) as Total , Sum(isnull(ProceMin,0)-isnull(HeldMin,0))  as Time from (  
Select TATDate,ClientId,Batchid,ServiceId,ServiceName,UserId,UserName,ProceMin,WithinTAT,OutOfTAT,sum(HeldMin) as HeldMin  
from(  
   
Select TATDate,ClientId,tat.Batchid as Batchid,ServiceId,ServiceName,UserId,UserName,Datediff(minute,HeldDate,ReleaseDate) as [HeldMin],  
arc_flow_athena.dbo.ARC_BusinessMinutesServiceBased(Cast(CONVERT(varchar,TATDate,101) + ' 09:30:00:000' as datetime),UploadDt,15,serviceid) as [ProceMin]  
,case when Convert(Date,UploadDt)<=Convert(varchar(11),TATendDate,101)  then 1 else 0 End as WithinTAT  
,case when Convert(Date,UploadDt)>Convert(varchar(11),TATendDate,101)  then 1 else 0 End as OutOfTAT   
from #TATReportEndDate tat left join TRN_kOFF_tHeldBatches  hld on tat.batchid=hld.batchid   
   
)X group by TATDate,ClientId,ServiceId,Batchid,UserId,ProceMin,WithinTAT,OutOfTAT,ServiceName,UserName  
) a group by TATDate,ClientId,ServiceId,UserId,ServiceName,  UserName
order by TATDate  
   
select * from #TblTAT  
  
Drop table #TATReportHeldBatch      
Drop table #TATReportEndDate  
Drop table #TblTAT  
   
   
End  
  

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Dashboard_GenerateOfflineTATData] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Dashboard_GenerateOfflineTATData] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Dashboard_GenerateOfflineTATData] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Dashboard_GenerateOfflineTATData] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Dashboard_GenerateOfflineTATData] TO [DB_DMLSupport]
    AS [dbo];

