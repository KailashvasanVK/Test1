﻿CREATE PROCEDURE  ARC_AUTO_ENTRYTOBATCHCOMPLETED         
(          
@BATCHNO NVARCHAR(MAX),          
@TICKETID VARCHAR(20),      
@NTUSERNAME VARCHAR(50)          
)          
AS           
/*          
          
Created By      : <KARMEGAN C  >      
Created On      : 20-06-2016           
Purpose         : TO PROCESS THE ENTRY TO BATCH COMPLETED       
Ticket/SCR ID   : <>      
TL Verified By  : <>      
SAMPLE          : EXEC ARC_FLOW_ENTRYTOBATCHCOMPLETED @BATCHNO ='S219600A1,S219663A1,S219781A1',@TICKETID ='147144'           
      
Modified By     : <Modified person Name>      
Modified On     :       
Modified Reason : <>      
      
Reviewed By     : <UDHAYA GANESH.P>      
Reviewed On     : 21-06-2016      
IT Ticket ID    :      
*/          
BEGIN         
       
if OBJECT_ID('tempdb..#BatchCollection') is not null drop table #BatchCollection           
if OBJECT_ID('tempdb..#BatchIds') is not null drop table #BatchIds    
  
SELECT @BATCHNO=REPLACE(REPLACE(REPLACE(@BATCHNO,CHAR(9),''),CHAR(10),''),CHAR(13),'')  
        
      
select batchid into #BatchIds  from TRN_kOFF_tbatches where Batchno in         
(select items  from DBO.MySplit(@BATCHNO,','))         
          
          
Declare @CreatedBy int=(SELECT USERID FROM ARC_REC_ATHENA..ARC_REC_USER_INFO WHERE NT_USERNAME= @NTUSERNAME)               
,@Comments varchar(1000)='Requested Ticket Id:'+@TICKETID+''           
          
Select que.BatchId,que.BatchProcessId          
into #BatchCollection  
from TRN_kOFF_tBatchQueue (nolock) as que          
inner join #BatchIds as bc on bc.BatchId = que.BatchId          
inner join TRN_kOFF_tBatches (nolock) bat on que.BatchId=bat.BatchId and bat.PostedDt is not null          
Where que.StatusId = 6        
   
 SELECT * FROM #BatchCollection  
        
update bat set UploadDt=getdate()          
from TRN_kOFF_tBatches bat inner join          
#BatchCollection bc on bat.BatchId=bc.BatchId          
           
update que set StatusId=13          
from TRN_kOFF_tBatchQueue que inner join          
#BatchCollection bc on que.BatchId=bc.BatchId and que.BatchProcessId=bc.BatchProcessId          
          
insert into TRN_kOFF_tBatchFlow(BatchProcessId,BatchId,Comments,CreatedBy,CreatedDt,StatusId)          
select distinct que.BatchProcessId,que.BatchId,@Comments,@CreatedBy,GETDATE(),13          
from TRN_kOFF_tBatchQueue que inner join          
#BatchCollection bc on que.BatchId=bc.BatchId and que.BatchProcessId=bc.BatchProcessId          
           
Insert into TRN_kOFF_tDirectUpload(BatchId,CreatedBy,CreatedDt)          
select distinct BatchId,1, GETDATE() from #BatchCollection          
           
Insert into TRN_kOFF_tBatchModified(BatchId,BatchServiceId,CreatedBy,CreaetdDt,Comments,ModifyMode)          
select distinct bat.BatchId,ServiceId,@CreatedBy,GETDATE(),'Direct upload By User :'+@Comments,'DU' from TRN_kOFF_tBatches bat           
inner join #BatchCollection bc on bc.BatchId=Bat.BatchId          
          
if OBJECT_ID('tempdb..#BatchCollection') is not null drop table #BatchCollection           
if OBJECT_ID('tempdb..#BatchIds') is not null drop table #BatchIds           
END          
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_AUTO_ENTRYTOBATCHCOMPLETED] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_AUTO_ENTRYTOBATCHCOMPLETED] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_AUTO_ENTRYTOBATCHCOMPLETED] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_AUTO_ENTRYTOBATCHCOMPLETED] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_AUTO_ENTRYTOBATCHCOMPLETED] TO [DB_DMLSupport]
    AS [dbo];

