﻿
CREATE procedure  TRN_kOFF_pGetForeCastTargetMonthlyReport
    (
     @fromDate varchar(20)='',
     @toDate varchar(20)='',
     @SearchStr varchar(50) ='',
	 @SearchPattern varchar(50)='='
    )
    as
    begin
    
    /*
Created By mallikarjun.nam
Created Date :04-09-2015
Impact : Forecastreport.aspx in .flow.offline (athena application) -Show monthly wise target achived details report

Modified by : mallikarjun.nam
Modified dt : 2015-10-05
Purpose     : previously report getting based on scandate now changed Trans completed date instead of scandate
*/
    
    --declare @fromDate varchar(20)='jan2015',@toDate varchar(20)='August2015'
    -- gettting @fromDate as starting date of month and @toDate as Last Date of the month 
	set @fromDate = '01'+ @fromDate
	SELECT  @toDate=DATEADD(d, -1, DATEADD(m, DATEDIFF(m, 0, @toDate) + 1, 0))
	
	-- declare @NoOfMonths int=DATEDIFF(mm,@fromDate,@toDate)
	 
	 ---In this CTE Table selecting all the months @fromDate to @toDate with null values
     if (OBJECT_ID('tempdb..#tblForeCast') IS NOT NULL)  DROP TABLE #tblForeCast
        ;with mths as
		(
	    	select datepart(mm,convert(date,@fromDate)) as mth,datepart(yy,convert(date,@fromDate)) as Year,
	    	0 as Achieved,
			0 as YetToAchieved,0 as [Achieved%], convert(date,@fromDate) as SDate
			union all
			select datepart(mm,DATEADD(mm,1,convert(date,SDate))),datepart(yy,DATEADD(mm,1,convert(date,SDate)))
			,0 as Achieved
			,0 as YetToAchieved,0 as [Achieved%]
			,DATEADD(mm,1,convert(date,SDate))  
			 from mths
			 where SDate< DATEADD(mm,-1,convert(date,@toDate))
		)
   select *  into #tblForeCast from mths
    option (maxrecursion 32767);
  
  if (OBJECT_ID('tempdb..#tblForeCastNew') IS NOT NULL)  DROP TABLE #tblForeCastNew
  --Getting Transvalue from trn_kOFF_tbatchTransact and inner join with mths table getting TrasDate and Sum(TransValue) etc.
  select F1.*,  F2.Target into #tblForeCastNew from #tblForeCast  F1 left outer join  ADM_Forecast F2
  on datepart(mm, F1.SDate)=F2.Month and datepart(yy, F1.SDate)= F2.Year
  
  select * into #Forecastreport from(
  select  left(datename(mm, convert(date, SDate)),3) + ''''+ right( datepart(yy, convert(date, SDate)),2) as Month
  ,isnull(Target,0) as [Forecast Target],Achieved
  ,(case when datepart(mm,SDate)=datepart(mm,getdate()) and datepart(yy,SDate)=  datepart(yy,getdate())then isnull(Target,0)-isnull(Achieved,0)else 0 end) as [Yet to Achieved]
  ,(case when  isnull(Target,0)=0 then '0.00%' else  convert(varchar, cast((convert(money,isnull(Achieved,0))/convert(money,isnull(Target,0))*100)as decimal(18,2))) + '%' end) as [Achieved%]
  from(
	select sum(TransValue) as Achieved,Target,FF.SDate from #tblForeCastNew FF left outer join 
	(
		select TransValue, convert(date,T.CreatedDt) as TrasDate  from trn_kOFF_tbatchTransact T Inner JOIN trn_kOFF_tbatches B ON T.BatchId= B.BatchID AND B.status=1 and T.TransValue <>0 and
		convert(date,T.CreatedDt) between convert(date,@fromDate) and convert(date,@toDate)
	)
	as TranTbl ON  convert(varchar, DATEPART(mm,FF.SDate)) + '/' + convert(varchar, DATEPART(yy,FF.SDate)) =convert(varchar, DATEPART(mm,TrasDate)) + '/' + convert(varchar, DATEPART(yy,TrasDate))
	group by Target,FF.SDate
  ) as TranSumTbl )X --order by SDate
	     
	     select * into #report from (
 select Convert(varchar(5),'')ColHead,
        Month,
        [Forecast Target],
        Achieved,
        [Yet to Achieved],
        [Achieved%] from #Forecastreport 
	    union all
select 'G',
       'Total' as Month,
       (select sum([Forecast Target]) from #Forecastreport),
       (select sum(Achieved) from #Forecastreport),
       (select sum([Yet to Achieved]) from #Forecastreport),
	   (CASE WHEN (select sum([Forecast Target]) from #Forecastreport)=0 then '0.00%' Else 
	    convert(varchar,( convert(money,(select sum(Achieved) from #Forecastreport))/convert(money,(select sum([Forecast Target]) from #Forecastreport))*100))end))x
	     
    Exec FilterTable  
	@DbName = 'tempdb'  
	,@TblName = '#report'  
	,@SearchStr = @SearchStr  
	,@SearchPattern = @SearchPattern
	,@OrderStr = ''
   
end


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pGetForeCastTargetMonthlyReport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pGetForeCastTargetMonthlyReport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pGetForeCastTargetMonthlyReport] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pGetForeCastTargetMonthlyReport] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pGetForeCastTargetMonthlyReport] TO [DB_DMLSupport]
    AS [dbo];

