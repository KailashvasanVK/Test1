﻿CREATE Procedure  CUS_kGreen_pAutoBatchImport
(
@BatchNo varchar(50)
,@ClientId int
,@ServiceId int
,@PageCount int
,@Qry varchar(max)
,@CreatedBy varchar(50)
,@DownloadDate date=null
,@ScanDate date = null
)
as
 Begin
 --Insert batches
 --Insert que
 --Insert flow 
 --get batchid 
  --update  q
  --insert into #BatchInfoFields from  
  if(select COUNT(*) from TRN_kAHS_tBatches where BatchNo =@BatchNo and ServiceId =@ServiceId) =0
  begin
		Declare @UserId int  =0 
		Declare @BatchId int =0
		set @UserId = (select top  1 USERID from ARC_REC_Athena..ARC_REC_USER_INFO where NT_USERNAME =@CreatedBy)    

		Insert into TRN_kAHS_tBatches(ScanDate,BatchNo,ClientId,ServiceId,BatchType,CreatedBy,CreatedDt,Priority,PgCount,FName,status,QType,CreatedOn)
		select distinct @ScanDate,@BatchNo,@ClientId,@ServiceId,3,@UserId,@DownLoadDate,0,@PageCount,'',1,2,GETDATE() 

		set @BatchId = IDENT_CURRENT('TRN_kAHS_tBatches') 
		insert into TRN_kAHS_tBatchQueue(BatchId,BatchNo,PageFrom,PageTo,Assigned,ClientId,ServiceId,StatusId,Comment,CreatedBy,CreatedDt,QType)
		select BatchId,BatchNo,1,PgCount,0,ClientId,ServiceId,0,'',CreatedBy,CreatedDt,QType 
		from TRN_kAHS_tbatches where BatchId = @BatchId

		insert into TRN_kAHS_tBatchFlow(BatchId,BatchProcessId,CreatedDt,CreatedBy,StatusId,Comments,Ref_FlowId)
		select que.BatchId,que.BatchProcessId,que.CreatedDt,que.CreatedBy,0,'',0 
		from TRN_kAHS_tbatches bat
		inner join TRN_kAHS_tBatchQueue que on bat.BatchId =  que.BatchId
		Where bat.BatchId = @BatchId	

		Update TRN_kAHS_tBatchQueue set FlowId = (Select MAX(flowid) from TRN_kAHS_tBatchFlow Where BatchProcessId = que.BatchProcessId)
		from TRN_kAHS_tBatchQueue  as Que
		inner join TRN_kAHS_tBatches  bat on bat.BatchId =que.BatchId and bat.BatchId =@BatchId

		IF OBJECT_ID('tempdb..#BatchInfoFields') IS NOT NULL    DROP TABLE #BatchInfoFields
		declare @Query varchar(max)
		set @Query='  
		select *  into #BatchInfoFields 
		from 
		(
		'+ @Qry+'
		)x
		Declare @ServiceIdAccountNo int =345
		Declare @ServiceIdPtLastName int = 344
		Declare @ServiceIdPtFirstName int = 343
		Declare @ServiceIdPOS int =342
		Declare @ServiceIdAdmitDt int =341
		Declare @ServiceIdPeromingDoc int=334  

		insert into TRN_kAHS_tBatchInformation(BatchId,PageNo,ServiceId,Infovalue,CreatedBy,CreatedDt) 
		select  '+convert(varchar,@BatchId)+',pageNo,@ServiceIdAccountNo ,AccountNo,'+convert(varchar,@UserId)+',GETDATE()
		from #BatchInfoFields 
		union all
		select  '+convert(varchar,@BatchId)+',pageNo,@ServiceIdPtLastName  ,PTLastName,'+convert(varchar,@UserId)+',GETDATE()
		from #BatchInfoFields 
		union all
		select  '+convert(varchar,@BatchId)+',pageNo,@ServiceIdPtFirstName  ,PTFirstName,'+convert(varchar,@UserId)+',GETDATE()
		from #BatchInfoFields 
		union all
		select  '+convert(varchar,@BatchId)+',pageNo,@ServiceIdPOS  ,POS,'+convert(varchar,@UserId)+',GETDATE()
		from #BatchInfoFields 
		union all
		select  '+convert(varchar,@BatchId)+',pageNo,@ServiceIdAdmitDt  ,AdmitDt,'+convert(varchar,@UserId)+',GETDATE()
		from #BatchInfoFields 
		union all
		select  '+convert(varchar,@BatchId)+',pageNo,@ServiceIdPeromingDoc  ,PeromingDoc,'+convert(varchar,@UserId)+',GETDATE()
		from #BatchInfoFields    
		'
		exec(@Query)  
  end  
 End



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kGreen_pAutoBatchImport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kGreen_pAutoBatchImport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kGreen_pAutoBatchImport] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kGreen_pAutoBatchImport] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kGreen_pAutoBatchImport] TO [DB_DMLSupport]
    AS [dbo];

