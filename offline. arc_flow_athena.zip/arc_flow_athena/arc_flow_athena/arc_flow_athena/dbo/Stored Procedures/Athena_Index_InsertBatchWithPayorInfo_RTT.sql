﻿    /*Add Payer Id*/  
CREATE  Proc Athena_Index_InsertBatchWithPayorInfo_RTT (                     
@BatchNo varchar(30)='',@PayorServiceId int=0,@ScanDate Date=NULL,@ntusername varchar(100)=''   )              
as                      
Begin                    
INSERT INTO Athena_Index_BatchWithPayorInfo(BatchNo,PayorServiceId,ScanDate,ntusername,CreatedDate)Values(@BatchNo,@PayorServiceId,@ScanDate,@ntusername,GETDATE())
  
Update ARC_Flow_Athena..TRN_kOFF_tBatches set PayerId=@PayorServiceId where BatchNo=@BatchNo     
                    
End  

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_InsertBatchWithPayorInfo_RTT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_InsertBatchWithPayorInfo_RTT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_InsertBatchWithPayorInfo_RTT] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_InsertBatchWithPayorInfo_RTT] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_InsertBatchWithPayorInfo_RTT] TO [DB_DMLSupport]
    AS [dbo];

