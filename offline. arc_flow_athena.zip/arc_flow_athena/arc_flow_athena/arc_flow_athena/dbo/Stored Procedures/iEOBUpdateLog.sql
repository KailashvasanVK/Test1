﻿Create Proc iEOBUpdateLog 
@Batchno varchar(30)  
/*  
CreatedBy:Noor  
CreatedDate : Nov 23,2017  
Purpose : Update output Log Detail  
*/  
as  
BEGIN
IF(SELECT count(id) FROM iEOB_PdfOCRTracker(nolock) WHERE Batchno=@Batchno)>0
BEGIN
Update iEOB_PdfOCRTracker set Outputs=1,OutputsDate=getdate() where batchno=@Batchno
END
END

GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOBUpdateLog] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[iEOBUpdateLog] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOBUpdateLog] TO [DB_DMLSupport]
    AS [dbo];

