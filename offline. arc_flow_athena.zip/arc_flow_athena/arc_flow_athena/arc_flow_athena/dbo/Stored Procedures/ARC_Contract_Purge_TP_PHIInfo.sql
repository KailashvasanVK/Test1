create Proc ARC_Contract_Purge_TP_PHIInfo   
as  
begin  
   
declare @qry varchar(max)='',@CustomerID int,@CmpKey varchar(10),@PurgeDays int  
declare @PurgeTillDate date  
Declare curTran Cursor for   
select a.customerid,a.cmpkey,b.RetentionDays from [ARC_FLOW].[dbo].ADM_Customer (nolock) a join  
ARC_REC.dbo.ARC_Contract_Customer_Retention (nolock) b on a.customerid=b.CustomerID and a.status=1  
and b.active=1  
Open curTran  
 while 1=1  
 begin  
  Fetch next from curTran into @CustomerID,@CmpKey,@PurgeDays  
  if @@FETCH_STATUS = -1 break  
    
  set @PurgeTillDate=dateadd(d,-@PurgeDays,getdate())  
    
  if(ISNULL(@CustomerID,0)<>0 and ISNULL(@CmpKey,'')<>'' and ISNULL(@PurgeDays,0)<>0)  
  begin  
    
    
    
  /*Issue Log Information */  
  set @qry='   
  update  [ARC_FLOW].[dbo].TRN_k'+@Cmpkey+'_tBatchIssueLogHistory   
  set Comments=null   where ilog_status=1 and Comments is not null and  
  datediff(d,CreatedDt,GETDATE())>'+CONVERT(varchar,@PurgeDays)+'   
       
  update  [ARC_FLOW].[dbo].TRN_k'+@Cmpkey+'_tBatchIssueLogMirror   
  set Comments=null   where ilog_status=1 and Comments is not null and  
  datediff(d,CreatedDt,GETDATE())>'+CONVERT(varchar,@PurgeDays)+'  
   
  update  [ARC_FLOW].[dbo].TRN_k'+@Cmpkey+'_tBatchFlow   
  set Comments=null   where    Comments is not null and 
  datediff(d,CreatedDt,GETDATE())>'+CONVERT(varchar,@PurgeDays)+'  
   
  update  [ARC_FLOW].[dbo].TRN_k'+@Cmpkey+'_tBatchQCComments   
  set Comments=null   where  Comments is not null and  
  datediff(d,CreatedDt,GETDATE())>'+CONVERT(varchar,@PurgeDays)+'  
     
  update  [ARC_FLOW].[dbo].TRN_k'+@Cmpkey+'_tBatchQCTran   
  set ErrNotes=null   where  ErrNotes is not null and  
  datediff(d,CreatedDt,GETDATE())>'+CONVERT(varchar,@PurgeDays)+'  
  update  [ARC_FLOW].[dbo].TRN_k'+@Cmpkey+'_tBatchQueue set Comment=null   where   
  datediff(d,CreatedDt,GETDATE())>'+CONVERT(varchar,@PurgeDays)+''  
  
  exec(@qry)  
    
  /* Purge Issuelog fields */  
  set @qry='update  BI   set  bi.ILogFieldValue=null  FROM  [ARC_FLOW].[dbo].TRN_k'+@Cmpkey+'_tBatchIssueFields BI   
  join  [ARC_FLOW].[dbo].ADM_IssuelogField  A on BI.ILogFieldId=a.FieldId   
  join [ARC_FLOW].[dbo]. ADM_Customer c on c.CustomerId=a.CustomerId  
  join  [ARC_FLOW].[dbo].TRN_k'+@Cmpkey+'_tBatchIssueLog BIL on BIL.ILogId=BI.ILogId  
  where a.PHIStatus=1 and  bi.ILogFieldValue is not null and  PurgeData=1 and isnull(A.Comments,'''')=''''  and a.Status=1 and BIL.Status=1 and  BIL.ILog_Status in (2,4,10)   
  and  not exists (Select 1 from [ARC_FLOW].dbo.ADM_ILogException  Where CustomerId = '  
  +CONVERT(varchar,@CustomerId)+' and BIL.ILogClassifyId = ILogClassifyId)  
  and datediff(d,BIL.CreatedDt,GETDATE())>'+CONVERT(varchar,@PurgeDays)+''  
  exec(@qry)   
  
  /*QC feedback associate view/QC feedback TL Acknowledgement Report & view */  
  set @qry='   
  update  [ARC_FLOW].[dbo].TRN_k'+@Cmpkey+'_tBatchQCComments set Comments=null  where  
  Comments is not null and   
  datediff(d,CreatedDt,GETDATE())>'+CONVERT(varchar,@PurgeDays)+''  
  exec(@qry)  
  
  /* Feedback Report */  
  update feedreq set  AHSIncorrectNote=null,Ticket=null,  
  ClinicCode=null,ClientComments=null,IncorrectActionTaken=null, ActiontobeTaken =null   
  from  [ARC_FLOW].[dbo].ADM_FeedbackRequest  feedreq       
  where  feedreq.CustomerId =@CustomerID  and  ( Ticket is not null or AHSIncorrectNote is not null or ClientComments is not null)
  and  datediff(d,CreatedDt,GETDATE())>@PurgeDays  
  
  update feedres set feedres.AHSComments=null, feedres.CorrectiveAction=null , feedres.PreventiveAction=null   
  from  [ARC_FLOW].[dbo].ADM_FeedbackResponse feedres join    
  [ARC_FLOW].[dbo].ADM_FeedbackRequest  feedreq    
  on feedres.FeedbackId = feedreq.FeedbackId  
  where feedreq.CustomerId =@CustomerID  and   ( feedres.AHSComments is not null or  feedres.CorrectiveAction is not null  or feedres.PreventiveAction is not null) and 
  datediff(d,feedreq.CreatedDt,GETDATE())>@PurgeDays  
    
  insert into TRN_PHI_Purge_Activity_Details(customerid,DataSource,Process,PurgeDate,PurgeTillDate,Status)  
  select @CustomerID,'TP',LOB,GetDate(),@PurgeTillDate,'Completed' from(  
  select distinct case when functionalityid=1 then 'Billing' when functionalityid=2  then 'Coding' else '' end as LOB  
  from arc_flow..adm_customerservices (nolock) where customerid=@CustomerID   
  ) a where LOB<>''  
    
    
  end  
  end  
    
Close curTran  
DeAllocate curTran  
end  
  
  

