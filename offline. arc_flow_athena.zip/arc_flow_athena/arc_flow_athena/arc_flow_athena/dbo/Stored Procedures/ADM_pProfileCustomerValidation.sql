﻿

/*START CustomerPriority */

CREATE Procedure ADM_pProfileCustomerValidation   
(  
	@UserId int = 0 , 
	@UserIdCollection varchar(max) = '2776,1' 
) 
As 
-- exec ADM_pProfileCustomerValidation @action = 'VerifyCustomer',@Customerid =0,@UserIdCollection = '2776,1973,1'
 --exec ADM_pProfileCustomerValidation @action = 'VerifyCustomer',@Customerid =0,@UserIdCollection = '690,1451'
 
Begin 
	/*
		Createddby  : Kathiravan.kand
		CreatedDt : 01/28/2015
		Purpose   : Validate the customer Details for the Selected Users
	*/ 
Declare @ErrMsg varchar(max) 
 
  
	if OBJECT_ID('tempdb..#SelectedUsersInfo') is not null drop table #SelectedUsersInfo 
	Create Table #SelectedUsersInfo(NtName varchar(75),UserId int,CustomerId int) 
	
	Insert into #SelectedUsersInfo(NtName,UserId,CustomerId) 
	Select ui.NT_USERNAME,users.items as UserId,isnull(userCus.CustomerID,0) as CustomerId 
	from dbo.fnSplitString(@UserIdCollection,',') as users  
	inner join ARC_REC_Athena..ARC_REC_USER_INFO as ui on ui.USERID = convert(int,users.items) 
	left join ARC_REC_Athena..ARC_REC_UserCustomer as userCus on userCus.UserId = convert(int,users.items) 
 --Customer availability check 
 if (Select count(*) from #SelectedUsersInfo Where CustomerId = 0)>0 
	Begin  
		Set @ErrMsg = 'Customer allocation missing for mentioned associates. Please contact HR team. </br>' + STUFF((Select ',' + ntName 
		from #SelectedUsersInfo Where CustomerId = 0 for xml path('')),1,1,'')  
	End 
 --users in conflicting customer names 
 else if (Select COUNT(*) as CustomersCnt from ( 
	  Select Customers 
	  From 
		 ( 
			 Select UserId 
			 ,(select ',' + Convert(varchar,CustomerId) from #SelectedUsersInfo where UserId = us.UserId for XML path('')) as Customers 
			 from #SelectedUsersInfo as us 
			 ) x group by Customers 
		 ) y 
	 ) > 1 
 Begin 
	Set @ErrMsg = 'Customer conflict. Selected users should have same customers' 
 End 
  
 drop table #SelectedUsersInfo 
	Select isnull(@ErrMsg,'') as Result 
 
End 

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pProfileCustomerValidation] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pProfileCustomerValidation] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pProfileCustomerValidation] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pProfileCustomerValidation] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pProfileCustomerValidation] TO [DB_DMLSupport]
    AS [dbo];

