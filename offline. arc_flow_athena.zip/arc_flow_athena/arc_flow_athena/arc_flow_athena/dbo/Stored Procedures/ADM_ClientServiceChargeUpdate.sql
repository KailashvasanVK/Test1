﻿CREATE Procedure [dbo].[ADM_ClientServiceChargeUpdate]      
      @ClientId int,      
      @ServiceId int,      
      @Price decimal(9,2),      
      @UpdateBy int      
As      
Begin  
/*                
Purpose           : To Update Charge of Client's Services  
Created By        : Bhuvaneswari                
Created Date      : 1 Apr 2013                
Impact to         : ClientsServiceConfiguration.aspx               
*/        

insert into ADM_ClientServicePrice (ClientId,ServiceId,Price,CreatedBy,CreatedDt)
select @ClientId,@ServiceId,@Price,@UpdateBy,GETDATE()
       
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ClientServiceChargeUpdate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ClientServiceChargeUpdate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ClientServiceChargeUpdate] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ClientServiceChargeUpdate] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ClientServiceChargeUpdate] TO [DB_DMLSupport]
    AS [dbo];

