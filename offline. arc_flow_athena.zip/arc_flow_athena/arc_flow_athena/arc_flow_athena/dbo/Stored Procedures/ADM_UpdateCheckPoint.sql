﻿CREATE Procedure ADM_UpdateCheckPoint        
      @CmpKey varchar(20),        
      @Userid int,        
      @ServiceId int,        
      @PTLevelId int,      
      @QCLevelId int,      
      @QALevelId int,    
      @CreatedBy int    
            
           
As        
Begin        
	declare @CustomerId as int      
	declare @ProcessEffectiveFrom as date    
	declare @QCEffectiveFrom as date    
	select @CustomerId = CustomerId from ADM_Customer where CmpKey = @CmpKey      
	select @ProcessEffectiveFrom = EffectiveFrom from ADM_AccessTarget where CustomerId = @CustomerId and userid = @Userid and ServiceId = @ServiceId       
	select @QCEffectiveFrom = EffectiveFrom from ADM_AccessTargetQC where CustomerId = @CustomerId and userid = @Userid and ServiceId = @ServiceId       
     
 IF(@ProcessEffectiveFrom = CAST(getdate() as DATE) and (select COUNT(*) from ADM_AccessTargetTran where CustomerId = @CustomerId and userid = @Userid and ServiceId = @ServiceId ) > 0)    
	 begin     
	 update ADM_AccessTarget set
		QCLevelId = @QCLevelId
		where CustomerId = @CustomerId and userid = @Userid and ServiceId = @ServiceId and EffectiveFrom = GETDATE()
		--RaisError ('Checkpoint setup cannot be set twice a day',16,1)    
		--return     
	 end    
 ELSE  
	 begin  
		insert into ADM_AccessTargetTran(AccTargetId,userid,CustomerId,ServiceId,ProcessTargetId,QcTargetId,PTLevelId,    
		QCLevelId,CreatedBy,CreatedDt,EffectiveFrom,EffectiveTo,ErrorPercentage)    

		select AccTargetId,userid,CustomerId,ServiceId,ProcessTargetId,QcTargetId,    
		PTLevelId,QCLevelId,@CreatedBy,GETDATE(),@ProcessEffectiveFrom,DATEADD(dd,-1,GETDATE()),ErrorPercentage    
		from ADM_AccessTarget where CustomerId = @CustomerId and userid = @Userid and ServiceId = @ServiceId       

		/*update ADM_AccessTarget set        
		PTLevelId = @PTLevelId,QCLevelId = @QCLevelId,EffectiveFrom = GETDATE()      
		where CustomerId = @CustomerId and userid = @Userid and ServiceId = @ServiceId 
		*/
		update ADM_AccessTarget set
		QCLevelId = @QCLevelId,EffectiveFrom = GETDATE()
		where CustomerId = @CustomerId and userid = @Userid and ServiceId = @ServiceId       
	 end        
	/*if(@QCEffectiveFrom = CAST(getdate() as DATE) and (select COUNT(*) from ADM_AccessTargetQCTran where CustomerId = @CustomerId and userid = @Userid and ServiceId = @ServiceId ) > 0)    
		begin  
			RaisError ('Checkpoint setup cannot be set twice a day',16,1)    
			return     
		end    
	else  
		begin  
			insert into ADM_AccessTargetQCTran(AccTargetId,Userid,CustomerId,ServiceId,QualityTargetId,QALevelId  
			,CreatedBy,CreatedDt,EffectiveFrom,EffectiveTo)    

			select AccTargetId,userid,CustomerId,ServiceId,QualityTargetId,QALevelId,@CreatedBy,GETDATE(),  
			@QCEffectiveFrom,DATEADD(dd,-1,GETDATE())    
			from ADM_AccessTargetQC where CustomerId = @CustomerId and userid = @Userid and ServiceId = @ServiceId       

			update ADM_AccessTargetQC set        
			QALevelId = @QALevelId,EffectiveFrom = GETDATE()      
			where CustomerId = @CustomerId and userid = @Userid and ServiceId = @ServiceId        
		end  
	*/	   
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_UpdateCheckPoint] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_UpdateCheckPoint] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_UpdateCheckPoint] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_UpdateCheckPoint] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_UpdateCheckPoint] TO [DB_DMLSupport]
    AS [dbo];

