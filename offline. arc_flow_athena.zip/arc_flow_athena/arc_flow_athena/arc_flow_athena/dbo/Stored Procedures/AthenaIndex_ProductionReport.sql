﻿CREATE PROC AthenaIndex_ProductionReport        
@gDate datetime=NULL        
as        
BEGIN        
/*SELECT batchnum,userinfo,Case cstatus when 0 then 'InComplete' when 1 then 'Completed' End as Status
 FROM batchIndex_TrackBatches WHERE CONVERT(varchar,CompletedDate,103)=convert(varchar,@gDate,103)     
Union       
SELECT batchnum,userinfo,Case cstatus when 0 then 'InComplete' when 1 then 'Completed' End as Status 
FROM batchIndex_TrackBatches WHERE CompletedDate is null    

below scrip is Modified by Udhai - to avoid deadlock.
*/
SELECT batchnum,userinfo,Case cstatus when 0 then 'InComplete' when 1 then 'Completed' End as Status FROM
batchIndex_TrackBatches (updlock) WHERE CONVERT(date,CompletedDate)=@gDate     
union
SELECT batchnum,userinfo,Case cstatus when 0 then 'InComplete' when 1 then 'Completed' End as Status
FROM batchIndex_TrackBatches (updlock)  WHERE CompletedDate is null    
 
       
END


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AthenaIndex_ProductionReport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AthenaIndex_ProductionReport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AthenaIndex_ProductionReport] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AthenaIndex_ProductionReport] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AthenaIndex_ProductionReport] TO [DB_DMLSupport]
    AS [dbo];

