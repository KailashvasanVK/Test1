﻿CREATE Proc Checkbatchstatus (@batchnum varchar(20))    
as    
Declare @BatchProcessId int    
Select @BatchProcessId=BatchProcessId From TRN_kOFF_tBatchQueue where BatchNo=@batchnum    
    
select tbf.*,sts.StatusDescription  from TRN_kOFF_tBatchFlow tbF     
inner join ADM_BatchStatusMaster sts     
on tbf.StatusId=sts.StatusId  where BatchProcessId=@BatchProcessId    
    
select trans.*,ads.ServiceName  from TRN_kOFF_tBatchTransact trans inner join ADM_Service ads    
on trans.ServiceId =ads.ServiceId     
where BatchProcessId=@BatchProcessId    
    
select qc.*,ads.ServiceName from TRN_kOFF_tBatchQCMaster qc    
inner join ADM_Service ads    
on qc.ServiceId =ads.ServiceId     
where BatchProcessId=@BatchProcessId    
    
    
select * from TRN_kOFF_tBatchTransactMirror where BatchProcessId=@BatchProcessId    
    
select * from TRN_kOFF_tBatchQCMaster where BatchProcessId=@BatchProcessId    
select * from TRN_kOFF_tBatchQCComments where BatchProcessId =@BatchProcessId  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Checkbatchstatus] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Checkbatchstatus] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Checkbatchstatus] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Checkbatchstatus] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Checkbatchstatus] TO [DB_DMLSupport]
    AS [dbo];

