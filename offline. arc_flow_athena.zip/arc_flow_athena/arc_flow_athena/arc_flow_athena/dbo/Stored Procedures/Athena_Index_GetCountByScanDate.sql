﻿CREATE Proc Athena_Index_GetCountByScanDate        
AS        
select ScanDate,COUNT(batchid) as Pending from TRN_kOFF_tBatches(nolock) where status=3  and ServiceId<>363      
group by scandate order by ScanDate asc 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_GetCountByScanDate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_GetCountByScanDate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_GetCountByScanDate] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_GetCountByScanDate] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_GetCountByScanDate] TO [DB_DMLSupport]
    AS [dbo];

