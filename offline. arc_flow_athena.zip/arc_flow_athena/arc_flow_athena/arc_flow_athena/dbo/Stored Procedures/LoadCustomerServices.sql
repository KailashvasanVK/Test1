﻿
Create Procedure [dbo].[LoadCustomerServices]  
(  
@CustomerId int,  
@UserId int,
@ServiceIds varchar(max)=null
)  
As  
Begin  
 if ISNULL(@ServiceIds,'')=''
 Begin
 
	Select ser.ServiceId,ser.ServiceName from ADM_CustomerServices aser  
	inner join ADM_Service ser on ser.ServiceId=aser.ServiceId  
	where CustomerId = @CustomerId/* and UserId=@UserId  */
 /*
	 Select ser.ServiceId,ser.ServiceName from ADM_AccessServices aser  
	 inner join ADM_Service ser on ser.ServiceId=aser.ServiceId  
	 where CustomerId = @CustomerId and UserId=@UserId  
	 */
	 --and exists (select 1 from ADM_ServiceGroup sg where sg.ServiceGroupId=aser.ServiceId)  
 End
 Else 
 Begin
    if OBJECT_ID('tempdb..#ServiceIds') is not null drop table #ServiceIds
    Select items as ServiceId into #ServiceIds from dbo.fnSplitString(@ServiceIds,',')
    
    Select ser.ServiceId,ser.ServiceName from ADM_Service ser  
	inner join #ServiceIds tmp on ser.ServiceId=tmp.ServiceId  	 
 End
End

GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[LoadCustomerServices] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[LoadCustomerServices] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[LoadCustomerServices] TO [DB_DMLSupport]
    AS [dbo];

