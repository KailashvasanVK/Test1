﻿CREATE  Procedure ADM_pGetUserUserFunctionality
@UseridCollection  varchar(max) = ''
As
/*,
Created by : Karthik M7
Created on : 20 FEB 2015.
Modified by : Kathiravan.kand
*/

-- Purpose : To get functionality details for the user --
Begin
		if OBJECT_ID('tempdb..#UsersList') is not null  drop table #UsersList
		CREATE TABLE #UsersList(Id INT IDENTITY(1,1), UserId INT,Func varchar(10))   
		INSERT INTO #UsersList (UserId)
		SELECT items FROM [dbo].[fnSplitString] (@UseridCollection, ',')
		
		
		
			--Select  Functionality  from ADM_AccessFunctionality  where UserId in (select UserId from #UsersList)
			--and Functionality in ('A','P')
			DECLARE @listStr VARCHAR(MAX)
			
			if	((select COUNT(Id) from  #UsersList) < 2 )
			BEGIN
			
				
			
				Select @listStr = COALESCE(@listStr+',' ,'') +Functionality    from ADM_AccessFunctionality
				where UserId in (select UserId from #UsersList)
				and Functionality in ('A','P')
				select @listStr
			
			END		
			else
			BEGIN
				
				update #UsersList set Func = (SELECT  STUFF(( SELECT ',' + Functionality  FROM ADM_AccessFunctionality where  UserId = #UsersList.UserId FOR  XML PATH('')  ), 1, 1, ''))
				
					if ((select count(distinct Func) from #UsersList)> 1 )
				BEGIN
					select  0 
				END
				ELSE
				BEGIN
					Select @listStr = COALESCE(@listStr+',' ,'') +Functionality    from ADM_AccessFunctionality
					where UserId =   (select top 1 UserId from #UsersList)
					and Functionality in ('A','P')
					select @listStr
					
					
				END
				
				
			END
			
			
			
			
			if OBJECT_ID('tempdb..#UsersList') is not null  drop table #UsersList
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pGetUserUserFunctionality] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pGetUserUserFunctionality] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pGetUserUserFunctionality] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pGetUserUserFunctionality] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pGetUserUserFunctionality] TO [DB_DMLSupport]
    AS [dbo];

