﻿CREATE procedure iEOBMerge_pExcludeFromMerge  (@scandate varchar(10))                   
as                                 
begin        
    
    
/*                              
                          
Cretaed By     : Leela.T                          
Created Date   : 2017-11-16                       
Purpose        : Release the batches in Merge  which is not Merged                  
Ticket/SCR ID  :                          
TL Verified By :        
    
*/    
          
Declare @qury varchar(Max)     
set @scandate=convert(varchar,@Scandate,101)
     
if(object_id('tempdb.dbo.#BatchDetails')is not null) drop table #BatchDetails                       
create table #BatchDetails(BatchNo  varchar(50))                                                                                                                                                                                                                                           
   
    
set @qury='Insert into #BatchDetails                                                       
select trn.BatchNo from trn_koff_tbatches(nolock) trn             
inner join trn_koff_tbatchqueue (nolock) bq on trn.batchno=bq.batchno       
inner join Arc_Athena..Batchmaster (nolock) bat on bat.batchnum=trn.batchno       
inner join arc_athena..iEOB_tAutomationBatchQueue(nolock) tque on tque.batchno=bat.Batchnum  and tque.statusid=5    
inner join arc_athena..iEOB_tAutoIdentifyTemplate ttemp on ttemp.BatchNo = tque.BatchNo       
left join mergebatchdetails (nolock) mrg on trn.batchno=mrg.childbatchno       
left join TRN_kOFF_tBatchResetLog Rp on RP.batchno= trn.batchno                
where trn.status=88 and trn.posteddt is null  and  bq.assigned=0                       
and bq.statusid=0 and  trn.UploadDt is null and left(trn.batchno,1) not in (''M'',''S'') and mrg.childbatchno is null                          
and bat.ULStatus is null and bat.uploaddate is null and PgCount between 2 and 20 and RP.batchno is null and trn.serviceid = 452 '                 
    
if @scandate <>''                                                       
Set @qury += ' and convert(varchar,trn.scandate,101) = '''+@scandate+''''                                                   

exec (@qury)                
          
set @qury=''      
    
update arc_athena..iEOB_tAutomationBatchQueue set statusid=7 where BatchNo in (Select Batchno from  #BatchDetails)    
insert into ARC_Athena..iEOB_tAutomationBatchFlow                                                     
select BatchId,BatchProcessId,7,'ExcludeMergequeue',1111,getdate() from  arc_athena..iEOB_tAutomationBatchQueue 
where batchno in (Select Batchno from  #BatchDetails)           
drop table #BatchDetails

End

GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOBMerge_pExcludeFromMerge] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[iEOBMerge_pExcludeFromMerge] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOBMerge_pExcludeFromMerge] TO [DB_DMLSupport]
    AS [dbo];

