﻿CREATE Procedure [dbo].[AccessCustomer]
@UserId int
as
/*
Created By  : Karthik Ic
Purpose     : To get the customer list based on the userid.
Exec  AccessCustomer 3
*/
Begin
Select Ac.CustomerId as CustomerId, ac.InternalName CustomerName from ARC_FLOW_Athena..ADM_Customer  AC
inner join  ARC_REC_Athena..ARC_REC_UserCustomer  ARUC on AC.CustomerId = ARUC.CustomerID  and ARUC.UserId  = @UserId
Where isnull(CmpKey,'') <> ''
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AccessCustomer] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AccessCustomer] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AccessCustomer] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AccessCustomer] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AccessCustomer] TO [DB_DMLSupport]
    AS [dbo];

