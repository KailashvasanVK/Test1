﻿Create Proc MergeReport_SP
as
select case when serviceid=355 then 'Payer1 Merge' else 'Payer3 Merge'  end as 'Merge',scandate , count(distinct parentbatchno) as 'MCount',count(distinct Childbatchno) as 'ChildCnt'
,sum(createdptncnt)+sum(paymentinscnt)+sum(exceptioncnt)+sum(ptnpostingcnt)+sum(colpostingcnt) as 'TransactionCount'
 from arc_flow_athena..mergebatchdetails (nolock) a
inner join arc_flow_athena..trn_koff_tbatches (nolock) b on a.childbatchno=b.batchno
inner join arc_athena..batchloginformation (nolock) c on c.batchnum=b.batchno
group by scandate,serviceid
order by scandate desc
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[MergeReport_SP] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MergeReport_SP] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MergeReport_SP] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[MergeReport_SP] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MergeReport_SP] TO [DB_DMLSupport]
    AS [dbo];

