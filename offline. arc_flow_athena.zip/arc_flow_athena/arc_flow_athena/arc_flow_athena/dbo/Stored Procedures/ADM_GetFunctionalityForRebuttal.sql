﻿CREATE Procedure ADM_GetFunctionalityForRebuttal
(
@Cmpkey varchar(5),
@UserId int
)
As
begin
/*
   Created By  : kathiravan.kand
   CreteatedDt : 01/23/2015
   Purpose     : get active functinalirt list 
*/

 Declare @DefualtFunctionality int
 Select @DefualtFunctionality=FUNCTIONALITY_ID from ARC_REC..ARC_REC_USER_INFO where USERID=@UserId 
 Declare @query varchar(max)
 Set @query='
    Select distinct  FunctionalityId,FunctionName, '+CONVERT(varchar,@DefualtFunctionality)+' as DefaultFunctionality 
    from TRn_k'+@Cmpkey+'_tbatcherrorrebuttalFlow flow
    inner join ARC_REC_ATHENA..ARC_REC_USER_INFO usr on flow.CreatedBy=usr.USERID
    inner join ARC_REC_ATHENA..HR_Functionality fun on fun.FunctionalityId=usr.FUNCTIONALITY_ID
    '
	/*select FunctionalityId,FunctionName from ARC_REC..HR_Functionality  where Status =1 */
	 Exec(@query)
End


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetFunctionalityForRebuttal] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_GetFunctionalityForRebuttal] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetFunctionalityForRebuttal] TO [DB_DMLSupport]
    AS [dbo];

