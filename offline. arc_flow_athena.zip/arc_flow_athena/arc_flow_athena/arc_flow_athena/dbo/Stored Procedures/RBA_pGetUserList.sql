﻿Create Procedure [dbo].[RBA_pGetUserList]    
(    
 @UserId varchar(100),  
 @CustomerId int  
)    
As     
Begin         

select userinfo.userid as FlowUserId,userinfo.nt_username as UserName
from arc_rec..DirectReports (nolock) recdr
join arc_rec_athena..arc_rec_user_info (nolock) sup on sup.nt_username=recdr.parent
join arc_rec_athena..arc_rec_user_info (nolock) userinfo on userinfo.nt_username=recdr.username
where sup.userid=@userID
and userinfo.active=1
order by recdr.level
End   

GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RBA_pGetUserList] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[RBA_pGetUserList] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[RBA_pGetUserList] TO [DB_DMLSupport]
    AS [dbo];

