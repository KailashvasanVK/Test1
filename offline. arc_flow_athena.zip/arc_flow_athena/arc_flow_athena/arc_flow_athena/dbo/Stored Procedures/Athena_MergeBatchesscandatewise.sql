﻿CREATE PROCEDURE Athena_MergeBatchesscandatewise(       
@scandate varchar(10)=null ,      
@Minpagecount varchar(5)=null      
,@Maxpagecount int,      
@serviceid varchar(10)=null ,@Percentlvl int )      
as                             
begin       
/*          
      
Cretaed By     : Leela.T      
Created Date   : 2015-03-09         
Purpose        : Batches are Logically Merged       
Ticket/SCR ID  : <>      
TL Verified By : <Ramki>      
      
Mod ID          :001      
Request Type    : Process improvement by IT>      
Purpose         : Merge process will only refer Chennai FTP server. Previously few batches were referring CBE.      
TL Verified By  : Ramakrishnan.G      
    
Mod ID          :002     
Modified by     : Leela.T    
Modified date   :2016-10-25      
Request Type    : Restrict Single Page Batch for Merge    
TL Verified By  : Ramakrishnan.G    

Mod ID          : 003   
Modified by     : Leela.T    
Modified date   : 2017-11-24      
Request Type    : Restrict the held batches
TL Verified By  :       
      
      
      
Implemented by : Udhayaganesh      
Implemented On : 19-04-2014      
      
Reviewd by     : Udhayaganesh      
Implemented On : 19-04-2014      
      
*/      
      
      
Declare @BatchCount int,@ParentBatchid int ,                            
@ParentBatchNo varchar(30),@Batchclientid int,@count int=0,@pgcount int,                            
@Chk int=0,@StartPgNo int, @EndPgNo int,@Fname varchar(300)                            
,@dollaramt money ,@BatchNo varchar(50), @qury nvarchar(Max) ,@Batchclinetid int                            
      
      
      
if(object_id('tempdb.dbo.#BatchCountDetails')is not null)                      
drop table #BatchCountDetails          
      
create table #BatchCountDetails                                                              
(                                                                                                                                                                                                         
BatchCount    int                                                                                                                                                                                                                                              


)                             
      
      
if(object_id('tempdb.dbo.#MergeBatchDetails')is not null)                      
drop table #MergeBatchDetails          
create table #MergeBatchDetails                                                        
(                                                                    
BatchNo   Varchar(15),                                                                                                                                                
PageCount   int,                                                            
Fname varchar(300) ,                                                      
status int,                                      
dollarAmt Money                                                       
)                              
      
set @qury='insert into #BatchCountDetails                            
select count(a.batchno) from trn_koff_tbatches a inner join ARC_Athena..batchMaster b on a.BatchNo=b.batchnum                               
Inner join TRN_kOFF_tBatchQueue bq on a.batchno=bq.batchno 
left join trn_koff_theldBatches hld on hld.Batchid=a.batchid
where bq.BatchNo not in (select ChildBatchNo from mergebatchdetails)                            
and status=1 and  bq.assigned=0 and bq.statusid=0 and a.postedDt is null and a.UploadDt is  null  and b.ULStatus is null and                             
a.ClientID not in (select Clientid from ExcludeFormerge) and  ( hld.Batchid is null or hld.ReleaseDate is not null) and  PgCount <>1 and '                        
set @qury+='PgCount <= cast('''+@Minpagecount+'''as int)'                            
      
if @scandate <>''                                              
      
Set @qury += ' and convert(varchar,scandate,101) = '''+@scandate+''''                             
      
if @serviceid <>''                                              
      
Set @qury += ' and a.serviceid = cast('''+@serviceid+'''as int) '                                
      
exec (@qury)                
  
set @qury=''                              
      
select @BatchCount=Batchcount from #BatchCountDetails                            
if(@batchcount<20)              
begin               
return              
End                       
      
      
select @BatchCount=@BatchCount- ROUND(((@batchcount*@Percentlvl)/100),0)                              
      
      
set @qury='update TRN_kOFF_tBatches set status=99 where BatchNo in (                                                     
select top '+ CONVERT(VARCHAR,@BatchCount) +' a.batchno from TRN_kOFF_tBatches a                  
Inner join TRN_kOFF_tBatchQueue bq on a.batchno=bq.batchno                     
inner join ARC_Athena..batchMaster b on a.BatchNo=b.batchnum 
left join trn_koff_theldBatches hld on hld.Batchid=a.batchid                     
where  a.BatchNo not in (select ChildBatchNo from mergebatchdetails)   and ( hld.Batchid is null or hld.ReleaseDate is not null)              
and status=1 and bq.assigned=0 and bq.statusid=0 and a.postedDt is null and a.UploadDt is null  and b.ULStatus is null and                                             
a.ClientID not in (select Clientid from ExcludeFormerge) and  a.PgCount <>1 and '             
      
set @qury+=' a.PgCount <= cast('''+@Minpagecount+'''as int)'                                                 
      
if @scandate <>''                                              
      
Set @qury += ' and convert(varchar,scandate,101) = '''+@scandate+''''                                               
      
if @serviceid <>''                               
Set @qury += ' and a.serviceid = cast('''+@serviceid+'''as int) '                                                 
      
      
set @qury+=') and ClientID not in (select Clientid from ExcludeFormerge) '                              
      
exec (@qury)                            
      
set @qury=''                                             
      
      
insert into Athena_ChildBatchgeneration                             
select MAX(Batchid)+1 from athena_childBatchGeneration                            
      
select @Batchclientid=MAX(Batchid) from athena_childBatchGeneration                            
      
INSERT INTO Athena_ParentBatchGeneration(ParentBatch) values (Convert(varchar(10),@Batchclientid) )                                                                    
set @ParentBatchid = SCOPE_IDENTITY()                                                                    
set @ParentBatchNo='S' + Convert(varchar(10),@ParentBatchid) + 'A1'                                                 
      
      
delete from #MergeBatchDetails                                                                    
      
insert into #MergeBatchDetails(batchno , pagecount,Fname,status,dollarAmt)                              
select batchno,pgcount,'\\fs-ib'+SUBSTRING(Fname,CHARINDEX('\',Fname,3),LEN(Fname)),0,b.dollarAmt from trn_koff_tbatches a     
inner join Arc_Athena..batchMaster b                                  
on a.BatchNo=b.batchnum where BatchNo not in (select ChildBatchNo from mergebatchdetails)      
and convert(varchar,ScanDate,101)=convert(varchar,@scandate,101)                                   
and status=99  and ServiceId=cast(@serviceid as int)                              
      
      
declare @CurMergeBatch cursor                                                                        
set  @CurMergeBatch  = cursor fast_forward for                           
        
select batchno, pagecount,Fname,dollaramt from #MergeBatchDetails where status=0                                                                     
           
open  @CurMergeBatch                                                                                                                                              
                                                                         
fetch next from @CurMergeBatch into                                                                   
@BatchNo,@PgCount ,@Fname,@dollaramt                                                                   
      
while(@@fetch_status<>-1)                                                                     
Begin                                    
      
set @count=@count+@pgcount                                                                                    
      
if(@Count>=@Maxpagecount)                              
begin                                                                
Set @Count=0                                                                
Set @Chk=0                                                        
select @Count=SUM(pagecount) from #MergeBatchDetails where status=0                                               
                                                    
if(@Count<40)               
begin                                                  
      
update TRN_kOFF_tBatches set status=1 where BatchNo in(                     
select BatchNo from #MergeBatchDetails where status=0)                                                
      
Goto NextSubClient                                                    
      
End                             
      
      
set @count=0                                                
set @count=@count+@pgcount                                                                    
      
      
insert into Athena_ChildBatchgeneration                             
select MAX(Batchid)+1 from athena_childBatchGeneration                            
      
select @Batchclientid=MAX(Batchid) from athena_childBatchGeneration                            
      
INSERT INTO Athena_ParentBatchGeneration(ParentBatch) values (Convert(varchar(10),@Batchclientid) )                                                                    
set @ParentBatchid = SCOPE_IDENTITY()                                                                    
set @ParentBatchNo='S' + Convert(varchar(10),@ParentBatchid) + 'A1'                                                                   
              
      
if (@Chk=0)                                                                
begin                                                                
Set @Chk=1                                                                
set @StartPgNo=1                                                                
set @EndPgNo=@PgCount                                                                
End                                                                
      
else                                                                
begin                                  
set @StartPgNo=@EndPgNo+1                                                                
set @EndPgNo= @startpgno + (@PgCount-1)                                                                
End                                                               
End                                                                
      
else                                                               
      
begin                             
      
if (@Chk=0)                                                                
begin                                                                
Set @Chk=1                                                 
set @StartPgNo=1 
set @EndPgNo=@PgCount    
End                              
      
else                               
      
begin                                                               
set @StartPgNo=@EndPgNo+1                                                                
set @EndPgNo= @startpgno + (@PgCount-1)                                                                
End                                                                
      
end                                                            
        
      
INSERT INTO MergeBatchDetails(ParentBatchNo,childBatchNo,StartPgNo,EndpgNo,TotalPages,status,Fname,dollaramt)                                                                
values(@ParentBatchNo,@BatchNo,@StartPgNo,@EndPgNo,@PgCount,1,'\\fs-ib'+SUBSTRING(@Fname,CHARINDEX('\',@Fname,3),LEN(@Fname)),@dollaramt)                                                                   
update #MergeBatchDetails set status=1 where BatchNo=@BatchNo                                                      
      
      
fetch next from @CurMergeBatch  into                                                                   
@BatchNo,@PgCount,@Fname,@dollaramt                             
         
End                 
      
NextSubClient:                              
        
close @CurMergeBatch                                
deallocate @CurMergeBatch                                                    
      
End 

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_MergeBatchesscandatewise] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_MergeBatchesscandatewise] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_MergeBatchesscandatewise] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_MergeBatchesscandatewise] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_MergeBatchesscandatewise] TO [DB_DMLSupport]
    AS [dbo];

