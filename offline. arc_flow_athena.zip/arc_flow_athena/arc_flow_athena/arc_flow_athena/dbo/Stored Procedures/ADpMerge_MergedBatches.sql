﻿CREATE PROC [dbo].[ADpMerge_MergedBatches] ( @UserName varchar(50),@Maxpagecount  int,@scandate date,@ChildBatchno ADPBatchList Readonly )                        
                        
as                            
Begin        
      
/*                              
                          
Cretaed By     : Leela.T                          
Created Date   : 2017-03-29                            
Purpose        : Create the logical merge for the ADP batches                     
Ticket/SCR ID  : 1195                       
TL Verified By : Udhayaganesh                      
                     
Implemented by : Udhdyaganesh.p              
Implemented On : 10-April-2017                
                          
                    
Modified By     : Leela.T                          
Modified Date   : 2017-06-16                            
Purpose         : Need to Change the staus 88 in for Remaining Batches                  
Ticket/SCR ID  :  214357                      
TL Verified By :   
                          
*/                           
                            
Declare                                                          
 @LoopCount int                    
,@Batchclientid int                                                          
,@PgCount int                    
,@batchno varchar(50)                     
,@ParentBatchid int                    
,@StartPgNo int                    
,@EndPgNo int                    
,@Chk int                    
,@ParentBatchNo Varchar(20)                    
,@Count int                    
,@Mergequry nvarchar(1000)                    
,@Fname varchar(300)                    
,@BatchCount int                    
,@dollaramt money                  
                                 
                     
                     
if(object_id('tempdb.dbo.#MergeBatchDetails')is not null)                                          
drop table #MergeBatchDetails                           
create table #MergeBatchDetails                                              
 (                                                          
BatchNo   Varchar(15),                                                                                                                                      
PageCount   int,                                                  
Fname varchar(300) ,                                            
status int,                            
dollarAmt Money                                             
)                             
                
select @BatchCount=count(id) from mergebatchdetails where childbatchno in (select Batchno from @ChildBatchno)                   
                 
 if (@BatchCount<>0)                
 return          
       
       
update ARC_Athena..SemiOcr_tAutomationBatchQueue set StatusId=99  where BatchNo in (select Batchno from @ChildBatchno)          
                 
insert into Athena_ChildBatchgeneration                                                 
select MAX(Batchid)+1 from athena_childBatchGeneration                                                
                          
select @Batchclientid=MAX(Batchid) from athena_childBatchGeneration                                                
                          
INSERT INTO Athena_ParentBatchGeneration(ParentBatch) values (Convert(varchar(10),@Batchclientid) )                                                                                        
set @ParentBatchid = SCOPE_IDENTITY()                                                                                        
set @ParentBatchNo='S' + Convert(varchar(10),@ParentBatchid) + 'A1'                                                                                                  
                                  
                                                       
                                                       
                    
insert into #MergeBatchDetails(batchno , pagecount,Fname,status,dollarAmt)                          
select batchno,pgcount,Replace(Fname,'\\fs-ib','\\fs-cbe') ,0,b.dollarAmt from trn_koff_tbatches a inner join ARC_Athena..batchMaster b                        
on a.BatchNo=b.batchnum where BatchNo in (select Batchno from @ChildBatchno)                            
set @Count=0                                                      
set @Chk=0                                                      
                           
                           
select * from #MergeBatchDetails                                             
                                                 
declare @CurMergeBatch cursor                                                              
set  @CurMergeBatch  = cursor fast_forward for                                                         
                                                        
select batchno, pagecount,Fname,dollaramt from #MergeBatchDetails where status=0                                                           
                                                         
open  @CurMergeBatch                                                                                                                                    
                                                                                                                       
fetch next from @CurMergeBatch into                                                         
@BatchNo,@PgCount ,@Fname,@dollaramt                                                         
                                           
                                                                                                                 
while(@@fetch_status<>-1)                                                           
Begin                                                       
                              
set @count=@count+@pgcount                                                          
                                                    
if(@Count>=@Maxpagecount)                                                       
begin                                                      
Set @Count=0                                                      
Set @Chk=0                                              
select @Count=SUM(pagecount) from #MergeBatchDetails where status=0                                          
                                        
 if(@Count<(@Maxpagecount-Floor(@Maxpagecount*0.2)))                                            
begin                                        
                                          
   update TRN_kOFF_tBatches set status=88 where BatchNo in(                                             
   select BatchNo from #MergeBatchDetails where status=0)     
       
    update ARC_Athena..SemiOcr_tAutomationBatchQueue set StatusId=0  where BatchNo in       
    (select BatchNo from #MergeBatchDetails where status=0)      
                                                               
   Goto NextSubClient                                          
                                  
End                                               
set @count=0                                      
set @count=@count+@pgcount                                                          
                                                    
                                                    
                              
 insert into Athena_ChildBatchgeneration                                                 
select MAX(Batchid)+1 from athena_childBatchGeneration                                                
                          
select @Batchclientid=MAX(Batchid) from athena_childBatchGeneration                                                
                          
INSERT INTO Athena_ParentBatchGeneration(ParentBatch) values (Convert(varchar(10),@Batchclientid) )                                                                                        
set @ParentBatchid = SCOPE_IDENTITY()                                               
set @ParentBatchNo='S' + Convert(varchar(10),@ParentBatchid) + 'A1'                                                                                
                                                    
if (@Chk=0)                                                      
begin                                                      
Set @Chk=1                 
set @StartPgNo=1                                                      
set @EndPgNo=@PgCount                                                      
End                                                      
                                                    
else                                                      
begin                                                      
set @StartPgNo=@EndPgNo+1                                                      
set @EndPgNo= @startpgno + (@PgCount-1)                                                      
End                                                     
End                                                      
                                                  
else                                                     
                                                  
begin                                                      
if (@Chk=0)                                                      
begin                                                      
Set @Chk=1                                                      
set @StartPgNo=1                                                      
set @EndPgNo=@PgCount                                                      
End                                                      
else                                                      
begin                                                     
 set @StartPgNo=@EndPgNo+1                                                      
set @EndPgNo= @startpgno + (@PgCount-1)                                                      
End                                                      
                                           
end                                                      
                                             
                                 
INSERT INTO MergeBatchDetails(ParentBatchNo,childBatchNo,StartPgNo,EndpgNo,TotalPages,status,Fname,dollaramt)                                                  
values(@ParentBatchNo,@BatchNo,@StartPgNo,@EndPgNo,@PgCount,4,@Fname,@dollaramt)                                                        
update #MergeBatchDetails set status=1 where BatchNo=@BatchNo                                            
Select * from  #MergeBatchDetails where BatchNo=@BatchNo                                           
                                                   
fetch next from @CurMergeBatch   into                                                         
@BatchNo,@PgCount,@Fname,@dollaramt                                                          
End                                             
                                              
  NextSubClient:                                                      
close @CurMergeBatch                                                         
deallocate @CurMergeBatch                                          
Select @LoopCount=@LoopCount-1     
    
drop table #MergeBatchDetails                                                          
                                                 
 End 



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADpMerge_MergedBatches] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADpMerge_MergedBatches] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADpMerge_MergedBatches] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADpMerge_MergedBatches] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADpMerge_MergedBatches] TO [DB_DMLSupport]
    AS [dbo];

