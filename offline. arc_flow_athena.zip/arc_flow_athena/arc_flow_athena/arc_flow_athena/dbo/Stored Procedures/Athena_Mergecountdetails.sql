﻿CREATE proc Athena_Mergecountdetails (@scandate varchar(10))                
as                
begin           
        
        
/*              
          
Cretaed By     : Leela.T          
Created Date   : 2016-07-27             
Purpose        : Merge Batch count & Percentage Details         
Ticket/SCR ID  : <>          
TL Verified By : <Ramki>          
          
         
          
Cretaed By     : Leela.T          
Created Date   : 2017-04-10             
Purpose        : Highlight the Automation Service       
Ticket/SCR ID  : 1195                     
TL Verified By : Udhayaganesh                 
                  
                   
Implemented by : Udhdyaganesh.p            
Implemented On : 10-April-2017              
                      
Reviewd by     : Udhdyaganesh.p                     
Implemented On : 10-April-2017            
          
*/          
           
          
 Declare @Bodymsg varchar(max)  
,@Rowid int        
,@inc int        
,@date varchar(10)                                                                                                                                                                                                                                             

,@serviceName varchar(300)        
,@ReceivedCnt int         
,@Mergecount int        
,@ChildCount int        
,@MergePrecent float        
,@NonMergeCount int        
,@NonMergePrecent float 
,@inrscandate date =convert(date,@scandate)    
        
          
if(object_id('tempdb.dbo.#Tempcount')is not null)                          
drop table #Tempcount               
create table #Tempcount                                                                  
(                                                                                                                                                                                                             
 scandate varchar(10)                                                                                                                                                                                                                                          
 
,serviceName varchar(300)        
,Mergecount int        
,ChildCount int        
)                                 
        
if(object_id('tempdb.dbo.#Receivecnt')is not null)                          
drop table #Receivecnt                
create table #Receivecnt                                                                  
(                                                                                                                                                                                                             
scandate varchar(10)                                                                                                                                                                                                                                           

  
,serviceName varchar(300)        
,ReceivedCnt int         
)          
        
                               
if(object_id('tempdb.dbo.#MergeList')is not null)                          
drop table #MergeList               
create table #Mergelist                                                                  
(          
 id int identity (1,1)                                                                                                                                                                                                           
,scandate varchar(10)                                                                                                                                                                                                                                          

  
  
,serviceName varchar(300)        
,ReceivedCnt int         
,Mergecount int        
,ChildCount int        
,MergePrecent float        
,NonMergeCount int        
,NonMergePrecent float        
        
)                                 
          
         
                
 insert into #Tempcount             
select CONVERT(varchar,ScanDate,101) , servicename, count(distinct parentbatchno),COUNT(childbatchno)  from  TRN_kOFF_tBatches(nolock) a                 
inner join mergebatchdetails (nolock) b on a.BatchNo=b.Childbatchno inner join adm_service(nolock)  s on s.ServiceId=a.ServiceId              
where  ScanDate=@inrscandate and LEFT(batchno,1) not in ('M','S') and pgcount<=9 group by ScanDate,ServiceName                
                
 insert into #Receivecnt                 
select Scandate,servicename,COUNT(batchno)  from  trn_koff_tbatches b            
inner join  adm_service(nolock)  s on s.ServiceId=b.serviceid             
where  ScanDate=@inrscandate and LEFT(batchno,1) not in ('M','S') and pgcount<=9        
group by servicename,Scandate          
          
insert into #Mergelist           
select a.scandate,a.servicename,ReceivedCnt,a.Mergecount,a.ChildCount, Round(CAST(a.ChildCount as float)/CAST(ReceivedCnt as float) * 100,2), (ReceivedCnt-a.Childcount),        
Round(CAST((ReceivedCnt-a.Childcount) as float)/CAST(ReceivedCnt as float) * 100,2)from #Tempcount a inner join #Receivecnt b          
on a.serviceName=b.serviceName  order by serviceName asc          
        
insert into #Mergelist        
select null,'Total' ,SUM(ReceivedCnt),SUM(Mergecount),SUM(childcount), ROUND(CAST(sum(ChildCount) as float)/CAST(sum(ReceivedCnt) as float) * 100,2),        
(sum(NonMergeCount)),Round(CAST(sum(NonMergeCount) as float)/CAST(sum(ReceivedCnt) as float) * 100,2)        
from #Mergelist         
        
        
        
        
select @Rowid=COUNT(id) from #Mergelist        
if(@Rowid>0)        
begin        
set @Bodymsg='Hi All,'                    
set @Bodymsg=@Bodymsg+' <br> <br>                   
<Table  border=1> <tr bgcolor=Purple>'                    
set @Bodymsg=@Bodymsg+'<th> <font color=White> Scandate  </font> </th> <th> <font color=White> Service Name </font> </th>        
<th> <font color=White>Received  Batches </font> </th> <th> <font color=White> Merge Batches </font> </th>        
<th> <font color=White> Child Batches </font> </th> <th> <font color=White> Merge Percent </font> </th>        
<th> <font color=White> Non MergeBatches </font> </th> <th> <font color=White> Non MergePercent</font> </th></tr>'                    
    set @inc=1                
while(@Rowid!=0)                    
begin                    
select @date=scandate,@serviceName=servicename,@ReceivedCnt=ReceivedCnt,@Mergecount=Mergecount,@ChildCount=ChildCount,@MergePrecent=MergePrecent,@NonMergeCount=NonMergeCount,@NonMergePrecent=NonMergePrecent  from #Mergelist   where id=@inc                

if (@serviceName<>'Automation')  
begin  
set @Bodymsg=@Bodymsg+'<tr>'                    
set @Bodymsg=@Bodymsg+'<td align=right>' + isnull(@date,'')  + '</td>'                    
set @Bodymsg=@Bodymsg+'<td align=right>' + @serviceName + '</td>'                   
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@ReceivedCnt as varchar)+ '</td>'        
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@Mergecount as varchar) + '</td>'        
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@ChildCount  as varchar)+ '</td>'        
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@MergePrecent as varchar) + '</td>'        
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@NonMergeCount as varchar) + '</td>'        
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@NonMergePrecent as varchar) + '</td> </tr>'        
 End  
 else  
 begin  
 set @Bodymsg=@Bodymsg+'<tr bgcolor=Green>'                    
set @Bodymsg=@Bodymsg+'<td align=right>' + isnull(@date,'')  + '</td>'                    
set @Bodymsg=@Bodymsg+'<td align=right>' + @serviceName + '</td>'      
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@ReceivedCnt as varchar)+ '</td>'        
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@Mergecount as varchar) + '</td>'        
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@ChildCount  as varchar)+ '</td>'        
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@MergePrecent as varchar) + '</td>'        
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@NonMergeCount as varchar) + '</td>'        
set @Bodymsg=@Bodymsg+'<td align=right>' + cast(@NonMergePrecent as varchar) + '</td> </tr>'    
 End       
set @Rowid=@Rowid-1                   
delete from #Mergelist where  id=@inc          
set @inc=@inc+1                
End                    
                    
set @Bodymsg=@Bodymsg +'</Table><br><br><br> Thanks <br><br><b> ** This is Auto generated Mail ** '                    
End        
        
  
EXEC msdb.dbo.sp_send_dbmail                                                                                                                                                                               
@profile_name = 'DBAMail',                                                                                                                                                           
@recipients='DL-WTP@accesshealthcare.co;mirza.karim@accesshealthcare.co;ramakrishnan.go@accesshealthcare.co;leela.thangavel@accesshealthcare.co;        
dl_dba@accesshealthcare.co;azzazbadusha.a@accesshealthcare.co',                                                                   
@subject='Merge Batch Details',                                              
@body = @Bodymsg ,                                                                                        
@body_format  = 'HTML'             
        
drop table #Tempcount          
drop Table #Receivecnt        
drop table #Mergelist          
          
End   

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Mergecountdetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Mergecountdetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Mergecountdetails] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Mergecountdetails] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Mergecountdetails] TO [DB_DMLSupport]
    AS [dbo];

