﻿CREATE Procedure ADM_FlowAccess_Action
@UserId int
As
Begin
Select COUNT (userid) Result  from ADM_FlowAccess Where userid = @UserId and ISNULL(active,0) = 1
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_FlowAccess_Action] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_FlowAccess_Action] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_FlowAccess_Action] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_FlowAccess_Action] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_FlowAccess_Action] TO [DB_DMLSupport]
    AS [dbo];

