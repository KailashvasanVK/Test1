﻿
CREATE Procedure [dbo].[ADM_HeldStatusMaster]                               
As
Begin
--select StatusId,StatusDescription from ADM_BatchStatusMaster where StatusId in (3,17)
/*
Modified By : Mallikarjun.nam
Modified Dt :2016-01-06
Purpose : Only 'Process Held By TL' status required 
*/
select StatusId,StatusDescription from ADM_BatchStatusMaster where StatusId in (17)
End



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_HeldStatusMaster] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_HeldStatusMaster] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_HeldStatusMaster] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_HeldStatusMaster] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_HeldStatusMaster] TO [DB_DMLSupport]
    AS [dbo];

