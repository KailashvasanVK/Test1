﻿
CREATE  Procedure ADM_pProfileLoadCustomers
	(
		@CustomerId int = 16,
		@UserId int = 1451
	)
	as
begin

--Declare @UserLocationId int =(select isnull(LocationID,1) from ARC_REC_ATHENA..ARC_REC_USER_INFO where USERID=@UserId and ACTIVE=1) -- Code added by mallikarjun.nam 

 if OBJECT_ID('tempdb..#UserLocation') is not null drop table #UserLocation
			Create table #UserLocation( locationid int,LocationName varchar(50))
			insert into  #UserLocation(locationId,LocationName)
			exec ADM_GetUserLocation @userid,0

	
 select ui.EMPCODE,ui.NT_USERNAME,ui.REPORTING_TO ,ui.DOJ,deg.Designation,fun.FunctionName,ui.UserId,
 LTRIM(RTRIM(substring((Select  ',' + case when functionality = 'P' then 'Process' when Functionality = 'A' then 'Audit' 
 else Functionality end from  ADM_AccessFunctionality where UserId = ui.USERID and Functionality in ('A','P') order by AccFunctionalityId for XML path('')),2,50))) as Functionality
 ,LTRIM(RTRIM(SUBSTRING(( select ', ' +  InternalName  from ADM_Customer cu
 inner join  ARC_REC_Athena..ARC_REC_UserCustomer  uc on uc.CustomerID = cu.CustomerId and uc.UserId = ui.USERID 
 where   Status=1 order by cu.InternalName FOR XML PATH('')), 2,10000))) AS Customers
 from ARC_REC_Athena ..ARC_REC_USER_INFO  ui	
 inner join ARC_REC_Athena ..ARC_REC_UserCustomer cust  on  cust.UserId = ui.USERID and cust.CustomerID = @CustomerId 	
 inner join ARC_REC_Athena..HR_Designation deg on deg.DesigId = 	ui.DESIGNATION_ID
 inner join ARC_REC_Athena..HR_Functionality fun on fun.FunctionalityId = ui.FUNCTIONALITY_ID 
 where  ui.ACTIVE=1 and ui.AHS_PRL = 'Y'  and ui.LocationID in(select locationid from #UserLocation)--@UserLocationId --Code added by mallikarjun.nam 
 order by ui.NT_USERNAME

END



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pProfileLoadCustomers] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pProfileLoadCustomers] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pProfileLoadCustomers] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pProfileLoadCustomers] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pProfileLoadCustomers] TO [DB_DMLSupport]
    AS [dbo];

