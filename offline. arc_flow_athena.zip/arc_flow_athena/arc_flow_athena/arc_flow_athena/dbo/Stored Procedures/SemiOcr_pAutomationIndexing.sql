﻿/*      
BatchIndexing : Assign Batches to every user with target basis      
Created Date : 09/02/15      
*/      
CREATE  PROCEDURE SemiOcr_pAutomationIndexing     
(         
@UserInfo varchar(30)        
)        
As        
Begin         
 BEGIN TRY    
     
            DECLARE             
            @UserCount Int,        
            @Target Int,      
            @ActualTarget Int         
  
            SET @UserCount = (Select COUNT(id) from batchIndex_TrackBatches Where userinfo = @UserInfo and cstatus = 0 and CompletedDate Is NULL)        
            SET @ActualTarget = (SELECT [Target] FROM tBatchIndexing_Target Where UserName = @UserInfo)      
            SET @Target = @ActualTarget - @UserCount;       
  
            INSERT INTO batchIndex_TrackBatches (batchnum,userinfo,cstatus)                       
            SELECT  TOP (@Target) Batchno, @UserInfo,0  from trn_koff_tbatches (nolock)  a                        
            Where uploaddt  is null and serviceid<>363 and status=3 and PgCount >= 10         
            and NOT EXISTS (SELECT top 1 Batchnum        
            From batchIndex_TrackBatches Where Batchnum =  a.BatchNo)  Order by  a.Priority desc ,ScanDate asc, PgCount  desc   
               
        SELECT ErrorNumber = 0;  
  
END TRY   
BEGIN CATCH  
    SELECT ERROR_NUMBER() AS ErrorNumber  
END CATCH  
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[SemiOcr_pAutomationIndexing] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SemiOcr_pAutomationIndexing] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SemiOcr_pAutomationIndexing] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[SemiOcr_pAutomationIndexing] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[SemiOcr_pAutomationIndexing] TO [DB_DMLSupport]
    AS [dbo];

