﻿CREATE Procedure CheckBatchdays_SendMailReport      
as      
begin     
Set nocount on;   
declare @xml varchar(max),@body varchar(Max),                                             
@From_Mailid varchar(100),                                                
@REcipients varchar(500),                                                
@CC varchar(1000),                                                
@Subject varchar(100),                                                
@ishtml varchar(5)     
     
if object_id('tempdb.dbo.#TempbatchList') is not null drop table tempdb.dbo.#TempbatchList     
     
create table #PendingBatchList (DayBatch int,DayName varchar(200), ScanDate date,TotalBatch varchar (200),     
Completed varchar (200),Pending varchar (200),Top10Pending varchar(max))    
    
insert into #PendingBatchList(DayBatch,DayName,ScanDate,TotalBatch,Completed,Pending,Top10Pending)    
exec CheckBatchdays    
  
             
SET @xml = CAST((select                      
DayBatch AS 'td',''                                       
,DayName AS 'td',''                                       
,ScanDate AS 'td',''      
,TotalBatch AS 'td',''      
,Completed  AS 'td',''      
,Pending AS 'td',''                                       
,Top10Pending AS 'td',''      
from #PendingBatchList    
              
FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))                 
              
--select @xml               
              
SET @body ='<html><head><title>Access Healthcare</title>                          
   <style type=text/css>                           
   .general{    FONT-FAMILY:VERDANA,ARIAL;FONT-SIZE:8pt;}                          
   .general1{    FONT-FAMILY:VERDANA,ARIAL;FONT-SIZE:14pt;}                          
   .general2{    FONT-FAMILY:VERDANA,ARIAL;FONT-SIZE:12pt;}                          
   .titleTR {     FONT-FAMILY:VERDANA,ARIAL;    FONT-SIZE:8pt; color: #FFFFFF; font-weight:bold; background-color:#003366; height:20;}                          
   tr {      FONT-FAMILY:VERDANA,ARIAL;    FONT-SIZE:8pt; background-color:#F0F0FF ; height:20;}                          
   </style>                           
</head><body>                                        
                                        
<table  border=0 cellspacing=1 cellpadding=1 width=75% align=center  >                                        
<tr class=''titletr''  bgcolor=#1457a7  align=center color=#FFFFFF height=''20''>      
                                         
<th>DayBatch</th>      
<th>DayName</th>                                        
<th>ScanDate</th>      
<th>TotalBatch</th>      
<th>Completed</th>      
<th>Pending</th>      
<th>Top10Pending</th>                                    
</tr>'                                            
                                         
SET @body = @body + @xml +'<tr class=''titletr''   bgcolor=#1457a7  align=center color=#FFFFFF height=''20''><th colspan=''12''>&nbsp;</th></tr></table></br>                                        
<table>                   
</body></html>'                       
                           
                                
    
set @From_Mailid='dump@accesshealthcare.com'                                                
set @REcipients='mirza.karim@accesshealthcare.com;karthick.radhak@accesshealthcare.com;sathishkumar.j@accesshealthcare.com;Arc_Apps_Support@accesshealthcare.com'                                               
--set @CC='nandigam.naraya@accesshealthcare.com'    
set @Subject= 'Athena Pending Batch details'                              
set @ishtml='Y'                                                
    
INSERT INTO ARC_Rec_Athena.dbo.Arc_Rec_Mail_Tran(FROM_MAILID,RECIPIENTS,SUBJECT_Text,BODY,ISHTML,CC)                                                
VALUES(@FROM_MAILID,@RECIPIENTS,@SUBJECT,@body,@ISHTML,@CC)      
    
    
End
GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CheckBatchdays_SendMailReport] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CheckBatchdays_SendMailReport] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CheckBatchdays_SendMailReport] TO [DB_DMLSupport]
    AS [dbo];

