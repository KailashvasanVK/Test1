﻿CREATE Procedure  [dbo].[ARC_Auto_TRN_pProductionReportBatchWise]  
As  
Begin

SET FMTONLY OFF;              
  
declare @CmpKey varchar(5)='OFF'  
 ,@fromDate date =NULL 
 ,@toDate date=NULL  
 ,@BatchServiceId int=0  
 ,@RptType varchar(1)  ='T'
 ,@SearchStr varchar(100) = ''    
 ,@SearchPattern varchar(4) = '=' /** = or % **/     
 ,@LocationId int=0       --added by mallikarjun.nam  
 ,@NtUsername as  varchar(50)='sujatha.sukumar'  
Set nocount on  ;
Set ansi_nulls on  
Set transaction isolation level read uncommitted  
if (DATEPART(hour,getdate())<10)
begin
set @fromDate=CONVERT(date,getdate()-1)
set @toDate =@fromDate
end
else
begin
set @fromDate=CONVERT(date,getdate())
set @toDate =@fromDate
end
/* sp Params Start */  
 --Declare @RptType varchar(1) = 'T'  
 --Declare @SearchStr varchar(100) = ''  
 --Declare @SearchPattern varchar(4) = '='  
 --Declare @CmpKey varchar(5)  
 --Declare @fromDate date  
 --Declare @toDate date  
 --Declare @BatchServiceId int  /** Optional **/    
 --Declare @UserId int /** Optional **/    
 --Set @CmpKey = 'OFF'  
 --Set @UserId = 3460  
 --Set @BatchServiceId = 0  
 --Set @fromDate = '2015-05-06'  
 --Set @toDate = '2015-05-06'   
/* sp Params End */  



Declare @USerID int =(select UserId from ARC_REC_ATHENA..ARC_REC_USER_INFO where NT_USERNAME=@NtUsername)  
  
if isnull(@RptType,'') = '' Set @RptType = 'T'  
Declare @localdbserver varchar(100) = (Select CTL_VALUE from ARC_REC_Athena..ARC_REC_SOFTCONTROL where CTL_ID = 'ServerConnection')          
Declare @qry varchar(max)  
Declare @CustomerId int  
Select @CustomerId = CustomerId from ADM_Customer where CmpKey = @CmpKey  
  
  
  
if OBJECT_ID('tempdb..#ProdRptAssociateWiseTrans') is not null drop table #ProdRptAssociateWiseTrans  
Create Table #ProdRptAssociateWiseTrans(NtName nvarchar(75),BatchNo nvarchar(75),UserId int,ClientId int,ServiceId int,ServiceName varchar(50),EntryTransCnt int,QcTransCnt int)  
Set @qry = '  
  
/* Code written by mallikarjun.nam  */         
 if OBJECT_ID(''tempdb..#UserLocation'') is not null drop table #UserLocation  
 Create table #UserLocation( locationid int,LocationName varchar(50))  
 insert into  #UserLocation(locationId,LocationName)  
 exec ADM_GetUserLocation '+ convert(varchar,@userid) +','+convert(varchar,@LocationId)+'  
  
Insert into #ProdRptAssociateWiseTrans(NtName,BatchNo,UserId,ClientId,ServiceId,ServiceName,EntryTransCnt,QcTransCnt)  
Select NtName,BatchNo,UserId,ClientId,ServiceId,ServiceName    
,Sum(ProTransCnt) as ProTransCnt    
,Sum(QcTransCnt) as QcTransCnt  
from  
(  
Select ui.NT_UserName as NtName,bat.BatchNo,batTrans.CreatedBy as UserId,batTrans.ClientId,batTrans.ServiceId,ser.ServiceName  
,Sum(TransValue) as ProTransCnt  
,0 as QcTransCnt  
from TRN_k'+@CmpKey+'_tBatchTransact as batTrans  
inner join TRN_k'+@CmpKey+'_tBatches as bat on bat.BatchId = batTrans.BatchId and bat.Status = 1  
inner join #UserLocation uloc on isnull(bat.LocationId,1) =uloc.LocationId -- mallikarjun.nam  
  
/*inner join ADM_AccessServices as accSer on accSer.ServiceId = batTrans.BatchServiceId and accSer.UserId = '+CONVERT(varchar,@UserId)+' and accSer.CustomerId = '+CONVERT(varchar,@CustomerId)+'*/  
inner join ADM_Service as ser on ser.ServiceId = batTrans.ServiceId and ser.FieldType = ''T''  
inner join ARC_REC_Athena..ARC_REC_User_Info as ui on ui.userid = batTrans.CreatedBy  
/*inner join ARC_REC_Athena..ARC_REC_UserCustomerView as users on users.CustomerID = '+CAST(@CustomerId as varchar)+' and users.UserId = batTrans.CreatedBy*/  
Where Cast(batTrans.CreatedDt as date) Between '''+CAST(@fromDate as varchar)+''' and '''+CAST(@toDate as varchar)+''' and batTrans.TransValue > 0  
'  
if ISNULL(@UserId,0) <> 0  and @RptType = 'A'  
Set @qry +=   
 '  
   and batTrans.CreatedBy = '+CAST(@UserId as varchar)+'  
 '  
if ISNULL(@BatchServiceId,0) <> 0  
 Set @qry +=   
 '     
   and batTrans.BatchServiceId = '+CAST(@BatchServiceId as varchar)+'  
 '  
Set @qry +=   
'  
Group by ui.NT_UserName,batTrans.CreatedBy,batTrans.ClientId,batTrans.ServiceId,ser.ServiceName,batTrans.CreatedDt,batTrans.BatchServiceId,bat.BatchNo  
'   
Set @qry +=   
'  
Union all  
Select ui.NT_UserName as NtName,bat.BatchNo,batTrans.CreatedBy as UserId,que.ClientId,batTrans.ServiceId,ser.ServiceName  
,0 as ProTransCnt  
,Sum(TransValue) as QcTransCnt  
from TRN_k'+@CmpKey+'_tBatchQCMaster as batTrans  
inner join TRN_k'+@CmpKey+'_tBatchQueue as que on que.BatchProcessId = batTrans.BatchProcessId  
inner join TRN_k'+@CmpKey+'_tBatches as bat on bat.BatchId = que.BatchId and bat.Status = 1  
inner join #UserLocation uloc on isnull(bat.LocationId,1) =uloc.LocationId-- mallikarjun.nam  
/*inner join ADM_AccessServices as accSer on accSer.ServiceId = que.ServiceId and accSer.UserId = '+CONVERT(varchar,@UserId)+' and accSer.CustomerId = '+Convert(varchar,@CustomerId)+'*/  
inner join ADM_Service as ser on ser.ServiceId = batTrans.ServiceId and ser.FieldType = ''T''  
inner join ARC_REC_Athena..ARC_REC_User_Info as ui on ui.userid = batTrans.CreatedBy  
/*inner join ARC_REC_Athena..ARC_REC_UserCustomerView as users on users.CustomerID = '+CAST(@CustomerId as varchar)+' and users.UserId = batTrans.CreatedBy*/  
Where Cast(batTrans.CreatedDt as date) Between '''+CAST(@fromDate as varchar)+''' and '''+CAST(@toDate as varchar)+'''  
'  
if ISNULL(@UserId,0) <> 0  and @RptType = 'A'  
Set @qry +=   
 '  
   and batTrans.CreatedBy = '+CAST(@UserId as varchar)+'  
 '  
if ISNULL(@BatchServiceId,0) <> 0  
 Set @qry +=   
 '  
   and que.ServiceId = '+CAST(@BatchServiceId as varchar)+'  
 '  
Set @qry +=   
'  
Group by ui.NT_UserName,batTrans.CreatedBy,que.ClientId,batTrans.ServiceId,ser.ServiceName,batTrans.CreatedDt,que.ServiceId,bat.BatchNo  
'    
Set @qry +=  
'  
)batTrans  
Group by NtName,UserId,ClientId,ServiceId,ServiceName,batchNo  
'    
   
Exec (@qry)  
Declare @EntryServiceCollection varchar(max)  
Set @EntryServiceCollection = (Select   
',Sum(Case when t.ServiceId = '+Convert(varchar,ServiceId)+' then EntryTransCnt else 0 end) as ['+ServiceName +' Entry]'  
 from #ProdRptAssociateWiseTrans as t Group by ServiceId,t.ServiceName  
 for xml path('')  
 )  
 + ',Sum(EntryTransCnt) as [Entry Total]'  
  
Declare @QcServiceCollection varchar(max)  
Set @QcServiceCollection = (Select     
',Sum(Case when t.ServiceId = '+Convert(varchar,ServiceId)+' then QcTransCnt else 0 end) as ['+ServiceName + ' Qc]'  
 from #ProdRptAssociateWiseTrans as t Group by ServiceId,t.ServiceName  
 for xml path('')  
 )   
 + ',Sum(QcTransCnt) as [Qc Total]'   
Set @EntryServiceCollection = ISNULL(@EntryServiceCollection,'')  
Set @QcServiceCollection = ISNULL(@QcServiceCollection,'')  
  
  
Set @qry = '  
  
/* Code written by mallikarjun.nam  */         
 if OBJECT_ID(''tempdb..#UserLocation'') is not null drop table #UserLocation  
 Create table #UserLocation( locationid int,LocationName varchar(50))  
 insert into  #UserLocation(locationId,LocationName)  
 exec ADM_GetUserLocation '+ convert(varchar,@userid) +','+convert(varchar,@LocationId)+'  
  
  
Select Convert(int,ROW_NUMBER() over(order by [Associate])) as [SNo]  
,x.*  
,Convert(nvarchar(10),'''') as [ColHead]  
into #ProdRptResult  
from  
(  
Select   
t.NtName as [Associate],t.BatchNo,Convert(nvarchar(30),ser.ServiceName) as [Service],Convert(nvarchar(30),cli.ClientAcmName) as [Client]  
' + @EntryServiceCollection + @QcServiceCollection + '  
from #ProdRptAssociateWiseTrans as t  
inner join TRN_k'+@CmpKey+'_tbatches bat on bat.Batchno = t.BatchNo and bat.Status=1  
inner join #UserLocation uloc on isnull(bat.LocationId,1) =uloc.LocationId -- mallikarjun.nam  
inner join ADM_service ser on ser.ServiceId = bat.ServiceId  
inner join ADM_client cli on cli.clientId = bat.ClientId   
Group by t.NtName,t.UserId,t.BatchNo,ser.ServiceName,cli.ClientAcmName  
)x  
Union all  
Select '''',x.*   
,Convert(varchar(5),''G'') as [ColHead]     
from  
(  
Select ''Grand Total'' as [Nt Name],Null as BatchNo,Null as [Service],Null as [Client]  
' + @EntryServiceCollection + @QcServiceCollection + '  
from #ProdRptAssociateWiseTrans as t  
)x    
  
Exec FilterTable    
@DbName = ''tempdb''    
,@TblName = ''#ProdRptResult''    
,@SearchStr = '''+@SearchStr+'''    
,@SearchPattern = '''+@SearchPattern+'''  
,@OrderStr = ''''  
  
'  
Exec (@qry)   
   
if OBJECT_ID('tempdb..#ProdRptAssociateWiseTrans') is not null drop table #ProdRptAssociateWiseTrans  
if OBJECT_ID('tempdb..#ProdRptAssociateTarget') is not null drop table #ProdRptAssociateTarget  
if OBJECT_ID('tempdb..#ProdRptResult') is not null drop table #ProdRptResult  

Set nocount off;
End   
  
  
  
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Auto_TRN_pProductionReportBatchWise] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Auto_TRN_pProductionReportBatchWise] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Auto_TRN_pProductionReportBatchWise] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_Auto_TRN_pProductionReportBatchWise] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_Auto_TRN_pProductionReportBatchWise] TO [DB_DMLSupport]
    AS [dbo];

