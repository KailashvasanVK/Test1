﻿CREATE Proc iEOBMerge_pAvailBatch_posted        
as         
begin        
        
        
/*                                  
                              
Cretaed By     : Leela.T                              
Created Date   : 2018-01-31                         
Purpose        : Check the available batch list for merge  after trans posted batches                            
Ticket/SCR ID  :                              
TL Verified By :   

         Modified By     : Leela.T                              
Modified Date   : 2019-06-06                         
Purpose        : Added Automation2 serveice                           
Ticket/SCR ID  :                              
TL Verified By :   


        
*/        
select Convert(varchar(10),trn.Scandate,101),pyr.Payername,cast(trn.serviceid as varchar(5)) as Servicecid ,count( distinct trn.Batchid) as Batch from trn_koff_tbatches(nolock) trn                 
inner join trn_koff_tbatchqueue(nolock) bq on trn.batchno=bq.batchno           
inner join Arc_Athena..Batchmaster(nolock) bat on bat.batchnum=trn.batchno           
inner join Arc_Athena..iEOB_tAutomationBatchQueue(nolock) tque on tque.batchno=bat.Batchnum  and tque.statusid in (20,5)
inner join adm_payerName (nolock) pyr on pyr.Payerid=trn.Payerid       
inner join Arc_Athena..Semiocr_paymentposting(nolock) pymt on pymt.BatchNo = tque.BatchNo and pymt.isposted=1      
left join mergebatchdetails (nolock) mrg on trn.batchno=mrg.childbatchno           
left join TRN_kOFF_tBatchResetLog Rp on RP.batchno= trn.batchno       
left join trn_koff_theldbatches (nolock) hld on trn.batchid=hld.batchid                    
where trn.status=88 and trn.posteddt is null  and  bq.assigned=0  and trn.serviceid in (452,445)                          
and bq.statusid=0 and trn.UploadDt is null and left(trn.batchno,1) not in ('M','S') and mrg.childbatchno is null                              
and bat.ULStatus is null and bat.uploaddate is null and PgCount between 2 and 20   and RP.batchno is null        
and (hld.Batchid is null or hld.ReleaseDate is not null)      
and not exists (select payerid from  iEOBMerge_tExcludePayer exld  where exld.payerid= trn.payerid and exld.status=1 )                                  
group by Convert(varchar(10),trn.Scandate,101),pyr.Payername ,trn.serviceid     
         
        
End    

GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOBMerge_pAvailBatch_posted] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[iEOBMerge_pAvailBatch_posted] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOBMerge_pAvailBatch_posted] TO [DB_DMLSupport]
    AS [dbo];

