﻿  CREATE Proc [dbo].[Athena_Index_ListInsurance_Test]            
as            
BEGIN            
SELECT  PayerName As  InsuranceName, PayerId   FROM ADM_PayerName  Where status = 1 
END     

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_ListInsurance_Test] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_ListInsurance_Test] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_ListInsurance_Test] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_ListInsurance_Test] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_ListInsurance_Test] TO [DB_DMLSupport]
    AS [dbo];

