﻿CREATE Procedure [dbo].[ADM_ErrorLogInsert]
@ErrorFrom varchar(100),
@ErrorDescription varchar(250),
@ExceptionDescription varchar(max)
as
/*                    
Purpose           : To insert the error details.
Created By        : Karthik I.c.
Created Date      :	11 June 2013
Impact to         : 
 */       
Begin
insert into ADM_ErrorLog (ErrorFrom,ErrorDescription,ExceptionDescription)
select @ErrorFrom,@ErrorDescription,@ExceptionDescription
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ErrorLogInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ErrorLogInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ErrorLogInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ErrorLogInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ErrorLogInsert] TO [DB_DMLSupport]
    AS [dbo];

