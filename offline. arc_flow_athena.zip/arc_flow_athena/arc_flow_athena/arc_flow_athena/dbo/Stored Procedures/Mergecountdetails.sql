﻿CREATE proc Mergecountdetails (@scandate varchar(10))            
as            
begin     
     
   /*          
      
Cretaed By     : Leela.T      
Created Date   : 2015-03-9         
Purpose        : Merge Batch count & Percentage Details     
Ticket/SCR ID  : <>      
TL Verified By : <Ramki>      
      
Modified by    : Leela.T  
Purpose        : call Athena_Mergecountdetails details SP for get the Exact Merge and NonMerge Details    
Modified Date  :2016-08-09  
TL Verified By : <Ramki>   
      
Implemented by :       
Implemented On :     
      
Reviewd by     :       
Implemented On :       
      
*/      
  
exec Athena_Mergecountdetails  @scandate  
  
/*if(object_id('tempdb.dbo.#TempCount')is not null)                    
drop table #TempCount  
create table #TempCount  
(  
Scandate varchar(10)  
,servicename varchar(75)  
,MergeCount int  
,chidBatchcount int  
)  
if(object_id('tempdb.dbo.#Receivecnt')is not null)                    
drop table #Receivecnt  
create table #Receivecnt  
(  
Scandate varchar(10)  
,servicename varchar(75)  
,ReceivedBatches int  
)  
  
 insert into #TempCount         
select CONVERT(varchar,ScanDate,101) Scandate, servicename, count(distinct parentbatchno)as 'Merge Count',  
COUNT(childbatchno) 'chidBatchcount' from  TRN_kOFF_tBatches(nolock) a             
inner join mergebatchdetails (nolock) b on a.BatchNo=b.ParentBatchNo            
inner join servicedets(nolock)  s on s.Parentserviceid=a.ServiceId          
where  CONVERT(varchar,ScanDate,101)=CONVERT(varchar,@scandate,101) group by ScanDate,ServiceName            
            
insert into #Receivecnt             
select Scandate,servicename,COUNT(batchno) 'Received Batches'  from  trn_koff_tbatches b        
inner join  servicedets(nolock)  s on s.ChildServiceid=b.serviceid         
where  CONVERT(varchar,ScanDate,101)=CONVERT(varchar,@scandate,101) and pgcount<=9      
group by servicename,Scandate      
      
       
 select a.scandate,a.servicename,[ReceivedBatches],[MergeCount],[chidBatchcount] from #TempCount a     
 inner join #Receivecnt b on a.serviceName=b.serviceName      
      
drop table #TempCount      
drop Table #Receivecnt*/      
      
End     

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Mergecountdetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Mergecountdetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Mergecountdetails] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Mergecountdetails] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Mergecountdetails] TO [DB_DMLSupport]
    AS [dbo];

