﻿CREATE Procedure ARC_AUTO_MandadeQC_Skipusers    
(@NTUsername Varchar(max))    
as    
    
Begin             
 Truncate Table MandadeQC    
        
SELECT @NTUsername=REPLACE(REPLACE(REPLACE(@NTUsername,CHAR(9),''),CHAR(10),''),CHAR(13),'')        
       
    
insert into MandadeQC(NT_Username)    
(select items  from DBO.MySplit(@NTUsername,','))        
--select * from ADM_QCAuditSkipUsers  where status=1    
 update ADM_QCAuditSkipUsers set status=0,modifiedby=11089,modifieddt=GETDATE()  where status=1    
     
 insert into ADM_QCAuditSkipUsers    
 select a.userid,11089,GETDATE(),1,NULL,NULL from ARC_REC_ATHENA.dbo.ARC_REC_USER_INFO A    
 inner join MandadeQC B on A.NT_USERNAME=B.NT_Username    
 where a.CLIENT_ID=25      
    
--select distinct Ntusername from MandadeQC      
--where Ntusername not in (select NT_USERNAME from ARC_REC_ATHENA.dbo.ARC_REC_USER_INFO )    
    
End 


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_AUTO_MandadeQC_Skipusers] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_AUTO_MandadeQC_Skipusers] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_AUTO_MandadeQC_Skipusers] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_AUTO_MandadeQC_Skipusers] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_AUTO_MandadeQC_Skipusers] TO [DB_DMLSupport]
    AS [dbo];

