﻿CREATE Procedure ADM_MailAlert_Action  
@Action varchar(50),  
@userId  int = 0,  
@Row_id int =  0  
As  
/*  
Purpose : To Show the client creation alert for the user.  
HasRead [0] : Yet Not Read.  
HasRead [1] : Already Read.  
ADM_MailAlert_Action 'SysComAlert',847  
ADM_MailAlert_Action 'ValidateSysComAlert',218  
*/  
Begin   
--set @userid = 847  
if @Action = 'SysComAlert'  
Begin  
Declare @RecipientMailId varchar(75)  
Select @RecipientMailId  = nt_userName + '@accesshealthcare.co' from ARC_REC_Athena..arc_rec_user_info where userid = @userId  
Select  Replace(isnull (MT.MailDescription,''),'return SysAlertResponse()','return SysAlertResponse('+Cast(Row_Id as varchar)+',this)') as MailDescription  
,(select Top 1 nt_userName from  ARC_REC_Athena..ARC_REC_USER_INFO  where UserId = MT.CreatedBy) as CreatedBy  
from ADM_Mail_Tran as MT  
Where MT.hasRead = 0 and MT.Recipients like '%'+@RecipientMailId +'%'  
  
select  @@ROWCOUNT as Result   
End   
else if @Action = 'ValidateSysComAlert'  
Begin  
if  exists (select top 1 ('x')  from ADM_Mail_Tran where Row_id  =  @Row_id and HasRead = 0 )  
Begin  
Update ADM_Mail_Tran set  HasRead = 1  where Row_id  =  @Row_id and HasRead = 0  
Select 1 as Result  -- Yet not Select  
End   
Else   
Begin  
Select 0  as Result  -- Assign   
End   
End  
End 



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_MailAlert_Action] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_MailAlert_Action] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_MailAlert_Action] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_MailAlert_Action] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_MailAlert_Action] TO [DB_DMLSupport]
    AS [dbo];

