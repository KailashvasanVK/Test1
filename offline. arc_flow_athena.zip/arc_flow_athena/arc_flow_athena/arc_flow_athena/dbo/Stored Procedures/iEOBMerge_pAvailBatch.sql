﻿CREATE Proc iEOBMerge_pAvailBatch        
as         
begin        
        
        
/*                                  
                              
Cretaed By     : Leela.T                              
Created Date   : 2017-11-13                               
Purpose        : Check the available batches from iEOB                          
Ticket/SCR ID  : 249774 ,264563                            
TL Verified By :    

Modified By    : Leela.T                              
Modified Date  : 2018-01-15                            
Purpose        : Exculde particular payers from Merge                       
Ticket/SCR ID  :  264563                            
TL Verified By :           
        
Implemented by : Ganesh Tanneru                              
Implemented On : 14-Nov-17          
        
*/        
        
select Convert(varchar(10),trn.Scandate,101),ttemp.TemplateName ,count(trn.Batchid) as Batch from trn_koff_tbatches(nolock) trn                 
inner join trn_koff_tbatchqueue (nolock) bq on trn.batchno=bq.batchno           
inner join Arc_Athena..Batchmaster (nolock) bat on bat.batchnum=trn.batchno           
inner join arc_athena..iEOB_tAutomationBatchQueue(nolock) tque on tque.batchno=bat.Batchnum  and tque.statusid=5        
inner join   arc_athena..iEOB_tAutoIdentifyTemplate ttemp on ttemp.BatchNo = tque.BatchNo            
left join mergebatchdetails (nolock) mrg on trn.batchno=mrg.childbatchno           
left join TRN_kOFF_tBatchResetLog Rp on RP.batchno= trn.batchno    
left join trn_koff_theldbatches (nolock) hld on trn.batchid=hld.batchid                   
where trn.status=88 and trn.posteddt is null  and  bq.assigned=0  and trn.serviceid=452 and (hld.Batchid is null or hld.ReleaseDate is not null)                        
and bq.statusid=0 and  trn.UploadDt is null and left(trn.batchno,1) not in ('M','S') and mrg.childbatchno is null                              
and bat.ULStatus is null and bat.uploaddate is null and PgCount between 2 and 20   and RP.batchno is null 
and not exists (select payerid from  iEOBMerge_tExcludePayer exld  where exld.payerid= trn.payerid and exld.status=1 )                                  
group by Convert(varchar(10),trn.Scandate,101),ttemp.TemplateName            
   End
GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOBMerge_pAvailBatch] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[iEOBMerge_pAvailBatch] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[iEOBMerge_pAvailBatch] TO [DB_DMLSupport]
    AS [dbo];

