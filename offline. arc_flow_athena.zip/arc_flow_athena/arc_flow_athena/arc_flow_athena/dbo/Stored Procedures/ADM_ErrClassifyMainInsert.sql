﻿CREATE Procedure [dbo].[ADM_ErrClassifyMainInsert]  
@ClassifyName varchar(50),  
@Status bit,  
@CreatedBy int,
@SubClassifyGroup varchar(250) = null    
As  
/*  
    Purpose   : Insert the Main Error Classify details  
    Created By   : Karthik IC  
    Created Date : 12 June 2013  
    Impact to    : ErrorClassification.aspx  
*/  
Begin  
Insert into ADM_ErrClassifyMain (ClassifyName,Status,CreatedBy)  
Select @ClassifyName,@Status,@CreatedBy  
if(@SubClassifyGroup is not null )
begin
Declare @ClassifyId  int = (SELECT IDENT_CURRENT ('ADM_ErrClassifyMain'));  
Insert into ADM_ErrClassifyGroup(ClassifyId,SubClassifyId,CreatedBy)
Select  @ClassifyId,items,@CreatedBy from  dbo.fnSplitString(@SubClassifyGroup,',')   
End
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ErrClassifyMainInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ErrClassifyMainInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ErrClassifyMainInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ErrClassifyMainInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ErrClassifyMainInsert] TO [DB_DMLSupport]
    AS [dbo];

