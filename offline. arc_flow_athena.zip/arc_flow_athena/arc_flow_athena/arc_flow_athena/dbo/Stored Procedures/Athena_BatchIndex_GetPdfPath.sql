﻿/* Application Name: UpdateAddtional Infomraion    
Created By: Noor    
Created Date : Nov 12 ,2014    
*/    
    
CREATE Proc Athena_BatchIndex_GetPdfPath    
@BatchNo varchar(30)    
as    
Begin    
SELECT FName  FROM ARC_Flow_Athena..TRN_kOFF_tBatches(nolock) where BatchNo=@BatchNo    
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_BatchIndex_GetPdfPath] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_BatchIndex_GetPdfPath] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_BatchIndex_GetPdfPath] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_BatchIndex_GetPdfPath] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_BatchIndex_GetPdfPath] TO [DB_DMLSupport]
    AS [dbo];

