﻿
CREATE Procedure ADM_pGetUserCustomerDetails
(
	@UseridCollection VARCHAR(max)  ='2776'
)
As
	BEGIN
	/*
		Createddby  : Kathiravan.kand
		CreatedDt : 01/28/2015
		Purpose   : To load customerDetails for the selected Userts
	*/ 
		-- declare @UseridCollection VARCHAR(max)  ='2776'
		if OBJECT_ID('tempdb..#UsersList') is not null  drop table #UsersList
		CREATE TABLE #UsersList(Id INT IDENTITY(1,1), UserId INT)   
		INSERT INTO #UsersList (UserId)
		SELECT items FROM [dbo].[fnSplitString] (@UseridCollection, ',')
		
		
		
		
		IF ((select COUNT(Id) from #UsersList) >1)
		BEGIN
		
					if OBJECT_ID('tempdb..#SelectedUsersInfo') is not null  drop table #SelectedUsersInfo
					Create Table #SelectedUsersInfo(UserId int,CustomerId varchar(max)) 
					insert into  #SelectedUsersInfo (CustomerId,UserId) 
					SELECT SUBSTRING((
					SELECT ',' + CAST(CustomerId AS VARCHAR)
					FROM ADM_AccessCutomers where UserId = items 
					FOR XML PATH('')), 2,10000) AS Csv,items
					from dbo.fnSplitString(@UserIdCollection,',')
			
			
					if	((select COUNT(distinct CustomerId) from  #SelectedUsersInfo) > 1 )
					BEGIN

							select distinct  CustomerName,CustomerId from  
							(
							Select  cust.InternalName as CustomerName,ucust.CustomerID as CustomerId ,ucust.UCid,AAC.AccCustomerId
							From ARC_REC_Athena..ARC_REC_UserCustomer  ucust  
							inner  join ADM_Customer  cust on cust.CustomerId = ucust.CustomerID  
							inner join #UsersList tmp on tmp.UserId = ucust.UserId      
							left join ADM_AccessCutomers   AAC on AAC.UserId  = ucust.userid and aac.CustomerId = ucust.CustomerID 
							Where  cust.Status =1     
							)x
							order by    CustomerName


					END
					ELSE
					BEGIN

							Select distinct aac.AccCustomerId,ucust.UCid  ,cust.InternalName as CustomerName,ucust.CustomerID as CustomerId 
							From ARC_REC_Athena..ARC_REC_UserCustomer  ucust  
							inner  join ADM_Customer  cust on cust.CustomerId = ucust.CustomerID  and ucust.UserId = (select top 1 UserId from #UsersList )
							--	inner join #UsersList tmp on tmp.UserId = ucust.UserId      
							left join ADM_AccessCutomers   AAC on AAC.UserId  = ucust.userid and aac.CustomerId = ucust.CustomerID 
							Where  cust.Status =1        
							order by  aac.AccCustomerId,ucust.UCid  
					END

					if OBJECT_ID('tempdb..#SelectedUsersInfo') is not null  drop table #SelectedUsersInfo
		END	 
		ELSE
		BEGIn
					Select distinct aac.AccCustomerId,ucust.UCid  ,cust.InternalName as CustomerName,ucust.CustomerID as CustomerId 
					From ARC_REC_Athena..ARC_REC_UserCustomer  ucust  
					inner  join ADM_Customer  cust on cust.CustomerId = ucust.CustomerID  
					inner join #UsersList tmp on tmp.UserId = ucust.UserId      
					left join ADM_AccessCutomers   AAC on AAC.UserId  = ucust.userid and aac.CustomerId = ucust.CustomerID 
					Where  cust.Status =1        
					order by  aac.AccCustomerId,ucust.UCid  
		END
		
		if OBJECT_ID('tempdb..#UsersList') is not null  drop table #UsersList
   END
   
   
   

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pGetUserCustomerDetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pGetUserCustomerDetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pGetUserCustomerDetails] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pGetUserCustomerDetails] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pGetUserCustomerDetails] TO [DB_DMLSupport]
    AS [dbo];

