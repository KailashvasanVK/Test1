﻿CREATE  proc Athena_MergeListBatches @scandate varchar(10)=null ,@Minpagecount varchar(5)=null,@Maxpagecount int,@ClientName varchar(10)= Null,@serviceid varchar(10)=null     
  as    
  Begin    
  select batchno,pgcount as PageCount,SUBSTRING(BatchNo,CHARINDEX('A',BatchNo)+1,(LEN(BatchNo)-CHARINDEX('A',BatchNo))+1) as ClientName from trn_koff_tbatches where PgCount <=@Minpagecount                     
and SUBSTRING(BatchNo,CHARINDEX('A',BatchNo)+1,(LEN(BatchNo)-CHARINDEX('A',BatchNo))+1) =@ClientName    
and ScanDate=@scandate and status=99 and ServiceId=@serviceid    and BatchNo  not in (select childbatchno from mergebatchdetails)   
  End  


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_MergeListBatches] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_MergeListBatches] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_MergeListBatches] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_MergeListBatches] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_MergeListBatches] TO [DB_DMLSupport]
    AS [dbo];

