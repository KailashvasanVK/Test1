﻿CREATE Procedure [dbo].[ADM_ClientServiceMovetoLog]              
 @ClientId int                
As                    
BEGIN     
 /*                      
 Purpose           : to move the Services into ServiceMovetoLog table if SericeId alresdy exist in DB                  
 Created By        : Kathiravan                      
 Created Date       :18 March 2013     
 Impact to         : ClientCreation.aspx                      
 */                    
  -- DECLARE @Priceconfig AS INT      
  -- SET @Priceconfig = (select COUNT(*) from ADM_ClientServices WHERE ClientId=@ClientId AND ISNULL(Price,0)<>0)        
  -- if(@Priceconfig = 0)      
   BEGIN      
       INSERT INTO ADM_ClientServicesLog(ClientId,ServiceId,DataType,CreatedBy,Status,CSId)      
       SELECT ClientId,ServiceId,DataType,CreatedBy,Status,CSId FROM ADM_ClientServices  where ClientId=@ClientId      
       Delete  from  ADM_ClientServices where ClientId=@ClientId      
   END      
END


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ClientServiceMovetoLog] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ClientServiceMovetoLog] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ClientServiceMovetoLog] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ClientServiceMovetoLog] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ClientServiceMovetoLog] TO [DB_DMLSupport]
    AS [dbo];

