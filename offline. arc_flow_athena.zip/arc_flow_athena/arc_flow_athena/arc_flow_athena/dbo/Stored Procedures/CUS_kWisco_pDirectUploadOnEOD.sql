﻿CREATE Procedure CUS_kWisco_pDirectUploadOnEOD
As
Begin
/**
CreatedBy : Mohamed Safiyullah
Purpose : Upload date mark on Previous day entry completed batches .
Customer : WISCO (CMN, SalesOrderBin)
**/
/** 348 - CMN **/
	Insert into TRN_kWISCO_tBatchFlow(BatchId,BatchProcessId,CreatedDt,CreatedBy,StatusId,Comments)
	Select q.BatchProcessId,q.BatchId,GETDATE(),1777,13,'Direct upload by System on EOD' 
	from TRN_kWISCO_tBatchQueue as q
	inner join TRN_kWISCO_tBatches as bat on bat.BatchId = q.BatchId 
	and Convert(date,bat.CreatedDt) = Convert(date,DATEADD(DD,-1,getdate())) 
	And bat.ServiceId in (348) 
	and bat.UploadDt is null and PostedDt is not null and bat.status = 1

	Update TRN_kWISCO_tBatchQueue Set StatusId = 13,FlowId = (Select MAX(FlowId) from TRN_kWISCO_tBatchFlow Where BatchProcessId = q.BatchProcessId and StatusId = 13)
	from TRN_kWISCO_tBatchQueue as q
	inner join TRN_kWISCO_tBatches as bat on bat.BatchId = q.BatchId 
	and Convert(date,bat.CreatedDt) = Convert(date,DATEADD(DD,-1,getdate())) 
	And bat.ServiceId in (348) 
	and bat.UploadDt is null and PostedDt is not null and bat.status = 1

	Update bat Set UploadDt = GETDATE()
	from TRN_kWISCO_tBatches as bat
	Where Convert(date,bat.CreatedDt) = Convert(date,DATEADD(DD,-1,getdate())) 
	And bat.ServiceId in (348) 
	and bat.UploadDt is null and PostedDt is not null and bat.status = 1
End



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kWisco_pDirectUploadOnEOD] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kWisco_pDirectUploadOnEOD] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kWisco_pDirectUploadOnEOD] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kWisco_pDirectUploadOnEOD] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kWisco_pDirectUploadOnEOD] TO [DB_DMLSupport]
    AS [dbo];

