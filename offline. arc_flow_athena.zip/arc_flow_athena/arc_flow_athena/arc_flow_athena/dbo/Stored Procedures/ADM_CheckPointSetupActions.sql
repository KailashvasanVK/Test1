﻿CREATE Procedure ADM_CheckPointSetupActions  
     @Action varchar(100),   
     @Userid int,   
     @CmpKey varchar(20),   
     @ServiceId int   
As   
BEGIN   
declare @CustomerId as int   
select @CustomerId = CustomerId from ADM_Customer where CmpKey = @CmpKey   
  
if @Action = 'GET_ACCESSTARGAT_USERS'   
 BEGIN   
	if OBJECT_ID('tempdb..#AssociateList') is not null drop table #AssociateList  
	Create Table #AssociateList(UserId int,Name varchar(100),ReportingTo varchar(100))  
	Insert into #AssociateList(UserId,Name,ReportingTo)   
	Select UserId,NT_USERNAME + ' (' + ui.EMPCODE + ')' as Name,ui.REPORTING_TO  from ARC_REC_Athena..ARC_REC_USER_INFO as ui  
	Where Ui.Reporting_To = (Select Nt_UserName from ARC_REC_Athena..arc_Rec_user_info where userid = @UserId)  
	and Ui.Active = 1 and Ui.Ahs_Prl = 'Y'   
	and USERID in (select distinct(USERID) from ADM_AccessTarget where CustomerId = @CustomerId)  
   
 if (Select COUNT(*) from ARC_FLOW_Athena..ADM_AccessFunctionality Where UserId = @UserId and Functionality = 'B') > 0  
 Begin  
	 Insert into #AssociateList(UserId,Name,ReportingTo)   
	 Select Ui.UserId,ui.NT_USERNAME + ' (' + ui.EMPCODE + ')' as Name ,ui.REPORTING_TO    
	 from ARC_REC_Athena..ARC_REC_USER_INFO as ui  
	 Where Ui.Reporting_To in (Select REPORTING_TO from ARC_REC_Athena..arc_Rec_user_info where userid = @UserId)  
	 and Ui.Active = 1 and Ui.Ahs_Prl = 'Y'   
	 and USERID in (select distinct(USERID) from ADM_AccessTarget where CustomerId = @CustomerId)  
 End   
	Select UserId ,Name as NAME ,ReportingTo from #AssociateList  
	group by UserId,Name,ReportingTo  
 END   
   
else if (@Action = 'GET_ACCTARGAT_SERVICES_BYUSERID')   
 BEGIN   
	select at.ServiceId,Ser.ServiceName from ADM_AccessTarget at   
	inner join ADM_Service ser on at.ServiceId = ser.ServiceId and ser.Status = 1   
	where at.userid = @Userid and at.CustomerId = @CustomerId   
 END   
else if (@Action = 'GET_ACCTARGAT_TRAN')   
 BEGIN    
   
	declare @ProcessTargetId as int   
	declare @QcTargetId as int   
	declare @QaTargetId as int  
	declare @CurrentPTLevelId as int   
	declare @CurrentQCLevelId as int   
	declare @CurrentQALevelId as int  
   
	-- Trying to get ProcessTargetId,QcTargetId,QaTargetId             
	select @ProcessTargetId = ProcessTargetId,@QcTargetId = QcTargetId,@CurrentPTLevelId = PTLevelId,@CurrentQCLevelId= QCLevelId from ADM_AccessTarget   
	where CustomerId = @CustomerId and userid = @Userid and ServiceId = @ServiceId     
	select @QaTargetId = QualityTargetId,@CurrentQALevelId = QALevelId from ADM_AccessTargetQC where CustomerId = @CustomerId and userid = @Userid and ServiceId = @ServiceId     
	--select @ProcessTargetId,@QcTargetId,@QaTargetId,@CurrentPTLevelId,@CurrentQCLevelId,@CurrentQALevelId     
	declare @TotalTranDays as int           
	select @TotalTranDays = dbo.FN_GetUserTransactionDays(@Userid) 
     --select @TotalTranDays          
   
	if OBJECT_ID('tempdb..#ProcessTargetTran') is not null drop table #ProcessTargetTran          
	Create table #ProcessTargetTran(TargetId int,Fromday int,Today int,TargetPercent decimal(9,2),PTLevelId int,TargetType varchar(50),CurrentTargetLevel varchar(500),AssignedLeveLId int)          

	if OBJECT_ID('tempdb..#QCTargetTran') is not null drop table #QCTargetTran          
	Create table #QCTargetTran(TargetId int,Fromday int,Today int,TargetPercent decimal(9,2),QCLevelId int,TargetType varchar(50),CurrentTargetLevel varchar(500),AssignedLeveLId int)          

	if OBJECT_ID('tempdb..#QATargetTran') is not null drop table #QATargetTran          
	Create table #QATargetTran(TargetId int,Fromday int,Today int,TargetPercent decimal(9,2),QALevelId int,TargetType varchar(50),CurrentTargetLevel varchar(500),AssignedLeveLId int)          
    
          -- Inserting ProcessTarget Tran values             
  /* 
	insert into #ProcessTargetTran(TargetId ,Fromday ,Today ,TargetPercent ,PTLevelId ,TargetType,CurrentTargetLevel,AssignedLevelId )          
	select ptt.TargetId,ptt.Fromday,ptt.Today,ptt.TargetPercent,ptt.PTLevelId,'ProcessTarget' as TargetType          
	,case when ptt.Fromday <= @TotalTranDays then '<input type="radio" name="ProcessTargetCurrentLeavel" id="ProcessTargetCurrentLeavel_'+ convert(varchar,ptt.PTLevelId) +'"  value="Process_Level_'+ convert(varchar,ptt.PTLevelId) +'"' +  
	case when ptt.PTLevelId = @CurrentPTLevelId then ' checked="checked"' else '' end  +'"/>'  
	else '' end  
	,isnull(acct.PTLevelId,0)  
	from ADM_ProcessTargetTran ptt   
	left join ADM_AccessTarget as accT on acct.CustomerId = @CustomerId and acct.ServiceId = @ServiceId and acct.userid = @Userid  and accT.PTLevelId = ptt.PTLevelId          
	inner join ADM_ProcessTarget pt on pt.TargetId = ptt.TargetId           
	where pt.TargetId = @ProcessTargetId --  and (@TotalTranDays between ptt.Fromday and ptt.Today)  
	order by ptt.PTLevelId  

	if @CurrentPTLevelId = 0  
	begin  
	-- Creating Radion button checked= true for minimum level  
	update #ProcessTargetTran set  
	CurrentTargetLevel = '<input type="radio" name="ProcessTargetCurrentLeavel" checked="checked" id="ProcessTargetCurrentLeavel_'+ convert(varchar,PTLevelId) +'"  value="Process_Level_'+ convert(varchar,PTLevelId) +'" />',  
	AssignedLeveLId = PTLevelId  
	where PTLevelId = (select MIN(PTLevelId) from #ProcessTargetTran)  
	end  
 */ 
	insert into #QCTargetTran(TargetId ,Fromday ,Today ,TargetPercent ,QCLevelId ,TargetType,CurrentTargetLevel,AssignedLeveLId )  
	select qtt.TargetId,qtt.Fromday,qtt.Today,qtt.TargetPercent,qtt.QCLevelId,'QcTarget' as TargetType  
	,case when qtt.Fromday <= @TotalTranDays then '<input type="radio" name="QCTargetCurrentLeavel" id="QCTargetCurrentLeavel_'+ convert(varchar,qtt.QCLevelId) +'"  value="QC_Level_'+ convert(varchar,qtt.QCLevelId) +'"' +  
	case when qtt.QCLevelId = @CurrentQCLevelId then ' checked="checked"' else '' end  +'"/>'  
	else '' end  
	,isnull(acct.QCLevelId,0)  
	from ADM_QcTargetTran qtt  
	left join ADM_AccessTarget as accT on acct.CustomerId = @CustomerId and acct.ServiceId = @ServiceId and acct.userid = @Userid  and accT.QCLevelId = qtt.QCLevelId          
	inner join ADM_QcTarget qt on qt.TargetId = qtt.TargetId              
	where qt.TargetId = @QcTargetId  -- and (@TotalTranDays between qtt.Fromday and qtt.Today)  
	order by qtt.QCLevelId          

	if @CurrentQCLevelId = 0          
	begin          
		-- Creating Radion button checked= true for minimum level          
		update #QCTargetTran set          
		CurrentTargetLevel = '<input type="radio" name="QCTargetCurrentLeavel" id="QCTargetCurrentLeavel_'+ convert(varchar,QCLevelId) +'"  checked="checked"   value="QC_Level_'+ convert(varchar,QCLevelId) +'" />',          
		AssignedLeveLId = QCLevelId          
		where QCLevelId = (select MIN(QCLevelId) from #QCTargetTran)          
    end   
           
  /*            
	insert into #QATargetTran(TargetId ,Fromday ,Today ,TargetPercent ,QALevelId ,TargetType,CurrentTargetLevel,AssignedLeveLId )          
	select qatt.TargetId,qatt.Fromday,qatt.Today,qatt.TargetPercent,qatt.QALevelId,'QaTarget'          
	,case when qatt.Fromday <= @TotalTranDays then '<input type="radio" name="QATargetCurrentLeavel" id="QATargetCurrentLeavel_'+ convert(varchar,qatt.QALevelId) +'"  value="QA_Level_'+ convert(varchar,qatt.QALevelId) +'"' +  
	case when qatt.QALevelId = @CurrentQALevelId then ' checked="checked"' else '' end  +'"/>'  
	else '' end  
	,isnull(acct.QALevelId,0)  
	from ADM_QaTargetTran qatt  
	left join ADM_AccessTargetQC as accT on acct.CustomerId = @CustomerId and acct.ServiceId = @ServiceId and acct.Userid = @Userid  and accT.QALevelId = qatt.QALevelId  
	inner join ADM_QaTarget qa on qatt.TargetId = qa.TargetId  
	where qa.TargetId = @QaTargetId  --   and (@TotalTranDays between qatt.Fromday and qatt.Today)  
	order by qatt.QALevelId  

	if @CurrentQALevelId = 0          
	begin          
	update #QATargetTran set          
	CurrentTargetLevel = '<input type="radio" name="QATargetCurrentLeavel" id="QATargetCurrentLeavel_'+ convert(varchar,QALevelId) +'"  checked="checked"   value="QA_Level_'+ convert(varchar,QALevelId) +'" />',          
	AssignedLeveLId = QALevelId          
	where QALevelId = (select MIN(QALevelId) from #QATargetTran)          
	end         
 */        
    select * from #ProcessTargetTran --order by PTLevelId desc          
    select * from #QCTargetTran --order by QCLevelId desc          
    select * from #QATargetTran --order by QALevelId desc     
    select @TotalTranDays as TotalTranDays        
      
 END  
END




GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_CheckPointSetupActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_CheckPointSetupActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_CheckPointSetupActions] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_CheckPointSetupActions] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_CheckPointSetupActions] TO [DB_DMLSupport]
    AS [dbo];

