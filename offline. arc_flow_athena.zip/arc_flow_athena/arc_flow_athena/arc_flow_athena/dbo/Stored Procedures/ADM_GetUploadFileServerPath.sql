﻿CREATE Procedure ADM_GetUploadFileServerPath
(
@CustomerId int
)
As
Select FilePath   from ADM_BatchErrorRebuttalFileServer where CustomerId=isnull(@CustomerId,25)

GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetUploadFileServerPath] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_GetUploadFileServerPath] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_GetUploadFileServerPath] TO [DB_DMLSupport]
    AS [dbo];

