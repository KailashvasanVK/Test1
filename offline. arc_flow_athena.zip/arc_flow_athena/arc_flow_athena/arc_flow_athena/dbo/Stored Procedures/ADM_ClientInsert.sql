﻿CREATE Procedure [dbo].[ADM_ClientInsert]      
(      
@CustomerId int      
,@ClientName varchar(75)      
,@ClientAcmName varchar(50)      
,@CreatedBy int      
,@cid int out    
,@CustomerName varchar(50) out    
)      
as      
Begin 
/*                  
Purpose           : insert Cient nad Cust Details into DB              
Created By        : Kathiravan                  
Created Date      :27 March 2013 
Impact to         : ClientCreation.aspx                  
 */     
Insert into ADM_Client(CustomerId,ClientName,ClientAcmName,CreatedBy)      
Select @CustomerId,@ClientName,@ClientAcmName,@CreatedBy     
    
set @cid = IDENT_CURRENT('ADM_Client')    
set @CustomerName = (select InternalName As CustomerName from ADM_Customer where CustomerId=@CustomerId)    
End



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ClientInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ClientInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ClientInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ClientInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ClientInsert] TO [DB_DMLSupport]
    AS [dbo];

