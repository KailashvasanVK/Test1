﻿CREATE Procedure ADM_ProfileAction 
( 
@Action Varchar(75), 
@ServiceId int = 0, 
@Customerid int = 0, 
@UserId int = 0 , 
@UserIdCollection varchar(max) = '', 
@SelectedValues varchar(max)= null ,
@LocationId int=0
) 
As 
--ADM_ProfileAction @action = 'VerifyCustomer',@UserIdCollection = '3' 
Begin 
Declare @ErrMsg varchar(max) 
If @Action = 'GetTeamMembers'  
Begin 
	--Select ui.UserId,ui.NT_USERNAME as Name 
	--from ARC_REC_Athena..arc_rec_user_info as UI 
	--inner join ARC_REC_Athena..arc_rec_user_info as Sup on Sup.USERID = @UserId and ui.REPORTING_TO = sup.NT_USERNAME 
	--Where Ui.AHS_PRL = 'Y' and ui.ACTIVE = 1  
	--Order by ui.NT_USERNAME  
	/*Code written by mallikarjun.nam fro Coimbatore location */
	if OBJECT_ID('tempdb..#UserLocation') is not null drop table #UserLocation
	 Create table #UserLocation( locationid int,LocationName varchar(50))
	 insert into  #UserLocation(locationId,LocationName)
	 exec ADM_GetUserLocation @userid,@LocationId
	
	if OBJECT_ID('tempdb..#AssociateList') is not null drop table #AssociateList
	Create Table #AssociateList(UserId int,Name varchar(100))
		if (@userid = 335) 	--   NT_USERNAME = manigandan.j
			Begin  
			Insert into #AssociateList(UserId,Name) 		
			Select UserId,NT_USERNAME + ' (' + ui.EMPCODE + ')' as Name  from ARC_REC_Athena..ARC_REC_USER_INFO as ui
			Where -- Ui.Reporting_To = (Select Nt_UserName from ARC_REC_Athena..arc_Rec_user_info where userid = @UserId)	and 
			Ui.Active = 1 and Ui.Ahs_Prl = 'Y' and Ui.LocationID in (select locationid from #UserLocation)		 -- Code added by mallikarjun.nam			
		End 
		else if (@userid != 335)
		Begin  
			Insert into #AssociateList(UserId,Name) 
			Select UserId,NT_USERNAME + ' (' + ui.EMPCODE + ')' as Name  from ARC_REC_Athena..ARC_REC_USER_INFO as ui
			Where Ui.CLIENT_ID = 25 /*(Select Nt_UserName from ARC_REC_Athena..arc_Rec_user_info where userid = @UserId)*/
			and Ui.Active = 1 and Ui.Ahs_Prl = 'Y' and Ui.LocationID in (select locationid from #UserLocation)		 -- Code added by mallikarjun.nam

			if (Select COUNT(*) from ARC_FLOW_Athena..ADM_AccessFunctionality Where UserId = @UserId and Functionality = 'B') > 0
			Begin
				Insert into #AssociateList(UserId,Name) 
				Select Ui.UserId,ui.NT_USERNAME + ' (' + ui.EMPCODE + ')' as Name  from ARC_REC_Athena..ARC_REC_USER_INFO as ui
				Where Ui.Reporting_To in (Select REPORTING_TO from ARC_REC_Athena..arc_Rec_user_info where userid = @UserId)
				and Ui.Active = 1 and Ui.Ahs_Prl = 'Y' and Ui.LocationID in (select locationid from #UserLocation)		 -- Code added by mallikarjun.nam
				and exists (select 1 from ARC_REC_Athena..ARC_REC_UserCustomer where USERID = ui.USERID and CustomerID in (Select CustomerID from ARC_REC_Athena..ARC_REC_UserCustomer where USERID = @UserId))
			End 
		End 
	Select distinct UserId,Name from #AssociateList  group by UserId,Name Order by Name
End 
else if @Action = 'VerifyCustomer' 
 Begin 
	if OBJECT_ID('tempdb..#SelectedUsersInfo') is not null drop table #SelectedUsersInfo 
	Create Table #SelectedUsersInfo(NtName varchar(75),UserId int,CustomerId int,Functionality varchar(5)) 
	
	Insert into #SelectedUsersInfo(NtName,UserId,CustomerId,Functionality) 
	Select ui.NT_USERNAME,users.items as UserId,isnull(userCus.CustomerID,0) as CustomerId 
	,isnull((Select 'P' from ADM_AccessFunctionality Where UserId = Convert(int,users.items) and functionality = 'P'),'') + 
	isnull((Select 'A' from ADM_AccessFunctionality Where UserId = Convert(int,users.items) and functionality = 'A'),'') as Audit 
	from dbo.fnSplitString(@UserIdCollection,',') as users --1,2,505,3,4 
	inner join ARC_REC_Athena..ARC_REC_USER_INFO as ui on ui.USERID = convert(int,users.items) 
	left join ARC_REC_Athena..ARC_REC_UserCustomer as userCus on userCus.UserId = convert(int,users.items) 
 --Customer availability check 
 if (Select count(*) from #SelectedUsersInfo Where CustomerId = 0)>0 
	Begin  
		Set @ErrMsg = 'Customer allocation missing for mentioned associates. Please contact HR team. </br>' + STUFF((Select ',' + ntName from #SelectedUsersInfo Where CustomerId = 0 for xml path('')),1,1,'')  
	End 
 --users in conflicting customer names 
 else if (Select COUNT(*) as CustomersCnt from ( 
	  Select Customers 
	  From 
		 ( 
			 Select UserId 
			 ,(select ',' + Convert(varchar,CustomerId) from #SelectedUsersInfo where UserId = us.UserId for XML path('')) as Customers 
			 from #SelectedUsersInfo as us 
			 ) x group by Customers 
		 ) y 
	 ) > 1 
 Begin 
	Set @ErrMsg = 'Customer conflict. Please select valid associates' 
 End  
 --functionality check 
 else if (Select COUNT(*) as FunctionalityCnt from ( 
	  Select Functionality 
	  From 
	 ( 
		 Select UserId 
		 ,(Select Functionality from #SelectedUsersInfo where UserId = us.UserId Group by Functionality) as Functionality 
		 from #SelectedUsersInfo as us 
		 ) x group by Functionality 
		 ) y 
	 ) > 1 
	 Begin 
	 Set @ErrMsg = 'Functionality conflict. Please select valid associates' 
 End  
 drop table #SelectedUsersInfo 
	Select isnull(@ErrMsg,'') as Result 
 End 
-- Else if @Action = 'BackupUserAssociateList'
---- Purpose : To get the all user's name and id --
--Begin
--Select UI.UserId , UI.NT_USERNAME + ' (' + isnull(ui.EMPCODE,'') + ')'  as Name from ARC_REC_Athena..ARC_REC_USER_INFO UI  
--	Where AHS_PRL = 'Y' and ACTIVE = 1 and ui.nt_username <> '' 	
--	and REPORTING_TO in((select NT_USERNAME from ARC_REC_Athena..ARC_REC_USER_INFO where USERID = @userid)
--		,(select REPORTING_TO from ARC_REC_Athena..ARC_REC_USER_INFO where USERID = @userid))
--Order by UserName
--End
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ProfileAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileAction] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ProfileAction] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileAction] TO [DB_DMLSupport]
    AS [dbo];

