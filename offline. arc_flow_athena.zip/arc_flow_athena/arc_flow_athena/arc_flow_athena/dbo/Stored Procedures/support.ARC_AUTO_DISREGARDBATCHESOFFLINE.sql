﻿CREATE Procedure [support.ARC_AUTO_DISREGARDBATCHESOFFLINE]        
(    
@BATCHNO VARCHAR(MAX),        
@TICKETNO VARCHAR(20),    
@NTUSERNAME VARCHAR(50)    
)        
AS       
    
/*        
        
Created By      : <KARMEGAN C  >    
Created On      : 20-06-2016         
Purpose         : TO DISREGARD BATCHES    
Ticket/SCR ID   : <>    
TL Verified By  : <>    
SAMPLE     : ARC_AUTO_DISREGARDBATCHESOFFLINE  @BATCHNO='S219600A1,S219663A1,S219781A1' ,@TICKETID'='147144'      
    
Modified By     : <Modified person Name>    
Modified On     :     
Modified Reason : <>    
    
Reviewed By     : <UDHAYA GANESH.P>    
Reviewed On     : 21-06-2016    
IT Ticket ID    :    
*/    
 BEGIN        
        
/*Step 1 Enter the batch nos from the excel*/        
Declare @CreatedBy int=(SELECT USERID FROM ARC_REC_ATHENA..ARC_REC_USER_INFO WHERE NT_USERNAME= @NTUSERNAME)     

SELECT @BATCHNO=REPLACE(REPLACE(REPLACE(@BATCHNO,CHAR(9),''),CHAR(10),''),CHAR(13),'')  
        
        
select BatchId into #batchids  from dbo.TRN_kOFF_tBatches(NOLOCK) where BatchNo in         
(select items  from DBO.MySplit(@BATCHNO,',')) 


select BatchId from #batchids
     
 /*Step 2 Change ticekt no from email and run the insert query */        
      
insert into  dbo.TRN_kOFF_tDisRegard (BatchId,Comments,CreatedBy,CreatedDt)        
Select BatchId,'support ticket - '+@TICKETNO+' Batch current Status - '+CONVERT(varchar(10),status)+'Created By :' +@NTUSERNAME,@CreatedBy,GETDATE() from dbo.TRN_kOFF_tBatches(NOLOCK) where BatchId in         
(select BatchId from #batchids ) and BatchId not in ( select BatchId from  TRN_kOFF_tDisRegard)        
        
/*Step 3 run update query */        
        
UPDATE  dbo.TRN_kOFF_tBatches SET status =0 where BatchId in (select BatchId from #batchids )        
        
END


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[support.ARC_AUTO_DISREGARDBATCHESOFFLINE] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[support.ARC_AUTO_DISREGARDBATCHESOFFLINE] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[support.ARC_AUTO_DISREGARDBATCHESOFFLINE] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[support.ARC_AUTO_DISREGARDBATCHESOFFLINE] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[support.ARC_AUTO_DISREGARDBATCHESOFFLINE] TO [DB_DMLSupport]
    AS [dbo];

