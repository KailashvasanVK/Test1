﻿CREATE Procedure FilterTable(    
@DbName varchar(100)    
,@TblName varchar(100)    
,@SearchStr varchar(100) = ''    
,@SearchPattern varchar(4) = '=' /** = or % **/    
,@OrderStr varchar(max) = ''    
)    
As    
Begin    
Declare @qry varchar(max)    
if @SearchStr <> ''    
 begin    
 if OBJECT_ID('tempdb..#GenFilter') is not null drop table #GenFilter    
 Create Table #GenFilter(FilterStr varchar(max))     
 declare @filterStr varchar(max)    
 Declare @query varchar(max)     
 Set @query = '    
 if ''' + @SearchPattern + ''' = ''=''    
     Begin    
  Insert into #GenFilter(FilterStr)    
  Select STUFF((select '' or convert(varchar(max),['' + name + '']) = ''''' + @SearchStr + ''''''' from '+@DbName+'.sys.columns where object_id = object_id(''' + @DbName + '..' + @TblName+''') for xml path('''')),1,3,'' where '')    
     End    
 else if ''' + @SearchPattern + ''' = ''%''    
     Begin    
  Insert into #GenFilter(FilterStr)    
  Select STUFF((select '' or convert(varchar(max),['' + name + '']) LIKE ''''%' + @SearchStr + '%'''''' from '+@DbName+'.sys.columns where object_id = object_id(''' + @DbName + '..' + @TblName+''') for xml path('''')),1,3,'' where '')    
     End       
 '    
 Exec (@query)    
 Set @qry = ' Select * from ' + @DbName + '..' + @TblName + isnull((Select Top 1 FilterStr from #GenFilter),'') + isnull(@OrderStr,'')    
 Exec (@qry)     
 Drop table #GenFilter    
 end    
else    
 begin     
 Set @qry = ' Select * from ' + @DbName + '..' + @TblName + @OrderStr  
 Exec (@qry)   
  end     
End   
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[FilterTable] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[FilterTable] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[FilterTable] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[FilterTable] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[FilterTable] TO [DB_DMLSupport]
    AS [dbo];

