﻿CREATE proc [dbo].[ADPMerge_GetBatches](@scandate date, @Batchno BatchnoList Readonly )
as                     
begin       
  
/*                          
                      
Cretaed By     : Leela.T                      
Created Date   : 2017-10-30                       
Purpose        : Change the selected pBAtchnoayer status                    
Ticket/SCR ID  :  245840                    
TL Verified By :                  
                  
                   
Implemented by :  Ganesh           
Implemented On :  30-10-2017          
                      
Reviewd by     :                     
Implemented On :                  
                      
*/               
select trn.Batchno,PayerName ,PgCount from trn_koff_tbatches(nolock) trn inner join adm_payerName (nolock) pay on pay.Payerid=trn.Payerid                    
inner join trn_koff_tbatchqueue (nolock) bq on trn.batchno=bq.batchno inner join Arc_Athena..Batchmaster (nolock) bat on bat.batchnum=trn.batchno                    
left join mergebatchdetails (nolock) mrg on trn.batchno=mrg.childbatchno left join TRN_kOFF_tBatchResetLog Rp on RP.batchno= trn.batchno                    
where trn.status=88  and trn.scandate = @scandate and trn.posteddt is null  and  bq.assigned=0  and trn.serviceid=418                            
and bq.statusid=0 and  trn.UploadDt is null and left(trn.batchno,1) not in ('M','S') and mrg.childbatchno is null and RP.batchno is null                                  
and bat.ULStatus is null and bat.uploaddate is null and trn.batchno in (select Batchno from @batchno)                         
                   
update   trn set trn.status=99 from   trn_koff_tbatches trn inner join adm_payerName  pay on pay.Payerid=trn.Payerid                    
inner join trn_koff_tbatchqueue bq on trn.batchno=bq.batchno inner join Arc_Athena..Batchmaster  bat on bat.batchnum=trn.batchno                    
left join mergebatchdetails  mrg on trn.batchno=mrg.childbatchno   left join TRN_kOFF_tBatchResetLog Rp on RP.batchno= trn.batchno                   
where trn.status=88   and trn.scandate = @scandate and trn.posteddt is null  and  bq.assigned=0  and trn.serviceid=418                            
and bq.statusid=0 and  trn.UploadDt is null and left(trn.batchno,1) not in ('M','S') and mrg.childbatchno is null and RP.batchno is null                                 
and bat.ULStatus is null and bat.uploaddate is null and   trn.batchno in (select Batchno from @batchno)                                   
                    
End 

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADPMerge_GetBatches] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_GetBatches] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_GetBatches] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADPMerge_GetBatches] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_GetBatches] TO [DB_DMLSupport]
    AS [dbo];

