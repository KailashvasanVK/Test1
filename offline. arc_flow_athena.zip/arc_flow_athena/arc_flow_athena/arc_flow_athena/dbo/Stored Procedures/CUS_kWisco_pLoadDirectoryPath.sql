﻿CREATE Procedure CUS_kWisco_pLoadDirectoryPath 
(
	@CustomerId int
)
as
BEGIN
      select cus.InternalName,batchpath.FromDirectoryPath,batchpath.ToDirectoryPath,REPLACE(convert(varchar,GETDATE(),101),'/','') as CurrentDate,
      batchpath.UserName,batchpath.Password,ISNULL(cus.CmpKey,'')as CmpKey,ISNULL(batchpath.ApplicationErrorRecipience,'') as ApplicationErrorRecipience,
      ISNULL(batchpath.FailureAlertRecipients,'') as FailureAlertRecipients,convert(varchar,GETDATE()-1,10) as SODownloadDate
      from ADM_Customer cus
      inner join ADM_BatchsFilePath  batchpath on batchpath.CustomerId = cus.CustomerId
      where cus.CustomerId=@CustomerId and batchpath.Active=1
END





GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kWisco_pLoadDirectoryPath] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kWisco_pLoadDirectoryPath] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kWisco_pLoadDirectoryPath] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kWisco_pLoadDirectoryPath] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kWisco_pLoadDirectoryPath] TO [DB_DMLSupport]
    AS [dbo];

