﻿CREATE procedure [CUS_TWISCO_ERNBatchImportInsertTable]
@ScanDate  date ,
@BatchNo varchar(50) ,
@ClientName  varchar(50)
as
/*
	To insert data into temp table for  WISCO ERN Batch Import.  
*/
Begin
Insert into Temp_CUS_TWISCO_ERNBatchImport  (ScanDate ,BatchNo ,ClientName ,ServiceId )
Select @ScanDate ,@BatchNo,@ClientName,197  --  Service id  :197  -  ServiceName :ERN  
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_TWISCO_ERNBatchImportInsertTable] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_TWISCO_ERNBatchImportInsertTable] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_TWISCO_ERNBatchImportInsertTable] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_TWISCO_ERNBatchImportInsertTable] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_TWISCO_ERNBatchImportInsertTable] TO [DB_DMLSupport]
    AS [dbo];

