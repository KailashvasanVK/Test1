﻿CREATE Proc MovetoForExtract              
as    
/*  
  
Cretaed By     : Ramakrishnan        
Created Date   : 2015-06-03 16:05:09.740         
Purpose        : Move the merge batch for extract        
Ticket/SCR ID  : <>        
TL Verified By : <Ramkakrishnan.G>        
        
Modified  Date : 2016-05-17    
Modified By    : udhayaganesh.p  
Purpose        : Added temp table drop and marked update lock to avoid deadlock.    
TL Verified By :       
        
Implemented by : Udhayaganesh.p      
Implemented On : 2016-05-17      
        
Reviewd by     : Udhayaganesh.p  
Implemented On : 2016-05-17         
     
Reviewd by     : Udhayaganesh.p  
Implemented On : 2019-02-20         

  
  
*/     
Begin  
  
Set Nocount On;    
  
if (OBJECT_id('Tempdb.dbo.#QCComp')) is not Null  
drop table #QCComp  
     
select BatchNo  into #QCComp from TRN_kOFF_tBatches (Nolock)where     
LEFT(BatchNo,1) in('M','S')  and status=1              
and PostedDt is not null and Uploaddt is not null  
and ScanDate>DATEADD(DD,-15,getdate())             

if  (select count(*) from #QCComp)>0
begin             
Update Tb set Tb.Status=20 from TRN_kOFF_tBatches  tb  
inner join #QCComp  b on tb.batchno=b.batchno    
  
insert into MovedBatchestoExtract               
select BatchNo  ,getdate() from #QCComp      
 end   

if (OBJECT_id('Tempdb.dbo.#QCComp')) is not Null  
drop table #QCComp  
  
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[MovetoForExtract] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MovetoForExtract] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MovetoForExtract] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[MovetoForExtract] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MovetoForExtract] TO [DB_DMLSupport]
    AS [dbo];

