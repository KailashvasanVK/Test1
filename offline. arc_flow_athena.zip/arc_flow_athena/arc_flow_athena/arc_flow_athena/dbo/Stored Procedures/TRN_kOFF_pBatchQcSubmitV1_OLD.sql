﻿CREATE Procedure [dbo].TRN_kOFF_pBatchQcSubmitV1_OLD    
(          
@CustomerId int    
,@BatchProcessId int    
,@Comments varchar(max)    
,@CompletedPageNo int /** This should be mandatory if status is incomplete **/    
,@CreatedBy int    
,@QceedPayment int /** Payment (358) transaction count */    
,@QceedCollection int /** Collection (359) transaction count */    
,@QceedExceptionPosting int /** ExceptionPosting (360) transaction count */    
,@QceedSelfPosting int /** SelfPosting (361) transaction count */    
,@QceedPatientPosting int /** PatientPosting (364) transaction count */    
,@Payment int /** Payment (358) transaction count */    
,@Collection int /** Collection (359) transaction count */    
,@ExceptionPosting int /** ExceptionPosting (360) transaction count */    
,@SelfPosting int /** SelfPosting (361) transaction count */    
,@PatientPosting int /** PatientPosting (364) transaction count */    
,@EntPayment int = 0 /** Payment (358) transaction count */    
,@EntCollection int = 0 /** Collection (359) transaction count */    
,@EntExceptionPosting int = 0 /** ExceptionPosting (360) transaction count */    
,@EntSelfPosting int = 0 /** SelfPosting (361) transaction count */    
,@EntPatientPosting int = 0 /** PatientPosting (364) transaction count */    
,@Status varchar(1)    
)    
as          
Begin    
Declare @CreatedDt datetime = getdate()    
Declare @BatchId int,@PageFrom int,@ServiceId int,@ClientId int,@FTE_ID int,@QCPer decimal(9,2),@PageTo int    
Select @BatchId = BatchId ,@PageFrom = PageFrom,@PageTo = PageTo,@ServiceId = ServiceId,@ClientId = ClientId    
from TRN_kOFF_tBatchQueue (nolock) Where BatchProcessId = @BatchProcessId    
Declare @LocationId int = (Select LocationId from ARC_REC_ATHENA..ARC_REC_User_Info where UserId = @CreatedBy)      
Declare @ShiftId int = (Select Top 1 SHIFT_ID from ARC_REC_ATHENA..ARC_REC_SHIFT_TRAN where USERID = @CreatedBy and Effect_DATE <= GETDATE() Order by Effect_DATE desc)  
if (Select count(*) from TRN_kOFF_TBatchQueue (nolock) Where BatchProcessId = @BatchProcessId and Assigned = @CreatedBy) = 0    
 Begin    
  /**    
  Have to check whether the process is assigned or not. If not then no need to process. (May the process held / disregard / reset from .manage)    
  **/    
  RAISERROR('Already batch status was changed',16,1)    
  Select 0    
  Return    
 End    
Declare   
@FactorPayment float /** Payment (358) transaction count */      
,@FactorCollection float /** Collection (359) transaction count */      
,@FactorExceptionPosting float /** ExceptionPosting (360) transaction count */      
,@FactorSelfPosting float /** SelfPosting (361) transaction count */      
,@FactorPatientPosting float /** PatientPosting (364) transaction count */   
,@QcFactorPayment float /** Payment (358) transaction count */      
,@QcFactorCollection float /** Collection (359) transaction count */      
,@QcFactorExceptionPosting float /** ExceptionPosting (360) transaction count */      
,@QcFactorSelfPosting float /** SelfPosting (361) transaction count */      
,@QcFactorPatientPosting float /** PatientPosting (364) transaction count */   
  
Select   
@FactorPayment = EntryPayment  
,@FactorCollection = EntryCollection  
,@FactorExceptionPosting = EntryExceptionPosting  
,@FactorSelfPosting = EntrySelfPosting  
,@FactorPatientPosting = EntryPatientCreation   
,@QcFactorPayment = QcPayment  
,@QcFactorCollection = QcCollection  
,@QcFactorExceptionPosting = QcExceptionPosting  
,@QcFactorSelfPosting = QcSelfPosting  
,@QcFactorPatientPosting = QcPatientCreation   
from ADM_FactorWaterTown   
Where ServiceGroupId = @ServiceId and CONVERT(date,getdate()) between EffectiveFrom and isnull(EffectiveTo,GETDATE())  
  
Select Top 1 @FTE_ID = CreatedBy from TRN_kOFF_tBatchFlow (nolock) Where BatchProcessId = @BatchProcessId and StatusId = 6 Order by FlowId desc    
Select @QCPer = Dbo.ADM_fnFteQcTarget(@CustomerId,@ServiceId,@FTE_ID)    
if (@QCPer = -1)    
 Begin    
 RAISERROR('QC Percentage not assigned for entry user',16,1)    
 return 0    
 End    
if @Status in ('I')    
 Begin    
 if (@CompletedPageNo = 0)    
  Begin    
  RAISERROR('Cannot change the status as incomplete with zero transaction',16,1)    
  Select 0    
  Return    
  End    
 if (@CompletedPageNo > @PageTo)    
  Begin    
  RAISERROR('Completed page no should be alloted page limit',16,1)    
  Select 0    
  Return    
  End    
 if (@CompletedPageNo+1 > @PageTo)    
  Begin    
  RAISERROR('Invalid Incomplete / Hold! To page should be lesser than total allocated pages.',16,1)    
  Select 0    
  Return    
  End    
 End    
Begin Transaction        
Begin Try    
Insert into TRN_kOFF_tBatchFlow (BatchId,BatchProcessId,CreatedBy,CreatedDt,StatusId,Comments)    
Values(@BatchId,@BatchProcessId,@CreatedBy,@CreatedDt,12,@Comments)    
if @QceedPayment > 0    
 Insert into TRN_kOFF_tBatchQCMaster(BatchProcessId,PageNo,CreatedBy,CreatedDt,ServiceId,TransValue,FTE_Id,QCPercentage,BatchId,LocationId,ShiftId,FactorTrans)  
 Values(@BatchProcessId,@PageFrom,@CreatedBy,@CreatedDt,358,@QceedPayment,@FTE_ID,@QCPer,@BatchId,@LocationId,@ShiftId,@QcFactorPayment)  
if @QceedCollection > 0    
 Insert into TRN_kOFF_tBatchQCMaster(BatchProcessId,PageNo,CreatedBy,CreatedDt,ServiceId,TransValue,FTE_Id,QCPercentage,BatchId,LocationId,ShiftId,FactorTrans)     
 Values(@BatchProcessId,@PageFrom,@CreatedBy,@CreatedDt,359,@QceedCollection,@FTE_ID,@QCPer,@BatchId,@LocationId,@ShiftId,@QcFactorCollection)    
if @QceedExceptionPosting > 0    
 Insert into TRN_kOFF_tBatchQCMaster(BatchProcessId,PageNo,CreatedBy,CreatedDt,ServiceId,TransValue,FTE_Id,QCPercentage,BatchId,LocationId,ShiftId,FactorTrans)     
 Values(@BatchProcessId,@PageFrom,@CreatedBy,@CreatedDt,360,@QceedExceptionPosting,@FTE_ID,@QCPer,@BatchId,@LocationId,@ShiftId,@QcFactorExceptionPosting)    
if @QceedSelfPosting > 0    
 Insert into TRN_kOFF_tBatchQCMaster(BatchProcessId,PageNo,CreatedBy,CreatedDt,ServiceId,TransValue,FTE_Id,QCPercentage,BatchId,LocationId,ShiftId,FactorTrans)     
 Values(@BatchProcessId,@PageFrom,@CreatedBy,@CreatedDt,361,@QceedSelfPosting,@FTE_ID,@QCPer,@BatchId,@LocationId,@ShiftId,@QcFactorSelfPosting)    
if @QceedPatientPosting > 0    
 Insert into TRN_kOFF_tBatchQCMaster(BatchProcessId,PageNo,CreatedBy,CreatedDt,ServiceId,TransValue,FTE_Id,QCPercentage,BatchId,LocationId,ShiftId,FactorTrans)  
 Values(@BatchProcessId,@PageFrom,@CreatedBy,@CreatedDt,364,@QceedPatientPosting,@FTE_ID,@QCPer,@BatchId,@LocationId,@ShiftId,@QcFactorPatientPosting)    
if @Payment > 0    
 Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry,LocationId,ShiftId,FactorTrans)  
 Values(@BatchProcessId,@PageFrom,358,@Payment,'',@CreatedBy,@CreatedDt,@BatchId,@ServiceId,@ClientId,1,@LocationId,@ShiftId,@FactorPayment)    
if @Collection > 0    
 Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry,LocationId,ShiftId,FactorTrans)    
 Values(@BatchProcessId,@PageFrom,359,@Collection,'',@CreatedBy,@CreatedDt,@BatchId,@ServiceId,@ClientId,1,@LocationId,@ShiftId,@FactorCollection)    
if @ExceptionPosting > 0    
 Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry,LocationId,ShiftId,FactorTrans)  
 Values(@BatchProcessId,@PageFrom,360,@ExceptionPosting,'',@CreatedBy,@CreatedDt,@BatchId,@ServiceId,@ClientId,1,@LocationId,@ShiftId,@FactorExceptionPosting)    
if @SelfPosting > 0    
 Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry,LocationId,ShiftId,FactorTrans)  
 Values(@BatchProcessId,@PageFrom,361,@SelfPosting,'',@CreatedBy,@CreatedDt,@BatchId,@ServiceId,@ClientId,1,@LocationId,@ShiftId,@FactorSelfPosting)    
if @PatientPosting > 0    
 Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry,LocationId,ShiftId,FactorTrans)  
 Values(@BatchProcessId,@PageFrom,364,@PatientPosting,'',@CreatedBy,@CreatedDt,@BatchId,@ServiceId,@ClientId,1,@LocationId,@ShiftId,@FactorPatientPosting)    
if @Status = 'C'    
 Begin    
 Insert into TRN_kOFF_tBatchQCComments(BatchProcessId,Comments,CreatedBy,CreatedDt,FTE_Id,BatchId,FromPage,ToPage,FTE_QcPer,LocationId,ShiftId)  
 values(@BatchProcessId,@Comments,@CreatedBy,@CreatedDt,@FTE_ID,@BatchId,@PageFrom,@PageTo,@QCPer,@LocationId,@ShiftId)    
 Update TRN_kOFF_tBatchQueue Set StatusId = 12,Assigned = 0,ActToPage = PageTo Where BatchProcessId = @BatchProcessId    
 Declare @ProcessCount int,@DirUpload int = 0    
 Select @ProcessCount = COUNT(BatchProcessId) from TRN_kOFF_tBatchQueue Where BatchId = @BatchId  
 if @ProcessCount <= (Select COUNT(*) from TRN_kOFF_tBatchQueue Where BatchId = @BatchId and StatusId = 12)  
  Begin  
  /** All the process has been met entry completed. PostedDt should be mark on Batch table **/  
  Update TRN_kOFF_tBatches Set AuditedDt = GETDATE() Where BatchId = @BatchId  and PostedDt is not null   
  End   
 Select @DirUpload = COUNT(batchid) from TRN_kOFF_tDirectUpload where BatchId = @BatchId and Status = 1    
 if (Select COUNT(batchid) from TRN_kOFF_tBatches Where BatchId = @BatchId and PostedDt is not null and (AuditedDt is not null or @DirUpload >= 1)) > 0    
  Begin    
  /** All the process has been met entry & qc completed.**/    
  if (Select COUNT(FlowId) from TRN_kOFF_tBatchFlow Where BatchId = @BatchId and StatusId = 13) = 0    
  Insert into TRN_kOFF_tBatchFlow (BatchId,BatchProcessId,CreatedBy,CreatedDt,StatusId,Comments)Values(@BatchId,@BatchProcessId,@CreatedBy,GETDATE(),13,'')    
  Update TRN_kOFF_tBatchQueue Set StatusId = 13 Where BatchId = @BatchId    
  Update TRN_kOFF_tBatches Set UploadDt = GETDATE() Where BatchId = @BatchId    
  End    
 --Exec TRN_kOFF_pMarkQCCompleted @BatchId = @BatchId, @CreatedBy  = @CreatedBy    
 --Exec TRN_kOFF_pMarkBatchCompleted @BatchId = @BatchId,@CreatedBy = @CreatedBy,@BatchProcessId = @BatchProcessId    
 End    
else if @Status = 'I'    
 Begin /** Qc Incomplete **/    
 Insert into TRN_kOFF_tBatchQCComments(BatchProcessId,Comments,CreatedBy,CreatedDt,FTE_Id,BatchId,FromPage,ToPage,FTE_QcPer,LocationId,ShiftId)    
 values(@BatchProcessId,@Comments,@CreatedBy,@CreatedDt,@FTE_ID,@BatchId,@PageFrom,@CompletedPageNo,@QCPer,@LocationId,@ShiftId)    
 Update TRN_kOFF_TBatchQueue Set PageFrom = @CompletedPageNo+1,StatusId = 8,Assigned = 0 Where BatchProcessId = @BatchProcessId     
 Insert into TRN_kOFF_tBatchFlow (BatchId,BatchProcessId,CreatedBy,CreatedDt,StatusId,Comments)    
 Values(@BatchId,@BatchProcessId,@CreatedBy,@CreatedDt,8,@Comments)    
 End    
Commit Transaction  
Select ''    
End Try        
Begin Catch        
Rollback transaction    
return Error_Message()  
End catch        
End  
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pBatchQcSubmitV1_OLD] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchQcSubmitV1_OLD] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchQcSubmitV1_OLD] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pBatchQcSubmitV1_OLD] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchQcSubmitV1_OLD] TO [DB_DMLSupport]
    AS [dbo];

