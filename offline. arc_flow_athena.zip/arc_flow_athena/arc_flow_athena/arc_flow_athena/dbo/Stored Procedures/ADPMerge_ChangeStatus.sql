﻿
 CREATE Proc [dbo].[ADPMerge_ChangeStatus] (@BatchNo StatusChangeBatch Readonly)      
  as      
  begin  
  
        
 /*                          
                      
Cretaed By     : Leela.T                      
Created Date   : 2017-03-29                        
Purpose        : Move the Batches to Scanning          
Ticket/SCR ID  : 1195                   
TL Verified By : Udhayaganesh               
                
                 
Implemented by : Udhdyaganesh.p          
Implemented On : 10-April-2017            
                    
Reviewd by     : Udhdyaganesh.p                   
Implemented On : 10-April-2017                       
                      
*/       
    
  update trn_koff_tbatches set status=77 where batchno in (select batchno from @BatchNo)    
    
  update ARC_Athena..SemiOcr_tAutomationBatchQueue  set statusid=77 where batchno in (select batchno from @BatchNo)  
         
  insert into ARC_Athena..SemiOcr_tAutomationBatchFlow     
  select Batchid,batchProcessId,getdate(),1111,77,'Move to Scanning From Merge'     
  from  ARC_Athena..SemiOcr_tAutomationBatchQueue  where batchno in (select batchno from @BatchNo)    
     
  insert into  ARC_Athena..Report_UpdateValuesTracking  
  select 'Move2Scanning',getdate(),batchno,99,77,'ADP Merge' from ARC_Athena..SemiOcr_tAutomationBatchQueue  
  where batchno in (select batchno from @BatchNo)   
    
  End  
  

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADPMerge_ChangeStatus] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_ChangeStatus] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_ChangeStatus] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADPMerge_ChangeStatus] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_ChangeStatus] TO [DB_DMLSupport]
    AS [dbo];

