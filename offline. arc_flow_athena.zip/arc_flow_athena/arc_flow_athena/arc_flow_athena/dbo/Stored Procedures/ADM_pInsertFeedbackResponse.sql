﻿CREATE Procedure  ADM_pInsertFeedbackResponse
(
	@FeedbackId int=0,
	@BatchNo varchar(50),
	@ServiceId int=0,
	@ClientId int=0,
	@PageNo int=0,
	@Ticket varchar(75),
	@ClinicCode varchar(50),
	@AHSIncorrectNote varchar(800),
	@IncorrectActionTaken varchar(800),
	@ActiontobeTaken varchar(800),
	@ClientComments varchar(800),
	@AHSPMSUser varchar(100),  -- 100
	@DateofBilling varchar(15),
	@CustomerId int=0,
	@ProcessedFTE  int=0, 
	@DatePeocessed varchar(15),
	@QAAssociate int=0,
	@NewInstructions  int=0,
	@RootcaseAnalysis int=0,
	@CorrectiveAction varchar(800),
	@CorrectiveActionDate varchar(15),
	@PreventiveAction varchar(800),
	@PreventiveActionDate varchar(15),
	@IncludeinTest bit=0,
	@TestedDate varchar(15),
	@TrainingTaken varchar(15),
	@AHSComments varchar(800),
	@CreatedBy int=0
	
)
AS
Begin
	Insert into ADM_FeedbackResponse(FeedbackId,BatchNo,ServiceId,ClientId,PageNo,Ticket,ClinicCode,AHSIncorrectNote,IncorrectActionTaken,ActiontobeTaken,ClientComments,
				AHSPMSUser,DateofBilling,CustomerId,ProcessedFTE,DatePeocessed,QAAssociate,NewInstructions,RootcaseAnalysis,CorrectiveAction,CorrectiveActionDate,PreventiveAction
				,PreventiveActionDate,IncludeinTest
				,TestedDate
				,TrainingTaken,AHSComments,CreatedBy,CreatedDt
				)
	  select  @FeedbackId,@BatchNo,@ServiceId,@ClientId,@PageNo,@Ticket,@ClinicCode,@AHSIncorrectNote,@IncorrectActionTaken,@ActiontobeTaken,@ClientComments
			,@AHSPMSUser,case when @DateofBilling <> '' then convert(date,@DateofBilling) else null end
			,@CustomerId,@ProcessedFTE
			,case when @DatePeocessed <> '' then convert(date,@DatePeocessed) else null end
			,@QAAssociate,@NewInstructions,@RootcaseAnalysis,@CorrectiveAction,
			case when @CorrectiveActionDate <> '' then convert(date,@CorrectiveActionDate) else null end
			,@PreventiveAction
			,case when @PreventiveActionDate <> '' then convert(date,@PreventiveActionDate) else null end
			,@IncludeinTest
			,case when @TestedDate <> '' then convert(date,@TestedDate) else null end
			,case when @TrainingTaken <> '' then convert(date,@TrainingTaken) else null end
			,@AHSComments,@CreatedBy,GETDATE()
			
			update ADM_FeedbackRequest set Status=2 where CustomerId=@CustomerId and FeedbackId=@FeedbackId and Status=1 
	
End





GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pInsertFeedbackResponse] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pInsertFeedbackResponse] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pInsertFeedbackResponse] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pInsertFeedbackResponse] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pInsertFeedbackResponse] TO [DB_DMLSupport]
    AS [dbo];

