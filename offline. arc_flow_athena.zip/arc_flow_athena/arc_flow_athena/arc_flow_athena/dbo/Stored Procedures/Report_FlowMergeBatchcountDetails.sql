﻿  
CREATE Proc Report_FlowMergeBatchcountDetails @FromDate date,@Todate date  
as  
begin  
  
/*        
    
Cretaed By     : Leela.T    
Created Date   : 2016-09-01       
Purpose        : Take  the Merge  & Liquid Batch , Trans Count in .flow Tables  
Ticket/SCR ID  : <>    
TL Verified By : <Ramki>    
    
*/  
  
Declare @FromUploadDate datetime  
       ,@ToUploadDate datetime  
  
  
if(object_id('tempdb.dbo.#FinalReport')is not null)                    
drop table #FinalReport  
Create table #FinalReport  
(Associate varchar(100)  
,ServiceName varchar(100)  
,MergeBatch int  
,MergeTrans int  
,LiquidBatch int  
,LiquidTrans int  
,TotBatch int  
,TotTrans int)  
  
if(object_id('tempdb.dbo.#Mergecount')is not null)                    
drop table #Mergecount  
create table #Mergecount  
(usrName varchar(100)  
,ServiceName Varchar(100)  
,MergeBatch Varchar(100)  
,MergeTrans int  
)  
  
if(object_id('tempdb.dbo.#liquidcount')is not null)                    
drop table #liquidcount  
create table #liquidcount  
(usrName varchar(100)  
,ServiceName Varchar(100)  
,BatchCount Varchar(100)  
,TransCount int  
)  
  
if (isnull(@FromDate,'') ='' and isnull(@ToDate,'') ='')          
begin          
 set  @FromUploadDate  =  convert(date,'1900-01-01')          
 set @ToUploadDate  = Convert(varchar,DateAdd(DD,1,Convert(Date,GETDATE()))) + ' 07:59'  
 End  
else  
 begin  
 set  @FromUploadDate  = Convert(varchar,Convert(Date,@FromDate)) + ' 08:00'   
 set @ToUploadDate  =Convert(varchar,DateAdd(DD,1,Convert(Date,@FromDate))) + ' 07:59'  
 end       
  
  
/*********************************Merge Batch &  Trans Details *************************************/  
insert into #Mergecount  
select  distinct Nt_userName as usrName,ServiceName,count(distinct Mergebatch)as MergeBatch , sum(MergeTrans) MergeTrans   
from  (  
select Nt_userName,ParentBatchNo MergeBatch,ServiceName, Sum(TransValue) MergeTrans  
from trn_koff_tbatches(nolock) tbat inner join mergebatchdetails(nolock) mer on tbat.Batchno=mer.ChildBatchNo  and tbat.status=1  
inner join trn_koff_tbatchTransact(nolock) trns on trns.Batchid=tbat.Batchid  
inner join ADM_Service ser on ser.ServiceId=tbat.ServiceId  
inner join ARC_REC_ATHENA..ARC_REC_USER_INFO (nolock)usr on usr.USERID=trns.createdby  
where trns.Createddt between @FromUploadDate and @ToUploadDate  
group by Nt_userName,ParentBatchNo,ServiceName ) a group by Nt_userName,ServiceName  
  
insert into #liquidcount  
select  distinct Nt_userName as usrName,ServiceName,count(distinct batch), sum(Trans) Trans   
from  (  
select Nt_userName,BatchNo Batch,ServiceName, Sum(TransValue) Trans  
from trn_koff_tbatches(nolock) tbat inner join trn_koff_tbatchTransact(nolock) trns on trns.Batchid=tbat.Batchid  
inner join ADM_Service ser on ser.ServiceId=tbat.ServiceId  
inner join ARC_REC_ATHENA..ARC_REC_USER_INFO (nolock)usr on usr.USERID=trns.createdby  
Left join mergebatchdetails(nolock) mer on tbat.Batchno=mer.ChildBatchNo  and tbat.status=1  
where trns.Createddt between @FromUploadDate and @ToUploadDate and mer.childbatchno is null  
and left(batchno,1) not in ('M','S')  
group by Nt_userName,BatchNo,ServiceName ) a group by Nt_userName,ServiceName  
  
  
/***********************ConcateNate the Data*************************************/  
  
Insert into #FinalReport(Associate,ServiceName,MergeBatch,MergeTrans,LiquidBatch,LiquidTrans)  
select UsrName,ServiceName,isnull(MergeBatch,0),isnull(MergeTrans,0),0,0 from #Mergecount order by usrName  
  
  
update fr Set fr.LiquidBatch=isnull(BatchCount,0),fr.LiquidTrans=isnull(lc.TransCount,0) from  #FinalReport  fr  
inner join #liquidcount lc on fr.Associate=lc.UsrName and fr.ServiceName=lc.servicename   
  
Insert into #FinalReport(Associate,ServiceName,MergeBatch,MergeTrans,LiquidBatch,LiquidTrans)  
select UsrName,ServiceName,0,0,isnull(BatchCount,0),isnull(TransCount,0) from #liquidcount lc  
where not exists( select 1 from #Mergecount where UsrName=lc.UsrName and ServiceName=lc.ServiceName )  
  
  
update #finalReport set TotBatch=MergeBatch+liquidBatch,TotTrans=MergeTrans+LiquidTrans  
  
  
select * from #finalReport order by Associate,ServiceName  
  
  
drop table #Mergecount  
drop table #liquidcount  
  
End  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Report_FlowMergeBatchcountDetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Report_FlowMergeBatchcountDetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Report_FlowMergeBatchcountDetails] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Report_FlowMergeBatchcountDetails] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Report_FlowMergeBatchcountDetails] TO [DB_DMLSupport]
    AS [dbo];

