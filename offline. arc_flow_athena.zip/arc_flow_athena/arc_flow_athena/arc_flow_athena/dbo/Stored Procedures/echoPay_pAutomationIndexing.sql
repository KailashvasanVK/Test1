﻿CREATE PROCEDURE echoPay_pAutomationIndexing
(                       
@UserInfo varchar(30)                      
)                      
As        
/*                      
Created By     : Gobinath.M                                  
Created Date   : 2019-05-14                   
Purpose        : Allocate the batches to echoPay Indexing team from Not Found Queue
Ticket/SCR ID  :                    
TL Verified By : Ramakrishnan.G                    
                    
Implemented On : 
Implemented On : 
Reviewed by    : 
Reviewed On    : 
*/                                   
Begin                       
BEGIN TRY                  
               
        DECLARE                           
        @UserCount Int,                      
        @Target Int,                    
        @ActualTarget Int                       
            
        SET @UserCount = (Select COUNT(id) from echoPay_tIndexing Where userinfo = @UserInfo and cstatus = 0 and CompletedDate Is NULL)                      
        SET @ActualTarget = (SELECT [Target] FROM tBatchIndexing_Target Where UserName = @UserInfo)                    
        SET @Target = @ActualTarget - @UserCount;                     
            
        INSERT INTO echoPay_tIndexing (batchnum,userinfo,cstatus)                                     
        SELECT  TOP (@Target) a.Batchno, @UserInfo,0  from trn_koff_tbatches (nolock)  a
        INNER JOIN ARC_ATHENA.dbo.batchMaster bm (nolock) on bm.batchnum = a.BatchNo
        INNER JOIN ARC_ATHENA.dbo.iEOB_tAutomationBatchQueue(nolock) tQ on tQ.BatchNo = a.BatchNo
        Where a.Status = 88 and tQ.StatusID = 8 And a.ServiceID = 452
        and NOT EXISTS (SELECT top 1 Batchnum
        From echoPay_tIndexing Where Batchnum =  a.BatchNo)  Order by  ScanDate asc, PgCount  desc, bm.dollarAmt desc
                         
    SELECT ErrorNumber = 0;
            
END TRY                 
BEGIN CATCH                
SELECT ERROR_NUMBER() AS ErrorNumber                
END CATCH                
End


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[echoPay_pAutomationIndexing] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[echoPay_pAutomationIndexing] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[echoPay_pAutomationIndexing] TO [DB_DMLSupport]
    AS [dbo];

