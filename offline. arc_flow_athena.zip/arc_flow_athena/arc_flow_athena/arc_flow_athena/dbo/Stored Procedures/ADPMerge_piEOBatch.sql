﻿CREATE PROC  ADPMerge_piEOBatch(@scandate DATE, @SystemIP VARCHAR(50),@BatchList iEOBatches READONLY)
AS 
BEGIN

/*Cretaed By   :   Leela.T
Created Date   :   2017-10-31 
Purpose        :     iEOB Mergebatches Tracking
Ticket/SCR ID  :     
TL Verified By : */ 
      

INSERT INTO ADPMerge_tiEOBatchTrack(scandate,Parentbatchno,Childbatchno,Mergeddt,SystemIP)
SELECT @scandate,parentbatchNo,Childbatchno,getdate(),@SystemIP FROM @BatchList


END

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADPMerge_piEOBatch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_piEOBatch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_piEOBatch] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADPMerge_piEOBatch] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_piEOBatch] TO [DB_DMLSupport]
    AS [dbo];

