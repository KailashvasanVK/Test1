﻿CREATE Procedure  CUS_kMWEST_pAutoBatchImport
(
 @pFileName varchar(200) = ''
,@pPageCount int = 0
,@pCmpKey varchar(5)=''
,@pScanDate date=''
,@pBatchNo varchar(50)=''  
,@pFiletype int=0 
,@pDownDate date =''       
)
As
Begin
	--declare @pBatchNo varchar(75) = 'ASC-PMTEOB-AZB1-052914-1549'	
	Declare @Subclient varchar(15)=''
	declare @DownloadDate date =null
	set @Subclient =(select LEFT(@pBatchNo, 3))
	Declare @ServiceId int = 0
	Declare @ClientId int = 0
	declare @FilePath varchar(500)=''	
	Declare @IsCodingClient int = 0
	if @Subclient = 'CSP' set @ClientId = 309
	else if @Subclient = 'LIM' set @ClientId = 342
	else set @ClientId = (select ClientId from ADM_Client where ClientAcmName =@Subclient and CustomerId=5)
	
	if(ISNULL(@pDownDate,'')<>'')
	  set @DownloadDate =(SELECT CONVERT(date,@pDownDate))
	else 
	  set @DownloadDate = (select CONVERT(date,getdate()))
	
   if (@Subclient = 'BJP' or @Subclient = 'BUR' or @Subclient = 'INP' or @Subclient = 'IPA' or @Subclient = 'IPC' or @Subclient = 'JKM' or @Subclient = 'OWL' or @Subclient = 'PFA' or @Subclient = 'PTL'or @Subclient = 'SJH' or @Subclient = 'TMF')
	   Set @IsCodingClient = 1
	   
    if (select Substring(@pBatchNo,5,3))='CHG'			
			set @ServiceId= CASE WHEN @IsCodingClient = 1 then 7 else 1 end /** Coding **/		
	else if((select Substring(@pBatchNo,5,3))='PMT' or (select Substring(@pBatchNo,5,3))='DEN' or (select Substring(@pBatchNo,5,5))='NONSF')
		set @ServiceId=5 --Payment
	else  if((select Substring(@pBatchNo,5,7))='CHG-PMT' or (select Substring(@pBatchNo,5,5))='COPAY' or (select Substring(@pBatchNo,5,5))='NOTES' or (select Substring(@pBatchNo,5,3))='MED')
		set @ServiceId=1 --charge
	else  if((select Substring(@pBatchNo,5,3))='CRM')
		set @ServiceId=235 --Return Mail
	else  if((select Substring(@pBatchNo,5,3))='REF')
		set @ServiceId=287 --Project 	

	if(@ClientId <>0 and @ServiceId <>0)
	begin     
	    if(@pFiletype =1)	       
			 set @FilePath =(select 'Midwest\'+REPLACE(convert(varchar,GETDATE(),101),'/','')+'\'+'All Batches'+'\'+@pBatchNo+'.PDF')  -- FName
		else if(@pFiletype =2)	 
             set @FilePath =(select 'Midwest\'+REPLACE(convert(varchar,GETDATE(),101),'/','')+'\'+'All Batches'+'\'+@pBatchNo+'.TIF')  -- FName
       	else if(@pFiletype =3)	
       	     set @FilePath =''
       	  
       	set @pBatchNo =  LTRIM(RTRIM(@pBatchNo))
		Exec TRN_pBatchesInsert @CmpKey ='MWEST',@ScanDate=@pScanDate,@BatchNo=@pBatchNo,@FileName =@pFileName,@ClientId =@ClientId,@ServiceId=@ServiceId
		                        ,@BatchType=@pFiletype,@CreatedBy=1777,@PageCount=@pPageCount,@BatchFullName=@FilePath,@DownloadDate=@DownloadDate
	End
End









GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kMWEST_pAutoBatchImport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kMWEST_pAutoBatchImport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kMWEST_pAutoBatchImport] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kMWEST_pAutoBatchImport] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kMWEST_pAutoBatchImport] TO [DB_DMLSupport]
    AS [dbo];

