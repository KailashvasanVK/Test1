﻿CREATE Procedure  CUS_kWISCO_pCMNBatchImportAction
(
@ServiceIdCMN int=348,
@CustomerId int =23,
@DownloadDate date
)
AS 
  Begin
      if(select COUNT(*)  from TRN_kWISCO_tBatches  where convert(date,CreatedDt) >= @DownloadDate and CreatedBy =1777 and ServiceId=348)>0
	begin 
	    RAISERROR('Batch already downloaded',16,1)
        Return
	End
	Declare @DownloadDateTime datetime = Convert(datetime,Convert(varchar,@DownloadDate) + ' 09:00:00')	
	
	Update CUS_kWISCO_tCMNBatchImportTable Set ClientId = ci.ClientId,ServiceId = @ServiceIdCMN
	,BatchNo = CONVERT(varchar,t.CMNKey) + '_' + ci.ClientAcmName
	,ReqBatchNo = CONVERT(varchar,t.CMNKey) + '_' + ci.ClientAcmName
	from CUS_kWISCO_tCMNBatchImportTable as t
	inner join ADM_Client as ci on ci.CustomerId = @CustomerId and ci.ClientAcmName = t.NickName
	
	/** Pivot cmnkey_clientname **/
	if OBJECT_ID('tempdb..#tmpDownloadBatches') is not null drop table #tmpDownloadBatches
	Create table #tmpDownloadBatches(BatchNo varchar(50),ReqBatchNo varchar(50),ClientId int,ServiceId int,BatchId int) 
	Insert into #tmpDownloadBatches(BatchNo,ReqBatchNo,ClientId,ServiceId)
	Select BatchNo,ReqBatchNo,ClientId,ServiceId from CUS_kWISCO_tCMNBatchImportTable 
	group by BatchNo,ReqBatchNo,ClientId,ServiceId 
	
	/** Purge batches **/
	if OBJECT_ID('tempdb..#PurgetBatches') is not null drop table #PurgetBatches	
	Select bat.BatchId,bat.BatchGroupNo as BatchNo into #PurgetBatches 
	from TRN_kWISCO_tBatches as bat	
	Where Convert(date,CreatedDt) < CONVERT(date,getdate()) and PostedDt is null and ServiceId = @ServiceIdCMN and status = 1
	and not exists (Select 1 from #tmpDownloadBatches Where BatchNo = bat.BatchGroupNo)
	
	Insert into CUS_kwisco_tPurgeBatches(BatchId,CreatedDt)
	Select BatchId,GETDATE() from #PurgetBatches
	
	Update TRN_kWISCO_tBatches Set status = 0 
	from TRN_kWISCO_tBatches as bat
	inner join #PurgetBatches as purge on purge.BatchId = bat.BatchId
	
	/** Removing existing batches **/
	if OBJECT_ID('tempdb..#ExistsBatches') is not null drop table #ExistsBatches
	Select bat.BatchId,bat.BatchGroupNo as BatchNo into #ExistsBatches
	from TRN_kWISCO_tBatches as bat	
	Where Convert(date,CreatedDt) < CONVERT(date,getdate()) and PostedDt is null and ServiceId = @ServiceIdCMN and status = 1
	and exists (Select 1 from #tmpDownloadBatches Where BatchNo = bat.BatchGroupNo)
	
	Delete tmp from #tmpDownloadBatches tmp
	inner join #ExistsBatches as exBatch on exBatch.BatchNo = tmp.BatchNo
	
	Delete tmp from CUS_kWISCO_tCMNBatchImportTable tmp
	inner join #ExistsBatches as exBatch on exBatch.BatchNo = tmp.BatchNo
	
	/** Adding iteration based on condition **/
	Update #tmpDownloadBatches Set BatchNo = downBatch.BatchNo
	from #tmpDownloadBatches as tmp
	inner join 
	(
	Select bat.BatchGroupNo + '_' + Count(bat.BatchGroupNo) as BatchNo,bat.BatchGroupNo as ReqBatchNo
	from TRN_kWISCO_tBatches as bat	
	Where Convert(date,CreatedDt) < CONVERT(date,getdate()) and PostedDt is not null and DATEDIFF(DD,Getdate(),PostedDt) > 2  and ServiceId = @ServiceIdCMN and status = 1
	and exists (Select 1 from #tmpDownloadBatches Where BatchNo = bat.BatchGroupNo)
	Group by bat.BatchGroupNo 
	)as downBatch on downBatch.ReqBatchNo = tmp.ReqBatchNo

	/** Insert into Batches **/
	Insert into TRN_kWISCO_tBatches(ScanDate,BatchNo,ClientId,ServiceId,BatchType,CreatedBy,CreatedDt,Priority,PgCount,FName,status,QType,CreatedOn,BatchGroupNo)
	select distinct convert(date,DATEADD(DD,-1,@DownloadDate)),BatchNo,ClientId,ServiceId,3,1777,@DownloadDateTime,0,1,'',1,2,GETDATE(),ReqBatchNo 
	from #tmpDownloadBatches 	
	
	insert into TRN_kWISCO_tBatchQueue(BatchId,BatchNo,PageFrom,PageTo,Assigned,ClientId,ServiceId,StatusId,Comment,CreatedBy,CreatedDt,QType)
	
	select bat.BatchId,bat.BatchNo,1,PgCount,0,bat.ClientId,bat.ServiceId,0,'',bat.CreatedBy,CreatedDt,QType 
	from TRN_kWISCO_tbatches  bat  
	inner join #tmpDownloadBatches as tmp on tmp.BatchNo = bat.BatchNo
	Where Bat.CreatedDt = @DownloadDateTime and bat.ServiceId = @ServiceIdCMN
	
	insert into TRN_kWISCO_tBatchFlow(BatchId,BatchProcessId,CreatedDt,CreatedBy,StatusId,Comments,Ref_FlowId)
	select que.BatchId,que.BatchProcessId,que.CreatedDt,que.CreatedBy,0,'',0 
	from TRN_kWISCO_tbatches bat
	inner join #tmpDownloadBatches as tmp on tmp.BatchNo = bat.BatchNo
	inner join TRN_kWISCO_tBatchQueue que on bat.BatchId =  que.BatchId 
	Where Bat.CreatedDt = @DownloadDateTime and bat.ServiceId = @ServiceIdCMN
	
	--inner join CUS_kWISCO_tCMNBatchImportTable tmp on convert(date,DATEADD(DD,-1,tmp.DownloadDt)) =  convert(date,bat.ScanDate) and tmp.ReqBatchNo  = bat.BatchNo
	--where  bat.ServiceId =@ServiceIdCMN

	Update TRN_kWISCO_tBatchQueue set FlowId = (Select MAX(flowid) from TRN_kWISCO_tBatchFlow Where BatchProcessId = que.BatchProcessId)
	from TRN_kWISCO_tBatchQueue  as Que
	inner join TRN_kWISCO_tBatches  bat on bat.BatchId =que.BatchId and bat.ServiceId =@ServiceIdCMN 
	inner join #tmpDownloadBatches as tmp on tmp.BatchNo = bat.BatchNo
    Where Bat.CreatedDt = @DownloadDateTime and bat.ServiceId = @ServiceIdCMN
    
    Update #tmpDownloadBatches Set BatchId = bat.BatchId
    from #tmpDownloadBatches as tmp
    inner join TRN_kWISCO_tBatches  bat on bat.BatchNo =tmp.BatchNo and bat.ServiceId =@ServiceIdCMN 
    Where Bat.CreatedDt = @DownloadDateTime and bat.ServiceId = @ServiceIdCMN
    
    Update CUS_kWISCO_tCMNBatchImportTable Set BatchId = tmp.BatchId
    from CUS_kWISCO_tCMNBatchImportTable cur
    inner join #tmpDownloadBatches as tmp on tmp.ReqBatchNo = cur.ReqBatchNo    
	
  
	Declare @ServiceIdSONumber int =349
	Declare @ServiceIdSODetailProcCode int = 351
	Declare @ServiceIdInsurancePrimaryPayor int = 350
	Declare @ServiceIdCMNForm int =352
    
	insert into TRN_kWISCO_tBatchInformation(BatchId,PageNo,ServiceId,Infovalue,CreatedBy,CreatedDt,BatchServiceId,ClientId,GroupId)   
	select  BatchId,1,@ServiceIdSONumber ,SONumber,1777,GETDATE(),ServiceId,ClientId,CmnId
	from CUS_kWISCO_tCMNBatchImportTable 	
	union all
	select  BatchId,1,@ServiceIdSODetailProcCode  ,SODetailProcCode,1777,GETDATE(),ServiceId,ClientId,CmnId
	from CUS_kWISCO_tCMNBatchImportTable 
	union all
	select  BatchId,1,@ServiceIdInsurancePrimaryPayor  ,InsurancePrimaryPayor,1777,GETDATE(),ServiceId,ClientId,CmnId
	from CUS_kWISCO_tCMNBatchImportTable 
	union all
	select  BatchId,1,@ServiceIdCMNForm  ,CMNForm,1777,GETDATE(),ServiceId,ClientId,CmnId
	from CUS_kWISCO_tCMNBatchImportTable      
  End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kWISCO_pCMNBatchImportAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kWISCO_pCMNBatchImportAction] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kWISCO_pCMNBatchImportAction] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kWISCO_pCMNBatchImportAction] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kWISCO_pCMNBatchImportAction] TO [DB_DMLSupport]
    AS [dbo];

