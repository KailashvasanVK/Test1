﻿CREATE Procedure [dbo].[ADM_ExtranetCustomerServiceTATClients] 
(  
@ServiceId  INT=0,  
@CustomerId INT=0  
)  
As  
BEGIN  
 /*       
 Purpose      :select  the  client details baesed on  the customerId and ServiceId  
 Created By   : Kathiravan            
 Created Date : 22 May 2013            
 Impact to    :FactorConfig.aspx            
 */     
select cl.ClientId,cl.ClientName from ADM_ClientServices as cs  
inner join ADM_Client as cl on cl.CustomerId = @CustomerId and cl.ClientId = cs.ClientId and cs.ServiceId = @ServiceId  
where not exists (select 1 from ADM_ExtranetTAT where CustomerId = cl.CustomerId and ClientId = cs.ClientId and ServiceId = cs.ServiceId and Status=1)  
  
END


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ExtranetCustomerServiceTATClients] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ExtranetCustomerServiceTATClients] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ExtranetCustomerServiceTATClients] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ExtranetCustomerServiceTATClients] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ExtranetCustomerServiceTATClients] TO [DB_DMLSupport]
    AS [dbo];

