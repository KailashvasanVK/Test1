﻿CREATE Procedure CUS_PNEAST_CodingBatchImportInsertTable
@ScanDate  date ,
@BatchNo varchar(50) ,
@ClientName  varchar(50),

@PageCount int
as
/*
	To insert data into temp table for  North East Coding Batch Import.  
*/
Begin
Insert into Temp_CUS_PNEAST_CodingBatchImport  (ScanDate ,BatchNo ,ClientName ,ServiceId,PageCount )
Select @ScanDate ,@BatchNo,@ClientName,7,@PageCount  --  Service id  : 7  -  ServiceName : Coding   
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_PNEAST_CodingBatchImportInsertTable] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_PNEAST_CodingBatchImportInsertTable] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_PNEAST_CodingBatchImportInsertTable] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_PNEAST_CodingBatchImportInsertTable] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_PNEAST_CodingBatchImportInsertTable] TO [DB_DMLSupport]
    AS [dbo];

