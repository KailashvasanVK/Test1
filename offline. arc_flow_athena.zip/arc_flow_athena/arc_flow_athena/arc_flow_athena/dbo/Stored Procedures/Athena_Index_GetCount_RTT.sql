﻿


CREATE Proc Athena_Index_GetCount_RTT       
@userinfo varchar(50)        
-- CreatedDate : Apr 24,2015   
as          
declare @UserCnt int=0        
declare @PendingCnt int=0        
select @UserCnt=count(batchnum)  from batchIndex_TrackBatches_RT where userinfo=@userinfo and cstatus=1  and  convert(varchar,CompletedDate,101)=CONVERT(varchar,getdate(),101)        
select @PendingCnt=count(BatchId) from TRN_kOFF_tBatches where status=3 and ServiceId=363        
        
SELECT @UserCnt as UserCount,@PendingCnt as Pending

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_GetCount_RTT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_GetCount_RTT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_GetCount_RTT] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_GetCount_RTT] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_GetCount_RTT] TO [DB_DMLSupport]
    AS [dbo];

