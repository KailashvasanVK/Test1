﻿CREATE proc [dbo].[ADPMerge_CheckAvailPayerDetails] @scandate Date, @frompage int, @topage int        
as         
begin  

/*                        
                    
Cretaed By     : Leela.T                    
Created Date   : 2017-03-29                     
Purpose        : Check the available payer list for merge                   
Ticket/SCR ID  : 1195                   
TL Verified By : Udhayaganesh               
                
                 
Implemented by : Udhdyaganesh.p          
Implemented On : 10-April-2017            
                    
Reviewd by     : Udhdyaganesh.p                   
Implemented On : 10-April-2017                  
                    
*/       
select PayerName,count(trn.Batchid) as Batch from trn_koff_tbatches(nolock) trn
inner join adm_payerName (nolock) pay on pay.Payerid=trn.Payerid        
inner join trn_koff_tbatchqueue (nolock) bq on trn.batchno=bq.batchno 
inner join Arc_Athena..Batchmaster (nolock) bat on bat.batchnum=trn.batchno        
left join mergebatchdetails (nolock) mrg on trn.batchno=mrg.childbatchno 
left join TRN_kOFF_tBatchResetLog Rp on RP.batchno= trn.batchno          
where trn.status=88 and trn.scandate=@scandate and trn.posteddt is null  and  bq.assigned=0  and trn.serviceid=418                
and bq.statusid=0 and  trn.UploadDt is null and left(trn.batchno,1) not in ('M','S') and mrg.childbatchno is null                    
and bat.ULStatus is null and bat.uploaddate is null and PgCount between @frompage and @topage   and RP.batchno is null                         
group by payername      
    
  
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADPMerge_CheckAvailPayerDetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_CheckAvailPayerDetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_CheckAvailPayerDetails] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADPMerge_CheckAvailPayerDetails] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_CheckAvailPayerDetails] TO [DB_DMLSupport]
    AS [dbo];

