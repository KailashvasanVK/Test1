﻿
   
CREATE proc [dbo].[ADPMerge_GetBatchesinPayerwise] @scandate Date, @frompage int, @topage int ,@PayerName PayerNameList Readonly                 
as                     
begin       
  
/*                          
                      
Cretaed By     : Leela.T                      
Created Date   : 2017-03-29                       
Purpose        : Change the selected payer status                    
Ticket/SCR ID  : 1195                     
TL Verified By : Udhayaganesh  

Mod ID          : 001  
Modified by     : Leela.T    
Modified date   : 2017-11-24      
Request Type    : Restrict the held batches
TL Verified By  :                  
                  
                   
Implemented by : Udhdyaganesh.p            
Implemented On : 10-April-2017              
                      
Reviewd by     : Udhdyaganesh.p                     
Implemented On : 10-April-2017                    
                      
*/               
select trn.Batchno,PayerName ,PgCount from trn_koff_tbatches(nolock) trn inner join adm_payerName (nolock) pay on pay.Payerid=trn.Payerid                    
inner join trn_koff_tbatchqueue (nolock) bq on trn.batchno=bq.batchno inner join Arc_Athena..Batchmaster (nolock) bat on bat.batchnum=trn.batchno                    
left join mergebatchdetails (nolock) mrg on trn.batchno=mrg.childbatchno left join TRN_kOFF_tBatchResetLog Rp on RP.batchno= trn.batchno 
left join trn_koff_theldbatches (nolock) hld on trn.batchid=hld.batchid                   
where trn.status=88  and trn.scandate=@scandate and trn.posteddt is null  and  bq.assigned=0  and trn.serviceid=418  and (hld.Batchid is null or hld.ReleaseDate is not null)                          
and bq.statusid=0 and  trn.UploadDt is null and left(trn.batchno,1) not in ('M','S') and mrg.childbatchno is null and RP.batchno is null                                  
and bat.ULStatus is null and bat.uploaddate is null and PgCount between @frompage and @topage  and payerName in (select Payername from @PayerName)                                
                   
update   trn set trn.status=99 from   trn_koff_tbatches trn inner join adm_payerName  pay on pay.Payerid=trn.Payerid                    
inner join trn_koff_tbatchqueue bq on trn.batchno=bq.batchno inner join Arc_Athena..Batchmaster  bat on bat.batchnum=trn.batchno                    
left join mergebatchdetails  mrg on trn.batchno=mrg.childbatchno   left join TRN_kOFF_tBatchResetLog Rp on RP.batchno= trn.batchno   
left join trn_koff_theldbatches (nolock) hld on trn.batchid=hld.batchid                 
where trn.status=88   and trn.scandate=@scandate  and trn.posteddt is null  and  bq.assigned=0  and trn.serviceid=418 and (hld.Batchid is null or hld.ReleaseDate is not null)                      
and bq.statusid=0 and  trn.UploadDt is null and left(trn.batchno,1) not in ('M','S') and mrg.childbatchno is null and RP.batchno is null                                 
and bat.ULStatus is null and bat.uploaddate is null and PgCount between @frompage and @topage  and  payerName in (select Payername from @PayerName)                                  
                    
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADPMerge_GetBatchesinPayerwise] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_GetBatchesinPayerwise] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_GetBatchesinPayerwise] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADPMerge_GetBatchesinPayerwise] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_GetBatchesinPayerwise] TO [DB_DMLSupport]
    AS [dbo];

