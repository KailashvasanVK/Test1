﻿


Create Procedure [dbo].[ADM_ProfileAccessServicesInsert]   
@UserIdCollection varchar(max) = '' , 
@CustomerId int,   
@ServiceIdCollection varchar(max) = '' , 
--@processTarget int,     
@IsScheduled int  ,
@ShuDateTime datetime,      
--@QcTarget int,      
--@QaTarget int,      
@CreatedBy  int    
As   
/*   
Created by : Karthik M7   
Created on : 2 FEB 2015   
Impact to  : ProfileSetup.aspx   
Purpose    : To save the user customer wise service details.   
*/  
Begin  
	IF(@IsScheduled = 0)
	BEGIN

		Insert into ADM_AccessServices(UserId,CustomerId,ServiceId,CreatedBy)  
		select a.items,@CustomerId,b.items,@CreatedBy   from fnSplitString(@UserIdCollection,',') a, fnSplitString(@ServiceIdCollection,',') b


		insert into ADM_AccessTarget(Userid,CustomerId,ServiceId,ProcessTargetId,QcTargetId,PTLevelId,QCLevelId,CreatedBy,CreatedDt) 
		select a.items,@CustomerId,b.items,0,0,0,0,@CreatedBy,GETDATE()   
		from fnSplitString(@UserIdCollection,',') a, fnSplitString(@ServiceIdCollection,',') b
		where not exists (select 'X' from ADM_AccessTarget where Userid = CAST(a.items as int) and ServiceId = CAST(b.items as int) and CustomerId = @CustomerId )  


		insert into ADM_AccessTargetQC(Userid,CustomerId,ServiceId,QualityTargetId,QALevelId,CreatedBy ,CreatedDt)          
		Select a.items,@CustomerId,b.items,0,0,@CreatedBy,GETDATE() 
		from fnSplitString(@UserIdCollection,',') a, fnSplitString(@ServiceIdCollection,',') b
		where not exists (select 'X' from ADM_AccessTargetQC where Userid = CAST(a.items as int) and ServiceId = CAST(b.items as int) and CustomerId = @CustomerId )  
	END
	ELSE
	BEGIN
		IF OBJECT_ID('tempdb..#TempAccessTarget') IS NOT NULL DROP TABLE #TempAccessTarget
		
		
		select CAST(items as int) as USERID,@CustomerId as CustomerId Into #TempAccessTarget from fnSplitString(@UserIdCollection,',')   
		
		INSERT Into ADM_AccessServicesScheduleLog(UserId,CustomerId,ServiceId,ScheduledDt,CreatedBy,CreatedDt,LogCreatedDt,StatusInfo)
		SELECT      TempACTG.USERID, ACTG.CustomerId , ServiceId, ScheduledDt,  CreatedBy, CreatedDt,GETDATE(),'Deleted' FROM  ADM_AccessServicesSchedule ACTG
		Inner Join #TempAccessTarget TempACTG on TempACTG.USERID = ACTG.USERID and TempACTG.CustomerId  = ACTG.CustomerId 
		
		
		DELETE ACTG FROM [ADM_AccessServicesSchedule] ACTG
       INNER JOIN #TempAccessTarget TempACTG
       ON TempACTG.USERID = ACTG.USERID and TempACTG.CustomerId  = ACTG.CustomerId 
		
		Insert into [ADM_AccessServicesSchedule] (UserId,CustomerId,ServiceId ,ScheduledDt ,CreatedBy,CreatedDt)  
		select a.items,@CustomerId,b.items,@ShuDateTime,@CreatedBy,GETDATE()   from fnSplitString(@UserIdCollection,',') a, fnSplitString(@ServiceIdCollection,',') b
		
		
		IF OBJECT_ID('tempdb..#TempAccessTarget') IS NOT NULL DROP TABLE #TempAccessTarget
	
	END
	
	
	
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ProfileAccessServicesInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileAccessServicesInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileAccessServicesInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ProfileAccessServicesInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileAccessServicesInsert] TO [DB_DMLSupport]
    AS [dbo];

