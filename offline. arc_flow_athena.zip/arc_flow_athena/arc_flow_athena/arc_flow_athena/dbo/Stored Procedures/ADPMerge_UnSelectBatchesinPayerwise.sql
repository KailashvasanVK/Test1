﻿  
CREATE proc [dbo].[ADPMerge_UnSelectBatchesinPayerwise] @scandate Date, @frompage int, @topage int ,@PayerName PayerNameList Readonly        
as    
begin  



/*                        
                    
Cretaed By     : Leela.T                    
Created Date   : 2017-04-10                     
Purpose        : Change the Unselected payer status                  
Ticket/SCR ID  : 1195                   
TL Verified By : Udhayaganesh               
                
                 
Implemented by : Udhdyaganesh.p          
Implemented On : 10-April-2017            
                    
Reviewd by     : Udhdyaganesh.p                   
Implemented On : 10-April-2017                   
                    
*/            
   
if(object_id('tempdb.dbo.#Batchdets')is not null)                                                              
drop table #Batchdets                     
Create table #Batchdets (Batchno varchar(30))    
    
insert into #Batchdets    
select trn.Batchno from trn_koff_tbatches(nolock) trn 
inner join adm_payerName (nolock) pay on pay.Payerid=trn.Payerid        
inner join trn_koff_tbatchqueue (nolock) bq on trn.batchno=bq.batchno 
inner join Arc_Athena..Batchmaster (nolock) bat on bat.batchnum=trn.batchno        
left join mergebatchdetails (nolock) mrg on trn.batchno=mrg.childbatchno 
left join TRN_kOFF_tBatchResetLog Rp on RP.batchno= trn.batchno    
where trn.status=99 and trn.scandate=@scandate and trn.posteddt is null  
and  bq.assigned=0  and trn.serviceid=418   and RP.batchno is null                  
and bq.statusid=0 and  trn.UploadDt is null and left(trn.batchno,1) not in ('M','S') 
and mrg.childbatchno is null and RP.batchno is null                 
and bat.ULStatus is null and bat.uploaddate is null 
and PgCount between @frompage and @topage  and payerName in (select PayerName from @PayerName )                        
    
update   trn_koff_tbatches set status=88  where batchno  in (select Batchno from  #Batchdets)   

select Batchno from  #Batchdets                    

drop table #Batchdets     
           
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADPMerge_UnSelectBatchesinPayerwise] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_UnSelectBatchesinPayerwise] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_UnSelectBatchesinPayerwise] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADPMerge_UnSelectBatchesinPayerwise] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADPMerge_UnSelectBatchesinPayerwise] TO [DB_DMLSupport]
    AS [dbo];

