﻿
CREATE Proc CurrentBatchStatus                  
as                 
Delete from Status                
insert into Status (cnt,scandate,stat)                  
select count(batchid) as 'cnt'  ,scandate,'EntryPending' as  'status'  from trn_koff_tbatches (nolock) where posteddt is null and serviceid<>363 and status in(1,99)                  
and scandate>'2015-02-21'    and   LEFT(batchno,1) not in('M','S')                
group by scandate                  
union                    
select count(batchid) as 'cnt' ,scandate,'IndexPending'  as  'status' from trn_koff_tbatches (nolock) where posteddt is null and serviceid<>363 and status=3                  
and scandate>'2015-02-21'                  
group by scandate                  
union                 
select COUNT(batchno),scandate ,'MergePending' as 'status'from trn_koff_tbatches (nolock) a                   
inner join arc_athena..batchmaster(nolock) b on a.batchno=b.batchnum   where                     
 posteddt is null  and status=1 and LEFT(batchno,1) ='M'    
and scandate>'2015-02-21'                  
group by scandate       
union               
select COUNT(batchno),scandate ,'SubclientMergePending' as 'status'from trn_koff_tbatches (nolock) a                   
inner join arc_athena..batchmaster(nolock) b on a.batchno=b.batchnum   where                     
 posteddt is null  and status=1 and LEFT(batchno,1) ='S'    
and scandate>'2015-02-21'                  
group by scandate                  
union                    
select count(batchid) as 'cnt' ,scandate,'QCPending'  as  'status' from trn_koff_tbatches (nolock) where posteddt is not null                   
and UploadDt is null and serviceid<>363 and status=1                  
and scandate>'2015-02-21'                  
group by scandate          
union           
               
select count(batchid) as 'cnt' ,scandate,'UploadPending'  as  'status' from trn_koff_tbatches (nolock) a                   
inner join arc_athena..batchmaster(nolock) b on a.batchno=b.batchnum   where                     
 UploadDt is not null and ulstatus is null and serviceid<>363 and status=1                  
and scandate>'2015-02-21'                  
group by scandate                  
union        
 Select  count(Bat.Batchno) as 'cnt' , bat.scandate,'Waiting_MergeExtract' as 'Status'                         
 from Arc_Flow_Athena..TRN_kOFF_tBatches (nolock) as Bat                                 
 inner join Arc_Flow_Athena..TRN_kOFF_tBatchFlow (nolock) as FteStFlow on FteStFlow.BatchId = Bat.BatchId and FteStFlow.StatusId = 1                                
 inner join Arc_Flow_Athena..TRN_kOFF_tBatchFlow (nolock) as Flow on Flow.BatchId = Bat.BatchId and Flow.StatusId = 6                                
 Where Bat.status = 20              
 group by bat.scandate        
Union                     
select count(b.batchno) as 'cnt' ,b.scandate , 'MergeIssue' as 'Status' from mergebatchdetails (nolock) a right outer join arc_flow_athena..trn_koff_tbatches (nolock) b on b.batchno=a.childbatchno             
where  b.status=99  and LEFT(batchno,1) not in('M','S')         
and a.childbatchno is null            
group by b.scandate                 
union         
select COUNT(batchno),scandate ,'Child_Inside_Merge' as 'status'from trn_koff_tbatches (nolock) a                   
inner join arc_athena..batchmaster(nolock) b on a.batchno=b.batchnum   where                     
 posteddt is null  and status=99 and LEFT(batchno,1) not in('M','S')                  
and scandate>'2015-02-21'                  
group by scandate                  
        
        
                  
select Convert(varchar(10),scandate,101), isnull(indexPending,0),isnull(EntryPending,0),isnull(MergePending,0),isnull(SubclientMergePending,0),    
isnull(Child_Inside_Merge,0),        
isnull(QCPending,0),isnull(UploadPending,0) ,        
     isnull(Waiting_MergeExtract,0),        
     isnull(MergeIssue,0)        
from              
(              
  select scandate,cnt,stat              
  from Status               
) d              
pivot              
(              
max(cnt)              
  for stat in ( indexPending, EntryPending,MergePending, SubclientMergePending,Child_Inside_Merge,QCPending,UploadPending,Waiting_MergeExtract,MergeIssue)              
) piv;               



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CurrentBatchStatus] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CurrentBatchStatus] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CurrentBatchStatus] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CurrentBatchStatus] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CurrentBatchStatus] TO [DB_DMLSupport]
    AS [dbo];

