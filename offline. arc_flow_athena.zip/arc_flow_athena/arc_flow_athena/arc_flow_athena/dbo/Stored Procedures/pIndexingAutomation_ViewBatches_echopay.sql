﻿
CREATE PROCEDURE pIndexingAutomation_ViewBatches_echopay            
(            
@UserInfo varchar(50)            
)            
As     
/*                
Created By     : Gobinath.M                            
Created Date   : 2015-07-21              
Purpose        : To Show the transaction in Indexing Application                            
Ticket/SCR ID  :              
TL Verified By : Ramakrishnan.G              
              
Implemented On : Ganesh             
Implemented On : 28-April-2016          
Reviewed by    : Ganesh             
Reviewed On    : 28-April-2016          
*/                       
Begin             
            
SELECT  BatchID, BatchNo, tb.ScanDate AS ScanDate, b.dollarAmt As DollarAmount,ISNULL(Adm.PayerId , 0) As InsuranceName, '' As Automation,
ClientType = (Select Top 1 Category from ARC_ATHENA.dbo.SubClient_Info (nolock)
Where SubClient = SUBSTRING(tb.BatchNo,CHARINDEX('A',tb.BatchNo)+1,(LEN(tb.BatchNo)-CHARINDEX('A',tb.BatchNo))+1)),
'' AS TaxID, '' AS NPID, '' AS PayeeNo,  FName,'' As CheckDate, 0 As Complete,
SubClient = SUBSTRING(tb.BatchNo,CHARINDEX('A',tb.BatchNo)+1,(LEN(tb.BatchNo)-CHARINDEX('A',tb.BatchNo))+1)
from dbo.POFF_Batchindex_EchoPay trb
Inner join TRN_kOFF_tBatches (nolock) tb on tb.BatchNo = trb.batchnum
Inner join ADM_PayerName(nolock) Adm on Adm.PayerID = tb.PayerID
Inner join ARC_Athena..BatchMaster(nolock) b on b.batchNum = tb.BatchNo
Where  trb.userinfo = @UserInfo
            
END
GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexingAutomation_ViewBatches_echopay] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[pIndexingAutomation_ViewBatches_echopay] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexingAutomation_ViewBatches_echopay] TO [DB_DMLSupport]
    AS [dbo];

