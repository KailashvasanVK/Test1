﻿CREATE Procedure [dbo].[ADM_ExtranetTATConfigActionsInsert]
(    
@Action varchar(100)='',   
@CustomerId INT=0,
@ClientId INT=0,
@ServiceId INt=0,    
@TatDuration int='',    
@EffectiveFrom varchar(50)='',  
@CreatedBy INT=0,    
@TatId int=0,  
@TID INT OUTPUT       
  
)    
AS    
BEGIN    
IF(@Action ='InsertTAT')        
 BEGIN   
if(select COUNT(*) from ADM_ExtranetTAT where  ServiceId=0 and CustomerId =@CustomerId) = 0 
   Begin
		INSERT INTO ADM_ExtranetTAT(CustomerId,ClientId,ServiceId,TAT_Duration,EffectiveFrom,CreatedBy)    
		Select @CustomerId,0,isnull(@ServiceId,0),@TatDuration,convert(varchar,@EffectiveFrom,101),@CreatedBy  
		SELECT @TID = IDENT_CURRENT('ADM_ExtranetTAT')   
   End
else if(select COUNT(*) from ADM_ExtranetTAT where ServiceId=@ServiceId and CustomerId =@CustomerId) = 0 
   Begin
       INSERT INTO ADM_ExtranetTAT(CustomerId,ClientId,ServiceId,TAT_Duration,EffectiveFrom,CreatedBy)    
		Select @CustomerId,0,isnull(@ServiceId,0),@TatDuration,convert(varchar,@EffectiveFrom,101),@CreatedBy  
		SELECT @TID = IDENT_CURRENT('ADM_ExtranetTAT')   
   End 
else if(select COUNT(*) from ADM_ExtranetTAT where  ServiceId=@ServiceId and CustomerId =@CustomerId) = 0 
   Begin
       INSERT INTO ADM_ExtranetTAT(CustomerId,ClientId,ServiceId,TAT_Duration,EffectiveFrom,CreatedBy)    
		Select @CustomerId,0,isnull(@ServiceId,0),@TatDuration,convert(varchar,@EffectiveFrom,101),@CreatedBy  
		SELECT @TID = IDENT_CURRENT('ADM_ExtranetTAT')   
   End 
 END   
Else IF(@Action ='')
  Begin
     select COUNT(*) from ADM_ExtranetTAT  
  End 
END


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ExtranetTATConfigActionsInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ExtranetTATConfigActionsInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ExtranetTATConfigActionsInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ExtranetTATConfigActionsInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ExtranetTATConfigActionsInsert] TO [DB_DMLSupport]
    AS [dbo];

