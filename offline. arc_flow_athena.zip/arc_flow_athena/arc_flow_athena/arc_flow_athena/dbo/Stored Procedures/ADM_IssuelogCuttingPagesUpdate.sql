﻿CREATE Procedure [dbo].[ADM_IssuelogCuttingPagesUpdate]
							@Id int
							,@OutMsg varchar(500) = ''
	as
	Begin
		UPDATE ADM_IssuelogPages SET Status = 1,OutMsg = @OutMsg,UpdatedDt = GETDATE()  WHERE Id = @Id 
	End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_IssuelogCuttingPagesUpdate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_IssuelogCuttingPagesUpdate] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_IssuelogCuttingPagesUpdate] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_IssuelogCuttingPagesUpdate] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_IssuelogCuttingPagesUpdate] TO [DB_DMLSupport]
    AS [dbo];

