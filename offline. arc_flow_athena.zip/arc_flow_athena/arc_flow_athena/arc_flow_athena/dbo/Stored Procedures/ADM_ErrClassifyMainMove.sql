﻿CREATE Procedure [dbo].[ADM_ErrClassifyMainMove]  
@ClassifyId  int   
As  
/*  
    Purpose   : Move the Error classify data while update  
    Created By   : Karthik IC    
    Created Date : 12 June 2013    
    Impact to    : ErrorClassification.aspx    
*/  
Begin  
if exists(select top 1 'x' from ADM_ErrClassifyMain where ClassifyId = @ClassifyId )  
Begin  
Insert into ADM_ErrClassifyMainLog  (ClassifyId,ClassifyName,Status,CreatedBy,CreatedDt )  
Select ClassifyId,ClassifyName,Status,CreatedBy,CreatedDt from ADM_ErrClassifyMain where ClassifyId = @ClassifyId   
Delete from ADM_ErrClassifyMain where ClassifyId = @ClassifyId   
End  
if exists(select top 1 'x' from ADM_ErrClassifyGroup  Where ClassifyId = @ClassifyId )  
Begin
insert into ADM_ErrClassifyGroupLog  (ClassifyGroupId,ClassifyId,SubClassifyId,CreatedBy,CreatedDt)
select ClassifyGroupId,ClassifyId,SubClassifyId,CreatedBy,CreatedDt from ADM_ErrClassifyGroup Where ClassifyId = @ClassifyId
Delete from ADM_ErrClassifyGroup Where ClassifyId = @ClassifyId   
End 
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ErrClassifyMainMove] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ErrClassifyMainMove] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ErrClassifyMainMove] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ErrClassifyMainMove] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ErrClassifyMainMove] TO [DB_DMLSupport]
    AS [dbo];

