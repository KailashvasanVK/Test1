﻿

CREATE  Procedure ADM_ProfileTargetConfiguration

@ServiceId  int  = 0,
@customerid  int = 0,
@UserIdCollection  varchar(max) 


As

Begin

		IF OBJECT_ID('tempdb..#TempuserProfileSetupUser') IS NOT NULL DROP TABLE #TempuserProfileSetupUser
		Create Table #TempuserProfileSetupUser (RowID int identity(1,1) not null,UserId int not null)

		Insert into #TempuserProfileSetupUser (USERID)
		select items  from fnSplitString(@UserIdCollection,',')

		
		
	
		Select distinct  x.UserId,
		
	 (	select NT_USERNAME from  ARC_REC_Athena..ARC_REC_USER_INFO where UserId = X.UserId and  ACTIVE= 1 and AHS_PRL='Y' ) as NT_USERNAME,
		
		isnull(procTgt.AccTargetId,0) as AccTargetId  ,ser.ServiceName
		,(Case when isnull(procA.Functionality,'') = '' then '' else procTgtMas.TargetName end) as ProcessTarget

		,(Case when isnull(procA.Functionality,'') = '' then '' else procQcTgtMas.TargetName  
		+ ' [ '+ cast(cast(isnull(procTgt.ErrorPercentage,0) as int )  as varchar) + '% ]' 
		end ) as QcTarget
		/* karthik add error percentage here 01 oct 2013) */

		,Case when isnull(qcA.Functionality,'') = '' then '' else qcTgtMas.TargetName end as QaTarget
		,isnull(qcTgt.AccTargetId,0) as QCAccTargetId
		from  
		(  
		--------Select turs.UserId,ServiceId,CustomerId from adm_AccessClient ac
		--------inner join #TempuserProfileSetupUser  turs on ac.UserId = turs.UserId
		--------Where CustomerId = @customerid --and UserId = @userid
		--------and ServiceId = @ServiceId
		--------Group by turs.UserId,ServiceId,CustomerId
			Select turs.UserId,ServiceId,CustomerId from ADM_AccessServices ac
		inner join #TempuserProfileSetupUser  turs on ac.UserId = turs.UserId
		Where CustomerId = @customerid --and UserId = @userid
		and ServiceId = @ServiceId
		Group by turs.UserId,ServiceId,CustomerId
		)x
		inner join ADM_Service as ser on  ser.ServiceId = @ServiceId 
		left join ADM_AccessFunctionality as procA on procA.UserId = x.UserId  and procA.Functionality = 'P'  -- put cmd here karthik
		left join ADM_AccessFunctionality as qcA on qcA.UserId = x.UserId  and  qcA.Functionality = 'A'   -- put cmd here kartihk
		left join ADM_AccessTarget as procTgt on procTgt.CustomerId = x.CustomerId and procTgt.UserId = x.UserId and procTgt.ServiceId = @ServiceId
		left join ADM_ProcessTarget as procTgtMas on procTgtMas.TargetId = procTgt.ProcessTargetId
		left join ADM_QcTarget as procQcTgtMas on procQcTgtMas.TargetId = procTgt.QcTargetId
		left join ADM_AccessTargetQC as qcTgt on qcTgt.CustomerId = x.CustomerId and qcTgt.UserId = x.UserId and qcTgt.ServiceId = @ServiceId
		left join ADM_QaTarget as qcTgtMas on qcTgtMas.TargetId = qcTgt.QualityTargetId 
		Where  x.customerid =  @customerid and ser.Status  = 1
		
		
		
		
		
		
		IF OBJECT_ID('tempdb..#TempuserProfileSetupUser') IS NOT NULL DROP TABLE #TempuserProfileSetupUser
		
		
		
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ProfileTargetConfiguration] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileTargetConfiguration] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileTargetConfiguration] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ProfileTargetConfiguration] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ProfileTargetConfiguration] TO [DB_DMLSupport]
    AS [dbo];

