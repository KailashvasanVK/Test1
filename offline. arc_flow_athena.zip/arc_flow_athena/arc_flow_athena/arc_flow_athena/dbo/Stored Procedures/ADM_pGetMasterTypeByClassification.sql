﻿

CREATE PROCedure [dbo].[ADM_pGetMasterTypeByClassification]
(
@Classification varchar(100)
)
As
Begin
SELECT * FROM ADM_MasterTypes (nolock)  where Active=1 and Classification=@Classification

End



GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pGetMasterTypeByClassification] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_pGetMasterTypeByClassification] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_pGetMasterTypeByClassification] TO [DB_DMLSupport]
    AS [dbo];

