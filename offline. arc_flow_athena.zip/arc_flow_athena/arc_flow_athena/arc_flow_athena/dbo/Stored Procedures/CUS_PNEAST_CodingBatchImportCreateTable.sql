﻿CREATE Procedure CUS_PNEAST_CodingBatchImportCreateTable
AS    
/*    
 To create a temp table for  WISCO ERN Batch Import.      
*/    
Begin    
if OBJECT_ID('Temp_CUS_PNEAST_CodingBatchImport') is not null Drop table Temp_CUS_PNEAST_CodingBatchImport    
Create table  Temp_CUS_PNEAST_CodingBatchImport (ScanDate date,BatchNo varchar(50),ClientId int,ClientName varchar(75),ServiceId int,ServiceName varchar(75),Status varchar(50),PageCount int)
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_PNEAST_CodingBatchImportCreateTable] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_PNEAST_CodingBatchImportCreateTable] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_PNEAST_CodingBatchImportCreateTable] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_PNEAST_CodingBatchImportCreateTable] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_PNEAST_CodingBatchImportCreateTable] TO [DB_DMLSupport]
    AS [dbo];

