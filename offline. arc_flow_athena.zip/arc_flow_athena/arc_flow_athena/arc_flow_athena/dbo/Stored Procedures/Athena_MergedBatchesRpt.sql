﻿create proc Athena_MergedBatchesRpt @Fromdate varchar(10), @Todate varchar(10)
as 
begin

/*Creted by:Leela.T
Created on:10/26/2015
Purpose :Get the  Merge Batch Count and Percentage Details*/

create table #BatchCountdets (Scandate varchar(10),BatchCount int ,Details varchar(30)) 
create table #MergedPercentage (Scandate varchar(10),ReceivedBathces float ,MergedBatches float, MergePercentage Float) 
insert into #BatchCountdets(Scandate,BatchCount,Details)
select Scandate,COUNT(batchno) , 'Batchcnt' as 'Details' from trn_koff_tbatches where ScanDate between @Fromdate and  @Todate and LEFT(batchno,1) not in ('S','M')
and ServiceId<>363 group by ScanDate
union 
select Scandate,COUNT(childbatchno), 'ChildBatchcount' as 'Details'  from mergebatchdetails mrg inner join trn_koff_tbatches trn on mrg.ChildBatchNo=trn.BatchNo
where ScanDate between @Fromdate and  @Todate and LEFT(batchno,1) not in ('S','M')
and ServiceId<>363  group by ScanDate


insert into #MergedPercentage (Scandate,ReceivedBathces,MergedBatches)
select Convert(varchar(10),scandate,101)as  scandate, isnull(Batchcnt,0) as BatchCount ,isnull(ChildBatchcount,0) as ChildBatchcount 
from                
(                
  select scandate,BatchCount,Details                
  from #BatchCountdets                 
) d
pivot                
(                
max(BatchCount)                
  for Details in (Batchcnt,ChildBatchcount)
) piv;                 
  
drop table #BatchCountdets

update #MergedPercentage set MergePercentage=Round(((MergedBatches/ReceivedBathces)*100),2)

select * from #MergedPercentage

drop table #MergedPercentage

End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_MergedBatchesRpt] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_MergedBatchesRpt] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_MergedBatchesRpt] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_MergedBatchesRpt] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_MergedBatchesRpt] TO [DB_DMLSupport]
    AS [dbo];

