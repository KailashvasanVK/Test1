﻿CREATE Procedure [dbo].[ADM_ErrClassifySubInsert] 
@SubClassifyName varchar(50),
@Status bit,
@ClassifyIds varchar(max),

@CreatedBy int 
as
/*
    Purpose		 :	Insert the Main Error sub classify details.
    Created By   :	Karthik IC
    Created Date :	12 June 2013
    Impact to    :	ErrorClassification.aspx
*/
Begin
Insert into ADM_ErrClassifySub (SubClassifyName,Status,CreatedBy)
Select @SubClassifyName,@Status,@CreatedBy

Declare @subClassifyId  int = (SELECT IDENT_CURRENT ('ADM_ErrClassifySub'));
Insert into ADM_ErrClassifyGroup (ClassifyId,SubClassifyId,CreatedBy)
Select  items ,@subClassifyId,@CreatedBy from  dbo.fnSplitString(@ClassifyIds,',') 
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ErrClassifySubInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ErrClassifySubInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ErrClassifySubInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ErrClassifySubInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ErrClassifySubInsert] TO [DB_DMLSupport]
    AS [dbo];

