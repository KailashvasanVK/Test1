﻿CREATE Proc Athena_Index_Insert_CheckInfo(@batchno varchar(20),@NPI varchar(30),@TaxID varchar(30),@Payeeno varchar(30),@DollarAmt money,@CheckNo varchar(50)=NULL,@CheckAmt money=NULL,@CheckDate datetime=NULL)                      
as                      
/*This SP willl Update the batch for indexing the batch for TaxID,NPI,Dollaramt and Payeeno*/                      
/*Create By Ramakrishnang. Aug 7th 2014        
        
UPDlock added by udhayaganesh - To avoid deadlock        
*/                      
If Exists (SELECT 1 from Athena_Index_BatchWithPayorInfo where  BatchNo=@BatchNo)        
BEGIN        
      UPDATE arc_athena..BatchMaster SET Dollaramt=@Dollaramt,NPIID=ltrim(rtrim(@NPI)),TaxID=ltrim(rtrim(@TaxID)),PAYEENUMBER=ltrim(rtrim(@Payeeno)) Where Batchnum = @BatchNo        
END     
                      
If exists(Select Batchid from trn_koff_tbatches with (updlock)     
where uploaddt  is null and serviceid<>363 and status=3 and batchno=@batchno)                      
                      
Begin                       
                     
      Update arc_athena..BatchMaster  set Dollaramt=@Dollaramt,NPIID=ltrim(rtrim(@NPI)),TaxID=ltrim(rtrim(@TaxID)),PAYEENUMBER=ltrim(rtrim(@Payeeno)) Where Batchnum=@Batchno            
      --,CheckNo=@CheckNo,CheckAmt=@CheckAmt,CheckDate=@CheckDate                        
      Update trn_koff_tbatches set Status=1 where Batchno=@batchno and Status=3                    
      Update batchIndex_TrackBatches  set cstatus=1,CompletedDate=GETDATE() where batchnum=@batchno                     
		--------------------------       
		Update arc_flow_athena..trn_koff_tbatchQueue set serviceid = 385 where right (@batchno,6)='A11284' 
		Update arc_flow_athena..trn_koff_tbatches set serviceid = 385 where right (@batchno,6)='A11284'  

		Update arc_flow_athena..trn_koff_tbatchQueue set serviceid = 385 where right (@batchno,6)='A11938' 
		Update arc_flow_athena..trn_koff_tbatches set serviceid = 385 where right (@batchno,6)='A11938'  
		----------------------------                   
End       

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_Insert_CheckInfo] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_Insert_CheckInfo] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_Insert_CheckInfo] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_Insert_CheckInfo] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_Insert_CheckInfo] TO [DB_DMLSupport]
    AS [dbo];

