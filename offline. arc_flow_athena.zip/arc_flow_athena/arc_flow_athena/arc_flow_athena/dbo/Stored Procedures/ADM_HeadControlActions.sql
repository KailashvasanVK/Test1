﻿CREATE Procedure  [dbo].[ADM_HeadControlActions]    
(    
@Action varchar(100)    
,@CustomerId int    
,@UserId int    
)    
AS    
BEGIN    
 /*     
      
    Created By   : Kathiravan          
    Created Date : 30 April 2013          
    Impact to    :ManualBatchCreation.aspx          
 */   
 Declare @CmpKey varchar(20)
 
 set @CmpKey = (Select isnull((Select CmpKey from ADM_Customer where CustomerId = ui.LastCustomerId),'')    
 from ARC_REC_Athena..ARC_REC_USER_INFO as ui where USERID = @UserId )
       
  IF @Action = 'UpdateLastCompanyId'  
  /* Purpose      :Updating the LastCustomerId into ARC_REC_Athena..ARC_REC_USER_INFO   */    
 update ARC_REC_Athena..ARC_REC_USER_INFO set LastCustomerId = @CustomerId where USERID = @UserId    
     
  IF @Action = 'GetLastCompanyId'    
  /* Purpose      :selecting the CmpKey and LastCustomerId for the USERID  */    
 Select isnull(LastCustomerId,0)LastCustomerId,oBJECT_ID('TRN_k'+@CmpKey+'_tBatches') as ObjectId    
 ,isnull((Select CmpKey from ADM_Customer where CustomerId = ui.LastCustomerId),'') as CmpKey    
 from ARC_REC_Athena..ARC_REC_USER_INFO as ui where USERID = @UserId  
 
 
  
 --select OBJECT_ID('TRN_k'+@CmpKey+'_tBatches')  
     
END


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_HeadControlActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_HeadControlActions] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_HeadControlActions] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_HeadControlActions] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_HeadControlActions] TO [DB_DMLSupport]
    AS [dbo];

