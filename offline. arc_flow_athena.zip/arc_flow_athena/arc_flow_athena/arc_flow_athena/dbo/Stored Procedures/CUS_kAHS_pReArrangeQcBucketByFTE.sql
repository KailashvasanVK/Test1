﻿CREATE Procedure CUS_kAHS_pReArrangeQcBucketByFTE(@FteId int)
As
Begin
/**
CreatedBy : Mohamed Safiyullah
Purpose : Random qc after completion of 10 process.
Customer : AHS (CMN, SalesOrderBin)
**/
if (Select COUNT(*) from TRN_kAHS_tProcessedBatches Where FTE_Id = @FteId and QcRequiredStatus = 0) = 10
	Begin
	if OBJECT_ID('tempdb..#QcProcess') is not null drop table #QcProcess
	Select Top 10 BatchProcessId,CONVERT(int,2) as QcBatch,QcPer into #QcProcess 
	from TRN_kAHS_tProcessedBatches Where FTE_Id = @FteId and QcRequiredStatus = 0 Order by BatchProcessId
	Declare @QcTarget Decimal(9,2)		
	Select Top 1 @QcTarget  = QcPer from #QcProcess
	Declare @QcBatches int = Floor(@QcTarget/10.0)
	Declare @qry varchar(max)
	Set @qry = 'Update #QcProcess Set QcBatch = 1 Where BatchProcessId = (select Top ' + Convert(varchar,@QcBatches) + ' BatchProcessId from #QcProcess Order by NEWID())'
	Exec (@qry)
	Update qcBatch Set QcRequiredStatus = tmp.QcBatch 
	from TRN_kAHS_tProcessedBatches as qcBatch
	inner join #QcProcess as tmp on tmp.BatchProcessId = QcBatch.BatchProcessId
	
	Insert into TRN_kAHS_tBatchFlow(BatchId,BatchProcessId,CreatedDt,CreatedBy,StatusId,Comments)
	Select tmp.BatchProcessId,q.BatchId,GETDATE(),1777,13,'Direct upload from ReArrangeQcInbox' 
	from #QcProcess as tmp		
	inner join TRN_kAHS_tBatchQueue as q on q.BatchProcessId = tmp.BatchProcessId		
	inner join TRN_kAHS_tBatches as bat on bat.BatchId = q.Batchid and bat.UploadDt is not null
	Where tmp.QcBatch = 2
	
	Update TRN_kAHS_tBatchQueue Set StatusId = 13,FlowId = (Select MAX(FlowId) from TRN_kAHS_tBatchFlow Where BatchProcessId = q.BatchProcessId and StatusId = 13)
	from TRN_kAHS_tBatchQueue as q
	inner join TRN_kAHS_tBatches as bat on bat.BatchId = q.Batchid and bat.UploadDt is not null
	inner join #QcProcess as tmp on tmp.BatchProcessId = q.BatchProcessId and tmp.QcBatch = 2
	
	Update bat Set UploadDt = GETDATE()
	from TRN_kAHS_tBatches as bat
	inner join TRN_kAHS_tBatchQueue as q on q.BatchId = bat.BatchId
	inner join #QcProcess as tmp on tmp.BatchProcessId = q.BatchProcessId and tmp.QcBatch = 2
	if OBJECT_ID('tempdb..#QcProcess') is not null drop table #QcProcess
	End
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kAHS_pReArrangeQcBucketByFTE] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kAHS_pReArrangeQcBucketByFTE] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kAHS_pReArrangeQcBucketByFTE] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[CUS_kAHS_pReArrangeQcBucketByFTE] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[CUS_kAHS_pReArrangeQcBucketByFTE] TO [DB_DMLSupport]
    AS [dbo];

