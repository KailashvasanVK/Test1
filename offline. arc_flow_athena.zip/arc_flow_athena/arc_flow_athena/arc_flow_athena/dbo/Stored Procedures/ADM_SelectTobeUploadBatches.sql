﻿CREATE Procedure  ADM_SelectTobeUploadBatches
as
 begin
   select FName,BatchId from ADM_ToBeUploadTran where status=0
 end


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_SelectTobeUploadBatches] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_SelectTobeUploadBatches] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_SelectTobeUploadBatches] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_SelectTobeUploadBatches] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_SelectTobeUploadBatches] TO [DB_DMLSupport]
    AS [dbo];

