﻿CREATE Proc Athena_Index_GetCount          
@userinfo varchar(50)          
/* Created By Noor */         
as    
Begin
declare @UserCnt int=0          
declare @PendingCnt int=0          
select @UserCnt=count(batchnum)  from batchIndex_TrackBatches (nolock)   
 where userinfo=@userinfo and cstatus=1  and  convert(date,CompletedDate)=CONVERT(date,getdate())          
select @PendingCnt=count(BatchId) from TRN_kOFF_tBatches (nolock)   
 where status=3 and ServiceId<>363          
          
SELECT @UserCnt as UserCount,@PendingCnt as Pending 

end
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_GetCount] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_GetCount] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_GetCount] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Athena_Index_GetCount] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Athena_Index_GetCount] TO [DB_DMLSupport]
    AS [dbo];

