﻿   
   
Create Proc AthenaIndex_GetUserProducionWithDuration_Report_RTT    
@gDate datetime=NULL    
as    
/*      
Purpose : Get Consolidate production by User _ BatchIndexing  for RT  
Created Date : May 19,2015     
Purpose : To get user working hours and batchcount     
exec AthenaIndex_GetProduction_HourlyReport   */
Begin    
select userinfo,CONVERT(char(8), DATEADD(SECOND,DATEDIFF(SECOND,Min(completeddate),Max(completeddate)),0),108) Duration,count(userinfo) batchCnt from batchIndex_TrackBatches_RT(nolock)     
where CONVERT(varchar,CompletedDate,101)=CONVERT(varchar,@gDate,101)    
 --userinfo='noormohamed.h' --and CONVERT(varchar,CompletedDate,101)='11/12/2014'    
group by userinfo    
End    
  

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AthenaIndex_GetUserProducionWithDuration_Report_RTT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AthenaIndex_GetUserProducionWithDuration_Report_RTT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AthenaIndex_GetUserProducionWithDuration_Report_RTT] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AthenaIndex_GetUserProducionWithDuration_Report_RTT] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AthenaIndex_GetUserProducionWithDuration_Report_RTT] TO [DB_DMLSupport]
    AS [dbo];

