﻿--select * from  sys.procedures  where name like '%mail%'
--select * from ADM_MailTranInsert

CREATE Procedure ADM_MailTran_Insert     
(      
	@FROM_MAILID VARCHAR(100) = ''    
	,@RECIPIENTS VARCHAR(MAX)
	,@CC VARCHAR(MAX)=''      
	,@SUBJECT_TEXT VARCHAR(100)      
	,@BODY NVARCHAR(MAX)      
	,@ISHTML VARCHAR(1) = 'N'      
)      
AS      
BEGIN      
IF ISNULL(@FROM_MAILID,'') = '' SET @FROM_MAILID = 'mail.support@accesshealthcare.co'    
INSERT INTO ARC_REC_Athena..ARC_REC_MAIL_TRAN(FROM_MAILID,RECIPIENTS,SUBJECT_TEXT,BODY,ISHTML,CC)VALUES(@FROM_MAILID,@RECIPIENTS,@SUBJECT_TEXT,@BODY,@ISHTML,@CC)      
END


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_MailTran_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_MailTran_Insert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_MailTran_Insert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_MailTran_Insert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_MailTran_Insert] TO [DB_DMLSupport]
    AS [dbo];

