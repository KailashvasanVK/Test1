﻿CREATE PROCEDURE ADP_Proc_IndexingBatchList  
(@SDate DATE,@PgRange INT)  
AS 
 /*  
Created By     : Saravanakumar.R
Created Date   : 2017-03-17 
Purpose		   : ADP - To View indexing pending status
Ticket ID	   : 195731
TL Verified By : Ramakrishnan.G


Implemented On :2017-03-20
Reviewed by    :Udhai
Reviewed On    :2017-03-20
*/        
BEGIN  
SELECT a.ScanDate,a.BatchNo,A.ClientId,PgCount,B.PayerName,C.ServiceName,d.ntusername,D.CreatedDate,   
CASE WHEN a.[STATUS]=3 THEN 'Pending' ELSE 'Completed' END IStatus  
FROM TRN_koff_tBAtches(NOLOCK) A  
LEFT JOIN adm_payername(NOLOCK) B ON A.PayerId = B.PayerId  
LEFT JOIN ADM_Service(NOLOCK) C ON A.ServiceId  = C.ServiceId  
LEFT JOIN BatchIndexing_tIndexingProcessed(NOLOCK)D ON a.BatchNo=D.BatchNo  
WHERE a.SCANDATE=@SDate AND PgCount>@PgRange AND LEFT(A.BatchNo, 1) NOT IN ('S','M') AND C.[Status]=1 AND C.[Description]='Offline'  
END



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADP_Proc_IndexingBatchList] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADP_Proc_IndexingBatchList] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADP_Proc_IndexingBatchList] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADP_Proc_IndexingBatchList] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADP_Proc_IndexingBatchList] TO [DB_DMLSupport]
    AS [dbo];

