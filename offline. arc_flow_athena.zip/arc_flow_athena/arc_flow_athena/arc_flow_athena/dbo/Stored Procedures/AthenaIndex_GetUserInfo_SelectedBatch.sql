﻿
/*  
Purpose : Get User Information for selected batch  
CreatedDate : Apr 10,2015  
*/  
CREATE Proc  AthenaIndex_GetUserInfo_SelectedBatch  
@BatchNo varchar(50)=NULL  
as  
Begin  
SELECT * from batchIndex_TrackBatches(nolock) where batchnum=@BatchNo   
End  



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AthenaIndex_GetUserInfo_SelectedBatch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AthenaIndex_GetUserInfo_SelectedBatch] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AthenaIndex_GetUserInfo_SelectedBatch] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[AthenaIndex_GetUserInfo_SelectedBatch] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[AthenaIndex_GetUserInfo_SelectedBatch] TO [DB_DMLSupport]
    AS [dbo];

