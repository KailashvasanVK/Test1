﻿         
CREATE PROCEDURE pIndexing_UpdateTNPInformation_old           
(            
@Batchno varchar(20),            
@NPI varchar(30),            
@TaxID varchar(30),            
@Payeeno varchar(30),            
@DollarAmt money,      
@AutomationType int = 1,      
@UserID varchar(500) = NULL                
)                                    
As      
Begin         
      
      Update Arc_Athena..BatchMaster  set Dollaramt=@Dollaramt,NPIID=ltrim(rtrim(@NPI)),TaxID=ltrim(rtrim(@TaxID)),      
      PAYEENUMBER=ltrim(rtrim(@Payeeno)) Where Batchnum=@Batchno        
            
 IF (@AutomationType = 0)        
  BEGIN         
        
      Update trn_koff_tbatches set Status=88 where Batchno=@batchno and Status=3      
              
      INSERT INTO ARC_Athena..SemiOcr_tAutomationBatchQueue        
      SELECT BatchId, @Batchno, PgCount, 0, @UserID, GETDATE() FROM trn_koff_tbatches tb  Where BatchNo = @batchno        
            
      INSERT INTO ARC_Athena..SemiOcr_tAutomationBatchFlow        
      SELECT BatchId, BatchProcessId,GETDATE(), @UserID, 0, '' FROM ARC_Athena..SemiOcr_tAutomationBatchQueue abQ  Where BatchNo = @batchno        
  END       
         
 ELSE IF(@AutomationType = 1)        
       
 BEGIN         
 Update trn_koff_tbatches set Status=1 where Batchno=@batchno and Status=3             
 END          
                                 
      Update batchIndex_TrackBatches  set cstatus=1,CompletedDate=GETDATE() where batchnum=@batchno        
                                       
  --------------------------                     
  Update Arc_Flow_Athena..trn_koff_tbatchQueue set serviceid = 385 where right (@batchno,6)='A11284' and BatchNo=@batchno               
  Update Arc_Flow_Athena..trn_koff_tbatches set serviceid = 385 where right (@batchno,6)='A11284' and BatchNo=@batchno                
              
  Update Arc_Flow_Athena..trn_koff_tbatchQueue set serviceid = 385 where right (@batchno,6)='A11938'  and BatchNo=@batchno              
  Update Arc_Flow_Athena..trn_koff_tbatches set serviceid = 385 where right (@batchno,6)='A11938'    and BatchNo=@batchno             
  ----------------------------                                 
          
 Update tb set tb.ServiceId=420 from         
 ARC_FLOW_ATHENA..TRN_kOFF_tBatches  tb  inner join        
 ARC_ATHENA..batchMaster bm on tb.BatchNo=bm.batchnum where bm.dollarAmt=0 and        
 tb.ServiceId =356  and tb.BatchNo=@BatchNo        
      
 Update tbq set tbq.ServiceId=420 from         
 ARC_FLOW_ATHENA..TRN_kOFF_tBatchQueue tbq  inner join        
 ARC_ATHENA..batchMaster bm on tbq.BatchNo=bm.batchnum where bm.dollarAmt=0 and        
 tbq.ServiceId =356  and tbq.BatchNo=@BatchNo               
          
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[pIndexing_UpdateTNPInformation_old] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexing_UpdateTNPInformation_old] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexing_UpdateTNPInformation_old] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[pIndexing_UpdateTNPInformation_old] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexing_UpdateTNPInformation_old] TO [DB_DMLSupport]
    AS [dbo];

