﻿CREATE Procedure [dbo].[ADM_QcTargetInsert]    
(    
 @TargetName VARCHAR(30),    
 @CreatedBy INT,    
 @Status INT,    
 @TargetId INT OUTPUT    
     
)    
As     
BEGIN    
 /*                        
 Purpose           : insert QcTarget details into ADM_QcTarget table                    
 Created By        : Kathiravan                        
 Created Date      :15 may 2013       
 Impact to         : ProcessTarget.aspx                        
  */     
    
	INSERT INTO ADM_QcTarget(TargetName,CreatedBy,Status)    
	SELECT @TargetName,@CreatedBy,@Status    
	SELECT @TargetId = IDENT_CURRENT('ADM_QcTarget')    
END


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_QcTargetInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_QcTargetInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_QcTargetInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_QcTargetInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_QcTargetInsert] TO [DB_DMLSupport]
    AS [dbo];

