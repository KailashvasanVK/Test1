﻿  
  
CREATE Procedure  [dbo].[TRN_kOFF_pEntryAndQcTranCheckListReport]    
(    
@fromDate date    
,@toDate date    
,@BatchServiceId int    
,@SearchStr varchar(100) = ''      
,@SearchPattern varchar(4) = '=' /** = or % **/       
)    
As    
Begin    
  
  
/*  
Created By :karthick.M7  
Purpose : To get EntryAndQcTranCheckList  
Created On : 09/16/2015  
Page:EntryAndQcTranCheckListReport.aspx  
*/  
Set nocount on    
Set ansi_nulls on  
Set Transaction Isolation level read Uncommitted;  
  
  
if OBJECT_ID('tempdb..#EntyQcChkResult') is not null drop table #EntyQcChkResult  
if OBJECT_ID('tempdb..#ScanBatches') is not null drop table #ScanBatches  
  
  
Select bat.BatchId , usrEntry.NT_USERNAME as 'EntryBy',CONVERT(varchar(10),batflowEntry.CreatedDt,101) as EntryCompletedOn--,  usrQc.NT_USERNAME  as 'QcBy' ,CONVERT(varchar(10),batflowQc.CreatedDt,101) as QcCompletedOn  
into #ScanBatches   
from TRN_kOFF_tBatches bat  
Left  join  TRN_kOFF_tBatchFlow batflowEntry on batflowEntry.BatchId = bat.BatchId and  batflowEntry.statusid = 6  
Left  join  ARC_REC_Athena..ARC_REC_USER_INFO usrEntry on  usrEntry.USERID = batflowEntry.CreatedBy    
where ScanDate between @fromDate and @toDate  and  bat.status = 1  and  ServiceId =  case when @BatchServiceId = 0 then ServiceId else @BatchServiceId END  
  
Select e.ScanDate,e.BatchNo,e.ServiceName,e.PayerName,e.EntryBy ,e.EntryCompletedOn,qccom.QcBy,qccom.QcCompletedOn,e.TotalEntry,q.TotalQceed,q.QCPercentage  
,case when dir.BatchNo IS not null then 'DirectUpload' else '' end as Direct,case when qccom.BatchNo is not null then 'Qceed' else 'QcNotFound' end as IsQc,  
case when (e.ErrorCount) > 0  
then  '<a href="#" onclick="return showdialog('+Cast(e.BatchProcessId as varchar)+')"><div>'+ +convert(varchar,e.ErrorCount)+'</div><a/>'  
else '0' end as ErrCount,e.UploadDt  
--e.ErrorCount  
into #EntyQcChkResult  
from  
(  
Select Bat.BatchNo,ser.ServiceName,SUM(t.TransValue)  as TotalEntry,CONVERT(varchar(10),bat.ScanDate,101) as ScanDate,  
CONVERT(varchar(10),bat.UploadDt,101) as UploadDt,(Select sum(ErrCount)  from TRN_kOFF_tBatchQCTran Where BatchProcessId = t.BatchProcessId) as ErrorCount,  
t.BatchProcessId ,payer.PayerName,b.EntryBy,b.EntryCompletedOn --,b.QcBy,b.QcCompletedOn   
from TRN_kOFF_tBatchTransact as t  
inner join #ScanBatches as b on b.BatchId = t.BatchId  
inner join TRN_kOFF_tBatches as bat on bat.BatchId = t.BatchId  
inner join ADM_Service as ser on ser.ServiceId =  bat.ServiceId  
inner join adm_payername as payer on payer.PayerId = bat.PayerId  
Group by bat.BatchNo,t.BatchProcessId,payer.PayerName ,bat.ScanDate ,bat.UploadDt,ser.ServiceName,b.EntryBy ,b.EntryCompletedOn--,b.QcBy,b.QcCompletedOn   
)e  
left join   
(  
Select Bat.BatchNo,SUM(TransValue) as TotalQceed,t.QCPercentage  
from TRN_kOFF_tBatchQCMaster as t  
inner join TRN_kOFF_tBatchQueue as q on q.BatchProcessId = t.BatchProcessId  
inner join #ScanBatches as b on b.BatchId = q.BatchId  
inner join TRN_kOFF_tBatches as bat on bat.BatchId = b.BatchId  
Group by bat.BatchNo,t.QCPercentage  
)q on q.BatchNo = e.BatchNo  
left join   
(  
Select Bat.BatchNo,CONVERT(varchar(10),t.CreatedDt,101) QcCompletedOn,usrQc.NT_USERNAME QcBy   
from TRN_kOFF_tBatchQCComments as t  
inner join TRN_kOFF_tBatchQueue as q on q.BatchProcessId = t.BatchProcessId  
inner join #ScanBatches as b on b.BatchId = q.BatchId  
inner join TRN_kOFF_tBatches as bat on bat.BatchId = b.BatchId  
inner join ARC_REC_Athena..ARC_REC_USER_INFO usrQc on  usrQc.USERID = t.CreatedBy  
Group by bat.BatchNo,t.CreatedDt ,usrQc.NT_USERNAME   
)qccom on qccom.BatchNo = e.BatchNo  
left join  
(  
Select bat.BatchNo from TRN_kOFF_tDirectUpload as d  
inner join #ScanBatches as s on s.BatchId = d.BatchId  
inner join TRN_kOFF_tBatches as bat on bat.BatchId = s.BatchId  
)dir on dir.BatchNo = e.BatchNo  
  
  
  Exec FilterTable      
 @DbName = 'tempdb'      
 ,@TblName = '#EntyQcChkResult'     
 ,@SearchStr = @SearchStr   
 ,@SearchPattern = '='    
 ,@OrderStr = ''     
if OBJECT_ID('tempdb..#EntyQcChkResult') is not null drop table #EntyQcChkResult  
if OBJECT_ID('tempdb..#ScanBatches') is not null drop table #ScanBatches  
  
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pEntryAndQcTranCheckListReport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pEntryAndQcTranCheckListReport] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pEntryAndQcTranCheckListReport] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pEntryAndQcTranCheckListReport] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pEntryAndQcTranCheckListReport] TO [DB_DMLSupport]
    AS [dbo];

