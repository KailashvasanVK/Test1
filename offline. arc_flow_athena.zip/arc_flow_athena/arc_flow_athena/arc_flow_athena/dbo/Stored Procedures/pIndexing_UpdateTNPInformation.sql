﻿CREATE PROCEDURE pIndexing_UpdateTNPInformation              
(              
@BatchNo varchar(20),    
@NPI varchar(30),    
@TaxID varchar(30),    
@Payeeno varchar(30),    
@DollarAmt money,    
@AutomationType int = 1,    
@UserID varchar(500)= NULL    
)    
/*    
ModifiedDate : Oct 20,2016    
Purpsose : To route the batches as per correspondence letter and non letter payer to respective bucket    
before it was moved corressponse letter directly that code was disabled    
    
Modified by : Udhayaganesh.P ,Udhayaganesh    
Modified ON : 10/20/2016  ,11/9/2016(priority client 0 dollar)    
    
Implemented By: Narayana              
ticket id:209302 ,230809      
  
Ticket : 392709  
Purpose : Add client 1453 in adventist logic  
Date : 05/27/2019         
*/          
As      
Begin      
      
Declare @Serviceid int=0;      
      
UPDATE ARC_ATHENA..BatchMaster SET Dollaramt=@Dollaramt,NPIID=ltrim(rtrim(@NPI)),TaxID=ltrim(rtrim(@TaxID)),      
PAYEENUMBER=ltrim(rtrim(@Payeeno))Where Batchnum=@BatchNo      
      
IF (right(@BatchNo,6)='A11284' or  right(@BatchNo,6)='A11938')      
Begin         
--------------------------      
Update Arc_Flow_Athena..trn_koff_tbatchQueue set serviceid = 385 where BatchNo=@BatchNo and PageTo <6      
Update Arc_Flow_Athena..trn_koff_tbatches set serviceid = 385 where  BatchNo=@BatchNo  and PgCount<6      
      
END      
      
SELECT @Serviceid=arpb.PayorBucketServiceId FROM ARC_FLOW_ATHENA.dbo.TRN_kOFF_tBatches(nolock) tb      
inner join arc_flow_athena.dbo.Athena_Index_RouteToPayorWithBucketInfo(nolock) arpb on tb.PayerId=arpb.PayorServiceId      
inner join ARC_ATHENA.dbo.batchMaster(nolock) bm on tb.BatchNo=bm.batchnum      
where bm.dollarAmt=0 and tb.ServiceId =356 and tb.BatchNo=@BatchNo      
      
if( @Serviceid >0)      
BEGIN      
Update ARC_FLOW_ATHENA.dbo.trn_koff_tbatchQueue set serviceid = @Serviceid where batchno=@BatchNo      
Update ARC_FLOW_ATHENA.dbo.trn_koff_tbatches set serviceid = @Serviceid where  batchno=@BatchNo      
      
End      
       
/* Need to move the priority client batches with control total as $0 to “Priority Client 0$” service bucket. */       
          
Update tbq set tbq.ServiceId=421 from ARC_FLOW_ATHENA..TRN_kOFF_tBatchQueue tbq      
INNER JOIN Arc_Flow_Athena.dbo.TRN_kOFF_tBatches  tb on tb.BatchId = tbq.BatchId      
inner join  ARC_ATHENA.dbo.batchMaster bm on bm.batchnum =tbq.BatchNo              
where bm.dollarAmt=0 and  tb.ServiceId =394  and tb.status = 3  and tb.PgCount <6          
and tb.BatchNo=@BatchNo      
      
Update tb set tb.ServiceId=421 from ARC_FLOW_ATHENA.dbo.TRN_kOFF_tBatches  tb      
inner join ARC_ATHENA.dbo.batchMaster bm on tb.BatchNo=bm.batchnum      
where bm.dollarAmt=0 and tb.ServiceId =394 and tb.status = 3  and tb.PgCount <6      
and tb.batchno=@BatchNo      
      
/*Move priority client-419 with dollar batch and client 6385,11845 to specialclient 356 bucket  Jan 31,2017 */      
      
Update tbq set tbq.ServiceId=356 from ARC_FLOW_ATHENA..TRN_kOFF_tBatchQueue tbq      
INNER JOIN Arc_Flow_Athena..TRN_kOFF_tBatches  tb on tb.BatchId = tbq.BatchId      
inner join  ARC_ATHENA..batchMaster bm on tbq.BatchNo=bm.batchnum      
where bm.dollarAmt>0 and  tbq.ServiceId =419  and tb.status = 3  and tb.PgCount <6      
and (right(tb.batchno,4)='6385' or right(tb.batchno,5)='11845')  and    tb.batchno=@BatchNo      
      
Update tb set tb.ServiceId=356 from ARC_FLOW_ATHENA..TRN_kOFF_tBatches  tb      
inner join ARC_ATHENA..batchMaster bm on tb.BatchNo=bm.batchnum      
where  bm.dollarAmt>0 and tb.ServiceId =419 and tb.status = 3  and tb.PgCount <6 and      
(right(tb.batchno,4)='6385' or right(tb.batchno,5)='11845') and  tb.batchno=@BatchNo      
          
/*SCR 1407--  Start      
Client 6385 -- $ batches Special client      
$0 batches Other queues - based on the routed payers      
- */      
Update tbq set tbq.ServiceId=356 from ARC_FLOW_ATHENA..TRN_kOFF_tBatchQueue tbq      
INNER JOIN Arc_Flow_Athena..TRN_kOFF_tBatches  tb on tb.BatchId = tbq.BatchId      
inner join  ARC_ATHENA..batchMaster bm on tbq.BatchNo=bm.batchnum      
where bm.dollarAmt>0 and   tb.status = 3  and tb.PgCount <6      
and (right(tb.batchno,4)='6385' or right(tb.batchno,5)='11845')  and    tb.batchno=@BatchNo      
          
Update tb set tb.ServiceId=356 from ARC_FLOW_ATHENA..TRN_kOFF_tBatches  tb      
inner join ARC_ATHENA..batchMaster bm on tb.BatchNo=bm.batchnum      
where  bm.dollarAmt>0 and tb.status = 3  and tb.PgCount <6 and      
(right(tb.batchno,4)='6385' or right(tb.batchno,5)='11845') and  tb.batchno=@BatchNo      
/*SCR 1407-- End*/         
          
/*SCR 1398 - Humana payerid = 253       
Batches should be route to this queue(DE Intercept) if the below condition satisfied      
o Batch total is greater than ZERO      
o Payer Name contains HUMANA      
*/       
      
SELECT @Serviceid=SERVICEID from adm_service where servicename='DE Intercept'      
      
Update tbq set tbq.ServiceId=@Serviceid from ARC_FLOW_ATHENA..TRN_kOFF_tBatchQueue tbq       
INNER JOIN Arc_Flow_Athena.dbo.TRN_kOFF_tBatches  tb on tb.BatchId = tbq.BatchId      
inner join  ARC_ATHENA..batchMaster bm on tbq.BatchNo=bm.batchnum      
where bm.dollarAmt>0 and tb.batchno=@BatchNo and tb.payerid=253 and status=3      
          
Update tb set tb.ServiceId=@Serviceid from ARC_FLOW_ATHENA.dbo.TRN_kOFF_tBatches tb          
inner join ARC_ATHENA.dbo.batchMaster bm on tb.BatchNo=bm.batchnum            
where  bm.dollarAmt>0 and  tb.batchno=@BatchNo and  tb.payerid=253 and status=3          
          
/*SCR 1421          
Batches pertain to Inpatient queue context ID’s should be moved to the new buckets          
Date Nov 22,2017          
*/          
Declare @ServiceidT int=0          
          
SELECT @Serviceid=arpb.PayorBucketServiceId FROM ARC_FLOW_ATHENA.dbo.TRN_kOFF_tBatches(nolock) tb              
inner join arc_flow_athena.dbo.Athena_Index_RouteToPayorWithBucketInfo(nolock) arpb on tb.PayerId=arpb.PayorServiceId              
where tb.BatchNo=@BatchNo          
          
Update tbq set tbq.ServiceId=@Serviceid from   ARC_FLOW_ATHENA..TRN_kOFF_tBatchQueue tbq          
INNER JOIN Arc_Flow_Athena.dbo.TRN_kOFF_tBatches  tb on tb.BatchId = tbq.BatchId          
inner join  ARC_ATHENA..batchMaster bm on tbq.BatchNo=bm.batchnum           
where  tb.batchno=@BatchNo and SUBSTRING(tb.batchno,CHARINDEX('A',tb.batchno)+1,(LEN(tb.batchno)-CHARINDEX('A',tb.batchno))+1)          
in(select subclientname from arc_athena..batchimport_subclient(nolock) where serviceid=385)   and tb.serviceid not in(418)               
          
Update tb set tb.ServiceId=@Serviceid from ARC_FLOW_ATHENA.dbo.TRN_kOFF_tBatches  tb          
inner join ARC_ATHENA.dbo.batchMaster bm on tb.BatchNo=bm.batchnum          
where  tb.batchno=@BatchNo and SUBSTRING(tb.batchno,CHARINDEX('A',tb.batchno)+1,(LEN(tb.batchno)-CHARINDEX('A',tb.batchno))+1)          
in(select subclientname from arc_athena..batchimport_subclient(nolock) where serviceid=385)   and tb.serviceid not in(418)             
SELECT @ServiceidT=arpb.RouteToBucketServiceId FROM ARC_FLOW_ATHENA.dbo.TRN_kOFF_tBatches(nolock) tb              
inner join arc_flow_athena.dbo.Athena_Index_RouteBucketToBucket(nolock) arpb on arpb.serviceid=tb.serviceid          
where tb.BatchNo=@BatchNo and SUBSTRING(tb.batchno,CHARINDEX('A',tb.batchno)+1,(LEN(tb.batchno)-CHARINDEX('A',tb.batchno))+1)          
in(select subclientname from arc_athena..batchimport_subclient(nolock) where serviceid=385) and tb.serviceid not in(418) and arpb.ParentServiceId=385          
          
Update tb set tb.ServiceId=@ServiceidT from ARC_FLOW_ATHENA.dbo.TRN_kOFF_tBatches  tb            
inner join ARC_ATHENA.dbo.batchMaster bm on tb.BatchNo=bm.batchnum           
where  tb.batchno=@BatchNo and SUBSTRING(tb.batchno,CHARINDEX('A',tb.batchno)+1,(LEN(tb.batchno)-CHARINDEX('A',tb.batchno))+1)            
in(select subclientname from arc_athena..batchimport_subclient(nolock) where serviceid=385)   and tb.serviceid not in(418)          
          
Update tbq set tbq.ServiceId=tb.serviceid from ARC_FLOW_ATHENA..TRN_kOFF_tBatchQueue tbq            
INNER JOIN Arc_Flow_Athena.dbo.TRN_kOFF_tBatches  tb on tb.BatchId = tbq.BatchId            
inner join  ARC_ATHENA..batchMaster bm on tbq.BatchNo=bm.batchnum           
where  tb.batchno=@BatchNo and SUBSTRING(tb.batchno,CHARINDEX('A',tb.batchno)+1,(LEN(tb.batchno)-CHARINDEX('A',tb.batchno))+1)            
in(select subclientname from arc_athena..batchimport_subclient(nolock) where serviceid=385)   and tb.serviceid not in(418)          
          
          
/*SCR 1421 End*/      
/*SCR 1476          
Batches pertain to Specialproject queue context ID’s should be moved to the new buckets          
Date Nov 30,2017          
*/          
-- Declare @ServiceidT int=0      
          
SELECT @Serviceid=arpb.PayorBucketServiceId FROM ARC_FLOW_ATHENA.dbo.TRN_kOFF_tBatches(nolock) tb           
inner join arc_flow_athena.dbo.Athena_Index_RouteToPayorWithBucketInfo(nolock) arpb on tb.PayerId=arpb.PayorServiceId              
where tb.BatchNo=@BatchNo          
          
Update tbq set tbq.ServiceId=@Serviceid from ARC_FLOW_ATHENA..TRN_kOFF_tBatchQueue tbq          
INNER JOIN Arc_Flow_Athena.dbo.TRN_kOFF_tBatches  tb on tb.BatchId = tbq.BatchId          
inner join  ARC_ATHENA..batchMaster bm on tbq.BatchNo=bm.batchnum           
where  tb.batchno=@BatchNo and SUBSTRING(tb.batchno,CHARINDEX('A',tb.batchno)+1,(LEN(tb.batchno)-CHARINDEX('A',tb.batchno))+1)          
in(select subclientname from arc_athena..batchimport_subclient(nolock) where serviceid=419)   and tb.serviceid not in(418)              
          
Update tb set tb.ServiceId=@Serviceid from ARC_FLOW_ATHENA.dbo.TRN_kOFF_tBatches  tb          
inner join ARC_ATHENA.dbo.batchMaster bm on tb.BatchNo=bm.batchnum          
where  tb.batchno=@BatchNo and SUBSTRING(tb.batchno,CHARINDEX('A',tb.batchno)+1,(LEN(tb.batchno)-CHARINDEX('A',tb.batchno))+1)          
in(select subclientname from arc_athena..batchimport_subclient(nolock) where serviceid=419)   and tb.serviceid not in(418)              
          
SELECT @ServiceidT=arpb.RouteToBucketServiceId FROM ARC_FLOW_ATHENA.dbo.TRN_kOFF_tBatches(nolock) tb              
inner join arc_flow_athena.dbo.Athena_Index_RouteBucketToBucket(nolock) arpb on arpb.serviceid=tb.serviceid          
where tb.BatchNo=@BatchNo and SUBSTRING(tb.batchno,CHARINDEX('A',tb.batchno)+1,(LEN(tb.batchno)-CHARINDEX('A',tb.batchno))+1)          
in(select subclientname from arc_athena..batchimport_subclient(nolock) where serviceid=419)   and tb.serviceid not in(418) and arpb.ParentServiceId=419          
          
Update tb set tb.ServiceId=@ServiceidT from ARC_FLOW_ATHENA.dbo.TRN_kOFF_tBatches  tb              
inner join ARC_ATHENA.dbo.batchMaster bm on tb.BatchNo=bm.batchnum           
where  tb.batchno=@BatchNo and SUBSTRING(tb.batchno,CHARINDEX('A',tb.batchno)+1,(LEN(tb.batchno)-CHARINDEX('A',tb.batchno))+1)            
in(select subclientname from arc_athena..batchimport_subclient(nolock) where serviceid=419)   and tb.serviceid not in(418)              
          
Update tbq set tbq.ServiceId=tb.ServiceId from ARC_FLOW_ATHENA..TRN_kOFF_tBatchQueue tbq            
INNER JOIN Arc_Flow_Athena.dbo.TRN_kOFF_tBatches  tb on tb.BatchId = tbq.BatchId            
inner join  ARC_ATHENA..batchMaster bm on tbq.BatchNo=bm.batchnum           
where  tb.batchno=@BatchNo and SUBSTRING(tb.batchno,CHARINDEX('A',tb.batchno)+1,(LEN(tb.batchno)-CHARINDEX('A',tb.batchno))+1)            
in(select subclientname from arc_athena..batchimport_subclient(nolock) where serviceid=419)   and tb.serviceid not in(418)          
          
          
/*SCR 1476 End*/               
/*SCR 1493 Start            
Description : MVA Batch movement from Special client            
Date : Dec 18,2017            
*/          
          
Update tb set tb.ServiceId=PayorBucketServiceId from  Arc_Flow_Athena.dbo.TRN_kOFF_tBatches  tb           
inner join  ARC_ATHENA..batchMaster bm on tb.BatchNo=bm.batchnum           
inner join arc_flow_athena..Athena_Index_RouteToPayorWithBucketInfo bf on bf.PayorServiceId=tb.payerid             
where  tb.batchno=@BatchNo  and tb.serviceid not in(418)  and PayorBucketServiceId=440 and serviceid=356 --and tb.status=3            
          
Update tbq set tbq.ServiceId=PayorBucketServiceId from ARC_FLOW_ATHENA..TRN_kOFF_tBatchQueue tbq            
INNER JOIN Arc_Flow_Athena.dbo.TRN_kOFF_tBatches  tb on tb.BatchId = tbq.BatchId            
inner join  ARC_ATHENA..batchMaster bm on tbq.BatchNo=bm.batchnum           
inner join arc_flow_athena..Athena_Index_RouteToPayorWithBucketInfo bf on bf.PayorServiceId=tb.payerid             
where  tb.batchno=@BatchNo  and tb.serviceid not in(418)  and PayorBucketServiceId=440 and tbq.serviceid=356 --and tb.status=3            
          
/*SCR 1493 End*/      
          
IF (@AutomationType = 0)          
BEGIN           
          
Update trn_koff_tbatches set Status=88 where Batchno=@BatchNo and Status=3          
          
INSERT INTO ARC_Athena..SemiOcr_tAutomationBatchQueue          
SELECT BatchId, @BatchNo, PgCount, 0, @UserID, GETDATE() FROM trn_koff_tbatches tb  Where BatchNo = @BatchNo          
          
INSERT INTO ARC_Athena..SemiOcr_tAutomationBatchFlow          
SELECT BatchId, BatchProcessId,GETDATE(), @UserID, 0, '' FROM ARC_Athena..SemiOcr_tAutomationBatchQueue abQ  Where BatchNo = @BatchNo          
END          
          
ELSE IF(@AutomationType = 1)          
          
BEGIN          
          
/*Update trn_koff_tbatches set Status=1 where Batchno=@BatchNo and Status=3*/          
          
Update tbq set tbq.ServiceId=tb.serviceid from ARC_FLOW_ATHENA..TRN_kOFF_tBatchQueue tbq            
INNER JOIN Arc_Flow_Athena.dbo.TRN_kOFF_tBatches  tb on tb.BatchId = tbq.BatchId             
where tb.BatchNo=@BatchNo           
          
END             
          
          
/*SCR 1611              
Purpose : Client 15749 batches moved to subclient 15749              
CreatedDate : Apr 17,2018              
*/           
          
Update tbq set tbq.ServiceId=499 from ARC_FLOW_ATHENA..TRN_kOFF_tBatchQueue tbq          
INNER JOIN Arc_Flow_Athena..TRN_kOFF_tBatches  tb on tb.BatchId = tbq.BatchId          
inner join  ARC_ATHENA..batchMaster bm on tbq.BatchNo=bm.batchnum          
where  right(tb.batchno,6)='A15749'   and    tb.batchno=@BatchNo and ULStatus is null and dollaramt>0          
          
          
Update tb set tb.ServiceId=499 from ARC_FLOW_ATHENA..TRN_kOFF_tBatches  tb          
inner join ARC_ATHENA..batchMaster bm on tb.BatchNo=bm.batchnum          
where  right(tb.batchno,6)='A15749'  and  tb.batchno=@BatchNo  and ULStatus is null  and dollaramt>0          
          
          
Update tbq set tbq.ServiceId=500 from  ARC_FLOW_ATHENA..TRN_kOFF_tBatchQueue tbq          
INNER JOIN Arc_Flow_Athena..TRN_kOFF_tBatches  tb on tb.BatchId = tbq.BatchId          
inner join  ARC_ATHENA..batchMaster bm on tbq.BatchNo=bm.batchnum          
where  right(tb.batchno,6)='A15749'   and    tb.batchno=@BatchNo and ULStatus is null and dollaramt=0           
          
          
Update tb set tb.ServiceId=500 from ARC_FLOW_ATHENA..TRN_kOFF_tBatches  tb          
inner join ARC_ATHENA..batchMaster bm on tb.BatchNo=bm.batchnum          
where  right(tb.batchno,6)='A15749'  and  tb.batchno=@BatchNo  and ULStatus is null  and dollaramt=0          
          
          
/* END SCR 1611          
*/             
/*SCR 1762  
Ticket : 392709  
Purpose : Add client 1453 in adventist logic  
Date : 05/27/2019  
*/              
UPDATE tbq set tbq.ServiceId=509 from  ARC_FLOW_ATHENA..TRN_kOFF_tBatchQueue tbq            
INNER JOIN Arc_Flow_Athena..TRN_kOFF_tBatches  tb on tb.BatchId = tbq.BatchId            
inner join  ARC_ATHENA..batchMaster bm on tbq.BatchNo=bm.batchnum           
WHERE  (right(tb.batchno,6)='A13122' or right(tb.batchno,5)='A3793' or  right(tb.batchno,5)='A1453') and tb.batchno=@BatchNo and bm.dollaramt>0 and ULStatus is null       
and tb.serviceid not in(418)              
          
          
UPDATE tb set tb.ServiceId=509 from ARC_FLOW_ATHENA..TRN_kOFF_tBatches  tb            
inner join ARC_ATHENA..batchMaster bm on tb.BatchNo=bm.batchnum           
WHERE  (right(tb.batchno,6)='A13122' or right(tb.batchno,5)='A3793' or  right(tb.batchno,5)='A1453') and tb.batchno=@BatchNo  and bm.dollaramt>0 and ULStatus is null       
and tb.serviceid not in(418)            
          
          
UPDATE tbq set tbq.ServiceId=509 from ARC_FLOW_ATHENA..TRN_kOFF_tBatchQueue tbq            
INNER JOIN Arc_Flow_Athena..TRN_kOFF_tBatches  tb on tb.BatchId = tbq.BatchId            
inner join  ARC_ATHENA..batchMaster bm on tbq.BatchNo=bm.batchnum           
WHERE  (right(tb.batchno,6)='A13122' or right(tb.batchno,5)='A3793' or  right(tb.batchno,5)='A1453')    and    tb.batchno=@BatchNo  and ULStatus is null       
and tb.serviceid=414 and tb.serviceid not in(418)              
          
          
UPDATE tb set tb.ServiceId=509 from ARC_FLOW_ATHENA..TRN_kOFF_tBatches  tb            
inner join ARC_ATHENA..batchMaster bm on tb.BatchNo=bm.batchnum           
WHERE  (right(tb.batchno,6)='A13122' or right(tb.batchno,5)='A3793' or  right(tb.batchno,5)='A1453')  and  tb.batchno=@BatchNo  and ULStatus is null       
and tb.serviceid=414 and tb.serviceid not in(418)              
          
--Zero dollar with other payer will move to adventist bucket            
Update tbq set tbq.ServiceId=509 from ARC_FLOW_ATHENA..TRN_kOFF_tBatchQueue tbq           
INNER JOIN Arc_Flow_Athena..TRN_kOFF_tBatches  tb on tb.BatchId = tbq.BatchId            
inner join  ARC_ATHENA..batchMaster bm on tbq.BatchNo=bm.batchnum           
where  (right(tb.batchno,6)='A13122' or right(tb.batchno,5)='A3793' or  right(tb.batchno,5)='A1453')    and    tb.batchno=@BatchNo  and ULStatus is null       
and tb.serviceid not in(418)  and bm.dollaramt=0             
and tb.payerid not in(807)            
          
Update tb set tb.ServiceId=509 from ARC_FLOW_ATHENA..TRN_kOFF_tBatches  tb            
inner join ARC_ATHENA..batchMaster bm on tb.BatchNo=bm.batchnum           
where  (right(tb.batchno,6)='A13122' or right(tb.batchno,5)='A3793' or  right(tb.batchno,5)='A1453')  and  tb.batchno=@BatchNo  and ULStatus is null       
and tb.serviceid not in(418) and bm.dollaramt=0             
and tb.payerid not in(807)            
/*SCR 1762*/      
          
UPDATE batchIndex_TrackBatches SET cstatus=1,CompletedDate=GETDATE()where batchnum=@BatchNo          
          
Declare @ntusername varchar(max)          
SET @ntusername = (SELECT NT_USERNAME From ARC_REC_ATHENA..ARC_REC_USER_INFO(nolock) Where UserID = @UserID)          
          
INSERT INTO Arc_Flow_Athena..BatchIndexing_tIndexingProcessed(BatchNo, ScanDate, PayorServiceId, CheckDate, ntusername, CreatedDate, ServiceID)          
SELECT BatchNo, ScanDate, PayerID, '' As CheckDate, @ntusername, GETDATE() As CreatedDate, ServiceID           
From Arc_Flow_Athena..TRN_koff_tbatches(nolock) Where BatchNo = @BatchNo          
          
          
/*Check iEOB Payer*/          
/*Check for Enterprise and Dual Client, if Yes skip to move iEOB Queue*/


/* Allow enterprise Client in Automation Queue 

Declare @SubClientCount int          
SET @SubClientCount = (Select COUNT(*) from((Select SubClient from ARC_Athena..subclient_info Where status = 1          
UNION select EnterpriseClient As SubClient from ARC_Athena..enterpriseclients  where status = 1))a          
Where a.SubClient = SUBSTRING(@BatchNo, CHARINDEX('A', @BatchNo) + 1, LEN(@BatchNo)))          
          
IF @SubClientCount = 0          
BEGIN
*/
          
          
/*For iEOB Update*/          
Update t SET ServiceID = 452, Status = 88 from Arc_Flow_Athena..TRN_koff_tbatches(nolock)t          
inner join ARC_Athena..iEOB_tPayerAllocation(nolock) p on p.PayerID = t.PayerID Where Batchno = @BatchNo          
And t.PgCount between p.PageFrom And p.PageTo And Status IN (3,88)          
          
If @@ROWCOUNT > 0             
BEGIN          
          
Update Arc_Flow_Athena..TRN_kOFF_tBatchQueue set ServiceID = 452 where BatchNo = @BatchNo             
          
DELETE from ARC_Athena.dbo.SemiOCR_tAutomationBatchFlow Where BatchID = (Select BatchID from ARC_Athena.dbo.SemiOCR_tAutomationBatchQueue    
Where BAtchNo = @BatchNo and StatusId = 0)    
DELETE from ARC_Athena.dbo.SemiOCR_tAutomationBatchQueue Where BatchNo = @BatchNo and StatusId = 0    
    
Declare @CheckDuplicate int     
SET @CheckDuplicate = (Select COUNT(BatchProcessId) From ARC_Athena.dbo.iEOB_tAutomationBatchQueue(nolock) Where BatchNo = @BatchNo)    
    
IF @CheckDuplicate = 0    
BEGIN    
    
 INSERT INTO ARC_Athena.dbo.iEOB_tAutomationBatchQueue    
 SELECT BatchId, @Batchno, PgCount, 0, @ntusername, GETDATE() FROM Arc_Flow_Athena.dbo.TRN_koff_tbatches tb    
 Where BatchNo = @BatchNo    
           
 INSERT INTO ARC_Athena.dbo.iEOB_tAutomationBatchFlow    
 SELECT BatchId, BatchProcessId, 0, '', @ntusername, GETDATE() FROM ARC_Athena.dbo.iEOB_tAutomationBatchQueue abQ    
 Where BatchNo = @BatchNo    
    
 RETURN    
     
END    
    
END          

/*END*/
          
/*End*/          
          
UPDATE Arc_Flow_Athena..trn_koff_tbatches SET Status=1 where Batchno=@BatchNo and Status=3          
          
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[pIndexing_UpdateTNPInformation] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexing_UpdateTNPInformation] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexing_UpdateTNPInformation] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[pIndexing_UpdateTNPInformation] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[pIndexing_UpdateTNPInformation] TO [DB_DMLSupport]
    AS [dbo];

