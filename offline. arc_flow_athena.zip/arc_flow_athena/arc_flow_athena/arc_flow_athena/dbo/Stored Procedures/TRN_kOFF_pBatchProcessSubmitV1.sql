﻿CREATE Procedure TRN_kOFF_pBatchProcessSubmitV1    
(    
 
 @pBatchProcessId int    
,@pStatus varchar(1) /* (C)omplete/(H)eld/(I)ncomplete */    
,@pCompletedPageNo int /** This should be mandatory if status is incomplete / held **/    
,@pComments varchar(max)    
,@pCreatedBy int    

,@pPayment int /** Payment (358) transaction count */    
,@pCollection int /** Collection (359) transaction count */    
,@pExceptionPosting int /** ExceptionPosting (360) transaction count */    
,@pSelfPosting int /** SelfPosting (361) transaction count */    
,@pPatientPosting int /** PatientPosting (364) transaction count */    
,@pHoldComments varchar(max) = ''    

)    
as    
Begin 

/*        
		Modified By     : mallikarjun.nam
		Modified Date   : 2016-07-26   
		Purpose        : For Random Qc alogothim
		Ticket/SCR ID  : 155811
		TL Verified By : Safi
		 
		Implemented by : Ganesh.Tanneru
		Implemented On : 26-07-2016
		 
		Reviewd by     : Ganesh.Tanneru
		Implemented On : 26-07-2016
		
		Modified By     : mallikarjun.nam
		Modified Date   : 2017-07-05
		Purpose         : Updating batch manually allocated status as 0 after batch processed
		
		SCR : 1844
        Purpose : Add new procedure for QC process
        ModifiedDate : 2018-11-08  
        
        Modified By :Noor
        MOdified Date:2018-11-28
        Implemented By Narayana
        SCR:1499
	 
	*/   
Declare @CreatedDt datetime = getdate()    
Declare @BatchId int,@PageFrom int,@ServiceId int,@ClientId int,@PageTo int    
Select @BatchId = BatchId ,@PageFrom = PageFrom,@PageTo = PageTo, @ServiceId = ServiceId,@ClientId = ClientId    
from TRN_kOFF_tBatchQueue Where BatchProcessId = @pBatchProcessId    
Declare @LocationId int = (Select LocationId from ARC_REC_ATHENA..ARC_REC_User_Info where UserId = @pCreatedBy)    
Declare @ShiftId int = (Select Top 1 SHIFT_ID from ARC_REC_ATHENA..ARC_REC_SHIFT_TRAN where USERID = @pCreatedBy and Effect_DATE <= GETDATE() Order by Effect_DATE desc)
if (Select count(*) from TRN_kOFF_TBatchQueue Where BatchProcessId = @pBatchProcessId and Assigned = @pCreatedBy) = 0    
 Begin    
  /**    
  Have to check whether the process is assigned or not. If not then no need to process. (May the process held / disregard / reset from .manage)    
  **/    
  RAISERROR('Already batch status was changed',16,1)    
  Select 0    
  Return    
 End    
if @pStatus in ('I')    
 Begin    
 if (@pCompletedPageNo = 0)    
  Begin    
  RAISERROR('Cannot change the status as incomplete with zero transaction',16,1)    
  Select 0    
  Return    
  End    
 if (@pCompletedPageNo > @PageTo)    
  Begin    
  RAISERROR('Completed page no should be allotted page limit',16,1)    
  Select 0    
  Return    
  End    
 if (@pCompletedPageNo+1 > @PageTo)    
  Begin    
  RAISERROR('Invalid Incomplete / Hold! To page should be lesser than total allocated pages.',16,1)    
  Select 0    
  Return    
  End    
  if (@pCompletedPageNo < @PageFrom)    
  Begin    
  RAISERROR('Invalid Incomplete / Hold! To page should be greater than allocated from page.',16,1)    
  Select 0    
  Return    
  End    
 End    
Begin Transaction    
Begin Try    

Insert into TRN_koff_tbatchTransactSubmitLogHistoy(CustomerId,BatchProcessId,Comments,CompletedPageNo,CreatedBy,EntPayment,EntCollection,EntExceptionPosting,EntSelfPosting,EntPatientPosting
,Status,HoldComments,IsEntryProcess)
Select 25,@pBatchProcessId,@pComments,@pCompletedPageNo,@pCreatedBy,@pPayment,@pCollection,@pExceptionPosting,@pSelfPosting,@pPatientPosting
,@pStatus,@pHoldComments,1

Delete from TRN_kOFF_tBatchTransact Where BatchProcessId = @pBatchProcessId


Declare @FactorPayment float /** Payment (358) transaction count */    
,@FactorCollection float /** Collection (359) transaction count */    
,@FactorExceptionPosting float /** ExceptionPosting (360) transaction count */    
,@FactorSelfPosting float /** SelfPosting (361) transaction count */    
,@FactorPatientPosting float /** PatientPosting (364) transaction count */ 

Select @FactorPayment = EntryPayment
,@FactorCollection = EntryCollection
,@FactorExceptionPosting = EntryExceptionPosting
,@FactorSelfPosting = EntrySelfPosting
,@FactorPatientPosting = EntryPatientCreation 
from ADM_FactorWaterTown 
Where ServiceGroupId = @ServiceId and CONVERT(date,getdate()) between EffectiveFrom and isnull(EffectiveTo,GETDATE())

if @pStatus = 'C'    
 Begin    
 if @pPayment > 0    
 Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry,LocationId,ShiftId,FactorTrans)
 Values(@pBatchProcessId,@PageFrom,358,@pPayment,'',@pCreatedBy,@CreatedDt,@BatchId,@ServiceId,@ClientId,0,@LocationId,@ShiftId,@FactorPayment)    
if @pCollection > 0    
 Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry,LocationId,ShiftId,FactorTrans)    
 Values(@pBatchProcessId,@PageFrom,359,@pCollection,'',@pCreatedBy,@CreatedDt,@BatchId,@ServiceId,@ClientId,0,@LocationId,@ShiftId,@FactorCollection)    
if @pExceptionPosting > 0    
 Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry,LocationId,ShiftId,FactorTrans)    
 Values(@pBatchProcessId,@PageFrom,360,@pExceptionPosting,'',@pCreatedBy,@CreatedDt,@BatchId,@ServiceId,@ClientId,0,@LocationId,@ShiftId,@FactorExceptionPosting)    
if @pSelfPosting > 0    
 Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry,LocationId,ShiftId,FactorTrans)    
 Values(@pBatchProcessId,@PageFrom,361,@pSelfPosting,'',@pCreatedBy,@CreatedDt,@BatchId,@ServiceId,@ClientId,0,@LocationId,@ShiftId,@FactorSelfPosting)   
if @pPatientPosting > 0    
 Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry,LocationId,ShiftId,FactorTrans)    
 Values(@pBatchProcessId,@PageFrom,364,@pPatientPosting,'',@pCreatedBy,@CreatedDt,@BatchId,@ServiceId,@ClientId,0,@LocationId,@ShiftId,@FactorPatientPosting)    
    
 Insert into TRN_kOFF_tBatchFlow (BatchId,BatchProcessId,CreatedBy,CreatedDt,StatusId,Comments)    
 Values(@BatchId,@pBatchProcessId,@pCreatedBy,@CreatedDt,6,@pComments)    
 Update TRN_kOFF_tBatchQueue Set StatusId = 6,Assigned = 0,ActToPage = PageTo Where BatchProcessId = @pBatchProcessId    
 Exec TRN_kOFF_pMarkEntryCompleted @BatchId = @BatchId, @CreatedBy  = @pCreatedBy    

 --IF(SELECT count(ID) FROM EnableNewQCAlgorithmUser(nolock) where UserId=@pCreatedBy and ActiveStatus=1)>0 
 /*SCR 1844 - Add new QC algorthim for merge batches and for liquid batches remain same*/
  Exec TRN_kOFF_pForecastBatchQcAlgorithmEnhance @BatchId = @BatchId,@CreatedBy = @pCreatedBy,@BatchProcessId = @pBatchProcessId
 --ELSE 
 --Exec TRN_kOFF_pForecastBatchQcAlgorithm @BatchId = @BatchId,@CreatedBy = @pCreatedBy,@BatchProcessId = @pBatchProcessId  /*This procedure added by mallikarjun.nam for Randome Qc Algorithm For Ticket Id :155811*/  
   
 Exec TRN_kOFF_pMarkBatchCompleted @BatchId = @BatchId,@CreatedBy = @pCreatedBy,@BatchProcessId = @pBatchProcessId    
 
 if(select COUNT(BatchProcessId) from TRN_kOFF_tManualAllocation(nolock) where BatchProcessId=@pBatchProcessId and AllocationMode='E' and status=1)>0
	 Update TRN_kOFF_tManualAllocation set status=0,AssignedTo=0 where BatchProcessId=@pBatchProcessId and AllocationMode='E' and status=1/*Added by mallikarjun*/
  
   /*SCR 1499, ReEnter transaction when batch reset,incomplete,split */
   --IF(SELECT count(ID) FROM EnableNewQCAlgorithmUser(nolock) where UserId=@pCreatedBy and ActiveStatus=1)>0  --- Now this table using for enable reenter production only for mentioned user
   exec Trn_kOFF_BatchReEnterTransaction @BatchId,@pBatchProcessId 
   
 End    
else if @pStatus = 'I'     
 Begin    
 if @pPayment > 0    
 Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry,LocationId,ShiftId,FactorTrans)    
 Values(@pBatchProcessId,@PageFrom,358,@pPayment,'',@pCreatedBy,@CreatedDt,@BatchId,@ServiceId,@ClientId,0,@LocationId,@ShiftId,@FactorPayment)    
if @pCollection > 0    
 Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry,LocationId,ShiftId,FactorTrans)
 Values(@pBatchProcessId,@PageFrom,359,@pCollection,'',@pCreatedBy,@CreatedDt,@BatchId,@ServiceId,@ClientId,0,@LocationId,@ShiftId,@FactorCollection)
if @pExceptionPosting > 0    
 Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry,LocationId,ShiftId,FactorTrans)
 Values(@pBatchProcessId,@PageFrom,360,@pExceptionPosting,'',@pCreatedBy,@CreatedDt,@BatchId,@ServiceId,@ClientId,0,@LocationId,@ShiftId,@FactorExceptionPosting)
if @pSelfPosting > 0    
 Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry,LocationId,ShiftId,FactorTrans)
 Values(@pBatchProcessId,@PageFrom,361,@pSelfPosting,'',@pCreatedBy,@CreatedDt,@BatchId,@ServiceId,@ClientId,0,@LocationId,@ShiftId,@FactorSelfPosting)
if @pPatientPosting > 0    
 Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry,LocationId,ShiftId,FactorTrans)
 Values(@pBatchProcessId,@PageFrom,364,@pPatientPosting,'',@pCreatedBy,@CreatedDt,@BatchId,@ServiceId,@ClientId,0,@LocationId,@ShiftId,@FactorPatientPosting)
    
 Insert into TRN_kOFF_tBatchFlow (BatchId,BatchProcessId,CreatedBy,CreatedDt,StatusId,Comments)    
 Values(@BatchId,@pBatchProcessId,@pCreatedBy,@CreatedDt,6,@pComments)    
 Update TRN_kOFF_tBatchQueue Set StatusId = 6,Assigned = 0,PageTo = @pCompletedPageNo,ActToPage = PageTo Where BatchProcessId = @pBatchProcessId    
 
 if(select COUNT(BatchProcessId) from TRN_kOFF_tManualAllocation(nolock) where BatchProcessId=@pBatchProcessId and AllocationMode='E' and Status=1)>0
	 Update TRN_kOFF_tManualAllocation set status=0,AssignedTo=0 where BatchProcessId=@pBatchProcessId and AllocationMode='E' and Status=1/*Added by mallikarjun*/
 
 /** Entry incomplete **/     
 Insert into TRN_kOFF_TBatchQueue(BatchId,BatchNo,PageFrom,PageTo,Assigned,ClientId,ServiceId,StatusId,Comment,CreatedBy,CreatedDt,QType)     
 Select BatchId,BatchNo,@pCompletedPageNo+1,@PageTo,0,ClientId,ServiceId,2,@pComments,@pCreatedBy,@CreatedDt,2     
 from TRN_kOFF_TBatchQueue Where BatchProcessId = @pBatchProcessId    
 Declare @NewBatchProcessId int = SCOPE_IDENTITY()    
Insert into TRN_kOFF_tBatchFlow (BatchId,BatchProcessId,CreatedBy,CreatedDt,StatusId,Comments)    
 Values(@BatchId,@NewBatchProcessId,@pCreatedBy,@CreatedDt,2,@pComments)    
 End    
else if @pStatus = 'H'     
 Begin    
  Insert into TRN_kOFF_tBatchFlow (BatchId,BatchProcessId,CreatedBy,CreatedDt,StatusId,Comments)    
  Select @BatchId,@pBatchProcessId,@pCreatedBy,@CreatedDt,17,@pHoldComments + ' : ' + @pComments    
  from TRN_kOFF_tBatches as Bat    
  Where BatchId = @BatchId and not Exists (Select 1 from TRN_kOFF_tHeldBatches Where BatchId = Bat.BatchId and ReleaseDate is null)      
  Insert into TRN_kOFF_tHeldBatches(BatchId,HeldDate,HeldBy,HeldComment)    
  Select @BatchId,getdate() as HeldDate,@pCreatedBy as HeldBy,@pHoldComments + ' : ' + @pComments    
  from TRN_kOFF_tBatches as Bat    
  Where BatchId = @BatchId and not Exists (Select 1 from TRN_kOFF_tHeldBatches Where BatchId = Bat.BatchId and ReleaseDate is null)    
  Update TRN_kOFF_tBatchQueue Set StatusId = 17,Assigned = 0 Where BatchProcessId = @pBatchProcessId    
 End    
 
 
Commit Transaction    
Select ''    
End Try    
Begin Catch    
Rollback transaction    
return Error_Message()    
End catch    
End







GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pBatchProcessSubmitV1] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchProcessSubmitV1] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchProcessSubmitV1] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_pBatchProcessSubmitV1] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_pBatchProcessSubmitV1] TO [DB_DMLSupport]
    AS [dbo];

