﻿ 
   
CREATE Proc [dbo].[MergeTrackingDetails](@scandate varchar(10),@Serviceid int, @MergeType varchar(15),@createdby  varchar(75),@Comments varchar(max))          
as          
begin          
          
/*                        
                    
Cretaed By     : Leela.T                    
Created Date   : 2017-03-29                      
Purpose        : Tracking the Merge Process              
Ticket/SCR ID  : 1195                   
TL Verified By : Ramki               
                
                 
Implemented by : Udhdyaganesh.p          
Implemented On : 10-April-2017            
                    
Reviewd by     : Udhdyaganesh.p                   
Implemented On : 10-April-2017                      
                    
*/          
          
          
insert into  MergeBatch_Tracking (scandate,Serviceid,MergeType , MergeTime,Comments,createdby )          
values(@scandate,@Serviceid ,@MergeType,getdate(),@Comments,@createdby )          
End 
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[MergeTrackingDetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MergeTrackingDetails] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MergeTrackingDetails] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[MergeTrackingDetails] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[MergeTrackingDetails] TO [DB_DMLSupport]
    AS [dbo];

