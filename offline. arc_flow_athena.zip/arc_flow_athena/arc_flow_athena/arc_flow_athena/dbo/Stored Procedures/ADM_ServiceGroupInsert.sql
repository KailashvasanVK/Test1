﻿CREATE Procedure [dbo].[ADM_ServiceGroupInsert]        
(        
@ServiceId int  
,@ServiceGroupId int  
,@CreatedBy int  
,@ClientId int     
)        
As        
Begin     
/*   
	Purpose      :Insert  servicesGroups into Database    
	Created By   : Kathiravan        
	Created Date : 29 April 2013        
	Impact to    :ClientCreation.aspx        
*/    
if ISNULL(@ClientId,0) = 0  
 select @ClientId = IDENT_CURRENT('ADM_Client')  
Insert into ADM_ServiceGroup(ServiceId,ServiceGroupId,CreatedBy,ClientId)        
Select @ServiceId,@ServiceGroupId,@CreatedBy,@ClientId        
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ServiceGroupInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ServiceGroupInsert] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ServiceGroupInsert] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_ServiceGroupInsert] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_ServiceGroupInsert] TO [DB_DMLSupport]
    AS [dbo];

