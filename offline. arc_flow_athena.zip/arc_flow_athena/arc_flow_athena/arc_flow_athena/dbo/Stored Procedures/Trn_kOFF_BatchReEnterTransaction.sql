﻿CREATE  Proc Trn_kOFF_BatchReEnterTransaction            
@BatchId int=0,@BatchProcessId int=0            
as            
/*Created By     : Noor                          
Created Date   : 2018-11-27            
Purpose        : When batch transactions are edited by other user(using Batchsplit,Reset,Incomplete) then need to regenerate in .flow production for this batch to address transaction mismatch.             
Ticket/SCR ID  : SCR 1499                   
TL Verified By : Ramakrishnan.G                          
Reviewd by     : <DBA Name>                            
Implemented by : Narayana                               
Implemented On : 2018-11-27  

Ticket/SCR ID  : SCR 1499                   
TL Verified By : Ramakrishnan.G  
Modified BY     : Noor                        
Reviewd by     : <DBA Name>                            
Implemented by : Narayana                               
Implemented On : 2018-12-04                
             
*/             
Begin            
DECLARE @Batchnum varchar(30)=''           
SELECT @Batchnum=Batchno from trn_koff_tbatches where BatchId=@BatchId and Status=1     
  
IF(Left(@Batchnum,1)='S')  
BEGIN  
return         
END  
  
if object_id('tempdb..#tmptbatchTransactSubmitLogHistoy') is not null drop table #tmptbatchTransactSubmitLogHistoy            
Create table #tmptbatchTransactSubmitLogHistoy            
(BatchNo varchar(30),BatchId int, BatchProcessId int,TransCnt int,            
CompletedPageNo int,CreatedBy int,TransServiceId int,isQCEntry int,BatchServiceId int,CreatedDate datetime)            
/*            
select batchnum,count(id) from paymentdetailmaster group by batchnum having count(batchnum)>10order by 1 descwhere batchnum=' 5448332A7598'            
ServiceId TransServiceName            
358 Payment            
359 Collection            
360 Exception Posting            
361 Self Posting            
364 Patient Creation            
*/            
            
DECLARE @isBatchTransModified int=0            
if(@BatchId>0)            
BEGIN            
If(SELECT count(BatchId) FROM TRN_kOFF_tBatchModified(nolock) where BatchID=@BatchId and ModifyMode='RP' ) > 0            
BEGIN            
SET @isBatchTransModified = 1            
END            
IF(SELECT count(BatchId) FROM trn_koff_tbatchqueue(nolock) where BatchId=@BatchId and ServiceId not in (418,452))  > 1            
BEGIN            
SET @isBatchTransModified = 1            
END    
IF(SELECT count(BatchId) FROM trn_koff_tbatchflow(nolock) where BatchId=@Batchid and StatusId=2)  > 0      /*Ticket : 368475*/        
BEGIN              
SET @isBatchTransModified = 0              
END             
END            
/* set @isBatchTransModified=1 */
if(@isBatchTransModified=1)            
BEGIN            
            
/* DECLARE @Batchnum varchar(30)='1000017A610' */

insert into #tmptbatchTransactSubmitLogHistoy(BatchNo, BatchProcessId,TransCnt,CreatedBy,TransServiceId,isQCEntry)            
select batchnum,processid,count(id), createdby,358, 0   from arc_athena..PaymentDetailMaster(nolock)                          
where BatchNum=@BatchNum group by batchnum,processid,createdby /* , isnull(isqcentry,0) */

insert into #tmptbatchTransactSubmitLogHistoy(BatchNo, BatchProcessId,TransCnt,CreatedBy,TransServiceId,isQCEntry)            
SELECT batchnum,ProcessId,count(CPId), createdby,359,0  From arc_athena.dbo.CollectionPostingMaster(nolock) col             
where col.BatchNum=@BatchNum  group by batchnum,processid,createdby /* ,isnull(isqcentry,0) */

DECLARE @userId int          
SELECT Top 1 @Userid=createdby FROM arc_flow_athena..trn_koff_tbatchflow(nolock) where batchid=@BatchId and statusid=1          

insert into #tmptbatchTransactSubmitLogHistoy(BatchNo, BatchProcessId,TransCnt,CreatedBy,TransServiceId,isQCEntry)            
select batchnum,processid,count(TransCnt) ,Case isnull(IsQCEntry,0) when 2 then @Userid else createdby end,360,isnull(IsQCEntry,0)   from(                  
SELECT batchnum,processid,modifiedby as createdby ,id as TransCnt,isnull(IsQCEntry,0) as isqcentry             
From arc_athena.dbo.BatchException(nolock) where BatchNum=@BatchNum /* and isnull(isqcentry,0)in(0,1) */
union all            
SELECT be.batchnum,be.processid,modifiedby as createdby ,id as TransCnt,0 as isqcentry From arc_athena.dbo.BatchException(nolock) be              
inner join arc_athena.dbo.refundrequestline(nolock) rf on be.batchnum=rf.batchnum and be.id=rf.rletterid where be.BatchNum=@BatchNum  and isnull(isqcentry,0)in(0,1)            
) a     group by batchnum,processid,createdby,isnull(IsQCEntry,0)                   

insert into #tmptbatchTransactSubmitLogHistoy(BatchNo, BatchProcessId,TransCnt,CreatedBy,TransServiceId,isQCEntry)                 
SELECT batchnum,processid,count(id), createdby,361,0   From arc_athena.dbo.PatientPostingMaster(nolock) pat            
where pat.batchNum=@BatchNum group by batchnum,processid,createdby,isnull(isqcentry,0)                                      

insert into #tmptbatchTransactSubmitLogHistoy(BatchNo, BatchProcessId,TransCnt,CreatedBy,TransServiceId,isQCEntry)            
Select pymnt.batchnum,processid,count(distinct csd.ClaimID), createdby,364,0   from arc_athena.dbo.PaymentDetailMaster(nolock) pymnt inner join                               
arc_athena.dbo.ClaimServiceDetailMaster(nolock) csd on pymnt.chargeID=csd.ChargeID               
inner join arc_athena.dbo.ClaimDetailMaster(nolock) clm on csd.ClaimID =clm.ClaimID                               
where pymnt.BatchNum=@BatchNum  and clm.Status =1            
group by pymnt.batchnum,processid,createdby            

/*select * from #tmptbatchTransactSubmitLogHistoy tbl inner join arc_flow_athena.dbo.trn_koff_tbatchqueue tbq            
on tbl.batchno=tbq.batchno and tbl.Batchprocessid=tbq.batchprocessid  */  

/* Update tbl set tbl.BatchServiceId=tbq.Serviceid,CompletedPageNo=PageFrom from #tmptbatchTransactSubmitLogHistoy tbl inner join arc_flow_athena.dbo.trn_koff_tbatchqueue tbq            
on tbl.batchno=tbq.batchno and tbl.Batchprocessid=tbq.batchprocessid Where tbq.batchno=@BatchNum    */

if(select count(batchid) from arc_flow_athena.dbo.trn_koff_tbatchqueue where batchno= @BatchNum)>1   
Update tbl set tbl.BatchServiceId=tbq.Serviceid,CompletedPageNo=tbq.PageFrom from #tmptbatchTransactSubmitLogHistoy tbl inner join arc_flow_athena.dbo.trn_koff_tbatchqueue tbq          
on tbl.batchno=tbq.batchno and tbl.Batchprocessid=tbq.batchprocessid Where tbq.batchno=@BatchNum       
ELSE
Update tbl set tbl.BatchServiceId=tbq.Serviceid,CompletedPageNo=tbq.PageTo,tbl.Batchprocessid=tbq.Batchprocessid from #tmptbatchTransactSubmitLogHistoy tbl inner join arc_flow_athena.dbo.trn_koff_tbatchqueue tbq          
on tbl.batchno=tbq.batchno  Where tbq.batchno=@BatchNum         


If(SELECT count(batchno) from TRN_koff_tbatchTransactReEnterTrans where BatchNo=@BatchNum)>0      
DELETE TRN_koff_tbatchTransactReEnterTrans where BatchNo=@BatchNum      

Insert into arc_flow_athena.dbo.TRN_koff_tbatchTransactReEnterTrans(CustomerId,BatchNo,BatchId, BatchProcessId,TransCnt            
,CompletedPageNo,CreatedBy,TransServiceId,BatchServiceId,isQCEntry,CreatedDate,Comments) 
select  25,tbl.batchno,tbq.batchid,tbl.batchprocessid,sum(distinct tbl.TransCnt) TransCnt,tbl.CompletedPageNo,tbl.CreatedBy,tbl.TransServiceid,tbq.Serviceid,isQCEntry,getdate(),'ReEnterProduction'  from #tmptbatchTransactSubmitLogHistoy tbl          
inner join arc_flow_athena.dbo.trn_koff_tbatchqueue(nolock) tbq          
on tbl.batchno=tbq.batchno  where tbq.batchno=@BatchNum
group by tbl.batchno,tbq.batchid,tbl.batchprocessid,tbl.CompletedPageNo,tbl.CreatedBy,tbl.TransServiceid,tbq.Serviceid,isQCEntry
                    
/* select distinct 25,tbq.batchno,tbq.batchid,tbq.batchprocessid,tbl.TransCnt,tbq.PageTo,tbl.CreatedBy,tbl.TransServiceid,tbq.Serviceid,isQCEntry,getdate(),'ReEnterProduction' from #tmptbatchTransactSubmitLogHistoy tbl            
inner join arc_flow_athena.dbo.trn_koff_tbatchqueue(nolock) tbq            
on tbl.batchno=tbq.batchno  where tbq.batchno=@BatchNum --and isnull(isQcentry,0) in (0,1) */


/*Insert Existing information*/            
Insert into TRN_kOFF_tBatchTransactLog(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,UpdatedBy,UpdatedDt,isQcEntry)                    
select BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,CreatedBy,getdate(),isQcEntry from TRN_kOFF_tBatchTransact where BatchId=@BatchID 
/*and BatchProcessId=@BatchProcessId */

/*Delete existing information and Insert new information*/            

DELETE TRN_kOFF_tBatchTransact WHERE batchid=@BatchId 
/*and  BatchProcessId=@BatchProcessId */


Insert into TRN_kOFF_tBatchTransact(BatchProcessId,PageNo,ServiceId,TransValue,InfoValue,CreatedBy,CreatedDt,BatchId,BatchServiceId,ClientId,isQcEntry,LocationId,ShiftId,FactorTrans)               
SELECT distinct BatchProcessId,CompletedPageNo,TransServiceId,TransCnt,Case isqcentry when 1 then 'EE' else '' end as InfoValue,tbR.CreatedBy,getdate(),tb.BatchId,            
tbR.BatchServiceId,tb.ClientId,isQCEntry,(Select LocationId from ARC_REC_ATHENA..ARC_REC_User_Info(nolock) where UserId = tbR.CreatedBy) as LocationId,            
(Select Top 1 SHIFT_ID from ARC_REC_ATHENA.dbo.ARC_REC_SHIFT_TRAN(nolock) where USERID = tbR.CreatedBy and Effect_DATE <= GETDATE() Order by Effect_DATE desc) as ShiftId,            
Case isQCEntry when 1 then (SELECT QCPayment FROM ADM_FactorWaterTown(nolock) Where ServiceGroupId = tbR.BatchServiceId and CONVERT(date,getdate()) between EffectiveFrom and isnull(EffectiveTo,GETDATE()))            
when 0 then (SELECT EntryPayment FROM ADM_FactorWaterTown(nolock) Where ServiceGroupId = tbR.BatchServiceId and CONVERT(date,getdate()) between EffectiveFrom and isnull(EffectiveTo,GETDATE())) end as FactorTrans             
FROM TRN_koff_tbatchTransactReEnterTrans(nolock) tbR inner join trn_koff_tbatches tb on tbR.batchno=tb.batchno             
where tb.batchid=@BatchId  and CompletedPageNo is not null
/*and tbR.BatchProcessId=@BatchProcessId */           


End            
END



GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Trn_kOFF_BatchReEnterTransaction] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[Trn_kOFF_BatchReEnterTransaction] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[Trn_kOFF_BatchReEnterTransaction] TO [DB_DMLSupport]
    AS [dbo];

