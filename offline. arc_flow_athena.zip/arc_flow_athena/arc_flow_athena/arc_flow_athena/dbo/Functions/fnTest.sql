﻿Create function fnTest()
returns varchar(100)
As
Begin
Declare @rt varchar(100)
Set @rt = ( SELECT * FROM  OPENROWSET( 'sqloledb',

                    'Server=172.19.5.4;Trusted_Connection=yes;',

                    'SET FMTONLY OFF; SET NOCOUNT ON; exec ARC_Flow.dbo.TestSP'

                  ))
return @rt
End



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[fnTest] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[fnTest] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[fnTest] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[fnTest] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[fnTest] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[fnTest] TO [DB_DMLSupport]
    AS [dbo];

