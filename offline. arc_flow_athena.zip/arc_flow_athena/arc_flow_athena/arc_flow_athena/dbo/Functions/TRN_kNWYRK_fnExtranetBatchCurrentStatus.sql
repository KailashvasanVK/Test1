﻿Create function [dbo].[TRN_kNWYRK_fnExtranetBatchCurrentStatus](@BatchId int,@Cmpkey varchar(5))
Returns varchar(100)
As
Begin
Declare @Batchstatus varchar(100)
	Select @Batchstatus = 'Held' from TRN_kNWYRK_tHeldBatches Where BatchId = @BatchId and ReleaseDate is null
	if ISNULL(@Batchstatus,'') = ''
		Select @Batchstatus = Case when Bat.UploadDt is null then 'InProgress' else 'Completed' end	
		from TRN_kNWYRK_tBatches as Bat  where Bat.BatchId=@BatchId
Return @Batchstatus
End
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kNWYRK_fnExtranetBatchCurrentStatus] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kNWYRK_fnExtranetBatchCurrentStatus] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kNWYRK_fnExtranetBatchCurrentStatus] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kNWYRK_fnExtranetBatchCurrentStatus] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kNWYRK_fnExtranetBatchCurrentStatus] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kNWYRK_fnExtranetBatchCurrentStatus] TO [DB_DMLSupport]
    AS [dbo];

