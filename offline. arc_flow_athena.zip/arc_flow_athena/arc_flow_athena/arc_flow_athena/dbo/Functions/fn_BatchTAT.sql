﻿CREATE Function fn_BatchTAT(@BatchId int)
Returns decimal as
Begin
Declare @TAT decimal(10,2)
Set @TAT = 75
Return @TAT
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[fn_BatchTAT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[fn_BatchTAT] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[fn_BatchTAT] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[fn_BatchTAT] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[fn_BatchTAT] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[fn_BatchTAT] TO [DB_DMLSupport]
    AS [dbo];

