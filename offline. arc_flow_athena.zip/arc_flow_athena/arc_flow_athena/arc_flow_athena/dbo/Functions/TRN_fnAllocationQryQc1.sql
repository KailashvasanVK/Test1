﻿CREATE function TRN_fnAllocationQryQc1(@Mode varchar(20),@CmpKey varchar(5),@CustomerId int,@UserId int) Returns varchar(max)
As
Begin
Declare @Qry varchar(max)
if @Mode = 'Assigned'
 Set @Qry = '    
 /* Checking any incomplete process exists for respective user */    
 Insert into #QueuedBatch(BatchProcessId,BatchNo,PageFrom,PageTo,AssignedTo,StatusId,Client,Service,BatchType,Qtype,BatchId,Scandate,PageInfo    
 ,CustomerId,ServiceId,ClientId,PageStart,TotPages,LastComment)    
 select Top 1 batQ.BatchProcessId,bat.BatchNo,batQ.PageFrom,batQ.PageTo,batQ.Assigned    
 ,batQ.StatusId,cli.ClientAcmName as Client    
 ,ser.ServiceName as [Service],''QC '' + qt.QDescription as BatchType,batQ.Qtype,batQ.BatchId,bat.Scandate    
 ,''From '' + cast(batQ.PageFrom as varchar) + '' To '' + cast(batQ.PageTo as varchar) + '' ; Count : '' + cast((batQ.PageTo - batQ.PageFrom) + 1 as varchar) as PageInfo    
 ,cli.CustomerId,batQ.ServiceId,batQ.ClientId,batQ.PageFrom,bat.PgCount
 ,(Select top 1 Comment from TRN_k'+ @CmpKey +'_tBatchFlow Where BatchProcessId = batQ.BatchProcessId and StatusId = batQ.StatusId Order by FlowId desc) as LastComment
 from TRN_k'+ @CmpKey +'_tBatchQueue (nolock) as batQ    
 inner join ADM_Client (nolock) as cli on cli.CustomerId = '+ cast(@CustomerId as varchar)+' and cli.ClientId = batQ.ClientId
 inner join ADM_Service (nolock) as ser on ser.ServiceId = batQ.ServiceId
 inner join ADM_BatchQueueTypeMaster as qt on qt.Qtype = batQ.Qtype      
 inner join TRN_k'+ @CmpKey +'_tBatches (nolock) as bat on bat.BatchId = batQ.BatchId and bat.Status = 1  and bat.UploadDt is null
 /*inner join #PrivilegeCustomer as priv on priv.CustomerId = ' + CAST(@CustomerId as varchar) + '    */
 where batQ.StatusId = 7 and batQ.Assigned = '+CAST(@UserId as varchar)+' /*and batQ.ServiceId = priv.ServiceId  */
 and not exists (select 1 from TRN_k'+@CmpKey+'_tHeldBatches Where BatchId = batQ.BatchId and ReleaseDate is null)  
 order by bat.Scandate,BatQ.StatusId desc,bat.PgCount desc,batQ.BatchProcessId'    
else if @Mode = 'Alloted'
 Set @Qry = '    
 Insert into #QueuedBatch(BatchProcessId,BatchNo,PageFrom,PageTo,AssignedTo,StatusId,Client,Service,BatchType,Qtype,BatchId,Scandate,PageInfo    
 ,CustomerId,ServiceId,ClientId,PageStart,TotPages,LastComment)    
 select Top 1 batQ.BatchProcessId,bat.BatchNo,batQ.PageFrom,batQ.PageTo,batQ.Assigned    
 ,batQ.StatusId,cli.ClientAcmName as Client    
 ,ser.ServiceName as [Service],''QC '' + qt.QDescription as BatchType,batQ.Qtype,batQ.BatchId,bat.Scandate    
 ,''From '' + cast(batQ.PageFrom as varchar) + '' To '' + cast(batQ.PageTo as varchar) + '' ; Count : '' + cast((batQ.PageTo - batQ.PageFrom) + 1 as varchar) as PageInfo    
 ,cli.CustomerId,batQ.ServiceId,batQ.ClientId,batQ.PageFrom,bat.PgCount
 ,(Select top 1 Comment from TRN_k'+ @CmpKey +'_tBatchFlow Where BatchProcessId = batQ.BatchProcessId and StatusId = batQ.StatusId Order by FlowId desc) as LastComment
 from TRN_k'+ @CmpKey +'_tBatchQueue (nolock) as batQ    
 inner join ADM_Client (nolock) as cli on cli.CustomerId = '+ cast(@CustomerId as varchar)+' and cli.ClientId = batQ.ClientId and cli.Status = 1     
 inner join ADM_Service (nolock) as ser on ser.ServiceId = batQ.ServiceId and ser.Status = 1      
 inner join ADM_BatchQueueTypeMaster as qt on qt.Qtype = batQ.Qtype      
 inner join TRN_k'+ @CmpKey +'_tBatches (nolock) as bat on bat.BatchId = batQ.BatchId   and bat.Status = 1   and bat.UploadDt is null and bat.PostedDt is not null
 inner join TRN_k'+ @CmpKey + '_tManualAllocation (nolock) as alloc on alloc.BatchProcessId = batQ.BatchProcessId and alloc.AllocationMode = ''Q'' and alloc.Status = 1 and alloc.AssignedTo = ' + CONVERT(varchar,@UserId) + '
 inner join #PrivilegeCustomer as priv on priv.CustomerId = ' + CAST(@CustomerId as varchar) + '      
 where batQ.StatusId in (6,20) and batQ.Assigned = 0 and batQ.ServiceId = priv.ServiceId   
 and not exists (select 1 from  TRN_k'+ @CmpKey +'_tBatchFlow where BatchProcessId = batQ.BatchProcessId and StatusId = 6 and CreatedBy = '+CAST(@UserId as varchar)+')  
 and not exists (select 1 from TRN_k'+@CmpKey+'_tHeldBatches Where BatchId = batQ.BatchId and ReleaseDate is null)  
 and not exists (Select 1 from TRN_k'+@CmpKey+'_tDirectUpload exDir Where exDir.BatchId = batQ.BatchId and exDir.Status = 1)  
 and not exists (Select 1 from TRN_k'+@CmpKey+'_tBatchQueue exQ Where exQ.BatchId = batQ.BatchId and exQ.StatusId in (2,3,17))  
 and not exists (select 1 from TRN_k'+@CmpKey+'_tHeldBatches Where BatchId = batQ.BatchId and ReleaseDate is null)   
  order by bat.Scandate,priv.Priority,qt.Priority,bat.Priority desc,BatQ.StatusId desc,bat.PgCount desc,batQ.BatchProcessId'    

else /* Pending */ 
 Set @Qry = '    
 Insert into #QueuedBatch(BatchProcessId,BatchNo,PageFrom,PageTo,AssignedTo,StatusId,Client,Service,BatchType,Qtype,BatchId,Scandate,PageInfo    
 ,CustomerId,ServiceId,ClientId,PageStart,TotPages,LastComment)    
 select Top 1 batQ.BatchProcessId,bat.BatchNo,batQ.PageFrom,batQ.PageTo,batQ.Assigned    
 ,batQ.StatusId,cli.ClientAcmName as Client    
 ,ser.ServiceName as [Service],''QC '' + qt.QDescription as BatchType,batQ.Qtype,batQ.BatchId,bat.Scandate    
 ,''From '' + cast(batQ.PageFrom as varchar) + '' To '' + cast(batQ.PageTo as varchar) + '' ; Count : '' + cast((batQ.PageTo - batQ.PageFrom) + 1 as varchar) as PageInfo    
 ,cli.CustomerId,batQ.ServiceId,batQ.ClientId,batQ.PageFrom,bat.PgCount  
 ,(Select top 1 Comment from TRN_k'+ @CmpKey +'_tBatchFlow Where BatchProcessId = batQ.BatchProcessId and StatusId = batQ.StatusId Order by FlowId desc) as LastComment
 from TRN_k'+ @CmpKey +'_tBatchQueue (nolock) as batQ    
 /*inner join TRN_k'+ @CmpKey +'_tManualAllocation as alloc on alloc.BatchProcessId <> batQ.BatchProcessId and alloc.AllocationMode = ''Q'' and alloc.Status = 1*/
 inner join ADM_Client (nolock) as cli on cli.CustomerId = '+ cast(@CustomerId as varchar)+' and cli.ClientId = batQ.ClientId and cli.Status = 1     
 inner join ADM_Service (nolock) as ser on ser.ServiceId = batQ.ServiceId and ser.Status = 1      
 inner join ADM_BatchQueueTypeMaster as qt on qt.Qtype = batQ.Qtype      
 inner join TRN_k'+ @CmpKey +'_tBatches (nolock) as bat on bat.BatchId = batQ.BatchId   and bat.Status = 1 
			and bat.UploadDt is null 
			and bat.PostedDt is not null
 inner join #PrivilegeCustomer as priv on priv.CustomerId = ' + CAST(@CustomerId as varchar) + '    
 where batQ.StatusId in (6,20) and batQ.Assigned = 0 and batQ.ServiceId = priv.ServiceId   
 and not exists (select 1 from  TRN_k'+ @CmpKey +'_tBatchFlow where BatchProcessId = batQ.BatchProcessId and StatusId = 6 and CreatedBy = '+CAST(@UserId as varchar)+')  
 and not exists (select 1 from TRN_k'+@CmpKey+'_tHeldBatches Where BatchId = batQ.BatchId and ReleaseDate is null) 
 and not exists (Select 1 from TRN_k'+@CmpKey+'_tDirectUpload exDir Where exDir.BatchId = batQ.BatchId and exDir.Status = 1)  
 and not exists (Select 1 from TRN_k'+@CmpKey+'_tBatchQueue exQ Where exQ.BatchId = batQ.BatchId and exQ.StatusId in (2,3,17))  
 and not exists (select 1 from TRN_k'+@CmpKey+'_tHeldBatches Where BatchId = batQ.BatchId and ReleaseDate is null)  
 and not exists (Select 1 from TRN_k'+ @CmpKey +'_tManualAllocation alloc where BatchProcessId = batQ.BatchProcessId and alloc.AllocationMode = ''Q'' and alloc.Status = 1)  
 order by bat.Scandate,priv.Priority,qt.Priority,bat.Priority desc,BatQ.StatusId desc,bat.PgCount desc,batQ.BatchProcessId'    
Return @Qry
End

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_fnAllocationQryQc1] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_fnAllocationQryQc1] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_fnAllocationQryQc1] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_fnAllocationQryQc1] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_fnAllocationQryQc1] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_fnAllocationQryQc1] TO [DB_DMLSupport]
    AS [dbo];

