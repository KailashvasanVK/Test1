﻿CREATE function TRN_fnAllocationQryQc(@Mode varchar(20),@CmpKey varchar(5),@CustomerId int,@UserId int) Returns varchar(max)
As
Begin
Declare @Qry varchar(max)
if @Mode = 'Assigned'
 Set @Qry = '    
 /* Checking any incomplete process exists for respective user */    
 Insert into #QueuedBatch(BatchProcessId,BatchNo,PageFrom,PageTo,AssignedTo,StatusId,Client,Service,BatchType,Qtype,BatchId,Scandate,PageInfo    
 ,CustomerId,ServiceId,ClientId,PageStart)    
 select Top 1 batQ.BatchProcessId,batQ.BatchNo,batQ.PageFrom,batQ.PageTo,batQ.Assigned    
 ,batQ.StatusId,cli.ClientAcmName as Client    
 ,ser.ServiceName as [Service],''QC '' + qt.QDescription as BatchType,batQ.Qtype,batQ.BatchId,bat.Scandate    
 ,''From '' + cast(batQ.PageFrom as varchar) + '' To '' + cast(batQ.PageTo as varchar) + '' ; Count : '' + cast((batQ.PageTo - batQ.PageFrom) + 1 as varchar) as PageInfo    
 ,cli.CustomerId,batQ.ServiceId,batQ.ClientId,batQ.PageFrom    
 from TRN_k'+ @CmpKey +'_tBatchQueue (nolock) as batQ    
 inner join ADM_Client (nolock) as cli on cli.CustomerId = '+ cast(@CustomerId as varchar)+' and cli.ClientId = batQ.ClientId
 inner join ADM_Service (nolock) as ser on ser.ServiceId = batQ.ServiceId
 inner join ADM_BatchQueueTypeMaster as qt on qt.Qtype = batQ.Qtype      
 inner join TRN_k'+ @CmpKey +'_tBatches (nolock) as bat on bat.BatchId = batQ.BatchId /**  and bat.UploadDt is null  **/
 inner join #PrivilegeCustomer as priv on priv.CustomerId = ' + CAST(@CustomerId as varchar) + '    
 where batQ.StatusId = 7 and batQ.Assigned = '+CAST(@UserId as varchar)+' and batQ.ServiceId = priv.ServiceId  
 and not exists (select 1 from TRN_k'+@CmpKey+'_tHeldBatches Where BatchId = batQ.BatchId and ReleaseDate is null)  
 order by batQ.CreatedDt,batQ.BatchId'    
else /* Pending */
 Begin
 Set @Qry = '    
 Insert into #QueuedBatch(BatchProcessId,BatchNo,PageFrom,PageTo,AssignedTo,StatusId,Client,Service,BatchType,Qtype,BatchId,Scandate,PageInfo    
 ,CustomerId,ServiceId,ClientId,PageStart)    
 select Top 1 batQ.BatchProcessId,batQ.BatchNo,batQ.PageFrom,batQ.PageTo,batQ.Assigned    
 ,batQ.StatusId,cli.ClientAcmName as Client    
 ,ser.ServiceName as [Service],''QC '' + qt.QDescription as BatchType,batQ.Qtype,batQ.BatchId,bat.Scandate    
 ,''From '' + cast(batQ.PageFrom as varchar) + '' To '' + cast(batQ.PageTo as varchar) + '' ; Count : '' + cast((batQ.PageTo - batQ.PageFrom) + 1 as varchar) as PageInfo    
 ,cli.CustomerId,batQ.ServiceId,batQ.ClientId,batQ.PageFrom    
 from TRN_k'+ @CmpKey +'_tBatchQueue (nolock) as batQ    
 inner join ADM_Client (nolock) as cli on cli.CustomerId = '+ cast(@CustomerId as varchar)+' and cli.ClientId = batQ.ClientId and cli.Status = 1     
 inner join ADM_Service (nolock) as ser on ser.ServiceId = batQ.ServiceId and ser.Status = 1     
 inner join ADM_AccessClient (nolock) as accCli on accCli.UserId = '+Cast(@UserId as varchar)+' and accCli.CustomerId = '+ cast(@CustomerId as varchar)+' and accCli.ClientId = cli.ClientId and accCli.ServiceId = ser.ServiceId
 inner join ADM_BatchQueueTypeMaster as qt on qt.Qtype = batQ.Qtype      
 inner join TRN_k'+ @CmpKey +'_tBatches (nolock) as bat on bat.BatchId = batQ.BatchId   and bat.Status = 1   /**  and bat.UploadDt is null  **/
 inner join #PrivilegeCustomer as priv on priv.CustomerId = ' + CAST(@CustomerId as varchar) + '    
 where batQ.StatusId in (6) and batQ.Assigned = 0 and batQ.ServiceId = priv.ServiceId   
 and not exists (select 1 from  TRN_k'+ @CmpKey +'_tBatchFlow where BatchProcessId = batQ.BatchProcessId and StatusId = 6 and CreatedBy = '+CAST(@UserId as varchar)+')  
 and not exists (select 1 from TRN_k'+@CmpKey+'_tHeldBatches Where BatchId = batQ.BatchId and ReleaseDate is null)  
 and not exists (Select 1 from TRN_k'+@CmpKey+'_tDirectUpload exDir Where exDir.BatchId = batQ.BatchId and exDir.Status = 1)  
 and not exists (Select 1 from TRN_k'+@CmpKey+'_tBatchQueue exQ Where exQ.BatchId = batQ.BatchId and exQ.StatusId in (2,3,17))  
 and not exists (select 1 from TRN_k'+@CmpKey+'_tHeldBatches Where BatchId = batQ.BatchId and ReleaseDate is null)  
 and batQ.BatchId in (
		Select comp.BatchId from 
		(
		Select q.BatchId,COUNT(*) as Cnt from TRN_k'+@CmpKey+'_tBatchQueue as q
		inner join TRN_k'+@CmpKey+'_tBatches as bat on bat.BatchId = q.BatchId and bat.UploadDt is null
		group by q.BatchId
		)x
		inner join 
		(
		Select q.BatchId,COUNT(*) as Cnt from TRN_k'+@CmpKey+'_tBatchQueue as q
		inner join TRN_k'+@CmpKey+'_tBatches as bat on bat.BatchId = q.BatchId and bat.UploadDt is null
		Where StatusId in (6,12,13)
		group by q.BatchId
		) comp on comp.BatchId = x.BatchId and comp.Cnt = x.Cnt
	)
 '  
 if @CmpKey <> 'Virgi' 
  Set @Qry += ' and (batQ.Qtype <> 0 or (batQ.QType = 0 and batQ.CreatedDt < convert(varchar,Convert(varchar,GETDATE(),101) + '' 9:00:00'')))'
 Set @Qry += ' order by priv.Priority,qt.Priority,bat.Priority desc,bat.CreatedDt,accCli.AccClientId,batQ.StatusId desc'    
 end
Return @Qry
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_fnAllocationQryQc] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_fnAllocationQryQc] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_fnAllocationQryQc] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_fnAllocationQryQc] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_fnAllocationQryQc] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_fnAllocationQryQc] TO [DB_DMLSupport]
    AS [dbo];

