﻿CREATE function [dbo].[TRN_kNwEng_fnGetBatchCurrentStatus](@BatchId int)
Returns varchar(100)
As
Begin
Declare @StatusCaption varchar(100)

 Select @StatusCaption='Disregard' from TRN_kNwEng_tBatches Where BatchId = @BatchId and status=0
if ISNULL(@StatusCaption,'') = ''
	Select @StatusCaption = 'Held' from TRN_kNwEng_tHeldBatches Where BatchId = @BatchId and ReleaseDate is null
if ISNULL(@StatusCaption,'') = ''
	Select Top 1 @StatusCaption = Case when bat.UploadDt is not null then 'Batch Completed' else batState.StatusCaption end 
	from TRN_kNwEng_tBatchQueue as Q
	inner join TRN_kNwEng_tBatches as Bat on Bat.BatchId = Q.BatchId
	inner join ADM_BatchStatusMaster as batState on batState.StatusId = q.StatusId
	Where Q.BatchId = @BatchId  AND q.QType IN (2,3)
	Order by Q.BatchProcessId Desc
Return @StatusCaption
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kNwEng_fnGetBatchCurrentStatus] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kNwEng_fnGetBatchCurrentStatus] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kNwEng_fnGetBatchCurrentStatus] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kNwEng_fnGetBatchCurrentStatus] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kNwEng_fnGetBatchCurrentStatus] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kNwEng_fnGetBatchCurrentStatus] TO [DB_DMLSupport]
    AS [dbo];

