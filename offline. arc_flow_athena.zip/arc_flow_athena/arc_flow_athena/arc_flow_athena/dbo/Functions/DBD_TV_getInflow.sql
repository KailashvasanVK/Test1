﻿
CREATE Function dbo.DBD_TV_getInflow(@FromDate date, @ToDate date, @ForeCast decimal(18,2), @CustomerId int) 
Returns int 
As
Begin
       Declare @WorkingDays int, @Inflow int

       select @WorkingDays=count(1) from [LNKTPARFLOW].arC_dashboard.dbo.DimDate where date between @FromDate and @ToDate and IsWeekday=1

	   if @ToDate>convert(varchar, getdate(), 101)
		set @ToDate=convert(varchar, getdate(), 101)

       select @Inflow=sum(round(@ForeCast/@WorkingDays,0))  from DimDate 
       where date between @FromDate and @ToDate and IsWeekday=1

       return @Inflow
End 


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[DBD_TV_getInflow] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[DBD_TV_getInflow] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[DBD_TV_getInflow] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[DBD_TV_getInflow] TO [DB_DMLSupport]
    AS [dbo];

