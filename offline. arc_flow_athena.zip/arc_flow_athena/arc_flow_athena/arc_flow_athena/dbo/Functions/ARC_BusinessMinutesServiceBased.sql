﻿CREATE function ARC_BusinessMinutesServiceBased(@dFrom datetime,@dTo datetime,@CustomerId int,@ServiceId int)
Returns int as
Begin
----Declare @dFrom datetime = '2014-07-03 09:00:00.000'
----Declare @dTo datetime  = '2014-07-07 20:41:40.880'
----Declare @CustomerId int = 12,@ServiceId int = 229
Declare @HolidayType int = 2
if @HolidayType is null Set @HolidayType = 2
Declare @Min int = 0
Declare @tempTo datetime = @dTo
if DATEPART(DD,@dFrom) = DATEPART(DD,@dTo)
	Begin
	if DATENAME(Weekday,@dFrom) <> 'Saturday' and DATENAME(Weekday,@dFrom) <> 'Sunday' and (Select COUNT(*) from ARC_Rec_Athena..ARC_REC_LEAVE_HOLIDAYLIST Where HOLIDAY_DATE = Convert(date,@dFrom) and listType = @HolidayType) <> 1
		Set @Min = DATEDIFF(MINUTE,@dFrom,@dTo)	
	End
Else
	While @dFrom <= @dTo
	Begin
	
	Set @tempTo = CONVERT(datetime,DateAdd(DD,1,Convert(date,@dFrom)))	
	if @tempTo > @dTo
		Set @tempTo = @dTo
	if DATENAME(Weekday,@dFrom) <> 'Saturday' and DATENAME(Weekday,@dFrom) <> 'Sunday' and (Select COUNT(*) from ARC_Rec_Athena..ARC_REC_LEAVE_HOLIDAYLIST Where HOLIDAY_DATE = Convert(date,@dFrom) and listType = @HolidayType) <> 1
		begin
		Set @Min += DATEDIFF(MINUTE,@dFrom,@tempTo)	
		end
	Set @dFrom = DATEADD(DD,1,Convert(date,@dFrom))
	End
	--Select @Min,@Min/60.0
Return @Min
End


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_BusinessMinutesServiceBased] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_BusinessMinutesServiceBased] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_BusinessMinutesServiceBased] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_BusinessMinutesServiceBased] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ARC_BusinessMinutesServiceBased] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ARC_BusinessMinutesServiceBased] TO [DB_DMLSupport]
    AS [dbo];

