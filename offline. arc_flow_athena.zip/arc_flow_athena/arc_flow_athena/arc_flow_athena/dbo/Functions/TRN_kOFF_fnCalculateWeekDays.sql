﻿-- =============================================
-- Author:		<Mallikarjun.nam>
-- Create date: <04-09-2015>ddmmyyy
-- Description:	<Calculate week day from given dates>
-- =============================================
CREATE FUNCTION  TRN_kOFF_fnCalculateWeekDays
(
	-- Add the parameters for the function here
	@fromDate date,@toDate date
)
RETURNS int
AS
BEGIN
	DECLARE @WORKDAYS INT=0
	Declare @pfromDate date=@fromDate
	WHILE @pfromDate<=@toDate
	BEGIN	  
		IF (DATENAME(DW,@pfromDate) Not in ('saturday','sunday')) and 
		   (select count(Holiday_Date) from arc_rec_athena..Athena_Holidaylist  where Holiday_Date =cast(@pfromDate as date))=0 
		   
		Begin 
			SET @WORKDAYS=@WORKDAYS+1
		End
		
		SET @pfromDate=DATEADD(d,1,@pfromDate)

	END
	
     /*
     DECLARE @WORKDAYS INT
	 SELECT @WORKDAYS = (DATEDIFF(dd, @fromDate, @toDate) + 1)
					  -(DATEDIFF(wk, @fromDate, @toDate) * 2)
   				      -(CASE WHEN DATENAME(dw, @fromDate) = 'Sunday' THEN 1 ELSE 0 END)
				      -(CASE WHEN DATENAME(dw, @toDate) = 'Saturday' THEN 1 ELSE 0 END)
	-- Return the result of the function
	RETURN @WORKDAYS
	*/
	RETURN @WORKDAYS
END

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_fnCalculateWeekDays] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_fnCalculateWeekDays] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_fnCalculateWeekDays] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_fnCalculateWeekDays] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_fnCalculateWeekDays] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_fnCalculateWeekDays] TO [DB_DMLSupport]
    AS [dbo];

