﻿
-- =============================================
-- Author:		<Mallikarjun.nam>
-- Create date: <04-09-2015>ddmmyyy
-- Description:	<Calculate week day from given dates and excluding holidays and week ends>
-- =============================================

Create FUNCTION [dbo].[TRN_kOFF_fnAddWorkingDays]
(
	@addDate datetime,
    @days int
)
RETURNS DATETIME
AS
BEGIN
 Declare @Tatdays int =@days
 WHILE @days>0
    BEGIN
       if(@Tatdays=@days)
       Begin
		   IF DATENAME(DW,@addDate)='saturday' SET @addDate=DATEADD(d,1,@addDate)
		   IF DATENAME(DW,@addDate)='sunday' SET @addDate=DATEADD(d,1,@addDate)
		   IF(select count(Holiday_Date) from arc_rec_athena..ARC_REC_LEAVE_HOLIDAYLIST  where Holiday_Date =cast(@addDate as date) and ListType=2)>0 
		   SET @addDate=DATEADD(d,1,@addDate)
       End
       
       SET @addDate=DATEADD(d,1,@addDate)
       IF DATENAME(DW,@addDate)='saturday' SET @addDate=DATEADD(d,1,@addDate)
       IF DATENAME(DW,@addDate)='sunday' SET @addDate=DATEADD(d,1,@addDate)
       IF(select count(Holiday_Date) from arc_rec_athena..ARC_REC_LEAVE_HOLIDAYLIST  where Holiday_Date =cast(@addDate as date) and ListType=2)>0 
       SET @addDate=DATEADD(d,1,@addDate)
       SET @days=@days-1
    END
    RETURN @addDate
END

GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_fnAddWorkingDays] TO [ACCESSHEALTHCAR\mallikarjun.nam]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_fnAddWorkingDays] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_fnAddWorkingDays] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_fnAddWorkingDays] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_fnAddWorkingDays] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[TRN_kOFF_fnAddWorkingDays] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[TRN_kOFF_fnAddWorkingDays] TO [DB_DMLSupport]
    AS [dbo];

