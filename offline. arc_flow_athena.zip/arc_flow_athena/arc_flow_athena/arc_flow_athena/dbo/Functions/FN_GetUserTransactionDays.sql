﻿CREATE function dbo.FN_GetUserTransactionDays (@Userid int)      
RETURNS INT      
AS      
BEGIN      
      
   DECLARE @Result VARCHAR(50)      
          Set @Result = 100  
    RETURN @Result      
END 


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[FN_GetUserTransactionDays] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[FN_GetUserTransactionDays] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[FN_GetUserTransactionDays] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[FN_GetUserTransactionDays] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[FN_GetUserTransactionDays] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[FN_GetUserTransactionDays] TO [DB_DMLSupport]
    AS [dbo];

