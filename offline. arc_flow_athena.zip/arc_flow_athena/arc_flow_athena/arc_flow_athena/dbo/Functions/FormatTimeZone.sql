﻿CREATE Function FormatTimeZone(@CurrentTime datetime,@TimeZone varchar(5)) Returns datetime
As
Begin
Declare @FormatedTime datetime
Declare @UTC_DATE datetime = DATEADD(MINUTE,DATEDIFF(MINUTE,getdate(),GETUTCDATE()),@CurrentTime)
Select @FormatedTime = Convert(datetime,x.[Current Time]) from ( 
SELECT 'UTC Time' as 'TimeZone','UTC' as 'TimeAbb' ,CONVERT(varchar(20),@UTC_DATE,113) as 'Current Time'
UNION ALL
--IST Time i.e. India Time=UTC+5:30
SELECT 'India Time' as 'TimeZone','IST' as 'TimeAbb',CONVERT(varchar(20),DATEADD(MI,30,DATEADD(hh,5,@UTC_DATE)),113) as 'Current Time'
UNION ALL
-- Atlantic Time = UTC-4
SELECT 'Atlantic Time' as 'TimeZone','AST' as 'TimeAbb',CONVERT(varchar(20),DATEADD(hh,-4,@UTC_DATE),113) as 'Current Time'
UNION ALL
-- Eastern Time = UTC-5
SELECT 'Eastern Time' as 'TimeZone','EST' as 'TimeAbb',CONVERT(varchar(20),DATEADD(hh,-5,@UTC_DATE),113) as 'Current Time'
UNION ALL
-- Mountain Time = UTC-6
SELECT 'Mountain Time' as 'TimeZone','MST' as 'TimeAbb',CONVERT(varchar(20),DATEADD(hh,-6,@UTC_DATE),113) as 'Current Time'
UNION ALL
-- Pacific Time = UTC-8
SELECT 'Pacific Time' as 'TimeZone','PST' as 'TimeAbb',CONVERT(varchar(20),DATEADD(hh,-8,@UTC_DATE),113) as 'Current Time'
UNION ALL
-- Alaska Time = UTC-9
SELECT 'Alaska Time' as 'TimeZone','AKST' as 'TimeAbb',CONVERT(varchar(20),DATEADD(hh,-9,@UTC_DATE),113) as 'Current Time'
UNION ALL
-- Hawai Time = UTC-10
SELECT 'Hawai Time' as 'TimeZone','HST' as 'TimeAbb',CONVERT(varchar(20),DATEADD(hh,-10,@UTC_DATE),113) as 'Current Time'
)x Where [TimeAbb] = @TimeZone
Return @FormatedTime
End



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[FormatTimeZone] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[FormatTimeZone] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[FormatTimeZone] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[FormatTimeZone] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[FormatTimeZone] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[FormatTimeZone] TO [DB_DMLSupport]
    AS [dbo];

