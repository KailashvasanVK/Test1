﻿


CREATE Function fnQualityCalculation(@EFCount bigint,@EFTrans bigint,@EDCount bigint,@EDTrans bigint,@EntryGrid decimal(15,2),@QcGrid decimal(15,2)) returns decimal(15,2)
As
Begin
Select @EFCount = ISNULL(@EFCount,0)
	,@EFTrans = isnull(@EFTrans ,0),@EDCount = isnull(@EDCount ,0),@EDTrans = isnull(@EDTrans,0)
Declare @EFRatio decimal(15,2) = Convert(Decimal(15,2),case when @EFTrans = 0 then 0 else (@EFTrans / Convert(Decimal(15,2),(@EFTrans + @EDTrans)))*100 end)
Declare @EDRatio decimal(15,2) = Convert(Decimal(15,2),case when @EDTrans = 0 then 0 else 100.0 - @EFRatio end)
Declare @ErrorFoundPer decimal(15,2) = case when @EFTrans=0 or @EFCount = 0 then 0 else (100- ((@EFCount/Convert(decimal(15,2),@EFTrans))*100))*(@EFRatio/100.0) end
Declare @ErrorDonePer decimal(15,2) = case when @EDTrans=0 then 0 else (100- ((@EDCount/Convert(decimal(15,2),@EDTrans))*100))*(@EDRatio/100.0) end
Declare @Quality decimal(15,2)
if @ErrorDonePer = 0 and @ErrorFoundPer = 0 and @EFTrans = 0 and @EFCount = 0 and @EDCount = 0 and @EDTrans = 0
	Set @Quality = 0
Else
	Set @Quality = Convert(Decimal(15,2),@ErrorFoundPer + @ErrorDonePer)
Set @Quality = Case when @Quality > 100 then 100 when @Quality < 0 then 0 else @Quality end
return @Quality
End



GO
GRANT EXECUTE
    ON OBJECT::[dbo].[fnQualityCalculation] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[fnQualityCalculation] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[fnQualityCalculation] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[fnQualityCalculation] TO [DB_DMLSupport]
    AS [dbo];

