﻿CREATE FUNCTION [dbo].[fnARC_REC_UserHierarchy] (@UserId int)  
RETURNS TABLE  
AS  
RETURN   
(  
  
 with  CTE as                       
    (                      
		select   USERID, EMPCODE 
		,       REPORTING_TO                      
		,       isnull(NT_USERNAME,'') as NT_USERNAME                      
		,       1 as level                      
		from    ARC_REC_ATHENA..ARC_REC_USER_INFO                       
		where   USERID = @UserId and Active=1
	
		union all                      
		select  child.userid,child.EMPCODE                      
		,       child.REPORTING_TO                      
		,       isnull(child.NT_USERNAME,'')NT_USERNAME                      
		,       level + 1                      
		from    ARC_REC_ATHENA..ARC_REC_USER_INFO child                      
		join    CTE parent                      
		on      child.REPORTING_TO = parent.NT_USERNAME
		WHERE child.EMPCODE  IS NOT NULL AND child.REPORTING_TO IS NOT NULL and child.Active=1
    )                      
  
  select *                      
    from    CTE  --where  USERID <> @UserId    and EMPCODE<>''  and nt_username<>''      
    
); 

