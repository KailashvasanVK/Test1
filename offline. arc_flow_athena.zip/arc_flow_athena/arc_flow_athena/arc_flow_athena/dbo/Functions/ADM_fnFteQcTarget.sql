﻿CREATE function ADM_fnFteQcTarget(@CustomerId int ,@ServiceId int,@FteId int)  
Returns Decimal(9,2)  
as  
Begin  
Declare @TargetId int      
Declare @LevelId int      
Select @TargetId = QcTargetId,@LevelId = QCLevelId from ADM_AccessTarget as ATar (nolock)     
Where CustomerId = @CustomerId and UserId = @FteId and ServiceId = @ServiceId  
if isnull(@LevelId,0) = 0      
 Select @LevelId = isnull(Min(QcLevelId),0) from ADM_QcTargetTran  (nolock)   where TargetId = @TargetId      
  
Declare @TargetPercent Decimal(10,2)   
if @LevelId = 0  
   Begin  
   Set @TargetPercent = -1  
   End  
Select @TargetPercent = TargetPercent from ADM_QcTargetTran  (nolock)  Where TargetId = @TargetId and QCLevelId = @LevelId  
Return @TargetPercent  
End  
  
GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_fnFteQcTarget] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_fnFteQcTarget] TO [DB_DMLSupport_WOD]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_fnFteQcTarget] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_fnFteQcTarget] TO [DB_Readonlysupport]
    AS [dbo];


GO
GRANT EXECUTE
    ON OBJECT::[dbo].[ADM_fnFteQcTarget] TO [DB_DMLSupport]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON OBJECT::[dbo].[ADM_fnFteQcTarget] TO [DB_DMLSupport]
    AS [dbo];

