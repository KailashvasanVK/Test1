﻿Create View Dbaevnt.Lock
as
select  resource_type,db_name(resource_database_id) DB_Nam, OBJECT_NAME(resource_associated_entity_id,resource_database_id) Tabl,
'kill '+CONVERT(varchar(10),request_session_id)killing,request_request_id,
request_mode,login_time,host_name,last_request_start_time,last_request_end_time,login_name,program_name
from sys.dm_tran_locks TL
inner join sys.dm_exec_sessions  ES on TL.request_session_id= Es.session_id
where Tl.resource_type='Object'
