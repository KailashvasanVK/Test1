﻿Create View Dbaevnt.tablecount1
as
select object_name(id)TName,rows  from sysindexes where id in (
select object_id from sys.tables /*where name not like '%koff%' */ )
and rows<>0 and indid =1 --order by rows desc
