﻿Create Proc Dbaevnt.scandensity_log
as
begin
insert into dbaevnt.fraglist_log
select *,getdate() from dbaevnt.fraglist

Truncate table dbaevnt.fraglist

declare @sql varchar(max)



set @sql='DBCC SHOWCONTIG WITH TABLERESULTS'

insert into dbaevnt.fraglist
exec(@sql)
end
