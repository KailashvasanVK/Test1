﻿Create proc Dbaevnt.badindex
as
SELECT  OBJECT_NAME(s.object_id) AS 'Table Name',
        i.name AS 'Index Name',
        i.index_id,
        user_updates AS 'Total Writes',
        user_seeks + user_scans + user_lookups AS 'Total Reads',
        user_updates - ( user_seeks + user_scans + user_lookups ) AS 'Difference'
FROM    sys.dm_db_index_usage_stats AS s WITH ( NOLOCK )
        INNER JOIN sys.indexes AS i WITH ( NOLOCK ) ON s.object_id = i.object_id
                                                       AND i.index_id = s.index_id
WHERE   OBJECTPROPERTY(s.object_id, 'IsUserTable') = 1
        AND s.database_id = DB_ID()
        AND user_updates > ( user_seeks + user_scans + user_lookups )
        AND i.index_id > 1 and OBJECT_NAME(s.object_id)='TRN_kOFF_tManualAllocation'
ORDER BY 'Difference' DESC,
        'Total Writes' DESC,
        'Total Reads' ASC ;



--TRN_kOFF_tBatches	IX_TRN_kOFF_tBatches_UploadDt_status_ServiceId
--TRN_kOFF_tBatches	IX_TRN_kOFF_tBatches_ServiceId_UploadDt_status_PgCount
--TRN_kOFF_tBatches	IND_TRN_kOFF_tBatches_StatusCreatedDt

--Drop index IX_TRN_kOFF_tManualAllocation_BatchProcessId on TRN_kOFF_tManualAllocation