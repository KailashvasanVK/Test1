﻿create Proc dbaevnt.BAD_index              
@databaseid int=0              
/*  BAD_index 8            
            
sp_helpdb            
        */              
as              
begin            
          
set @databaseid =(select DB_ID())            
    SELECT 'TableName' = object_name(s.object_id),i.type_desc, 'IndexName' =i.name, i.index_id,              
           'Total Writes' =  user_updates, 'Total Reads' = user_seeks + user_scans + user_lookups,              
            'Difference' = user_updates - (user_seeks + user_scans + user_lookups),  
            user_seeks , user_scans ,user_lookups,user_updates             
   into #temp  FROM sys.dm_db_index_usage_stats AS s              
    INNER JOIN sys.indexes AS i              
    ON s.object_id = i.object_id  and is_primary_key =0            
    AND i.index_id = s.index_id              
    WHERE objectproperty(s.object_id,'IsUserTable') = 1              
    AND s.database_id = @databaseid              
    AND user_updates > (user_seeks + user_scans + user_lookups)              
    ORDER BY 'Difference' DESC, 'Total Writes' DESC, 'Total Reads' ASC;              
                        
    select 'Drop Index '+IndexName + ' On ' +  TableName,user_seeks, user_scans , user_lookups,user_updates from #temp  where index_id<>0      
      and indexname not like 'PK_%' and indexname not like 'U%'  and user_seeks=0 and   user_lookups=0 and  user_scans=0  
            
       select 'Drop Index '+IndexName + ' On ' +  TableName,user_seeks , user_scans , user_lookups,user_updates from #temp  where index_id<>0      
      and indexname not like 'PK_%' --and indexname not like 'U%'       
             
    end