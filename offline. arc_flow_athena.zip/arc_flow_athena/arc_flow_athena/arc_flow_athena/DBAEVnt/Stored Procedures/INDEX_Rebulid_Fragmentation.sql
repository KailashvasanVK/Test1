﻿          
CREATE Proc [DBAEvnt].[INDEX_Rebulid_Fragmentation]                          
AS                          
Begin                         
                        
Set Nocount on;                         
                          
Declare @TC int,@indexName nvarchar(500),@TableName Nvarchar(100),@idint int,@index_id int                          
,@avg_fragmentation_in_percent numeric(18,2),@DBLog numeric(18,2),@qry nvarchar(500)                          
          
insert into DBAEvnt.IndexBuild(IndexName,TableName,avg_fragmentation_in_percent,Index_id)        
        
                  
SELECT name IndexName,OBJECT_NAME(a.object_id) TableName,avg_fragmentation_in_percent,b.index_id                         
FROM sys.dm_db_index_physical_stats (DB_ID(), NULL, NULL, NULL, NULL) AS a                          
JOIN sys.indexes AS b ON a.object_id = b.object_id AND a.index_id = b.index_id                           
where  name is not null and avg_fragmentation_in_percent>=5 and page_count >=1000                  
                    
                      
                          
Set @TC=(select COUNT(*) from DBAEvnt.IndexBuild where Status =0)                          
                          
                          
while @tc!=0                                  
begin                                  
                                  
select @index_id=index_id,@TableName =TableName,@indexName=IndexName,@avg_fragmentation_in_percent=avg_fragmentation_in_percent             
from DBAEvnt.IndexBuild where status=0       
                        
if @avg_fragmentation_in_percent>=30                        
begin                        
                          
insert into [DBAEvents].dbo.IndexRebulidDetails(DBNAME,TableName,IndexName,REBulidStart,BFIndexFra,BLogs)                          
select DB_NAME(),@TableName,@indexName,GETDATE(),@avg_fragmentation_in_percent,size from sys.database_files where type =1                          
                          
set @idint=SCOPE_IDENTITY()                          
                        
--if @index_id=1                        
--Begin                        
set @qry= 'ALTER INDEX '+@indexName+' ON '+@TableName+' rebuild ; '                              
 EXEC sp_executesql @qry                          
--End                         
--else                         
--Begin                        
--DBCC DBReindex(@TableName,@indexName,70)                          
--end                        
                         
                          
                          
SELECT @avg_fragmentation_in_percent=avg_fragmentation_in_percent                          
FROM sys.dm_db_index_physical_stats (DB_ID(), NULL, NULL, NULL, NULL) AS a                          
JOIN sys.indexes AS b ON a.object_id = b.object_id AND a.index_id = b.index_id                           
where  name=@indexName and OBJECT_NAME(a.object_id)=@TableName                          
                          
select @DBLog=size from sys.database_files where type =1                          
                          
                          
update [DBAEvents].dbo.IndexRebulidDetails set RebulidEnd=GETDATE(),AFIndexFra=@avg_fragmentation_in_percent,ALogs=@DBLog where  id=@idint                            
end                        
Else --if @avg_fragmentation_in_percent>5 and @avg_fragmentation_in_percent<30                        
begin                        
                        
insert into [DBAEvents].dbo.IndexRebulidDetails(DBNAME,TableName,IndexName,REBulidStart,BFIndexFra,BLogs)                          
select DB_NAME(),@TableName,@indexName,GETDATE(),@avg_fragmentation_in_percent,size from sys.database_files where type =1                          
                          
set @idint=SCOPE_IDENTITY()   
                          
set @qry= 'ALTER INDEX '+@indexName+' ON '+@TableName+' REORGANIZE ; '                         
 EXEC sp_executesql @qry                            
                          
      
SELECT @avg_fragmentation_in_percent=avg_fragmentation_in_percent                          
FROM sys.dm_db_index_physical_stats (DB_ID(), NULL, NULL, NULL, NULL) AS a                          
JOIN sys.indexes AS b ON a.object_id = b.object_id AND a.index_id = b.index_id                    
where  name=@indexName and OBJECT_NAME(a.object_id)=@TableName                          
                     
select @DBLog=size from sys.database_files where type =1                          
                          
                          
update [DBAEvents].dbo.IndexRebulidDetails set RebulidEnd=GETDATE(),AFIndexFra=@avg_fragmentation_in_percent,ALogs=@DBLog where  id=@idint                            
                        
                        
                        
                        
End                    
                                  
set @tc=@tc-1                                  
update  DBAEvnt.IndexBuild set status=1 where IndexName =@indexName  and status=0                                
end                         
                        
                        
Set Nocount OFF;                         
                                        
End 