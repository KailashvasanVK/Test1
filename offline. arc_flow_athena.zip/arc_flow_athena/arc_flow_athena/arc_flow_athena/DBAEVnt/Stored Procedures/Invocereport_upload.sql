﻿CREATE Proc DBaevnt.Invocereport_upload
as 
Begin
EXEC sp_configure 'show advanced options', 1                              
RECONFIGURE                              
EXEC sp_configure 'xp_cmdshell', 1                              
RECONFIGURE        


EXEC xp_cmdshell 'bcp "exec arc_flow_athena.DBaevnt.invoiceReport" queryout "E:\Invoicereport\InvoicePreort.csv" -c -t, -T'  
  
  
  
EXEC sp_configure 'show advanced options', 1                              
RECONFIGURE                              
EXEC sp_configure 'xp_cmdshell', 0                             
RECONFIGURE 

ENd