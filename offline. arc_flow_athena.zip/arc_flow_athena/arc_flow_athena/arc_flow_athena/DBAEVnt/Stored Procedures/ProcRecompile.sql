﻿Create procedure DBAEVnt.ProcRecompile  
as  
begin  
DECLARE @ProcName sysname  
DECLARE @SQLSTMT  varchar(2000)  
DECLARE ProcCursor CURSOR FOR  
select b.Name+'.'+a.name Name from sys.procedures  a
inner join sys.schemas b on a.Schema_id=b.schema_id  
OPEN ProcCursor  
FETCH NEXT FROM ProcCursor  
INTO @ProcName  
WHILE @@FETCH_STATUS = 0  
BEGIN  
SET @SQLSTMT = 'sp_recompile ' + '[' + @ProcName + ']'  
EXECUTE (@SQLSTMT)  
FETCH NEXT FROM ProcCursor INTO @ProcName  
END  
CLOSE ProcCursor  
DEALLOCATE ProcCursor  
end

