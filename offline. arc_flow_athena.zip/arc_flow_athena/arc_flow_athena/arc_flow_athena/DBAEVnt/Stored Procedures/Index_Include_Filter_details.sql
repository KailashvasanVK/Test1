﻿Create Proc dbaevnt.Index_Include_Filter_details  
as  
with Columnsqry as   
    (select name,ic.object_id,ic.index_id,is_included_column,ic.key_ordinal  
    from sys.index_columns IC,  
    sys.columns c  
    where ic.object_id=c.object_id and   
    ic.column_id = c.column_id ),   
    IndexQry as  
    (select I.object_id,I.index_id,   
        (select stuff((select ',' + name as [text()] from Columnsqry q  
            where q.object_id=I.object_id  
            and q.index_id=i.index_id and q.is_included_column=0  
            order by q.key_ordinal  
            for xml path('')),1,1,'')) Keys,  
        (select stuff((select ',' + name as [text()] from Columnsqry q  
            where q.object_id=I.object_id  
            and q.index_id=i.index_id and q.is_included_column=1  
            for xml path('')),1,1,'')) Included   
    from Columnsqry q, sys.indexes I,   
            sys.objects o  
    where q.object_id=I.object_id  
            and q.index_id=i.index_id   
            and o.object_id=I.object_id   
            and O.type not in ('S','IT')  
    group by I.object_id,I.index_id)  
select IQ.object_id,o.name as [table],  
        IQ.Index_id,I.name as [Index],  
        I.type_desc,  
        keys,included,  
        is_unique,fill_factor,is_padded,  
        has_filter,filter_definition  
from IndexQry IQ, Sys.objects o,sys.indexes I  
where IQ.object_id=o.object_id   
    and IQ.object_id=I.object_id   
    and IQ.Index_id=I.index_id