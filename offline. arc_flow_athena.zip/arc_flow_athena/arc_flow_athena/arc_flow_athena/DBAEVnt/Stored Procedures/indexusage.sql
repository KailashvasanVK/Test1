﻿Create proc Dbaevnt.indexusage
as
SELECT   OBJECT_NAME(S.[OBJECT_ID]) AS [OBJECT NAME], 
             I.[NAME] AS [INDEX NAME], 
             USER_SEEKS, 
             USER_SCANS, 
             USER_LOOKUPS, 
             USER_UPDATES,s.last_user_seek,last_system_scan 
    FROM     SYS.DM_DB_INDEX_USAGE_STATS AS S 
             INNER JOIN SYS.INDEXES AS I 
               ON I.[OBJECT_ID] = S.[OBJECT_ID] 
                  AND I.INDEX_ID = S.INDEX_ID 
    WHERE    OBJECTPROPERTY(S.[OBJECT_ID],'IsUserTable') = 1 
    and OBJECT_NAME(s.object_id)='TRN_kOFF_tManualAllocation'
    
    --select * from sys.dm_db_index_usage_stats s
    --WHERE    OBJECTPROPERTY(S.[OBJECT_ID],'IsUserTable') = 1 
    --and OBJECT_NAME(s.object_id)='TRN_kOFF_tBatches'
    