﻿CREATE Proc DBaevnt.invoiceReport  
AS  
begin  
Set nocount on;
SET fmtonly off;
Declare @From Date,@to Date  
  
if DATEPART(hour,getdate())<14  
begin  
Set @From =CONVERT(date,GETDATE()-1)  
Set @to =@From  
end  
else   
begin  
Set @From =CONVERT(date,GETDATE())  
Set @to =@From  
end  

if OBJECT_ID('temp1') is not null drop table temp1    



Create table temp1
(
SNo int,
Associate Varchar(40),
BatchNo varchar(40),
Service varchar(50),
Client varchar(200) ,
[Self Posting Entry] int,
[Collection Entry] int,
[Payment Entry] int,
[Patient Creation Entry] int,
[Exception Posting Entry] int,
[Entry Total] int,
[Self Posting Qc] int,
[Collection Qc] int,
[Payment Qc] int,
[Patient Creation Qc] int,
[Exception Posting Qc] int,
[Qc Total] int,
[ColHead] int
)
  
Declare @USerID int =(select UserId from ARC_REC_ATHENA..ARC_REC_USER_INFO where NT_USERNAME='sujatha.sukumar')  
insert into  temp1
exec TRN_pProductionReportBatchWise @BatchServiceId=0,@CmpKey='OFF',@fromDate=@From,  
@toDate=@From,@UserId=@USerID,@RptType='T',@LocationId=0  


Set nocount off;  
Set fmtonly on;
End  