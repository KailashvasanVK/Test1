﻿Create Proc Dbaevnt.checkbatchtran
@batchno varchar(40)=null
as
select TB.BatchNo, trn.TransValue EntyTran,trn.FactorTrans EntyFactor,m.TransValue QCtran,M.FactorTrans QCFactor from TRN_kOFF_tBatches TB
inner join TRN_kOFF_tBatchQueue BQ on BQ.BatchId=TB.BatchId
inner join TRN_kOFF_tBatchTransact TRN on Trn.BatchProcessId =bq.BatchProcessId
left join TRN_kOFF_tBatchQCMaster M on m.BatchProcessId =bq.BatchProcessId
where tb.BatchNo =@batchno

