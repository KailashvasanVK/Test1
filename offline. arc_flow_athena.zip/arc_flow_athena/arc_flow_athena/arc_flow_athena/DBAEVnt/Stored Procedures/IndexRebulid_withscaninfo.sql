﻿CREATE Proc Dbaevnt.IndexRebulid_withscaninfo
as
begin
Declare @Tc int,@objectname varchar(255)
select objectname,scandensity,countpages into #temp from dbaevnt.fraglist where scandensity<99
and countpages>1000
order by objectname

Set @tc=(select count(*) from #temp)

while @tc!=0
begin

select @objectname=ltrim(rtrim(objectname)) from #temp

select @objectname

Dbcc Dbreindex(@objectname,'',70)

update dbaevnt.fraglist set scandensity=100 where  objectname=@objectname

set @Tc=@Tc-1
delete #temp where objectname=@objectname
end     
drop table #temp   
end                                                                                                                                                                                                                                                                                                                                                                                                                             