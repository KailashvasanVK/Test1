﻿CREATE TABLE [DBAEVnt].[IndexBuild] (
    [Id]                           INT             IDENTITY (1, 1) NOT NULL,
    [IndexName]                    VARCHAR (300)   NULL,
    [TableName]                    VARCHAR (300)   NULL,
    [avg_fragmentation_in_percent] NUMERIC (18, 2) NULL,
    [Index_id]                     INT             NULL,
    [Status]                       TINYINT         DEFAULT ((0)) NULL,
    [currentdate]                  DATETIME        DEFAULT (getdate()) NULL
);

