﻿
CREATE TRIGGER [NON_DB_Owner_Drop_Procudure]          
ON DATABASE             
FOR DROP_PROCEDURE             
AS
IF ISNULL((SELECT IS_MEMBER('db_owner')), 0) < 1
BEGIN
   DECLARE @ObjectName NVARCHAR(256)
   -- Capture Table Name
   SELECT @ObjectName = EVENTDATA().value('(/EVENT_INSTANCE/ObjectName)[1]', 'varchar(256)')

   RAISERROR('Cannot Drop the Procedures ''%s'', because you do not have permission.', 14, 20, @ObjectName)
   ROLLBACK
END


