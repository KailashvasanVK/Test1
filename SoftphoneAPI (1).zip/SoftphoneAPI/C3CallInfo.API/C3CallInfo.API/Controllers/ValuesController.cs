﻿using C3CallInfo.API.Models;
using C3CallInfo.Business;
using C3CallInfo.Model;
using Newtonsoft.Json;
using System;
using System.Web.Http;

namespace C3CallInfo.API.Controllers
{
    public class ValuesController : ApiController
    {
        [Route("api/Values/PostRCData")]
        public IHttpActionResult PostRCData(CallInfoModel data)
        {
            string returnMessage = string.Empty;

            try
            {
                CallRecordInformationFlow callRecordInformationFlow = new CallRecordInformationFlow();
                if(data!=null)
                {
                    data.IsInsert = 0;
                }
                string result = callRecordInformationFlow.InsertOrUpdateCallInfo(data);

                if(data != null && !string.IsNullOrEmpty(GlobalConfig.IsDataLog) && GlobalConfig.IsDataLog == "true")
                {
                    string output = JsonConvert.SerializeObject(data);
                    new ErrorLogger().Log(data?.Uniqueid, data?.SourceAdded, data?.FromName, "Insert Data", DateTime.Now, output);
                }

                if (result == "Bad Request")
                {
                    return BadRequest("Invalid parameters");
                }
                returnMessage = result;
            }
            catch (Exception e)
            {
                new ErrorLogger().Log(data?.Uniqueid, data?.SourceAdded, data?.FromName, e.ToString(), DateTime.Now, e.Message);
                returnMessage = e.ToString();
            }

            return Ok(returnMessage);
        }

        [Route("api/Values/UpdateRCData")]
        public IHttpActionResult UpdateRCData(CallInfoModel data)
        {
            string returnMessage = string.Empty;

            try
            {
                CallRecordInformationFlow callRecordInformationFlow = new CallRecordInformationFlow();
                if (data != null)
                {
                    data.IsInsert = 1;
                }
                string result = callRecordInformationFlow.InsertOrUpdateCallInfo(data);


                if (data != null && !string.IsNullOrEmpty(GlobalConfig.IsDataLog) && GlobalConfig.IsDataLog == "true")
                {
                    string output = JsonConvert.SerializeObject(data);
                    new ErrorLogger().Log(data?.Uniqueid, data?.SourceAdded, data?.FromName, "Update Data", DateTime.Now, output);
                }

                if (result == "Bad Request")
                {
                    return BadRequest("Invalid Parameters");
                }

                returnMessage = result;
            }
            catch (Exception ex)
            {
                new ErrorLogger().Log(data?.Uniqueid, data?.SourceAdded, data?.FromName, ex.ToString(), DateTime.Now, ex.Message);
                returnMessage = ex.ToString();
            }

            return Ok(returnMessage);
        }
    }
}
