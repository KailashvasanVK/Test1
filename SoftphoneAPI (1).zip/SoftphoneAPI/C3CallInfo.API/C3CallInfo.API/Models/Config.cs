﻿using System.Configuration;

namespace C3CallInfo.API.Models
{
    public class Config
    {
        public static string CorsURL
        {
            get
            {
                return ConfigurationManager.AppSettings["CORS"];
            }
        }

        public static string IsDataLog
        {
            get
            {
                return ConfigurationManager.AppSettings["IsDataLog"];
            }
        }

        public static string EventHubName
        {
            get
            {
                return ConfigurationManager.AppSettings["EventHubName"];
            }
        }

        public static string EventConnectionString
        {
            get
            {
                return ConfigurationManager.AppSettings["EventConnectionString"];
            }
        }

        public static string IsEventHubCall
        {
            get
            {
                return ConfigurationManager.AppSettings["IsEventHubCall"];
            }
        }
    }
}