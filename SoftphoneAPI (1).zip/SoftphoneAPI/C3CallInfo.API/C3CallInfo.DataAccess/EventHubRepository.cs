﻿using C3CallInfo.Model;
using Microsoft.ServiceBus.Messaging;
using Newtonsoft.Json;
using System;
using System.Text;
using System.Threading.Tasks;

namespace C3CallInfo.DataAccess
{
    public class EventHubRepository
    {
        static string callrecordingHubName = GlobalConfig.EventHubName;
        static string callrecordingConnectionString = GlobalConfig.EventConnectionString;
        static EventHubClient callEventHubClient = EventHubClient.CreateFromConnectionString(callrecordingConnectionString, callrecordingHubName);
        public async Task SendEventAsync(CallEventModel callEvent)
        {
            try
            {
                await callEventHubClient.SendAsync(new EventData(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(callEvent))));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
