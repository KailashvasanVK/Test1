﻿using C3CallInfo.Model;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace C3CallInfo.DataAccess
{
    public class CallRecordInformation
    {
        public DataTable SaveCallInformation(CallInfoModel callInfo, DataTable data)
        {
            #region Variable declaration
            DataTable result = new DataTable();
            SqlParameter CallInfo, Uniqueid, IsInsert, Result;
            string connstring = ConfigurationManager.ConnectionStrings["CallRecordDB"].ToString();
            #endregion

            #region Parameter Initialization
            Uniqueid = new SqlParameter("@Uniqueid", SqlDbType.VarChar);
            CallInfo = new SqlParameter("@Data", SqlDbType.Structured);
            IsInsert = new SqlParameter("@IsInsert", SqlDbType.TinyInt);
            Result = new SqlParameter("@Result", SqlDbType.VarChar);
            #endregion

            #region Parameters Assignment
            CallInfo.Value = data;
            Uniqueid.Value = callInfo.Uniqueid;
            IsInsert.Value = callInfo.IsInsert;
            Result.Value = callInfo.Result;
            #endregion

            using (SqlConnection connection = new SqlConnection(connstring))
            {
                using (SqlCommand command = new SqlCommand("C3_VoiceCallApiInfo", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add(CallInfo);
                    command.Parameters.Add(Uniqueid);
                    command.Parameters.Add(IsInsert);
                    command.Parameters.Add(Result);

                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();

                        using (SqlDataAdapter adap = new SqlDataAdapter(command))
                        {
                            adap.Fill(result);
                        }
                    }
                    catch (Exception ex)
                    {
                        new ErrorLoggerRepository().Log(callInfo?.Uniqueid, callInfo?.SourceAdded, callInfo?.FromName, ex.ToString(), DateTime.Now, ex.Message);
                        //result = ex.ToString();
                    }
                    finally
                    {
                        if (connection != null)
                        {
                            connection.Close();
                        }
                    }
                }                
            }
            //try
            //{
            //    conn.Open();
            //    result = comm.ExecuteScalar() as string;
            //}
            //catch (Exception ex)
            //{
            //    new ErrorLoggerRepository().Log(callInfo?.Uniqueid, callInfo?.SourceAdded, callInfo?.FromName, ex.ToString(), DateTime.Now, ex.Message);
            //    result = ex.ToString();
            //}
            //finally
            //{
            //    conn.Close();
            //}

            return result;
        }
    }
}
