﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace C3CallInfo.DataAccess
{
    public class ErrorLoggerRepository
    {
        public string Log(string uniqueId, string sourceAdded, string username, string errorAt, DateTime errorOn, string errorMessage)
        {
            #region Variable declaration
            string result = string.Empty;
            SqlConnection conn;
            SqlCommand comm;
            SqlParameter ErrorAt, ErrorOn, ErrorMessage,
                 NtUserName, SourceAdded, Uniqueid;
            string connstring = ConfigurationManager.ConnectionStrings["CallRecordDB"].ToString();
            conn = new SqlConnection(connstring);

            comm = new SqlCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "C3_VoiceCallApiErrrorInfo"
            };
            #endregion

            #region Parameter Initialization
            ErrorAt = new SqlParameter("@ErrorAt", SqlDbType.VarChar);
            ErrorOn = new SqlParameter("@ErrorOn", SqlDbType.DateTime);
            ErrorMessage = new SqlParameter("@ErrorMessage", SqlDbType.VarChar);
            SourceAdded = new SqlParameter("@SourceAdded", SqlDbType.VarChar);
            Uniqueid = new SqlParameter("@Uniqueid", SqlDbType.VarChar);
            NtUserName = new SqlParameter("@NtUserName", SqlDbType.VarChar);
            #endregion

            #region Parameters Add
            comm.Parameters.Add(ErrorAt);
            comm.Parameters.Add(ErrorOn);
            comm.Parameters.Add(ErrorMessage);
            comm.Parameters.Add(SourceAdded);
            comm.Parameters.Add(Uniqueid);
            comm.Parameters.Add(NtUserName);
            #endregion

            #region Parameters Assignment
            SourceAdded.Value = sourceAdded;
            Uniqueid.Value = uniqueId;
            ErrorAt.Value = errorAt;
            ErrorOn.Value = errorOn;
            ErrorMessage.Value = errorMessage;
            NtUserName.Value = username;
            #endregion

            try
            {
                conn.Open();
                result = comm.ExecuteScalar() as string;
            }
            catch (Exception ex)
            {
                result = ex.ToString();
            }
            finally
            {
                conn.Close();
            }

            return result;
        }
    }
}
