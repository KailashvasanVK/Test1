﻿using C3CallInfo.DataAccess;
using C3CallInfo.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;

namespace C3CallInfo.Business
{
    public class CallRecordInformationFlow
    {
        private CallRecordInformation _callRecordInformation;
        //private EventHubCaller _eventHubCaller;
        public CallRecordInformationFlow()
        {
            _callRecordInformation = new CallRecordInformation();
            //_eventHubCaller = new EventHubCaller();
        }

        public string InsertOrUpdateCallInfo(CallInfoModel callInfo)
        {
            string result = string.Empty;

            if(callInfo != null && !string.IsNullOrEmpty(callInfo.Uniqueid))
            {
                if (!string.IsNullOrEmpty(callInfo.CallInitiatedTimeISO))
                {

                    if (DateTime.TryParse(callInfo.CallInitiatedTimeISO, null, System.Globalization.DateTimeStyles.RoundtripKind, out DateTime formatTime))
                    {
                        callInfo.CallInitiatedTime = formatTime;
                    }
                }

                if(callInfo.IsInsert == 1)
                {
                    if (callInfo.UserSystemDateTime != null)
                    {
                        if (!(callInfo.UserSystemDateTime <= DateTime.UtcNow && (callInfo.CallInitiatedTime == null || callInfo.CallInitiatedTime <= callInfo.UserSystemDateTime) && callInfo.UserSystemDateTime > DateTime.UtcNow.AddHours(-9)))
                        {
                            if(GlobalConfig.IsDataLog == "true")
                            {
                                string output = JsonConvert.SerializeObject(callInfo);
                                new ErrorLogger().Log(callInfo?.Uniqueid, callInfo?.SourceAdded, callInfo?.FromName, "Invalid UserSystemDateTime", DateTime.Now, output);
                            }
                            
                            callInfo.UserSystemDateTime = DateTime.UtcNow;
                        }
                    }
                    else
                    {
                        if (GlobalConfig.IsDataLog == "true")
                        {
                            string output = JsonConvert.SerializeObject(callInfo);
                            new ErrorLogger().Log(callInfo?.Uniqueid, callInfo?.SourceAdded, callInfo?.FromName, "Null UserSystemDateTime", DateTime.Now, output);
                        }
                        callInfo.UserSystemDateTime = DateTime.UtcNow;
                    }
                }                

                callInfo.PageURL = (!string.IsNullOrEmpty(callInfo.PageURL) && callInfo.PageURL.Length > 250) ? callInfo.PageURL.Substring(0, 250) : callInfo.PageURL;

                //Save logic
                List<CallInfoModel> callInfos = new List<CallInfoModel>()
                {
                    callInfo
                };

                DataTable data = new Utilities().ConvertToDataTable(callInfos, "CallInitiatedTimeISO", "IsInsert", "Result");
                DataTable table = _callRecordInformation.SaveCallInformation(callInfo, data);

                


                if (GlobalConfig.IsEventHubCall && callInfo.CallInitiatedTime != null && !string.IsNullOrEmpty(callInfo.FromName))
                {
                    try
                    {
                        DateTime? eventDate = null;
                        string endDate = null;
                        
                        if (callInfo.IsInsert == 0)
                        {
                            eventDate = callInfo.CallInitiatedTime;
                            eventDate = eventDate.Value.AddMinutes(330);
                        }
                        else if(callInfo.IsInsert == 1)
                        {
                            if (table != null && table.Rows.Count > 0)
                            {
                                try
                                {
                                    endDate = table.Rows[0]["CallEndTime"].ToString();
                                }
                                catch (Exception)
                                {
                                }
                            }
                            if (endDate != null && DateTime.TryParse(endDate, out DateTime eventDateFromDB))
                            {
                                eventDate = eventDateFromDB;
                            }
                            else
                            {
                                eventDate = DateTime.Now;
                            }
                        }
                        else
                        {
                            eventDate = DateTime.Now;
                        }

                        CallEventModel callEvent = new CallEventModel()
                        {
                            ntusername = callInfo?.FromName?.Replace(' ', '.'),
                            UniqueID = callInfo.Uniqueid,
                            EventDate = eventDate,
                            EventType = callInfo.IsInsert == 0 ? "Start" : "Stop"
                        };

                        var eventHubCaller = new EventHubCaller();
                        eventHubCaller.CallEventHub(callEvent);
                    }
                    catch (Exception ex)
                    {
                        if(GlobalConfig.IsEventHubErrorLogging)
                        {
                            new ErrorLogger().Log(callInfo?.Uniqueid, callInfo?.SourceAdded, callInfo?.FromName, ex.ToString(), DateTime.Now, ex.Message);
                        }
                    }
                }                
            }
            else
            {
                result = "Bad Request";
            }

            return result;
        }
    }
}
