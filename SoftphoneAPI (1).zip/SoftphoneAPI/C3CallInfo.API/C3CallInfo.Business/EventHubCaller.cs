﻿using C3CallInfo.DataAccess;
using C3CallInfo.Model;

namespace C3CallInfo.Business
{
    public class EventHubCaller
    {
        private EventHubRepository _eventHubRepository;
        public EventHubCaller()
        {
            _eventHubRepository = new EventHubRepository();
        }

        public void CallEventHub(CallEventModel callEvent)
        {
            if (callEvent != null)
            {
                var _request = _eventHubRepository.SendEventAsync(callEvent);
                //if(GlobalConfig.EventHubTimeoutInSeconds>0)
                //{
                //    _request.Wait(GlobalConfig.EventHubTimeoutInSeconds);
                //}
                //else
                //{
                //    _request.Wait();
                //}
            }
        }
    }
}
