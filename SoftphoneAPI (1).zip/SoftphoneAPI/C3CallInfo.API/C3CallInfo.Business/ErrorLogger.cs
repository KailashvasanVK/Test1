﻿using C3CallInfo.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C3CallInfo.Business
{
    public class ErrorLogger
    {
        private ErrorLoggerRepository _errorLoggerRepository;
        public ErrorLogger()
        {
            _errorLoggerRepository = new ErrorLoggerRepository();
        }

        public void Log(string uniqueId, string sourceAdded, string username, string errorAt, DateTime errorOn, string errorMessage)
        {
            var result = _errorLoggerRepository.Log(uniqueId, sourceAdded, username, errorAt, errorOn, errorMessage);
        }
    }
}
