﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace C3CallInfo.Business
{
    public class Utilities
    {
        public DataTable ConvertToDataTable<T>(List<T> list, params string[] excludeColumns)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            PropertyInfo[] Props = null;

            if(excludeColumns!=null && excludeColumns.Length > 0)
            {
                Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance).Where(x => !excludeColumns.Contains(x.Name)).ToArray();
            }
            else
            {
                Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            }
            
            foreach (PropertyInfo prop in Props)
            {
                dataTable.Columns.Add(prop.Name);
            }

            foreach (T item in list)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }
            return dataTable;
        }
    }
}
