﻿using System;
using System.Configuration;

namespace C3CallInfo.Model
{
    public class GlobalConfig
    {
        public static string CorsURL
        {
            get
            {
                return ConfigurationManager.AppSettings["CORS"];
            }
        }

        public static string IsDataLog
        {
            get
            {
                return ConfigurationManager.AppSettings["IsDataLog"];
            }
        }

        public static string EventHubName
        {
            get
            {
                return ConfigurationManager.AppSettings["EventHubName"];
            }
        }

        public static string EventConnectionString
        {
            get
            {
                return ConfigurationManager.AppSettings["EventConnectionString"];
            }
        }

        public static bool IsEventHubCall
        {
            get
            {
                return ConfigurationManager.AppSettings["IsEventHubCall"] == "true";
            }
        }

        public static bool IsEventHubErrorLogging
        {
            get
            {
                return ConfigurationManager.AppSettings["IsEventHubErrorLogging"] == "true";
            }
        }

        public static int EventHubTimeoutInSeconds
        {
            get
            {
                if(!string.IsNullOrEmpty(ConfigurationManager.AppSettings["EventHubTimeoutInSeconds"]) && int.TryParse(ConfigurationManager.AppSettings["EventHubTimeoutInSeconds"], out int result))
                {
                    result = result * 1000;
                }
                else
                {
                    result = 0;
                }

                return result;
            }
        }
    }
}
