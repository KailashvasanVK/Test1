﻿using System;

namespace C3CallInfo.Model
{
    public class CallInfoModel
    {
        public string ClaimNo { get; set; }
        public string ToPhoneNumber { get; set; } //PhoneNumber
        public DateTime? CallInitiatedTime { get; set; }
        public string CallInitiatedTimeISO { get; set; }
        public DateTime? CallEndTime { get; set; }
        public string RecordingURL { get; set; }
        public string FromName { get; set; } //CreatedBy
        public string SourceAdded { get; set; }
        public string Uniqueid { get; set; }
        public string CallDisposition { get; set; }
        public string ToLocation { get; set; } //Location
        public string ToName { get; set; } //New
        public int Duration { get; set; }
        public string Direction { get; set; }
        public string RecordingID { get; set; }
        public byte IsInsert { get; set; }
        //public string FromName { get; set; }
        public string FromExtn { get; set; } //New
        public string PageURL { get; set; } //New
        public string Reason { get; set; } //New
        public string ReasonDescription { get; set; } //New
        public int? EndCallEventFlag { get; set; }
        public DateTime? UserSystemDateTime { get; set; }
        public string Result { get; set; }
        //public DateTime UserSystemDateTimeISO { get; set; }
    }
}
