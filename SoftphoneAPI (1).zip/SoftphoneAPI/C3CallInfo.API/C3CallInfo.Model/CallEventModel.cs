﻿using System;

namespace C3CallInfo.Model
{
    public class CallEventModel
    {
        public string ntusername { get; set; }
        public string UniqueID { get; set; }
        public DateTime? EventDate { get; set; }
        public string EventType { get; set; }
    }
}
