import { Component, OnInit } from '@angular/core';
import{ Router} from '@angular/router';
import { FormControl } from '@angular/forms';


export interface Food {
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-process-management',
  templateUrl: './process-management.component.html',
  styleUrls: ['./process-management.component.css']
})
export class ProcessManagementComponent implements OnInit {
  infoTab = true;
  constructor(private router:Router) { }
  myControl = new FormControl();
  Teamoptions: string[] = ['Athena', 'Brightree', 'Non-Athena', 'Operation - Micro Clustering', 'Shared Services'];
  Processoptions: string[] = ['-Choose-'];
  ngOnInit() {

    
  }
  
  foods: Food[] = [
    {value: 'steak-0', viewValue: 'Steak'},
    {value: 'pizza-1', viewValue: 'Pizza'},
    {value: 'tacos-2', viewValue: 'Tacos'}
  ];

}

