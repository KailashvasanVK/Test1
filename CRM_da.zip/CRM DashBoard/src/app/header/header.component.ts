import { Component, OnInit, ViewEncapsulation, ViewChild, Inject } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
// import { DialogExistingUserComponent } from '../dialog-existing-user/dialog-existing-user.component';
export interface UserData {
  id: string;
  name: string;
  progress: string;
}

export interface DialogData {
  animal: string;
  name: string;
}
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
  // encapsulation: ViewEncapsulation.None
  
})

export class HeaderComponent implements OnInit {
  todaydate: any;
  UserFullName: any;
  step = 0;
  Filename: any;

  hide=false;
  hideupload = true;
  grdSection = true;
  grdSearch = true;
  infoTab = true;
f= '../../assets/CRMIntegration_Template.xlsx';

  displayedColumns: string[] = ['id', 'name', 'progress', 'action'];
  dataSource: MatTableDataSource<UserData>;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  myControl = new FormControl();
  Roleoptions: string[] = ['Admin', 'Supervisor', 'Client Partner'];
  Processoptions: string[] = ['-Choose-'];
  Teamoptions: string[] = ['Athena', 'Brightree', 'Non-Athena', 'Operation - Micro Clustering', 'Shared Services'];

  setStep(index: number) {
    this.step = index;
  }

  nextStep() {
    this.step++;
  }

  dashboardClick() {
    this.hide =true;
  }
  prevStep() {
    this.step--;
  }
  animal: string;
  name: string;
  // constructor() {// Create 100 users
  //   const users = Array.from({length: 100}, (_, k) => createNewUser(k + 1));

  //   // Assign the data to the data source for the table to render
  //   this.dataSource = new MatTableDataSource(users); }

  constructor(public dialog: MatDialog,private router: Router) { }

  onShow(): void {
    const dialogRef = this.dialog.open(DialogExistingUserComponent, {
      width: '1250px',
      data: { name: this.name, animal: this.animal }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      this.animal = result;
    });

   
  }

  ngOnInit() {
    const users = Array.from({ length: 100 }, (_, k) => createNewUser(k + 1));
    this.dataSource = new MatTableDataSource(users);
    this.UserFullName = "Lokesh C";
    setInterval(() => {
      this.todaydate = new Date();
    }, 1);

    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  uploadedFile(event) {
    debugger;
    this.Filename = event.target.files[0].name;
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  btnSearchClick() {
    this.grdSection = false;
    this.grdSearch = false;
  }
  btnClearClick() {
    this.grdSection = true;
    this.grdSearch = true;
  }
  getImage(ev) {
    console.log(1);
 }
 Redirect(){
   debugger;
  this.router.navigate(['/dashboard']);
 }
  // onShow() {
  //   console.log("ABC");
  //   this.infoTab = false;
  // }
}

const NAMES: string[] = [
  'Maia', 'Asher', 'Olivia', 'Atticus', 'Amelia', 'Jack', 'Charlotte', 'Theodore', 'Isla', 'Oliver',
  'Isabella', 'Jasper', 'Cora', 'Levi', 'Violet', 'Arthur', 'Mia', 'Thomas', 'Elizabeth'
];
function createNewUser(id: number): UserData {
  const name = NAMES[Math.round(Math.random() * (NAMES.length - 1))] + ' ' +
    NAMES[Math.round(Math.random() * (NAMES.length - 1))].charAt(0) + '.';

  return {
    id: id.toString(),
    name: name,
    progress: Math.round(Math.random() * 100).toString()
  };
}



@Component({
  selector: 'app-dialog-existing-user',
  templateUrl: './dialog-existing-user.component.html',
})
export class DialogExistingUserComponent {
  step = 0;
  infoTab = true;
  constructor(
    public dialogRef: MatDialogRef<DialogExistingUserComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) { }

    myControl = new FormControl();
    Roleoptions: string[] = ['Admin', 'Supervisor', 'Client Partner'];
    Processoptions: string[] = ['-Choose-'];
    Teamoptions: string[] = ['Athena', 'Brightree', 'Non-Athena', 'Operation - Micro Clustering', 'Shared Services'];

  onNoClick(): void {
    debugger;
    this.dialogRef.close();
  }

  setStep(index: number) {
    this.step = index;
  }

  nextStep() {
    this.step++;
  }

  prevStep() {
    this.step--;
  }
  submit(){ 
    debugger;
    this.dialogRef.close();
  }

}
