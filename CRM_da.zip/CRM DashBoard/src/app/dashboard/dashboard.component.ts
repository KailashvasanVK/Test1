import { Component, OnInit, ViewEncapsulation, HostListener } from '@angular/core';
import { DataSource } from '@angular/cdk/table';
import { DecimalPipe } from '@angular/common';
import { Router } from '@angular/router';
import { AppserviceService } from '../appservice.service';
import { DeploymentStatsModel } from '../Model/dashboard-model';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']

})

export class DashboardComponent implements OnInit {
  chartfreq = true;
  constructor(private router: Router, private _appSer: AppserviceService) {
    this.getTeamWiseStats();
    //this.TeamWiseStatsToValues();
  }
  products: any[];
  values: any[];
  dataSource: any;
  dataSource1: DeploymentStatsModel[]
  DailerWiseInfo: any;
  DailerWiseSources: any;
  teams: any;
  highAverage = 100;
  lowAverage = 50;
  cache = []
  pipe: any = new DecimalPipe("en-US");
  teamleadname: any;
  teamname:any;
  ProcessID: any;
  datanew: any;
  fchartwith = 600;
  TWchartwidth = 750;
  TWchartheight = 400;
  diameter = '0.70';
  innerRadius = '0.75';
  dashboardfont = '';
  TWcharttop = 50;
  TWbottom = 50;
  rotationAngle=-25;
  dialers: Iterable<string>;
  TeamwiseData: any;
  teamleaders: any;
  teamleadersdata: any;
  DialerTeamwiseData: any;
  DialerTeamwiseDatanew: Iterable<string>;
  processname: any;
  dialerwiseusage: any;
  innerWidth: any;
  getcolor = ['#f5564a', '#003366'];
  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.innerWidth = window.innerWidth;
  }
  ngOnInit() {
    this.innerWidth = window.innerWidth;

    if (this.innerWidth >= 2560) {
      this.rotationAngle=-25;
      this.fchartwith = 800;
      this.TWchartwidth = 700;
      this.TWchartheight = 550;
      this.TWcharttop = 0;
      this.TWbottom = 100;
    } else if (this.innerWidth >= 1366 && this.innerWidth < 1440) {
      this.rotationAngle=-25;
      this.fchartwith = 550;
      this.TWchartwidth = 550;
      this.TWchartheight = 300;
      this.TWcharttop = 50;
      this.TWbottom = 50;
    }
    else if (this.innerWidth > 1024 && this.innerWidth < 1366) {
      this.rotationAngle=-25;
      this.fchartwith = 500;
      this.TWchartwidth = 550;
      this.TWchartheight = 300;
      this.TWcharttop = 50;
      this.TWbottom = 50;
    }
    else if (this.innerWidth <= 1024) {
      this.rotationAngle=-25;
      this.fchartwith = 400;
      this.TWchartwidth = 550;
      this.TWchartheight = 300;
      this.TWcharttop = 50;
      this.TWbottom = 50;
    }
    else if (this.innerWidth >= 1440 && this.innerWidth < 2560) {
      this.rotationAngle=-25;
      this.fchartwith = 550;
      this.TWchartwidth = 550;
      this.TWchartheight = 300;
      this.TWcharttop = 50;
      this.TWbottom = 40;
    }
    else {
      this.rotationAngle=-25;
      this.fchartwith = 575;
      this.TWchartwidth = 600;
      this.TWchartheight = 350;
      this.TWcharttop = 25;
      this.TWbottom = 10;
    }

    this.getDeploymentstate();
    this.getTeamWiseStats();
    this.getdialerwiseusage();
    this.getprocessnameData();


    this.teams = [{ name: "", value: "" }, { name: "", value: "" }]
    let DailerWiseSources: any = [
      { value: "TATA", name: "TATA" },
      { value: "KruptoConnect", name: "KruptoConnect" }
    ];
    this.dataSource;
    this.DailerWiseSources = DailerWiseSources;
  }

  


  getprocessid(value: any) {
    this.ProcessID = value.value.ProcessID;
    this.teamleadname = null;
    //this.teamname=null;
    this.chartfreq = true;
    this._appSer.get('Dashboard/GetTeamwiseDialerStats').subscribe(res => {
      this.teamleaders = [];
      this.teamleadersdata = res;
      var d = this.teamleadersdata.filter(res => (res.ProcessID == this.ProcessID));
      var dd = [];
      for (var i = 0; i < d.length; i++) {
        dd.push(d[i].Leadname);

      }
      this.teamleaders = dd;

    });


  }

  getDeploymentstate() {
    this._appSer.get('Dashboard/GetDeploymentStats').subscribe(res => {
      debugger;
      this.datanew = res;
      if (this.innerWidth >= 1366 && this.innerWidth <= 1440) {
        if (this.datanew.length > 2) {
          this.diameter = '0.55';
        this.innerRadius = '0.87';
       // this.dashboardfont = "font-size: 8px !important";
        }
        else if (this.datanew.length > 4) {
          this.diameter = '0.30';
          this.innerRadius = '0.35';
        }
        else {
          this.diameter = '0.70';
          this.innerRadius = '0.75';
         // this.dashboardfont = "font-size: 18px";
        }
      }
     else if (this.innerWidth >= 1024 && this.innerWidth < 1366) {
        if (this.datanew.length > 2) {
          this.diameter = '0.50';
          this.innerRadius = '0.90';
        //  this.dashboardfont = "font-size: 1px !important";
        }
        else if (this.datanew.length > 4) {
          this.diameter = '0.30';
          this.innerRadius = '0.35';
        }
        else {
          this.diameter = '0.70';
          this.innerRadius = '0.75';
         // this.dashboardfont = "font-size: 18px";
        }
      }
      
      else if (this.datanew.length > 2) {
        this.diameter = '0.60';
        this.innerRadius = '0.75';
       // this.dashboardfont = "font-size: 18px";
      }
      else if (this.datanew.length > 4) {
        this.diameter = '0.30';
        this.innerRadius = '0.35';
      }
      else {
        this.diameter = '0.70';
        this.innerRadius = '0.75';
        //this.dashboardfont = "font-size: 18px";
      }
      this.dialers = this.datanew.map(t => t.DialerName);
      this.getData(this.dialers);


    });
  }

  getTeamWiseStats() {
    this._appSer.get('Dashboard/GetTeamwiseStats').subscribe(res => {
      this.TeamwiseData = res;
      var dd = [];
      for (var i = 0; i < this.TeamwiseData.length; i++) {
        dd.push({ 'ProcessID': this.TeamwiseData[i].ProcessID, 'name': this.TeamwiseData[i].Teamname, 'UsedCount': this.TeamwiseData[i].UsedCount, 'UnusedCount': this.TeamwiseData[i].UnusedCount, 'count': this.TeamwiseData[i].TotalCount, 'active': true });       
      }
      // dd.push({ 'ProcessID': 11, 'name': "Application New51", 'UsedCount': 51, 'UnusedCount': 51, 'count': 51, 'active': true });
      // dd.push({ 'ProcessID': 12, 'name': "Application New52", 'UsedCount': 52, 'UnusedCount': 52, 'count': 52, 'active': true });
      // dd.push({ 'ProcessID': 13, 'name': "Application New53", 'UsedCount': 53, 'UnusedCount': 53, 'count': 153, 'active': true });
      // dd.push({ 'ProcessID': 14, 'name': "Application New54", 'UsedCount': 54, 'UnusedCount': 54, 'count': 54, 'active': true });
      // dd.push({ 'ProcessID': 15, 'name': "Application New55", 'UsedCount': 55, 'UnusedCount': 55, 'count': 180, 'active': true });
      // dd.push({ 'ProcessID': 16, 'name': "Application New56", 'UsedCount': 56, 'UnusedCount': 56, 'count': 56, 'active': true });
      // dd.push({ 'ProcessID': 17, 'name': "Application New57", 'UsedCount': 57, 'UnusedCount': 57, 'count': 24, 'active': true });
      // dd.push({ 'ProcessID': 18, 'name': "Application New58", 'UsedCount': 58, 'UnusedCount': 58, 'count': 58, 'active': true });
      // dd.push({ 'ProcessID': 19, 'name': "Application New59", 'UsedCount': 59, 'UnusedCount': 59, 'count': 177, 'active': true });
      //dd.push({ 'ProcessID': 20, 'name': "Shared Services – Application New60", 'UsedCount': 60, 'UnusedCount': 60, 'count': 85, 'active': true });
      // dd.push({ 'ProcessID': 21, 'name': "Shared Services – Application New61", 'UsedCount': 61, 'UnusedCount': 61, 'count': 61, 'active': true });
      // dd.push({ 'ProcessID': 22, 'name': "Shared Services – Application New62", 'UsedCount': 62, 'UnusedCount': 62, 'count': 62, 'active': true });
      // dd.push({ 'ProcessID': 23, 'name': "Shared Services – Application New63", 'UsedCount': 63, 'UnusedCount': 63, 'count': 63, 'active': true });
      // dd.push({ 'ProcessID': 24, 'name': "Shared Services – Application New64", 'UsedCount': 64, 'UnusedCount': 64, 'count': 64, 'active': true });
      // for (var i = 0; i < this.TeamwiseData.length; i++) {
      //   dd.push({ 'ProcessID': this.TeamwiseData[i].ProcessID, 'name': this.TeamwiseData[i].Teamname, 'UsedCount': this.TeamwiseData[i].UsedCount, 'UnusedCount': this.TeamwiseData[i].UnusedCount, 'count': this.TeamwiseData[i].TotalCount, 'active': true });
      // }
      // for (var i = 0; i < this.TeamwiseData.length; i++) {
      //   dd.push({ 'ProcessID': this.TeamwiseData[i].ProcessID, 'name': this.TeamwiseData[i].Teamname, 'UsedCount': this.TeamwiseData[i].UsedCount, 'UnusedCount': this.TeamwiseData[i].UnusedCount, 'count': this.TeamwiseData[i].TotalCount, 'active': true });
      // }
      //this.TeamwiseData = dd;
      //debugger;
      this.values = dd;
      //this.TeamWiseStatsToValues();
    });
  }
  customizePoint = (arg: any) => {
    debugger;
        // var color, hoverStyle;
        // switch (arg.data.count >= 100 ? 1 : 0) {
        //     case 1:
        //         color = "#f5564a";
        //         hoverStyle = { border: { color: "#f5564a" } };
        //         break;
        //     case 0 :
        //         color = "#15426c";
        //         hoverStyle = { border: { color: "#15426c" } };
        // }
        // return { color, hoverStyle };
    
        if(arg.value > this.highAverage) {
          return { color: "#f5564a", hoverStyle: { color: "#f5564a" } };
      } else if(arg.value < this.lowAverage) {          
          return { color: "#696969", hoverStyle: { color: "#696969" } };
      }
      else if(arg.value > this.lowAverage && arg.value < this.highAverage) {          
        return { color: "#15426c", hoverStyle: { color: "#15426c" } };
    }
    }
    customizeLabelchart = (arg: any) => {
      //if (arg.value > this.highAverage) {
          return {
              visible: true,
              backgroundColor: "#ff7c7c",
              customizeText: function (e: any) {
                  return e.valueText ;
              }
          };
      //}
    }



  TeamWiseStatsToValues() {
    let values = [];

    this.products.forEach(function (product) {
      if (product.active) {
        values.push(product.count);
      }
    })

    this.values = values;
  }



  getdialerwiseusage() {
    this._appSer.get('Dashboard/GetDialerwiseStats').subscribe(res => {
      this.dialerwiseusage = res;
      var dd = [];
      debugger;
      for (var i = 0; i < this.dialerwiseusage.length; i++) {
        dd.push({ 'DailerMonth': this.dialerwiseusage[i].Monthname, 'KruptoConnect': this.dialerwiseusage[i].DialersCount[0].UsedCount, 'TATA': this.dialerwiseusage[i].DialersCount[1].UsedCount });
      }
      this.DailerWiseInfo = dd;
    });
  }
  getprocessnameData() {
    debugger
    this._appSer.get('Dashboard/GetTeams').subscribe(res => {
      this.processname = res;
      this.getprocessidload(this.processname[0].ProcessID,this.processname[0].TeamName)
    });

  }

  getprocessidload(value: any,value1:any) {
    debugger;
    this.ProcessID = value;
    this.teamleadname = null;
    //this.teamname=null;
    this.chartfreq = true;
    this.teamname=value1;
    this._appSer.get('Dashboard/GetTeamwiseDialerStats').subscribe(res => {
      
      this.teamleaders = [];
      this.teamleadersdata = res;
      var d = this.teamleadersdata.filter(res => (res.ProcessID == this.ProcessID));
      var dd = [];
      for (var i = 0; i < d.length; i++) {
        dd.push(d[i].Leadname);

      }
      this.teamleaders = dd;
      var value=dd[1]
this.getDailerTeamcountload(value);
    });


  }
  getDailerTeamcountload(value: any) {

    this._appSer.get('Dashboard/GetTeamwiseDialerStats').subscribe(res => {
      this.dataSource = [];
      this.teamleadname = value;
      //this.teamname=null;
      this.DialerTeamwiseData = res;
      var d = this.DialerTeamwiseData.filter(res => (res.Leadname == value && res.ProcessID == this.ProcessID));
      if (d.length != 0) {
        var dd = [];
        for (var i = 0; i < d[0].DialersCount.length; i++) {
          d[0].DialersCount[i].state = d[0].DialersCount[i].Dialername;
          dd.push(d[0].DialersCount[i]);
          this.chartfreq = false;
        }
        if (dd.length == 0) { this.chartfreq = true; }
        this.dataSource = dd;
      }
    });
  }


  getDailerTeamcount(value: any) {
debugger
    this._appSer.get('Dashboard/GetTeamwiseDialerStats').subscribe(res => {
      this.dataSource = [];
      this.DialerTeamwiseData = res;
      var d = this.DialerTeamwiseData.filter(res => (res.Leadname == value.value && res.ProcessID == this.ProcessID));
      if (d.length != 0) {
        var dd = [];
        for (var i = 0; i < d[0].DialersCount.length; i++) {
          d[0].DialersCount[i].state = d[0].DialersCount[i].Dialername;
          dd.push(d[0].DialersCount[i]);
          this.chartfreq = false;
        }
        if (dd.length == 0) { this.chartfreq = true; }
        this.dataSource = dd;
      }
    });
  }

  getData(dial?: any): any {

    //for (var i = 0; i < dial[0].DialersCount.length; i++) {
    if (dial) {
      let a = this.datanew.filter(item => item.DialerName === dial)
      let b = [{ DialerName: a[0].DialerName, Commodity: "Used", Count: a[0].UsedCount }, { DialerName: a[0].DialerName, Commodity: "Unused", Count: a[0].UnusedCount }]
      return b
    }
    // }
    return this.datanew;
  }
  customizeLabel(e) {
    return `${e.valueText}\n${e.argumentText}`;
  }
  calculateTotal(pieChart) {
    const totalValue = pieChart.getAllSeries()[0].getVisiblePoints().reduce((s, p) => s + p.originalValue, 0);
    return this.pipe.transform(totalValue, "1.0-0");
  }

  customizeTooltip(arg: any) {
    // alert(arg.valueText);
    return {
      text: arg.valueText
    };
  }

}
