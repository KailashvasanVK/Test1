export class DeploymentStatsModel {
    Dialername: any
    UsedCount: any
    UnusedCount: any
}
export class TeamwiseStatsModel {
    Teamname: any
    UsedCount: any
    UnusedCount: any
}
export class DialerCountModel {
    DialersCount: any
    Dialername: any
    DialerCount: any
    UsedCount: any
    UnusedCount: any
}

export class DialerwiseStatsModel {
    Monthname: any
    DialerCountModel: DialerCountModel
}

export class TeamwiseDialerStatsMode {
    Processname: any
    Leadname: any
    DialerCountModel: DialerCountModel
}