// import { DashboardModel } from './dashboard-model';

// describe('DashboardModel', () => {
//   it('should create an instance', () => {
//     expect(new DashboardModel()).toBeTruthy();
//   });
// });
