import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HeaderComponent ,DialogExistingUserComponent} from './header/header.component';
import {FormsModule,ReactiveFormsModule}    from '@angular/forms';
import {MatFormFieldModule} from '@angular/material/form-field';
import {CdkTableModule} from '@angular/cdk/table';
import { DxBarGaugeModule, DxCheckBoxModule } from 'devextreme-angular';
import { DxButtonModule,DxChartModule,DxSelectBoxModule,DxPieChartModule,DxPolarChartModule } from 'devextreme-angular';

import {
  MatAutocompleteModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,
  MatStepperModule,
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ProcessManagementComponent } from './process-management/process-management.component';
import { HttpClientModule } from '@angular/common/http';
import { TopheaderComponent } from './topheader/topheader.component';

import {
  DxDropDownBoxModule
} from 'devextreme-angular';
const modules = [
  CdkTableModule,
  MatAutocompleteModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatStepperModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  DxDropDownBoxModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,
];
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    DialogExistingUserComponent,
    DashboardComponent,
    ProcessManagementComponent,
    TopheaderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,modules,FormsModule,ReactiveFormsModule,DxButtonModule,DxChartModule,DxSelectBoxModule,DxPieChartModule,DxPolarChartModule,HttpClientModule,DxBarGaugeModule,
    DxCheckBoxModule
  ],
  providers: [{ provide: MatDialogRef, useValue: {} },
    { provide: MAT_DIALOG_DATA, useValue: [] },],
  bootstrap: [AppComponent],entryComponents:[DialogExistingUserComponent]
})
export class AppModule { }
