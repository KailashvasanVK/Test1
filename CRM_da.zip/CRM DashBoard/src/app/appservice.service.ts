import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { DeploymentStatsModel } from './Model/dashboard-model';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class AppserviceService {

    constructor(private http: HttpClient) { }
    apiURL = "http://10.20.79.116:1234/";
    


    get(url: string) {

        return this.http.get(this.apiURL + url);
    }




}
