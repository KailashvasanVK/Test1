# spark-streamingapp
Code for Spark Structured Streaming with Kafka and storing data into cassandra
