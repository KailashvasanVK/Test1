package com.streamapp.model

case class ProductSale(Id: String, firstName: String, lastName: String, house: String, street: String, city: String, state: String, zip: String, prod: String, tag: String) extends Serializable
