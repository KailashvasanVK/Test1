﻿using EmailMicroservice.Command;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using EmailMicroservice.Models;
using Microsoft.AspNetCore.Authorization;

namespace EmailMicroservice.Controllers
{
    [Route("Email")]
    public class EmailController : Controller
    {
        private IMediator _mediator;
        public EmailController(IMediator mediator)
        {
            _mediator = mediator;
        }

        //Handle Authorization
        [Authorize(Roles = "ADMIN")]  //Need to check if a policy is required to handle authorization to API methods
        [Route("SendEmail")]
        [HttpPost]
        public async Task<IActionResult> SendEmail([FromBody] SendEmailRequestCommand emailRequest)
        {
            try
            {
                //Write validation Code. If validation failed then return as BadRequest.
                var Result = await _mediator.Send(emailRequest);
                if (Result.Status == "1")
                    return Ok(Result);
                else
                    return StatusCode(400);
            }
            catch //(Exception ex)
            {
                //Log Exception
                return StatusCode(500);
            }
        }
    }
}
