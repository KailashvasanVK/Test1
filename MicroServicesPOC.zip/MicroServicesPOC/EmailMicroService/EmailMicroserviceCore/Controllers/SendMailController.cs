﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Net.Mime;
using System.Threading.Tasks;
using System.Web;
using EmailMicroservice.Command;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using System.Data;

namespace EmailMicroserviceCore.Controllers
{
    //[Route("api/[controller]")]
    [Authorize]
    [ApiController]
    public class SendMailController : ControllerBase
    {        
    
        private IMediator _mediator;
        IConfiguration configuration;
        public SendMailController(IMediator mediator, IConfiguration config)
        {
            _mediator = mediator;
            configuration = config;
        }
        
        [Route("api/[controller]/send")]
        [HttpPost]
        public async Task<IActionResult> Send(SendEmailRequestCommand sendEmailRequestCommand)
        {
            try
            {
                

                MailMessage mailMsg = new MailMessage();
                foreach (var address in sendEmailRequestCommand.To.Split(new[] { ";" }, StringSplitOptions.RemoveEmptyEntries))
                {
                    //mailMsg.To.Add(new MailAddress(sendEmailRequestCommand.To));
                    //Email Id Validation
                    Regex regex = new Regex(@"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$");
                    bool isValid = regex.IsMatch(address);
                    if (!isValid)
                    {
                        return BadRequest("please Enter the proper To mail Id!!");
                    }
                    else
                    {
                        mailMsg.To.Add(new MailAddress(address));
                    }
                }
                mailMsg.From = new MailAddress(sendEmailRequestCommand.From);
                foreach (var address in sendEmailRequestCommand.Cc.Split(new[] { ";" }, StringSplitOptions.RemoveEmptyEntries))
                {
                    Regex regex = new Regex(@"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$");
                    bool isValid = regex.IsMatch(address);
                    if (!isValid)
                    {
                        return BadRequest("please Enter the proper CC mail Id!!");
                    }
                    else
                    {
                        mailMsg.CC.Add(new MailAddress(address));
                    }
                   
                }

                mailMsg.Subject = sendEmailRequestCommand.Subject;
                string filepath;
                if (sendEmailRequestCommand.FilePath != string.Empty)
                {
                    filepath = sendEmailRequestCommand.FilePath;
                    byte[] bytes;
                    using (FileStream file = new FileStream(filepath, FileMode.Open, FileAccess.Read))
                    {
                        bytes = new byte[file.Length];
                        file.Read(bytes, 0, (int)file.Length);
                    }

                    Attachment attachment = new Attachment(new MemoryStream(bytes), Path.GetFileName(filepath));
                    mailMsg.Attachments.Add(attachment);
                }
                else
                {
                    filepath = string.Empty;
                }
                mailMsg.AlternateViews.Add(AlternateView.CreateAlternateViewFromString(sendEmailRequestCommand.Body, null, MediaTypeNames.Text.Html));
                mailMsg.Body = sendEmailRequestCommand.Body;
                SmtpClient smtpClient = new SmtpClient(configuration.GetSection("SMTP")
                    .GetSection("Server").Value, Convert.ToInt32(configuration
                    .GetSection("SMTP").GetSection("Port").Value));
                smtpClient.UseDefaultCredentials = false;
                smtpClient.EnableSsl = true;
                System.Net.NetworkCredential credentials = new System.Net.NetworkCredential(configuration.GetSection("Network")
                    .GetSection("Username").Value, configuration.GetSection("Network")
                    .GetSection("Password").Value);
                smtpClient.Credentials = credentials;
                bool containsHTML = (sendEmailRequestCommand.Body != HttpUtility.HtmlEncode(sendEmailRequestCommand.Body));
                if (containsHTML) { sendEmailRequestCommand.IsHTML = 'Y'; } else { sendEmailRequestCommand.IsHTML = 'N'; }
                smtpClient.Send(mailMsg);
                sendEmailRequestCommand.MailStatus = 1;
                sendEmailRequestCommand.CreatedDate = DateTime.Now;
                sendEmailRequestCommand.CreatedBy = Environment.UserName;
                if (!string.IsNullOrEmpty(mailMsg.From.ToString()) &&
                    !string.IsNullOrEmpty(mailMsg.To.ToString()) &&
                    !string.IsNullOrEmpty(mailMsg.Subject.ToString()) &&
                    !string.IsNullOrEmpty(mailMsg.Body.ToString()))
                {
                    var Result = await _mediator.Send(sendEmailRequestCommand);
                    return Ok("mail Succeessfully Sent");
                }
                else
                {
                    return BadRequest("Bad Request. Please provide all required fields.");
                }
                //Production Use Only 
                //string constring = configuration.GetSection("ConnectionStrings").GetSection("ARCConnection").Value;
                //using (SqlConnection con = new SqlConnection(constring))
                //{
                //    using (SqlCommand cmd = new SqlCommand("P_add_EMAIL_CONTENT", con))
                //    {
                //        cmd.CommandType = CommandType.StoredProcedure;
                //        cmd.Parameters.AddWithValue("@FromMail", mailMsg.From.ToString());
                //        cmd.Parameters.AddWithValue("@ToMail", mailMsg.To.ToString());
                //        cmd.Parameters.AddWithValue("@Subject", mailMsg.Subject.ToString());
                //        cmd.Parameters.AddWithValue("@Body", mailMsg.Body.ToString());
                //        cmd.Parameters.AddWithValue("@Ishtml", sendEmailRequestCommand.IsHTML.ToString());
                //        cmd.Parameters.AddWithValue("@CcMail", mailMsg.CC.ToString());
                //        cmd.Parameters.AddWithValue("@FilePath", filepath);
                //        cmd.Parameters.Add("@ResultStatus", SqlDbType.VarChar, 30);
                //        cmd.Parameters["@ResultStatus"].Direction = ParameterDirection.Output;
                //        con.Open();
                //        cmd.ExecuteNonQuery();
                //        con.Close();
                //        string resultStatus = cmd.Parameters["@ResultStatus"].Value.ToString();
                //        if (resultStatus == "Y")
                //        {
                //            sendEmailRequestCommand.MailStatus = 1;
                //            sendEmailRequestCommand.CreatedDate = DateTime.Now;
                //            sendEmailRequestCommand.CreatedBy = Environment.UserName;
                //            var Result = await _mediator.Send(sendEmailRequestCommand);
                //            return Ok("Mail Succeessfully Sent");
                //        }
                //        else
                //        {
                //            return BadRequest("SomeThing Went Wrong!!!");
                //        }
                //    }

                //}
            }

            catch (Exception ex)
            {
                sendEmailRequestCommand.MailStatus = 0;
                sendEmailRequestCommand.Exception = ex.Message;
                var Result = await _mediator.Send(sendEmailRequestCommand);
                return BadRequest(ex.Message);
            }
        }
    }
}
   

//sample data
//SendEmailRequestCommand emailRequest = new SendEmailRequestCommand();
//mailMsg.Subject = "Test";
//sendEmailRequestCommand.To = "gurunathan.g@accesshealthcare.com";
//sendEmailRequestCommand.From = "gurunathan.g@accesshealthcare.com";
//sendEmailRequestCommand.Cc = "jayashri.ganesa@accesshealthcare.com";
//sendEmailRequestCommand.RequestId = 13;
//sendEmailRequestCommand.Body = "Sample";
//sendEmailRequestCommand.CreatedBy = "Guru";
//sendEmailRequestCommand.IsHTML = 'Y';
//sendEmailRequestCommand.CreatedDate = DateTime.Now;

//sendEmailRequestCommand.Subject = mailMsg.Subject;
//                string html = @"<p>'dotnet.exe' (CoreCLR: clrhost): Loaded 'C:\Program Files\dotnet\shared\Microsoft.NETCore.App\2.1.9\System.Collections.Specialized.dll'. Skipped loading symbols. Module is optimized and the debugger option 'Just My Code' is enabled.
//'dotnet.exe' (CoreCLR: clrhost): Loaded 'C:\Program Files\dotnet\shared\Microsoft.NETCore.App\2.1.9\System.Drawing.Primitives.dll'. Skipped loading symbols. Module is optimized and the debugger option 'Just My Code' is enabled.
//'dotnet.exe' (CoreCLR: clrhost): Loaded 'C:\Program Files\dotnet\shared\Microsoft.</p>";           