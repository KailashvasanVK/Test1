﻿using EmailMicroservice.Command;
using EmailMicroservice.Repository;
using EmailMicroserviceCore.External;
using EmailMicroserviceCore.External.Model;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Text.RegularExpressions;


namespace EmailMicroserviceCore.Middleware
{
    public class Authentication
    {
        private readonly RequestDelegate _next;
        private IHttpClient _httpClient;

        public Authentication(RequestDelegate next, IHttpClient httpClient)
        {
            _next = next;
            _httpClient = httpClient;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                /* Incorporate validation.
                   Handle exceptions. */
                //   try
                //              

                //var responseUserName = "";
                string token = context.Request.Headers["Token"];
                string userName = context.Request.Headers["UserName"];
                if (token != null)
                {
                    User user = new User();
                    user.Token = token;
                    user.Username = userName;
                    var userObj = _httpClient.ValidateToken(user);
                    if (userName == userObj.Username)
                    {
                        ClaimsIdentity claimsIdentity = new ClaimsIdentity("Custom");
                        var claims = new List<Claim>();
                        claims.Add(new Claim(ClaimTypes.Name, user.Username));
                        claims.Add(new Claim(ClaimTypes.NameIdentifier, "admin"));
                        claims.Add(new Claim(ClaimTypes.Role, userObj.Role.ToString()));
                        ClaimsPrincipal claimsPrincipal = new ClaimsPrincipal(claimsIdentity);
                        context.User = claimsPrincipal;
                        context.Response.Headers.Add(ClaimTypes.Role, userObj.Role.ToString());
                    }
                    else
                    {
                        throw new UnauthorizedAccessException("User is not Authorized.");
                        
                    }
                }

                await _next(context);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


    }
    public class statusresult
    {
        public string Status { get; set; }

        
    }

}
