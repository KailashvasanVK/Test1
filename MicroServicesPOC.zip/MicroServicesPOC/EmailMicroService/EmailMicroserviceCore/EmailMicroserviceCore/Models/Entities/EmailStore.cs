﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EmailMicroserviceCore.Models.Entities
{
    public partial class EmailStore
    {
        [Key]
        public int RequestId { get; set; }
        public string From { get; set; }
        public string To { get; set; }
        public string Cc { get; set; }
        public char IsHTML { get; set; }
        public string Body { get; set; }
        public int MailStatus { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public string FilePath { get; set; }
        public string Subject { get; set; }
        public string Active { get; set; }
        public string Exception { get; set; }
        public string AppName { get; set; }
        //public int RequestId { get; set; }
        //public string From { get; set; }
        //public string To { get; set; }
        //public string Body { get; set; }
        //public DateTime CreatedDate { get; set; }
        //public string CreatedBy { get; set; }
    }
}
