﻿using EmailMicroservice.Models;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmailMicroservice.Command
{
    //For Query - This model is not generic. Can have seperate response type for each query.
    public class PendingDetailsResponse
    {
        public int RequestId { get; set; }
        public string From { get; set; }
        public string To { get; set; }
        public string Body { get; set; }
        public DateTime CreatedDate { get; set; }
        public int MailStatus { get; set; }
        public bool IsHTML { get; set; }
        public string CreatedBy { get; set; }
        public string FilePath { get; set; }
        public string Subject { get; set; }
        public string Cc { get; set; }

        //Other details.

        public string Filecontent { get; set; }
        public string Filename { get; set; }
        public int AppId { get; set; }
        //Other details.
    }
}