﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MediatR;
using EmailMicroservice.Repository;
using EmailMicroserviceCore.Models.Entities;
using Microsoft.EntityFrameworkCore;
using AutoMapper;
using EmailMicroserviceCore.Mapper;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using EmailMicroserviceCore.Middleware;
using EmailMicroserviceCore.External;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.AspNetCore.Authorization;

namespace EmailMicroserviceCore
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
            // Auto Mapper Configurations
            var mappingConfig = new MapperConfiguration(mc =>
            {
                mc.AddProfile(new MappingProfiles());
            });
            IMapper mapper = mappingConfig.CreateMapper();
            services.AddSingleton(mapper);

            services.AddDbContext<AhsPlatform_183Context>(options => options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));
            services.AddTransient<IEmailServiceRepository, EmailServiceRepository>();
            services.AddScoped(typeof(IEmailServiceRepository), typeof(EmailServiceRepository));
            services.AddMediatR(typeof(Startup));
            services.AddHttpClient();
            services.AddSingleton<IHttpClient, HttpClient>();
            services.AddSingleton<IConfiguration>(Configuration);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            app.UseMiddleware<Authentication>();
            //app.ApplyUserTokenValidation();
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            }            
            //app.UseMiddleware<Redirect>();
            app.UseMvc();
           
        }  
     
    }
}
