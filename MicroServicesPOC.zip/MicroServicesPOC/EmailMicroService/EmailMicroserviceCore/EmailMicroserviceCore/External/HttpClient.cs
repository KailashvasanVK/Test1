﻿using EmailMicroservice.Command;
using EmailMicroserviceCore.External.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;

namespace EmailMicroserviceCore.External
{
    public class HttpClient: IHttpClient
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IConfiguration _configuration;
       
        public HttpClient(IHttpClientFactory httpClientFactory, IConfiguration iconfiguration)
        {
            _httpClientFactory = httpClientFactory;
            _configuration = iconfiguration;
        }
        public User ValidateToken(User user)
        {
            try
            {
                var client = _httpClientFactory.CreateClient();
                /*Need to move the URL to configuration
                 Incorporate Validation code*/
                string url = _configuration.GetSection("ServerName").GetSection("ServerUrl").Value;
                client.BaseAddress = new Uri(url);
                var response = client.PostAsJsonAsync("", user).Result;
                var responseContent = response.Content.ReadAsStringAsync().Result;
                var responseObj = JsonConvert.DeserializeObject<User>(responseContent);                
                return responseObj;
            }
            catch(Exception ex)
            {
                //Handle Exception
                throw ex;
            }
        }


    }
}