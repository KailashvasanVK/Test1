﻿using EmailMicroserviceCore.External.Model;

namespace EmailMicroserviceCore.External
{
    public interface IHttpClient
    {
        User ValidateToken(User user);
    }
}
