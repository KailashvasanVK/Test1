﻿using AutoMapper;
using EmailMicroservice.Command;
using EmailMicroserviceCore.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmailMicroserviceCore.Mapper
{
    public class MappingProfiles: Profile
    {
        public MappingProfiles()
        {
            CreateMap<SendEmailRequestCommand, EmailStore>().ReverseMap();
        }
    }
}
