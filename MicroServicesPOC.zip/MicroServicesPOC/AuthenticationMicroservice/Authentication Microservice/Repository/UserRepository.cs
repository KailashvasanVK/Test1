﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Extensions.Options;
using System.Text;
using System.Net;
using Authentication.Microservice.Model.Entities;
using Microsoft.EntityFrameworkCore;
using Authentication.Model.Entities;

namespace Authentication
{
    public class UserRepository : IUserRepository
    {
        private AhsPlatform_183Context _context;
        public List<User> _users;
        private DbSet<User> _emailEntity;
        private readonly AppSettings _appSettings;
        ITokenManager _tokenManager;
        public UserRepository(AhsPlatform_183Context context, IOptions<AppSettings> appSettings, ITokenManager tokenManager)
        {
            this._context = context;
            _emailEntity = context.Set<User>();
            // _users = new List<User>();
            // _users.Add(new User() { Username = "Test1", Password = "Pass1", Role = Roles.ADMIN });
            // _users.Add(new User() { Username = "Test2", Password = "Pass2", Role = Roles.CREATOR });
            _appSettings = appSettings.Value;

            _tokenManager = tokenManager;
        }
        public User Authenticate(string username, string password)
        {
            try
            {
                //var user = _users.SingleOrDefault(x => x.Username == username && x.Password == password);
                var user = _context.User.SingleOrDefault(a => a.Username == username && a.Password == password);
                // return null if user not found
                if (user == null)
                    return null;
                // authentication successful so generate jwt token
                _tokenManager.CreateToken(user, username);
                return user;
            }
            catch (Exception ex)
            {
                //Handle exception & Write log
                return null;
            }
        }
        public User GetRoles(User user)
        {
            try
            {
                var objUser = _users.SingleOrDefault(x => x.Username == user.Username);
                if (objUser == null)
                    return null;
                else
                {
                    objUser.Password = null;
                    return objUser;
                }
            }
            catch (Exception ex)
            {
                //Handle exception & Write log
                return null;
            }
        }
    }
}
