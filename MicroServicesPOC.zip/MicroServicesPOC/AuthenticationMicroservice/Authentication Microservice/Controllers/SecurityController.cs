﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MediatR;

namespace Authentication_Microservice.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api /[controller]")]
    public class UserController : ControllerBase
    {
        private IUserRepository _userRepository;       
        ITokenManager _tokenManager;

       
        public UserController(IUserRepository userService, ITokenManager tokenManager)
        {
            _userRepository = userService;           
            _tokenManager = tokenManager;
        }

        [AllowAnonymous]
        [HttpPost("Authenticate")]
        public IActionResult Authenticate([FromBody]User user)
        {
            //Write Validation code
            var objUser = _userRepository.Authenticate(user.Username, user.Password);
            if (objUser == null)
                return BadRequest(new { message = "Username or password is incorrect" });
            return Ok(objUser);
        }

        [AllowAnonymous]
        [HttpPost("ValidateToken")]
        public IActionResult ValidateToken([FromBody]User user)
        {
            //Write validation code
            string tokenUsername = _tokenManager.ValidateToken(user.Token);
            if (user.Username.Equals(tokenUsername))
            {
                var objUser = _userRepository.GetRoles(user);
                return Ok(objUser);
            }
            else
                return BadRequest();
        }
    }
}
