﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Authentication.Model.Entities;

namespace Authentication.Microservice.Model.Entities
{
    public class AhsPlatform_183Context:DbContext
{
    public AhsPlatform_183Context()
    {
    }

    public AhsPlatform_183Context(DbContextOptions<AhsPlatform_183Context> options)
        : base(options)
    {
    }

    public virtual DbSet<User> User { get; set; }
        
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!optionsBuilder.IsConfigured)
        {
            optionsBuilder.UseSqlServer("Server=AHS-HQ-DEVDB,30786;Database=AhsPlatform_183;Trusted_Connection=True;");
        }
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
            modelBuilder
        .Entity<User>()
        .Property(e => e.Role)
        .HasConversion(
            v => v.ToString(),
            v => (Roles)Enum.Parse(typeof(Roles), v));
        }
}
}
