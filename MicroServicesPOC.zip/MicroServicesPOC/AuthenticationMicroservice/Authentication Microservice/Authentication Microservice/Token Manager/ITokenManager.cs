﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Authentication
{
    public interface ITokenManager 
    {
        User CreateToken(User user, string userName);
        string ValidateToken(string token);
        ClaimsPrincipal GetPrincipal(string token);

    }
}
