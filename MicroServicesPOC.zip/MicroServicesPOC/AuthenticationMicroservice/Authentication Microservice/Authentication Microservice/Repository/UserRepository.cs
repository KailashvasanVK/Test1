﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Extensions.Options;
using System.Text;
using System.Net;
using Authentication.Microservice.Model.Entities;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using Authentication.Model.Entities;
using System.IO;

namespace Authentication
{
    public class UserRepository : IUserRepository
    {
        private AhsPlatform_183Context _context;
        public List<User> _users;
        private DbSet<User> _emailEntity;
        private readonly AppSettings _appSettings;
        ITokenManager _tokenManager;
        public UserRepository(AhsPlatform_183Context context, IOptions<AppSettings> appSettings, ITokenManager tokenManager)
        {
            this._context = context;
            _emailEntity = context.Set<User>();
            _appSettings = appSettings.Value;

            _tokenManager = tokenManager;
        }
        public User Authenticate(string username, string password)
        {
            try
            {

                var user = _context.User.FirstOrDefault(a => a.Username == username && Decrypt(a.Password) == Decrypt(password));
                if (null != user)
                {
                    _tokenManager.CreateToken(user, username);
                    return user;
                }
                return null;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public User GetRoles(User user)
        {
            try
            {
                var objUser = _context.User.SingleOrDefault(x => x.Username == user.Username);
                if (objUser == null)
                    return null;
                else
                {
                    objUser.Password = null;
                    return objUser;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        private string Decrypt(string cipherText)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return cipherText;
        }
    }
}
